DROP TABLE IF EXISTS [dbo].[timesheet_overdue_data_export_log]

	CREATE TABLE [dbo].[timesheet_overdue_data_export_log](
		[processid] [nvarchar](16) NOT NULL,
		[starttime] [datetime] NULL,
		[lastupdated] [datetime] NULL,
		[lastProgramid] [int] NULL,
		[lasttemplateid] [int] NULL,
		[Status] [int] NULL
	) ON [PRIMARY]

	/* Retrieve data from backup table */
	INSERT INTO [dbo].[timesheet_overdue_data_export_log]
			   ([processid]
				,[starttime]
				,[lastupdated]
				,[lastProgramid]
				,[lasttemplateid]
				,[Status])
		SELECT [processid]
				,[starttime]
				,[lastupdated]
				,[lastProgramid]
				,[lasttemplateid]
				,[Status]
			FROM [americalearns2008_03202020].[dbo].[timesheet_overdue_data_export_log]
		Order by [processid]

		--483020 row(s) affected)