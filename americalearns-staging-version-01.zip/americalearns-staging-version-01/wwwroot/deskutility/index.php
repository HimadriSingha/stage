<?php
define('FRESHDESK_SHARED_SECRET','be7b2977405bac55b09224f4a2818c9c');
define('FRESHDESK_BASE_URL','http://americalearns.freshdesk.com/');	

function getSSOUrl($strName, $strEmail) {
	$timestamp = time();
	$to_be_hashed = $strName . FRESHDESK_SHARED_SECRET . $strEmail . $timestamp;
	$hash = hash_hmac('md5', $to_be_hashed, FRESHDESK_SHARED_SECRET);
	return FRESHDESK_BASE_URL."login/sso/?name=".urlencode($strName)."&email=".urlencode($strEmail)."&timestamp=".$timestamp."&hash=".$hash;
}

$custName = $_GET['name'];
$email = $_GET['email'];

echo getSSOUrl($custName,$email)
?>