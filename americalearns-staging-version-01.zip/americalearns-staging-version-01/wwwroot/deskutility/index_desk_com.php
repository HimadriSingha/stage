
<?php
$account_key = 'americalearns';
$api_key     = 'b24550703db80130d1c112313f070061';

$salted = $api_key . $account_key;
$hash = hash('sha1',$salted,true);
$saltedHash = substr($hash,0,16);
$iv = "OpenSSL for Ruby";

$userid=$_GET['uid'];
$custEmail = $_GET['email'];
$custName = $_GET['name'];
$dat = $_GET['dat'];

// Build json data
/*$user_data = array(
	'uid' => '125',
	'customer_email' => 'glk9@americalearns.net',
	'customer_name' => 'Alison',
	'expires' => date("c", strtotime("+5 minutes"))
);*/

$user_data = array(
	'uid' => $userid,
	'customer_email' => $custEmail,
	'customer_name' => $custName,
	'expires' => date("c", strtotime("+5 minutes"))
	
);

$data = json_encode($user_data);

// XOR first block of data with IV
for ($i = 0; $i < 16; $i++) {
	$data[$i] = $data[$i] ^ $iv[$i];
}

// pad using standard PKCS#5 padding with block size of 16 bytes
$pad = 16 - (strlen($data) % 16);
$data = $data . str_repeat(chr($pad), $pad);

// encrypt data using AES128-cbc
$cipher = mcrypt_module_open(MCRYPT_RIJNDAEL_128,'','cbc','');
mcrypt_generic_init($cipher, $saltedHash, $iv);
$multipass = mcrypt_generic($cipher,$data);
mcrypt_generic_deinit($cipher);

// Base64 encode the encrypted data
$multipass = base64_encode($multipass);

// Convert encoded data to the URL safe variant
$multipass = preg_replace('/\=$/', '', $multipass);
$multipass = preg_replace('/\n/', '', $multipass);
$multipass = preg_replace('/\+/', '-', $multipass);
$multipass = preg_replace('/\//', '_', $multipass);

// Build an HMAC-SHA1 signature using the multipass string and your API key
$signature = hash_hmac("sha1", $multipass, $api_key, true);
// Base64 encode the signature
$signature = base64_encode($signature);

// Finally, URL encode the multipass and signature
$multipass = urlencode($multipass);
$signature = urlencode($signature);

$urlk = 'https://americalearns.desk.com/customer/authentication/multipass/callback?multipass=';
$urlk = $urlk . $multipass .'&signature='.$signature;

echo $urlk;
?>