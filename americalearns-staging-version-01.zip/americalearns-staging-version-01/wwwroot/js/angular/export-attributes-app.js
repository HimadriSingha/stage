//Adminfunct-94
var ChurnZero = ChurnZero || [];
var downloadZipRow = 0; // MV-1943
var selectedarrayorder = [];
var previewBGExport = 0;
var fromSavedReport = 0;
(function() {
    var cz = document.createElement('script'); cz.type = 'text/javascript';
    cz.async = true;
    cz.src = 'https://analytics.churnzero.net/churnzero.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(cz, s);
})();

//Adminfunct-94
/*var browserInfo = navigator.userAgent;
var browser = "";
if (browserInfo.includes('Opera') || browserInfo.includes('Opr')) {
  browser = 'Opera';
} else if (browserInfo.includes('Edg')) {
  browser = 'Edge';
} else if (browserInfo.includes('Chrome')) {
  browser = 'Chrome';
} else if (browserInfo.includes('Safari')) {
  browser = 'Safari';
} else if (browserInfo.includes('Firefox')) {
  browser = 'Firefox'
} else {
  browser = 'unknown'
}*/

/* YEOU : START */
var app = angular.module('exportAttributeApp', ['ngAnimate', 'ngTouch', 'ui.grid', 'ui.grid.moveColumns', 'ui.grid.saveState', 'ui.grid.selection', 'ui.grid.cellNav', 'ui.grid.resizeColumns', 'ui.grid.moveColumns', 'ui.grid.pinning', 'ui.grid.grouping', 'ui.grid.pagination', 'ui.grid.exporter']);

//app.controller('exportAttributeCtrl', ['$scope', '$timeout', '$compile', '$sce', 'uiGridConstants', 'uiGridExporterService', 'uiGridExporterConstants','exportUiGridService', function ($scope, $timeout, $compile, $sce, uiGridConstants, uiGridExporterService, uiGridExporterConstants,exportUiGridService) {
//ASSNS-527
app.controller('exportAttributeCtrl', ['$scope', '$timeout', '$compile', '$sce', 'uiGridConstants', 'uiGridExporterConstants',function ($scope, $timeout, $compile, $sce, uiGridConstants, uiGridExporterConstants) {
	
	var colCount;
	var rowCount;
	var response;
	var downloadReport = false;
	//var totalIdentifierAliasPlural; // BG-113
	$scope.attributeOrder = [];			// DS:: BG-454
	
	var hideAjaxLoadingOverlay = function () {
		$('#ajaxFilterLoading .bg').height('100%');
		$('#ajaxFilterLoading').fadeOut(300);
	}

	var showLoadingOverlay = function () {
		$('#ajaxFilterLoading .bg').height('100%');
		$('#ajaxFilterLoading').fadeIn(300);
		$("#ajaxFilterLoading").attr("tabindex", -1).focus();
	};

	$scope.removeFieldOrder = []; // ASSNS-527
	//Save the order of columns in hidden field.
	$scope.state = "";
	$scope.saveOrder = function() {		
		var state = $scope.gridApi.saveState.save();
		$scope.state = state;		
		var attributeOrder = [];
		$scope.attributeOrder = [];
		/* Start: BG-113 */
		$scope.attributeOrder.push('attribute_identifiername');
		attributeOrder.push('attribute_identifiername');
		var columnDefs = $scope.gridOptions.columnDefs;
		/* End: BG-113 */
		for (var i = 0; i < state.columns.length; i++) {
			var attributeid=state.columns[i].name;
			if(attributeid != 'attribute_identifiername') {	 /* Added conditions: BG-113 */			 
				 attributeOrder.push(attributeid);
				 $scope.attributeOrder.push(attributeid);				//BG-454
				
			}
			
		}
		$("#attributesortorder").val($scope.attributeOrder);
		$("#setAttributeOrder").val('1');
	}

	//Modified BG-64 : Start
	$scope.restoreOrder = function(){
		var attributesortorder = $("#attributesortorder").val().split(',');
		var columns = [];
		var noOfColumns = attributesortorder.length;
		for(var i = 0; i < noOfColumns; ++i){
			$scope.state.columns.find(function(column){
				if(typeof column.name != "undefined" && column.name === attributesortorder[i]){
					columns.push(column.name);
				}
			});
		}
		$scope.state.columns = columns;

		$scope.gridApi.saveState.restore( $scope, $scope.state);
	}
	//Modified BG-64 : Stops

	$scope.gridOptions = {
		enableColumnResizing: true,
		enableColumnMoving: true,
		enableSorting: true,
		enableHiding: false,
		enableSelectAll: true,
		exporterCsvFilename: 'myFile.csv',
		exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
		onRegisterApi: function (gridApi) {
			$scope.gridApi = gridApi;
			$scope.gridApi.colMovable.on.columnPositionChanged($scope, $scope.saveOrder);
		}
	};
	$scope.htmlEncode = function (value) {
		//create a in-memory div, set it's inner text(which jQuery automatically encodes)
		//then grab the encoded contents back out.  The div never exists on the page.
		return $('<div/>').text(value).html();
	}

	$scope.current_date_decider_flag ="remove";//Added for BG-64
	$scope.historical_date_decider_flag ="remove";//Added for BG-64

	$scope.displayAttributesBasedOnCheckbox = function (downloadReport) {
		$scope.checkIfAllCheckboxAreChecked();

		colCount = response.headers;
		rowCount = response.data;		
		archivedSiteList = response.archivedSiteList; //BG-577
		//identifiercount = response.totalidentifiercount;
		attributepermission = response.attributepermission;
		$scope.gridOptions.columnDefs = [];
		$scope.gridOptions.data = [];
		var columnDefs = [];
		var newcolumnDefs = [];
		var associationid = $("#associationid").val();
    		var listCheckedAttributes = [];
		var totalIdentifierCount = [];
		$scope.fieldcount = $scope.attributeOrder.length;
		var temp=0;        //BG-454
		
	  	if(Array.isArray(selectedarrayorder) && selectedarrayorder.length) {
			
			listCheckedAttributes = selectedarrayorder;
			temp=1;
			$scope.attributeOrder =listCheckedAttributes;
		
		} else {
			$scope.attributeOrder = $.map($(".childpanelitem:checked"), function (val, i) {
			return $(val).attr("data-attribute-id");
			});
		}
		
		$timeout(function () {
			var headersLength = colCount.length;
			//for (var j = 0; j < listCheckedAttributes.length; ++j) { 				// Comment :: DS:: BG-454
				for(var i= 0 ; i < headersLength; ++i)
				{
					
				//if (listCheckedAttributes[j] === colCount[i].id) {                        // Comment :: DS:: BG-454
					if ($scope.attributeOrder.indexOf(colCount[i].id) != -1) {                    // ADD :: DS:: BG-454
					var encodedColName = $scope.htmlEncode(colCount[i].displayName);
					var encodedPanelName = $scope.htmlEncode(colCount[i].panelname);
					var encodedSubpanelName = colCount[i].subpanelname != 'Default' ? ': ' + $scope.htmlEncode(colCount[i].subpanelname) : '';

					//Start HeaderTemp
					var headerTemp = '<div role="columnheader" ng-class="{ \'sortable\': sortable }"  ui-grid-one-bind-aria-labelledby-grid="col.uid + \'-header-text \' + col.uid + \'-sortdir-text\'" aria-sort="{{col.sort.direction == asc ? \'ascending\' : ( col.sort.direction == desc ? \'descending\' : (!col.sort.direction ? \'none\' : \'other\'))}}">' + '<div role="button" tabindex="0" class="ui-grid-cell-contents ui-grid-header-cell-primary-focus" col-index="renderIndex" title="TOOLTIP"' +
						'>' + '<span class="ui-grid-header-cell-label" ui-grid-one-bind-id-grid="col.uid + \'-header-text\'">' + encodedPanelName + encodedSubpanelName + '{{  CUSTOM_FILTERS }}</span>' + '</br><div style="float:left;margin-top:10px;color:#fff">' + encodedColName + /* --BG-110: Start-- */((typeof colCount[i].agefield !== "undefined" && colCount[i].agefield == "currentAge") ? ' (in years)' : '') /* --BG-110: End-- */ + '</div>' +
						'<span ui-grid-one-bind-id-grid="col.uid + \'-sortdir-text\'" ui-grid-visible="col.sort.direction"' +
						'aria-label="{{getSortDirectionAriaLabel()}}" style="float:left;margin-left: 1px;margin-top: 14px;"> <i id="' + colCount[i].name.trim() + '" ng-class="{ \'ui-grid-icon-up-dir\': col.sort.direction == asc, \'ui-grid-icon-down-dir\':' + 'col.sort.direction == desc, \'ui-grid-icon-blank\': !col.sort.direction }"' +
						'title="{{isSortPriorityVisible() ? i18n.headerCell.priority + \' \' + ( col.sort.priority + 1' + ' )  : null}}"' + ' aria-hidden="true">&nbsp;&nbsp;</i>' + '<sub ui-grid-visible="isSortPriorityVisible()" class="ui-grid-sort-priority-number">' + '{{col.sort.priority + 1}}</sub>' + '</span> </div>' + '<div role="button" tabindex="0" ui-grid-one-bind-id-grid="col.uid + \'-menu-button\'" ' + 'class="ui-grid-column-menu-button" ng-if="grid.options.enableColumnMenus && !col.isRowHeader  &&' + 'col.colDef.enableColumnMenu !== false" ng-click="toggleMenu($event)" ng-class="{\'ui-grid-column-menu-button-last-col\': isLastCol}"' +
						'ui-grid-one-bind-aria-label="i18n.headerCell.aria.columnMenuButtonLabel" aria-haspopup="true">' +
						'<i class="ui-grid-icon-angle-down" aria-hidden="true"> &nbsp;</i></div>' + '<div ui-grid-filter></div></div>';
					if (colCount[i].attributeid !== 'attribute_identifiername') {
						headerTemp += '<div class="delColumn" ng-controller="exportAttributeCtrl"><div class="deletecolumn" ng-click="grid.appScope.removeColumn(' + colCount[i].panelid + ',' + "'" + colCount[i].subpanelid + "'" + ',' + "'" + colCount[i].id + "'" + ')" style="float:right;" rel="' + colCount[i].id + '"></div></div>';
					}
					//End HeaderTemp

					//Start editCellTemp
					var editCellTemp = '';
					var cellTemp = '';
					var cellclass = '{{ row.entity.cellclass }}';
					var celleditable = '{{ row.entity.celleditable }}';
					var editCellClass = '';
					var pencilCellClass = '';
					if (colCount[i].name.trim() === "attribute_identifierid" || colCount[i].name.trim() === "attribute_createdon" || colCount[i].name.trim() === "attribute_historicalassignedto") {
						editCellTemp += 'data-attr-head="' + encodedColName + '" title="{{ COL_FIELD.trim() }}"';
					} else if(colCount[i].attributetype === "file") {
						editCellTemp = 'data-attr-head="' + encodedColName + '" panelid="' + colCount[i].panelid + '" panelname="' + encodedPanelName + '" paneltype="' + colCount[i].paneltype + '" subpanelid="' + colCount[i].subpanelid + '" subpanelname="' + colCount[i].subpanelname + '" column="' + colCount[i].name + '" columnvalue="{{ COL_FIELD.trim() }}" attribute_identifierid="{{ row.entity.attribute_identifierid }}" title="' + encodedColName + '" attributetype="' + colCount[i].attributetype + '" attributeid="' + colCount[i].attributeid + '"';
						editCellClass = cellclass + 'section';
						pencilCellClass = cellclass;
					} else {
						editCellTemp = 'data-attr-head="' + encodedColName + '" panelid="' + colCount[i].panelid + '" panelname="' + encodedPanelName + '" paneltype="' + colCount[i].paneltype + '" subpanelid="' + colCount[i].subpanelid + '" subpanelname="' + colCount[i].subpanelname + '" column="' + colCount[i].name + '" columnvalue="{{ COL_FIELD.trim() }}" attribute_identifierid="{{ row.entity.attribute_identifierid }}" title="{{ COL_FIELD.trim() }}" attributetype="' + colCount[i].attributetype + '" attributeid="' + colCount[i].attributeid + '"';
						editCellClass = cellclass + 'section';
						pencilCellClass = cellclass;
					}

					cellTemp = '<div class="ngCellText ui-grid-cell-contents ng-binding ng-scope ' + editCellClass + '"';

					cellTemp += editCellTemp;

					cellTemp += '>';
					if (colCount[i].name.trim() == "attribute_identifiername") {
						cellTemp += '<span id="identifier_attribute_{{ row.entity.attribute_identifierid }}_'+colCount[i].attributeid+'" style="float:left;overflow: hidden;position: absolute;text-overflow: ellipsis;white-space: nowrap;"><a href="/index.cfm?event=dashboard.view_missioncontrol&associationid=' + associationid +'&associationitemid={{ row.entity.attribute_identifierid }}" target="_blank">{{ COL_FIELD }}</a></span>';
					} 
					// ASSNS-527 Starts
					else if (colCount[i].name.trim() != "attribute_identifiername" && colCount[i].attributetype.trim() == 'file'){
						cellTemp += '<span id="identifier_attribute_{{ row.entity.attribute_identifierid }}_'+colCount[i].attributeid+'" style="float:left;overflow: hidden;position: absolute;text-overflow: ellipsis;white-space: nowrap;"><div ng-bind-html="COL_FIELD | trusted"></div></span>';
					} 
					// ASSNS-527 Ends

					// BG-64 Start
					else if(colCount[i].name.trim() == 'attribute_historicalassignedto'){
						cellTemp += '<span id="identifier_attribute_{{ row.entity.attribute_identifierid }}_'+colCount[i].attributeid+'" class="historicaldates" style="float:left;overflow: hidden;position: absolute;text-overflow: ellipsis;white-space: nowrap;"><div ng-bind-html="COL_FIELD | trusted"></div></span>';
					}
					// BG-64 End					
					/* Start: MV-1232 */
					else if(colCount[i].attributetype.trim() == 'RecieveText') {
						cellTemp += '<span id="identifier_attribute_{{ row.entity.attribute_identifierid }}_'+colCount[i].attributeid+'" class="identifier_attribute_recieveText_{{ row.entity.attribute_identifierid }}_'+colCount[i].attributeid+'" style="float:left;overflow: hidden;position: absolute;text-overflow: ellipsis;white-space: nowrap;">{{ COL_FIELD }}</span>';
					}
					/* End: MV-1232 */
					else {
						cellTemp += '<span id="identifier_attribute_{{ row.entity.attribute_identifierid }}_'+colCount[i].attributeid+'" style="float:left;overflow: hidden;position: absolute;text-overflow: ellipsis;white-space: nowrap;">{{ COL_FIELD }}</span>';
					}
					cellTemp += '</span>';
										
					if(attributepermission[0].editpermission == "true") {
						cellTemp += '<div class="' + pencilCellClass + '" style="float:right;cursor:pointer;' + celleditable + '"' + editCellTemp + '></div>';
					}

					cellTemp += '</div>';
					//End editCellTemp
					var fieldcount = $(".childpanelitem:checked").length;
					var wid = 0;
					if (fieldcount == 1) {
						wid = 1230;
					} else if (fieldcount == 2) {
						wid = 610;
					} else if (fieldcount == 3){
						wid = 407;
					} else if (fieldcount == 4){
						wid = 305;
					} else {
						wid = 243;
					}
					/* Start: BG-113 */	
					var columnmove=true;
					var freezecolumn=false; 
					if(colCount[i].attributetype == 'identifiername') {
						columnmove = false;
						freezecolumn = true;
					}
					/* End- BG-113 */
					if(colCount[i].attributetype === "createdon" || colCount[i].attributetype === "date") {
						
						// -------- BG-110: Start, sorting type change for current age field ---------
						if(typeof colCount[i].agefield !== "undefined" && colCount[i].agefield != null && colCount[i].agefield != "" && colCount[i].agefield == "currentAge"){
							columnDefs.push({
								'name': colCount[i].id,
								'displayName': colCount[i].panelname +
									(colCount[i].subpanelname != 'Default' ? ': ' + colCount[i].subpanelname + ': ' : ': ') +
									colCount[i].displayName + /* --BG-110: Start-- */ ' (in years)' /* --BG-110: End-- */,
								'headerCellTemplate': headerTemp,
								'cellTemplate': cellTemp,
				  				//ASSNS-527	Start
								'attributetype' : colCount[i].attributetype.trim(), 					
								'attributeid' : colCount[i].attributeid, 						
								'fieldname' : colCount[i].displayName, 
				  				//ASSNS-527 End
								'width' : wid,						
								'type' : 'number',
								/* Start: BG-113 */
								'pinnedLeft':freezecolumn,
								'enableColumnMoving':columnmove,
								'isQualitative': colCount[i].isQualitative,
								'agefield': colCount[i].agefield
								/* End: BG-113	*/							
							});
							// -------- BG-110: End, sorting type change for current age field ---------
						}else{
							columnDefs.push({
								'name': colCount[i].id,
								'displayName': colCount[i].panelname +
									(colCount[i].subpanelname != 'Default' ? ': ' + colCount[i].subpanelname + ': ' : ': ') +
									colCount[i].displayName,
								'headerCellTemplate': headerTemp,
								'cellTemplate': cellTemp,
				  				//ASSNS-527	Start
								'attributetype' : colCount[i].attributetype.trim(), 					
								'attributeid' : colCount[i].attributeid, 						
								'fieldname' : colCount[i].displayName, 
				  				//ASSNS-527 End
								'width' : wid,						
								'type' : 'date',
								/* Start: BG-113 */
								'pinnedLeft':freezecolumn,
								'enableColumnMoving':columnmove,
								'isQualitative': colCount[i].isQualitative,
								'agefield': colCount[i].agefield
								/* End: BG-113	*/					
							});
						}						
						
					} else {
						
						var fieldDataType = 'string';
						if (colCount[i].attributetype.trim() == 'identifierid' || colCount[i].attributetype.trim() == 'number' || (colCount[i].attributetype.trim() == 'select' && colCount[i].isQualitative == '0')) {
							fieldDataType = 'number';
						}
						
						columnDefs.push({
							'name': colCount[i].id,
							'displayName': colCount[i].panelname +
								(colCount[i].subpanelname != 'Default' ? ': ' + colCount[i].subpanelname + ': ' : ': ') +
								colCount[i].displayName,
							'headerCellTemplate': headerTemp,
							'cellTemplate': cellTemp,
							//ASSNS-527	Start
							'attributetype' : colCount[i].attributetype.trim(), 					
							'attributeid' : colCount[i].attributeid, 						
							'fieldname' : colCount[i].displayName, 
							//ASSNS-527 End							
							'width' : wid,
							'type': fieldDataType,
							/* Start: BG-113 */
							'pinnedLeft':freezecolumn,
							'enableColumnMoving':columnmove,
							'isQualitative': colCount[i].isQualitative,
							'agefield': colCount[i].agefield
							/* End: BG-113	*/					
						});
					}					
					$scope.gridOptions.columnDefs = columnDefs;
					//break;                                    // DS:: BG-454
				}
				
				}
				 // DS:: BG-454
				 if(listCheckedAttributes.length > 0 && temp == 1){
								var newColumnDefs = [];
								$scope.attributeOrder.forEach(function(e){
									$scope.gridOptions.columnDefs.filter(function(item){
										 if(e.indexOf(item.name) != -1){
											var pos = newColumnDefs.map(function(ee) {
												return ee.name; }).indexOf(item.name);											
											if(pos == -1){
												newColumnDefs.push(item);
											}
										} else {
											return true;
										}
									});
								});	
					$scope.gridOptions.columnDefs = newColumnDefs;				
				}
				// END: BG-454
		}); //end column timeout

		var data = [];
		$timeout(function () {			
			for (var rowIndex = 0; rowIndex < rowCount.length; rowIndex++) {
				var row = {};
				for (var colIndex = 0; colIndex < colCount.length; colIndex++) {
					var val = colCount[colIndex].name;
					row[colCount[colIndex][val]] = rowCount[rowIndex][val];
					if (colCount[colIndex].attributetype === 'checkbox' || colCount[colIndex].attributetype === 'assignedto' || colCount[colIndex].attributetype === 'historicalassignedto' || colCount[colIndex].attributetype === 'site') { //  BG-577 AkashAgrawal
						if (typeof rowCount[rowIndex][val] === 'string') {
							
						// === BG-64 : Start === //
							if(colCount[colIndex].attributetype === 'assignedto'){
								var text = rowCount[rowIndex][val].replace(/~/g, ';; ').replace(/\$squote\$/g,"'").replace(/\$dquote\$/g,'"').replace(/&amp;/g,'&').replace(/&#x0D;/g,'\r');
								row[val] = (text.slice(text.length - 3,text.length) === ';; ') ? text.slice(0,text.length-3):text;
								var original_row_value = row[val];
								var copy_row_value = row[val];
								
								if($scope.current_date_decider_flag == "remove"){		
										if(copy_row_value.length != 0){
											var historical_date_array = copy_row_value.split(";; ");
											var only_name_part = "";
											for(counter_i = 0; counter_i < historical_date_array.length; counter_i++){
												var single_row_value = historical_date_array[counter_i];
												//single_row_value.substring(0,single_row_value.lastIndexOf("(")).trim();//BG-97
												if(only_name_part == ""){
												
													if(single_row_value.match(/\(([^)]*)\)[^(]*$/) != null){
														only_name_part = single_row_value.substring(0,single_row_value.lastIndexOf("(")).trim();//BG-97
													}
													else
													{
														only_name_part = single_row_value.trim();
													}
												}
												else
												{	
													if(single_row_value.match(/\(([^)]*)\)[^(]*$/) != null){
														only_name_part = only_name_part.trim() + ";; " + single_row_value.substring(0,single_row_value.lastIndexOf("(")).trim();//BG-97
													}
													else
													{
														only_name_part = only_name_part.trim() + ";; " + single_row_value.trim();
													}
												}
												
											}
											row[val] = only_name_part;
										}
								}
								else if($scope.current_date_decider_flag == "add")
								{
										row[val] = original_row_value;
								}
							}
							else if(colCount[colIndex].attributetype === 'historicalassignedto')
							{
									var text = rowCount[rowIndex][val].replace(/~/g, ';; ').replace(/\$squote\$/g,"'").replace(/\$dquote\$/g,'"').replace(/&amp;/g,'&').replace(/&#x0D;/g,'\r');
									row[val] = (text.slice(text.length - 3,text.length) === ';; ') ? text.slice(0,text.length-3):text;
									var original_row_value = row[val];
									var copy_row_value = row[val];
									
									if($scope.historical_date_decider_flag == "remove"){		
											if(copy_row_value.length != 0){
												var historical_date_array = copy_row_value.split(";; ");
												var only_name_part = "";
												for(counter_i = 0; counter_i < historical_date_array.length; counter_i++){
													var single_row_value = historical_date_array[counter_i];
													if(only_name_part == ""){
														only_name_part = single_row_value.substring(0,single_row_value.lastIndexOf("(")).trim();//BG-97
													}
													else
													{
														only_name_part = only_name_part.trim() + ";; " + single_row_value.substring(0,single_row_value.lastIndexOf("(")).trim();//BG-97
													}
												}
												row[val] = only_name_part;
											}
									}
									else if($scope.historical_date_decider_flag == "add")
									{
											row[val] = original_row_value;
									}
							}
							else
							{
								/* Start: BG-475 BG Export */
								var text = "";
								if(colCount[colIndex].attributetype === 'checkbox' && colCount[colIndex].isQualitative == '0') {
									text = rowCount[rowIndex][val].replace(/~/g, ';; ');
										   //BG-577 start
								} else if(colCount[colIndex].attributetype === 'site') { 
									var archievesitelist_array = archivedSiteList != "" ? archivedSiteList.split("~") : null ; 
									var selectedColArr = rowCount[rowIndex][val];
									if(selectedColArr != '' && selectedColArr.indexOf('~') > -1)
										{    
											var selectedcolarr_array = selectedColArr.split("~")  
											if(archievesitelist_array != null){
												var selectedcolarr_array = selectedcolarr_array.map(function(item) {
													return archievesitelist_array.includes(item) ? item +" (Archived)" : item;
												});
												selectedColArr = selectedcolarr_array.toString() 
											} 
										}else if(selectedColArr != ''){
											if(archievesitelist_array != null){
												var selectedcolarr_array = archievesitelist_array.includes(selectedColArr) ? selectedColArr +" (Archived)" : selectedColArr;
												selectedColArr = selectedcolarr_array.toString()
											}   
										}
										
									text = selectedColArr.replace(/~/g, ';; ').replace(/,/g, ';; ').replace(/\$squote\$/g,"'").replace(/\$dquote\$/g,'"').replace(/&amp;/g,'&').replace(/&#x0D;/g,'\r');	
										//BG-577 end  
								} else { 
									text = rowCount[rowIndex][val].replace(/~/g, ';; ').replace(/\$squote\$/g,"'").replace(/\$dquote\$/g,'"').replace(/&amp;/g,'&').replace(/&#x0D;/g,'\r');									
								}
								row[val] = (text.slice(text.length - 3,text.length) === ';; ') ? text.slice(0,text.length-3):text;
								/* End: BG-475 BG Export */
							}
						// === BG-64 : Stops === //

						} else {
							row[val] = rowCount[rowIndex][val]; //.toString().replace(/\$squote\$/g,"'").replace(/\$dquote\$/g,'"').replace(/&amp;/g,'&').replace(/&#x0D;/g,'\r');
						}
						
					} 
					/* Start: BG-475 BG Export */
					else if (colCount[colIndex].attributetype === 'identifierid' || colCount[colIndex].attributetype === 'createdon' || colCount[colIndex].attributetype === 'status' || colCount[colIndex].attributetype === 'mobile' || colCount[colIndex].attributetype === 'RecieveText' || ((colCount[colIndex].attributetype === 'select' || colCount[colIndex].attributetype === 'textbox') && colCount[colIndex].isQualitative == '0')) {						
						row[val] = rowCount[rowIndex][val.toLowerCase()];						
					} 
					/* End: BG-475 BG Export */
					else {		
						//console.log(colCount[colIndex].attributetype);						
						row[val] = rowCount[rowIndex][val].toString().replace(/\$squote\$/g,"'").replace(/\$dquote\$/g,'"').replace(/&amp;/g,'&').replace(/&#x0D;/g,'\r');
					}
					row['cellclass'] = rowCount[rowIndex].classname;
					row['celleditable'] = rowCount[rowIndex].editable;
				} //inner for loop
				
				/* Start: Export Optimization */												
				totalIdentifierCount.push(row['attribute_identifierid']);
				/* End: Export Optimization */
				
				data.push(row);
			}			
			$('.totalidentifiers').html('Total ' + identifieraliasplural + ': ' + totalIdentifierCount.length);
			
			//$scope.gridOptions.data = response.data;
		});
		$scope.gridOptions.data = data;				
		
		$timeout(function () {
			if($("#setAttributeOrder").val()==1){
				var state = $scope.gridApi.saveState.save();
				$scope.state = state;
				$scope.restoreOrder();
			}			
		});

		$timeout(function () {
			hideLoadingOverlay();
		});

		$timeout(function () {
			if(downloadReport == true){
				$scope.exportIdentifiersReport();
			}
		});
	};

	$scope.removeColumn = function (panelid, subpanelid, Id) {
    // ASSNS-527 start
		var searchdata = "";
		if(Id.indexOf("Association") != -1)
		{
			searchdata = panelid+"_"+Id.split("_")[1];
		}
		else{
			searchdata = panelid+"_"+Id;
		}
		$scope.removeFieldOrder.push(searchdata);
    // ASSNS-527 end
		$("#" + Id).prop('checked', false);
		$('.childpanelitem:not(:checked)').parents('.columngroup').removeClass("check_bgcolor");
		selectedarrayorder = [];
		$scope.displayAttributesBasedOnCheckbox(false);

	}

	$scope.generateExcelReport = function () {
		var associationid = $("#associationid").val();
		var current_date = new Date();

		var utc =  moment.utc(new Date());
		//var pst = moment(utc).zone('-0700'); // -0700 is code for PST
		//var pst = moment(utc).zone('America/Los_Angeles'); // -0800 is code for PDT
		var pst = moment.tz(utc,'America/Los_Angeles');

		var fileDate = pst.format('MMMM_D_YYYY_h_mmA');
		var documentName = "Group_"+ associationid + "-" + fileDate;//MCR-47

		var grid = $scope.gridApi;
		var rowTypes = uiGridExporterConstants.ALL;
		var colTypes = uiGridExporterConstants.ALL;
    // ASSNS-527
		//exportUiGridService.exportToExcel(documentName,'sheet 1',grid, rowTypes, colTypes);
		$scope.exportToExcel();		
	};
	
	$scope.exportToExcel= function(){		
		var wb = new ExcelJS.Workbook();
		var ws = wb.addWorksheet('Export');
		var origin   = window.location.origin;
		
		// Header
		var utc =  moment.utc(new Date());		
		var pst = moment.tz(utc,'America/Los_Angeles');
		var fileDate = pst.format('MMMM_D_YYYY_h_mmA');
		var associationName = $("#associationName").val();
		var associationid = $("#associationid").val();		
		var exportDateTime = "(as of "+ pst.format('MM/DD/YYYY')+" at " + pst.format('h:mm A')+" U.S. Pacific)";
		var firstRow = "Group Name: "+ associationName + " " + exportDateTime; //MCR-47
		var associationitemid='';
		row1 = ws.getRow(1);
		row1.getCell(1).value = firstRow;
		row1.font = { name: 'Arial', size: 10};
		var com_his_count=1;
		$scope.saveOrder();			
		if($scope.removeFieldOrder.length > 0 )
		{
			$scope.removeFieldOrder.forEach(function(e){				
				var tempindex = $scope.attributeOrder.indexOf(e);				
				if(tempindex != -1){
					$scope.attributeOrder.splice(tempindex,1);
				}else{					
					do {				
						var val=e+'_'+com_his_count;						
						var tempindex1 = $scope.attributeOrder.indexOf(val);				
						if(tempindex1 != -1){
							$scope.attributeOrder.splice(tempindex1,1);
						}else{					
							break;
						}
						com_his_count++;
					}
					while (com_his_count>0);
				}
			});
			tableorder=$scope.attributeOrder;			
		}
		else
		{				
			tableorder=$scope.attributeOrder;
		}		
		var fileorder=[];			
		var cellcount=1;		
		//tableorder.forEach(ord => {						
		tableorder.forEach(function(ord) {						
			//write column of excel
			row3 = ws.getRow(3);				
			//$scope.gridOptions.columnDefs.map( (head, index) => {					
			$scope.gridOptions.columnDefs.map( function (head, index) {					
				headname=head.name;		
				if(ord==headname){	
					cellName = head.fieldname;									
					if(head.attributetype.toLowerCase()=='file'){
						fileorder.push(headname+':'+cellcount);						
					}
					cellNumber = cellcount;							
					cellwidth=head.displayName.length + cellName.length;		 
					ws.getColumn(cellNumber).width = cellwidth +2;						
					row3.getCell(cellNumber).value = {
						richText: [
							{text: head.displayName },							
						]
					};	
					row3.font = { name: 'Arial', size: 10, bold: true };
					index=cellNumber-1;
					cellcount=index+1;
					cellcount=cellcount+1;										
				}				
			})					
		})
		//write header download zip link in excel	
		var recordCountRows = $scope.gridApi.core.getVisibleRows();
		var row4count=0
		row4 = ws.getRow(4);
		var flag=false;	// MV-1943	
		//tableorder.forEach(ord => {
		//if(recordCountRows > 0) {
			tableorder.forEach(function(ord) {
				row4count=row4count+1;
				findex=0;
				
				for (var i = 0; i < $scope.gridOptions.columnDefs.length; i++) {
					var headname=$scope.gridOptions.columnDefs[i].name;											
					if(ord==headname){
						flag=false;	 // MV-1943								
						if($scope.gridOptions.columnDefs[i].attributetype=='file'){		
							colname=$scope.gridOptions.columnDefs[i].name;							
							if($scope.gridOptions.data.length > 0){ //MV-1861					
								associationitemid = $scope.gridOptions.data[0]['attribute_identifierid'];		
								for (var j = 0; j < $scope.gridOptions.data.length; j++) {							
									if($scope.gridOptions.data[j][colname].trim() != ''){// ASSNS-707
										flag=true;
										downloadZipRow = 1; // MV-1943	
										break;
									}   
								}	
							}//MV-1861
							if(flag){
								//fileorder.forEach(ord1 => {
								fileorder.forEach(function(ord1) {
									if(ord1.split(':')[0]==headname)
										findex=ord1.split(':')[1];
								})							
								fileIndex = parseInt(findex);									
								pid=$("#programid").val();					
								attrid=headname.split('_')[1].trim();							
								
								mainhyperlinkurl=origin+"/index.cfm?event=association.downloadfilezip&prg="+pid+"&associationid="+associationid+"&associationitemid="+associationitemid+"&associationitemidlist="+response.newExportIdentifierListId+"&attributeid="+attrid;
								row4.getCell(fileIndex).value = { formula:'HYPERLINK("' + mainhyperlinkurl + '","Download.Zip")' };
								row4.getCell(fileIndex).font = { name: 'Arial', size: 10, underline: 'single', color: { argb: '000366d6' } };							
							}
						}
					}
				}
			})	
		//}
							
		/* Start: BG-113 */
		var cellValuesArray = [[]];			
		var cellNumberArray = [];
		var cellValuesTypeArray = [];
		var objectValues = {};			
		/* End: BG-113 */
		var cellFieldTypeArray = []; // BG-209
		// write Data in excel			
		ws.addRows($scope.gridOptions.data);
		var visibleRows=$scope.gridApi.core.getVisibleRows();
		var identifiersCount = visibleRows.length; //BG-113
		var flag=false;		
			
        	for (var i = 0; i < $scope.gridOptions.columnDefs.length; i++) {
			   if($scope.gridOptions.columnDefs[i].attributetype=='file') {
				   flag=true;				   
			   }
			 }
			for(l=0;l<visibleRows.length;l++) {		
                    
			   	if(downloadZipRow == 1){ // MV-1943
				   rowIndex = l + 5;
			   	} else {
				   rowIndex = l + 4;
			   	}
									   	               				   
				row = ws.getRow(rowIndex);
				var rowdatacount=1;				
				associationitemid = visibleRows[l].entity.attribute_identifierid;
				//tableorder.forEach(ord => {	
				tableorder.forEach(function(ord) {
					/* Start: BG-113 */						
					if(cellNumberArray.indexOf(rowdatacount) == -1) {
						cellValuesArray[rowdatacount] = [];
						cellNumberArray.push(rowdatacount);						
					}
					/* End: BG-113 */	
					//$scope.gridOptions.columnDefs.map((head, index) => {
					$scope.gridOptions.columnDefs.map( function (head, index) {							
						var headname=head.name;	
						var cellisQualitative = head.isQualitative; // BG-113
						var agefield = head.agefield; // BG-113
						if(ord==headname){
							cellNumber = rowdatacount;	 	 
							columnType = head.attributetype.trim();	
							var fileText='';
							var filename='';
							var fn='';	
							var z='';				
							if (columnType === 'file'){											
								if(visibleRows[l].entity[head.name].split(';;').length > 1){
									fileText = 'Download.zip' ;
									filename='';
									z=1;
								}
								else if(visibleRows[l].entity[head.name].split(';;')[0]){
									fileText=visibleRows[l].entity[head.name];														
									if(fileText.trim() != ''){
										//console.log($(fileText)[0].id);

										fn= $(fileText)[0].id;
										filename=fileText.split('id')[1];										
										filename=filename.substring(2);
										
										var txtsplic=fileText.split('>');													
										var len=txtsplic[1].indexOf('<');										
										
										fileText=txtsplic[1].substring(0,len);	
										filename=fileText;										
										//filename=filename.substring(0,filename.indexOf("'"));		
										//filename=fileText.find('id');	
										//console.log(filename);													
										z=0;
									}									
								}															
								if (fileText.trim() !== ''){// ASSNS-703
									pid=$("#programid").val();									
									attrid=headname.split('_')[1].trim();									
									innerhyperlinkurl=origin+"/index.cfm?event=association.downloadfile&prg="+pid+"&associationid="+associationid+"&associationitemid="+associationitemid+"&attributeid="+attrid+"&fieldtype="+columnType+"&fn="+fn+"&z="+z;
									row.getCell(cellNumber).value = { formula: 'HYPERLINK("' + innerhyperlinkurl + '","' + fileText + '")' };
									row.getCell(cellNumber).font = { name: 'Arial', size: 10, underline: 'single', color: { argb: '000366d6' } }; 																
								 }								
								rowdatacount=rowdatacount+1;
							}else {	
								/* Start: BG-113 */	
								var excelCellValue = '' + visibleRows[l].entity[head.name];
								if(excelCellValue != 'undefined' && excelCellValue != '') {
									excelCellValue = excelCellValue.toString().trim();								 								
								}
								var cellValueType = '';
								if(excelCellValue != '' && (columnType == 'identifierid' || (columnType == 'textbox' && cellisQualitative == '0') || (columnType == 'select' && cellisQualitative == '0') || (columnType == 'date' && agefield != 'undefined' && agefield != null && agefield != "" && agefield == "currentAge"))) {			
									//excelCellValue = visibleRows[l].entity[head.name];
									excelCellValue = Number(excelCellValue);									
								}
								
								if (columnType == 'identifierid' || (columnType == 'textbox' && cellisQualitative == '0') || (columnType == 'select' && cellisQualitative == '0') || (columnType == 'checkbox' && cellisQualitative == '0') || (columnType == 'date' && agefield != 'undefined' && agefield != null && agefield != "" && agefield == "currentAge")) {
									cellValueType = 'number';
								} else if ((columnType == 'createdon' || columnType == 'date') && (agefield == 'undefined' || agefield == null || agefield == "")){
									cellValueType = 'date';
								} else if (columnType == 'assignedto' || columnType == 'historicalassignedto' || ((columnType == 'select' || columnType == 'checkbox') && cellisQualitative == '1')) {
									cellValueType = 'text';
								}
								
								row.getCell(cellNumber).value = excelCellValue;	
								
								/* Start: MV-973 */
								if((columnType == 'createdon' || columnType == 'date') && (agefield == 'undefined' || agefield == null || agefield == "")) {
									row.getCell(cellNumber).numFmt = 'm/d/yyyy';	
								}
								/* End: MV-973 */
								
								row.getCell(cellNumber).font = { name: 'Arial', size: 10};
								rowdatacount=rowdatacount+1;
																
								cellValuesTypeArray[cellNumber] = cellValueType;
								cellFieldTypeArray[cellNumber] = columnType;
								
								if(columnType != 'identifierid' && columnType != 'email' && columnType != 'phone' && columnType != 'mobile' && columnType != 'freetextarea' && columnType != 'encryptedtext' && excelCellValue != '') { // BG-564
									if(columnType == 'checkbox' || columnType == 'assignedto' || columnType == 'historicalassignedto' || columnType == 'site') { // Bg-577 AkashAgrawal
										var cellValueCheckbox = row.getCell(cellNumber).value;
										var cellValueCheckboxArray = cellValueCheckbox.split(";;");
										for(var j = 0; j < cellValueCheckboxArray.length; j++) {
											if((columnType == 'assignedto' && $('.hide_current_date').text() == "Remove Dates") || (columnType == 'historicalassignedto' && $('.hide_historical_date').text() == "Remove Dates")) {
												var volunAssigned = cellValueCheckboxArray[j].trim();												
												var period = volunAssigned.lastIndexOf('(');												
												if (period != -1) {
													var volun = volunAssigned.substring(0, period).trim();	
													cellValuesArray[cellNumber].push(volun)
												} else {
													cellValuesArray[cellNumber].push(volunAssigned)
												}																							
											} else {
												cellValuesArray[cellNumber].push(cellValueCheckboxArray[j].trim());
											}
										}
									} else if ((columnType == 'textbox' && cellisQualitative == '0') || columnType != 'textbox'){										
										cellValuesArray[cellNumber].push(row.getCell(cellNumber).value);
									}
								}
								/* End: BG-113 */
							}							
						}
					});					
				})
			}//end for loop	
			downloadZipRow = 0; // MV-1943
			/* Start: BG-113 */
			if(visibleRows.length > 0) { // BG-475
				rowIndex = rowIndex + 2;
				row = ws.getRow(rowIndex);
				row.getCell(1).alignment = {wrapText: true};			
				row.getCell(1).value = {
					richText: [
						{text: 'Total ' + identifieraliasplural + ': ' + identifiersCount },							
					]
				};
				row.font = { name: 'Arial', size: 10, bold: true};
				
				for(var i =1;i<cellNumberArray.length;i++) {
					var currentCellNum = cellNumberArray[i];
					var cellValuesCountArray;				
					if (cellValuesTypeArray[currentCellNum] == 'number') {
						cellValuesArray[currentCellNum] = cellValuesArray[currentCellNum].sort(function (a, b) {  return a - b;  });					
						cellValuesCountArray = arrayElementCount(cellValuesArray[currentCellNum]);
					} else if (cellValuesTypeArray[currentCellNum] == 'date') {					
						cellValuesArray[currentCellNum] = cellValuesArray[currentCellNum].sort(function (a, b) {  var dateA = new Date(a), dateB = new Date(b); return dateA - dateB;});					
						cellValuesCountArray = arrayElementCount(cellValuesArray[currentCellNum]);
					} else if (cellValuesTypeArray[currentCellNum] == 'text') {
						cellValuesArray[currentCellNum] = cellValuesArray[currentCellNum].sort(
																							  function(a, b) {
																								if (a.toLowerCase() < b.toLowerCase()) return -1;
																								if (a.toLowerCase() > b.toLowerCase()) return 1;
																								return 0;
																							  });
						cellValuesCountArray = arrayElementCount(cellValuesArray[currentCellNum]);
						cellValuesCountArray = cellValuesCountArray.sort(function (a, b) {  return b.count - a.count;  });
					} else {
						cellValuesCountArray = arrayElementCount(cellValuesArray[currentCellNum]);
					}
					var dataCount = '';		
					var totalDataCount = 0; // BG-209
					for(let i = 0; i < cellValuesCountArray.length; i++){
						/* Start: BG-209 */
						if (cellValuesTypeArray[currentCellNum] == 'number' && cellFieldTypeArray[currentCellNum] != 'date') {
							totalDataCount = totalDataCount + (parseFloat(cellValuesCountArray[i].value) * parseInt(cellValuesCountArray[i].count));
						}
						/* End: BG-209 */
						dataCount = dataCount + cellValuesCountArray[i].value + ' (' + cellValuesCountArray[i].count + ')' + '\x0A';
					}	
					/* Start: BG-209 */
					if (cellValuesTypeArray[currentCellNum] == 'number' && cellFieldTypeArray[currentCellNum] != 'date' && dataCount != '') {
						if(cellFieldTypeArray[currentCellNum] == 'textbox') {
							dataCount = 'Total (' + totalDataCount + ')';
						} else {
							dataCount = 'Total (' + totalDataCount + ')' + '\x0A' + '\x0A' + dataCount;
						}
					}
					/* End: BG-209 */
					row.getCell(currentCellNum).alignment = {wrapText: true};
					row.getCell(currentCellNum).value = {
						richText: [
							{ text: dataCount},							
						]
					};	
					row.font = { name: 'Arial', size: 10, bold: true };
				}	
			}
			/* End: BG-113 */
			
		//export excel
		wb.xlsx.writeBuffer( {
				base64: true
			})
			.then( function (xls64) {
				// build anchor tag and attach file (works in chrome)
				var data = new Blob([xls64], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });	
				var fileName="CustomRoster_"+fileDate+".xlsx";
				//for microsoft IE
				if (window.navigator && window.navigator.msSaveOrOpenBlob) {
					window.navigator.msSaveOrOpenBlob(data,fileName );
				} else { //other browsers
					var a = document.createElement("a");										
					var url = URL.createObjectURL(data);					
					a.href = url;			
					a.download = fileName;
					document.body.appendChild(a);
					a.click();
					setTimeout(function() {
						document.body.removeChild(a);
						window.URL.revokeObjectURL(url);
					},
					0);
				}
				
			})
			.catch(function(error) {
				console.log(error.message);
				hideLoadingOverlay();
			});
		hideLoadingOverlay();
    };//End exportExcel

	$scope.loadResponse = function (data, downloadReport) {
		//showLoadingOverlay();
		var _current_time_cache = new Date().getTime();
		var formData = {};
		data.forEach(function(obj) {
		   Object.entries(obj).forEach(function([key, value]) {
			  formData[key] = value;
		   });			  
	    });
		
		$.ajax({
			type: "POST",			
			url: "index.cfm?event=association.associationidentifierattributevalues&currenttimestamp=" + _current_time_cache,
			data: formData,
			dataType: "json",
			//async: false,
			beforeSend: function() {	
				//showLoadingOverlay();
				showWaitScreen();
			},
			success: function(responseData) {				
				response = responseData;
				//$scope.resetfieldorder();
				//$scope.displayAttributesBasedOnCheckbox(downloadReport);		
			},	
			//timeout: 20000000,
			complete: function(responseData) {	
				$scope.resetfieldorder();
				$scope.displayAttributesBasedOnCheckbox(downloadReport);
				var surveyReportId = getUrlParameter('reportId');				
				if(typeof surveyReportId != 'undefined' && surveyReportId !='' && previewBGExport == 0) {
					displaySavedReports(surveyReportId);					
					previewBGExport = 1;
					//displayReportAttributes();
				}	
				hideWaitScreen();
				hideLoadingOverlay();
			},
			error: function(responseData) {
				console.log(responseData);
				alert('oops some mistake on server');
			}
		});	
	};

	$scope.toggleArchivedAttributes = function(){
		showLoadingOverlay();
		var show_archived_attributes = $('#show_archived_attributes');
		if(show_archived_attributes.html() === 'Show Archived Fields'){
			if($('#select_all_attributes').html() === 'Select None'){
				$('.archivedAttribute:not(:visible)').find('.childpanelitem').prop('checked',true);
				$('.archivedAttribute:not(:visible)').find('.childpanelitem').parents('.columngroup').addClass("check_bgcolor");
			}

			var allArchivedAttributes = $('.archivedAttribute:not(:visible)').find('.childpanelitem');
			var allArchivedAttributesLength = allArchivedAttributes.length;
			for(var i=0;i<allArchivedAttributesLength;++i){
				var currArchivedAttribute = $(allArchivedAttributes[i]);
				
				if($("#select_assignment_panel_attributes" +$(currArchivedAttribute).attr("data-association-panel-id")).html() == "Select None"){
					$(currArchivedAttribute).prop("checked", true);
					$(currArchivedAttribute).parents('.columngroup').addClass("check_bgcolor");
				}
				else if($("#select_user_panel_attributes" +$(currArchivedAttribute).attr("data-association-panel-id")).html() == "Select None"){
					$(currArchivedAttribute).prop("checked", true);
					$(currArchivedAttribute).parents('.columngroup').addClass("check_bgcolor");
				}
			}
			
			$('.archivedAttribute').css('display','table-cell');
			$('.archivedPanelAttribute').css('display','block');		
			$('.archivedSubPanelAttribute').css('display','block');	
			$('.archivedAttributeOption').attr('disabled',false);
			$('.archivedAttributeOption').css('display','block');			
			show_archived_attributes.html('Hide Archived Fields');
			/* Start: BG-112 */
			$j1(".attributes_filter").select2();
			/* End: BG-112 */
		} else if (show_archived_attributes.html() === 'Hide Archived Fields') {
			if($('#select_all_attributes').html() === 'Select None'){
				$('.archivedAttribute:visible').find('.childpanelitem').prop('checked',false);
				$('.archivedAttribute:not(:visible)').find('.childpanelitem').parents('.columngroup').removeClass("check_bgcolor");
			}

			var allArchivedAttributes = $('.archivedAttribute:visible').find('.childpanelitem');
			var allArchivedAttributesLength = allArchivedAttributes.length;
			for(var i=0;i<allArchivedAttributesLength;++i){
				var currArchivedAttribute = $(allArchivedAttributes[i]);
				
				if($("#select_assignment_panel_attributes" +$(currArchivedAttribute).attr("data-association-panel-id")).html() == "Select None"){
					$(currArchivedAttribute).prop("checked", false);
					$(currArchivedAttribute).parents('.columngroup').removeClass("check_bgcolor");
				}
				else if($("#select_user_panel_attributes" +$(currArchivedAttribute).attr("data-association-panel-id")).html() == "Select None"){
					$(currArchivedAttribute).prop("checked", false);
					$(currArchivedAttribute).parents('.columngroup').removeClass("check_bgcolor");
				}
			}

			$('.archivedAttribute').css('display','none');
			$('.archivedPanelAttribute').css('display','none');
			$('.archivedSubPanelAttribute').css('display','none');
			$('.archivedAttributeOption').attr('disabled','disabled');
			$('.archivedAttributeOption').css('display','none');			
			show_archived_attributes.html('Show Archived Fields');
			/* Start: BG-112 */
			$j1(".attributes_filter").select2({
			   templateResult: function(option) {
				  var myOption = $j1('.attributes_filter').find('option[value="' + option.id + '"]');
				  if (myOption.css('display') != 'none') {
						return option.text;
				  }
				  return false;
			   }
			});
			/* End: BG-112 */
		}
		$scope.displayAttributesBasedOnCheckbox(false);
		hideAjaxLoadingOverlay();
	}

	$scope.checkIfAllCheckboxAreChecked = function(){
		var select_all_attributes = $('#select_all_attributes');
		var select_assignment_panel_attributes = $('.select_assignment_panel_attributes');
		var select_user_panel_attributes = $('.select_user_panel_attributes');

		var show_archived_attributes = $('#show_archived_attributes');
		var attributeCheckBoxes =  $('.childpanelitem');
		var archivedAttributes = $('.archivedAttribute').find('.childpanelitem');
		
		var attributesChecked = $('.childpanelitem:checked');
		var attributesNotChecked = $('.childpanelitem:not(:checked)');
		var attributesInView = 0;

		if(show_archived_attributes.html() === 'Show Archived Fields'){
			attributesInView = attributeCheckBoxes.length - archivedAttributes.length;
			if(attributesInView == attributesChecked.length){
				select_all_attributes.html("Select None");
			}else{
				select_all_attributes.html("Select All Fields");

			}
		} else { 
			//Before it was " else if(show_archived_attributes.html() === 'Hide Archived Attributes'){
			attributesInView = attributeCheckBoxes.length;
			if(attributesInView == attributesChecked.length){
				select_all_attributes.html("Select None");
			}else{
				select_all_attributes.html("Select All Fields");
			}
		}
	}

	$scope.selectallattributes = function () {
		showLoadingOverlay();
		var select_all_attributes = $('#select_all_attributes');
		var select_assignment_panel_attributes = $('.select_assignment_panel_attributes');
		var select_user_panel_attributes = $('.select_user_panel_attributes');
		if (select_all_attributes.html() === 'Select All Fields') {
			$('.childpanelitem').prop('checked', true);
			$('.childpanelitem:checked').parents('.columngroup').addClass("check_bgcolor");
					
			if($('#show_archived_attributes').html() === 'Show Archived Fields'){
				$('.archivedAttribute:not(:visible)').find('.childpanelitem').prop('checked',false);
			}

			select_all_attributes.html('Select None');
			select_assignment_panel_attributes.html('Select None');
			select_user_panel_attributes.html('Select None');
		} else if (select_all_attributes.html() === 'Select None') {
			$('.childpanelitem').prop('checked', false);
			$('.columngroup').removeClass("check_bgcolor");
			select_all_attributes.html('Select All Fields');
			$scope.stayChecked();
			select_assignment_panel_attributes.html('Select All');
			select_user_panel_attributes.html('Select All');
		}
		
		//$scope.displayAttributesBasedOnCheckbox(false);
		
		setTimeout(
			function(){				
				$scope.resetfieldorder();				
				$scope.getSelectedFieldData('panelFields',0,'');
			}
		,400);
		//hideAjaxLoadingOverlay();
	}

	$scope.selectPanelAllAttributes = function (selectid, panelid) {
		showLoadingOverlay();
		var selectAnchor = $("#" + selectid);		
		if (selectAnchor.html() === 'Select All') {
			selectAnchor.html("Select None");
			$("#panel" + panelid).find(".childpanelitem").prop('checked', true);
			$("#panel" + panelid).find(".RecieveText").show();
			$('.childpanelitem:checked').parents('.columngroup').addClass("check_bgcolor");
			if($('#show_archived_attributes').html() === 'Show Archived Fields'){
				$('.archivedAttribute:not(:visible)').find('.childpanelitem').prop('checked',false);
				$('.archivedAttribute:not(:visible)').find('.childpanelitem').parents('.columngroup').removeClass("check_bgcolor");
			}
			$("#panel" + panelid + ' input[name="childpanelitem"]:checked').each(function (e, i) {
				toggelSelectAllText($(this),selectAnchor.attr("class"))
			});
		} else if (selectAnchor.html() === 'Select None') {
			selectAnchor.html("Select All");
			$("#panel" + panelid).find(".RecieveText").hide();
			$("#panel" + panelid).find(".childpanelitem").prop('checked', false);
			$('.childpanelitem:not(:checked)').parents('.columngroup').removeClass("check_bgcolor");
			$("#panel" + panelid + ' input[name="childpanelitem"]:not(:checked)').each(function (e, i) {
				toggelSelectAllText($(this),selectAnchor.attr("class"))
			});
			$scope.stayChecked();
			
		}
						
		//$scope.displayAttributesBasedOnCheckbox(false);
		
		setTimeout(
			function(){				
				$scope.resetfieldorder();				
				$scope.getSelectedFieldData('panelFields',0,'');
			}
		,400);
		
		//hideAjaxLoadingOverlay();
	}
	$scope.stayChecked = function () {
		$("#attribute_identifiername").prop("checked", true);
		$("#attribute_identifiername").parents(".columngroup").addClass("check_bgcolor");
	}
	$scope.resetfieldorder = function () {
		$scope.attributeOrder = [];				// DS:: BG-454
		$('input[name="childpanelitem"]:checked').each(function (e, i) {
			var panelId = $(this).attr('panelid');
			var fieldId = $(this).val();
			$scope.attributeOrder.push(panelId + '_' + fieldId);			// DS:: BG-454
		});
		$scope.fieldcount = $scope.attributeOrder.length;				// DS:: BG-454
	}

	$scope.onLoad = function () {
		if ($('body').find('#ajaxFilterLoading').attr('id') != 'ajaxFilterLoading') {
			var html = '<div id="ajaxFilterLoading" style="display:none"><img id="loading" src="../../images/icons/animated_loading.gif"><div>';
			html += '<div></div></div><div class="bg"></div></div>'
			$('body').append(html);
		}

		var height = $('body').outerHeight();
		var width = $('body').outerWidth();
		$('#ajaxFilterLoading').css({
			'width': '100%',
			'height': '100%',
			'position': 'fixed',
			'z-index': '10000000',
			'top': '0',
			'left': '0'
		});

		$('#ajaxFilterLoading .bg').css({
			'background': '#000000',
			'opacity': '0.15',
			'width': '100%',
			'height': '100%',
			'position': 'absolute',
			'top': '0'
		});

		$('#ajaxFilterLoading > div:first').css({
			'width': '100%',
			'text-align': 'center',
			'position': 'absolute',
			'left': '0',
			'top': '48%',
			'font-size': '16px',
			'z-index': '10',
			'color': '#ffffff'
		});

		$scope.fetchattributesdata(false);
	};

	/* YEOU : END */

	/* Lucky : Start Code */
	$scope.arrangeattributes = "row";
	$scope.changeArrangeAttributes = function () {				
		var appliedFCount = $(".appliedfiltercount").val();
		var appliedAllFiterCount = $(".filtercount").val();//MV-1885
		var msg = "";
		if(appliedAllFiterCount > 1) {//MV-1885
			msg = validateFilters();
		}
		
		var currentArrangments = $("#currentArrangeField").val();
		if(msg != "" && msg == 'invalid pattern') {
			$('input[name="arrangeattributes"][value="'+currentArrangments+'"]').prop('checked', true);	
			return false;
		} else if (msg != "" && msg != 'invalid pattern') {						
			$('input[name="arrangeattributes"][value="'+currentArrangments+'"]').prop('checked', true);	
			alert(msg);
			return false;		
		} else if (appliedAllFiterCount > 1 && $('#btn_apply_filter').prop('disabled') == true) {//MV-1885
			$('input[name="arrangeattributes"][value="'+currentArrangments+'"]').prop('checked', true);	
			alert('Please update filter value.');
			return false;
		} else {
			var fieldcount = $(".childpanelitem:checked").length;
			if(fieldcount > 2) {
				showLoadingOverlay();	
				setTimeout ( 
					function() {
						$('#currentArrangeField').val($(".arrangeattributes:checked").val());
						$('#attributesortorder').val($scope.attributeOrder);     //BG-454
						$('#setAttributeOrder').val('1');
						//$scope.fetchattributesdata(false);		
						$scope.getSelectedFieldData('singleField', 'identifiername', 'identifiername');
						//hideLoadingOverlay();
					},
				400);
			}
		}				
	};

	$scope.addFilter = function (datacount,updatefilepattern) { 
		updateFilterSection(datacount,updatefilepattern,$compile,$scope,reportDeciderFlag);//Parameters Added For ASSNS-656
		//Code Commented For ASSNS-656
		/*
		var loadData = updateFilterSection(datacount);
		if (loadData) {
			var button = $('.btn_add_filter_' + datacount).html();
			if (button == 'Add') {
				var filtercount = parseInt($('.filtercount').val());
				$('.btn_add_filter_' + datacount).html('Edit');
				$('.btn_cancel_filter_' + datacount).html('Remove');
				var filterButtons = "<div id='filterButtons_" + filtercount + "' class='filterButtons filterButtons_" + filtercount + " pull-left' style='margin-top:5px'><div class='buttonBlock pull-left filter_btn_box'><a class='btn_add_filter btn_add_filter_" + filtercount + "' name='Action' data-count='" + filtercount + "' style='margin-left:3px;' ng-click='addFilter(" + filtercount + ",1)'>Add</a></div><div class='buttonBlock pull-left filter_btn_box'><a class='btn_cancel_filter btn_cancel_filter_" + filtercount + " margin-left-6'  name='Action' data-count='" + filtercount + "' ng-click='removeFilter(" + filtercount + ")'>Cancel</a></div></div>";
				var temp = $compile(filterButtons)($scope);
				angular.element(document.getElementById('subfilter_' + filtercount)).append(temp);
			}
				if(updatefilepattern==1){
					if($('select[name="logical"]').prop("disabled")==false)
						$scope.updateFilterPattern();
					else{
						$('select[name="logical"]').val('');
						$('select[name="logical"]').prop("disabled",true);
					}
						
				}
		}
		*/
	};

	$scope.updateFilterPattern = function () {
		var filtervaluepattern = "(1)";
		var filtercount = parseInt($('.filtercount').val());
		for (i = 2; i < filtercount; i++) {
			var filterjoin = $('option:selected', '.logical_' + i).text();
			filtervaluepattern = "(" + filtervaluepattern;
			filtervaluepattern += " " + filterjoin + " " + i + ")";
		}
		$('#filtervaluepattern').val(filtervaluepattern);
		$('#patternforrestore').val(filtervaluepattern);
	};

	$scope.editPattern = function () {
		
		var patternButtons = "<div class='pattern pull-left' id='editablefilterpattern' style='padding-left:10px;margin-top:7px;'><div class='buttonBlock pull-left undopattern' style='width:auto;display:none;'><a class='undopattern' id='undopattern' ng-click='undoPattern()'>Undo</a></div><div class='buttonBlock pull-left' style='width:auto;margin-left:8px;'><a class='removepattern' id='removepattern' ng-click='removeCustomPattern()'>Remove</a></div></div>";
		//var patternButtons = "<div class='pattern pull-left' id='editablefilterpattern' style='padding-left:10px;margin-top:7px;'><div class='buttonBlock pull-left' style='width:auto;'><a class='savepattern' id='savepattern' ng-click='savePattern()'>Save</a></div><div class='buttonBlock pull-left' style='width:auto;margin-left:8px;'><a class='cancelpattern' id='cancelpattern' ng-click='cancelPattern()'>Cancel</a></div></div>";
		var currentPattern = $('#filtervaluepattern').val().trim();
		$('#hiddenpattern').val(currentPattern);
		$('#filtervaluepattern').attr('disabled', false);
		$('select[name="logical"]').attr('disabled', true);
		$('select[name="logical"]').val('');

		$('#editablefilterpattern').remove();
		var temp = $compile(patternButtons)($scope);
		angular.element(document.getElementById('filterpattern')).append(temp);
	};

	$scope.savePattern = function () {
		var checkPattern = validateFilterPattern();
		if (checkPattern) {
			var patternButtons = '<div class="pattern pull-left" id="editablefilterpattern" style="padding-left:10px;margin-top:7px;"><label class="pull-left"><a id="editfilterpattern" class="editfilterpattern" ng-click="editPattern()">Edit Pattern</a></label><div class="help_tooltip"><img src="../../images/icons/question_icon_bw.gif" onmouseover="this.src=\'../../images/icons/question_icon.gif\'" onmouseout="this.src=\'../../images/icons/question_icon_bw.gif\'" border="0" alt=""/><span class="tooltiptext help_tooltip-bottom">To edit filter pattern, click on Edit Pattern and then save.</span></div></div>';
			$('#filtervaluepattern').attr('disabled', true);
			$('#editablefilterpattern').remove();
			var temp = $compile(patternButtons)($scope);
			var oldPattern = $('#hiddenpattern').val();
			var currentPattern = $('#filtervaluepattern').val().trim();
			angular.element(document.getElementById('filterpattern')).append(temp);
			showLoadingOverlay();
			if (oldPattern != currentPattern) {
				currentPattern = currentPattern.replace(/and/ig,'AND');
				currentPattern = currentPattern.replace(/or/ig,'OR');
				$('#filtervaluepattern').val(currentPattern);
				//$scope.fetchattributesdata(false);
			}
			hideLoadingOverlay();
		}
		/*else{ commented for MV-1885
			var patternButtons = '<div class="pattern pull-left" id="editablefilterpattern" style="padding-left:10px;margin-top:7px;"><label class="pull-left"><a id="editfilterpattern" class="editfilterpattern" ng-click="editPattern()">Edit Pattern</a></label><div class="help_tooltip"><img src="../../images/icons/question_icon_bw.gif" onmouseover="this.src=\'../../images/icons/question_icon.gif\'" onmouseout="this.src=\'../../images/icons/question_icon_bw.gif\'" border="0" alt=""/><span class="tooltiptext help_tooltip-bottom">To edit filter pattern, click on Edit Pattern and then save.</span></div></div>';
			$('#filtervaluepattern').attr('disabled', true);
			$('#editablefilterpattern').html('');
			$('#editablefilterpattern').remove();
			var temp = $compile(patternButtons)($scope);
			angular.element(document.getElementById('filterpattern')).append(temp);
			hideLoadingOverlay();
		}*/
		return checkPattern;
	};
	
	$scope.undoPattern = function () {
		$('#filtervaluepattern').val($('#hiddenpattern').val());
		$('#undopattern').hide();
	};
	
	$scope.removeCustomPattern = function () {
		var patternButtons = '<div class="pattern pull-left" id="editablefilterpattern" style="padding-left:10px;margin-top:7px;"><label class="pull-left"><a id="editfilterpattern" class="editfilterpattern" ng-click="editPattern()">Edit Pattern</a></label><div class="help_tooltip"><img src="../../images/icons/question_icon_bw.gif" onmouseover="this.src=\'../../images/icons/question_icon.gif\'" onmouseout="this.src=\'../../images/icons/question_icon_bw.gif\'" border="0" alt=""/><span class="tooltiptext help_tooltip-bottom">To edit filter pattern, click on Edit Pattern and then save.</span></div></div>';
			
			if($('#editpatternflage').val()!=1){
				$('select[name="logical"]').prop("disabled",false);
				pattern = $('#patternforrestore').val()
				pattern = pattern.replace(/and/ig,'&&');
				pattern = pattern.replace(/or/ig,'||');
				var operatorsInString = get_logical(pattern);
				var filterIndex = 2;
				if(operatorsInString != null) {
					$('select[name="logical"]').val('1');
					for(i=0; i<=operatorsInString.length; i++) {					
						var htmldiv = "<select class='logical_"+ filterIndex + "'  name='logical' style='margin-left:0px;height:22px;'>";//ASSNS-656
						if(operatorsInString[i] == '&&') {									
							htmldiv = htmldiv + "<option value='1' selected>AND</option><option value='2'>OR</option>";				
						} else if (operatorsInString[i] == '||') {						
							htmldiv = htmldiv + "<option value='1' >AND</option><option value='2' selected>OR</option>";				
						} else {
							htmldiv = htmldiv + "<option value='1' selected>AND</option><option value='2'>OR</option>";
						}
						htmldiv = htmldiv + "</select>";
						$('.filter_logical_' + filterIndex).html(htmldiv);
						filterIndex++;
					}		
				}
				else{
					var htmldiv = "<select class='logical_"+ filterIndex + "'  name='logical' style='margin-left:0px;height:22px;'>";//ASSNS-656	 				
					htmldiv = htmldiv + "<option value='1' selected>AND</option><option value='2'>OR</option>";
					htmldiv = htmldiv + "</select>";
					$('.filter_logical_' + filterIndex).html(htmldiv);
				}
				if($('#removeFilterFlage').val()==1){
					$scope.updateFilterPattern();	
				}
			}
		$('#filtervaluepattern').val($('#patternforrestore').val());
		$('#filtervaluepattern').attr('disabled', true);
		$('#editablefilterpattern').html('');
		$('#editablefilterpattern').remove();
		var temp = $compile(patternButtons)($scope);
		angular.element(document.getElementById('filterpattern')).append(temp);
	};
	
	

	$scope.cancelPattern = function () {
		var patternButtons = '<div class="pattern pull-left" id="editablefilterpattern" style="padding-left:10px;margin-top:7px;"><label class="pull-left"><a id="editfilterpattern" class="editfilterpattern" ng-click="editPattern()">Edit Pattern</a></label><div class="help_tooltip"><img src="../../images/icons/question_icon_bw.gif" onmouseover="this.src=\'../../images/icons/question_icon.gif\'" onmouseout="this.src=\'../../images/icons/question_icon_bw.gif\'" border="0" alt=""/><span class="tooltiptext help_tooltip-bottom">To edit filter pattern, click on Edit Pattern and then save.</span></div></div>';
		var oldPattern = $('#hiddenpattern').val();
		$('#filtervaluepattern').val(oldPattern);
		$('#filtervaluepattern').attr('disabled', true);
		$('#editablefilterpattern').html('');
		$('#editablefilterpattern').remove();
		var temp = $compile(patternButtons)($scope);
		angular.element(document.getElementById('filterpattern')).append(temp);
	};

	$scope.applyfilter = function () {
		var msg = validateFilters();
		
		if(msg != "" && msg == 'invalid pattern') {
			return false;
		} else if (msg != "" && msg != 'invalid pattern') {
			alert(msg);
			return false;
		} else {
			var filtercount = parseInt($('.filtercount').val());
			$('.appliedfiltercount').val(filtercount);
			showLoadingOverlay();				
			setTimeout(
				function(){	
					if($('select[name="logical"]').prop("disabled") == false)
						$scope.updateFilterPattern();			
						
					//$scope.fetchattributesdata(false);
					$scope.getSelectedFieldData('filterField',0,'');						
				}
			,400);					
		}	  
	};	
	
	$scope.clearfilters = function () {
		showLoadingOverlay();
		$('.errormsg_class').css('display', 'none');//ASSNS-656
		var filtercount = parseInt($('.filtercount').val());

		for (i = 2; i <= filtercount; i++) {
			$('#subfilter_' + i).remove();
		}

		$('.filtercount').val('1');
		$('.appliedfiltercount').val('1');		
		$('#filtervaluepattern').val('');
		$('#patternforrestore').val('');
		$('#editpatternflage').val('0');
		$('#removeFilterFlage').val('0');
		$('.filterpattern').css('display', 'none');
		$('#clearfilter').css('display', 'none');
		$('#btn_apply_filter').prop("disabled", true)

		$('.filternumber_1').removeClass('padding-left-5');
		$('.filternumber_1').html('');
		$('.filternumber_1').css('display', 'none');

		$('.filter_logical_1').html('');
		$('.filter_logical_1').css('display', 'none');

		$('.attributes_filter_label').addClass('attributes_filter_label-215');
		$('.attributes_filter_label').removeClass('attributes_filter_label-175');
		$('.attributes_filter_label').removeAttr('style');
		$('.attributes_filter_label').addClass('margin-left-5');

		$('.attributes_filter_1').addClass('attributes_filter-215');
		$('.attributes_filter_1').removeClass('attributes_filter-175');

		$('.attributes_operators_label').addClass('attributes_operators_label-135');
		$('.attributes_operators_label').removeClass('attributes_operators_label-100');

		$('.attributes_operators_1').addClass('attributes_operators-135');
		$('.attributes_operators_1').removeClass('attributes_operators-100');

		$('.attributes_values_label').addClass('attributes_values_label-165');
		$('.attributes_values_label').removeClass('attributes_values_label-140');
		
		$(".filterinput_1").addClass('date_filter_input-146');

		//$(".filterinput_1").removeClass('date_filter_input-146');
		//$(".filterinput_1").removeClass('date_filter_input-177');

		$('.attributes_values_1').addClass('attributes_values-165');
		$('.attributes_values_1').removeClass('attributes_values-140');
		$('.attributes_values_1').val('');

		$('.btn_add_filter_1').html('Add');
		$('.btn_cancel_filter_1').html('Cancel');
		
		/* Start: BG-112 */
		$j1(".attributes_filter_1").select2('destroy');	
		$('.attributes_operators_1').html('');		
		$j1('.attributes_filter_1').val('0');
		$j1('.attributes_filter').trigger("change");
		if($j1('#show_archived_attributes').html() === 'Show Archived Fields') {					
			$j1(".attributes_filter").select2({
			   templateResult: function(option) {
				  var myOption = $j1('.attributes_filter').find('option[value="' + option.id + '"]');
				  if (myOption.css('display') != 'none') {
						return option.text;
				  }
				  return false;
			   }
			});	
		} else {				
			$('.archivedAttributeOption').attr('disabled',false);
			$('.archivedAttributeOption').css('display','block');
			$j1(".attributes_filter").select2();	
		}
		/* End: BG-112 */

		$('#btn_apply_filter').prop("disabled", true); // Sitemanage-285
		
		setTimeout(
			function(){	
				$scope.fetchattributesdata(false);
			}
		,400);
	};

	$scope.removeFilter = function (datacount) {
		$('#errormsg_'+datacount).remove();//Added for ASSNS-656
		if ($('.btn_cancel_filter_' + datacount).html() == 'Remove') {
			var patternButtons = '<div class="pattern pull-left" id="editablefilterpattern" style="padding-left:10px;margin-top:7px;"><label class="pull-left"><a id="editfilterpattern" class="editfilterpattern" ng-click="editPattern()">Edit Pattern</a></label><div class="help_tooltip"><img src="../../images/icons/question_icon_bw.gif" onmouseover="this.src=\'../../images/icons/question_icon.gif\'" onmouseout="this.src=\'../../images/icons/question_icon_bw.gif\'" border="0" alt=""/><span class="tooltiptext help_tooltip-bottom">To edit filter pattern, click on Edit Pattern and then save.</span></div></div>';
			var oldPattern = $('#hiddenpattern').val();
			if($('select[name="logical"]').prop("disabled")==false){
				$('#filtervaluepattern').val(oldPattern);
				$('#removeFilterFlage').val('0');
			}
			else{
				$('#removeFilterFlage').val('1');
			}
			$('#filtervaluepattern').attr('disabled', true);
			$('#editablefilterpattern').html('');
			$('#editablefilterpattern').remove();
			var temp = $compile(patternButtons)($scope);
			angular.element(document.getElementById('filterpattern')).append(temp);

			var filtercount = parseInt($('.filtercount').val());
			var removedFilter = datacount;
			if (filtercount > 1 && filtercount != datacount) {
				filtercount = filtercount - 1;
				$('.filtercount').val(filtercount);
				//$('.appliedfiltercount').val(filtercount);
				$(".subfilter_" + datacount).html('');
				$(".subfilter_" + datacount).remove();

				for (i = removedFilter + 1; i <= filtercount + 1; i++) {
					var filterno = parseInt($('.filternumber_' + i).attr('data-count'));
					var newFilterNo = filterno - 1;
					
					//ASSNS-656 Starts
					var margin_var = '0px';
					if(newFilterNo < 10){
						margin_var = '8px';
					}
					//console.log("i : "+i+", newFilterNo : "+newFilterNo+", margin_var : "+margin_var);
					//ASSNS-656 Finish

					$('.filternumber_' + i).html("<span class='pull-left' style='margin-top:3px; margin-left:"+margin_var+"; margin-right:5px;'>" + newFilterNo + "</span>");//ASSNS-656
					$('.filternumber_' + i).attr('data-count', newFilterNo);
					$('.filternumber_' + i).addClass('filternumber_' + newFilterNo);
					$('.filternumber_' + i).removeClass('filternumber_' + i);

					$('.filter_logical_' + i).addClass('filter_logical_' + newFilterNo);
					$('.filter_logical_' + i).removeClass('filter_logical_' + i);
					$('.filter_logical_' + i).attr('data-count', newFilterNo);

					$('.logical_' + i).addClass('logical_' + newFilterNo);
					$('.logical_' + i).removeClass('logical_' + i);

					$('.attributes_filter_' + i).attr('data-count', newFilterNo);
					$('.attributes_filter_' + i).attr('name', 'attributes_filter_' + newFilterNo);
					$('.attributes_filter_' + i).addClass('attributes_filter_' + newFilterNo);
					$('.attributes_filter_' + i).removeClass('attributes_filter_' + i);

					$('.operators_' + i).addClass('operators_' + newFilterNo);
					$('.operators_' + i).removeClass('operators_' + i);
					$('.attributes_operators_' + i).attr('data-count', newFilterNo);
					$('.attributes_operators_' + i).addClass('attributes_operators_' + newFilterNo);
					$('.attributes_operators_' + i).removeClass('attributes_operators_' + i);
					$('.attributes_operators_' + newFilterNo).attr('name', 'attributes_operators_' + newFilterNo);

					$('#errormsg_' + i).attr('id', 'errormsg_'+newFilterNo);//Added for ASSNS-656
					$(".filterinput_" + i).find(".datelinkSingle").attr('for','datelink_' + newFilterNo);// BG-197
					$(".filterinput_" + i).find(".datelink1").attr('for','datelink1_' + newFilterNo);// BG-197
					$(".filterinput_" + i).find(".datelink2").attr('for','datelink2_' + newFilterNo);// BG-197
					$('.filterinput_' + i).addClass('filterinput_' + newFilterNo);
					$('.filterinput_' + i).removeClass('filterinput_' + i);
					$("#datelink_" + i).attr('id','datelink_' + newFilterNo);// BG-197
					$("#datelink1_" + i).attr('id','datelink1_' + newFilterNo);// BG-197
					$("#datelink2_" + i).attr('id','datelink2_' + newFilterNo);// BG-197
					$('.attributes_values_' + i).attr('data-count', newFilterNo);
					$('.attributes_values_' + i).addClass('attributes_values_' + newFilterNo);
					$('.attributes_values_' + i).removeClass('attributes_values_' + i);

					$('.search_attr_value_' + i).addClass('search_attr_value_' + newFilterNo);
					$('.search_attr_value_' + i).removeClass('search_attr_value_' + i);
					$('.search_magnifier_' + i).attr('data-count', newFilterNo);
					$('.search_magnifier_' + i).addClass('search_magnifier_' + newFilterNo);
					$('.search_magnifier_' + i).removeClass('search_magnifier_' + i);

					$('.subfilter_' + i).addClass('subfilter_' + newFilterNo);
					$('.subfilter_' + i).attr('id', 'subfilter_' + newFilterNo);
					$('.subfilter_' + i).removeClass('subfilter_' + i);

					$(".filterButtons_" + i).html('');
					$(".filterButtons_" + i).remove();

					// BG-197 Start
					var atrribute = $('.attributes_filter_' + newFilterNo + ' option:selected').attr('data-attribute-type');
					if (atrribute == 'date') {
						var filterButtons = "<div id='filterButtons_" + newFilterNo + "' class='filterButtons filterButtons_" + newFilterNo + " pull-left' style='margin-top:5px'><div class='buttonBlock pull-left filter_btn_box'><a class='firefoxAdd btn_add_filter btn_add_filter_" + newFilterNo + "'  name='Action' data-count='" + newFilterNo + "' ng-click='addFilter(" + newFilterNo + ",1)' style='margin-left:1px;'>"; //Review
					}else{
						var filterButtons = "<div id='filterButtons_" + newFilterNo + "' class='filterButtons filterButtons_" + newFilterNo + " pull-left' style='margin-top:5px'><div class='buttonBlock pull-left filter_btn_box'><a class='btn_add_filter btn_add_filter_" + newFilterNo + "'  name='Action' data-count='" + newFilterNo + "' ng-click='addFilter(" + newFilterNo + ",1)' style='margin-left:1px;'>"; //Review
					}

					if (i < filtercount + 1) {
						filterButtons += "Edit"
					} else {
						filterButtons += "Add";
					}

					if (atrribute == 'date') {
						filterButtons += "</a></div><div class='buttonBlock pull-left filter_btn_box'><a class='firefoxCancel btn_cancel_filter btn_cancel_filter_" + newFilterNo + "'  name='Action' data-count='" + newFilterNo + "' ng-click='removeFilter(" + newFilterNo + ")' style='margin-left:0px;'>";//Review
					}else{
						filterButtons += "</a></div><div class='buttonBlock pull-left filter_btn_box'><a class='btn_cancel_filter btn_cancel_filter_" + newFilterNo + "'  name='Action' data-count='" + newFilterNo + "' ng-click='removeFilter(" + newFilterNo + ")' style='margin-left:-4px;'>";//Review
					}

					if (i < filtercount + 1) {
						filterButtons += "Remove";
					} else {
						filterButtons += "Cancel";
					}
					filterButtons += "</a></div></div>"
					var temp = $compile(filterButtons)($scope);
					angular.element(document.getElementById('subfilter_' + newFilterNo)).append(temp);

					// BG-197 Start
					if (atrribute == 'date') {
						$(".btn_add_filter_" + newFilterNo).closest(".filterButtons_" + newFilterNo).css('margin-top','2px');
					}else{
						$(".btn_add_filter_" + newFilterNo).closest(".filterButtons_" + newFilterNo).css('margin-top','5px');
					}
					// BG-197 End

				}
			}
			var filtercount = parseInt($('.filtercount').val());
			if (filtercount == 1) {
				showLoadingOverlay();
				$('#filtervaluepattern').val('');
				$('.appliedfiltercount').val('1');	// MV-1823: Changes
				$('.filterpattern').css('display', 'none');
				$('#clearfilter').css('display', 'none');
				$('#btn_apply_filter').prop("disabled", true)
				$('.errormsg_class').remove(); //Added for ASSNS-656	
				$('.filternumber_' + datacount).html('');
				$('.filternumber_' + datacount).css('display', 'none');

				$('.filter_logical_' + datacount).html('');
				$('.filter_logical_' + datacount).css('display', 'none');

				$('.attributes_filter_label').addClass('attributes_filter_label-215');
				$('.attributes_filter_label').removeClass('attributes_filter_label-175');
				$('.attributes_filter_label').removeAttr('style');
				$('.attributes_filter_label').addClass('margin-left-5');

				$('.attributes_operators_label').addClass('attributes_operators_label-135');
				$('.attributes_operators_label').removeClass('attributes_operators_label-100');

				$('.attributes_values_label').addClass('attributes_values_label-165');
				$('.attributes_values_label').removeClass('attributes_values_label-140');

				$('.attributes_filter_' + datacount).addClass('attributes_filter-215');
				$('.attributes_filter_' + datacount).removeClass('attributes_filter-175');

				$('.attributes_operators_' + datacount).addClass('attributes_operators-135');
				$('.attributes_operators_' + datacount).removeClass('attributes_operators-100');

				$('.filterinput_' + datacount).removeClass('date_filter_input-146');
				$('.filterinput_' + datacount).removeClass('date_filter_input-177');

				$('.attributes_values_' + datacount).addClass('attributes_values-165');
				$('.attributes_values_' + datacount).removeClass('attributes_values-140');
				
				/* Start: BG-112 */
				$j1('.attributes_filter_' + datacount).select2('destroy');	
				$('.attributes_operators_' + datacount).html('');		
				$('.attributes_filter_' + datacount).val("0").change();
				if($j1('#show_archived_attributes').html() === 'Show Archived Fields') {					
					$j1('.attributes_filter_' + datacount).select2({
					   templateResult: function(option) {
						  var myOption = $j1('.attributes_filter_' + datacount).find('option[value="' + option.id + '"]');
						  if (myOption.css('display') != 'none') {
								return option.text;
						  }
						  return false;
					   }
					});	
				} else {
					$('.archivedAttributeOption').attr('disabled',false);
					$('.archivedAttributeOption').css('display','block');
					$j1('.attributes_filter_' + datacount).select2();	
				}
				/* End: BG-112 */
				
				setTimeout(
					function(){	
						$scope.fetchattributesdata(false);
					}
				,400);
			} else {
				if($('select[name="logical"]').prop("disabled")==false)
					$scope.updateFilterPattern();
			}
			if (filtercount > 1) {
				$('.filter_logical_1').html('&nbsp;');
				$('.filter_logical_1').css('display', 'block');
			}
		} else {
			var filtercount = parseInt($('.filtercount').val());
			if (filtercount > 1) {
				$('.logical_' + datacount).val("1").change();
			}
			//$('.attributes_filter_' + datacount).val("0").change();			
				
			$('.attributes_filter_' + datacount).val("0");
			$j1('.attributes_filter_' + datacount).select2();
			$j1('.attributes_filter_' + datacount).val("0").change();
			$('.attributes_operators_' + datacount).html('');	
			$('.attributes_values_' + datacount).val('');	
			$('.search_magnifier_' + datacount).css('display','none');
			$('#btn_apply_filter').prop("disabled", true); // MV-1929
			$('.errormsg_class').remove(); // MV-1929

			//Added for ASSNS-656
			if ($('.btn_cancel_filter_' + datacount).html() == 'Cancel' && filtercount > 1){
				$('.attributes_operators_' + datacount).removeClass('attributes_operators-135');
				$('.attributes_operators_' + datacount).addClass('attributes_operators-100');
			}
		}
	};

	$scope.fetchattributesdata = function (downloadReport) {
		//showLoadingOverlay();
		var associationid = $("#associationid").val();
		var filtercount = parseInt($('.filtercount').val());
		var arrangeattributesby = $('.arrangeattributes:checked').val();
		var attributes = "";
		var atrributesFilterIds = "";
		var attributetype = "";
		var operators = "";
		var filtervalues = "";
		var logical = " ";
		var filtervaluepattern=$('#filtervaluepattern').val();	
		var identifierStatus = $('#ident_status_action').val();
		var appliedfiltercount = $('.appliedfiltercount').val();
		var filtervaluesoption = "";
		var filtervalueattrid = "";
		var filtervalueattrType = ""; // BG-475
		var filterApplied = 0;
		
		/* Start: Export Optimization*/
		var attributessArray = [];
		var selectedAttributeType = [];		
		$('input[name="childpanelitem"]:checked').each(function(e,i){					
			var fieldId = $(this).val();			
			attributessArray.push(fieldId);
			selectedAttributeType.push($(this).attr('data-attribute-type'));			
		});
		
		attributessArray.push($('input[data-attribute-type="identifierid"]').val());
		/* End: Export Optimization*/

		if(appliedfiltercount > 1) {
			filterApplied = 1;
			for (var i = 1; i < filtercount; i++) {
				var filterby = $('.attributes_filter_' + i + ' option:selected').val();
				var attrFilterId = $('.attributes_filter_' + i + ' option:selected').attr('data-attribute-id');
				var atrribute = $('.attributes_filter_' + i + ' option:selected').attr('data-attribute-type');
				var operatortype = $('.attributes_operators_' + i + ' option:selected').text();
				if(operatortype=='is only')operatortype = 'is';
				var filteroption = $('.attributes_values_' + i).attr('data-filter-option');
				var filtervalueattributeid = $('.attributes_values_' + i).attr('data-attribute-id');
				var filtervalueattributetype = $('.attributes_values_' + i).attr('data-filter-type'); // BG-475
				var attributevaluefilter = "";
				var attributevaluefilteroption = "";
				var dataattributeid = "";
				if (operatortype == 'between' || operatortype == 'not between') {
					$('.attributes_values_' + i).each(function () {
						attributevaluefilter += $(this).val() + ",";
					});
					attributevaluefilter.substring(0, attributevaluefilter.length - 1);
				} else if (operatortype == "is empty" || operatortype == "isn't empty" || operatortype == "today" || operatortype == "tomorrow" || operatortype == "tomorrow onwards"  || operatortype == "yesterday" || operatortype == "until yesterday" || operatortype == "last month"  || operatortype == "current month" || operatortype == "next month"  || operatortype == "last week" || operatortype == "current week" || operatortype == "next week") {
					attributevaluefilter = "  ";				
				} else {
					attributevaluefilter = $('.attributes_values_' + i).val();
					attributevaluefilteroption = $('.attributes_values_' + i).attr('data-filter-option');
				}
				if (i > 1) {
					logical += $('option:selected', '.logical_' + i).text();
				}
				attributes += filterby + "~";
				atrributesFilterIds += attrFilterId + "~";
				attributetype += atrribute + "~";
				operators += operatortype + "~";
				if(attributevaluefilteroption == 2) {
					dataattributeid = $('.attributes_values_' + i).attr('data-attribute-id');
					filtervalues += dataattributeid + "~";
					filtervaluesoption += filteroption + "~";
					filtervalueattrid += filtervalueattributeid + "~";
					filtervalueattrType += filtervalueattributetype + "~";
				} else {
					filtervalues += attributevaluefilter.replaceAll("~","&tilde;") + "~"; //SM-193
				}
				//filtervaluesoption += filteroption + "~";
				//filtervalueattrid += filtervalueattributeid + "~";
				//filtervalueattrType += filtervalueattributetype + "~";
				logical += "~";
				
				/* Start: Export Optimization*/
				attributessArray.push(attrFilterId);
				selectedAttributeType.push(atrribute);
				/* End: Export Optimization*/
			}
		}

		/* Start: Export Optimization*/		
		var data = [];
						
		data.push({
			"associationid": associationid
		});				
		data.push({
			"selectedAttributes": attributessArray.toString()
		});		
		data.push({		
			"selectedAttributesTypes": selectedAttributeType.toString()
		});
		data.push({
			"selectedAttributeId": attributessArray.toString()
		});	
		data.push({
			"selectedAttributeType": selectedAttributeType.toString()
		});	
		data.push({
			"filterApplied": filterApplied
		});		
		/* End: Export Optimization*/
		
		data.push({
			"attributes": attributes
		});
		data.push({
			"atrributesFilterIds": atrributesFilterIds
		});
		data.push({
			"attributetype": attributetype
		});
		data.push({
			"operators": operators
		});
		data.push({
			"filtervalues": filtervalues
		});
		data.push({				
			"filtervaluesoption": filtervaluesoption
		});	
		data.push({				
			"filtervalueattributeid": filtervalueattrid
		});	
		data.push({				
			"filtervalueattributetype": filtervalueattrType
		});		
		data.push({
			"logical": logical
		});
		data.push({
			"arrangeattributesby": arrangeattributesby
		});
		data.push({
			"filtervaluepattern": filtervaluepattern
		});
		data.push({
			"identifierStatus": identifierStatus
		});		
		$scope.loadResponse(data, downloadReport);
	};
	
	/* Start: Export optimization */
	$scope.fieldClicked = function(panelid,subpanelid,fieldid,fieldtype) {	
		showLoadingOverlay();
		setTimeout(
			function () {   
				$.when(
					$scope.getSelectedFieldData('singleField', fieldid, fieldtype)
					//$scope.changeSelectText(panelid,subpanelid),			
					//$scope.resetfieldorder(),								
					//$scope.displayAttributesBasedOnCheckbox(downloadReport)
				).done(function (resp) { 
					$scope.resetfieldorder();								
					$scope.displayAttributesBasedOnCheckbox(downloadReport);
					hideLoadingOverlay();
					
				});        			
			}, 1000);			
		$('.childpanelitem:checked').parents('.columngroup').addClass("check_bgcolor");
		$('.childpanelitem:not(:checked)').parents('.columngroup').removeClass("check_bgcolor");
	};
	
	$scope.getSelectedFieldData = function(selectionType, selectedFieldId, selectedFieldType) {	
		showLoadingOverlay();
		var data = [];
		var fieldsArray = [];			
		var fieldTypearr = [];
		var panelTypearr = [];		
		var subpanelNamearr = [];		
		var filterValues = "";			
		var filterValuesOption = "";		
		var paneltype = "";
		var subpaneltype = "";		
		var attributes = "";
		var attributetype = "";
		var operators = "";
		var filtervalues = "";
		var logical = " ";
		var filterApplied = 0;
		var filtervaluesoption = "";
		var filtervalueattrid = "";		
		var filtervalueattrType = "";
		var fieldSelectionStatus = 0;
		var atrributesFilterIds = "";
		
		var associationid = $("#associationid").val();		
		var filtercount = parseInt($('.filtercount').val());
		var arrangeattributesby = $('.arrangeattributes:checked').val();		
		var filtervaluepattern= $('#filtervaluepattern').val();	
		var identifierStatus = $('#ident_status_action').val();
		var appliedfiltercount = $('.appliedfiltercount').val();
				
		fieldSelectionStatus = $('#attribute_' + selectedFieldId).is(':checked');
		
		var attributessArray = [];
		var selectedAttributeType = [];
		var standardAttributesArray = [];
		var userAttributesArray = [];
		
		if(selectionType == 'panelFields') {
			fieldsArray.push('identifierid');
			fieldTypearr.push('identifierid');
			panelTypearr.push('AssignmentDetails');
			subpanelNamearr.push('Default');
		}
		
		$('input[name="childpanelitem"]:checked').each(function(e,i){					
			var fieldId = $(this).val();			
			attributessArray.push(fieldId);
			selectedAttributeType.push($(this).attr('data-attribute-type'));	
			
			if(selectionType == 'panelFields') {
				fieldTypearr.push($(this).attr('data-attribute-type'));
				panelTypearr.push($(this).attr('data-paneltype'));
				subpanelNamearr.push($(this).attr('data-subpanelname'));
				/*if($(this).attr('data-subpanelname') != 'Default') {
					subpanelNamearr.push('User');
				} else {
					subpanelNamearr.push('Default');
				}*/
			}
		});									
						
		data.push({
			"associationid": associationid
		});		
		data.push({
			"selectedAttributes": attributessArray.toString()
		});	
		data.push({		
			"selectedAttributesTypes": selectedAttributeType.toString()
		});
		data.push({
			"selectedAttributeId": selectedFieldId
		});	
		data.push({		
			"selectedAttributeType": selectedFieldType
		});									
				
		if(selectedFieldId == 0) {
			data.push({		
				"fieldTypearr": fieldTypearr.toString()
			});
			
			data.push({		
				"panelTypearr": panelTypearr.toString()
			});
			
			data.push({		
				"subpanelNamearr": subpanelNamearr.toString()
			});
		} else {
			data.push({		
				"fieldTypearr": $('#attribute_' + selectedFieldId).attr('data-attribute-type')
			});
			
			data.push({		
				"panelTypearr": $('#attribute_' + selectedFieldId).attr('data-paneltype')
			});		
			data.push({		
				"subpanelNamearr": $('#attribute_' + selectedFieldId).attr('data-subpanelname')
			});
			/*if($('#attribute_' + selectedFieldId).attr('data-subpanelname') != 'Default') {
				data.push({		
					"subpanelNamearr": "User"
				});
			} else {
				data.push({		
					"subpanelNamearr": "Default"
				});
			}*/
			
		}
		
		if(selectionType == 'addFilter' || selectionType == 'sortField' || selectionType == 'filterField' || (selectedFieldId == 0 && selectionType == 'panelFields')) {		   
		   fieldSelectionStatus = true;
		}		
										
		if(selectionType == 'filterField' || parseInt(appliedfiltercount) > 1) {
			filterApplied = 1;
			for (var i = 1; i < filtercount; i++) {
				var filterby = $('.attributes_filter_' + i + ' option:selected').val();
				var attrFilterId = $('.attributes_filter_' + i + ' option:selected').attr('data-attribute-id');
				var atrribute = $('.attributes_filter_' + i + ' option:selected').attr('data-attribute-type');
				var operatortype = $('.attributes_operators_' + i + ' option:selected').text();
				if(operatortype=='is only')operatortype = 'is';
				var filteroption = $('.attributes_values_' + i).attr('data-filter-option');
				var filtervalueattributeid = $('.attributes_values_' + i).attr('data-attribute-id');
				var filtervalueattributetype = $('.attributes_values_' + i).attr('data-filter-type'); // BG-475
				var attributevaluefilter = "";
				var attributevaluefilteroption = "";
				var dataattributeid = "";
				if (operatortype == 'between' || operatortype == 'not between') {
					$('.attributes_values_' + i).each(function () {
						attributevaluefilter += $(this).val() + ",";
					});
					attributevaluefilter.substring(0, attributevaluefilter.length - 1);
				} else if (operatortype == "is empty" || operatortype == "isn't empty" || operatortype == "today" || operatortype == "tomorrow" || operatortype == "tomorrow onwards"  || operatortype == "yesterday" || operatortype == "until yesterday" || operatortype == "last month"  || operatortype == "current month" || operatortype == "next month"  || operatortype == "last week" || operatortype == "current week" || operatortype == "next week") {
					attributevaluefilter = "  ";				
				} else {
					attributevaluefilter = $('.attributes_values_' + i).val();
					/* Start: BG-564 BG-597*/
					if(attributevaluefilter == '') {
						attributevaluefilter = "  ";
					}
					/* End: BG-564 BG-597*/
					attributevaluefilteroption = $('.attributes_values_' + i).attr('data-filter-option');
				}
				if (i > 1) {
					logical += $('option:selected', '.logical_' + i).text();
				}
				attributes += filterby + "~";
				atrributesFilterIds += attrFilterId + "~";
				attributetype += atrribute + "~";
				operators += operatortype + "~";
				if(attributevaluefilteroption == 2) {
					dataattributeid = $('.attributes_values_' + i).attr('data-attribute-id');
					filtervalues += dataattributeid + "~";
					filtervaluesoption += filteroption + "~";
					filtervalueattrid += filtervalueattributeid + "~";
					filtervalueattrType += filtervalueattributetype + "~";
				} else {
					filtervalues += attributevaluefilter.replaceAll("~","&tilde;")  + "~";//SM-193					
				}
				//filtervaluesoption += filteroption + "~";
				//filtervalueattrid += filtervalueattributeid + "~";
				//filtervalueattrType += filtervalueattributetype + "~";
				logical += "~";
			}
		}
		
		data.push({		
			"filterApplied": filterApplied
		});	
		data.push({
			"attributes": attributes
		});
		data.push({
			"atrributesFilterIds": atrributesFilterIds
		});
		data.push({
			"attributetype": attributetype
		});
		data.push({
			"logical": logical
		});
		data.push({
			"operators": operators
		});
		data.push({
			"filtervalues": filtervalues
		});
		data.push({				
			"filtervaluesoption": filtervaluesoption
		});	
		data.push({				
			"filtervalueattributeid": filtervalueattrid
		})
		data.push({				
			"filtervalueattributetype": filtervalueattrType
		});	
		data.push({
			"filtervaluepattern": filtervaluepattern
		});
		data.push({
			"arrangeattributesby": arrangeattributesby
		});		
		data.push({
			"identifierStatus": identifierStatus
		});				
		data.push({		
			"fieldSelectionStatus": fieldSelectionStatus
		});	
		data.push({
			"selectionType": selectionType
		});
							
		if(fieldSelectionStatus) {						
			$scope.loadSelectedFieldResponse(data);
		}
	};	
	
	$scope.loadSelectedFieldResponse = function(data) {	
		var _current_time_cache = new Date().getTime();
		var formData = {};		
		data.forEach(function(obj) {
		   Object.entries(obj).forEach(function([key, value]) {
			  formData[key] = value;
		   });
		});
		
		// added this condition as Safari Doesn't Support async: false
		$.ajax({
			type: "POST",		
			url: "index.cfm?event=association.getAssociationIdentifierSelectedAttributeValues&currenttimestamp=" + _current_time_cache,
			data: formData,
			dataType: "json",
			//async: false,
			//processData: false,
			beforeSend: function() {								
				showWaitScreen();				
			},
			success: function(responseData) {					
				/* Start: For Display in Preview Table */
				response = responseData;
				colCount = responseData.headers;
				rowCount = responseData.data;
				newExportIdentifierListId = responseData.newExportIdentifierListId;				
				/* End: For Display in Preview Table */								
				
				/* Start: For Filter Value Validation */
				$scope.resultJSON = responseData.originalResult;	
				/* End: For Filter Value Validation */
				if(!fromSavedReport){
					$scope.resetfieldorder();	
				}									
			},				
			complete: function() {	
				$scope.displayAttributesBasedOnCheckbox(downloadReport,fromSavedReport);
				hideWaitScreen();								
			},
			error: function(data) {
				alert('oops mistake on server');
				status = false;
			}
		});		
	};
	/* End: Export Optimization */
	
	$scope.exportIdentifiersReport = function(saveReport,action,overwrite) {
		if (saveReport != 'checkSaveReport') {
			$("#userinputreportname").val('');
			$("#userinputreportname_char_count").html('80');
		}
		var reportname =  $("#userinputreportname").val().trim();
		/* Start :: MV-1859 & MV-1885 */
		var appliedFCount = $(".filtercount").val();
		var msg = "";
		if(appliedFCount > 1){
			msg = validateFilters();
		}
		if(msg != "" && msg == 'invalid pattern') {
			return false;
		} else if (msg != "" && msg != 'invalid pattern') {
			alert(msg);
			return false;
		} else {
		/* End :: MV-1859 & MV-1885 */
			if(action == "save") {
				if (reportname.length == 0) {
					alert('Please provide a report name.');
					$("#userinputreportname").focus();
					return;
				}
				else if(validateNames(reportname)){
					alert('Please provide a report name that only uses letters, numbers and spaces.');
					$("#userinputreportname").focus();
					return;
				} else {
					var _current_time_cache = new Date().getTime();								
					var associationid = $("#associationid").val();	
					var filtercount = parseInt($('.appliedfiltercount').val());	
					var arrangeattributesby = $('.arrangeattributes:checked').val();
					var setAttributesOrder =  $('#setAttributeOrder').val();
					var identifierStatus = $('#ident_status_action').val();
					var selectedAttributes = "";
					var attributes = "";		
					var attributetype = "";
					var operators = "";
					var filtervalues = "";
					var logical = " ";
					var filtervaluesoption = "";
					var filtervalueattrid = "";
					$scope.saveOrder();
					if (setAttributesOrder == "0") {
						$('input[name="childpanelitem"]:checked').each(function (e, i) {
							var attributeid = $(this).attr('id');
							selectedAttributes += attributeid + ",";
						});	
						selectedAttributes = selectedAttributes.slice(0, selectedAttributes.length - 1);
					} else {
						selectedAttributes = $('#attributesortorder').val();
					}
					for (var i = 1; i < filtercount; i++) {							 
						var filterby = $('.attributes_filter_' + i + ' option:selected').val();				
						var atrribute = $('.attributes_filter_' + i + ' option:selected').attr('data-attribute-type');	
						var operatortype = $('.attributes_operators_' + i + ' option:selected').val();
						var operatortypetext = $('.attributes_operators_' + i + ' option:selected').text();
						if(operatortypetext=='is only')operatortypetext = 'is';
						var filteroption = $('.attributes_values_' + i).attr('data-filter-option');
						var filtervalueattributeid = $('.attributes_values_' + i).attr('data-attribute-id');
						var attributevaluefilter = "";						
						if(operatortypetext == 'between' || operatortypetext == 'not between') {
							$('.attributes_values_' + i).each(function(){
								attributevaluefilter += $(this).val() + ",";								  
							});						
							attributevaluefilter = attributevaluefilter.substring(0, attributevaluefilter.length-1);				
						} else if (operatortypetext == "is empty" || operatortypetext == "isn't empty" || operatortypetext == "today" || operatortypetext == "tomorrow" || operatortypetext == "tomorrow onwards"  || operatortypetext == "yesterday" || operatortypetext == "until yesterday" || operatortypetext == "last month"  || operatortypetext == "current month" || operatortypetext == "next month"  || operatortypetext == "last week" || operatortypetext == "current week" || operatortypetext == "next week") {
							attributevaluefilter = "  ";
						} else {
							attributevaluefilter = 	$('.attributes_values_' + i).val().trim();				
						}								
						logical += $('option:selected', '.logical_' + i).val() + "~";						
						attributes += filterby + "~";			
						attributetype += atrribute + "~";
						operators += operatortype + "~";
						filtervalues += attributevaluefilter.replaceAll("~","&tilde;") + "~";//SM-193	
						filtervaluesoption += filteroption + "~";
						filtervalueattrid += filtervalueattributeid + "~";
					}
					
					var editpatternflage = 0;
					if($('select[name="logical"]').prop("disabled")==true)
						editpatternflage=1;
					
					// Added for BG-64 : Start	
					var current_date_decider_value = $("#current_date").attr("class");
					var historical_date_decider_value = $("#historical_date").attr("class");		
					// Added for BG-64 : Stops

					var data = [];
					data.push({
						"associationid" : associationid
					});		
					data.push({
						"reportname" : reportname
					});	
					data.push({		  
					"arrangeattributesby": arrangeattributesby
					});
					data.push({		  
					"selectedAttributes": selectedAttributes
					});
					data.push({				
						"filterlogical": logical
					});	
					data.push({			
						"filterattributes": attributes			
					});		
					data.push({				
						"filterattributetype": attributetype
					});
					data.push({			
						"filteroperators": operators
					});
					data.push({				
						"filtervalues": filtervalues
					});												
					data.push({				
						"filtervaluesoption": filtervaluesoption
					});	
					data.push({				
						"filtervalueattributeid": filtervalueattrid
					});					
					data.push({				
						"filtervaluepattern": $('#filtervaluepattern').val()
					});	
					data.push({				
						"editpatternflage": editpatternflage
					});
					data.push({				
						"identifierStatus": identifierStatus
					});
					// Added for BG-64 : Start
					data.push({
						"current_date_decider_value" : current_date_decider_value
					});	
					data.push({
						"historical_date_decider_value" : historical_date_decider_value
					});	
					// Added for BG-64 : Stops		
					
					var url = "index.cfm?event=association.saveidentifiersreport&overwrite="+overwrite+"&currenttimestamp=" + _current_time_cache;
					$.post(url, {data:JSON.stringify(data)},
						function (saveReportStatus) {						
							if(saveReportStatus == "1") {
								overwritewindow(reportname,0); 
								//alert(reportname + ' already exists. Please enter a unique name');
								//$("#userinputreportname").focus();
							} else {
								if(overwrite == 1)
									closeCRWindow();
								showLoadingOverlay();
								overwritewindow(reportname,1);
								loadSavedReports();
								//$scope.generateExcelReport();					
								hideLoadingOverlay();
							}
						}
					)
				} 
			} else {
				showLoadingOverlay();
				setTimeout(function() {
					$scope.generateExcelReport();
					},
				400);
				//Adminfunct-94
				var churn_programid=$('#programid').val();
				var churn_email=$('#churnuseremail').val();
				var churn_api=$('#churnuapi').val();	
				var churn_SalesforceId=$('#SalesforceId').val();
				var churn_ChurnZerotrack=$('#ChurnZerotrack').val();
				ChurnZero.push(['setAppKey', churn_api]); // AppKey from ChurnZero
				ChurnZero.push(['setContact',churn_programid, churn_email]);
				
				if(churn_SalesforceId !='' && churn_ChurnZerotrack==1){
					ChurnZero.push(['trackEvent', 'Groups: Group Profile Export Run']);	
				}
				//Adminfunct-94
			}
		} //MV-1859 & MV-1885
	};
	
	//Code modified for BG-89/BG-90
	$scope.updateFetchedAttributesData = function(identifierId, attributeId, attributeValue, attributetype, user_Id_List, associationid)
	{
		//BG-64 Start		
		var responseResultData ="";
		var _current_time_cache = new Date().getTime();
		
		if(attributetype == 'assignedto') { // Start: Added Condition BG-475
			var url = "index.cfm?event=association.getcurrentlyactiveteacherassignments&user_Id_List=" + user_Id_List + "&identifierId=" + identifierId + "&associationid=" + associationid + "&currenttimestamp=" + _current_time_cache;		
			$.ajax({
				type:"post",
				url:url,
				async: false,
				beforeSend: function() {
					showLoadingOverlay();
				},
				success: function(responseData)
				{ 
					responseData = JSON.parse(responseData);
					responseResultData = responseData;
				},
				complete:function(data){	
					hideLoadingOverlay();			
				},
				error: function(data) {
				}	
			});	
			//BG-64 Stops	
	
			//BG-89/BG-90 : Start
			var responseResultDataHistorical ="";
			var _current_time_cache_ = new Date().getTime();
			var url = "index.cfm?event=association.getpreviousteacherassignments&identifierId=" + identifierId + "&associationid=" + associationid + "&currenttimestamp=" + _current_time_cache_;		
			var promise = $.ajax({
				type:"post",
				url:url,
				async: false,
				beforeSend: function() {
					showLoadingOverlay();
				},
				success: function(responseDataHistorical)
				{ 
					responseDataHistorical = JSON.parse(responseDataHistorical);
					responseResultDataHistorical = responseDataHistorical;
				},
				complete:function(data){	
					hideLoadingOverlay();			
				},
				error: function(data) {
				}	
			});	
			//BG-89/BG-90 : Stops	
		} // End: Added Condition BG-475

		var dataLen = response.data.length;
		var attributeColumn = "attribute_" + attributeId;		
		if(attributetype == 'RecieveText')
		{
			attributeColumn = "recievetext_" + attributeId;
			if(attributeValue.toLowerCase().trim() == "no")
			{
				attributeValue = "No"
			}
			else if(attributeValue.toLowerCase().trim() == "yes")
			{
				attributeValue = "Yes"
			}
		}		
		for(var i=0;i<dataLen;i++){				
			if(response.data[i].attribute_identifierid == identifierId)
			{
					if(attributeId == 'attribute_status'){
						response.data[i][attributeId] = attributeValue == 1 ? 'Active' : 'Archived';
					}
					else if(attributeId == 'attribute_identifiername' || attributeId == 'attribute_assignedto'){	
						
						//BG-64 Starts
						if(attributeId == 'attribute_identifiername'){
							response.data[i][attributeId] = attributeValue;
						}
						else if(attributeId == 'attribute_assignedto'){
							response.data[i][attributeId] = responseResultData;
							response.data[i]['attribute_historicalassignedto'] = responseResultDataHistorical;
						}
						//BG-64 Stops					
					}
					else{
						//console.log(attributeValue);
						if(Array.isArray(attributeValue)) {											
							response.data[i][attributeColumn] = attributeValue.join(";; ").toString();
						} else {
							if(attributeValue != undefined) {								
								if(attributetype == 'file'){	
									response.data[i][attributeColumn] = ''; // ASSNS-527 :: ASSNS-688
								}else{									
									response.data[i][attributeColumn] = attributeValue.toString();
								}	
								/* Start: MV-1232 */
								if(attributetype == 'mobile' && attributeValue.toString() == '') {
									var attrColId = 'recievetext_' + attributeColumn.split('_')[1];									
									response.data[i][attrColId] = '';
								}
								/* End: MV-1232 */
							} else {										
								response.data[i][attributeColumn] = "";								
							}
							
						}
						
					}
			}
		}
		$scope.displayAttributesBasedOnCheckbox(false);
	}//End


	var reportDeciderFlag = 0;
	$scope.displayReportAttributes = function(downloadReport){
			showLoadingOverlay();															  
			var reportId = $('input[name="report_name"]:checked').val();	
			var associationId = $("#associationid").val();
			var _current_time_cache = new Date().getTime();										
			var filtercount = parseInt($('.filtercount').val());

			for (i = 2; i <= filtercount; i++) {
				$('#subfilter_' + i).remove();
			}
	
			$('.filtercount').val('1');
			$('.appliedfiltercount').val('1');
			$('#filtervaluepattern').val('');
			$('#patternforrestore').val('');
			$('#editpatternflage').val('0');
			$('.filterpattern').css('display', 'none');
			$('#clearfilter').css('display', 'none');
			$('#btn_apply_filter').prop("disabled", true)
			$('.btn_add_filter_1').html('Add');
			$('.btn_cancel_filter_1').html('Cancel');	
			$('#userinputreportname').val('');
						
			$('input[name="childpanelitem"]').prop('checked',false);	
			$('input[name="childpanelitem"]').parents('.columngroup').removeClass("check_bgcolor");			
			
			var data = [];		
			data.push({
				"associationid" : associationId
			});		
			data.push({
				"reportid" : reportId
			});
			var url = "index.cfm?event=association.getidentifierreportalldetails&currenttimestamp=" + _current_time_cache;
			$.post(url, {data:JSON.stringify(data)},
				function (reportAllDetails) {	
					var previousStatus = $('#ident_status_action').val();
					var identifierStatus = reportAllDetails.reportdetails.identifierStatus;
					var arrangeattributesby = reportAllDetails.reportdetails.arrangeattributesby;
					var filtervaluepattern = reportAllDetails.reportdetails.filtervaluepattern;
					var editpatternflage = reportAllDetails.reportdetails.editpatternflage;
					var attributesselected = reportAllDetails.reportattributedetails.attributesselected;
					var attributesselectedArray = attributesselected.split(',');
					selectedarrayorder = attributesselectedArray;
					fromSavedReport = 1;		
					//BG-64 : Start
					var currentClass="";
					var historicalClass="";
					$("#current_date_span").hide();
					$("#historical_date_span").hide();

					var DateDeciderFlag = reportAllDetails.reportattributedetails.DateDeciderFlag;	
					var DateDeciderFlagArray = DateDeciderFlag.split(",");
					for(counter_j = 0;counter_j<attributesselectedArray.length;counter_j++){
						if(attributesselectedArray[counter_j] == "attribute_assignedto"){
							$("#current_date_span").show();	
							currentClass = DateDeciderFlagArray[counter_j];
						}else if(attributesselectedArray[counter_j] == "attribute_historicalassignedto")
						{
							$("#historical_date_span").show();
							historicalClass = DateDeciderFlagArray[counter_j];

						}
					}
					//alert(currentClass + " : "+ historicalClass);
					var cur_class = $("#current_date").prop("class");
					if(cur_class != currentClass)
					{
						$("#current_date").trigger("click");
					}
					var his_class = $("#historical_date").prop("class");
					if(his_class != historicalClass)
					{	
						$("#historical_date").trigger("click");
					}
					$('input[name="arrangeattributes"][value="' + arrangeattributesby + '"]').prop('checked', true);
					$("#currentArrangeField").val(arrangeattributesby); // BG-475
					$("#currentidentifierDisplay").val(identifierStatus); // BG-475
					//BG-64 : Stops	
					var count = 1;	
					$('#ident_status_action').val(identifierStatus);
					$('#attributesortorder').val(attributesselected);
					$("#setAttributeOrder").val('1');
					for(var i=0; i < attributesselectedArray.length; i++) {
						$('input[id="' + attributesselectedArray[i] + '"]').prop('checked', true);	
						$('#' + attributesselectedArray[i]).parents('.columngroup').addClass("check_bgcolor");
					}
					//$('input[name="arrangeattributes"][value="' + arrangeattributesby + '"]').prop('checked', true);
					
					$scope.attributeOrder = selectedarrayorder; 	// DS:: BG-454
					
					if (!($.isEmptyObject(reportAllDetails.reportfilterdetails))) {

						var filterlogicalArray = reportAllDetails.reportfilterdetails.filterlogical.split(',');	
						var attributeidArray = reportAllDetails.reportfilterdetails.attributeid.split(',');
						var attributetypeArray = reportAllDetails.reportfilterdetails.attributetype.split(',');	
						$('.appliedfiltercount').val(attributeidArray.length + 1);
						if(attributeidArray.length > 1) {
							var filteroperatorArray = reportAllDetails.reportfilterdetails.filteroperator.split(',');	
							var filtervalueoptionArray = reportAllDetails.reportfilterdetails.filtervalueoption.split('~');
							var filtervalueattributeidArray = reportAllDetails.reportfilterdetails.filtervalueattributeid.split('~');
							var filtervalueArray = reportAllDetails.reportfilterdetails.filtervalue.split('~');	
						} else {
							var filteroperatorArray = reportAllDetails.reportfilterdetails.filteroperator;
							var filtervalueoptionArray = reportAllDetails.reportfilterdetails.filtervalueoption;
							var filtervalueattributeidArray = reportAllDetails.reportfilterdetails.filtervalueattributeid;
							var filtervalueArray = reportAllDetails.reportfilterdetails.filtervalue;	
						}					
						
						$('#filterbox').slideDown(1000);
						$('#filteroption').html('Hide Filter');	
						
						var disabledLogicalOperator = false; 
						 
						for(var j=0; j < attributeidArray.length; j++) {							
							if(count > 1 && filterlogicalArray[j] != '' && filterlogicalArray[j] != 'undefined') {
								$('.logical_' + count +' option[value="' + filterlogicalArray[j] +'"]').prop('selected', 'selected');								
							}
							else if(count > 1){
								disabledLogicalOperator = true;
							}
							$j1('.attributes_filter_' + count).val(attributeidArray[j]);
							$j1('.attributes_filter_' + count).trigger("change");													
							if(attributeidArray.length > 1) {
								$('.attributes_operators_' + count +' option[value="' + filteroperatorArray[j] +'"]').prop('selected', 'selected');
							} else {								
								$('.attributes_operators_' + count +' option[value="' + filteroperatorArray +'"]').prop('selected', 'selected');
							}	
							$('.attributes_operators_' + count).trigger("change");							
							var operatorText = $('.attributes_operators_' + count + ' option:selected').text();							
							var filterattributerel = $('.attributes_filter_' + count + ' option:selected').attr('rel');//BG-135						
							if(operatorText == 'between' || operatorText == 'not between') {
								if(attributeidArray.length > 1) {
									var datebetweenValues = filtervalueArray[j].split(',');											
								} else {
									var datebetweenValues = filtervalueArray.split(',');
								}
								//alert(datebetweenValues[0] + ", "+ datebetweenValues[1] + ", "+filterattributerel);
									// BG-135: Start
								if(typeof filterattributerel != 'undefined' && filterattributerel.length > 0){
									$('#agetxtbox_1_' + count).val(datebetweenValues[0]);	
									$('#agetxtbox_2_' + count).val(datebetweenValues[1]);
									// BG-135: End
								}else{								
									$('#datelink1_' + count).val(datebetweenValues[0]);	
									$('#datelink2_' + count).val(datebetweenValues[1]);
								}	
							} else {									
								if(attributeidArray.length > 1) {								
									if(filtervalueoptionArray[j] == 2) {
										$('.attributes_values_' + count).prop('disabled',true);
									}
									$('.attributes_values_' + count).attr('data-filter-option',filtervalueoptionArray[j]);								
									$('.attributes_values_' + count).attr('data-attribute-id',filtervalueattributeidArray[j]);
									$('.attributes_values_' + count).val(filtervalueArray[j].replaceAll("&tilde;","~"));//SM-193
								} else {
									if(filtervalueoptionArray == 2) {
										$('.attributes_values_' + count).prop('disabled',true);
									}
									$('.attributes_values_' + count).attr('data-filter-option',filtervalueoptionArray);								
									$('.attributes_values_' + count).attr('data-attribute-id',filtervalueattributeidArray);
									$('.attributes_values_' + count).val(filtervalueArray.replaceAll("&tilde;","~"));//SM-193
								}
							}	
							if(editpatternflage == 1) {
								reportDeciderFlag = 1;	
								$scope.addFilter(count,0); // 0 used to not call the update filter pattern
								angular.element(document.getElementById('exportAttributeCtrl')).scope().cancelPattern();
								$('#filtervaluepattern').val(filtervaluepattern);
								$('#hiddenpattern').val('');
								$('#patternforrestore').val(filtervaluepattern);
								$('#editpatternflage').val(editpatternflage);
								reportDeciderFlag = 0;	
							} else {
								reportDeciderFlag = 1;							
								$scope.addFilter(count,1);	
								reportDeciderFlag = 0;							
							}					
							count++;																																										
						}
						if(disabledLogicalOperator){
							$('select[name="logical"]').prop('disabled', true);
							$('select[name="logical"]').val('');
						}
					} else {							
						$('.filternumber_1').html('');
						$('.filternumber_1').css('display', 'none');
		
						$('.filter_logical_1').html('');
						$('.filter_logical_1').css('display', 'none');
		
						$('.attributes_filter_label').addClass('attributes_filter_label-215');
						$('.attributes_filter_label').removeClass('attributes_filter_label-175');
						$('.attributes_filter_label').removeAttr('style');
						$('.attributes_filter_label').addClass('margin-left-5');
		
						$('.attributes_operators_label').addClass('attributes_operators_label-135');
						$('.attributes_operators_label').removeClass('attributes_operators_label-100');
		
						$('.attributes_values_label').addClass('attributes_values_label-165');
						$('.attributes_values_label').removeClass('attributes_values_label-140');
		
						$('.attributes_filter_1').addClass('attributes_filter-215');
						$('.attributes_filter_1').removeClass('attributes_filter-175');
		
						$('.attributes_operators_1').addClass('attributes_operators-135');
						$('.attributes_operators_1').removeClass('attributes_operators-100');
		
						$('.filterinput_1').removeClass('date_filter_input-146');
						$('.filterinput_1').removeClass('date_filter_input-177');
		
						$('.attributes_values_1').addClass('attributes_values-165');
						$('.attributes_values_1').removeClass('attributes_values-140');
		
						$('.attributes_filter_1').val("0").change();
						
						$('#filterbox').slideUp(1000);
						$('#filteroption').html('Show Filter');		
						
						$scope.removeFilter(1);	// MV-1929
					}						
					//$scope.fetchattributesdata(downloadReport);	
					$timeout(function () {
						//if(identifierStatus == 1) {
						//	$scope.getSelectedFieldData('panelFields',0,'');
						//} else {
							$scope.fetchattributesdata(downloadReport);	
						//}
					});
					
					/*$timeout(function () {
						if(downloadReport){
							$scope.exportToExcel();
						}
					});*/
				}, 'json'
			).always(hideAjaxLoadingOverlay);
	  };	
	  
			var links = document.getElementsByTagName("a");
			var panelid = 0;
			var selectAnchor = '';
			var paneltotalinput = '';
			//console.log(links.length);

			for ( var i = 0; i < links.length; i++ ) {
				if(links[i].innerHTML=='Select All'){
				
					panelid = links[i].getAttribute("rel");
					selectAnchor = $("#" + links[i].getAttribute("id"));
					//console.log($("#panel" + panelid).find(".childpanelitem").length);
					//console.log($("#panel" + panelid).find(".childpanelitem:checked").length);
					if($("#panel" + panelid).find(".childpanelitem").length == $("#panel" + panelid).find(".childpanelitem:checked").length){
						links[i].innerHTML = 'Select None';
					}
				}       
			}
	/* Lucky : End Code */
}]);
// ASSNS-527 Starts
app.filter('trusted', function ($sce) {
	return function (value) {
	  return $sce.trustAsHtml(value);
	}
});
// ASSNS-527 Ends
/* YEOU : START */
/*app.factory('exportUiGridService', exportUiGridService);
exportUiGridService.inject = ['uiGridExporterService'];
function exportUiGridService(uiGridExporterService) {
	var service = {
		exportToExcel: exportToExcel
	};

	return service;

	function Workbook() {
		if (!(this instanceof Workbook)) return new Workbook();
		this.SheetNames = [];
		this.Sheets = {};
	}

	function exportToExcel(documentName, sheetName, gridApi, rowTypes, colTypes) {
		var columns = gridApi.grid.options.showHeader ? uiGridExporterService.getColumnHeaders(gridApi.grid, colTypes) : [];
		var data = uiGridExporterService.getData(gridApi.grid, rowTypes, colTypes);
		var fileName = gridApi.grid.options.exporterExcelFilename ? gridApi.grid.options.exporterExcelFilename : documentName;
		fileName += '.xlsx';

		var wb = new Workbook(),
			ws = sheetFromArrayUiGrid(data, columns);
		wb.SheetNames.push(sheetName);
		wb.Sheets[sheetName] = ws;
		var wbout = XLSX.write(wb, {
			bookType: 'xlsx',
			bookSST: true,
			type: 'binary'
		});

		//Show Completed Text on popup 
		//Hide In Progress Text/ProgressBar
		//Show Download link
		$("#Completed").show();
		$("#nonCompleted").hide();
		$("#ReportLink").show();
		
		saveAs(new Blob([s2ab(wbout)], {
			type: 'application/octet-stream'
		}), fileName);
	}

	function sheetFromArrayUiGrid(data, columns) {
		var ws = {};
		var range = {
			s: {
				c: 10000000,
				r: 10000000
			},
			e: {
				c: 0,
				r: 0
			}
		};

		var associationName = $("#associationName").val();

		var utc =  moment.utc(new Date());
		//var pst = moment(utc).zone('-0700'); // -0700 code is for PST
		//var pst = moment(utc).zone('-0800'); //-0800 code is for PDT
		var pst = moment.tz(utc,'America/Los_Angeles');

		var exportDateTime = "(as of "+ pst.format('MM/DD/YYYY')+" at " + pst.format('h:mm A')+" U.S. Pacific)";
		var firstRow = "Group Name: "+ associationName + " " + exportDateTime; //MCR-47
		addCell(range,firstRow,0,0,ws,false);
		var C = 0;
		var wscols = [];
		columns.forEach(function (c) {
			var v = c.displayName || c.value || columns[i].name;
			wscols.push({'wch':v.length});
			addCell(range, v, 2, C, ws,true);
			C++;
		}, this);

		var R = 3;
		data.forEach(function (ds) {
			C = 0;
			ds.forEach(function (d) {
				var v = $.trim(d.value);
				addCell(range, v, R, C, ws,false);
				C++;
			});
			R++;
		}, this);
		if (range.s.c < 10000000) ws['!ref'] = XLSX.utils.encode_range(range);
		ws['!cols'] = wscols;
		return ws;
	}*/
	/**
	 * 
	 * @param {*} data 
	 * @param {*} columns 
	 */

	/*function datenum(v, date1904) {
		if (date1904) v += 1462;
		var epoch = Date.parse(v);
		return (epoch - new Date(Date.UTC(1899, 11, 30))) / (24 * 60 * 60 * 1000);
	}

	function s2ab(s) {
		var buf = new ArrayBuffer(s.length);
		var view = new Uint8Array(buf);
		for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
		return buf;
	}

	function addCell(range, value, row, col, ws, isHeader) {
		if (range.s.r > row) range.s.r = row;
		if (range.s.c > col) range.s.c = col;
		if (range.e.r < row) range.e.r = row;
		if (range.e.c < col) range.e.c = col;
		var cell = {
			v: value,
			s: {alignment: {horizontal:"left"}}
		};
		if (cell.v == null) cell.v = '-';
		var cell_ref = XLSX.utils.encode_cell({
			c: col,
			r: row
		});

		//if (typeof cell.v === 'number') cell.t = 'n';
		//if (!isNaN(cell.v)) cell.t = 'n'; 
		//else 
		if (typeof cell.v === 'boolean') cell.t = 'b';
		else if (cell.v instanceof Date) {
			cell.t = 'n';
			cell.z = XLSX.SSF._table[14];
			cell.v = datenum(cell.v);
		} else cell.t = 's';
		if(isHeader){
			cell.s = {
				font: {
					bold:isHeader
				}
			};
		}
		ws[cell_ref] = cell;
	}
}*/


/* Start: BG-475 */
function fetchattributesdata(downloadReport){	
	angular.element(document.getElementById('exportAttributeCtrl')).scope().fetchattributesdata(downloadReport);		
}

function validateFilters() {
	var validationstatus = angular.element(document.getElementById('exportAttributeCtrl')).scope().savePattern();	
	var msg = "";
	if(validationstatus) {
		var filtercount = parseInt($('.filtercount').val());
		for (var datacount = 1; datacount < filtercount; datacount++) {
			var filterby = $('option:selected', '.attributes_filter_' + datacount).val();
			var operatorType = $('.attributes_operators_' + datacount + ' option:selected').text();
			if(operatorType=='is only')operatorType = 'is';
			var filterValue = $('.attributes_values_' + datacount).val().trim();
			var filterattributetext = $('option:selected', '.attributes_filter_' + datacount).text();
			var filterattributetype = $('.attributes_filter_' + datacount + ' option:selected').attr('data-attribute-type');
			var filterattributerel = $('.attributes_filter_' + datacount + ' option:selected').attr('rel');//BG-110, BG-135				
			var filterattributeisqualitative = $('.attributes_filter_' + datacount + ' option:selected').attr('data-attribute-isqualitative');
			
			if (filterby == 0) {
				msg += "Please select filter by.";
			}
			if (operatorType != "is empty" && operatorType != "isn't empty" && operatorType != "today" && operatorType != "tomorrow" && operatorType != "tomorrow onwards" && operatorType != "yesterday" && operatorType != "until yesterday" && operatorType != "last month" && operatorType != "current month" && operatorType != "next month" && operatorType != "last week" && operatorType != "current week" && operatorType != "next week") {
				if ($('.attributes_filter_' + datacount + ' option:selected').attr('data-attribute-type') == 'date') {
					if ((operatorType == "between" || operatorType == "not between") && (($('#datelink1_' + datacount).val() != 'undefined' && $('#datelink1_' + datacount).val() == "") || ($('#datelink2_' + datacount).val() != 'undefined' && $('#datelink2_' + datacount).val() == ""))) {
						msg += "Please provide both between date filter value.";
					}
						// BG-135: Start
					else if ((operatorType == "between") && (($('#agetxtbox_1_' + datacount).val() != 'undefined' && $('#agetxtbox_1_' + datacount).val() == "") || ($('#agetxtbox_2_' + datacount).val() != 'undefined' && $('#agetxtbox_2_' + datacount).val() == ""))) {
						msg += "Please provide both between age filter value.";
					}
						// BG-135: End
					else {
						// BG-135: Start	
						if (typeof filterattributerel != 'undefined' && filterattributerel.length > 0) {
							if (typeof filterValue != 'undefined' && filterValue == "") {
								msg += "\nPlease provide age filter value.";
							}
						}else{
							if (typeof filterValue != 'undefined' && filterValue == "") {
								msg += "\nPlease provide date filter value.";
							}
						}
						// BG-135: End
					}
				} else {
					if (typeof filterValue != 'undefined' && filterValue == "") {
						msg += "\nPlease provide filter value.";
					} else if ((filterattributetype == 'textbox' || filterattributetype == 'select' || filterattributetype == 'checkbox') && filterattributeisqualitative == '0') {
						filteroption = $('.attributes_values_' + datacount).attr('data-filter-option');
						if (isNaN(filterValue) && filteroption != 2) {
							msg += "\nPlease provide a numeric filter value for " + filterattributetext + ".";
						}
					} /*else if (filterValue.indexOf('~') > -1) {
						msg += "\nPlease provide valid filter value for " + filterattributetext + ", it should not contain tilde(~) operator.";
					} Commented for SM-193*/
				}
			}
			if (msg != "") {
				break;
			}
		}
	}
	if(validationstatus == false) {
		return "invalid pattern";
	}
	return msg;
}
/* End: BG-475 */

function displayReportAttributes(){
	angular.element(document.getElementById('exportAttributeCtrl')).scope().displayReportAttributes(false);
}

// "updateFetchedAttributesData" Modified for BG-64
function updateFetchedAttributesData(identifierId, attributeId, attributeValue, attributetype, user_Id_List, associationid){
	if(attributetype === 'RecieveText')
	{
		if(attributeValue == 1)
		{
			attributeValue = 'Yes'
		}
		else if(attributeValue == 0)
		{
			attributeValue = 'No'
		}
	}	
	angular.element(document.getElementById('exportAttributeCtrl')).scope().updateFetchedAttributesData(identifierId, attributeId, attributeValue, attributetype, user_Id_List, associationid);
}

function downloadReport(){
	angular.element(document.getElementById('exportAttributeCtrl')).scope().displayReportAttributes(true);
}
//ASSNS-527 Start
function loadResponse(data, downloadReport){
	showLoadingOverlay();	
	setTimeout(
		function(){	
			angular.element(document.getElementById('exportAttributeCtrl')).scope().loadResponse(data, downloadReport);
		},
	0);	
}
//ASSNS-527 End

function checkIfAllCheckboxAreChecked(){
	angular.element(document.getElementById('exportAttributeCtrl')).scope().checkIfAllCheckboxAreChecked();
}

function closeExportWindow(){	
	ColdFusion.Window.destroy("ExportWindow");
}

function isInArray(value, array) {
    return array.indexOf(value) > -1;
}
function toggleRecieveCheckbox(inputName,this_)
{
	if(inputName!="undefined")
	{
		if($(this_).prop("checked") == true){
					
		}
		else{
			
			$(inputName).prop("checked",false)
		}
	}
	
}
function toggelSelectAllText(curr,className){
	selectedarrayorder = [];
	//BG-64 : Start
	var element_id = $(curr).attr("id");
	if(element_id == "attribute_assignedto"){
		if($(curr).prop("checked") == true){
			$("#current_date_span").show();
		}
		else
		{
			$("#current_date_span").hide();
		}
	}
	if(element_id == "attribute_historicalassignedto"){
		if($(curr).prop("checked") == true){
			$("#historical_date_span").show();
		}
		else
		{	
			$("#historical_date_span").hide();
		}

	}
	//BG-64 : Stops
	
	var panelId = $(curr).attr('data-association-panel-id');
	if($("#setAttributeOrder").val()==1){	
		var _val = $(curr).attr('data-attribute-id');		
		var arr_selected = $('#attributesortorder').val().split(',');	
		if($(curr).prop("checked")){
			if (!isInArray(_val, arr_selected)) {			
				arr_selected.push(_val);			
			}
		 }
		 else{			 
				if($.inArray(_val, arr_selected)>0)
			 	arr_selected.splice($.inArray(_val, arr_selected),1);
		 }		
		$('#attributesortorder').val(arr_selected.toString());
	}	
	if(!$(curr).prop('checked')){
		$('#'+className+panelId).html('Select All');		
	}else{
		var currPanel = $('#panel'+panelId);
		var show_archived_attributes = $('#show_archived_attributes');
		var allCheckboxesInCurrentPanel = currPanel.find('.childpanelitem');
		var checkboxesCheckedInCurrentPanel = currPanel.find('.childpanelitem:checked');
		var archivedAttributes =  currPanel.find('.archivedAttribute').find('.childpanelitem');

		var attributesInView = 0;

		if(show_archived_attributes.html() === 'Show Archived Fields'){
			attributesInView = allCheckboxesInCurrentPanel.length - archivedAttributes.length;
			if(attributesInView == checkboxesCheckedInCurrentPanel.length){
				$('#'+className+panelId).html('Select None');
			}else{
				$('#'+className+panelId).html('Select All');
			}
		} else {
			//before it was (else if(show_archived_attributes.html() === 'Hide Archived Attributes'))
			attributesInView = allCheckboxesInCurrentPanel.length;
			if(attributesInView == checkboxesCheckedInCurrentPanel.length){
				$('#'+className+panelId).html('Select None');
			}else{
				$('#'+className+panelId).html('Select All');
			}
		}
		//This is outside the Angular Controller.
		checkIfAllCheckboxAreChecked();

	}
}

function overwritewindow(reportname,status){
  var cfwindowTitle = "";
  if(status==0){
  ColdFusion.Window.create("overwriteWindow",cfwindowTitle,"index.cfm?event=association.overwritewindow&reportname="+reportname+"&statusow="+status,{modal:true,width:450,height:180,center:true,draggable:true});
  }
  else{
   ColdFusion.Window.create("overwriteWindow",cfwindowTitle,"index.cfm?event=association.overwritewindow&reportname="+reportname+"&statusow="+status,{modal:true,width:250,height:180,center:true,draggable:true}); 
  }
  ColdFusion.Window.onHide("overwriteWindow", closeCRWindow); 
}

function closeCRWindow(){
  ColdFusion.Window.destroy("overwriteWindow");        
}

function contineOW(){
	angular.element(document.getElementById('exportAttributeCtrl')).scope().exportIdentifiersReport('checkSaveReport','save',1);
}
/* YEOU : END */

/* Lucky: Start ASSNS-635 */
function fetchIdentifiersByStatus() {
	var appliedFCount = $(".appliedfiltercount").val();
	var appliedAllFilterCount= $(".filtercount").val();//MV-1885
	var msg = "";
	if(appliedAllFilterCount > 1) {//MV-1885
		msg = validateFilters();
	}	
	
	var currentStatus = $("#currentidentifierDisplay").val();	
	if(msg != "" && msg == 'invalid pattern') {
		$('#ident_status_action').val(currentStatus);
		return false;
	} else if (msg != "" && msg != 'invalid pattern') {						
		$('#ident_status_action').val(currentStatus);		
		alert(msg);
		return false;		
	} else if (appliedAllFilterCount > 1 && $('#btn_apply_filter').prop('disabled') == true) {//MV-1885
		$('#ident_status_action').val(currentStatus);
		alert('Please update filter value.');
		return false;
	} else {
		showLoadingOverlay();	
		setTimeout(
			function(){	
				//hideLoadingOverlay();	
				angular.element(document.getElementById('exportAttributeCtrl')).scope().fetchattributesdata(false);	
			},
		400);
	}
}
/* Lucky: End ASSNS-635 */

	//BG-64 Start
	function toggleCurrentDate(currentDate){
		if($(currentDate).attr("class") == "show_current_date")
		{
			$(currentDate).text("Remove Dates");
			$(currentDate).removeClass("show_current_date");
			$(currentDate).addClass("hide_current_date");
			angular.element(document.getElementById('exportAttributeCtrl')).scope().current_date_decider_flag = "add";
			angular.element(document.getElementById('exportAttributeCtrl')).scope().displayAttributesBasedOnCheckbox(downloadReport);
		}
		else if($(currentDate).attr("class") == "hide_current_date")
		{
			$(currentDate).text("Add Dates");
			$(currentDate).removeClass("hide_current_date");
			$(currentDate).addClass("show_current_date");
			angular.element(document.getElementById('exportAttributeCtrl')).scope().current_date_decider_flag ="remove";
			angular.element(document.getElementById('exportAttributeCtrl')).scope().displayAttributesBasedOnCheckbox(downloadReport);
		}
		
	}

	function toggleHistoricalDate(historicalDate){
		if($(historicalDate).attr("class") == "show_historical_date")
		{
			$(historicalDate).text("Remove Dates");
			$(historicalDate).removeClass("show_historical_date");
			$(historicalDate).addClass("hide_historical_date");
			angular.element(document.getElementById('exportAttributeCtrl')).scope().historical_date_decider_flag ="add";
			angular.element(document.getElementById('exportAttributeCtrl')).scope().displayAttributesBasedOnCheckbox(downloadReport);
		}
		else if($(historicalDate).attr("class") == "hide_historical_date")
		{
			$(historicalDate).text("Add Dates");
			$(historicalDate).removeClass("hide_historical_date");
			$(historicalDate).addClass("show_historical_date");
			angular.element(document.getElementById('exportAttributeCtrl')).scope().historical_date_decider_flag ="remove";
			angular.element(document.getElementById('exportAttributeCtrl')).scope().displayAttributesBasedOnCheckbox(downloadReport);
		}
	}
	//BG-64 Stops

/* Start: BG-113 */
function arrayElementCount(original) {
 
	var compressed = [];
	// make a copy of the input array
	var copy = original.slice(0);
 
	// first loop goes over every element
	for (var i = 0; i < original.length; i++) {
 
		var myCount = 0;	
		// loop over every element in the copy and see if it's the same
		for (var w = 0; w < copy.length; w++) {
			if (original[i] == copy[w]) {
				// increase amount of times duplicate is found
				myCount++;
				// sets item to undefined
				delete copy[w];
			}
		}
 
		if (myCount > 0) {
			var a = new Object();
			a.value = original[i];
			a.count = myCount;
			compressed.push(a);
		}
	}
 
	return compressed;
};
/* End: BG-113 */