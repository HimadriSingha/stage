var selectedarrayorder = [];
var downloadZipRow = 0; // MV-MV-1943

var app = angular.module('exportStaffApp', ['ngAnimate', 'ngTouch', 'ui.grid', 'ui.grid.moveColumns', 'ui.grid.saveState', 'ui.grid.selection', 'ui.grid.cellNav', 'ui.grid.resizeColumns', 'ui.grid.moveColumns', 'ui.grid.pinning', 'ui.grid.grouping', 'ui.grid.pagination', 'ui.grid.exporter']);
var fromSavedReport = 0;
app.controller('exportStaffCtrl', ['$scope', '$timeout', '$compile', '$sce', 'uiGridConstants', 'uiGridExporterConstants',function ($scope, $timeout, $compile, $sce, uiGridConstants, uiGridExporterConstants) {
	
	var rosterOrganization = $('#rosterOrganization').val();
	var inValidInput = false;
	var colCount = [];
	var rowCount;
	var response;	
	var sortcolumn = "";
	var sorttype = "";
	var downloadReport = false;
	var userlistid = "";
	var resultUserIdList = "";
	var resultUserStatus = "";
	var enableSort = false;
  var iconEnable=""; //MV-862
	var emailIcon=""; //MV-862
	if(rosterOrganization == 'staffmember') {
		enableSort = true;
	}
	$scope.JCounter = 0;	
	$scope.resultJSON = [];
	$scope.removeFieldOrder = [];
	$scope.state = "";
	$scope.fieldorder=[];
	$scope.arrangefields = "row";
	var updated_user_id = "";	
	var hideAjaxLoadingOverlay = function () {
		$('#ajaxFilterLoading .bg').height('100%');
		$('#ajaxFilterLoading').fadeOut(300);
	}

	var showLoadingOverlay = function () {
		$('#ajaxFilterLoading .bg').height('100%');
		$('#ajaxFilterLoading').fadeIn(300);
		$("#ajaxFilterLoading").attr("tabindex", -1).focus();
	};
		
	$scope.gridOptions = {
		enableColumnResizing: true,
		enableColumnMoving: true,
		enableSorting: enableSort,
		enableHiding: false,
		enableSelectAll: true,
		exporterCsvFilename: 'myFile.csv',
		exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
		onRegisterApi: function (gridApi) {
			$scope.gridApi = gridApi;
			$scope.gridApi.colMovable.on.columnPositionChanged($scope, $scope.saveOrder);
		}
	};
	
	$scope.gridOptions.columnDefs = [];
	
	$scope.htmlEncode = function (value) {
		//create a in-memory div, set it's inner text(which jQuery automatically encodes)
		//then grab the encoded contents back out.  The div never exists on the page.
		return $('<div/>').text(value).html();
	}
	
	$scope.onLoad = function () {				
		
		if ($('body').find('#ajaxFilterLoading').attr('id') != 'ajaxFilterLoading') {
			var html = '<div id="ajaxFilterLoading" style="display:none"><img id="loading" src="../../images/icons/animated_loading.gif"><div>';
			html += '<div></div></div><div class="bg"></div></div>'
			$('body').append(html);
		}

		var height = $('body').outerHeight();
		var width = $('body').outerWidth();
		$('#ajaxFilterLoading').css({
			'width': '100%',
			'height': '100%',
			'position': 'fixed',
			'z-index': '10000000',
			'top': '0',
			'left': '0'
		});

		$('#ajaxFilterLoading .bg').css({
			'background': '#000000',
			'opacity': '0.15',
			'width': '100%',
			'height': '100%',
			'position': 'absolute',
			'top': '0'
		});

		$('#ajaxFilterLoading > div:first').css({
			'width': '100%',
			'text-align': 'center',
			'position': 'absolute',
			'left': '0',
			'top': '48%',
			'font-size': '16px',
			'z-index': '10',
			'color': '#ffffff'
		});

		$scope.fetchFieldsData(false);
	};
	
	$scope.fetchFieldsData = function (generateExcel) {	
		showLoadingOverlay();
		var rosterOrganization = $('#rosterOrganization').val();
		var staffList = "";
		var filtercount = parseInt($('.filtercount').val());
		var arrangeFieldsby = $('.arrangefields:checked').val();
		var filterFields = "";
		var filterFieldtype = "";
		var filterOperators = "";
		var filterValues = "";
		var filterLogical = " ";
		var filterPattern= $('#filtervaluepattern').val();		
		var filterApplied = "";
		var filtercount = parseInt($('.filtercount').val());	
		var filterValuesOption = "";
		var filterValueFieldId = "";
		var paneltype = "";
		var subpaneltype = "";
		var data = [];
		var fieldsArray = [];
		var selectedFieldType = [];
						
		if(filtercount > 1){
			var filtervaluepattern = $('#filtervaluepattern').val();	
			for(var i = 1; i<filtercount; i++) {	
					var filterby = $('option:selected', '.filter_field_' + i).val();	
					var panel = $('option:selected', '.filter_field_' + i).attr('data-paneltype');	
					var subpanel = $('option:selected', '.filter_field_' + i).attr('data-subpanelname');
					var field = $('option:selected', '.filter_field_' + i).attr('data-fieldtype');	
					var operatorType = $('.filter_operators_' + i + ' option:selected').text();
					if(operatorType=='is only')operatorType = 'is';
					fieldvaluefilter = "";					
					if(operatorType == 'between' || operatorType == 'not between') {
						$('.filtervalue_' + i).each(function(){
							fieldvaluefilter += $(this).val() + ",";								  
						});
						fieldvaluefilter.substring(0, fieldvaluefilter.length-1);				
					} else {
						fieldvaluefilter = 	$('.filtervalue_' + i).val();
						if(fieldvaluefilter == '') {
							fieldvaluefilter = ' ';
						}
					}
					if(i>1) {
						filterLogical += $('option:selected', '.sel_action_' + i).text();
					}
					filterFields += filterby + "~";
					paneltype += panel + "~";
					subpaneltype += subpanel + "~";
					filterFieldtype += field + "~";
					filterOperators += operatorType + "~";
					filterValues += fieldvaluefilter + "~";	
					filterLogical += "~";
					
					fieldsArray.push(filterby);
			}
		}
		
		/*if(filterFields != '') {
		   	$("#filterApplied").val("1");
		}*/				
		
		$('input[name="childpanelitem"]:checked').each(function(e,i){					
			var fieldId = $(this).val();
			fieldsArray.push(fieldId);
			selectedFieldType.push($(this).attr('data-fieldType'));			
		});
				
		fieldsArray.push($('input[data-fieldtype="userid"]').val());		
		
		data.push({
			"rosterOrganization": rosterOrganization
		});
		data.push({
			"staffList": $('#staffList').val()
		});
		data.push({
			"siteList": $('#siteList').val()
		});				
		data.push({				
			"customfields": $('.customfields').val()
		});
		data.push({			
			"customfieldvalue": $('.customfieldvalue').val()
		});		
		data.push({			
			"customfieldvaluenames": $('.customfieldvaluenames').val()
		});
		data.push({
			"stafffields": fieldsArray.toString()
		});	
		data.push({		
			"selectedFields": fieldsArray.toString()
		});
		data.push({
			"selectedFieldType": selectedFieldType.toString()
		});
		data.push({
			"sortcolumn": sortcolumn
		});
		data.push({
			"sorttype": sorttype
		});		
		data.push({
			"filterFields": filterFields
		});
		data.push({
			"filterFieldtype": filterFieldtype
		});
		data.push({
			"paneltype": paneltype
		});
		data.push({
			"subpaneltype": subpaneltype
		});
		data.push({
			"filterOperators": filterOperators
		});
		data.push({
			"filterValues": filterValues
		});
		data.push({				
			"filterValuesOption": filterValuesOption
		});	
		data.push({				
			"filterValueFieldId": filterValueFieldId
		});	
		data.push({
			"filterLogical": filterLogical
		});
		data.push({
			"filterApplied": $("#filterApplied").val()
		});		
		data.push({
			"arrangefieldsby": arrangeFieldsby
		});
		data.push({
			"filterPattern": filterPattern
		});		
		
		hideLoadingOverlay();		
		
		$scope.loadResponse(data, generateExcel);
	};
	
	$scope.loadResponse = function (data, generateExcel) {			
		//var selectedAttributes = $(".childpanelitem:checked");
		var _current_time_cache = new Date().getTime();
		var formData = {};
		data.forEach(function(obj) {
		   Object.entries(obj).forEach(function([key, value]) {
			  formData[key] = value;
		   });			  
	    });
		
		$.ajax({
			type: "POST",			
			url: "index.cfm?event=staff.staffExportFieldValues&currenttimestamp=" + _current_time_cache,
			data: formData,
			dataType: "json",
			//async: false,
			beforeSend: function() {				
				showWaitScreen();
			},
			success: function(responseData) {				
				inValidInput = $.isEmptyObject(responseData.Error);
				if(inValidInput) {
					
					/* Start: For Display in Preview Table */
					colCount = responseData.headers;
					rowCount = responseData.data;
					userlistid = responseData.USERLISTID;
					emailIcon=responseData.mailIcon; //MV-862
					/* End: For Display in Preview Table */
					
					/* Start: For CP Popup */
					resultUserIdList = responseData.RESULTUSERLISTID;	
					$('#resultUserIdList').val(resultUserIdList);
					resultUserStatus = responseData.RESULTUSERSTATUS;	
					$('#resultUserStatus').val(resultUserStatus);
					/* End: For CP Popup */
					
					/* Start: For Filter Value Validation */
					$scope.resultJSON = responseData.originalResult;																										
					if($scope.JCounter == 0){
						$scope.resultJSON = responseData.originalResult;
						$scope.JCounter++;
					}
					else
					{	
						for(i=0;i<responseData.data.length;i++){
							if(responseData.data[i]["userid"] == updated_user_id)
							{
								$scope.resultJSON.data[i]=responseData.data[i];/*MS-181*/
							}
						}
						updated_user_id ="";
					}
					/* End: For Filter Value Validation */
				} else {
					alert("Please select the valid options");
				}
			},		
			complete: function(responseData) {				
				if(inValidInput) {
					if(!fromSavedReport){
						$scope.resetfieldorder();
					}
					$timeout(function () {		//MV-862
						$scope.displayFieldsBasedOnCheckbox(generateExcel);	
					});
				}
				hideWaitScreen();				
			},
			error: function(responseData) {
				console.log(responseData);
				alert('oops some mistake on server');
			}
		});		
	};
	
	$scope.fieldClicked = function(panelid,subpanelid,fieldid,fieldtype) {		
		if(inValidInput) {
			$scope.getSelectedFieldData('singleField', fieldid, fieldtype);
			showLoadingOverlay();
			setTimeout(
				function () {
					$scope.changeSelectText(panelid,subpanelid);
					$scope.resetfieldorder();				
					$scope.displayFieldsBasedOnCheckbox(downloadReport);
				}
				, 1000);
			hideLoadingOverlay();
		} else {
			alert("Please select the valid options from roster page");
		}
		
		$('.childpanelitem:checked').parents('.columngroup').addClass("check_bgcolor");
		$('.childpanelitem:not(:checked)').parents('.columngroup').removeClass("check_bgcolor");
	};
	
	$scope.changeSelectText = function (panelid, subpanelid)
	{
		var selectallpanelclass = 'staffPanel_' + panelid + '_SelectAll';	
		var selectallsubpanelclass = 'staffSubPanel_' + subpanelid + '_SelectAll';	
		var childid= 'staffPanel_' + panelid + '_SelectAll_Field';
		var subchildid= 'staffSubPanel_' + subpanelid + '_SelectAll_Field';	
		var allfieldcount = 0;
		var panelfieldcount = 0;
		var subpanelfieldcount = 0;	
		
		$('.childpanelitem').each(function(e,i) {
			if($(this).prop("checked") == false && $(this).closest('.attrItemdata_attr_Name').css('display') != 'none') {
				allfieldcount++;
				//break;
			}
		});		
		//console.log("allfieldcount : " + allfieldcount);
		if(allfieldcount > 0) {
			$('#staffPanel_SelectAll').html("Select All Fields");
			//$('.selectall_additionaltext').css('display','none');
		} else {
			$('#staffPanel_SelectAll').html("Select None");
			//$('.selectall_additionaltext').css('display','block');
		}
		
		$('.' + childid).each(function(e,i) {
			if($(this).is(':visible') && ($(this).attr("data-subpanelname") == "Default") && $(this).prop("checked") == false && $(this).closest('.columngroup').css('display') != 'none') {
				panelfieldcount++;		
				//break;
			}
		});
		
		$('.' + subchildid).each(function(e,i) {
			if($(this).is(':visible') && $(this).prop("checked") == false && $(this).closest('.columngroup').css('display') != 'none') {				
				subpanelfieldcount++;				
				//break;
			}
		});		
		//console.log("panelfieldcount : "+panelfieldcount+", subpanelfieldcount : "+subpanelfieldcount);
		if (panelfieldcount == 0) {					
			$('.' + selectallpanelclass).html("Select None");	
		} else if (panelfieldcount > 0 || subpanelfieldcount > 0)
		{
			$('.' + selectallpanelclass).html("Select All");
		}
		
		if(subpanelfieldcount > 0) {								
			$('.' + selectallsubpanelclass).html("Select All");	
		} else {
			$('.' + selectallsubpanelclass).html("Select None");	
		}
	}

	$scope.getSelectedFieldData = function(selectionType, selectedFieldId, selectedFieldType) {		
		var data = [];
		var fieldsArray = [];
		var selectedFieldType = [];			
		var fieldTypearr = [];
		var panelTypearr = [];		
		var subpanelNamearr = [];		
		var filterFields = "";
		var filterFieldtype = "";
		var filterOperators = "";
		var filterValues = "";
		var filterLogical = " ";		
		var filterValuesOption = "";
		var filterValueFieldId = "";
		var paneltype = "";
		var subpaneltype = "";		
		var fieldSelectionStatus = 0;
		
		var arrangefieldsby = $('.arrangefields:checked').val();
		var filtercount = parseInt($('.filtercount').val());
		var filterPattern = $('#filtervaluepattern').val();		
		var filterApplied = $('#filterApplied').val();
		fieldSelectionStatus = $('#childpanelitem_' + selectedFieldId).is(':checked');
		
		$('input[name="childpanelitem"]:checked').each(function(e,i){
			var fieldId = $(this).val();
			fieldsArray.push(fieldId);
			
			if(selectionType == 'panelFields') {
				fieldTypearr.push($(this).attr('data-fieldType'));
				panelTypearr.push($(this).attr('data-paneltype'));
				if($(this).attr('data-subpanelname') != 'Default') {
					subpanelNamearr.push('User');
				} else {
					subpanelNamearr.push('Default');
				}
			}		
		});	
		
		if(selectionType == 'panelFields') {
			fieldsArray.push($('input[data-fieldtype="userid"]').val());
			fieldTypearr.push('userid');
			panelTypearr.push('Standard');
			subpanelNamearr.push('Default');
		}
		
		data.push({
			"rosterOrganization": rosterOrganization
		});
		data.push({
			"staffList": $('#staffList').val()
		});
		data.push({
			"siteList": $('#siteList').val()
		});
		data.push({				
			"customfields": $('.customfields').val()
		});
		data.push({			
			"customfieldvalue": $('.customfieldvalue').val()
		});		
		data.push({			
			"customfieldvaluenames": $('.customfieldvaluenames').val()
		});
		data.push({
			"stafffields": fieldsArray.toString()
		});			
		data.push({		
			"selectionType": selectionType
		});		
		data.push({		
			"selectedFields": selectedFieldId
		});		
		data.push({		
			"selectedFieldType": selectedFieldType
		});			
				
		if(selectedFieldId == 0) {
			data.push({		
				"fieldTypearr": fieldTypearr.toString()
			});
			
			data.push({		
				"panelTypearr": panelTypearr.toString()
			});
			
			data.push({		
				"subpanelNamearr": subpanelNamearr.toString()
			});
		} else {
			data.push({		
				"fieldTypearr": $('#childpanelitem_' + selectedFieldId).attr('data-fieldtype')
			});
			
			data.push({		
				"panelTypearr": $('#childpanelitem_' + selectedFieldId).attr('data-paneltype')
			});
			
			if($('#childpanelitem_' + selectedFieldId).attr('data-subpanelname') != 'Default') {
				data.push({		
					"subpanelNamearr": "User"
				});
			} else {
				data.push({		
					"subpanelNamearr": "Default"
				});
			}
		}
		
		if(selectionType == 'addFilter' || selectionType == 'sortField' || selectionType == 'filterField' || (selectedFieldId == 0 && selectionType == 'panelFields')) {		   
		   fieldSelectionStatus = true;
		}		
		
		data.push({		
			"fieldSelectionStatus": fieldSelectionStatus
		});										
		
		if(selectionType == "filterField" || $('#filterApplied').val() == '1'){
			for(var i = 1; i<filtercount; i++) {	
				var filterby = $('option:selected', '.filter_field_' + i).val();	
				var panel = $('option:selected', '.filter_field_' + i).attr('data-paneltype');	
				var field = $('option:selected', '.filter_field_' + i).attr('data-fieldtype');
				var subpanel = $('option:selected', '.filter_field_' + i).attr('data-subpanelname');			
				operatorType = $('.filter_operators_' + i + ' option:selected').text();
				if(operatorType=='is only')operatorType = 'is';
				fieldvaluefilter = "";		
				if(operatorType == 'between' || operatorType == 'not between') {
					$('.filtervalue_' + i).each(function(){
						fieldvaluefilter += $(this).val() + ",";								  
					});
					fieldvaluefilter.substring(0, fieldvaluefilter.length-1);				
				} else {
					fieldvaluefilter = 	$('.filtervalue_' + i).val();
					if(fieldvaluefilter == '') {
						fieldvaluefilter = ' ';
					}
				}
				if(i>1) {
					filterLogical += $('option:selected', '.sel_action_' + i).text();
				}
				/*Sitemanage-176 : start*/
				if(field == 'cohort_name'){
					fieldvaluefilter= fieldvaluefilter.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;");
				}
        		/*sitemanage-176 : end*/
				filterFields += filterby + "~";
				paneltype += panel + "~";
				subpaneltype += subpanel + "~";
				filterFieldtype += field + "~";
				filterOperators += operatorType + "~";
				filterValues += fieldvaluefilter.replaceAll("~","&tilde;") + "~";	//MV-1877
				filterLogical += "~";
			}
		}
		
		data.push({
			"filterFields": filterFields
		});
		data.push({
			"filterFieldtypes": filterFieldtype
		});
		data.push({
			"filterOperators": filterOperators
		});
		data.push({
			"filterValues": filterValues
		});
		data.push({				
			"filterValuesOption": filterValuesOption
		});	
		data.push({				
			"filterValueFieldId": filterValueFieldId
		});	
		data.push({
			"filterLogical": filterLogical
		});
		data.push({			
			"paneltype": paneltype
		});
		data.push({			
			"subpaneltype": subpaneltype
		});
		data.push({				
			"filterApplied": $('#filterApplied').val()
		});
			
		data.push({		  
			"arrangefieldsby": arrangefieldsby
		});
		data.push({		  
			"sortcolumn": sortcolumn
		});
		data.push({		  
			"sorttype": sorttype
		});
		data.push({
			"filterPattern": filterPattern
		});	
		/*data.push({				
			"sessionvolunteerlist": $('#sessionvolunteerlist').val()
		});*/
							
		if(fieldSelectionStatus) {
			//$scope.resetfieldorder();			
			$scope.loadSelectedFieldResponse(data);
		}
	};	
	
	$scope.loadSelectedFieldResponse = function(data) {	
		var _current_time_cache = new Date().getTime();
		var formData = {};		
		data.forEach(function(obj) {
		   Object.entries(obj).forEach(function([key, value]) {
			  formData[key] = value;
		   });
		});
		
		$.ajax({
			type: "POST",		
			url: "index.cfm?event=staff.getStaffExportSelectedFieldValue&currenttimestamp=" + _current_time_cache,
			data: formData,
			dataType: "json",
			async: false,
			beforeSend: function() {								
				showWaitScreen();				
			},
			success: function(responseData) {	
			
				/* Start: For Display in Preview Table */				
				colCount = responseData.headers;				
				rowCount = responseData.data;
				userlistid = responseData.USERLISTID;
				/* End: For Display in Preview Table */
				
				/* Start: For CP Popup */
				resultUserIdList = responseData.RESULTUSERLISTID;	
				$('#resultUserIdList').val(resultUserIdList);
				resultUserStatus = responseData.RESULTUSERSTATUS;	
				$('#resultUserStatus').val(resultUserStatus);
				/* End: For CP Popup */
				
				/* Start: For Filter Value Validation */
				$scope.resultJSON = responseData.originalResult;	
				/* End: For Filter Value Validation */
				if(!fromSavedReport){
					$scope.resetfieldorder();	
				}
				iconEnable=responseData.iconEn; //MV-862
				$scope.displayFieldsBasedOnCheckbox(downloadReport,fromSavedReport);	
			},		
			complete: function() {				
				hideWaitScreen();								
			},
			error: function(data) {
				alert('oops mistake on server');
				status = false;
			}
		});
	};
	
	$scope.resetfieldorder = function () {
		$scope.fieldorder = [];
		$('input[name="childpanelitem"]:checked').each(function (e, i) {
			var panelId = $(this).attr('data-panelid');
			var fieldId = $(this).val();
			$scope.fieldorder.push(panelId + '_' + fieldId);
		});
		$scope.fieldcount = $scope.fieldorder.length;		
	};
	
	$scope.displayFieldsBasedOnCheckbox = function (downloadReport,fromSavedReport) {			
		$scope.gridOptions.columnDefs = [];
		$scope.gridOptions.data = [];
		var columnDefs = [];	
		var totalStaffCount = [];	
		$scope.fieldcount = $scope.fieldorder.length;		
		$timeout( function() {
			for (var colIndex = 0; colIndex < colCount.length; colIndex++) {
				var arrelement = colCount[colIndex].panelid + '_' + colCount[colIndex].id;					
				var panelId = colCount[colIndex].panelid;											
				var usertype = $("#currentusertype").val();	
				var permission = $("#editPermission").val();				
				if($scope.fieldorder.indexOf(arrelement) != -1) { 						
					var headerTemp;	
					var cellclass;					
					var cellTemp;
					var editCellTemp;
					var editCellClass = '';
					var pencilCellClass = '';
					var dispName;
					var wid;
					var fieldtype='string';				
					var type='string';						
					var subpanelid = colCount[colIndex].subpanelid;
					var isQualitative = colCount[colIndex].isQualitative;
					var agefield = colCount[colIndex].description;						
					var encodedColName = $scope.htmlEncode(colCount[colIndex].displayName);
					var encodedPanelName = $scope.htmlEncode(colCount[colIndex].panelname);
					if(colCount[colIndex].subpanelname!='Default'){
						var encodedSubpanelName = ': ' + $scope.htmlEncode(colCount[colIndex].subpanelname);
					}else{
						var encodedSubpanelName = '';
					}
					if(colCount[colIndex].subpanelname == 'Default'){
						dispName=colCount[colIndex].panelname;
					}else{
						dispName=colCount[colIndex].panelname + ": " +  colCount[colIndex].subpanelname;
					}
					
					if($scope.fieldcount == 2) {
						wid = 615;
					} else if ($scope.fieldcount == 3){
						wid = 410;
					} else if ($scope.fieldcount == 4){
						wid = 307;
					} else {
						wid = 246;
					}					
					
					headerTemp = '<div style="height:58px;" role="columnheader" ng-class="{ \'sortable\': sortable }"  ui-grid-one-bind-aria-labelledby-grid="col.uid + \'-header-text \' + col.uid + \'-sortdir-text\'" aria-sort="{{col.sort.direction == asc ? \'ascending\' : ( col.sort.direction == desc ? \'descending\' : (!col.sort.direction ? \'none\' : \'other\'))}}">' + '<div role="button" tabindex="0" class="ui-grid-cell-contents ui-grid-header-cell-primary-focus" col-index="renderIndex" title="TOOLTIP"';
					/*MV-2153:Start*/
					if(rosterOrganization != 'staffmember') {
						headerTemp += ' ng-click="grid.appScope.cellClickedSort(' +"'"+colCount[colIndex].name.trim()+"'"+')"';
					}else if(rosterOrganization == 'staffmember' && colCount[colIndex].fieldtype == "status") {
						headerTemp += ' ng-click="grid.appScope.cellClickedSort(' +"'"+colCount[colIndex].name.trim()+"'"+')"';
					}
					/*MV-2153:End*/	
					headerTemp += '>' + '<span  class="ui-grid-header-cell-label" ui-grid-one-bind-id-grid="col.uid + \'-header-text\'">';						
					headerTemp += encodedPanelName + encodedSubpanelName+'{{  CUSTOM_FILTERS }}</span>' + '</br><div style="float:left;margin-top:10px;color:#fff">'+encodedColName+'</div>';																
					headerTemp += '<span ui-grid-one-bind-id-grid="col.uid + \'-sortdir-text\'" ui-grid-visible="col.sort.direction"'+
					'aria-label="{{getSortDirectionAriaLabel()}}" style="float:left;margin-left: 5px;margin-top: 14px;"> <i id="' + colCount[colIndex].name.trim() + '" ng-class="{ \'ui-grid-icon-up-dir\': col.sort.direction == asc, \'ui-grid-icon-down-dir\':'+ 'col.sort.direction == desc, \'ui-grid-icon-blank\': !col.sort.direction }"'+
					'title="{{isSortPriorityVisible() ? i18n.headerCell.priority + \' \' + ( col.sort.priority + 1'+' )  : null}}"' + ' aria-hidden="true">&nbsp;&nbsp;</i>'+ '<sub ui-grid-visible="isSortPriorityVisible()" class="ui-grid-sort-priority-number">' + '{{col.sort.priority + 1}}</sub>' + '</span> </div>' + '<div role="button" tabindex="0" ui-grid-one-bind-id-grid="col.uid + \'-menu-button\'" ' + 'class="ui-grid-column-menu-button" ng-if="grid.options.enableColumnMenus && !col.isRowHeader  &&'+ 'col.colDef.enableColumnMenu !== false" ng-click="toggleMenu($event)" ng-class="{\'ui-grid-column-menu-button-last-col\': isLastCol}"'+
					'ui-grid-one-bind-aria-label="i18n.headerCell.aria.columnMenuButtonLabel" aria-haspopup="true">'+
					'<i class="ui-grid-icon-angle-down" aria-hidden="true"> &nbsp;</i></div>' + '<div ui-grid-filter></div>';
					/* MV-862 */
					if(colCount[colIndex].displayName == "Password Setup Status") {
						if(iconEnable == 1) {
							headerTemp +='<span ng-controller="exportStaffCtrl" ng-click="passwordSetupPopup()" style="position: absolute; left: 81%; top: 50%; webkit-transform: translate(-50%, -50%);transform: translate(-50%, -50%);"><img src="../../images/icons/mail2_24.gif"></span>';
						}
						else if(emailIcon == 1 && iconEnable == 2){
							headerTemp+='<span ng-controller="exportStaffCtrl" ng-click="passwordSetupPopup()" style="position: absolute; left: 81%; top: 50%; webkit-transform: translate(-50%, -50%);transform: translate(-50%, -50%);"><img src="../../images/icons/mail2_24.gif"></span>';
						}
					}
					headerTemp +='</div>';
					/* MV-862:End */
					cellclass='{{ row.entity.cellclass }}';
					
					if(colCount[colIndex].name.trim() == "fname" || colCount[colIndex].name.trim() == "lname") {						
						headerTemp += '';
					} else {									
						headerTemp += '<div class="delColumn" ng-controller="exportStaffCtrl"><div class="deletecolumn" ng-click="grid.appScope.removeColumn('+colCount[colIndex].panelid+','+"'"+colCount[colIndex].subpanelid+"'"+','+"'"+colCount[colIndex].id+"'"+')" style="float:right;" rel="' + colCount[colIndex].id + '"></div></div>';
					}					
					
					if(colCount[colIndex].name.trim() == "userid" || colCount[colIndex].name.trim() == "siteid" || colCount[colIndex].fieldtype == "passwordStatus" || (colCount[colIndex].fieldtype == "email" && colCount[colIndex].paneltype=='Standard' && colCount[colIndex].subpanelname == 'Default') || colCount[colIndex].fieldtype=='signdocument' || colCount[colIndex].fieldtype=='cohortid' || colCount[colIndex].fieldtype == 'status') {//Mv-862 //MV-2153
						/* Start: MV-2064(Added if condition ,else code already available) */
						if(colCount[colIndex].fieldtype=='signdocument') {
							editCellTemp = 'title="'+encodedColName.replace('"','&quot;')+'"';
						}else{
							editCellTemp = 'title="{{ COL_FIELD }}"';
						}
						/* End: MV-2064*/
					} else {
						if((usertype == 'submanager' && permission != 0)||(usertype == 'manager')){
							if(colCount[colIndex].fieldtype == "fileattachment") {
								editCellTemp = 'panelid="'+colCount[colIndex].panelid+'" panelname="'+encodedPanelName+'" paneltype="'+colCount[colIndex].paneltype+'" subpanelid="'+colCount[colIndex].subpanelid+'" subpanelname="'+colCount[colIndex].subpanelname+'" column="'+colCount[colIndex].name+'" columnvalue="{{ COL_FIELD }}" userid="{{ row.entity.userid }}" title="'+encodedColName.replace('"','&quot;')+'" fieldtype="'+ colCount[colIndex].fieldtype +'" fieldid="' + colCount[colIndex].id + '" isQualitative="' + colCount[colIndex].isQualitative + '" isrequired="' + colCount[colIndex].Required + '" fieldDescription="' + colCount[colIndex].description + '"';
							} else {
								editCellTemp = 'panelid="'+colCount[colIndex].panelid+'" panelname="'+encodedPanelName+'" paneltype="'+colCount[colIndex].paneltype+'" subpanelid="'+colCount[colIndex].subpanelid+'" subpanelname="'+colCount[colIndex].subpanelname+'" column="'+colCount[colIndex].name+'" columnvalue="{{ COL_FIELD }}" userid="{{ row.entity.userid }}" title="'+encodedColName.replace('"','&quot;')+'" fieldtype="'+ colCount[colIndex].fieldtype +'" fieldid="' + colCount[colIndex].id + '" isQualitative="' + colCount[colIndex].isQualitative + '" isrequired="' + colCount[colIndex].Required + '" fieldDescription="' + colCount[colIndex].description + '"';
							}
							editCellClass = cellclass + 'section';
							pencilCellClass = cellclass;
						}
					}
					cellTemp = '<div class="ngCellText ui-grid-cell-contents ng-binding ng-scope '+editCellClass+'"';					
					cellTemp += editCellTemp;					
					cellTemp +=  '>';											
					
					if(colCount[colIndex].name.trim() === "fname" || colCount[colIndex].name.trim() === "lname") {						
						cellTemp += '<span class="link" encuid="{{ row.entity.encuid }}" user="{{ row.entity.userid }}" style="float:left;overflow: hidden;position: absolute;text-overflow: ellipsis;white-space: nowrap;">{{ COL_FIELD }}</span>';
						
					} else if (colCount[colIndex].fieldtype === "fileattachment" || colCount[colIndex].fieldtype === "photo" || colCount[colIndex].fieldtype === "signdocument") {						
						cellTemp += '<span style="float:left;overflow: hidden;position: absolute;text-overflow: ellipsis;white-space: nowrap;"><div ng-bind-html="COL_FIELD | trusted"></div></span>';
					} else {	
						if(colCount[colIndex].fieldtype == 'date'){
							type=colCount[colIndex].fieldtype;
							if(agefield != 'undefined' && agefield != null && agefield != "" && agefield == "Current Age") {
								type='number';
							}
						} else if(colCount[colIndex].fieldtype == 'userid' || colCount[colIndex].fieldtype == 'number' || (colCount[colIndex].fieldtype=='select' && isQualitative == '0')) {
							type='number';
						} 
						
						cellTemp += '<span  style="float:left;overflow: hidden;position: absolute;text-overflow: ellipsis;white-space: nowrap;">{{ COL_FIELD }}</span>';
					}
					cellTemp += '</span>';					
					// Start:MS-539
					/* if (colCount[colIndex].fieldtype == 'status'){
						cellTemp += '<div class="' + pencilCellClass + '" ng-style="{\'float\': \'right\', \'cursor\': \'pointer\'}" ng-if="(' + window.userid + ' != row.entity.userid)" ' + editCellTemp + '></div>';
					} else { Commented For MV-2153 */
						cellTemp += '<div class="' + pencilCellClass + '" style="float:right;cursor:pointer;"' + editCellTemp + '></div>';
					// }
					// End:MS-539
					cellTemp += '</div>';
					
					var counterflag = 0;
					var columnmove=true;
					var freezecolumn=false; 
					if(colCount[colIndex].fieldtype == 'fname' || colCount[colIndex].fieldtype == 'lname') {
						columnmove = false;
						freezecolumn = true;
					}
					
					$scope.gridOptions.columnDefs.forEach(function(e,idx){
						if(e.name == colCount[colIndex].name){counterflag++;}
					});										
					
					if (counterflag == 0) {
						$scope.gridOptions.columnDefs.push({
							id:colCount[colIndex].id,												   
							name: colCount[colIndex].name,
							displayName:dispName,	
							enableColumnMenu: false,
							width: wid,	
							cellTemplate:cellTemp,
							headerCellTemplate:headerTemp,
							pinnedLeft:freezecolumn,
							enableColumnMoving:columnmove,
							panelid:colCount[colIndex].panelid,
							fieldid:colCount[colIndex].id,
							fieldtype:colCount[colIndex].fieldtype,
							fieldname:colCount[colIndex].displayName,
							pnlid_fid:colCount[colIndex].panelid+'_'+colCount[colIndex].id,
							type:type,							
							subpanelid: subpanelid,
							isQualitative: isQualitative,
							agefield: agefield							
						});
					}
					
				} //end if
			} //end for loop					
			if(downloadReport || fromSavedReport == 1){
				var newColumnDefs = [];
				$scope.fieldorder.forEach(function(e){
					$scope.gridOptions.columnDefs.filter(function(item){
						 if(e.indexOf(item.pnlid_fid) != -1){
							var pos = newColumnDefs.map(function(ee) { return ee.pnlid_fid; }).indexOf(item.pnlid_fid);
							if(pos == -1){
								newColumnDefs.push(item);
							}
						} else {
							return true;
						}
					});
				});			
				$scope.gridOptions.columnDefs = newColumnDefs;
				$scope.fieldcount = $scope.fieldorder.length;	
				if(downloadReport) {
					$timeout(function () {				
						$scope.exportToExcel();				
					});
				}
			}
			
		}); //end column timeout
		
		var data = [];
		/*MV-2153:Start*/				
		var columnname='';
		/*MV-2153:End*/
		$timeout(function() {										
			var view_data_as_list_array = [];
			if(typeof view_data_as_list != "undefined") {
				view_data_as_list = view_data_as_list.substring(1,view_data_as_list.length);							
				view_data_as_list_array = view_data_as_list.split("~");
			}	
				
			for (var rowIndex = 0; rowIndex < rowCount.length; rowIndex++) {
				var row = {};
				for (var colIndex = 0; colIndex < colCount.length; colIndex++) {									
					var val=colCount[colIndex].name;																				
					var panel_type = colCount[colIndex].subpanelname;
					var field_value = rowCount[rowIndex][val];					
					
					if (typeof field_value == "string") {
						field_value = field_value.toString().replace(/amp;/g,'').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"');									
						field_value = field_value.toString().replace(/\$comma\$/g,",").replace(/\$openbraces\$/g,"(");
					}					
																					 
					row[val] = field_value;			
					row['encuid'] = rowCount[rowIndex].encuid;
					row['userid'] = rowCount[rowIndex].userid;
					row['cellclass'] = rowCount[rowIndex].classname;
					/*MV-2153:Start*/
					if(colCount[colIndex].fieldtype=='status'){							
						columnname=colCount[colIndex].fieldtype;
					}
					/*MV-2153:End*/
				}//inner for loop			
				var staffId = row['userid'];					
				if(staffId != '' && totalStaffCount.indexOf(staffId) == -1) {
					totalStaffCount.push(staffId);
				}			
				data.push(row);								
			}//for loop
			$('#totalstaff').html('Total ' + staffAliasPlural + ': ' + totalStaffCount.length);
			$scope.gridOptions.data = data;				
		}); //End Row Timeout	
		/*MV-2153:Start(Block will execute when column='status' )*/
		setTimeout(function(){		
			
			if(rosterOrganization=='staffmember' && sortcolumn=='status' && sorttype=='desc'){						
				$('#' + columnname).removeClass('ui-grid-icon-blank');
				$('#' + columnname).removeClass('ui-grid-sort-asc');
				$('#' + columnname).addClass('ui-grid-sort-desc');
			}else if(rosterOrganization=='staffmember' && sortcolumn=='status' && sorttype=='asc'){				
				$('#' + columnname).removeClass('ui-grid-icon-blank');
				$('#' + columnname).removeClass('ui-grid-sort-desc');
				$('#' + columnname).addClass('ui-grid-sort-asc');
			}else if(sortcolumn=='status' && sorttype==''){				
				$('#' + columnname).removeClass('ui-grid-sort-desc');
				$('#' + columnname).removeClass('ui-grid-sort-asc');
				$('#' + columnname).addClass('ui-grid-icon-blank');
			}
		}, 100);
		/*MV-2153:End*/
	};
	
	$scope.cellClickedSort = function(columnname){
		showLoadingOverlay();
		var element =  document.getElementById(sortcolumn);
		if (typeof(element) != 'undefined' && element != null) {
			$("#" + sortcolumn).removeClass('ui-grid-icon-blank');
			$("#" + sortcolumn).removeClass('ui-grid-sort-asc');
			$("#" + sortcolumn).removeClass('ui-grid-sort-desc');
			if(sortcolumn != columnname) {
				sorttype = '';	
			}
		}
		sortcolumn = columnname;
		if(sorttype == 'asc') {
			/*MV-2153:Start*/		
			if(columnname=='status'){
				sorttype = '';
			}else{
				sorttype = 'desc';
				$("#" + columnname).removeClass('ui-grid-icon-blank');
				$("#" + columnname).removeClass('ui-grid-sort-asc');
				$("#" + columnname).addClass('ui-grid-sort-desc');
			}
			/*MV-2153:End*/		
		} else if(sorttype == 'desc') {
			/*MV-2153:Start*/		
			if(columnname=='status'){
				sorttype = 'asc';
			}else{
				sorttype = '';
				$("#" + columnname).removeClass('ui-grid-sort-desc');
				$("#" + columnname).removeClass('ui-grid-sort-asc');
				$("#" + columnname).addClass('ui-grid-icon-blank');
			}
			/*MV-2153:End*/		
		} else {
			/*MV-2153:Start*/			
			if(columnname=='status'){
				sorttype = 'desc';				
			}else{
				sorttype = 'asc';
				$("#" + columnname).removeClass('ui-grid-icon-blank');
				$("#" + columnname).removeClass('ui-grid-sort-desc');
				$("#" + columnname).addClass('ui-grid-sort-asc');
			}
			/*MV-2153:End*/		
		}		
		hideLoadingOverlay();
		$scope.getSelectedFieldData('sortField',0,'');
		
	};
	
	$scope.removeColumn = function (panelid, subpanelid, fieldId) {		 
		$scope.removeFieldOrder.push(panelid+"_"+fieldId);
		$("#childpanelitem_" + fieldId).prop('checked', false);
		$scope.resetfieldorder();
		$('.childpanelitem:not(:checked)').parents('.columngroup').removeClass("check_bgcolor");
		selectedarrayorder = [];
		$scope.displayFieldsBasedOnCheckbox(false);
	}
		
	$scope.saveOrder = function() {		
		var state = $scope.gridApi.saveState.save();
		$scope.state = state;		
		var fieldOrder = [];		
		$scope.fieldOrder = [];						
		var fnameId = $('input[data-fieldtype="fname"]').attr('id');
		var fname_pfid = $('#'+ fnameId).attr('data-panelid') + '_' +  $('#'+ fnameId).attr('data-fieldid');
		$scope.fieldOrder.push(fname_pfid); // First Name Column Should always be at First Position
		var columnDefs = $scope.gridOptions.columnDefs;
		for (var i = 0; i < state.columns.length; i++) {
			var fieldNameId = state.columns[i].name;
			if(fieldNameId != 'fname') {
				for (var j = 0; j < columnDefs.length; j++) {
					var columnNameId = columnDefs[j].name;				
					if(fieldNameId == columnNameId) {	
						var pnl_fid = columnDefs[j].pnlid_fid;										
						$scope.fieldOrder.push(pnl_fid);
					}	
				}
			}
		}
		
		/*for (var i = 0; i < state.columns.length; i++) {
			var fieldid=state.columns[i].name;			
			$scope.fieldOrder.push(fieldid);			
		}*/
		
		$("#fieldsortorder").val($scope.fieldOrder);
		$("#setFieldOrder").val('1');
	}
	
	var panelText="";
	$scope.selectPanelAllFields = function (panelid,subpanelid) {   
		var anchor_class = 'staffPanel_' + panelid + '_SelectAll';
		var field_class = anchor_class + "_Field";
		var archived_StaffFields = '' ; /* MS-493*/
		showLoadingOverlay();
		if($('.' + anchor_class).html() == 'Select All') { 
			panelText = $('.' + anchor_class).html();
			$('.'+ anchor_class).html("Select None");						
			$('.'+ field_class).prop("checked", true);						
			$("a[name^='"+anchor_class+"']").html("Select None");
			$('.'+ field_class).closest('.columngroup').addClass("check_bgcolor");
			if($('.archived_fields').attr('rel') == 0) 
			{
				$('.HideField').find('input[type=checkbox]:checked').prop('checked',false);
				$("input[id^='childpanelitem_']").closest('.HideField').removeClass("check_bgcolor"); 
				archived_StaffFields = $('.HideField').find('input[type=checkbox]').length;/* MS-493*/
			}
		} else {
			$('.'+ anchor_class).html("Select All");						
			$('.'+ field_class).prop("checked", false);						
			$("a[name^='"+anchor_class+"']").html("Select All");
			$('.'+ field_class).closest('.columngroup').removeClass("check_bgcolor");
			$('.check_required').prop("checked", true);
		}
		/* Start :: MS-493*/
		var total_checked= $("input[id^='childpanelitem_']").length;
		if($('.archived_fields').attr('rel') == 0){
			total_checked = total_checked - archived_StaffFields;
		}
		var checked = $("input[id^='childpanelitem_']:checked").length;
		if(checked == total_checked){
			$("#staffPanel_SelectAll").html("Select None");
		}
		if(total_checked > checked){
			$("#staffPanel_SelectAll").html("Select All Fields");
		}
		/* End :: MS-493*/	
		setTimeout(
			function(){				
				$scope.resetfieldorder();				
				$scope.getSelectedFieldData('panelFields',0,'');
			}
		,10);
		hideLoadingOverlay();
	};
	
	var subPanelText="";
	$scope.selectSubPanelAllFields = function(panelid,subpanelid) {   
		var anchor_class = 'staffSubPanel_' + subpanelid + '_SelectAll';
		var field_class = anchor_class + "_Field";
		var archived_StaffFields = '' ;/* MS-493*/	
		showLoadingOverlay();
		if($('.' + anchor_class).html() == 'Select All') { 
			subPanelText = $('.' + anchor_class).html();
			$('.'+ anchor_class).html("Select None");						
			$('.'+ field_class).prop("checked", true);						
			$('.'+ field_class).closest('.columngroup').addClass("check_bgcolor");
			if($('.archived_fields').attr('rel') == 0) {
				$('.HideField').find('input[type=checkbox]:checked').prop('checked',false);
				$("input[id^='childpanelitem_']").closest('.HideField').removeClass("check_bgcolor"); 
				archived_StaffFields = $('.HideField').find('input[type=checkbox]').length;/* MS-493*/
			}
		} else {
			$('.'+ anchor_class).html("Select All");						
			$('.'+ field_class).prop("checked", false);					
			$('.'+ field_class).closest('.columngroup').removeClass("check_bgcolor");
		}
		/* Start :: MS-493*/
		var total_checked= $("input[id^='childpanelitem_']").length;
		if($('.archived_fields').attr('rel') == 0){
			total_checked = total_checked - archived_StaffFields;
		}
		var checked = $("input[id^='childpanelitem_']:checked").length;
		if(checked == total_checked){
			$("#staffPanel_SelectAll").html("Select None");
		}
		if(total_checked > checked){
			$("#staffPanel_SelectAll").html("Select All Fields");
		}
		/* End :: MS-493*/
		
		setTimeout(
			function(){				
				$scope.resetfieldorder();				
				$scope.getSelectedFieldData('panelFields',0,'');
			}
		,10);
		hideLoadingOverlay();
	};
	
	$scope.selectAllFields = function () {   
		showLoadingOverlay();
		if($('#staffPanel_SelectAll').html() == 'Select All Fields') 
		{
			$('#staffPanel_SelectAll').html("Select None");
			$("a[id^='staffPanel_']").html("Select None");
			$("a[id^='staffSubPanel_']").html("Select None");
			$("input[id^='childpanelitem_']").prop("checked", true);
			$("input[id^='childpanelitem_']").closest('.columngroup').addClass("check_bgcolor"); 
			if($('.archived_fields').attr('rel') == 0) 
			{
				$('.HideField').find('input[type=checkbox]:checked').prop('checked',false);
				$("input[id^='childpanelitem_']").closest('.HideField').removeClass("check_bgcolor"); 
			}
		}
		else
		{
			$("a[id^='staffPanel_']").html("Select All");/* MS-493*/
			$("a[id^='staffSubPanel_']").html("Select All");/* MS-493*/
			$('#staffPanel_SelectAll').html("Select All Fields");/* MS-493*/
			$("input[id^='childpanelitem_']").prop("checked", false);
			$("input[id^='childpanelitem_']").closest('.columngroup').removeClass("check_bgcolor"); 
			$('.check_required').prop("checked", true);
	
		}	
		
		setTimeout(
			function(){				
				$scope.resetfieldorder();				
				$scope.getSelectedFieldData('panelFields',0,'');
			}
		,10);
		hideLoadingOverlay();
	};
	
	$scope.addFilter = function (fieldFilter,updatefilepattern,displayFields) {		
		updateFilterSection(fieldFilter,updatefilepattern,displayFields,$compile,$scope);
		if ($('#archived_fields').html() === 'Show Archived Fields')
		{
			setTimeout(function (){
				$('.HideArchivedField').attr('disabled',true);
				$('.filter_field').select2();  
			},1000);
		}
		else
		{
			setTimeout(function (){
			$('.HideArchivedField').attr('disabled',false);
			$('.filter_field').select2();},1000);
		}
	};
	
	$scope.removeFilter = function (fieldFilter) {	
		
		showLoadingOverlay();
		if($('.btn_cancel_filter_' + fieldFilter).html() == 'Remove') {
				var patternButtons = '<div class="staff_fields tmsht-widt-100 pattern" id="editablefilterpattern"><label class="pull-left"><a id="editfilterpattern" class="editfilterpattern" ng-click="editPattern()">Edit Pattern</a></label><div class="help_tooltip"><img src="../../images/icons/question_icon_bw.gif" onmouseover="this.src=\'../../images/icons/question_icon.gif\'" onmouseout="this.src=\'../../images/icons/question_icon_bw.gif\'" border="0" alt=""/><span class="tooltiptext help_tooltip-bottom">To edit filter pattern, click on Edit Pattern and then save.</span></div></div>';	
				var oldPattern = $('#hiddenpattern').val();								

				if($('select[name="sel_action"]').prop("disabled")==false){
					$('#filtervaluepattern').val(oldPattern);
					$('#removeFilterFlage').val('0');
				}
				else{
					$('#removeFilterFlage').val('1');
				}
				
				$('#filtervaluepattern').attr('disabled',true);
				$('#editablefilterpattern').html('');
				$('#editablefilterpattern').remove();	
				
				var temp = $compile(patternButtons)($scope);
				angular.element(document.getElementById('filterpattern')).append(temp);		
				
				var filtercount1 = parseInt($('.filtercount').val());
				var removedFilter = fieldFilter;			
				if(filtercount1 > 1 && filtercount1 != fieldFilter) {
					filtercount1 = filtercount1 - 1;
					$('.filtercount').val(filtercount1);
					$( ".subfilter_" + fieldFilter).html('');
					$( ".subfilter_" + fieldFilter).remove();					
					var j=removedFilter + 1;
					var k=filtercount1+1;					
					for (i = j; i <=k; i++){
						var filterno = parseInt($('.filtercount_' + i).attr('rel'));
						var newFilterNo = filterno - 1;
						$('.filtercount_' + i).html("<span style='line-height:21px'>" + newFilterNo + "</span>");
						$('.filtercount_' + i).attr('rel',newFilterNo);
						$('.filtercount_' + i).addClass('filtercount_' + newFilterNo);
						$('.filtercount_' + i).removeClass('filtercount_' + i);	
						$('.logical_' + i).addClass('logical_' + newFilterNo);
						$('.logical_' + i).removeClass('logical_' + i);
						$('.sel_action_' + i).addClass('sel_action_' + newFilterNo);
						$('.sel_action_' + i).removeClass('sel_action_' + i);	
						$('.filter_field_' + i).attr('data-count',newFilterNo);
						$('.filter_field_' + i).addClass('filter_field_' + newFilterNo);
						$('.filter_field_' + i).removeClass('filter_field_' + i);	
						$('.field_operators_' + i).addClass('field_operators_' + newFilterNo);
						$('.field_operators_' + i).removeClass('field_operators_' + i);
						$('.filter_operators_' + i).attr('data-count',newFilterNo);
						$('.filter_operators_' + i).addClass('filter_operators_' + newFilterNo);
						$('.filter_operators_' + i).removeClass('filter_operators_' + i);
						$('.filter_operators_' + newFilterNo).attr('name','filter_operators_' + newFilterNo);

						$(".filterinput_" + i).find(".datelinkSingle").attr('for','datelink_' + newFilterNo);
						$(".filterinput_" + i).find(".datelink1").attr('for','datelink1_' + newFilterNo);
						$(".filterinput_" + i).find(".datelink2").attr('for','datelink2_' + newFilterNo);
						$('.filterinput_' + i).addClass('filterinput_' + newFilterNo);
						$('.filterinput_' + i).removeClass('filterinput_' + i);

						$("#datelink_" + i).attr('id','datelink_' + newFilterNo);
						$("#datelink1_" + i).attr('id','datelink1_' + newFilterNo);
						$("#datelink2_" + i).attr('id','datelink2_' + newFilterNo);
						$('.filtervalue_' + i).attr('rel',newFilterNo);
						$('.filtervalue_' + i).addClass('filtervalue_' + newFilterNo);
						$('.filtervalue_' + i).removeClass('filtervalue_' + i);
						$('.filter_icon_' + i).addClass('filter_icon_' + newFilterNo);
						$('.filter_icon_' + i).removeClass('filter_icon_' + i);
						$('.search_magnifier_' + i).attr('rel',newFilterNo);
						$('.search_magnifier_' + i).addClass('search_magnifier_' + newFilterNo);
						$('.search_magnifier_' + i).removeClass('search_magnifier_' + i);
						
						if(document.getElementById('errormsg_' + i)!=null) {
							document.getElementById('errormsg_' + i).id = 'errormsg_' + newFilterNo;
						}
						
						$('.subfilter_' + i).addClass('subfilter_' + newFilterNo);
						$('.subfilter_' + i).attr('id','subfilter_' + newFilterNo);
						$('.subfilter_' + i).removeClass('subfilter_' + i);	
						
						$( ".filterButtons_" + i).html('');
						$( ".filterButtons_" + i).remove();
						if (i < filtercount1 + 1) {
							var filterButtons = "<div style='float:right; padding-right:5px;'><div id='filterButtons_" + newFilterNo + "' class='filterButtons_" + newFilterNo + "' style='margin-top:7px'><div class='buttonBlock pull-left filter_btn_box' style='width:54px; text-align:left !important;margin-left: 0px !important;'><a class='margin-left-6 filter_add_btn btn_add_filter btn_add_filter_" + newFilterNo + "'  name='Action' rel='"+ newFilterNo +"' ng-click='addFilter(" + newFilterNo + ",1,false)'>Edit</a></div><div class='buttonBlock pull-left filter_btn_box' style='width:55px;text-align: left !important; margin-right: 5px; margin-left: 0px !important;'><a class='filter_remove_btn btn_cancel_filter btn_cancel_filter_" + newFilterNo + "'  name='Action' rel='" + newFilterNo + "' ng-click='removeFilter(" + newFilterNo + ")'>Remove</a></div></div></div>";//ASSNS-656
						} else {
							var filterButtons = "<div style='float:right; padding-right:5px;'><div id='filterButtons_" + newFilterNo + "' class='filterButtons_" + newFilterNo + "' style='margin-top:7px'><div class='buttonBlock pull-left filter_btn_box' style='width:54px; text-align:left !important;margin-left: 0px !important;'><a class='margin-left-6 filter_add_btn btn_add_filter btn_add_filter_" + newFilterNo + "'  name='Action' rel='"+ newFilterNo +"' ng-click='addFilter(" + newFilterNo + ",1,false)'>Add</a></div><div class='buttonBlock pull-left filter_btn_box' style='width:55px;text-align: left !important; margin-right: 5px; margin-left: 0px !important;'><a class='filter_remove_btn btn_cancel_filter btn_cancel_filter_" + newFilterNo + "'  name='Action' rel='" + newFilterNo + "' ng-click='removeFilter(" + newFilterNo + ")'>Cancel</a></div></div></div>";//ASSNS-656
						}
						var temp = $compile(filterButtons)($scope);
						angular.element(document.getElementById('subfilter_' + newFilterNo)).append(temp);				
					}								
				}
				
				filtercount2 = parseInt($('.filtercount').val());		
				if(filtercount2 == 1) {					
					$('#filtervaluepattern').val('');
					$('.filterpattern').css('display','none');
					$('#clearfilter').css('display','none');
					$('#btn_apply_filter').prop("disabled", true)
					$('.errormsg_class').remove(); //Added for ASSNS-656	
					$('.filtercount_'+ fieldFilter).addClass('padding-left-10');
					$('.filtercount_' + fieldFilter).html('');	
					$('.filtercount_' + fieldFilter).css('display','none');
					$('.sel_action_' + fieldFilter).remove('');
					$('.filter_field_' + fieldFilter).addClass('tmsht-widt-215');
					$('.filter_field_' + fieldFilter).removeClass('tmsht-widt-134');
					$('.filtervalue_' + fieldFilter).addClass('tmsht-widt-161');
					$('.filtervalue_' + fieldFilter).removeClass('tmsht-widt-134');
					$('.ffilterby').removeClass('text-right');
					$('.fOperator').removeClass('text-right');
					$('.fValue').removeClass('text-right');									
					$('.filterbylable').removeClass('margin-right-63');
					$('.operatorlabel').removeClass('margin-right-63');
					$('.valuelabel').removeClass('margin-right-102');	
					
					//$('.filter_field_' + fieldFilter).select2('destroy');	
					$('.filterOperator_' + fieldFilter).html('');		
					$('.filter_field_' + fieldFilter +' option[value="0"]').attr('selected', true);
					$('.filter_field_' + fieldFilter).trigger("change");	
					if($('#archived_fields').html() === 'Show Archived Fields') {
						$('.HideArchivedField').attr('disabled',true);						
					} else {
						$('.HideArchivedField').attr('disabled',false);						
					}
					$('.filter_field_' + fieldFilter).select2();
					
					fromApplyfilterPublic = false;
					iconEnable = 2; //MV-862
					//if($('#filterApplied').val() == 1) {
						$('#filterApplied').val('0');
						$scope.fetchFieldsData(false);						
					//}
				} else {		
					if($('select[name="sel_action"]').prop("disabled") == false)
						$scope.updateFilterPattern();		
				}
				
				if(filtercount2 > 1) {
					$('.sel_action_1').html('&nbsp;');		
					$('.filterpattern').css('display','block');
				}				
		} else {
			var filtercount1 = parseInt($('.filtercount').val());	
			if(fieldFilter == 1) {
				$('.filterpattern').css('display','none');
				$('#btn_apply_filter').prop("disabled", true);
			}
			if($("#editpatternflage").val() == 0) {					
				if(filtercount1>1) {
					$('.logical_' + fieldFilter + ' option[value="1"]').attr('selected', true);				
				}
				$('.filter_field_' + fieldFilter + ' option[value="0"]').attr('selected', true);
				
				$('.filter_field_' + fieldFilter).select2();
				$('.filter_field_' + fieldFilter).val('0').change();
				$(".filterOperator_" + fieldFilter).html('');
				$(".filtervalue_" + fieldFilter).val('');
				$('.search_magnifier_' + fieldFilter).hide();
				if(fieldFilter > 1){
					$('.filterpattern').css('display','block'); 
				}				
			}			
		}	
		hideLoadingOverlay();
	};
	
	
	$scope.clearfilters = function (rel) {		
		showLoadingOverlay();
		var filtercount = parseInt($('.filtercount').val());		
		for(i=2;i<=filtercount;i++) {
			$('#subfilter_' + i).remove();
		}
		$('.filtercount').val('1');
		$('#filtervaluepattern').val('');
		$('.filterpattern').css('display','none');
		$('#clearfilter').css('display','none');
		$('#btn_apply_filter').prop("disabled", true)	
		$('.filtercount_1').addClass('padding-left-10');
		$('.filtercount_1').html('');	
		$('.filtercount_1').css('display','none');
		$('.sel_action_1').remove('');
		$('.filter_field_1').addClass('tmsht-widt-215');
		$('.filter_field_1').removeClass('tmsht-widt-134');
		$('.filtervalue_1').addClass('tmsht-widt-161');
		$('.filtervalue_1').removeClass('tmsht-widt-134');
		$('.filtervalue_1').val('');
		$('.ffilterby').removeClass('text-right');
		$('.fOperator').removeClass('text-right');
		$('.fValue').removeClass('text-right');									
		$('.filterbylable').removeClass('margin-right-63');
		$('.operatorlabel').removeClass('margin-right-63');
		$('.valuelabel').removeClass('margin-right-102');	
		$('.btn_add_filter_1').html('Add');
		$('.btn_cancel_filter_1').html('Cancel');		
		$('.filter_field_1').select2('destroy');	
		$('.filterOperator_1').html('');		
		$('.filter_field_1').val('0');
		$('.filter_field_1').trigger("change");	
		if($('#archived_fields').html() === 'Show Archived Fields') {
			$('.HideArchivedField').attr('disabled',true);			
		} else {
			$('.HideArchivedField').attr('disabled',false);			
		}		
		$('.filter_field_1').select2();
    
		iconEnable = 2; //MV-862		
		$('#btn_apply_filter').prop("disabled", true); // SiteManage-285
		
		//if($('#filterApplied').val() == 1) {
			$('#filterApplied').val('0');
			$scope.fetchFieldsData(false);			
		//}
		hideLoadingOverlay();
	};
	
	$scope.updateFilterPattern = function() {
		var filtervaluepattern = "(1)";
		var filtercount = $('.filtercount').val();
		for (i = 2; i < filtercount; i++) {
			var filterjoin = $('option:selected', '.logical_' + i).text();
			filtervaluepattern = "(" + filtervaluepattern;
			filtervaluepattern +=  " " + filterjoin + " " + i + ")";			 
		}		
		$('#filtervaluepattern').val(filtervaluepattern);
		$('#patternforrestore').val(filtervaluepattern);
	}
	
	$scope.editPattern = function () {		
		var patternButtons = "<div class='pattern pull-left' id='editablefilterpattern' style='padding-left:3px;margin-top:7px;'><div class='buttonBlock pull-left undopattern' style='width:auto;display:none;margin-right:8px;'><a class='undopattern' id='undopattern' ng-click='undoPattern()'>Undo</a></div><div class='buttonBlock pull-left' style='width:auto;'><a class='removepattern' id='removepattern' ng-click='removeCustomPattern()'>Remove</a></div></div>";
		
		
		var currentPattern = $('#filtervaluepattern').val();	
		$('#hiddenpattern').val(currentPattern);
		$('#filtervaluepattern').attr('disabled',false);
		$('select[name="sel_action"]').attr('disabled', true);
		$('select[name="sel_action"]').val('');
		$('#editablefilterpattern').html('');
		$('#editablefilterpattern').remove();	
		var temp = $compile(patternButtons)($scope);
		angular.element(document.getElementById('filterpattern')).append(temp);
	};
	
	$scope.savePattern = function () {
		var checkPattern = validateFilterPattern();
		if(checkPattern) {
			var patternButtons = '<div class="staff_fields tmsht-widt-100 pattern" id="editablefilterpattern"><label class="pull-left"><a id="editfilterpattern" class="editfilterpattern" ng-click="editPattern()">Edit Pattern</a></label><div class="help_tooltip"><img src="../../images/icons/question_icon_bw.gif" onmouseover="this.src=\'../../images/icons/question_icon.gif\'" onmouseout="this.src=\'../../images/icons/question_icon_bw.gif\'" border="0" alt=""/><span class="tooltiptext help_tooltip-bottom">To edit filter pattern, click on Edit Pattern and then save.</span></div></div>';				
			$('#filtervaluepattern').attr('disabled',true);
			$('#editablefilterpattern').html('');
			$('#editablefilterpattern').remove();	
			var temp = $compile(patternButtons)($scope);
			var oldPattern = $('#hiddenpattern').val();
			var currentPattern = $('#filtervaluepattern').val().trim();			
			angular.element(document.getElementById('filterpattern')).append(temp);	
			showLoadingOverlay();
			if (oldPattern != currentPattern) {
				currentPattern = currentPattern.replace(/and/ig,'AND');
				currentPattern = currentPattern.replace(/or/ig,'OR');
				$('#filtervaluepattern').val(currentPattern);				
			}			
			hideLoadingOverlay();	
		} 
    /*else { commented for MV-1885
			var patternButtons = '<div class="staff_fields tmsht-widt-100 pattern" id="editablefilterpattern"><label class="pull-left"><a id="editfilterpattern" class="editfilterpattern" ng-click="editPattern()">Edit Pattern</a></label><div class="help_tooltip help_tooltip2"><img src="../../images/icons/question_icon_bw.gif" onmouseover="this.src=\'../../images/icons/question_icon.gif\'" onmouseout="this.src=\'../../images/icons/question_icon_bw.gif\'" border="0" alt=""/><span class="tooltiptext help_tooltip-bottom">To edit filter pattern, click on Edit Pattern and then save.</span></div></div>';				
			$('#filtervaluepattern').attr('disabled',true);
			$('#editablefilterpattern').html('');
			$('#editablefilterpattern').remove();
			var temp = $compile(patternButtons)($scope);
			angular.element(document.getElementById('filterpattern')).append(temp);
			hideLoadingOverlay();
		}*/
		return checkPattern;
	};
	
	$scope.undoPattern = function () {
		$('#filtervaluepattern').val($('#hiddenpattern').val());
		$('#undopattern').hide();
	};
	
	$scope.removeCustomPattern = function () {
		var patternButtons = '<div class="staff_fields pattern pull-left" id="editablefilterpattern"><label class="pull-left"><a id="editfilterpattern" class="editfilterpattern" ng-click="editPattern()">Edit Pattern</a></label><div class="help_tooltip help_tooltip2"><img src="../../images/icons/question_icon_bw.gif" onmouseover="this.src=\'../../images/icons/question_icon.gif\'" onmouseout="this.src=\'../../images/icons/question_icon_bw.gif\'" border="0" alt=""/><span class="tooltiptext help_tooltip-bottom">To edit filter pattern, click on Edit Pattern and then save.</span></div></div>';
			
		if($('#editpatternflage').val() != 1){
			$('select[name="sel_action"]').prop("disabled",false);
			pattern = $('#patternforrestore').val()
			pattern = pattern.replace(/and/ig,'&&');
			pattern = pattern.replace(/or/ig,'||');
			var operatorsInString = get_logical(pattern);
			var filterIndex = 2;
			if(operatorsInString != null) {
				$('select[name="sel_action"]').val('1');
				for(i=0; i<=operatorsInString.length; i++) {					
					var htmldiv = "<select class='margin-top-5 logical_width pull-right margin-right-5 logical logical_"+ filterIndex + "'  name='sel_action' style='margin-left:18px;'>";
					if(operatorsInString[i] == '&&') {									
						htmldiv = htmldiv + "<option value='1' selected>AND</option><option value='2'>OR</option>";				
					} else if (operatorsInString[i] == '||') {						
						htmldiv = htmldiv + "<option value='1' >AND</option><option value='2' selected>OR</option>";				
					} else {
						htmldiv = htmldiv + "<option value='1' selected>AND</option><option value='2'>OR</option>";
					}
					htmldiv = htmldiv + "</select>";
					$('.sel_action_' + filterIndex).html(htmldiv);
					filterIndex++;
				}								
			}
			else{
				var filtercountoperator = parseInt($('.filtercount').val());
				if(filtercountoperator > 2) {
					for(var k=2;k<=filtercountoperator;k++) {
						var htmldiv = "<select class='margin-top-5 logical_width pull-right margin-right-5 logical logical_"+ k + "'  name='sel_action' style='margin-left:18px;'>";					
						htmldiv = htmldiv + "<option value='1' selected>AND</option><option value='2'>OR</option>";
						htmldiv = htmldiv + "</select>";
						$('.sel_action_' + k).html(htmldiv);							
					}
				} else {
					var htmldiv = "<select class='margin-top-5 logical_width pull-right margin-right-5 logical logical_"+ filterIndex + "'  name='sel_action' style='margin-left:18px;'>";					
					htmldiv = htmldiv + "<option value='1' selected>AND</option><option value='2'>OR</option>";
					htmldiv = htmldiv + "</select>";
					$('.sel_action_' + filterIndex).html(htmldiv);
				}
			}
			if($('#removeFilterFlage').val()==1){
				$scope.updateFilterPattern();	
			}
		}
		$('#filtervaluepattern').val($('#patternforrestore').val());
		$('#filtervaluepattern').attr('disabled', true);
		$('#editablefilterpattern').html('');
		$('#editablefilterpattern').remove();
		var temp = $compile(patternButtons)($scope);
		angular.element(document.getElementById('filterpattern')).append(temp);
	};
		
	$scope.cancelPattern = function () {
		var patternButtons = '<div class="staff_fields tmsht-widt-100 pattern" id="editablefilterpattern"><label class="pull-left"><a id="editfilterpattern" class="editfilterpattern" ng-click="editPattern()">Edit Pattern</a></label><div class="help_tooltip help_tooltip2"><img src="../../images/icons/question_icon_bw.gif" onmouseover="this.src=\'../../images/icons/question_icon.gif\'" onmouseout="this.src=\'../../images/icons/question_icon_bw.gif\'" border="0" alt=""/><span class="tooltiptext help_tooltip-bottom">To edit filter pattern, click on Edit Pattern and then save.</span></div></div>';	
		var oldPattern = $('#hiddenpattern').val();	
		$('#filtervaluepattern').val(oldPattern);
		$('#filtervaluepattern').attr('disabled',true);
		$('#editablefilterpattern').html('');
		$('#editablefilterpattern').remove();	
		var temp = $compile(patternButtons)($scope);
		angular.element(document.getElementById('filterpattern')).append(temp);		
	};
		
	$scope.arrangeFields = function () {		
		var checkedFieldId = $("input[name='childpanelitem']:checked").val();
		var checkedFieldType = $("input[name='childpanelitem']:checked").attr('data-fieldtype');

		/* start :: MV-1823 */
		var appliedFCount = $(".filtercount").val();
		var msg = "";
		if(appliedFCount > 1){
			msg = validateFilters();
		}
		var currentArrangments = $("#currentArrangeField").val();
		if(msg != "" && msg == 'invalid pattern') {
			$('input[name="arrangefields"][value="'+currentArrangments+'"]').prop('checked', true);	
			return false;
		} else if (msg != "" && msg != 'invalid pattern') {						
			$('input[name="arrangefields"][value="'+currentArrangments+'"]').prop('checked', true);	
			alert(msg);
			return false;		
		} else if (appliedFCount > 1 && $('#btn_apply_filter').prop('disabled') == true) {
			$('input[name="arrangefields"][value="'+currentArrangments+'"]').prop('checked', true);	
			alert('Please update filter value.');
			return false;
		} else {
			$('#currentArrangeField').val($(".arrangefields:checked").val());

			$scope.resetTable();			
			$scope.getSelectedFieldData('singleField',checkedFieldId,checkedFieldType);
		}
		/* End :: MV-1823 */
	};
	
	$scope.applyfilter = function(){		
		/*var validationstatus = $scope.savePattern();
		if(validationstatus){
			var filtercount = parseInt($('.filtercount').val());		
			for(var rel=1; rel < filtercount; rel++) {
				var button = $('.btn_add_filter_' + rel).html();
				var filterby = $('option:selected', '.filter_field_' + rel).val();	
				var filterbySelected = $('option:selected', '.filter_field_' + rel).attr('data-fieldtype');						
				var fieldvalueclass = 'btn_add_filter_' + rel;
				var operatorType = $('.filter_operators_' + rel + ' option:selected').text();
				if(operatorType=='is only')operatorType = 'is';
				var fieldvaluefilter = 	$('.filtervalue_' + rel).val();				
				var msg = "";
				if(filterby == 0) {
					msg += "Please select filter by.\n";		
				} 	
				if(operatorType != "is empty" && operatorType != "isn't empty" && operatorType != "today" && operatorType != "tomorrow" && operatorType != "tomorrow onwards"  && operatorType != "yesterday" && operatorType != "until yesterday" && operatorType != "last month"  && operatorType != "current month" && operatorType != "next month"  && operatorType != "last week" && operatorType != "current week" && operatorType != "next week" && operatorType != "is fully executed" && operatorType != "is waiting for supervisor signature" && operatorType != "is waiting for " + staffAliasLcase + " signature" && operatorType != "is waiting for director signature" && operatorType != "is waiting for " + volunteerAliasLcase + " signature" && operatorType != "has no signatures") {
						if($('option:selected', '.filter_field_' + rel).attr('data-field-type') == 'date') {
							if((operatorType == "between" || operatorType == "not between") && (($('#datelink1_' + rel).val() != 'undefined' && $('#datelink1_' + rel).val() == "") || ($('#datelink2_' + rel).val() != 'undefined' && $('#datelink2_' + rel).val() == ""))) {
								msg += "Please provide both between date filter value.";	
							} else {
								if(typeof fieldvaluefilter != 'undefined' && fieldvaluefilter.trim() == "") {
									msg += "Please provide date filter value.";
								}
							}			
						}else {							
							if(typeof fieldvaluefilter != 'undefined' && fieldvaluefilter.trim() == "") {
								msg += "Please provide filter value.";
							}
						}	
				}
				if(msg != "") {
					break;
				}			
			}
			if(msg != "") {
				alert(msg);			
			} else {							
				if($('select[name="sel_action"]').prop("disabled") == false)
					$scope.updateFilterPattern();
					
				fromApplyfilterPublic = true				
				$('#filterApplied').val('1');
				$scope.getSelectedFieldData('filterField',0,'');				
			}
		}*/
		/* MV-1823 : start */
		var msg = validateFilters();
		
		if(msg != "" && msg == 'invalid pattern') {
			return false;
		} else if (msg != "" && msg != 'invalid pattern') {
			alert(msg);
			return false;
		} else {							
			if($('select[name="sel_action"]').prop("disabled") == false)
				$scope.updateFilterPattern();
				
			fromApplyfilterPublic = true				
			$('#filterApplied').val('1');
			$scope.getSelectedFieldData('filterField',0,'');				
		}
		/* MV-1823 : End */
	};
	
	$scope.resetTable=function(){
		var columnDefs = $scope.gridOptions.columnDefs;
		var columnDefsBak = columnDefs.slice();
		columnDefs.length = 0;
		$scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN );
		columnDefs.push.apply(columnDefs, columnDefsBak)
		$scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN );
	};
	
	$scope.saveStaffExportReport = function(saveReport,action,overwrite) {
		if (saveReport != 'checkSaveReport') {
			$("#userinputfilename").val('');
			$("#userinputfilename_cnt").html('80');
		}
		var reportname =  $("#userinputfilename").val().trim();
		/* Start :: MV-1859 & MV-1885 */	
		var appliedFCount = $(".filtercount").val();
		var msg = "";
		if(appliedFCount > 1){
			msg = validateFilters();
		}
		if(msg != "" && msg == 'invalid pattern') {
			return false;
		} else if (msg != "" && msg != 'invalid pattern') {
			alert(msg);
			return false;
		} else {
		/* End :: MV-1859 & MV-1885 */
			if(action == "save") {	
				if (reportname.length == 0) {
					alert('Please provide a report name.');
					$("#userinputfilename").focus();
					return;
				}
				else if(validateNames(reportname)){
					alert('Please provide a report name that only uses letters, numbers and spaces.');
					$("#userinputfilename").focus();
					return;
				} else {
					var _current_time_cache = new Date().getTime();
					$scope.saveOrder();				
					var editpatternflage = 0;				
					var rosterOrganization = $('.rosterOrganization').val();				
					
					if($('select[name="sel_action"]').prop("disabled")==true)
						editpatternflage=1;
					
					var data =[];
					var fieldarr = [];					
					data.push({
						"name": "rosterOrganization",
						"value": rosterOrganization
					});					
					data.push({
						"name": "arrangefieldsby",
						"value": $('.arrangefields:checked').val()
					}); 
					
					$('input[name="childpanelitem"]:checked').each(function(e,i){
						var panelId = $(this).attr('data-panelid');
						var fieldId = $(this).val();
						var panelfieldId = panelId + '_' + fieldId;
						fieldarr.push(panelfieldId);					  
					});								
		
					var filtercount = parseInt($('.filtercount').val()); 
					var filter = "";
					var paneltype = "";
					var fieldtype = "";
					var operator = "";
					var operatorval = "";
					var filtervalue = "";
					var logical = " ";
					for(i = 1; i <filtercount; i++) { 
						filterby = $('option:selected', '.filter_field_' + i).val();  
						panel = $('option:selected', '.filter_field_' + i).attr('data-paneltype'); 
						field = $('option:selected', '.filter_field_' + i).attr('data-fieldtype');
						operatorType = $('.filter_operators_' + i + ' option:selected').text();
						if(operatorType=='is only')operatorType = 'is';
						operatorValue = $('.filter_operators_' + i + ' option:selected').val();					
						fieldvaluefilter = "";
						if(operatorType == 'between' || operatorType == 'not between') {
						$('.filtervalue_' + i).each(function(){
							fieldvaluefilter += $(this).val() + ",";                 
						});
						fieldvaluefilter.substring(0, fieldvaluefilter.length-1);       
						} else {
						fieldvaluefilter =  $('.filtervalue_' + i).val();
						if(fieldvaluefilter == '') {
							fieldvaluefilter = ' ';
						}
						}
						if(i>1) {
						logical += $('option:selected', '.sel_action_' + i).text();
						}
						filter += filterby + "~";
						paneltype += panel + "~";
						fieldtype += field + "~";
						operator += operatorType + "~";
						operatorval += operatorValue + "~";
						filtervalue += fieldvaluefilter.replaceAll("~","&tilde;") + "~";  //MV-1877
						logical += "~";     
					}							
					data.push({
						"name": "SelectedFields",
						"value": fieldarr
					});
					data.push({
						"name": "filter",
						"value": filter
					});
					data.push({
					"name": "paneltype",
					"value": paneltype
					});
					data.push({
					"name": "fieldtype",
					"value": fieldtype
					});
					data.push({
						"name": "operator",
						"value": operator
					});
					data.push({
						"name": "operatorval",
						"value": operatorval
					});
					data.push({
						"name": "filtervalue",
						"value": filtervalue
					});
					data.push({
						"name": "logical",
						"value": logical
					});
					data.push({
						"name": "fieldorder",
						"value": $('#fieldsortorder').val()
					});
					data.push({
						"name": "reportname",
						"value": reportname
					});	
					data.push({	
						"name": "filtervaluepattern",
						"value": $('#filtervaluepattern').val()
					});	
					data.push({				
						"name": "editpatternflage",
						"value": editpatternflage
					});					
					
					var url = "index.cfm?event=staff.saveExportReportDetails&overwrite="+overwrite+"&currenttimestamp=" + _current_time_cache;
					
					$.ajax({
						type: "POST",
						url: url,
						data: data,
						dataType: "json",
						beforeSend: function() {
							showLoadingOverlay();							
						},
						success: function(saveReportStatus) {							
							if(saveReportStatus == "1") {
								overwritewindow(reportname,0); 
							} else {
								if(overwrite == 1)
									closeCRWindow();
								showLoadingOverlay();
								overwritewindow(reportname,1);
								
								loadSavedReports(); // function to Update Saved Report Section	
							}	
						},
						complete: function() {
							hideLoadingOverlay();						  
						},
						error: function(data) {
							status = false;
						}
					});
				}  		
			} else {
				$scope.exportToExcel();			
			}
		} //MV-1859 & MV-1885
	};		
	
	/*$scope.callsaveOrder = function() {		
		var state = $scope.gridApi.saveState.save();		
		$scope.fieldorder = [];		
		for(var i=0; i<state.columns.length; i++) {			
			var fieldId = state.columns[i].name;			
			$scope.fieldorder.push(fieldId);		
		}
		$("#fieldsortorder").val($scope.fieldorder);	
		$("#setFieldOrder").val('1');
	};*/
	
	$scope.displayReportFields = function(generateExcel) {	
		showLoadingOverlay();
		var reportId = $(".report_radio:checked").val();					
		var filtercount = parseInt($('.filtercount').val());		
		var isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);		//MV-1368::MV-1791
		for(var i=2; i<=filtercount; i++) {
			$('#subfilter_' + i).remove();
		}
		$('.filtercount').val('1');
		$('#filtervaluepattern').val('');
		$('#patternforrestore').val('');
		$('#editpatternflage').val('0');
		$('.filterpattern').css('display','none');		
		$('#clearfilter').css('display','none');
		$('#btn_apply_filter').prop("disabled", true);	
		$('.filtercount_1').addClass('padding-left-10');
		$('.filtercount_1').html('');	
		$('.filtercount_1').css('display','none');
		$('.sel_action_1').remove('');
		$('.filter_field_1').addClass('tmsht-widt-215');
		$('.filter_field_1').removeClass('tmsht-widt-134');
		$('.filtervalue_1').addClass('tmsht-widt-161');
		$('.filtervalue_1').removeClass('tmsht-widt-134');
		$('.filtervalue_1').val('');
		$('.ffilterby').removeClass('text-right');
		$('.fOperator').removeClass('text-right');
		$('.fValue').removeClass('text-right');									
		$('.filterbylable').removeClass('margin-right-63');
		$('.operatorlabel').removeClass('margin-right-63');
		$('.valuelabel').removeClass('margin-right-102');	
		$('.btn_add_filter_1').html('Add');
		$('.btn_cancel_filter_1').html('Cancel');		
		//MV-1368::MV-1791
		if(!isSafari){
			$('.filter_field_1 option[value="0"]').attr('selected', true);	
		}
		//MV-1368::MV-1791
		$('.filter_field_1').select2('destroy');	
		$('.filter_operators_1').html('');		
		//MV-1368::MV-1791	
		if(!isSafari){
		$('.filter_field_1 option[value="0"]').attr('selected', true);	
		}
		//MV-1368::MV-1791
		$('.filter_field_1').trigger("change");
		$('.filter_field_1').select2();					
		
		$("#filterbox").hide();
		$('#filterApplied').val('0'); 
		
		$('input[name="childpanelitem"]').not('.check_required').prop('checked',false);	
		$('input[name="childpanelitem"]').not('.check_required').parents('.columngroup').removeClass("check_bgcolor");
		//$scope.fieldorder = [];
		var editpatternflage=0;
		var filtervaluepattern='';
		$('.attrItemdata').css('display','none');//MS-278
		$('.showHide').removeClass('hideIt').addClass('showIt');// MS-278
		$.ajax({
			type:"post",
			url:"index.cfm?event=staff.getStaffReportDetails&reportId="+reportId,			
			async: false,
			success: function(reportData) {	
				reportData = $.parseJSON(reportData);				
				var arrangefieldsby = reportData.reportdetails.arrangefieldsby;
				var filtervaluepattern = reportData.reportdetails.filtervaluepattern;
				var editpatternflage = reportData.reportdetails.editpatternflage;									
				var fieldSelected = reportData.reportfielddetails.fieldid;
				fromSavedReport = 1;
				/* MS-278 : Start*/
				var panelid = reportData.reportfielddetails.panelid;
				var panelidArray = panelid.split(',');
				var uniquepanelid = panelidArray.filter(function(elem, index, self) {
				    return index === self.indexOf(elem);
				});
				for(var i=0; i<uniquepanelid.length; i++){
					
					var showHide=$('#staffPanel_'+uniquepanelid[i]).siblings();
					showHide.removeClass('showIt').addClass('hideIt');
					$('#userAssign'+uniquepanelid[i]).css('display','block');
				}
				/* MS-278 : END*/
				//$('input[value="'+arrangefieldsby+'"]').prop("checked",true);
				$('input[name="arrangefields"][value="' + arrangefieldsby + '"]').prop('checked', true); //MV-1823
				$("#currentArrangeField").val(arrangefieldsby);//MV-1823

				var fieldsArray = fieldSelected.split(',');
				var fieldOrderArray = [];
				for(var counter_j=0; counter_j<fieldsArray.length; counter_j++){
					$("#childpanelitem_"+fieldsArray[counter_j]).prop("checked", true);						
					$("#childpanelitem_"+fieldsArray[counter_j]).closest('.columngroup').addClass("check_bgcolor");
					var field_pfid = $("#childpanelitem_"+fieldsArray[counter_j]).attr('data-panelid') + '_' + fieldsArray[counter_j];
					fieldOrderArray.push(field_pfid);
				}
				
				/* Start: Code to set Same Column Order during Save */
				$('#fieldsortorder').val(fieldOrderArray);
				$("#setFieldOrder").val('1');
				$scope.fieldorder = fieldOrderArray;
				/* End: Code to set Same Column Order during Save */
					
				if (!($.isEmptyObject(reportData.reportfilterdetails))) {					
					var logicalArray = reportData.reportfilterdetails.logical.toString().split(',');	
					var fieldidArray = reportData.reportfilterdetails.fieldid.toString().split(',');
					var fieldtypeArray = reportData.reportfilterdetails.fieldtype.toString().split(',');
					var filteroperatorArray = reportData.reportfilterdetails.operator.toString().split(',');
					var filtervalueArray = reportData.reportfilterdetails.filtervalue.toString().split('~');															
					
					$('#filterbox').slideDown(1000);
					$('#filteroption').html('Hide Filter');	
					$('#filtercount').val(fieldidArray);					
					
					var filtercnt=0;										
					for(var j=0; j < fieldidArray.length; j++) {	
						filtercnt++;
						//$scope.fieldorder.push(fieldidArray[j]);						
						//$('.filter_field_' + filtercnt + ' option[id="'+fieldtypeArray[j]+'_'+fieldidArray[j]+'"').attr("selected", "selected");
						//$('.filter_field_' + filtercnt).val(fieldidArray[j]);
					 	//$('.filter_field_'+ filtercnt).trigger("change");		
						$('.filter_field_' + filtercnt).val(fieldidArray[j]).trigger('change');
						
					 	$('.filter_operators_'+ filtercnt).val(filteroperatorArray[j]);
					 	$('.filter_operators_'+ filtercnt).trigger("change");
						
						var operatorText = $('.filter_operators_'+ filtercnt + ' option:selected').text();						
						if(operatorText == 'between' || operatorText == 'not between') {							
							var datebetweenValues = filtervalueArray[j].split(',');							
							if(isDate(datebetweenValues[0]) && isDate(datebetweenValues[1])){
								$('#datelink1_' + filtercnt).val(datebetweenValues[0]);	
								$('#datelink2_' + filtercnt).val(datebetweenValues[1]);
							} else {
								$('#agetxtbox_1_' + filtercnt).val(datebetweenValues[0]);	
								$('#agetxtbox_2_' + filtercnt).val(datebetweenValues[1]);
							}							
						} else {
							/*CPORT-100 */
							if(fieldtypeArray[j] == "receiveemail" || fieldtypeArray[j] == "receiveTexts" ){
								if (filtervalueArray[j] == "false" || filtervalueArray[j] == "no") 
								{ 
									 filtervalueArray[j] = "No"; 
									$('.filtervalue_'+ filtercnt).val(filtervalueArray[j]);
								}
								else if (filtervalueArray[j] == "true" || filtervalueArray[j] == "yes") 
								{ 
									 filtervalueArray[j] = "Yes"; 
									$('.filtervalue_'+ filtercnt).val(filtervalueArray[j]);
								}
							}
							/*CPORT-100 */
							var replaceFilterValue= filtervalueArray[j].replaceAll("&tilde;","~");//MV-1877
					 		$('.filtervalue_'+ filtercnt).val(replaceFilterValue); //MV-1877
						}
						
						if(filtercnt > 1) {	
					 		if(logicalArray[j] == 'AND')
					 			$('.logical_'+filtercnt).val(1);
					 		else if(logicalArray[j] == 'OR')
					 			$('.logical_'+filtercnt).val(2);	
							$scope.updateFilterPattern();

					 	}
						
						if(editpatternflage == 1) {
							$scope.addFilter(filtercnt,0, true);	
							$('select[name="sel_action"]').val('');
							$('select[name="sel_action"]').prop("disabled",true);
							$('#filtervaluepattern').val(filtervaluepattern);
							$('#hiddenpattern').val('');
							$('#patternforrestore').val(filtervaluepattern);
							$('#editpatternflage').val(editpatternflage);
						} else {							
							$scope.addFilter(filtercnt,1, true);								
						}																		
					}	
					filtercnt++;
					$('.filter_field_'+ filtercnt +' option[value="0"]').attr('selected', true);
					$('#filterApplied').val('1'); 
				}
				/* Start: MV-1929 */
				else {
					$scope.removeFilter(1);					
				}
				/* End: MV-1929 */
				
				$scope.resetTable();					
				$scope.getSelectedFieldData('panelFields',0,'');
				
				$timeout(function () {
					if(generateExcel){							
						$scope.exportToExcel();
					}
				});
			
				//$scope.fetchFieldsData(generateExcel);
				//$scope.fieldorder = [];
				//var filterCnt=0;
				//var fieldorder=[];
			},
			error: function(reportData) {
				console.log(reportData);
				alert('oops some mistake on server');
			}
		});
			
		hideLoadingOverlay();
	};
	
/* MV-862:Start */
$scope.passwordSetupPopup = function() {
	var postData = [];
	postData.push({
		"name": "sendPasswordUserIds",
		"value": $('#resultUserIdList').val()
	});
	
	var title = "Send Password Setup E-mail to " + staffAliasPlural + " Without Passwords";
	var height = 260;
    var width = 420;
	$.ajax({
		type: "post",
		url: "index.cfm?event=user.ShowPasswordResetWindow&value=sendmail&pagereq=staffs&isSetup=passwordMail",
		data: postData,
		before: function () {
			showLoadingOverlay();
		},
		success: function (result) {
			hideLoadingOverlay();
			$('#popupid').css('background', 'white');
			$('#popupid').css('max-height', '500px');
			$('#popupid').css('min-height', height);
			$('#popupid').css('padding-bottom', '50px');
			$('#popupid').dialog({ autoOpen: false, modal: true, title: title, width: width, center: true, draggable: false, resizable: false, dialogClass: 'dialog-resetpass' });
			$("#popupid").dialog('open').html(result);
		},
		error: function(resp) {						
		}
	});
}
/* MV-862:End */
	$scope.exportToExcel= function(){	
		var wb = new ExcelJS.Workbook();
		var ws = wb.addWorksheet('Export');
		var origin   = window.location.origin;
		
		// Header
		var utc =  moment.utc(new Date());		
		var pst = moment.tz(utc,'America/Los_Angeles');
		var fileDate = pst.format('MMMM_D_YYYY_h_mmA');
		  
		row1 = ws.getRow(1);
		row1.getCell(1).value = staffAlias + ' Export Report (' + fileDate + ' )';
		row1.font = { name: 'Arial', size: 10 };
		var com_his_count=1;
		$scope.saveOrder();	
	
		/*if($scope.removeFieldOrder.length > 0 )
		{
			$scope.removeFieldOrder.each(function(e){				
				var tempindex = $scope.fieldOrder.indexOf(e);				
				if(tempindex != -1){
					$scope.fieldOrder.splice(tempindex,1);
				} else {					
					do {				
						var val  = e + '_' + com_his_count;						
						var tempindex1 = $scope.fieldOrder.indexOf(val);				
						if(tempindex1 != -1) {
							$scope.fieldOrder.splice(tempindex1,1);
						} else {					
							break;
						}
						com_his_count++;
					}
					while (com_his_count>0);
				}
			});
			tableorder = $scope.fieldOrder;			
		} else {				
			tableorder = $scope.fieldOrder;
		}*/				
		tableorder = $scope.fieldOrder;
		
		var fileorder = [];			
		var cellcount = 1;		
		var currentuserid = "";		
		var cellNumber;
		var columnType;
		var colname;
							
		tableorder.forEach(function(ord) {						
			//write column of excel
			row3 = ws.getRow(3);						
			$scope.gridOptions.columnDefs.map( function(head, index) {																	
				pnlid_fid = head.pnlid_fid;			
				if(ord == pnlid_fid){					
					cellName = head.fieldname;																
					if(head.fieldtype.toLowerCase() == 'fileattachment' || head.fieldtype.toLowerCase() == 'photo' || head.fieldtype.toLowerCase() == 'signdocument'){
						fileorder.push(pnlid_fid+':'+cellcount);
						
					}
					cellNumber = cellcount;							
					cellwidth=head.displayName.length + cellName.length;		 
					ws.getColumn(cellNumber).width = cellwidth +2;						
					row3.getCell(cellNumber).value = {
						richText: [
						  { font: { name: 'Arial', size: 10, bold: true }, text: head.displayName },
						  { font: { name: 'Arial', size: 10, color: { argb: '000366d6' } }, text: ': ' + cellName },
						]
					};						
					index=cellNumber-1;
					cellcount=index+1;
					cellcount=cellcount+1;				
				}				
			})					
		})
		//write header download zip link in excel			
		var row4count=0
		row4 = ws.getRow(4);	
		var flag=false;	
		//tableorder.forEach(ord => {	
		tableorder.forEach(function(ord) {	
			row4count=row4count+1;
			findex=0;
			for (var i = 0; i < $scope.gridOptions.columnDefs.length; i++) {				
				var pnlid_fid = $scope.gridOptions.columnDefs[i].pnlid_fid;					
				if(ord == pnlid_fid){
					flag=false; // MV-1943		
					if($scope.gridOptions.columnDefs[i].fieldtype == 'fileattachment' || $scope.gridOptions.columnDefs[i].fieldtype == 'photo' || $scope.gridOptions.columnDefs[i].fieldtype =='signdocument'){		
						colname=$scope.gridOptions.columnDefs[i].name;
						columnType =$scope.gridOptions.columnDefs[i].fieldtype;	
													
						if($scope.gridOptions.columnDefs[i].fieldtype == 'signdocument') {
							for (var j = 0; j < $scope.gridOptions.data.length; j++) {
								/* Start: MV-2064 */
								var signenowHtml=$scope.gridOptions.data[j][colname];								
								if(signenowHtml.indexOf('<') != -1 && signenowHtml.indexOf('>') != -1) {
									var txtsplic1 = signenowHtml.split('>');						
									var len = txtsplic1[1].indexOf('<');										
									signenowHtml = txtsplic1[1].substring(0,len);
								}
								/* End: MV-2064 */
								if($scope.gridOptions.data[j][colname]!='' && $scope.gridOptions.data[j][colname]!='Waiting for director signature' && $scope.gridOptions.data[j][colname]!='Waiting for ' + staffAlias.toLowerCase() + ' signature' && $scope.gridOptions.data[j][colname]!="Waiting for " + volunteerAliasLcase + " signature" && $scope.gridOptions.data[j][colname]!="has no signatures" && signenowHtml!="Upload a signed document"){//MV-2064
									flag=true;
									downloadZipRow = 1; // MV-1943	
									break;
								}
							}
						} else {
							for (var j = 0; j < $scope.gridOptions.data.length; j++) {
								if($scope.gridOptions.data[j][colname] != ''){
									flag=true;
									downloadZipRow = 1; // MV-1943	
									break;
								}
							}	
						}							
											
						if(flag){
							//fileorder.forEach(ord1 => {
							fileorder.forEach(function(ord1) {
								if(ord1.split(':')[0]==pnlid_fid)
									findex=ord1.split(':')[1];
							})							
							fileIndex = parseInt(findex);									
							pid = $("#programid").val();	
							uid = $("#userid").val();								
							//pnlid = pnlid_fid.split('_')[0].trim();
							fid = pnlid_fid.split('_')[1].trim();														
							if($scope.gridOptions.columnDefs[i].fieldtype=='signdocument') {
								mainhyperlinkurl=origin+"/index.cfm?event=staff.downloadsignedfilezip&prg="+pid+"&usr=undefined&field="+fid+"&userlistid="+userlistid+"&fieldtype="+columnType;			
							} else {
								mainhyperlinkurl=origin+"/index.cfm?event=staff.downloadfilezip&prg="+pid+"&usr=undefined&field="+fid+"&userlistid="+userlistid+"&fieldtype="+columnType;			
							}								
							
							row4.getCell(fileIndex).value = { formula:'HYPERLINK("' + mainhyperlinkurl + '","Download.Zip")' };
							row4.getCell(fileIndex).font = { name: 'Arial', size: 10, underline: 'single', color: { argb: '000366d6' } };						
						}
					}
				}
			}
		})			
			
		var cellValuesArray = [[]];
		var staffCount = 0;
		var cellNumberArray = [];
		var cellValuesTypeArray = [];
		var objectValues = {};						
		var cellFieldTypeArray = []; 
		
		// write Data in excel
		ws.addRows($scope.gridOptions.data);
		var visibleRows=$scope.gridApi.core.getVisibleRows();
		staffCount = visibleRows.length;
		$scope.resetfieldorder();
		//var flag=false;
		/*for (var gridindex = 0; gridindex < $scope.gridOptions.columnDefs.length; gridindex++) {	
		 	//if($scope.gridOptions.columnDefs[gridindex].pnlid_fid === $scope.fieldorder[gridindex] && ($scope.gridOptions.columnDefs[gridindex].fieldtype === 'fileattachment' || $scope.gridOptions.columnDefs[gridindex].fieldtype === 'photo' || $scope.	gridOptions.columnDefs[gridindex].fieldtype === 'signdocument')) { // MV-1344 Commented and added below
			if(($scope.gridOptions.columnDefs[gridindex].fieldtype === 'fileattachment' || $scope.gridOptions.columnDefs[gridindex].fieldtype === 'photo' || $scope.gridOptions.columnDefs[gridindex].fieldtype === 'signdocument')) {								
				flag=true;		
				break;
			}
		}*/
								
		for(l=0; l<visibleRows.length; l++) {				               
			if(downloadZipRow == 1) { // MV-1943
				rowIndex = l + 5;
			} else {
				rowIndex = l + 4;
			}
							
			row = ws.getRow(rowIndex);
			var rowdatacount=1;				
				
			tableorder.forEach(function(ord) {											
				if(cellNumberArray.indexOf(rowdatacount) == -1) {
					cellValuesArray[rowdatacount] = [];
					cellNumberArray.push(rowdatacount);						
				}												
													
				$scope.gridOptions.columnDefs.map(function(head, index) {																							   
					var pnlid_fid = head.pnlid_fid;
					var cellisQualitative = head.isQualitative;						
					var agefield = head.agefield;										
					if(ord == pnlid_fid){
						cellNumber = rowdatacount;	 	 
						columnType = head.fieldtype.trim();	
						fileText='';
						filename='';							
						if (columnType === 'fileattachment' || columnType === 'photo'){						
							if(visibleRows[l].entity[head.name].split(';;').length > 1) {
								fileText = 'Download.zip' ;
								filename='';
								z = 1;
							} else if(visibleRows[l].entity[head.name].split(';;')[0]) {
								fileText = visibleRows[l].entity[head.name];
								filename = fileText.split('id')[1];
								filename = filename.substring(2);
							
								var txtsplic = fileText.split('>');						
								var len = txtsplic[1].indexOf('<');	
								
								fileText = txtsplic[1].substring(0,len);
								filename = filename.substring(0,filename.indexOf("'"));						
								z = 0;
							}									
							if (fileText !== ''){
								pid = $("#programid").val();	
								uid = visibleRows[l].entity.userid;									
								fid = pnlid_fid.split('_')[1].trim();										
								innerhyperlinkurl=origin+"/index.cfm?event=staff.downloadfile&prg="+pid+"&usr="+uid+"&field="+fid+"&fieldtype="+columnType+"&fn="+filename+"&z="+z;
									
								row.getCell(cellNumber).value = { formula: 'HYPERLINK("' + innerhyperlinkurl + '","' + fileText + '")' };
								row.getCell(cellNumber).font = { name: 'Arial', size: 10, underline: 'single', color: { argb: '000366d6' } }; 																
							 }								
							rowdatacount=rowdatacount+1;
						} else if (columnType === 'signdocument') {
								fileText=visibleRows[l].entity[head.name];	
								
								if(fileText.indexOf('<') != -1 && fileText.indexOf('>') != -1) {
									var txtsplic = fileText.split('>');						
									var len = txtsplic[1].indexOf('<');										
									fileText = txtsplic[1].substring(0,len);
								}
								if(fileText != '' && fileText != 'Waiting for ' + staffAlias.toLowerCase() + ' signature' && fileText != 'Waiting for director signature' && fileText != 'Waiting for ' + volunteerAliasLcase + ' signature') {		
									fileNameText=visibleRows[l].entity[head.name];										
									filename=fileNameText.split('id')[1];	
									filename=filename.substring(2);										
									filename=filename.substring(0,filename.indexOf("'"));
									
									pid = $("#programid").val();	
									uid = visibleRows[l].entity.userid;									
									fid = pnlid_fid.split('_')[1].trim();										
									innerhyperlinkurl=origin+"/index.cfm?event=staff.downloadsignedfile&prg="+pid+"&usr="+uid+"&field="+fid+"&fieldtype="+columnType+"&fn="+filename+"&z=0";
									/* Start: MV-2064(Added if condition ,inner code already available) */
									if(fileText!='Upload a signed document'){	
										row.getCell(cellNumber).value = { formula: 'HYPERLINK("' + innerhyperlinkurl + '","' + fileText + '")' };
										row.getCell(cellNumber).font = { name: 'Arial', size: 10, underline: 'single', color: { argb: '000366d6' } };
									}
									/* End: MV-2064 */
								} else {
									row.getCell(cellNumber).value = fileText;
								}
								rowdatacount=rowdatacount+1;
						} else {								
							var excelCellValue = visibleRows[l].entity[head.name];
							var cellValueType = '';
							if(excelCellValue != '' && typeof excelCellValue == 'number' && (columnType == 'userid' || columnType == 'number' || (columnType == 'select' && cellisQualitative == 0) || (columnType == 'date' && agefield != 'undefined' && agefield != null && agefield != "" && agefield == "Current Age"))) {
								excelCellValue = Number(excelCellValue);									
							}																
							
							row.getCell(cellNumber).value = excelCellValue;
															
							if(excelCellValue != '' && columnType == 'date' && (agefield == 'undefined' || agefield == null || agefield == "")) {									
								row.getCell(cellNumber).numFmt = 'm/d/yyyy';	
							}								
							
							row.getCell(cellNumber).font = { name: 'Arial', size: 10};
							rowdatacount=rowdatacount+1;
							
							if (rosterOrganization == 'staffmember') {								
								var fieldsubpanelid = head.subpanelid.toString().trim();
								
								if (columnType == 'userid' || columnType == 'siteid' || columnType == 'cohortid' || columnType == 'number' || ((columnType == 'select' || columnType == 'checkbox') && cellisQualitative == 0) || (columnType == 'date' && agefield != 'undefined' && agefield != null && agefield != "" && agefield == "Current Age")) {										
									cellValueType = 'number';
								} else if (columnType == 'date') {
									cellValueType = 'date';
								} else if (columnType == 'site' || columnType == 'cohort_name' || ((columnType == 'select' || columnType == 'checkbox') && cellisQualitative == 1)) {
									cellValueType = 'text';
								}
								
								cellValuesTypeArray[cellNumber] = cellValueType;	
								cellFieldTypeArray[cellNumber] = columnType;
								
								if(columnType != 'lname' && columnType != 'userid' && columnType != 'text' && columnType != 'encryptedtext' && columnType != 'freetextarea' && row.getCell(cellNumber).value != null && row.getCell(cellNumber).value.toString().trim() != '') {									
									if(columnType == 'checkbox' || columnType == 'site' || columnType == 'siteid' || columnType == 'cohortid' || columnType == 'cohort_name') {
										var cellValueCheckbox = row.getCell(cellNumber).value.toString().trim();
										var cellValueCheckboxArray = cellValueCheckbox.split(";;");										
										for(var j = 0; j < cellValueCheckboxArray.length; j++) {												
											cellValuesArray[cellNumber].push(cellValueCheckboxArray[j].toString().trim());
										}
									} else {
										cellValuesArray[cellNumber].push(row.getCell(cellNumber).value.toString().trim());
									}
								}
							}								
						}							
					}
				});					
			})
		}//end for loop	
		downloadZipRow = 0; // MV-1943					
		if (rosterOrganization == 'staffmember' && typeof rowIndex != 'undefined') {
			rowIndex = rowIndex + 2;
			row = ws.getRow(rowIndex);
			row.getCell(1).alignment = {wrapText: true};
			row.getCell(1).value = {
				richText: [
					{ font: { name: 'Arial', size: 10, bold: true }, text: 'Total ' + staffAliasPlural + ': ' + staffCount },							
				]
			};
			for(var i =1; i<cellNumberArray.length; i++) {
				var currentCellNum = cellNumberArray[i];
				var cellValuesCountArray;
				var dataCount = '';		

				if (cellValuesTypeArray[currentCellNum] == 'number') {
					cellValuesArray[currentCellNum] = cellValuesArray[currentCellNum].sort(function (a, b) {  return a - b;  });					
					cellValuesCountArray = arrayElementCount(cellValuesArray[currentCellNum]);
				} else if (cellValuesTypeArray[currentCellNum] == 'date') {					
					cellValuesArray[currentCellNum] = cellValuesArray[currentCellNum].sort(function (a, b) {  var dateA = new Date(a), dateB = new Date(b); return dateA - dateB;});					
					cellValuesCountArray = arrayElementCount(cellValuesArray[currentCellNum]);
				} else if (cellValuesTypeArray[currentCellNum] == 'text') {
					cellValuesArray[currentCellNum] = cellValuesArray[currentCellNum].sort(function(a, b) {
																							if (a.toLowerCase() < b.toLowerCase()) return -1;
																							if (a.toLowerCase() > b.toLowerCase()) return 1;
																							return 0;
																						  });
					cellValuesCountArray = arrayElementCount(cellValuesArray[currentCellNum]);
					cellValuesCountArray = cellValuesCountArray.sort(function (a, b) {  return b.count - a.count;  });
				} else {
					cellValuesCountArray = arrayElementCount(cellValuesArray[currentCellNum]);
				}
				
				var totalDataCount = 0;
				for(let i = 0; i < cellValuesCountArray.length; i++){												
					if (cellValuesTypeArray[currentCellNum] == 'number' && cellFieldTypeArray[currentCellNum] != 'date') {
						totalDataCount = totalDataCount + (parseFloat(cellValuesCountArray[i].value) * parseInt(cellValuesCountArray[i].count));
					}									
					dataCount = dataCount + cellValuesCountArray[i].value + ' (' + cellValuesCountArray[i].count + ')' + '\n';			
				}	
									
				if (cellValuesTypeArray[currentCellNum] == 'number' && cellFieldTypeArray[currentCellNum] != 'date' && dataCount != '') {
					if(cellFieldTypeArray[currentCellNum] == 'number') {
						dataCount = 'Total (' + totalDataCount + ')';
					} else {
						dataCount = 'Total (' + totalDataCount + ')' + '\n' + '\n' + dataCount;
					}
				}				
			
				row.getCell(currentCellNum).alignment = {wrapText: true};
				row.getCell(currentCellNum).value = {
					richText: [
						{ text: dataCount },							
					]
				};	
				row.font = { name: 'Arial', size: 10, bold: true };
			}	
		}		
			
		//export excel
		wb.xlsx.writeBuffer( {
				base64: true
			})
			.then( function (xls64) {
				// build anchor tag and attach file (works in chrome)
				var a = document.createElement("a");
				var data = new Blob([xls64], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });				
				var url = URL.createObjectURL(data);				
				a.href = url;			
				a.download = "CustomRoster_" + fileDate + ".xlsx";
				document.body.appendChild(a);
				a.click();
				setTimeout(function() {
						document.body.removeChild(a);
						window.URL.revokeObjectURL(url);
					},
					0);
			})
			.catch(function(error) {
				console.log(error.message);
			});
    };//End exportExcel

}]);
		
app.filter('trusted', function ($sce) {
  return function (value) {
    return $sce.trustAsHtml(value);
  }
});		
				
function arrayElementCount(original) {
 
	var compressed = [];
	// make a copy of the input array
	var copy = original.slice(0);
 
	// first loop goes over every element
	for (var i = 0; i < original.length; i++) {
 
		var myCount = 0;	
		// loop over every element in the copy and see if it's the same
		for (var w = 0; w < copy.length; w++) {
			if (original[i] == copy[w]) {
				// increase amount of times duplicate is found
				myCount++;
				// sets item to undefined
				delete copy[w];
			}
		}
 
		if (myCount > 0) {
			var a = new Object();
			a.value = original[i];
			a.count = myCount;
			compressed.push(a);
		}
	}
 
	return compressed;
};

function overwritewindow(reportname,status){
	var cfwindowTitle = "";	
	ColdFusion.Window.create("overwriteWindow",cfwindowTitle,"index.cfm?event=staff.reportSaveOverWritewindow&reportname="+reportname+"&statusow="+status,{modal:true,width:450,height:180,center:true,draggable:true});	
	ColdFusion.Window.onHide("overwriteWindow", closeCRWindow); 
}

function closeCRWindow(){
	ColdFusion.Window.destroy("overwriteWindow");        
}
				
/* Start: Mv-1823 */
function validateFilters() {
	var validationstatus = angular.element(document.getElementById('exportStaff')).scope().savePattern();
	if(validationstatus){
		var filtercount = parseInt($('.filtercount').val());		
		for(var rel=1; rel < filtercount; rel++) {
			var button = $('.btn_add_filter_' + rel).html();
			var filterby = $('option:selected', '.filter_field_' + rel).val();	
			var filterbySelected = $('option:selected', '.filter_field_' + rel).attr('data-fieldtype');						
			var fieldvalueclass = 'btn_add_filter_' + rel;
			var operatorType = $('.filter_operators_' + rel + ' option:selected').text();
			if(operatorType=='is only')operatorType = 'is';
			var fieldvaluefilter = 	$('.filtervalue_' + rel).val();				
			var msg = "";
			if(filterby == 0) {
				msg += "Please select filter by.\n";		
			} 	
			if(operatorType != "is empty" && operatorType != "isn't empty" && operatorType != "is set" && operatorType != "is not set" && operatorType != "today" && operatorType != "tomorrow" && operatorType != "tomorrow onwards"  && operatorType != "yesterday" && operatorType != "until yesterday" && operatorType != "last month"  && operatorType != "current month" && operatorType != "next month"  && operatorType != "last week" && operatorType != "current week" && operatorType != "next week" && operatorType != "is fully executed" && operatorType != "is waiting for supervisor signature" && operatorType != "is waiting for " + staffAliasLcase + " signature" && operatorType != "is waiting for director signature" && operatorType != "is waiting for " + volunteerAliasLcase + " signature" && operatorType != "has no signatures") {//Mv-862
					if($('option:selected', '.filter_field_' + rel).attr('data-field-type') == 'date') {
						if((operatorType == "between" || operatorType == "not between") && (($('#datelink1_' + rel).val() != 'undefined' && $('#datelink1_' + rel).val() == "") || ($('#datelink2_' + rel).val() != 'undefined' && $('#datelink2_' + rel).val() == ""))) {
							msg += "Please provide both between date filter value.";	
						} else {
							if(typeof fieldvaluefilter != 'undefined' && fieldvaluefilter.trim() == "") {
								msg += "Please provide date filter value.";
							}
						}			
					}else {							
						if(typeof fieldvaluefilter != 'undefined' && fieldvaluefilter.trim() == "") {
							msg += "Please provide filter value.";
						}
					}	
			}
			if(msg != "") {
				break;
			}			
		}
	}
	if(validationstatus == false) {
		return "invalid pattern";
	}
	return msg;
}
/* End: MV-1823 */				
			   
