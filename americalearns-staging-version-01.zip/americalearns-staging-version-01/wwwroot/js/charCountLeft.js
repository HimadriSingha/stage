function CountLeft(field, max) {

	if(typeof field.value != 'undefined') {	
		tempvalue = field.value.replace(/\r\n/g,"\n");
		//input = $j(field).closest("#que_ans");
		counter = $j("*#"+field.name+"_cnt");			
		if(counter.length > 1)
			cnt = counter[1];
		else
			cnt =  counter[0];
		
		if (tempvalue.length > max) {
			field.value = tempvalue.substring(0, max);
			nowCount = max - field.value.length;
			$j(cnt).text(nowCount);
		} else { 	
			nowCount = max - tempvalue.length;
			$j(cnt).text(nowCount);
		} 		
		//field.style.height='';
		if(parseInt(field.style.minHeight)<field.scrollHeight)
		{
			//field.style.height=field.scrollHeight+'px';
		}
	} else {
		var ele = document.getElementById(field);
		var target_ele = document.getElementById(field+"_cnt");
		
		if( ele != null && target_ele!=null) {
			tempvalue = ele.value.replace(/\r\n/g,"\n");
			//alert(tempvalue);
			
			if(typeof tempvalue != 'undefined') {
				if (tempvalue.length > max) {
					ele.value = tempvalue.substring(0, max);
					nowCount = max - ele.value.length;
					target_ele.childNodes[0].nodeValue = nowCount;
				} else { 	
					nowCount = max - tempvalue.length;
					target_ele.childNodes[0].nodeValue = nowCount;
				}	//ele.style.height='';
				if(parseInt(ele.style.minHeight)<ele.scrollHeight)
				{
					//ele.style.height=ele.scrollHeight+'px';
				}
			}
		}		
	}	
}