

function processassociationitem(element1,element2,element3,form_in){
	//location of post data file
	new Ajax.Request("/index.cfm?event=association.associationitemsformprocess", {
		method: "post",
		parameters: Form.serialize(form_in,true),
		onSuccess: function(t) {
			Effect.toggle(element1, 'slide');
			Element.update(element3,t.responseText);
    	},
		onFailure: function(){
			alert("Technical problems please try reloading page");
		}

	});

	return false;
}

function insertForm(element1,element2,element3,type){
	//$("processing-indicator").show();
	//location of form
	new Ajax.Request("/index.cfm?event=association.associationitemsform&element1=" + element1 + "&userid=" + element2 + "&element3=" + element3 + "&type=" + type, { 

		onSuccess: function(t) { 
			//$("processing-indicator").hide();
			Element.update(element1, t.responseText); 
			Effect.toggle(element1, 'slide');			
		}, 
		onFailure: function(){ 
			alert('Oops...mistake on server');
		} 
	});

	return false; 
}
function insertQuestionForm(element1,element2,element3,type,associationitemid){
	//$("processing-indicator").show();
	//location of form
	var aa = document.URL.split('?');
	var bb = aa[1];
	var cc = bb.split('&');
	var pagename = cc[0].split('=');
	$j.ajax({
		url: "/index.cfm?event=association.associationitemsformquestions",
		method: "GET",  // Assuming a GET request, change to POST if necessary
		data: {
		  element1: element1,
		  userid: element2,
		  element3: element3,
		  type: type,
		  associationitemid: associationitemid,
		  pagename: pagename
		},
		success: function(response) {
		  // Update the content of element1
		  $j('#' + element1).html(response);
		  
		  // Toggle the element with a slide effect
		  $j('#' + element1).slideToggle();
	  
		  // Call the udfFillCheckBox function
		  udfFillCheckBox(associationitemid);
		},
		error: function() {
		  alert('Oops... mistake on server');
		}
	  });
	/*new Ajax.Request("/index.cfm?event=association.associationitemsformquestions&element1=" + element1 + "&userid=" + element2 + "&element3=" + element3 + "&type=" + type + "&associationitemid=" + associationitemid + "&pagename=" +pagename, { 

		onSuccess: function(t) { 
			//$("processing-indicator").hide();
			Element.update(element1, t.responseText);
			//alert(t.responseText);
			//alert('after update in fn'); 
			Effect.toggle(element1, 'slide');
			//alert(t.responseText);
			//document.getElementById(element1).innerHTML = t.responseText;
			udfFillCheckBox(associationitemid);
		}, 
		onFailure: function(){ 
			alert('Oops...mistake on server');
		} 
	});*/

	return false; 
}

/*
  * 
  * BY DM:Ajith - 23July2008
  function for getting all the programs under a SU
  * 
  * */
function getProgramsForSU(element1)
{

	var newlist = document.getElementById("programlist").value;
	//document.getElementById("programlist").value = "";
	if(document.getElementById(element1).style.display == 'none')
	{
		new Ajax.Request("/index.cfm?event=su.getprogramsforsu&newlist=" +newlist, { 
	
					onSuccess: function(t) { 
					
					//alert(t.responseText);
					Element.update(element1, t.responseText); 
					//Effect.Shake(element1);
					//Effect.toggle(element1, 'slide');
					Effect.Appear(element1);
					
					}, 
					onFailure: function(){ 
					alert('Oops...mistake on server');
					} 
				});
	}
	
}

/*
 * 
 * BY DM: 09Dec2008
 function for getting all the Currently active sites for a MC
 * 
 * */
function ShowActiveSites(element1)
{
	var activesitelist = document.getElementById("activesitelist").value;
	
	if(document.getElementById(element1).style.display == 'none')
	{
		$j.ajax({
			url: "/index.cfm?event=mc.getactivesites&activesitelist=" + activesitelist,
			method: "GET",  // Assuming you want to use GET request, you can change it to POST if needed
			success: function(t) {
			  $j('#ActiveSites').html(t);
			  $j('#ActiveSites').show();
			},
			error: function() {
			  alert('Oops... mistake on server');
			}
		  });
		/*new Ajax.Request("/index.cfm?event=mc.getactivesites&activesitelist=" +activesitelist, { 
			
			onSuccess: function(t) { 
			
			//alert(t.responseText);
			Element.update(element1, t.responseText); 
			//Effect.Appear(element1);
			//Effect.Appear(element1, 'slide');
			
			document.getElementById('ActiveSites').style.display = 'block';
			}, 
			onFailure: function(){ 
			alert('Oops...mistake on server');
			} 
		});*/
	}
	
}

function CloseProgramsForSU(element1)
{
	//Effect.Shake(element1);
	Effect.Fade(element1);
	//Effect.toggle(element1, 'slide');
	Effect.Appear(element1);
}

function ChangeLinkText(obj,associd)
{
	//alert(document.getElementById("asso_"+associd).value);
	var assoclist = document.getElementById("asso_"+associd).value;
	//alert(assoclist.length);
	if(assoclist.length > 0)
	{
		document.getElementById("checkButton"+associd).innerHTML = "Assigned";
	}
	else
	{
		document.getElementById("checkButton"+associd).innerHTML = "Assign";
	}
	/*if(obj.checked==true)
	{
		document.getElementById("checkButton"+associd).innerHTML = "Assigned";
	}
	else
	{
		document.getElementById("checkButton"+associd).innerHTML = "Assign";
	}*/
}

// Time Sheet Settings // 
function insertTemplateForm(element1,element2,element3,type,typetimesheet){
	//$("processing-indicator").show();
	//location of form
	new Ajax.Request("/index.cfm?event=association.associationitemstemplateform&element1=" + element1 + "&userid=" + element2 + "&element3=" + element3 + "&type=" + type + "&typetimesheet=" + typetimesheet, { 

		onSuccess: function(t) { 
			//$("processing-indicator").hide();
			Element.update(element1, t.responseText); 
			Effect.toggle(element1, 'slide');
		}, 
		onFailure: function(){ 
			alert('Oops...mistake on server');
		} 
	});

	return false; 
}

function processTemplateItem(element1,element2,element3,form_in,typetimesheet,user_id,creationuserid){
		
		//new Ajax.Request("/index.cfm?event=association.associationitemstemplateformprocess&typetimesheet=" + typetimesheet + "&tutor_id=" + user_id + "&creationuserid=" + creationuserid, {
		new Ajax.Request("/index.cfm?event=association.associationitemstemplateformprocess&typetimesheet=" + typetimesheet + "&userid=" + user_id + "&creationuserid=" + creationuserid, {
			method: "post",
			parameters: Form.serialize(form_in,true),
			onSuccess: function(t) {
				Effect.toggle(element1, 'slide');
				Element.update(element3,t.responseText);
				
				if(document.getElementById('a_delete_link'))
				{
					changeSetEditLink('edit');	
				}
				else
				{
					changeSetEditLink('set');	
				}
	    	},
			onFailure: function(){
				alert("Technical problems please try reloading page");
			}
		});
	
	return false;
}
