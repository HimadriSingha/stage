//this is the function to show the breAk by tutor area association wide
function BreakByTutorAssociationWideTimeSeries(allassociationitems, loadingImgId, TutorDataDivId, clickLinkId, questionID, beginSurvey, endSurvey, notSelectedIds, programList, associationitemidcollectionselected, showingstatus, showtutorstudentall, qsurveysiteuserid, thisElement, scope, questionType,omitattributelist,includetype_attribute, sites) {
	var BreakByTutorAssociationWideTimeSeries = "BreakByTutorAssociationWideTimeSeries_"+questionID;

		var BreakByTutorAssociationWideTimeSeriesId = document.getElementById(BreakByTutorAssociationWideTimeSeries);
		
		if (BreakByTutorAssociationWideTimeSeriesId.classList.contains('breakOutOtherThanAttribute')===true){
		BreakByTutorAssociationWideTimeSeriesId.classList.remove("breakOutOtherThanAttribute");
	if (document.getElementById(TutorDataDivId).style.display == 'none' || showingstatus == 'firsttimemain' || showingstatus == 'z-a' || showingstatus == 'a-z' || showingstatus == 'asc' || showingstatus == 'desc') {

		document.getElementById(loadingImgId).style.display = 'block';



		if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain') {
			document.getElementById(loadingImgId).style.display = 'none';

		} else {
			try{
				attributeString = (jQuery('#attributeString' + questionID).length > 0 ) ? jQuery('#attributeString' + questionID).val():'';
				neededAssociationItems = (jQuery('#theListOfAssociationItems' + questionID).length > 0 ) ? jQuery('#theListOfAssociationItems' + questionID).val() : '';
				allassociationitems = (jQuery('#hidden_allassociationitems').length > 0 ) ? jQuery('#hidden_allassociationitems').val():'';
				associationitemidcollectionselected = (jQuery('#hidden_associationitemidcollectionselected').length > 0 ) ? jQuery('#hidden_associationitemidcollectionselected').val():'';
				if(typeof getUrlVars == 'function'){
					parameterVar = getUrlVars(attributeString);
				}else{
					parameterVar = {};
				}	
				parameterVar = jQuery.extend({},parameterVar,{
					allassociationitems : allassociationitems, allassociations : neededAssociationItems, 
					associationitemidcollectionselected : associationitemidcollectionselected, qsurveysiteuserid : qsurveysiteuserid, scope : scope, sites : sites, 
					questionid : questionID, quid : questionID, beginsurvey : beginSurvey, endsurvey : endSurvey,notselectedids : notSelectedIds, 
					programlist : programList, showingstatus : showingstatus, showtutorstudentall : showtutorstudentall, 
					neededassociations : neededAssociationItems, questionType : questionType, 
					omitattributelist : omitattributelist, includetype_attribute : includetype_attribute
				});
			}
			catch(err){
				parameterVar = {
					allassociationitems: allassociationitems,
					associationitemidcollectionselected: associationitemidcollectionselected,
					qsurveysiteuserid: qsurveysiteuserid
				}
			}

			var attributeDiv = "AttributeDataDiv" + questionID;
			var attributeSelectionDiv = "AttributeSelectionDiv" + questionID;
			new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbytutorassociationwidetimeseries&questionid=" + questionID + "&beginsurvey=" + beginSurvey + "&endsurvey=" + endSurvey + "&notselectedids=" + notSelectedIds + "&programlist=" + programList + "&showingstatus=" + showingstatus + "&showtutorstudentall=" + showtutorstudentall), {
				method: 'post',
				parameters: parameterVar,
				onSuccess: function (returnHtml) {

					document.getElementById(loadingImgId).style.display = 'none';
					document.getElementById(clickLinkId).style.display = 'block';
					Element.update(TutorDataDivId, returnHtml.responseText);
					//Effect.toggle(TutorDataDivId, 'slide');
					/*if (showingstatus == 'firsttimemain')
						Effect.BlindDown(TutorDataDivId);*/
					if (jQuery('#' + attributeDiv).css('display') != 'none' && typeof (jQuery('#' + attributeDiv).css('display')) !== 'undefined') {
						jQuery('#' + attributeDiv).hide();
						jQuery('#' + attributeSelectionDiv).hide();
						if (showingstatus == 'firsttimemain') {
							document.getElementById(TutorDataDivId).style.display = 'block';
						}
					} else {
						jQuery('#' + attributeSelectionDiv).hide();
						if (showingstatus == 'firsttimemain')
							Effect.BlindDown(TutorDataDivId);
					}

				},
				onFailure: function () {
					alert('Oops...mistake on server');
				}
			});
		}




	} else {

		processAndCloseBreakBoxTimeAssociationWide(TutorDataDivId, loadingImgId);

	}
		}
}

function BreakByTutorAssociationWideTimeSeriesInner(allassociationitems, loadingImgId, TutorDataDivId, clickLinkId, questionID, beginSurvey, endSurvey, notSelectedIds, programList, associationitemidcollectionselected, showingstatus, showtutorstudentall, qsurveysiteuserid, thisElement, scope, questionType,omitattributelist,includetype_attribute, sites) {
	
	if (document.getElementById(TutorDataDivId).style.display == 'none' || showingstatus == 'firsttimemain' || showingstatus == 'z-a' || showingstatus == 'a-z' || showingstatus == 'asc' || showingstatus == 'desc') {

		document.getElementById(loadingImgId).style.display = 'block';



		if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain') {
			document.getElementById(loadingImgId).style.display = 'none';
            document.getElementById(clickLinkId).style.display = 'block';
		} else {
			try{
				attributeString = (jQuery('#attributeString' + questionID).length > 0 ) ? jQuery('#attributeString' + questionID).val():'';
				neededAssociationItems = (jQuery('#theListOfAssociationItems' + questionID).length > 0 ) ? jQuery('#theListOfAssociationItems' + questionID).val() : '';
				allassociationitems = (jQuery('#hidden_allassociationitems').length > 0 ) ? jQuery('#hidden_allassociationitems').val():'';
				associationitemidcollectionselected = (jQuery('#hidden_associationitemidcollectionselected').length > 0 ) ? jQuery('#hidden_associationitemidcollectionselected').val():'';
				if(typeof getUrlVars == 'function'){
					parameterVar = getUrlVars(attributeString);
				}else{
					parameterVar = {};
				}	
				parameterVar = jQuery.extend({},parameterVar,{
					allassociationitems : allassociationitems, allassociations : neededAssociationItems, 
					associationitemidcollectionselected : associationitemidcollectionselected, qsurveysiteuserid : qsurveysiteuserid, scope : scope, sites : sites, 
					questionid : questionID, quid : questionID, beginsurvey : beginSurvey, endsurvey : endSurvey,notselectedids : notSelectedIds, 
					programlist : programList, showingstatus : showingstatus, showtutorstudentall : showtutorstudentall, 
					neededassociations : neededAssociationItems, questionType : questionType, 
					omitattributelist : omitattributelist, includetype_attribute : includetype_attribute
				});
			}
			catch(err){
				parameterVar = {
					allassociationitems: allassociationitems,
					associationitemidcollectionselected: associationitemidcollectionselected,
					qsurveysiteuserid: qsurveysiteuserid
				}
			}

			var attributeDiv = "AttributeDataDiv" + questionID;
			var attributeSelectionDiv = "AttributeSelectionDiv" + questionID;
			new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbytutorassociationwidetimeseries&questionid=" + questionID + "&beginsurvey=" + beginSurvey + "&endsurvey=" + endSurvey + "&notselectedids=" + notSelectedIds + "&programlist=" + programList + "&showingstatus=" + showingstatus + "&showtutorstudentall=" + showtutorstudentall), {
				method: 'post',
				parameters: parameterVar,
				onSuccess: function (returnHtml) {

					document.getElementById(loadingImgId).style.display = 'none';
					document.getElementById(clickLinkId).style.display = 'block';
					Element.update(TutorDataDivId, returnHtml.responseText);
					//Effect.toggle(TutorDataDivId, 'slide');
					/*if (showingstatus == 'firsttimemain')
						Effect.BlindDown(TutorDataDivId);*/
					if (jQuery('#' + attributeDiv).css('display') != 'none' && typeof (jQuery('#' + attributeDiv).css('display')) !== 'undefined') {
						jQuery('#' + attributeDiv).hide();
						jQuery('#' + attributeSelectionDiv).hide();
						if (showingstatus == 'firsttimemain') {
							document.getElementById(TutorDataDivId).style.display = 'block';
						}
					} else {
						jQuery('#' + attributeSelectionDiv).hide();
						if (showingstatus == 'firsttimemain')
							Effect.BlindDown(TutorDataDivId);
					}

				},
				onFailure: function () {
					alert('Oops...mistake on server');
				}
			});
		}




	} else {

		processAndCloseBreakBoxTimeAssociationWide(TutorDataDivId, loadingImgId);

	}
		
}



function processAndCloseBreakBoxTimeAssociationWide(TutorDataDivId, loadingImgId) {

	document.getElementById(loadingImgId).style.display = 'block';

	Effect.Fade(TutorDataDivId);
	//Effect.toggle(TutorDataDivId, 'slide');
	Effect.BlindUp(TutorDataDivId);
	document.getElementById(loadingImgId).style.display = 'none';
	var questionID = parseInt(TutorDataDivId.match(/[0-9]+/)[0], 10);
	var BreakByTutorAssociationWideSelectRadio = "BreakByTutorAssociationWideSelectRadio_"+questionID;
    var BreakByResponseAssociationWideCheckBox = "BreakByResponseAssociationWideCheckBox_"+questionID;
	var BreakByStudentAssociationWideCheckBox = "BreakByStudentAssociationWideCheckBox_"+questionID;	
	var BreakByTutorAssociationWideNumberText = "BreakByTutorAssociationWideNumberText_"+questionID;
	var BreakByTutorAssociationWideTimeSeries = "BreakByTutorAssociationWideTimeSeries_"+questionID;
	var BreakByStudentAssociationWideSelectRadio = "BreakByStudentAssociationWideSelectRadio_"+questionID;
	var BreakByResponseAssociationWideSelectRadio = "BreakByResponseAssociationWideSelectRadio_"+questionID;
	var BreakByTutorAssociationWideNonNumericSelectRadio = "BreakByTutorAssociationWideNonNumericSelectRadio_"+questionID;
	var BreakByTutorAssociationWideNonNumericCheckBox = "BreakByTutorAssociationWideNonNumericCheckBox_"+questionID;
	var BreakByTutorAssociationWideSelectRadioId = document.getElementById(BreakByTutorAssociationWideSelectRadio);
	var BreakByTutorAssociationWideNonNumericCheckBoxId = document.getElementById(BreakByTutorAssociationWideNonNumericCheckBox);
    var BreakByResponseAssociationWideCheckBoxId = document.getElementById(BreakByResponseAssociationWideCheckBox);
		var BreakByTutorAssociationWideNumberTextId = document.getElementById(BreakByTutorAssociationWideNumberText);
		var BreakByStudentAssociationWideCheckBoxId = document.getElementById(BreakByStudentAssociationWideCheckBox);
		var BreakByTutorAssociationWideTimeSeriesId = document.getElementById(BreakByTutorAssociationWideTimeSeries);
		var BreakByResponseAssociationWideSelectRadioId = document.getElementById(BreakByResponseAssociationWideSelectRadio);
		var BreakByTutorAssociationWideNonNumericSelectRadioId = document.getElementById(BreakByTutorAssociationWideNonNumericSelectRadio);
		var BreakByStudentAssociationWideSelectRadioId = document.getElementById(BreakByStudentAssociationWideSelectRadio);
		if(BreakByTutorAssociationWideNumberTextId !== null)
         BreakByTutorAssociationWideNumberTextId.classList.add("breakOutOtherThanAttribute");
	    if(BreakByTutorAssociationWideSelectRadioId !== null)
         BreakByTutorAssociationWideSelectRadioId.classList.add("breakOutOtherThanAttribute");
	    if(BreakByResponseAssociationWideCheckBoxId !== null)
         BreakByResponseAssociationWideCheckBoxId.classList.add("breakOutOtherThanAttribute");
	     if(BreakByStudentAssociationWideCheckBoxId  !== null)
         BreakByStudentAssociationWideCheckBoxId .classList.add("breakOutOtherThanAttribute");
	    if(BreakByTutorAssociationWideTimeSeriesId  !== null)
         BreakByTutorAssociationWideTimeSeriesId .classList.add("breakOutOtherThanAttribute");
	    if( BreakByTutorAssociationWideNonNumericSelectRadioId  !== null)
          BreakByTutorAssociationWideNonNumericSelectRadioId .classList.add("breakOutOtherThanAttribute");
	    if( BreakByResponseAssociationWideSelectRadioId  !== null)
          BreakByResponseAssociationWideSelectRadioId .classList.add("breakOutOtherThanAttribute");
	    if( BreakByStudentAssociationWideSelectRadioId  !== null)
          BreakByStudentAssociationWideSelectRadioId .classList.add("breakOutOtherThanAttribute");
	    if( BreakByTutorAssociationWideNonNumericCheckBoxId  !== null)
          BreakByTutorAssociationWideNonNumericCheckBoxId.classList.add("breakOutOtherThanAttribute");



}