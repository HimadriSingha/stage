/*BG-244-SC:Start*/
var $body = $(document.body);
function closeRenameWindow(){	
    $body.css("overflow", "auto");
    ColdFusion.Window.destroy("RenameWindow");  
    window.location.reload();
}  
function updateAttributePositions(){};
function showAjaxError(){};
function showAjaxLoadingOverlay() {
    showLoadingOverlay();
}
function hideAjaxLoadingOverlay() {
    hideLoadingOverlay();
}
showAjaxError = function () {};
function validateField(){
    var itemvalue = $('#itemvalue').val();
    var dragtext = $("#dragtext").val();
    var attributeid = $("#attributeid").val();
    var dataStr = $("#dataStr").val();
    var attributelist = $("#attributelist").val();
    var panelDescription = $("#panelDescription").val();
    var attributelistarray = [];
    //console.log(dragtext);
    //console.log(attributeid);
    //console.log(dataStr);
    //console.log(attributelist);
    if(itemvalue.trim() != "" && (itemvalue.trim() != dragtext.trim()) && !/[^a-zA-Z0-9?\'\-()_/?${}(|) \:;@,.!*]/.test(itemvalue))
    {  
       attributelistarray = attributelist.split("$Comma$");
       for(counterK=0; counterK<attributelistarray.length; counterK++){
            if(itemvalue.toLowerCase().trim() == attributelistarray[counterK].toLowerCase().trim()){
                alert("Field with the same name already present in the "+panelDescription+". Please enter a unique name.");
                return false;
            }
       }
        
       showAjaxLoadingOverlay();
       $.ajax({
        type: "post",
        async:true,
        data: {attributeid:attributeid,attributename:itemvalue},
        url: "index.cfm?event=association.updateDragFieldPosition",		
        error: function(){console.log("error.")},
        success: function() {
            $.post("index.cfm?event=association.updateAttributePositions", {
                method: "handleArray",
                returnFormat: "plain",
                argumentCollection: dataStr
            },
                updateAttributePositions,
                "json"
            ).fail(showAjaxError)
            .always(getPanelRecordAfterInsertDelete, hideAjaxLoadingOverlay)
            closeRenameWindow();
            window.location.reload();
        }
        });
        
        return true; 
    }
    else{
        return false;  
    }    
}
/*BG-244-SC:Stops*/

/*
    id = #blankAttr is for not in use.
    class = .blankAttr is for attributes in use.

*/
/* Yeou : START */

var alNs = alNs || {};


/* Yeou : END */

/* Lucky : Start */
var globalQuid, $dialog = {};
var $loadingImageTable = '<table width="100%"><tr><td align="center"><img src="../../images/icons/animated_loading.gif"></td></tr></table>';
var $restoreLink = $('<a href="javascript:void(0)" style="display:none;" class="restoreThis">Restore</a>');

function dialogSettings(title, dialogClass, maxWidth, width, maxHeight, height) {
    return {
        modal: true,
        title: title,
        resizable: false,
        maxWidth: maxWidth,
        maxHeight: maxHeight,
        width: width,
        height: height,
        autoOpen: false,
        //position:['center',50],
        dialogClass: dialogClass,
	close: destroyDialog
    }
}

function destroyDialog() {
		$(this).empty();
}
	
$(document).ready(function () {
    /* Yeou : START */
    window_title = $('#window_title').val();//MCR-60
    alNs.panelObj = new alNs.AssociationDashboard(".sortablePanel");
    alNs.subPanelObj = new alNs.AssociationDashboard(".sortableSubPanel");
    alNs.layoutForObj = new alNs.AssociationDashboard("#layoutforboth");
    alNs.attributeObj = new alNs.AssociationDashboard(".column_left, .column_right, .column-full, .unused_attributes");

    /* Yeou : END */

    if ($('body').find('#ajaxFilterLoading').attr('id') != 'ajaxFilterLoading') {
        var html = '<div id="ajaxFilterLoading" style="display:none"><img id="loading" src="../../images/icons/animated_loading.gif"><div>';
        html += '<div></div></div><div class="bg"></div></div>'
        $('body').append(html);
    }

    var height = $('body').outerHeight();
    var width = $('body').outerWidth();
    $('#ajaxFilterLoading').css({
        'width': '100%',
        'height': '100%',
        'position': 'fixed',
        'z-index': '10000000',
        'top': '0',
        'left': '0'
    });

    $('#ajaxFilterLoading .bg').css({
        'background': '#000000',
        'opacity': '0.15',
        'width': '100%',
        'height': '100%',
        'position': 'absolute',
        'top': '0'
    });

    $('#ajaxFilterLoading > div:first').css({
        'width': '100%',
        'text-align': 'center',
        'position': 'absolute',
        'left': '0',
        'top': '48%',
        'font-size': '16px',
        'z-index': '10',
        'color': '#ffffff'
    });

    $dialog.CreateAssociationPanel = $('<div></div>').dialog(dialogSettings('Create a Panel', 'CreateAssociationPanel', 500, 500, 400, 360));
    $dialog.EditAssociationPanel = $('<div></div>').dialog(dialogSettings('Edit a Panel', 'CreateAssociationPanel', 500, 500, 400, 360));
    $dialog.CreateAssociationSubPanel = $('<div></div>').dialog(dialogSettings('Create a Sub-panel', 'CreateAssociationSubPanel', 500, 500, 380, 350));
    $dialog.EditAssociationSubPanel = $('<div></div>').dialog(dialogSettings('Edit a Sub-panel', 'CreateAssociationSubPanel', 500, 500, 380, 350));
    $dialog.CreateAssociationAttribute = $('<div></div>').dialog(dialogSettings('Create a New Field', 'CreateAssociationAttribute', 540, 540, 600, 600));
    $dialog.EditAttribute = $('<div></div>').dialog(dialogSettings('Edit Field', 'EditAttribute', 540, 540, 600, 600));
    $dialog.DeleteAssociationPanel = $('<div></div>').dialog(dialogSettings('Delete a Panel', 'DeleteAssociationPanel', 500, 500, 'auto', 'auto'));
    $dialog.DeleteAssociationSubPanel = $('<div></div>').dialog(dialogSettings('Delete a Sub-panel', 'DeleteAssociationSubPanel', 500, 500, 'auto', 'auto'));
    $dialog.CloneAssociationPanel = $('<div></div>').dialog(dialogSettings('Clone a Panel', 'CloneAssociationPanel', 500, 500, 380, 380));
    $dialog.CloneAssociationSubPanel = $('<div></div>').dialog(dialogSettings('Clone a Sub-panel', 'CloneAssociationSubPanel', 500, 500, 380, 350));
	/* Start: Lucky - Added for ASSNS-562 */
	$dialog.CopyAssociationDashboardLayout = $('<div></div>').dialog(dialogSettings('Copy '+window_title+' Dashboard Layout', 'CopyAssociationDashboardLayout', 720, 720, 600, 600));
	/* End: Lucky - Added for ASSNS-562 */
	$dialog.CopyAssociationDashboardLayoutValidation = $('<div></div>').dialog(dialogSettings('Copy '+window_title+' Dashboard Layout', 'CopyAssociationDashboardLayoutValidation', 600, 600, 500, 300));

    //BG-324 Create Content Block
    $dialog.CreateContentBlock = $('<div></div>').dialog(dialogSettings('Create a Context Block', 'CreateContentBlock', 620, 620, 500, 500));
    $dialog.EditContentBlock = $('<div></div>').dialog(dialogSettings('Edit a Context Block', 'EditContentBlock', 620, 620, 500, 500));
    $dialog.DeleteContentBlock = $('<div></div>').dialog(dialogSettings('Delete a Context Block', 'DeleteContentBlock', 500, 500, 200, 200));
    //BG-324 Create Content Block End

    function loadStatusHandler(status) {
        if (status == "error") {
            var msg = "Sorry but there was an error.";
            handledAlert(msg);
        }
    }

    function handledAlert(msg) {
        try {
            alert(msg);
        } catch (err) {}
    }

    $.fn.loadDialogContent = function (url) {
        this.load(url, {}, function (response, status, xhr) {
            loadStatusHandler(status);
        });
    }

    $(document).on('click', 'input.closeDialog', function () {
        var dialog = $(this).attr('data-dialog');
        if(typeof dialog != "undefined")/*BG-244-SC*/
        $dialog[dialog].dialog('close').empty();
        slideCounterAssociation = 0;//MV-1901
    });

    $(document).on('click', '#createassociationpanel', function (e) {
        e.stopPropagation();
	showLoadingOverlay();
        var associationid = $('#associationid').attr('value');
        var associationpanelid = $(this).attr('data-association-panel-id');
        var layoutfor = $('#layoutfor option:selected').attr('value');
        $dialog.CreateAssociationPanel.dialog('open')
            //.html($loadingImageTable)
            .loadDialogContent(root + 'association.createassociationpanelwindow&associationid=' + associationid + '&associationpanelid=' + associationpanelid + '&layoutfor=' + layoutfor);
	hideLoadingOverlay();
    });

    $(document).on('click', '#editassociationpanel', function (e) {
        e.stopPropagation();
	showLoadingOverlay();
        var associationid = $('#associationid').attr('value');
        var associationpanelid = $(this).attr('data-association-panel-id');
        var layoutfor = $('#layoutfor option:selected').attr('value');
        $dialog.EditAssociationPanel.dialog('open')
            //.html($loadingImageTable)
            .loadDialogContent(root + 'association.createassociationpanelwindow&associationid=' + associationid + '&associationpanelid=' + associationpanelid + '&layoutfor=' + layoutfor);
	hideLoadingOverlay();
    });

    $(document).on('click', '#createassociationsubpanel', function (e) {
        e.stopPropagation();
	showLoadingOverlay();
        var associationid = $('#associationid').attr('value');
        var associationsubpanelid = $(this).attr('data-association-subpanel-id');
        var layoutfor = $('#layoutfor option:selected').attr('value');
        $dialog.CreateAssociationSubPanel.dialog('open')
            //.html($loadingImageTable)
            .loadDialogContent(root + 'association.createassociationsubpanelwindow&associationid=' + associationid + '&associationsubpanelid=' + associationsubpanelid + '&layoutfor=' + layoutfor);
	hideLoadingOverlay();
    });

    $(document).on('click', '#editassociationsubpanel', function (e) {
        e.stopPropagation();
	showLoadingOverlay();
        var associationid = $('#associationid').attr('value');
        var associationsubpanelid = $(this).attr('data-association-subpanel-id');
        var layoutfor = $('#layoutfor option:selected').attr('value');
        $dialog.EditAssociationSubPanel.dialog('open')
            //.html($loadingImageTable)
            .loadDialogContent(root + 'association.createassociationsubpanelwindow&associationid=' + associationid + '&associationsubpanelid=' + associationsubpanelid + '&layoutfor=' + layoutfor);
	hideLoadingOverlay();
    });

    //BG-324  Create Content Block
    // $(document).on('click', '#createContentBlock', function(e) {
    //     e.stopPropagation();
    //     var associationid = $('#associationid').attr('value');

    //     $dialog.CreateContentBlock.dialog('open')
    //         .html($loadingImageTable)
    //         .loadDialogContent(root + 'associationsecond.createContentBlockWindow&contentBlockId=0&associationid=' + associationid);
            
           
    // });
    $(document).on('click', '#createContentBlock', function(e) {
        e.stopPropagation();
        showLoadingOverlay();
        $('body').addClass('addRemove-O-lay');
        var associationid = $('#associationid').attr('value');
         $.ajax({
             url:root + 'associationsecond.createContentBlockWindow&contentBlockId=0&associationid=' + associationid,
             type: "post",
             success: function(data) {
                 $('#abc').html(data).dialog({modal:false,title:"Create a Context Block",maxWidth:620, width:620, maxHeight:509, height:509});
                 
                 hideLoadingOverlay();
             }
             
         });
         $(document).on('click', '.ui-dialog-titlebar-close', function(e){
             $('body').removeClass('addRemove-O-lay');
 
         });
     });
 
    $(document).on('click', '#editContentBlock', function(e) {
         e.stopPropagation();
         $('body').addClass('addRemove-O-lay');
         var contentBlockId = $(this).attr('rel');
         var associationid = $('#associationid').val(); 
         $.ajax({
             url:root + 'associationsecond.createContentBlockWindow&contentBlockId=' + contentBlockId + '&associationid=' + associationid,
             type: "post",
             success: function(data) {
                 $('#abc').html(data).dialog({modal:false,title:"Create a Context Block",maxWidth:620, width:620, maxHeight:500, height:500});
                 
                 hideLoadingOverlay();
             }             
         });            
         $(document).on('click', '.ui-dialog-titlebar-close', function(e){
             $('body').removeClass('addRemove-O-lay');        
         });
     
     });
    // $(document).on('click', '#editContentBlock', function(e) {
    //     e.stopPropagation();
    //     var contentBlockId = $(this).attr('rel');
    //     var associationid = $('#associationid').val();

    //     $dialog.EditContentBlock.dialog('open')
    //         .html($loadingImageTable)
    //         .loadDialogContent(root + 'associationsecond.createContentBlockWindow&contentBlockId=' + contentBlockId + '&associationid=' + associationid);
    // });

    $(document).on('click', '#deleteContentBlock', function(e) {
        e.stopPropagation();
        var contentBlockId = $(this).attr('rel');
        var associationid = $('#associationid').val();
        $dialog.DeleteContentBlock.dialog('open')
            .html($loadingImageTable)
            .loadDialogContent(root + 'associationsecond.deleteContentAssociationBlockWindow&contentBlockId=' + contentBlockId + '&associationid=' + associationid);
    });
    //BG-324 Content Block End

    $(document).on('click', '#createassociationattribute', function(e) {
        e.stopPropagation();
	showLoadingOverlay();
        var associationid = $('#associationid').attr('value');
        var layoutfor = $('#layoutfor option:selected').attr('value');
        $dialog.CreateAssociationAttribute.dialog('open')
            //.html($loadingImageTable)
            .loadDialogContent(root + 'association.createtype3attributepopup&currentpage=manageassociationdashboard&associationid=' + associationid + '&layoutfor=' + layoutfor);
	hideLoadingOverlay();
    });

    $(document).on('click', '#editassociationattribute', function (e) {
        if(!$(this).hasClass("noClick")){
            e.stopPropagation();
            showLoadingOverlay();
                var associationid = $('#associationid').attr('value');
                var attributeid = $(this).attr('data-association-attr-id');
                var layoutfor = $('#layoutfor option:selected').attr('value');
            var attributename = $(this).attr('title');
               $dialog.EditAttribute.dialog(dialogSettings('Edit '+attributename, 'EditAttribute', 540, 540, 600, 600));
			   /* BG-85 :: Changed By Arun :: 09/25/2019 */
               /* $dialog.EditAttribute.dialog('open')
                    //.html($loadingImageTable)
                    .loadDialogContent(root + 'association.edittype3attributepopup&currentpage=manageassociationdashboard&associationid=' + associationid + '&attributeid=' + attributeid + '&layoutfor=' + layoutfor);
            hideLoadingOverlay();*/
			$.ajax({
				url: root + 'association.edittype3attributepopup&currentpage=manageassociationdashboard&associationid=' + associationid + '&attributeid=' + attributeid + '&layoutfor=' + layoutfor,
				type: "post",
				success: function (data) {            
				 $dialog.EditAttribute.dialog('open').html(data);
				 hideLoadingOverlay();
				}
			});
			/* BG-85 :: Changed By Arun :: 09/25/2019 */
        }
        
    });

    $(document).on('click', '#deleteassociationpanel', function (e) {
        e.stopPropagation();
	showLoadingOverlay();
        var associationid = $('#associationid').attr('value');
        var associationpanelid = $(this).attr('data-association-panel-id');
        var layoutfor = $('#layoutfor option:selected').attr('value');
        $dialog.DeleteAssociationPanel.dialog('open')
            //.html($loadingImageTable)
            .loadDialogContent(root + 'association.deleteassociationpanelwindow&associationid=' + associationid + '&associationpanelid=' + associationpanelid + '&layoutfor=' + layoutfor);
	hideLoadingOverlay();
    });

    $(document).on('click', '#deleteassociationsubpanel', function (e) {
        e.stopPropagation();
	showLoadingOverlay();
        var associationid = $('#associationid').attr('value');
        var subpanellid = $(this).attr('data-association-subpanel-id');
        var layoutfor = $('#layoutfor option:selected').attr('value');
        $dialog.DeleteAssociationSubPanel.dialog('open')
            //.html($loadingImageTable)
            .loadDialogContent(root + 'association.deleteassociationsubpanelwindow&associationid=' + associationid + '&associationsubpanelid=' + subpanellid + '&layoutfor=' + layoutfor);
	hideLoadingOverlay();
    });

    $(document).on('click', '#cloneassociationpanel', function (e) {

        e.stopPropagation();
        var associationid = $('#associationid').attr('value');
        var associationpanelid = $(this).attr('data-association-panel-id');
        var layoutfor = $('#layoutfor option:selected').attr('value');
        $dialog.CloneAssociationPanel.dialog('open')
            .html($loadingImageTable)
            .loadDialogContent(root + 'association.cloneassociationpanelwindow&associationid=' + associationid + '&associationpanelid=' + associationpanelid + '&layoutfor=' + layoutfor);
    });

    $(document).on('click', '#cloneassociationsubpanel', function (e) {

        e.stopPropagation();
        var associationid = $('#associationid').attr('value');
        var subpanellid = $(this).attr('data-association-subpanel-id');
        var layoutfor = $('#layoutfor option:selected').attr('value');
        $dialog.CloneAssociationSubPanel.dialog('open')
            .html($loadingImageTable)
            .loadDialogContent(root + 'association.cloneassociationsubpanelwindow&associationid=' + associationid + '&associationsubpanelid=' + subpanellid + '&layoutfor=' + layoutfor);
    });

    changeLayout(); //MCR-75
});

/* MCR-75 Start */

/* 
//Commented For MCR-195
$(document).on('change', '#layoutfor', function (e) {
    changeLayout();
});
*/

//Added For MCR-195
$(document).on('click', '#layoutfor-menu li div', function (e) {
    changeLayout();
});

function changeLayout()
{
    /* Yeou : START */
    alNs.layoutForObj.syncSortOrders();
    /* Yeou : END */

    var associationid = $('#associationid').val();
    var layoutfor = $('#layoutfor option:selected').val();
    var displayattributesnotinuse = "Hide";
	
    if(layoutfor == 0) {
    	$('#createassociationpanel').css("display","none");
		$('#createassociationsubpanel').css("display","none");
		$('#createassociationattribute').css("display","none");	
		/* Start: Lucky - Added for ASSNS-562 */
		$('.copydashboardlayout').css("display","none");
		/* End: Lucky - Added for ASSNS-562 */
		
    } else {
    	$('#createassociationpanel').css("display","block");
		$('#createassociationsubpanel').css("display","block");
		$('#createassociationattribute').css("display","block");
		/* Start: Lucky - Added for ASSNS-562 */
		$('.copydashboardlayout').css("display","block");
		/* End: Lucky - Added for ASSNS-562 */
    }

    var postdata = [];
    postdata.push({
        "name": "associationid",
        "value": associationid
    });
    postdata.push({
        "name": "layoutfor",
        "value": layoutfor
    });
    postdata.push({
        "name": "displayattributesnotinuse",
        "value": displayattributesnotinuse
    });
    loadAssociationLayout(postdata, layoutfor, displayattributesnotinuse);
}

/* MCR-75 End */

$(document).on('click', '#attributesnotinuse', function (e) {
    if ($('#attributesnotinuse').text() == 'Show') {
        $('#attributesnotinuselist').slideDown(1000);
        $('#attributesnotinuse').text('Hide');
    } else {
        $('#attributesnotinuselist').slideUp(1000);
        $('#attributesnotinuse').text('Show');
    }
});
// Added : SC Start
$(document).on('click', '.not-sortable .showHide', function (e) {

    var panal_obj = $(".not-sortable");
    if($(panal_obj).find(".showHide").hasClass("hideIt"))
    {
        //alert("hideIt");
        $(".catchSortable").addClass("not-sortable");
    }
    else if($(panal_obj).find(".showHide").hasClass("showIt"))
    {
        //alert("showIt");
        $(".catchSortable").removeClass("not-sortable");
    }
});
// Added : SC End
$(document).on('click', 'a.showHide', function (e) {
    var $headingDiv = $(this).closest('.dataGroupHeader');
    e.stopPropagation();
    if (!$headingDiv.hasClass('loading')) {
        $headingDiv.addClass('loading');
        var $link = $('a.showHide', $headingDiv);
        var $popupdiv = $('a.div.edit_panel', $headingDiv);
        var relValue = $link.attr('rel');
        if ($link.hasClass('hideIt')) {
            $link.siblings('.edit_panel').slideToggle('slow');
            $('.' + relValue).slideToggle('slow', function () {
                $headingDiv.removeClass('loading');
            });
            $link.toggleClass('hideIt showIt');
        } else {
            $link.siblings('.edit_panel').slideToggle('slow');
            $('.' + relValue).slideToggle('slow', function () {
                $headingDiv.removeClass('loading');
            });
            $link.toggleClass('hideIt showIt');
        }
    }
});


function showLoadingOverlay() {
    $('#ajaxFilterLoading .bg').height('100%');
    $('#ajaxFilterLoading').fadeIn(300);
    $("#ajaxFilterLoading").attr("tabindex", -1).focus();
}

function hideLoadingOverlay() {
    $('#ajaxFilterLoading .bg').height('100%');
    $('#ajaxFilterLoading').fadeOut(300);
}

function loadAssociationLayout(postdata, layoutfor, displayattributesnotinuse) {
    
    var layout=0;
    var userPanelCount = "";
    var userSubPanelCount = "";
    if(layoutfor == 1)
    { 
        layout = 1;
    }
    else if(layoutfor == 2)
    { 
        layout = 0;
    }
    var status = false;
    var _current_time_cache = new Date().getTime();
	var openedPanels = [];
	$('a.showHide').each(function(){		 
		if($(this).hasClass('hideIt')){				 
			panelId = $(this).attr('data-association-panel-id');
			openedPanels.push(panelId);
		}
	});
	postdata.push({
		"name": "openedPanels",
		"value": openedPanels
	});	
    $.ajax({
        type: "POST",
        url: "index.cfm?event=association.loadassoiationlayout&currenttimestamp=" + _current_time_cache+"&layout="+layout,
        data: postdata,
        beforeSend: function () {
            showLoadingOverlay();
        },
        success: function (panelsubpanelattribute) {
            if (layoutfor > 0) {
                $('#layoutboth').css("display", 'block');
                $('#associationlayout').html(panelsubpanelattribute);
                if (displayattributesnotinuse == 'Show') {
                    $('#attributesnotinuse').text('Show');
                    $('#attributesnotinuselist').css('display', 'none');
                } else {
                    $('#attributesnotinuse').text('Hide');
                    $('#attributesnotinuselist').css('display', 'block');
                }
            } else {
                $('#layoutboth').css("display", 'none');
                $('#associationlayout').html('');
            }
        },
        complete: function (panelsubpanelattribute) {
            hideLoadingOverlay();
            $("#layoutfor").val(layoutfor);
		/* ASSNS-562 - Start */
		userPanelCount = $('.userPanelCount').val();
		userSubPanelCount = $('.userSubPanelCount').val();			
		if(userPanelCount == '0' && userSubPanelCount == '0') {
			$('.copydashboardlayout').css('color','##999999');
			$('.copydashboardlayout').removeClass("copyDashboardLayoutPopup");
		} else {				
			//$('.copydashboardlayout').css('color','blue'); //MCR-76
			$('.copydashboardlayout').addClass("copyDashboardLayoutPopup");
		}
		/* ASSNS-562 - End */
			
            /* Yeou : START */

            alNs.panelObj.sortablePanel();
            alNs.subPanelObj.sortableSubPanel();
            alNs.attributeObj.sortableAttributes();
            /* Yeou : END */
        },
        error: function (data) {
            status = false;
        }
    });
    return status;
}

/* Added to restrict special Chars in Names */
function validateNames(string) {
    var specialChars = "<>@!#$%^+[]{}|\"\\~`="
    for (i = 0; i < specialChars.length; i++) {
        if (string.indexOf(specialChars[i]) > -1) {
            return true
        }
    }
    return false;
}

/* Lucky : End */

/* Yeou : START */

alNs.AssociationDashboard = function (ctl) {
    /* 
        if eqCtl === sortablePanel {sortablePanel}
        if eqCtl === sortableSubPanel {sortableSubPanel}
        
    */
    this.eqCtl = ctl;
    this.panelStartIndex = 0;
    this.panelEndIndex = 0;

    this.subPanelStartIndex = 0;
    this.subPanelEndIndex = 0;

    this.attributeStartIndex = 0;
    this.attributeEndIndex = 0;

    this.attributeStartClass = "";
    this.attributeEndClass = "";

    this.prevParent = "";

};

alNs.AssociationDashboard.prototype = function () {
    var sortablePanel = function () {
        $(this.eqCtl).sortable({
            axis: 'y',
            placeholder: "placeHolder",
            cursor: "move",
            opacity: 0.7,
            forceHelperSize: true,
            forcePlaceholderSize: true,
            items: ".groupContainer:not(.not-sortable):not(.catchSortable)",
            cancel: "img,a,.not-sortable,.columngroup-full-width,.catchSortable",
            start: startSortablePanel,
            stop: stopSortablePanel
        }).disableSelection();
    },
        sortableSubPanel = function () {
            $(this.eqCtl).sortable({
                axis: 'y',
                placeholder: "placeHolder",
                cursor: "move",
                opacity: 0.7,
                forceHelperSize: true,
                forcePlaceholderSize: true,
                placeholder: "placeHolder",
                cancel: "img,a,.not-sortable",
                start: startSortableSubPanel,
                stop: stopSortableSubPanel
            }).disableSelection();
        },
        sortableAttributes = function () {
            $(this.eqCtl).sortable({
                axis: '',
                cursor: "move",
                opacity: 0.7,
                forceHelperSize: true,
                forcePlaceholderSize: true,
                connectWith: ".connectedSortable",
                placeholder: "placeHolder_rgt",
                //helper : 'clone',
                //items: ".panelgroup:not(.not-sortable), .columngroup:not(.not-sortable), .panelgroup-full:not(.not-sortable)",
                cancel:".not-sortable",
                start: startSortableAttributes,
                stop: stopSortableAttributes
            }).disableSelection();
        },
        startSortablePanel = function (event, ui) {
            // panelStartIndex = index-1 because first panel is not sortable
            this.panelStartIndex = ui.item.index() - 1;

            ui.placeholder.width(ui.item.width() - 10);
            ui.placeholder.addClass('placeHolder');
        },
        stopSortablePanel = function (event, ui) {
            // panelEndIndex = index-1 because first panel is not sortable
            this.panelEndIndex = ui.item.index() - 1;

            /*
                layoutFor : 1 , 2
                1: Layout for staff
                2: Layout for volunteer

                layoutForBoth : true
                if true layout same for both staff and volunteer
            */
            var elements = $(this).sortable('toArray'),
                layoutFor = $("#layoutfor").val(),
                layoutForBoth = $("#layoutforboth").prop("checked"),
                panelId = 0,
                currCtl = "";

            //Update UI
            var minIndex = 0,
                maxIndex = 0;

            if (this.panelEndIndex < this.panelStartIndex) {
                minIndex = this.panelEndIndex;
                maxIndex = this.panelStartIndex;
            } else {
                minIndex = this.panelStartIndex;
                maxIndex = this.panelEndIndex;
            }

            //data is post data for ajax call.
            var data = {};
            data.panelDataList = [];

            for (i = minIndex; i <= maxIndex; ++i) {
                currCtl = "#" + elements[i];
                $(currCtl).attr("data-panel-sort-order", i + 2);

                //Add panel data that needs to be updated in database
                var panelData = {};
                panelData.panelId = $(currCtl).attr("data-association-panel-id");
                panelData.sortOrder = $(currCtl).attr("data-panel-sort-order");
                data.panelDataList.push(panelData);
            }

            data.layoutFor = layoutFor;
            data.layoutForBoth = layoutForBoth;
            data.panelDataListLength = data.panelDataList.length;
            //Update database
            if (minIndex != maxIndex) {
                showAjaxLoadingOverlay();
                $.post("index.cfm?event=association.updatePanelSortOrders",
                        data,
                        updatePanelSortOrders,
                        "json"
                    )
                    .fail(showAjaxError)
                    .always(hideAjaxLoadingOverlay);
            }
        },
        startSortableSubPanel = function (event, ui) {
            // subPanelStartIndex = index because first subpanel is sortable
            this.subPanelStartIndex = ui.item.index();

            ui.placeholder.width(ui.item.width() - 10);
            ui.placeholder.addClass('placeHolder');
        },
        stopSortableSubPanel = function (event, ui) {
            // subPanelStartIndex = index because first subpanel is sortable
            this.subPanelEndIndex = ui.item.index();

            var elements = $(this).sortable('toArray'),
                layoutFor = $("#layoutfor").val(),
                layoutForBoth = $("#layoutforboth").prop("checked"),
                currCtl = "";

            //Update UI
            var minIndex = 0,
                maxIndex = 0;

            if (this.subPanelEndIndex < this.subPanelStartIndex) {
                minIndex = this.subPanelEndIndex;
                maxIndex = this.subPanelStartIndex;
            } else {
                minIndex = this.subPanelStartIndex;
                maxIndex = this.subPanelEndIndex;
            }

            //data is post data for ajax call.
            var data = {};
            data.panelId = $("#" + elements[minIndex]).attr("data-association-panel-id");
            data.subPanelDataList = [];

            for (i = minIndex; i <= maxIndex; ++i) {
                currCtl = "#" + elements[i];
                /*
                    data-subpanel-sort-order = index+2 because index start from 0 
                    and default subpanel has sortorder 1
                */
                $(currCtl).attr("data-subpanel-sort-order", i + 2);

                var subPanelData = {};
                subPanelData.subPanelId = $(currCtl).attr("data-association-subpanel-id");
                subPanelData.sortOrder = $(currCtl).attr("data-subpanel-sort-order");
                data.subPanelDataList.push(subPanelData);
            }

            data.layoutFor = layoutFor;
            data.layoutForBoth = layoutForBoth;
            data.subPanelDataListLength = data.subPanelDataList.length;
            //Update database
            if (minIndex != maxIndex) {
                showAjaxLoadingOverlay();
                $.post("index.cfm?event=association.updateSubPanelSortOrders",
                        data,
                        updateSubPanelSortOrders,
                        "json"
                    )
                    .fail(showAjaxError)
                    .always(hideAjaxLoadingOverlay);
            }
        },
        startSortableAttributes = function (event, ui) {
            this.attributeStartIndex = ui.item.index();
            ui.item.data('start_pos', ui.item.index());
            ui.item.find("#editassociationattribute").addClass("noClick");
            var itemCtr = $(ui.item);
            this.prevParent = itemCtr.parent();
        },
        stopSortableAttributes = function (event, ui) {
            
            //BG-244-SC:Start
            var dragtext = "";
            var attributeid = "";
            var panelDescription = "";
            var duprecord = false;
            var ui_item = $(ui.item);
            var attr_id = ui_item.attr("data-association-attr-id");
            var attributearray = "";
            var attributelist = "";
            if($("a[data-association-attr-id='"+attr_id+"']").hasClass("noClick"))
            {
                $("a[data-association-attr-id='"+attr_id+"']").removeClass("noClick");
            }
            var attrid = "#"+ui_item.attr("id");
            var outerDiv = $(attrid).parent().parent().children()[0];
            var temp_attr_list = "";
            if($(outerDiv).hasClass("previous_panel_desc")){
                var tempDivs = $(attrid+" :not(.unused_attr)").parent().parent(); 
                for(x=0; x<tempDivs.length; x++){ 
                    var tempChildDivs = tempDivs[x];
                    var target_class = $(tempChildDivs).attr("class").split(" ")[0];
                    if((target_class == "column-full") || (target_class == "column_left") || (target_class == "column_right")){
                        var tempChildEach = $(tempChildDivs).parent().children();
                        for(y=0; y<tempChildEach.length; y++){ 
                            var tempChildDivs = $(tempChildEach[y]).children();
                            for(s=0; s<tempChildDivs.length; s++){
                                var tempLastDivs = tempChildDivs[s];
                                var temp_data_attributename = $(tempLastDivs).find("a").prop("title");
                                temp_attr_list = temp_attr_list + temp_data_attributename + "$Comma$";
                            } 
                        }
                    }
                }
                var z = 0;
                var temp_attr_list_arr = temp_attr_list.split("$Comma$");
                var temp_attr_list_arrnew = [];
                for(k=0; k<temp_attr_list_arr.length; k++){
                    if(temp_attr_list_arr[k] != "null"){
                        if(temp_attr_list_arr[k] !== "undefined"){
                        temp_attr_list_arrnew[z] = temp_attr_list_arr[k].toLowerCase();
                        z++;
                        }
                    }
                }
                if(chkDuplicates(temp_attr_list_arrnew,true)  && $(attrid).parent().hasClass("unused_attributes") == false ){ 
                    dragtext =  $(attrid).find("span").prop("title");
                    attributeid = $(attrid).attr("data-association-attr-id");
                    panelDescription = "User Panel";
                    duprecord = true;
                    attributearray = temp_attr_list_arrnew;
                    console.log("dragtext : "+dragtext+", attributeid : "+attributeid+",temp_attr_list_arrnew : "+temp_attr_list_arrnew);
                }
            }
            else
            {
                var parentDivs = $(attrid).parent().parent().children();
                var attr_list = "";
                for(i=0; i<parentDivs.length; i++){
                    var childEach = $(parentDivs[i]).children();
                    for(j=0; j<childEach.length; j++){ 
                        var childDivs = childEach[j];
                        var data_attributename = $(childDivs).find("a").prop("title");
                        attr_list = attr_list + data_attributename + "$Comma$";
                    }
                }
                var z = 0;
                var attr_list_arr = attr_list.split("$Comma$");
                var attr_list_arrnew = [];
                for(k=0; k<attr_list_arr.length; k++){
                    if(attr_list_arr[k] != "null"){
                        if(attr_list_arr[k] != "undefined"){
                            attr_list_arrnew[z] = attr_list_arr[k].toLowerCase();
                            z++;
                        }
                    }
                }
                if(chkDuplicates(attr_list_arrnew,true) && $(attrid).parent().hasClass("unused_attributes") == false ){
                    dragtext =  $(attrid).find("a").prop("title");
                    attributeid = $(attrid).attr("data-association-attr-id");
                    panelDescription = "User Panel";
                    duprecord = true;
                    attributearray = attr_list_arrnew;
                    console.log("dragtext : "+dragtext+", attributeid : "+attributeid+",attr_list_arrnew : "+attr_list_arrnew);
                }
                else if($(attrid).parent().hasClass("unused_attributes") == true ){
                     var attr_list_arrnew_unused = [];
                     var counterX = 0;
                     for(counterY=0; counterY<attr_list_arrnew.length; counterY++){
                        if(attr_list_arrnew[counterY].length != 0){
                            if(attr_list_arrnew[counterY] !== "undefined"){
                            attr_list_arrnew_unused[counterX] = attr_list_arrnew[counterY];
                            counterX++;
                            }
                        } 
                     }
                    if(chkDuplicates(attr_list_arrnew_unused,true)){
                        dragtext =  $(attrid).find("a").prop("title");
                        attributeid = $(attrid).attr("data-association-attr-id");
                        panelDescription = "Unused Fields";
                        duprecord = true;
                        attributearray = attr_list_arrnew_unused;
                        console.log("dragtext : "+dragtext+", attributeid : "+attributeid+",attr_list_arrnew_unused : "+attr_list_arrnew_unused);
                    }
                }
            }
            function chkDuplicates(arr,justCheck){
                var len = arr.length, tmp = {}, arrtmp = arr.slice(), dupes = [];
                arrtmp.sort();
                while(len--){
                    var val = arrtmp[len];
                    if (/nul|nan|infini/i.test(String(val))){
                    val = String(val);
                    }
                    if (tmp[JSON.stringify(val)]){
                        if (justCheck) {return true;}
                        dupes.push(val);
                    }
                    tmp[JSON.stringify(val)] = true;
                }
                return justCheck ? false : dupes.length ? dupes : null;
            } 
            //BG-244-SC:Stops

            var attrdata = $(ui.item).children().children();
            //console.log("Stop");
            attributeAdded(attrdata);// Added : SC
            setTimeout(function () { ui.item.find("#editassociationattribute").removeClass("noClick"); }, 300);
            //if full dropped on right cancel the drop.
            if (($(ui.item).hasClass('panelgroup-full') || $(ui.item).attr("data-col-width") == 2) && $(ui.item).parent().hasClass("column_right")) {
                $(this).sortable("cancel");
            }
            if ($(ui.item).hasClass('previous_panel_name')) {
                console.log("previous_panel_name");
            }

            this.attributeEndIndex = ui.item.index();
            var start_pos = ui.item.data('start_pos');

            var prevAttributes = "";
            var currAttributes = "";

            var itemCtr = $(ui.item),
                elements = "",
                columnWidth = itemCtr.attr("data-col-width");

            var column_full_html = "<div class='column-full connectedSortable'></div>";
            var column_left_html = "<div class='column_left connectedSortable'></div>";
            column_right_html = "<div class='column_right connectedSortable'></div>";
            var column_right_with_blank_html = "<div class='column_right connectedSortable'>" +
                "<div class='panelgroup blankAttr not-sortable' data-row-number='0' data-col-number='0' data-col-width='1'>" +
                "<div class='attrItemdata_attr_Name'>" +
                "<label class='pull-left label-pdg'>&nbsp;</label>" +
                "</div></div></div>";

            var noAttributesAddedText = "<div class='column_left connectedSortable'>" +
                "<div class='panelgroup not-sortable noAttributesAdded' data-row-number='1' data-col-number='1' data-col-width='1'>" +
                "<div class='attrItemdata_attr_Name'>" +
                "<label class='pull-left label-pdg'>(No Fields Added)</label>" +
                "</div></div></div>" +
                "<div class='column_right connectedSortable'>" +
                "<div class='panelgroup blankAttr not-sortable' data-row-number='1' data-col-number='1' data-col-width='1'>" +
                "<div class='attrItemdata_attr_Name'>" +
                "<label class='pull-left label-pdg'>&nbsp;</label>" +
                "</div></div></div>";

            var blankAttr_html = "<div class='panelgroup blankAttr not-sortable' data-row-number='0' data-col-number='0' data-col-width='1'>" +
                "<div class='attrItemdata_attr_Name'>" +
                "<label class='pull-left label-pdg'>&nbsp;</label>" +
                "</div></div>";

            var parentClass = itemCtr.parent().attr("class").split(" ")[0];

            switch (parentClass) {
                case "unused_attributes":
                    {
                        itemCtr.addClass("columngroup inline-block");
                        itemCtr.removeClass("panelgroup");
                        itemCtr.removeClass("panelgroup-full");

                        itemCtr.attr("data-col-number", 0);
                        itemCtr.attr("data-row-number", 0);


                        var attrCount = $(".unused_attributes > .columngroup").length;
                        if (attrCount > 1) {
                            $("#none_available_unused_attributes").hide();
                        }

                        prevAttributes = sortDataRowNumberForEachAttributes(this.prevParent);
                        currAttributes = sortDataRowNumberForEachAttributes(itemCtr.parent());
                        sortNotInUseAlphabetically();
                        break;
                    }
                case "column_left":
                case "column_right":
                    {
                        // When full is dropped on half.
                        if (columnWidth == 2) {
                            itemCtr.removeClass("columngroup inline-block");
                            itemCtr.addClass("panelgroup-full");

                            var minIndex = 0,
                                maxIndex = itemCtr.parent().children().length - 2;
                            index = itemCtr.index();
                            var attr = $(itemCtr).attr("id");
                            if (parentClass == "column_left") {
                                if (index == minIndex) {
                                    if (!itemCtr.parent().prev().hasClass("column-full")) {
                                        itemCtr.parent().parent().prepend(column_full_html);
                                    }
                                    itemCtr.parent().prev().append(itemCtr);

                                } else if (index > maxIndex) {
                                    if (!itemCtr.parent().next().next().hasClass("column-full")) {
                                        itemCtr.parent().parent().append(column_full_html);
                                    }
                                    itemCtr.parent().next().next().append(itemCtr);
                                } else {
                                    var prevSiblings = $(".column_left > #" + attr).prevAll();
                                    var nextSiblings = $(".column_left > #" + attr).nextAll();
                                    var currentParent = $(".column_left > #" + attr).parent();
                                    var range = currentParent.next().children().length;
                                    var nextSiblingsOfRight = currentParent.next().children().slice(index, range);
                                    currentParent.next().after(column_full_html + column_left_html + column_right_html);
                                    currentParent.next().next().next().append(nextSiblings);
                                    currentParent.next().next().append(itemCtr);

                                    currentParent.next().next().next().next().append(nextSiblingsOfRight);
                                }
                            }
                        }
                        if (columnWidth == 1) {
                            itemCtr.removeClass("columngroup inline-block");
                            itemCtr.addClass("panelgroup");
                        }

                        if (parentClass == "column_left") {
                            itemCtr.attr("data-col-number", 1);
                        } else {
                            itemCtr.attr("data-col-number", 2);
                        }

                        if (!this.prevParent.hasClass("unused_attributes")) {
                            prevAttributes = sortDataRowNumberForEachAttributes(this.prevParent);
                        }
                        currAttributes = sortDataRowNumberForEachAttributes(itemCtr.parent());
                        sortNotInUseAlphabetically();

                        var attrCount = $(".unused_attributes > .columngroup").length;
                        showNoneAvailableAttributeText(attrCount);
                        break;
                    }
                case "column-full":
                    {
                        //When half is dropped on full.
                        if (columnWidth == 1) {
                            itemCtr.removeClass("columngroup inline-block");
                            itemCtr.addClass("panelgroup");

                            var minIndex = 0,
                                index = itemCtr.index(),
                                maxIndex = itemCtr.parent().children().length - 2;

                            var attr = $(itemCtr).attr("id");
                            if (index == minIndex) {
                                if (!itemCtr.parent().prev().hasClass("column_right")) {
                                    itemCtr.parent().parent().prepend(column_left_html + column_right_with_blank_html);
                                }

                                itemCtr.parent().prev().prev().append(itemCtr);

                            } else if (index > maxIndex) {
                                if (!itemCtr.parent().next().hasClass("column_left")) {
                                    itemCtr.parent().parent().append(column_left_html + column_right_with_blank_html);
                                }
                                itemCtr.parent().next().append(itemCtr);

                            } else {
                                var nextSiblings = $(".column-full > #" + attr).nextAll();
                                var currentParent = $(".column-full > #" + attr).parent();
                                currentParent.after(column_left_html + column_right_with_blank_html + column_full_html);

                                currentParent.next().next().next().append(nextSiblings);
                                currentParent.next().append(itemCtr);

                            }
                        }
                        if (columnWidth == 2) {
                            itemCtr.removeClass("columngroup inline-block");
                            itemCtr.addClass("panelgroup-full");
                        }

                        itemCtr.attr("data-col-number", 1);

                        if (!this.prevParent.hasClass("unused_attributes")) {
                            prevAttributes = sortDataRowNumberForEachAttributes(this.prevParent);
                        }
                        currAttributes = sortDataRowNumberForEachAttributes(itemCtr.parent());

                        sortNotInUseAlphabetically();

                        var attrCount = $(".unused_attributes > .columngroup").length;
                        showNoneAvailableAttributeText(attrCount);
                        break;
                    }
                default:
                    {
                        $(itemCtr).addClass("panelgroup");
                        $(itemCtr).removeClass("columngroup inline-block");
                        break;
                    }
            }

            //Handle Blanks - START
            $(".not-sortable").removeClass("ui-sortable-handle");
            if (itemCtr.parents(".panel_row").get(0) === this.prevParent.parents(".panel_row").get(0)) {
                var column_left_array = itemCtr.parents(".panel_row").children(".column_left");
                var column_left_array_length = column_left_array.length;

                for (var i = 0; i < column_left_array_length; ++i) {
                    var column_left = column_left_array[i];
                    var diffInNoOfAttributes = 0;
                    diffInNoOfAttributes = $(column_left).children(".ui-sortable-handle").length - $(column_left).next().children(".ui-sortable-handle").length;
                    $(column_left).children(".blankAttr").remove();
                    $(column_left).next().children(".blankAttr").remove();
                    if (diffInNoOfAttributes < 0) {
                        //Add blanks to left
                        for (var j = 0; j < Math.abs(diffInNoOfAttributes); ++j) {
                            $(column_left).append(blankAttr_html);
                        }
                    } else if (diffInNoOfAttributes > 0) {
                        //Add blanks to right
                        for (var j = 0; j < Math.abs(diffInNoOfAttributes); ++j) {
                            $(column_left).next().append(blankAttr_html);
                        }
                    }
                }
            } else {
                //Current Parent
                var column_left_array = itemCtr.parents(".panel_row").children(".column_left");
                var column_left_array_length = column_left_array.length;

                for (var i = 0; i < column_left_array_length; ++i) {
                    var column_left = column_left_array[i];
                    var diffInNoOfAttributes = 0;
                    diffInNoOfAttributes = $(column_left).children(".ui-sortable-handle").length - $(column_left).next().children(".ui-sortable-handle").length;
                    $(column_left).children(".blankAttr").remove();
                    $(column_left).next().children(".blankAttr").remove();
                    if (diffInNoOfAttributes < 0) {
                        //Add blanks to left
                        for (var j = 0; j < Math.abs(diffInNoOfAttributes); ++j) {
                            $(column_left).append(blankAttr_html);
                        }
                    } else if (diffInNoOfAttributes > 0) {
                        //Add blanks to right
                        for (var j = 0; j < Math.abs(diffInNoOfAttributes); ++j) {
                            $(column_left).next().append(blankAttr_html);
                        }
                    }
                }

                //Previous Parent
                var prev_column_left_array = this.prevParent.parents(".panel_row").children(".column_left");
                var prev_column_left_array_length = prev_column_left_array.length;

                for (var i = 0; i < prev_column_left_array_length; ++i) {
                    var prev_column_left = prev_column_left_array[i];
                    var diffInNoOfAttributes = 0;
                    diffInNoOfAttributes = $(prev_column_left).children(".ui-sortable-handle").length - $(prev_column_left).next().children(".ui-sortable-handle").length;
                    $(prev_column_left).children(".blankAttr").remove();
                    $(prev_column_left).next().children(".blankAttr").remove();
                    if (diffInNoOfAttributes < 0) {
                        //Add blanks to left
                        for (var j = 0; j < Math.abs(diffInNoOfAttributes); ++j) {
                            $(prev_column_left).append(blankAttr_html);
                        }
                    } else if (diffInNoOfAttributes > 0) {
                        //Add blanks to right
                        for (var j = 0; j < Math.abs(diffInNoOfAttributes); ++j) {
                            $(prev_column_left).next().append(blankAttr_html);
                        }
                    }
                }
            }
            //Handle Blanks - END

            //Check if Attributes are present - START

            if (this.prevParent.parents(".panel_row").find(".ui-sortable-handle").length == 0) {
                this.prevParent.parents(".panel_row").append(noAttributesAddedText);
            }

            if (itemCtr.parents(".panel_row").find(".ui-sortable-handle").length > 0 && itemCtr.parents(".panel_row").find(".noAttributesAdded").length > 0) {
                itemCtr.parents(".panel_row").find(".noAttributesAdded").remove();
                if (itemCtr.parent().hasClass("column-full")) {
                    itemCtr.parents(".panel_row").find(".column_left").remove();
                    itemCtr.parents(".panel_row").find(".column_right").remove();
                }
                removeAttribute(this);// Added : SC
            }
            else {
                removeAttribute(this);// Added : SC
            }

            //Check if Attributes are present - END

            //Reinitialize Attribute Sortable.
            alNs.attributeObj.sortableAttributes();

            //Remove Junk Divs (blank column-full, column_left, column_right) - START

            var column_left_empty = $(".column_left:not(:has(*))");
            var column_right_empty = $(".column_right:not(:has(*))");
            var column_full_empty = $(".column-full:not(:has(*))");

            var column_left_empty_length = column_left_empty.length;
            var column_right_empty_length = column_right_empty.length;
            var column_full_empty_length = column_full_empty.length;

            for (var i = 0; i < column_left_empty_length; ++i) {
                var curr_column_left = column_left_empty[i];
                if ($(curr_column_left).prev().hasClass("column-full") && $(curr_column_left).next().next().hasClass("column-full")) {

                    $(curr_column_left).prev().append($(curr_column_left).next().next().children());
                    $(curr_column_left).next().next().remove();
                    //$(curr_column_left).next().remove();
                    //$(curr_column_left).remove();
                }
            }

            for (var i = 0; i < column_full_empty_length; ++i) {
                var curr_column_full = column_full_empty[i];
                if ($(curr_column_full).prev().prev().hasClass("column_left") && $(curr_column_full).next().hasClass("column_left")) {
                    $(curr_column_full).prev().prev().append($(curr_column_full).next().children());
                }

                if ($(curr_column_full).prev().hasClass("column_right") && $(curr_column_full).next().next().hasClass("column_right")) {
                    $(curr_column_full).prev().append($(curr_column_full).next().next().children());
                }

                var left_blanks = $(curr_column_full).prev().prev().children(".blankAttr").detach();
                var right_blanks = $(curr_column_full).prev().children(".blankAttr").detach();
                $(curr_column_full).prev().prev().append(left_blanks);
                $(curr_column_full).prev().append(right_blanks);
            }
            $(".column_left:not(:has(*))").detach();
            $(".column_right:not(:has(*))").detach();
            $(".column-full:not(:has(*))").detach();

            //Remove Junk Divs (blank column-full, column_left, column_right) - END



            //START : Update database with attribute possitons (column, row)
            var data = {};
            if (!this.prevParent.hasClass("unused_attributes")) {
                prevAttributes = sortDataRowNumberForEachAttributes(this.prevParent);
            }
            currAttributes = sortDataRowNumberForEachAttributes(itemCtr.parent());

            data.prevAttributes = prevAttributes;
            data.currAttributes = currAttributes;
            data.associationid = $("#associationid").val();
            data.layoutFor = $("#layoutfor").val();
            data.layoutForBoth = $("#layoutforboth").prop("checked");
            var layout = $("#layoutfor").val();
			var currentattributeidappend = "";
			var previousattributeidappend = "";
            /*BG-244-SC:Start*/
            //console.log("dragtext : "+dragtext);
            //console.log("attributeid : "+attributeid);
            //console.log("panelDescription : "+panelDescription);
            //console.log("duprecord : "+duprecord);
            //console.log(currAttributes);
            for(counterZ=0; counterZ<attributearray.length; counterZ++){
                if(attributearray[counterZ].length != 0){
                    //console.log(attributearray[counterZ]);
                    attributelist += attributearray[counterZ] + "$Comma$";
                }
            }
            //console.log(attributelist);
            var current_panel_id = currAttributes[0]["associationPanelId"];
            var current_subpanel_id = currAttributes[0]["associationSubPanelId"];
            var previous_panel_id;
			var previous_subpanel_id;
			$("#fieldvalues_"+current_panel_id).val(" ");
			if(typeof current_subpanel_id != "undefined")
			{
				$("#Subfieldvalues_"+current_subpanel_id).val(" ");
            }
			if (prevAttributes.length != 0)
			{
				previous_panel_id = prevAttributes[0]["associationPanelId"];
				previous_subpanel_id = prevAttributes[0]["associationSubPanelId"];
			}
			
            if(typeof current_panel_id != "undefined" && typeof current_subpanel_id == "undefined"){
				if(currAttributes.length == 1)
				{
					$("<input>").attr({
					name: "fieldvalues_"+current_panel_id,
					id: "fieldvalues_"+current_panel_id,
					value: currAttributes[0]["attributeid"],
					type: "hidden",
					}).appendTo(".AssociationPanel"+current_panel_id);
				}
				else if(currAttributes.length > 1)
				{
					for (var i = 0; i < currAttributes.length; ++i) 
					{
						var temp;
						if (currAttributes.length-1 == i)
						{
							temp = currAttributes[i]["attributeid"]
						}
						else
						{
							temp = currAttributes[i]["attributeid"]+"~";
						}
						currentattributeidappend = currentattributeidappend + temp
					
					}
					$("#fieldvalues_"+current_panel_id).val(currentattributeidappend);
				}
				
				$("#fieldvalues_"+previous_panel_id).val(" ");
				if(typeof previous_subpanel_id != "undefined")
				{
				    $("#Subfieldvalues_"+previous_subpanel_id).val(" ");
				}
                
            }
            else if(typeof current_subpanel_id != "undefined") 
            {
				 if(currAttributes.length == 1)
				{
					$("<input>").attr({
					name: "Subfieldvalues_"+current_subpanel_id,
					id: "Subfieldvalues_"+current_subpanel_id,
					value: currAttributes[0]["attributeid"],
					type: "hidden",
					}).appendTo("#subpanel"+current_subpanel_id);
				}
				else if(currAttributes.length > 1)
				{
					for (var i = 0; i < currAttributes.length; ++i) {
						var temp;
						if (currAttributes.length-1 == i)
						{
							temp = currAttributes[i]["attributeid"]
						}
						else
						{
							temp = currAttributes[i]["attributeid"]+"~";
						}
						currentattributeidappend = currentattributeidappend + temp
					}
					$("#Subfieldvalues_"+current_subpanel_id).val(currentattributeidappend);
				}
				$("#fieldvalues_"+previous_panel_id).val(" ");
				if(typeof previous_subpanel_id != "undefined")
				{
				    $("#Subfieldvalues_"+previous_subpanel_id).val(" ");
				}
                
            }
            if(typeof previous_panel_id != "undefined" && typeof previous_subpanel_id == "undefined")
			{
                for (var i = 0; i < prevAttributes.length; ++i) 
                {
                    var temp;
                    if (prevAttributes.length-1 == i)
                    {
                        temp = prevAttributes[i]["attributeid"]
                    }
                    else
                    {
                        temp = prevAttributes[i]["attributeid"]+"~";
                    }
                    previousattributeidappend = previousattributeidappend + temp
                
                }
                $("#fieldvalues_"+previous_panel_id).val(previousattributeidappend);
            }
            else if(typeof previous_subpanel_id != "undefined") 
            {
                for (var i = 0; i < prevAttributes.length; ++i) 
                {
                    var temp;
                    if (prevAttributes.length-1 == i)
                    {
                        temp = prevAttributes[i]["attributeid"]
                    }
                    else
                    {
                        temp = prevAttributes[i]["attributeid"]+"~";
                    }
                    previousattributeidappend = previousattributeidappend + temp
                
                }
                $("#Subfieldvalues_"+previous_subpanel_id).val(previousattributeidappend);
            }
            if(panelDescription != "Unused Fields"){
                if(typeof current_subpanel_id != "undefined"){
                //console.log("current_subpanel_id : "+current_subpanel_id);
                panelDescription = $("div[data-association-subpanel-id='"+current_subpanel_id+"']").find("strong").text();
                panelDescription = panelDescription.replace("\n","");
                panelDescription = panelDescription.replace("\t","");
                panelDescription = panelDescription.trim();
                }
                else{
                    //console.log("current_panel_id : "+current_panel_id);
                    panelDescription = $("a[data-association-panel-id='"+current_panel_id+"']").next().html();
                    panelDescription = panelDescription.replace("\n","");
                    panelDescription = panelDescription.replace("\t","");
                    panelDescription = panelDescription.trim();
                }
            }
            var dataStr = JSON.stringify(data);
            //console.log(dataStr);
            //console.log("panelDescription : "+panelDescription);
            if(duprecord){
                $.ajax({
                    url: 'index.cfm?event=association.updateFieldName',
                    data: {
                        dragtext:dragtext,
                        attributeid:attributeid,
                        panelDescription:panelDescription,
                        dataStr:dataStr,
                        attributelist:attributelist
                    },
                    type: "POST",
                    beforeSend: function(){showLoadingOverlay();},
                    success:function(response){	
                        ColdFusion.Window.create("RenameWindow", "Rename Field", "",{modal: true,width: 500,height: 400,center: true,draggable: true,						
                            callbackHandler:function(){	
                                $body.css("overflow", "hidden");
                            }						
                        });
                        ColdFusion.Window.onHide("RenameWindow",closeRenameWindow);
                        document.getElementById('RenameWindow-body').innerHTML = response;
                        hideLoadingOverlay();
                        return false;
                    }                                     
                });
            }
            else
            {
                showAjaxLoadingOverlay();
                $.post("index.cfm?event=association.updateAttributePositions", {
                    method: "handleArray",
                    returnFormat: "plain",
                    argumentCollection: JSON.stringify(data)
                },
                    updateAttributePositions,
                    "json"
                ).fail(showAjaxError)
                    //.always(hideAjaxLoadingOverlay)
                    .always(getPanelRecordAfterInsertDelete, hideAjaxLoadingOverlay)// Modified : SC
            }
        
            /*BG-244-SC:Stops*/
            //END : Update database with attribute possitons (column, row)
        },
        sortDataRowNumberForEachAttributes = function (itemCtr) {
            var isUnused_Attributes = itemCtr.parent().hasClass("unused_attributes");
            var elements = itemCtr.parent().children();

            var noOfElements = elements.length;
            var rowNumberLeft = 1;
            var rowNumberRight = 1;
            var largerRowNumberOfTwo = 0;

            var data = [];

            for (var i = 0; i < noOfElements; ++i) {
                var childElements = $(elements[i]).children(".ui-sortable-handle");
                var noOfChildElements = childElements.length;
                if ($(elements[i]).hasClass("column_left")) {
                    if (largerRowNumberOfTwo > 0) {
                        rowNumberLeft = largerRowNumberOfTwo;
                    }
                    for (var j = 0; j < noOfChildElements; ++j) {
                        $(childElements[j]).attr("data-row-number", rowNumberLeft);
                        ++rowNumberLeft;

                        var element = {};
                        element.attributeid = $(childElements[j]).attr("data-association-attr-id");
                        element.column = $(childElements[j]).attr("data-col-number");
                        element.row = $(childElements[j]).attr("data-row-number");
                        element.associationPanelId = $(childElements[j]).parents(".groupContainer").attr("data-association-panel-id");

                        if ($(childElements[j]).parents(".subpanel").length > 0) {
                            element.associationSubPanelId = $(childElements[j]).parents(".subpanel").attr("data-association-subpanel-id");
                        }

                        data.push(element);
                    }
                } else if ($(elements[i]).hasClass("column_right")) {
                    if (largerRowNumberOfTwo > 0) {
                        rowNumberRight = largerRowNumberOfTwo;
                    }
                    for (var j = 0; j < noOfChildElements; ++j) {
                        $(childElements[j]).attr("data-row-number", rowNumberRight);
                        ++rowNumberRight;

                        var element = {};
                        element.attributeid = $(childElements[j]).attr("data-association-attr-id");
                        element.column = $(childElements[j]).attr("data-col-number");
                        element.row = $(childElements[j]).attr("data-row-number");
                        element.associationPanelId = $(childElements[j]).parents(".groupContainer").attr("data-association-panel-id");

                        if ($(childElements[j]).parents(".subpanel").length > 0) {
                            element.associationSubPanelId = $(childElements[j]).parents(".subpanel").attr("data-association-subpanel-id");
                        }

                        data.push(element);
                    }
                } else if ($(elements[i]).hasClass("column-full")) {
                    largerRowNumberOfTwo = (rowNumberLeft >= rowNumberRight) ? rowNumberLeft : rowNumberRight;
                    for (var j = 0; j < noOfChildElements; ++j) {
                        $(childElements[j]).attr("data-row-number", largerRowNumberOfTwo);
                        ++largerRowNumberOfTwo;

                        var element = {};
                        element.attributeid = $(childElements[j]).attr("data-association-attr-id");
                        element.column = $(childElements[j]).attr("data-col-number");
                        element.row = $(childElements[j]).attr("data-row-number");
                        element.associationPanelId = $(childElements[j]).parents(".groupContainer").attr("data-association-panel-id");

                        if ($(childElements[j]).parents(".subpanel").length > 0) {
                            element.associationSubPanelId = $(childElements[j]).parents(".subpanel").attr("data-association-subpanel-id");
                        }
                        data.push(element);
                    }
                } else {
                    for (var j = 0; j < noOfChildElements; ++j) {
                        var element = {};
                        element.attributeid = $(childElements[j]).attr("data-association-attr-id");
                        element.column = $(childElements[j]).attr("data-col-number");
                        element.row = $(childElements[j]).attr("data-row-number");
                        element.associationPanelId = 0;
                        element.associationSubPanelId = 0;
                        data.push(element);
                    }
                }
            }
            return data;
        },
        updatePanelSortOrders = function (data) {
            //Nothing to do.
        },
        updateSubPanelSortOrders = function (data) {
            //Nothing to do.
        },
        syncSortOrders = function () {
            $(this.eqCtl).click(function () {
                if ($(this).prop("checked")) {
                    $("#LayoutForBothDialog").dialog({
                        dialogClass: 'LayoutForBothDialog',
                        modal: true,
                        maxWidth: 400,
                        maxHeight: 500, // MS-143
                        width: 400,
                        //height: 200, // MS-143
                        buttons: [{
                                text: "OK",
                                class: "create_button",
                                click: function () {

                                    var data = {};
                                    data.layoutForBoth = $("#layoutforboth").prop("checked");
                                    data.layoutFor = $("#layoutfor").val();
                                    data.associationId = $("#associationid").val();
                                    showAjaxLoadingOverlay();
                                    $.post("index.cfm?event=association.SyncSortOrders",
                                            data,
                                            function (data) {},
                                            "json"
                                        ).fail(showAjaxError)
                                        .always(hideAjaxLoadingOverlay);

                                    $(this).dialog("destroy");
                                }
                            },
                            {
                                text: "Cancel",
                                class: "create_button",
                                click: function () {
                                    $("#layoutforboth").prop("checked", false);
                                    $(this).dialog("destroy");
                                }
                            },
                        ],
                        create: function (event, ui) {
                            $('.ui-dialog-buttonset').children('button').
                            removeClass("ui-button ui-corner-all ui-widget").
                            mouseover(function () {
                                $(this).removeClass('ui-state-hover');
                            }).
                            mousedown(function () {
                                $(this).removeClass('ui-state-active');
                            }).
                            focus(function () {
                                $(this).removeClass('ui-state-focus');
                            });
                        },
                        open: function (event, ui) {
                            $('.create_button').blur();
                        }
                    });
                } else {
			var data = {};						
			data.layoutFor = $("#layoutfor").val();
			data.associationId = $("#associationid").val();
			showAjaxLoadingOverlay();
			$.post("index.cfm?event=association.updateAssociationLayoutForBoth",
					data,
					function (data) {},
					"json"
				).fail(showAjaxError)
				.always(hideAjaxLoadingOverlay);
		}
            });
        },
        showNoneAvailableAttributeText = function (attrCount) {
            var none_available_unused_attributes = $("#none_available_unused_attributes");
            var blankAttr_html = "<div id='blankAttr' class='columngroup inline-block not-sortable' data-attributename=''>" +
                "<div class='attrItemdata_attr_Name'>" +
                "<label class='pull-left label-pdg'>&nbsp;</label>" +
                "</div></div>";
            blankAttr_html = "";    /* Code Added : SC */
            if (attrCount == 1) {
                none_available_unused_attributes.show();
                $(".liketr > .tablerow > .unused_attributes").append(blankAttr_html);
            }
        },
        sortNotInUseAlphabetically = function () {
            var blankAttr = "";
            if ($(".unused_attributes #blankAttr").length) {
                blankAttr = $(".unused_attributes #blankAttr");
                $(".unused_attributes > #blankAttr").remove();
            } else {
                blankAttr = "<div id='blankAttr' class='columngroup inline-block not-sortable' data-attributename=''>" +
                    "<div class='attrItemdata_attr_Name'>" +
                    "<label class='pull-left label-pdg'>&nbsp;</label>" +
                    "</div></div>";
                blankAttr = "";    /* Code Added : SC */
            }

            var sortableList = $('.unused_attributes > .columngroup');
            var unused_attributes_html = $(".liketr > .tablerow > .unused_attributes");
            var listitems = sortableList;
            var unsed_html = "";
            listitems.sort(function (a, b) {
                return ($(a).attr("data-attributename").toUpperCase() > $(b).attr("data-attributename").toUpperCase()) ? 1 : -1;
            });

            unused_attributes_html.empty();
            unused_attributes_html.prepend(unsed_html);
            unused_attributes_html.append(listitems);

            var noOfAttributes = $('.unused_attributes > .columngroup:visible').length;
            if (noOfAttributes % 2 == 1) {
                unused_attributes_html.append(blankAttr);
            }
        },
        updateAttributePositions = function (data) {
            //Nothing to Do
        },
        showAjaxLoadingOverlay = function () {
            showLoadingOverlay();
        },
        hideAjaxLoadingOverlay = function () {
            hideLoadingOverlay();
        },
        showAjaxError = function () {};

    return {
        sortablePanel: sortablePanel,
        sortableSubPanel: sortableSubPanel,
        sortableAttributes: sortableAttributes,
        syncSortOrders: syncSortOrders
    };
}();

/* Yeou : END */

/* Added : SC Start */

// Get Previous Panel Record Description Through Ajax 
function getPanelRecordAfterInsertDelete() {
    
    var associationid = $('#associationid').attr('value');
    //var attribute_count = $('#attribute_count').attr('value');
   
    var layoutFor = $("#layoutfor").val();
    var layoutForBoth = $("#layoutforboth").prop("checked");
    var isMissionControl=0;
    if( layoutFor == 1 ){
        isMissionControl = 1;
    }
    else if( layoutFor == 2 )
    {
        isMissionControl = 0;
    }
    
    $.ajax({
        url: "index.cfm?event=association.updatePreviousPanelDetails&associationid=" + associationid,
        type: "post",
        datatype: "json",
        success: function (data) {            
            data = $.parseJSON(data);             
            var counter = 0;
            var rows = 0;
            var finalPanelId="";
            var finalSubPanelId="";
            var panelID = 0;  
            var layout = 0;
           var attributeId_index = data['COLUMNS'].indexOf('ATTRIBUTEID');
           var previousPanelId_index = data['COLUMNS'].indexOf('PREVIOUSPANELID');
           var previousSubPanelId_index = data['COLUMNS'].indexOf('PREVIOUSSUBPANELID');
           var isMissionControl_index = data['COLUMNS'].indexOf('ISMISSIONCONTROL');

            $(".targetedspan").each(function () {
               
                var panelIdFromSpan = "";
              
                if (data['DATA'].length == 0) {
                   
                    panelIdFromSpan = $(this).attr("class").split('_')[1];
                   
                    $(".previoushistory_" + panelIdFromSpan).html("No Panel History").css("color","#000");
                }
                if (data['DATA'].length > 0) {                   
                    panelIdFromSpan = $(this).attr("class").split('_')[1];                    
                    for (i = 0; i < data['DATA'].length; i++){
                        rows = data['DATA'][i];
                        if (panelIdFromSpan == rows[attributeId_index] && isMissionControl == rows[isMissionControl_index]) {
                            counter++;
                            finalPanelId = rows[previousPanelId_index];
                            finalSubPanelId = rows[previousSubPanelId_index];
                        }
                    }                   
                    if(counter > 0){
                        var panelobj = $("#panel" + finalPanelId);
                        var subpanelobj = $("#subpanel" + finalSubPanelId);
                        var sub_panel_name = "";
                        if (subpanelobj[0] != null) {
                            sub_panel_name = " (" + subpanelobj[0].children[0].children[0].children[0].innerText + ") ";
                        }
                        else {
                            sub_panel_name = "";
                        }
                        var final_text = panelobj[0].children[0].children[1].innerText + sub_panel_name;
                        $(".previoushistory_" + panelIdFromSpan).html(final_text).css("color","#000");
                    }
                    else
                    {
                        $(".previoushistory_" + panelIdFromSpan).html("No Panel History").css("color","#000");  
                    }
                }
                counter=0;
            });
        }
    });
}

// Adding Attribute To Previous Panel Record  
function attributeAdded(curr_obj) {   
    if ($(curr_obj).parent().parent().parent().parent().attr('class') == "tablerow toprow") {       
        if ($(".previous_panel_name").length != 0) {
            $(".previous_panel_name").remove();
        }
        var panel_arr = [];
        var arr_obj = $(curr_obj).closest('.tablerow').find(".attrItemdata_attr_Name");       
        $(arr_obj).each(function (i) {
            var divelements = this;
            if (divelements.children[0].innerText !== "extra" && divelements.children[0].innerText !== "(None Available)") {
                var attr_name=divelements.children[0].innerText;
                attr_name=attr_name.replace(/[^\w\s]/gi, '');
                panel_arr.push(attr_name + "~" + divelements.children[0].children[0].getAttribute('data-association-attr-id'));
            }
        });
        panel_arr = $.unique(panel_arr);
        panel_arr = panel_arr.sort(function (a, b) {
            return (a.split("~")[0].toUpperCase() > b.split("~")[0].toUpperCase()) ? 1 : -1;
	    console.log("here");
        });
        
        for (i = 0; i < panel_arr.length; i++) {
            //console.log(panel_arr[i]);  
            $("<div class='columngroup inline-block previous_panel_name'>" +
                "<div class='attrItemdata_attr_Name not-sortable'>" +
                "<label class='pull-left label-pdg'>" +
                "<span style='color:#fff' class='targetedspan previoushistory_" + panel_arr[i].split("~")[1] + "'>" + panel_arr[i] + "</span>" +
                "</label>" +
                "</div>" +
                "</div>").appendTo(".dyna_previous_panel_desc");
        }
        $(".previous_panel_desc").remove();
    }
}

// Removing Attribute To Previous Panel Record 
function removeAttribute(curr_obj) {       
    if ($(curr_obj).parent().attr('class') == "tablerow toprow") {
        $(".previous_panel_desc").remove();
        $(".dyna_previous_panel_desc").empty();
        $(".dyna_previous_panel_desc").show();
       
        $(curr_obj).children().each(function (i) {
            var divelements = this;            
            if ($(divelements).attr("id") != "none_available_unused_attributes") {                
                if ((divelements.lastElementChild.children[0].innerText) !== "extra") {
                    var final_id = divelements.children[0].children[0].children[0].getAttribute('data-association-attr-id');
                    $("<div class='columngroup inline-block previous_panel_name'>" +
                        "<div class='attrItemdata_attr_Name not-sortable'>" +
                        "<label class='pull-left label-pdg'>" +
                        "<span style='color:#fff' class='targetedspan previoushistory_" + final_id + "'>" + divelements.lastElementChild.children[0].innerText + "~" + final_id + "</span>" +
                        "</label>" +
                        "</div>" +
                        "</div>").appendTo(".dyna_previous_panel_desc");
                }                
            }
        });
    }
}
/* Added : SC End */


/* Start: Lucky - Added for ASSNS-562 */
$(document).on('click', '.copyDashboardLayoutPopup', function (e) {
	e.stopPropagation();
	showLoadingOverlay();
	var associationid = $('#associationid').attr('value');	
	var layoutfor = $('#layoutfor option:selected').val();
	var layoutForBoth = $("#layoutforboth").prop("checked")
	$dialog.CopyAssociationDashboardLayout.dialog('open')	
		.loadDialogContent(root + 'association.copyassociationdashboardlayout&associationid=' + associationid + '&layoutforboth=' + layoutForBoth + '&layoutfor=' + layoutfor);
	hideLoadingOverlay();
});

function associationType3Slide(){
	$(".associationsTitles").slideToggle('slow');
}

$(document).on('click', '#selectType3Associations', function (e) {
	if($(this).text()=='Select All') {		 
		$('.associationType3_checkbox input.associationItem').prop('checked', true);
		$(this).text('Select None');
		$(".associationsTitles input[name='associationsApply']").removeAttr('disabled');
	} else {
		$('.associationType3_checkbox input.associationItem').prop('checked', false);
		$(this).text('Select All');
		$(".associationsTitles input[name='associationsApply']").attr('disabled','disabled');
	}
	return false;
});

/*function associationSlide(){
	$(".associationType3Slide").slideToggle('slow');
}*/

function associationApplyButtonEnable(){
	var aoData = "";
	var aoIdArr = "";
	$('.associationsTitles input[type="checkbox"]').each(function(){
  	 	if($(this).is(':checked')){
    		aoData = aoData + $(this).val() +'~';
    	}
    });
    aoData = aoData.substring(0,aoData.length -1);
    var aoIdArr = aoData.split("~");
    var aoId = aoIdArr[0].trim();
    if((aoId.length) != 0) {
		$(".associationsTitles input[name='associationsApply']").removeAttr('disabled');
    } else {
    	$(".associationsTitles input[name='associationsApply']").attr('disabled','disabled');
		$(".associationType3Assign").empty();
		$(".associationType3AssignText").html("Assign");
    }
	/* Start: Toggle Select All-None */
	var associationCheckBoxes =  $('.associationsTitles input[type="checkbox"]');		
	var associationChecked = $('.associationsTitles input[type="checkbox"]:checked');			
	if(associationCheckBoxes.length == associationChecked.length) {
		$('#selectType3Associations').html("Select None");
	} else {
		$('#selectType3Associations').html("Select All");
	}
	/* End: Toggle Select All-None */
}

function saveSelectedType3Associations() {	 
	var aoData = "";
	var aoDatatext = "";	
  	$('.associationsTitles input[type="checkbox"]').each(function(){
  	 	if($(this).is(':checked')){
    		aoData = aoData + $(this).val() +'~';
    		aoDatatext = aoDatatext + $(this).attr('data-asso-name') +'~';
     	}
    });
    $(".associationsTitles").slideUp('slow');
    aoDatatext = aoDatatext.substring(0,aoDatatext.length -1);
    var aoArr = aoDatatext.split("~");
    var aoIdArr = aoData.split("~");
    $(".associationType3Assign").empty();
    $.each(aoArr, function(i,value) {
    	$(".associationType3Assign").append( "<div style='padding-bottom:5px'>"+aoArr[i]+"</div>");
	});
    $(".associationType3AssignText").html('Edit');	
}

$(document).on('change', '.copylayout_childpanelitem', function (e) {
    if($(this).is(":checked")) {		
        $(this).closest('.panel_columngroup').addClass("check_bgcolor");		
    } else {		
        $(this).closest('.panel_columngroup').removeClass("check_bgcolor");		
    }
});

$(document).on('click', '.select_all_copylayout_attributes', function (e) {																	   
    if($(this).html() == 'Select All Panel &amp; Sub-Panels') {	
		$('.copylayout_panel').prop("checked",true);
		$('.copylayout_subpanel').prop("checked",true);
		$('.copylayout_childpanelitem').prop("checked",true);
		$('.copylayout_childpanelitem').closest('.panel_columngroup').addClass("check_bgcolor");
		stayUnCheckedDefaultAttributes();
		$(this).html('Deselect All Panel & Sub-Panels');		
    } else {		
		$('.copylayout_panel').prop("checked",false);
		$('.copylayout_subpanel').prop("checked",false);
		$('.copylayout_childpanelitem').prop("checked",false);
		$('.panel_columngroup').removeClass("check_bgcolor");		
		$(this).html('Select All Panel & Sub-Panels');		
    }
});

function stayCheckedDefaultAttributes() {	
	$('#attribute_identifiername').prop("checked",true);
	$('#attribute_createdon').prop("checked",true);
	$('#attribute_association').prop("checked",true);
	$('#attribute_assignedto').prop("checked",true);
	$('#attribute_identifiername').closest('.panel_columngroup').addClass("check_bgcolor");
	$('#attribute_createdon').closest('.panel_columngroup').addClass("check_bgcolor");
	$('#attribute_association').closest('.panel_columngroup').addClass("check_bgcolor");
	$('#attribute_assignedto').closest('.panel_columngroup').addClass("check_bgcolor");
}

function stayUnCheckedDefaultAttributes() {	
	$('#attribute_identifiername').closest('.panel_columngroup').removeClass("check_bgcolor");
	$('#attribute_createdon').closest('.panel_columngroup').removeClass("check_bgcolor");
	$('#attribute_association').closest('.panel_columngroup').removeClass("check_bgcolor");
	$('#attribute_assignedto').closest('.panel_columngroup').removeClass("check_bgcolor");
	$('#attribute_identifiername').closest('.panel_columngroup').addClass("disabled_bgcolor");
	$('#attribute_createdon').closest('.panel_columngroup').addClass("disabled_bgcolor");
	$('#attribute_association').closest('.panel_columngroup').addClass("disabled_bgcolor");
	$('#attribute_assignedto').closest('.panel_columngroup').addClass("disabled_bgcolor");
}

function selectPanelAttributes(current) {
	showLoadingOverlay();	
	var currentPanelId = $(current).attr('data-association-panel-id');
	var currentPanel = $('.AssociationPanel' + currentPanelId);	
	if($(current).prop("checked")) {
		$(currentPanel).find(".copylayout_subpanel").prop('checked', true);
		$(currentPanel).find(".copylayout_childpanelitem").prop('checked', true);
		$(currentPanel).find(".copylayout_childpanelitem").closest('.panel_columngroup').addClass("check_bgcolor");		
	} else {
		$(currentPanel).find(".copylayout_subpanel").prop('checked', false);
		$(currentPanel).find(".copylayout_childpanelitem").prop('checked', false);
		$(currentPanel).find(".copylayout_childpanelitem").closest('.panel_columngroup').removeClass("check_bgcolor");
	}
	//stayCheckedDefaultAttributes();
	checkIfAllCheckboxAreChecked();
	hideLoadingOverlay();
}

function selectSubPanelAttributes(current) {
	showLoadingOverlay();	
	var currentPanelId = $(current).attr('data-association-panel-id');
	var currentSubPanelId = $(current).attr('data-association-subpanel-id');	
	var currentSubPanel = $('.copylayout_subpanel' + currentSubPanelId);
	var currentAttributes = $('.copylayout_childpanelitem_' + currentPanelId + '_' + currentSubPanelId);	
	if($(current).prop("checked")) {
		$(currentAttributes).prop('checked', true);
		$(currentAttributes).closest('.panel_columngroup').addClass("check_bgcolor");
	} else {	
		$(currentAttributes).prop('checked', false);
		$(currentAttributes).closest('.panel_columngroup').removeClass("check_bgcolor");
	}	
	checkIfAllCheckboxAreChecked();
	hideLoadingOverlay();
}

function toggelSelectAllText(current) {	
	var currentPanelId = $(current).attr('data-association-panel-id');
	var currentSubPanelId = $(current).attr('data-association-subpanel-id');	
	var currentPanel = $('.copylayout_panel' + currentPanelId);	
	var currentSubPanel = $('.copylayout_subpanel' + currentSubPanelId);
	var currentSubPanelType = $(current).attr('data-association-subpanel-type');	
	if($(current).prop("checked")) {	
		if(currentSubPanelType == 'default') {
			$(currentPanel).prop("checked",true);
		}
		$(currentSubPanel).prop("checked",true);
	}
	checkIfAllCheckboxAreChecked();
}

function checkIfAllCheckboxAreChecked() {	
	var panelCheckBoxes = $('.copylayout_panel');
	var panelsChecked = $('.copylayout_panel:checked');
	var subpanelCheckBoxes = $('.copylayout_subpanel');
	var subpanelsChecked = $('.copylayout_subpanel:checked');	
	var attributeCheckBoxes =  $('.copylayout_childpanelitem');		
	var attributesChecked = $('.copylayout_childpanelitem:checked');			
	if(panelCheckBoxes.length == panelsChecked.length && subpanelCheckBoxes.length == subpanelsChecked.length && attributeCheckBoxes.length == attributesChecked.length) {
		$('.select_all_copylayout_attributes').html("Deselect All Panel & Sub-Panels");
	} else {
		$('.select_all_copylayout_attributes').html("Select All Panel & Sub-Panels");
	}
}

function validateCopyForm() {
	submitCopyAssociationLayout();
}

function submitCopyAssociationLayout() {	
	var _current_time_cache = new Date().getTime();
	var programid = $("#programID").val();
	var associationid = $('#associationid').val();
	var layoutfor = $("#layoutfor").val();
	var skipattributeids = $("#skipattributeids").val();
	if(layoutfor == 1) {
		layoutfor = 1;
	} else {
		layoutfor = 0;
	}	
	var associationIdArray = [];
	$('input[name="typeThreeAssociationNames"]:checked').each(function() {
		associationIdArray.push($(this).val());																   
	});
	var copyLayoutTo = [];
	$('input[name="copylayoutto"]:checked').each(function() {
		copyLayoutTo.push($(this).val());																   
	});
	var panelsToCopy = [];
	$('input[name="copylayout_panel"]:checked').each(function() {	
		if($(this).attr('data-association-panel-type') != 'AssignmentDetails') {
			panelsToCopy.push($(this).val());
		}
	});
	var subpanelsToCopy = [];
	$('input[name="copylayout_subpanel"]:checked').each(function() {		
		subpanelsToCopy.push($(this).val());		
	});
	var attributesToCopy = [];
	$('input[name="copylayout_childpanelitem"]:checked').each(function() {	
		if($(this).val() != 'identifiername' && $(this).val() != 'createdon' && $(this).val() != 'association' && $(this).val() != 'assignedto') {
			attributesToCopy.push($(this).val());
		}
	});	
	var postdata = [];	
	postdata.push({
		"name": "associationid",
		"value": associationid
	});	
	postdata.push({
		"name": "layoutfor",
		"value": layoutfor
	});
	postdata.push({
		"name": "associationIdArray",
		"value": associationIdArray
	});	
	postdata.push({
		"name": "copyLayoutTo",
		"value": copyLayoutTo
	});	
	postdata.push({
		"name": "panelsToCopy",
		"value": panelsToCopy
	});
	postdata.push({
		"name": "subpanelsToCopy",
		"value": subpanelsToCopy
	});	
	postdata.push({
		"name": "attributesToCopy",
		"value": attributesToCopy
	});
	postdata.push({
		"name": "skipattributeids",
		"value": skipattributeids
	});
		
	if(associationIdArray.length > 0) {
		$.ajax({
			type: "POST",
			url: "index.cfm?event=association.copyassociationdashboardprocess&currenttimestamp=" + _current_time_cache,		
			data: postdata,		
			beforeSend: function () {				
				showLoadingOverlay();
			},
			success: function (copiedData) {
				$('#closeDialogValidation').trigger('click');
				$('#closeDialog').trigger('click');				
			},
			complete: function () {
				hideLoadingOverlay();		
			},
			error: function (copiedData) {
				$('#closeDialog').trigger('click');
				alert('Oops...mistake on server');
				return false;
			}
		});
	}
}
/* End: Lucky - Added for ASSNS-562 */

/* Start: Ritu - Added for ASSNS-562 */

function validateCopyForm(current){
	var associationarr = [];
	var attrids = [];
	var panelids = [];
	var subpanelids = [];
	var stafforvol = [];
	var selectedIds = "";
	var selectedpanelids = [];
	var selectedsubpanelids = [];
	var associationid = document.getElementById('associationid').value;
	var panelsChecked = $('.copylayout_panel:checked');	
	var subpanelsChecked = $('.copylayout_subpanel:checked');
	var window_title = $('#window_title').val();
	$('input.associationItem:checkbox:checked').each(function () {
		associationarr.push($(this).val());
	});
	$('input.copylayoutto:checkbox:checked').each(function () {
		stafforvol.push($(this).val());
	});
	if(associationarr.length == 0) {		
		alert('Please select atleast one destination '+ window_title +'.');
			current.disabled=false;
		return false;
	}
	if(stafforvol.length == 0) {		
		alert('Please select in which layout you want to copy the fields.');
		current.disabled=false;
		return false;
	}
	$('input.copylayout_childpanelitem:checkbox:checked').each(function () {
		var thisAttrId = $(this).attr('data-attribute-id');
		var thisPanelId = $(this).attr('data-association-panel-id');
		var thisSubPanelId = $(this).attr('data-association-subpanel-id');			 
		selectedIds = thisAttrId.slice(10) + '~' + thisPanelId + '~' + thisSubPanelId;
		attrids.push(selectedIds);
		panelids.push(thisPanelId);
		subpanelids.push(thisSubPanelId);
		
	});
	if(selectedIds.length == 0 && panelsChecked.length == 0 && subpanelsChecked.length == 0) {		
		alert('Please select at least one Panel, Sub-panel or Field to copy.');
		current.disabled=false;
		return false;
	}
	$('input.copylayout_panel:checkbox:checked').each(function () {
		selectedpanelids.push($(this).val());		 
	});
	$('input.copylayout_subpanel:checkbox:checked').each(function () {
		selectedsubpanelids.push($(this).val());		 
	});
	
	var postdata = [];
    postdata.push({
        "name": "selectedIds",
        "value": attrids
    });
    postdata.push({
        "name": "selectedassociations",
        "value": associationarr
    });
	postdata.push({
        "name": "associationid",
        "value": associationid
    });
	postdata.push({
        "name": "stafforvol",
        "value": stafforvol
    });
	postdata.push({
        "name": "selectedpanelids",
        "value": selectedpanelids
    });
	postdata.push({
        "name": "selectedsubpanelids",
        "value": selectedsubpanelids
    });
	$.ajax({
        type: "POST",
        url: "index.cfm?event=association.ispopupcheckvalidationforcopylayout",
        data: postdata,
        beforeSend: function () {
            showLoadingOverlay();
        },
        success: function (response) {
             obj = $.parseJSON(response);
             //BG-577 Start
             if('8' in obj)
                {
                    alert(obj[8]);
                }
            //BG-577 End
            else if ( (('2' in obj ) || ('4' in obj)) && !('6' in obj)){
			 $dialog.CopyAssociationDashboardLayoutValidation.dialog('open')	
		.loadDialogContent(root + 'association.checkvalidationforcopylayout&associationid=' + associationid + '&selectedassociations=' + associationarr + '&selectedIds=' + attrids + '&stafforvol=' + stafforvol + '&selectedpanelids=' + selectedpanelids + '&selectedsubpanelids=' + selectedsubpanelids);
			 }
			//BG-244 Start
             else if('6' in obj)
            {
                alert("The Destination Panel already has a field by this name");
            }
			//BG-244 End
			 else{
				submitCopyAssociationLayout(); 
			 }			 
        },		
        complete: function (response) {
            hideLoadingOverlay();
        },    
        error: function (response) {
            status = false;
        }
    });
		
    current.disabled=false;
    return false;
	
}
	
function uncheckselecteditems(skipattributeids,skipassociationids){	
	$('#skipattributeids').val = skipattributeids;
	document.getElementById("skipattributeids").value = skipattributeids;	 
	submitCopyAssociationLayout();
}

/* End: Ritu - Added for ASSNS-562 */	

