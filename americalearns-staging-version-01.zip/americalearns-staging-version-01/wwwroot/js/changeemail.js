// this function is to open up the change password scroll down
function OpenChangeEmail()
{
	if (document.getElementById("div_changeemail").style.display == "none")
	{
		new Ajax.Request("/index.cfm?event=user.openchangeemail",{ 
	
				onSuccess: function(returnHtml) { 
	
				 Element.update("div_changeemail", returnHtml.responseText);
				 //Effect.SlideDown("div_changeemail");
				 jQuery('#div_changeemail').slideDown(1000);
				}, 
				onFailure: function(){ 
				alert('Oops...mistake on server');
				} 
			});
	}
	else
	{
		jQuery('#div_changeemail').slideUp(1000);
	}		
}

//this is to close the slider down
function CancelCloseChangeEmail()
{
	document.getElementById("imgLoadingChangeEmail").style.display = "block";
	//Effect.SlideUp("div_changeemail");
	jQuery('#div_changeemail').slideUp(1000);
	document.getElementById("imgLoadingChangeEmail").style.display = "none";
}

//validating and updating the email address
function updateEmailwithValidations(currentUserID,currentEmailId)
{
	var emailAddress = trim(document.getElementById("txt_address").value,' ');
	var confirmEmailAddress = trim(document.getElementById("txt_confirmaddress").value,' ');
	document.getElementById("imgLoadingChangeEmail").style.display = "block";
	if (emailAddress.length == 0)
	{
		alert("Please enter a valid email address to send a link to reset your password.");
		document.userpersonal.txt_address.focus();
		document.getElementById("imgLoadingChangeEmail").style.display = "none";
	}
	else if (emailAddress.length > 150)
	{
		alert("Please enter a valid e-mail address of 150 characters or less.");
		document.userpersonal.txt_address.focus();
		document.getElementById("imgLoadingChangeEmail").style.display = "none";
	}
	else
	{
		if (emailAddress != confirmEmailAddress)
		{
			alert("The addresses in the \"New Address\" and \"Confirm Address\" boxes need to match. Please try again.");
			document.userpersonal.txt_address.focus();	
			document.getElementById("imgLoadingChangeEmail").style.display = "none";		
		}
		else
		{
			//checking whether its email id
			//var regexp = new RegExp ("^[A-Za-z0-9](([_\.\-]?[a-zA-Z0-9]+)*)@([A-Za-z0-9]+)(([\.\-]?[a-zA-Z0-9]+)*)\.([A-Za-z]{1,})$");
			//var regexp = new RegExp ("^[\_a-zA-Z0-9\-][\_a-zA-Z0-9\-]*(\.[\_a-zA-Z0-9\-][\_a-zA-Z0-9\-]*)*@[a-zA-Z0-9\-][a-zA-Z0-9\-]*(\.[a-zA-Z0-9\-][a-zA-Z0-9\-]*)*\.(([a-zA-Z]{2,3})|(aero|coop|info|name))$");
			var regexp = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
			
			if (regexp.test(emailAddress))
			{
				new Ajax.Request("/index.cfm?event=user.updateemailaddress&currentUserID="+currentUserID+"&currentEmailId="+encodeURIComponent(currentEmailId)+"&emailAddress="+encodeURIComponent(emailAddress)+"&alertuser=1",{ 
	
				onSuccess: function(returnHtml) { 
	
				 Element.update("div_changeemail", returnHtml.responseText);
				}, 
				onFailure: function(){ 
				alert('Oops...mistake on server');
				} 
				});
			}
			else
			{
				alert("The email address you entered is invalid. Please enter a valid email address, including the @ symbol and domain, such as name@example.com.");
				document.getElementById("txt_address").value="";
				document.getElementById("txt_confirmaddress").value="";
				document.userpersonal.txt_address.focus();
				document.getElementById("imgLoadingChangeEmail").style.display = "none";
			}
		
		}
	}
	

}


function trim(str, chars) {
	return ltrim(rtrim(str, chars), chars);
}
 
function ltrim(str, chars) {
	chars = chars || "\\s";
	return str.replace(new RegExp("^[" + chars + "]+", "g"), "");
}
 
function rtrim(str, chars) {
	chars = chars || "\\s";
	return str.replace(new RegExp("[" + chars + "]+$", "g"), "");
}