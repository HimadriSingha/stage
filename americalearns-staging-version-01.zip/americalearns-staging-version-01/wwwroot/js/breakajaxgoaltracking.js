var asc = 0;
var quid='';
var objectnm='';
var col_names_array = new Array();
var showtype=1;
function linkDisabled(obj){
	var objName = obj.id;
	var objrel = obj.rel; 
	
	var showraw="showraw"+objrel;
	var unduplicate ="unduplicate"+objrel;
	var rawlabel="rawlabel"+objrel;
	var duplicatelabel="duplicatelabel"+objrel;
	var breakout = "BreakOutByGoal"+objrel;
	document.getElementById(breakout).style.display = 'block';
	var breakoutId = document.getElementById(breakout);
	var showrawId = document.getElementById(showraw);
	var unduplicateId = document.getElementById(unduplicate);
	var elms2 = document.querySelectorAll('[id="' +duplicatelabel+ '"]');
	var elms1 = document.querySelectorAll('[id="' +rawlabel+ '"]');
	if (breakoutId.style.display==='block')
	{
		if(obj.classList.contains('isDisabled')===false && objName===showrawId.id)
		{
			obj.classList.add("isDisabled");
			obj.innerHTML = "Showing Raw Data";
			unduplicateId.innerHTML = "Show Unduplicated Data";
			unduplicateId.classList.remove("isDisabled");
			for(var i = 0; i < elms1.length; i++)
			{
				elms1[i].classList.remove("raw_duplicate");
				elms2[i].classList.add("raw_duplicate");
			}
			showtype = 1;
			
		}
		else if (obj.classList.contains('isDisabled')===false && objName===unduplicateId.id)
		{
			obj.classList.add("isDisabled");
			showrawId.classList.remove("isDisabled");
		
			obj.innerHTML = "Showing Unduplicate Data";
			showrawId.innerHTML = "Show Raw Data";
			for(var i = 0; i < elms2.length; i++) 
			{
				elms1[i].classList.add("raw_duplicate");
				elms2[i].classList.remove("raw_duplicate");
			}
			showtype=2;
			
		}
		
		DisplayZeroValues(objrel);
		
	}
	
}

function BreakByGoal(obj, loadingImgId, showingstatus)
{
	
	var objName = obj.id;
	var objrel = obj.rel;
	objectnm = obj.rel;
	quid = obj.rel;
	var showraw="showraw"+objrel;
	var duplicatelabel="duplicatelabel"+objrel;	
	var rawlabel="rawlabel"+objrel;
	var unduplicate ="unduplicate"+objrel;
	var hidebreak_row ="hidebreak_row"+objrel;
	var breakout = "BreakOutByGoal"+objrel;
	var loading = document.getElementById(loadingImgId);

	if (document.getElementById(breakout).style.display == 'none') {
	if (showingstatus == 'firsttimemain') {
		showtype=1;
		DisplayZeroValues(objrel);
		loading.style.display = 'inline-block';	
		Effect.BlindDown(breakout,{duration:2, afterFinish: hideloading});
		
	}
	var showrawId = document.getElementById(showraw);
	var unduplicateId = document.getElementById(unduplicate);
	var hidebreak_row = document.querySelectorAll('[id="' +hidebreak_row+ '"]');
	var elms2 = document.querySelectorAll('[id="' +duplicatelabel+ '"]');
	var elms1 = document.querySelectorAll('[id="' +rawlabel+ '"]');
		showrawId.classList.add("isDisabled");
		showrawId.innerHTML = "Showing Raw Data";
		unduplicateId.innerHTML = "Show Unduplicated Data";
		unduplicateId.classList.remove("isDisabled");
		for(var i = 0; i < elms1.length; i++) 
		{
			elms1[i].classList.remove("raw_duplicate");
			elms2[i].classList.add("raw_duplicate");
		}
		
		for(var i = 0; i < hidebreak_row.length; i++) 
		{
			hidebreak_row[i].classList.remove("raw_duplicate");
			hidebreak_row[i].classList.add("raw_duplicate");
			hidebreak_row[i].style.display="block";
		}
	//var loading = document.getElementById(loadingImgId);
	//loading.style.display = 'inline-block';
	//DisplayZeroValues(objrel);
	
}
	
	
	
	
}
function hideloading(breakout) {
	var loading = document.getElementById('loadingImg_'+quid);
	//console.log(loading);
	loading.style.display = 'none';
	
	
}
function IdentifierAliasBreak(objid)
{
	var SetIdentifierDiv ="SetIdentifier"+objid;
	var identifierBreakOutCheck ="identifierBreakOut"+objid;
	var identifierBreakOutCheckId = document.getElementById(identifierBreakOutCheck);
	var elms1 = document.querySelectorAll('[id="' +SetIdentifierDiv+ '"]');
	if (identifierBreakOutCheckId.checked == 1)
	{
		for(var i = 0; i < elms1.length; i++) 
		{
			elms1[i].classList.remove("raw_duplicate");
		}
	}
	else if (identifierBreakOutCheckId.checked == 0)
	{
		for(var i = 0; i < elms1.length; i++) 
		{
			elms1[i].classList.add("raw_duplicate");
		}
		
	}
	
}

function DisplayZeroValues(quid) {
	var i = 0;
	
	var breakout = "BreakOutByGoal"+quid;
	var checkname = "showZerovalues"+quid;
	var divGoalData = document.getElementById(breakout);
	var chkShowZeroValues = document.getElementById(checkname);
	
	var columnhead='';
	var count=parseInt(0);
	if(divGoalData!=null) {
		var children = divGoalData.children;
		for(var j=0;j<children.length;j++) {
			var id = children[j].id;
			var maindataelement = children[j];
			
			if(maindataelement.tagName == 'TABLE') {
				//console.log("table:"+id);
				var childelements = maindataelement.rows;
				var startpos =parseInt(0);
				var endpos=parseInt(0);
				var nodatacount = parseInt(0);
				var headingcount=parseInt(0);
				var seperatorcount =0;
				var datacount=0;
				count=0;
				var colpos=0;
				var datapos=0;
				var dividerpos=0;
				var celldata='';
				for(var k=0;k<childelements.length;k++) {
					var len = childelements[k].cells.length;
					
					var cellvalueraw2 = childelements[k].cells[0].innerText;
					
					
					if(cellvalueraw2.trim()=='' || cellvalueraw2.trim() == 'Goal Set' || cellvalueraw2.trim() == 'Made Progress' || cellvalueraw2.trim() == 'Didn\'t Make Progress' || cellvalueraw2.trim() == 'Met / Accomplished' || cellvalueraw2.trim() == 'Goal Dropped')
					{
									
						headingcount++;
					}
				
					if(childelements[k].style.display === 'none') {
									childelements[k].style.display = '';
					} 
								
					
					if(chkShowZeroValues.checked == false) {
						
							if(len>1 && childelements[k].cells[1].innerText.startsWith('Number of Goals')) {
								//console.log("colpos:"+colpos);
								colpos = k;
								dividerpos=0;
								datapos=0;
								//console.log("header:"+childelements[colpos].cells[0].innerText);
							
							} else if(len>1 && !childelements[k].cells[1].innerText.startsWith('Number of Goals') && childelements[k].cells[0].innerText.length>0) {
							
								var dt = childelements[k].cells[1].innerText;
								var matches = dt.match(/(\d+)/);
						
								if(matches!=null && dt!='' && dt.trim() !='0') {
									//console.log("data:"+dt);
									datapos++;
								
								}
								//console.log("data:"+k+",,,"+(childelements.length-1));
								if(k==childelements.length-1) {
									if(datapos==0) {
										var colheader = childelements[colpos].cells[0].innerText;
										if(colheader.trim() != 'Goal Set' && colheader.trim() != 'Made Progress' && colheader.trim() != 'Didn\'t Make Progress' && colheader.trim() != 'Met / Accomplished' && colheader.trim() != 'Goal Dropped') {
											childelements[colpos].style.display = 'none';
										}
										childelements[colpos-1].style.display = 'none';
										
									}
									
								}
							
							}else if((len<=1 && childelements[k].cells[0].innerText.length<=0) || (len==0)) {
								//console.log("divider:"+datapos);
								dividerpos =k;
								if(datapos==0) {
								
									//console.log("headerpos:"+childelements[colpos].cells[0].innerText);
									var colheader = childelements[colpos].cells[0].innerText;
									if(colheader.trim() != 'Goal Set' && colheader.trim() != 'Made Progress' && colheader.trim() != 'Didn\'t Make Progress' && colheader.trim() != 'Met / Accomplished' && colheader.trim() != 'Goal Dropped') {
									childelements[colpos].style.display = 'none';
									childelements[colpos-1].style.display = 'none';
									}
									childelements[dividerpos].style.display = 'none';
								
								}
							
							
						}
						
					}
					
					if(len==2 ) {
						
						
						var cellvalueraw = childelements[k].cells[1].innerText;
								
						if(cellvalueraw.trim().startsWith('Number of Goals')) {
							startpos = k;
							columnhead= cellvalueraw2;
							headingcount++;
							
						
						}
					
					
						if(chkShowZeroValues.checked == false) {
							
							var matches = cellvalueraw.match(/(\d+)/);
							if(matches==null && cellvalueraw!='') {
								childelements[k].style.display = '';
								
							} else {
								var cellvalue = matches[0];
								if(cellvalue.trim() == '0' || cellvalueraw2.startsWith('datacount') || cellvalueraw2.startsWith('undatacount')) {
									
									count++;
									childelements[k].style.display = 'none';
								}
								else  {
									childelements[k].style.display = '';
									}
								}
								
								
						
							} else /*if(!cellvalueraw2.startsWith('datacount') && !cellvalueraw2.startsWith('undatacount'))*/{

								if(childelements[k].style.display === 'none') {
									childelements[k].style.display = '';
								} else {
									childelements[k].style.display = '';
								}
								
								
								
							}
							
							
						
							
						}
						
							
					if(cellvalueraw2.startsWith('datacount') || cellvalueraw2.startsWith('undatacount')){

								childelements[k].style.display = 'none';
								
						}
						
						
					
				}
			
				if((((count)+headingcount>= maindataelement.rows.length))) {
					maindataelement.style.display='none'
					maindataelement.style.height='0'
				} else {
					maindataelement.style.display=''
				}
				
				
			
				
			}
		}
	
	} else {
		console.log("no data found...");
	}
	}  
  
  
function sortdata(idname,columnname,rowcount,arrowcount,columnid){
	if (asc == 2) {asc = -1;} else {asc = 2;}
		var table = document.getElementById(idname);
		var element = document.getElementById(arrowcount);
		var arr_index = new Array();
		var rows = table.tBodies[0].rows;
		var rlen = rows.length-1;
		var arr = new Array();
		var a=0;
		var start =0;
		var end =0;
		var ishidden=0;
		for(c=0;c<rlen;c++){
			
			if(rows[c].cells.length>1) {
				var rowdata= rows[c].cells[1].innerHTML;
				var matchescolumnid = rowdata.includes(columnname+"_"+columnid);
				if(matchescolumnid && columnname==rows[c].cells[0].innerText){
					start=c+1;
					break;
			
				}
			}
		}
	
	
	
	for(a=start;a<=rlen;a++)
	{		
			if(a==rlen || rows[a].cells.item(0)==null || rows[a].cells.item(0).innerText==''){
				end=a;
				break;
			}  
			if(!(rows[a].style.display === 'none')) {
				arr_index.push(a);
			
			}
				
     }
	
	var valuecount = 0;
	for(a=0;a<arr_index.length;a++)
	{
		cells = rows[arr_index[a]].cells;
		clen = cells.length;
		arr[valuecount] = new Array();
		
		for(j = 0; j < clen; j++) { 
			arr[valuecount][j] = cells[j].innerHTML;
			
		}
		valuecount++;
		
	}
	
		
	arr.sort(function(a, b)
	{
		var retval=0;
		var col1 = a[1];
		var col2 = b[1];
		var fA=parseFloat(col1);
		var fB=parseFloat(col2);
		
		if(col1 != col2) {
			if((fA==col1) && (fB==col2) ){ retval=( fA > fB ) ? asc : -1*asc; } //numerical
			else { retval=(col1 > col2) ? asc : -1*asc;}
		}	else if(col1 == col2) { 
			//if((fA==col1) && (fB==col2) ){ retval=( fA > fB ) ? asc : -1*asc; } //numerical
			//else { retval=(col1 > col2) ? asc : -1*asc;}
			retval = -1;
		}
		
		return retval;
	});
	
	var counter =0;
	for(var rowidx=0;rowidx<=valuecount-1;rowidx++)
	{
		start = arr_index[counter++];
		for(var colidx=0;colidx<2;colidx++){
			
			table.tBodies[0].rows[start].cells[colidx].innerHTML=arr[rowidx][colidx]//arr1[rowidx][colidx]; 
		}
		
	}
	
	if (asc == -1) {
		element.classList.remove('ui-icon-triangle-1-s');
        element.classList.add('ui-icon-triangle-2-s');
		
		} else {
	    
		 element.classList.remove('ui-icon-triangle-2-s');
         element.classList.add('ui-icon-triangle-1-s');
	}
	
}

function processAndCloseGoalTrackingSection(TutorDataDivId) {
	var breakout = "BreakOutByGoal"+TutorDataDivId;
	var showraw="showraw"+TutorDataDivId;
	var unduplicate="unduplicate"+TutorDataDivId;
	var hidebreak_row ="hidebreak_row"+TutorDataDivId;	
	Effect.Fade(breakout);
	Effect.BlindUp(breakout);
	var showrawId = document.getElementById(showraw);
	var unduplicateId = document.getElementById(unduplicate);
	 hidebreak_row = document.querySelectorAll('[id="' +hidebreak_row+ '"]');
	if(showrawId.classList.contains('isDisabled')===false)
		{
			unduplicateId.innerHTML = "Show Unduplicated Data";
			showrawId.innerHTML = "Show Raw Data";
			unduplicateId.classList.remove("isDisabled");
		}
	else if(unduplicateId.classList.contains('isDisabled')===false)
		{
			
			showrawId.innerHTML = "Show Raw Data";
			unduplicateId.innerHTML = "Show Unduplicated Data";
			showrawId.classList.remove("isDisabled");
		}
		for(var i = 0; i < hidebreak_row.length; i++) 
		{
			hidebreak_row[i].classList.add("raw_duplicate");
				hidebreak_row[i].style.display="none";
		}
	
}




