// this function is to open up the change phone number scroll down
function OpenChangecellphonenumber()
{
	if (document.getElementById("div_cellphonenumber").style.display == "none")
	{
		new Ajax.Request("/index.cfm?event=user.openchangephonenumber",{ 
	
				onSuccess: function(returnHtml) { 
	
				 Element.update("div_cellphonenumber", returnHtml.responseText);
				 //Effect.SlideDown("div_changeemail");
				 jQuery('#div_cellphonenumber').slideDown(1000);
				}, 
				onFailure: function(){ 
				alert('Oops...mistake on server');
				} 
			});
	}
	else
	{
		jQuery('#div_cellphonenumber').slideUp(1000);
	}		
}

//this is to close the slider down
function CancelCloseChangecellphonenumber()
{
	document.getElementById("imgLoadingChangePhone").style.display = "block";
	//Effect.SlideUp("div_changeemail");
	jQuery('#div_cellphonenumber').slideUp(1000);
	document.getElementById("imgLoadingChangePhone").style.display = "none";
}

//validating and updating the email address
/*
function updatephonenumberwithValidations(currentUserID)
{	
	var phone = document.getElementById('phonenumber').value;
	var length = phone.length;
	var phonepattern = /^[0-9]+$/; 
	document.getElementById("imgLoadingChangePhone").style.display = "block";
	var carrier = document.getElementById('carrier').value;
	var existingphonenumber = document.getElementById('existingphonenumber').value;
	if(phone !=""){
		if(length != 10){
			try{
			alert("Please enter a mobile device number with 10 digits and no symbols or spaces. \n\nExample: 5555555555."); 
			document.getElementById("imgLoadingChangePhone").style.display = "none";
			}catch(err){
				document.getElementById("imgLoadingChangePhone").style.display = "none";
			}
			return false;
		}else{
			if(!(phone.match(phonepattern))){
				try{
				alert("Please enter a mobile device number without spaces or symbols such as parentheses and dashes.\n\nExample: 5555555555");
				document.getElementById("imgLoadingChangePhone").style.display = "none";
				}catch(err){
					document.getElementById("imgLoadingChangePhone").style.display = "none";
				}
				return false;
			}else if(phone =="0000000000"){
				try{
					alert("Invalid number in the mobile device new number text box.");
					document.getElementById("imgLoadingChangePhone").style.display = "none";
					}catch(err){
						document.getElementById("imgLoadingChangePhone").style.display = "none";
					}
					return false;				
			}else{
				  if(carrier != 0){
					  try{
					  new Ajax.Request("/index.cfm?event=user.updatephonenumber&currentUserID="+currentUserID+"&phonenumber="+phone+"&carrierid="+carrier+"&alertuser=1",{ 
							
						onSuccess: function(returnHtml) { 
			
						 //Element.update("div_cellphonenumber", returnHtml.responseText);
						 document.getElementById("imgLoadingChangePhone").style.display = "none";
						 CancelCloseChangecellphonenumber();
						}, 
						onFailure: function(){ 
						document.getElementById("imgLoadingChangePhone").style.display = "none";
						alert('Oops...mistake on server');
						} 
						});
					  }catch(err){
						  document.getElementById("imgLoadingChangePhone").style.display = "none";
					  }
				  	//return true;
				  }else{
					try{  
				  	alert('Please use the drop-down menu to select a carrier for the mobile device number.');
				  	document.getElementById("imgLoadingChangePhone").style.display = "none";
					}catch(err){
						document.getElementById("imgLoadingChangePhone").style.display = "none";
					}
				  	return false;
				  }
			}
		 }
	}else if(carrier != 0){
		try{
		  new Ajax.Request("/index.cfm?event=user.updatephonenumber&currentUserID="+currentUserID+"&phonenumber="+phone+"&carrierid="+carrier+"&alertuser=1",{ 
				
				onSuccess: function(returnHtml) { 
	
				 //Element.update("div_cellphonenumber", returnHtml.responseText);
				 document.getElementById("imgLoadingChangePhone").style.display = "none";
				 CancelCloseChangecellphonenumber();
				}, 
				onFailure: function(){ 
				document.getElementById("imgLoadingChangePhone").style.display = "none";
				alert('Oops...mistake on server');
				} 
				});
		}catch(err){
			document.getElementById("imgLoadingChangePhone").style.display = "none";
		}
		  	//return true;
	}	
	if (existingphonenumber.length==0 && carrier == 0){
		try{
		alert('Please enter a mobile device number.\nPlease use the drop-down menu to select a carrier for the mobile device number.');
		document.getElementById("imgLoadingChangePhone").style.display = "none";
		}catch(err){
			document.getElementById("imgLoadingChangePhone").style.display = "none";
		}
		return false;
	}else if(carrier == 0){
		try{
		alert('Please use the drop-down menu to select a carrier for the mobile device number.');
	  	document.getElementById("imgLoadingChangePhone").style.display = "none";
		}catch(err){
			document.getElementById("imgLoadingChangePhone").style.display = "none";
		}
	  	return false;
		
	}

}
*/

function updatephonenumberwithValidations(currentUserID)
{
	
	/*Validation for Phone number*/	
	var phone = document.getElementById('phonenumber').value;
	var length = phone.length;
	var phonepattern = /^[0-9]+$/; 
	document.getElementById("imgLoadingChangePhone").style.display = "block";
	var existingphonenumber = document.getElementById('existingphonenumber').value;
	if(phone !=""){
		if(length != 10){
			try{
			alert("Please enter a mobile device number with 10 digits and no symbols or spaces. \n\nExample: 5555555555."); 
			document.getElementById("imgLoadingChangePhone").style.display = "none";
			}catch(err){
				document.getElementById("imgLoadingChangePhone").style.display = "none";
			}
			return false;
		}else{
			if(!(phone.match(phonepattern))){
				try{
				alert("Please enter a mobile device number without spaces or symbols such as parentheses and dashes.\n\nExample: 5555555555");
				document.getElementById("imgLoadingChangePhone").style.display = "none";
				}catch(err){
					document.getElementById("imgLoadingChangePhone").style.display = "none";
				}
				return false;
			}else if(phone =="0000000000"){
				try{
					alert("Invalid number in the mobile device new number text box.");
					document.getElementById("imgLoadingChangePhone").style.display = "none";
					}catch(err){
						document.getElementById("imgLoadingChangePhone").style.display = "none";
					}
					return false;				
			}else{
				if((phone).length == 10 && isNaN(phone)==false){
					try{
					  new Ajax.Request("/index.cfm?event=user.vaildateMobileNumberBySlooce&phoneNumber="+phone,{ 	async:false,						
						  onSuccess: function(response) {
								data = response.responseText;
								data = data.replace(/^["'](.+(?=["']$))["']$/, '$1');
								if(data != 'true'){
									document.getElementById("imgLoadingChangePhone").style.display = "none";
									alert(data);
									return false;
								}else{
									try{
									  new Ajax.Request("/index.cfm?event=user.updatephonenumber&currentUserID="+currentUserID+"&phonenumber="+phone+"&alertuser=1",{
										async:false,					
										onSuccess: function(returnHtml) { 
										 	//Element.update("div_cellphonenumber", returnHtml.responseText);
										 	document.getElementById("imgLoadingChangePhone").style.display = "none";
										 	CancelCloseChangecellphonenumber();
											Console.log('saved');
										}, 
										onFailure: function(){ 
											document.getElementById("imgLoadingChangePhone").style.display = "none";
											alert('Oops...mistake on server');
										} 
									 });
								    }catch(err){
									  document.getElementById("imgLoadingChangePhone").style.display = "none";
									}
								}
							}, 
							onFailure: function(){ 
								document.getElementById("imgLoadingChangePhone").style.display = "none";
								alert('Oops...mistake on server');
							} 
						});
					}catch(err){
						  document.getElementById("imgLoadingChangePhone").style.display = "none";
					}
				}	
			}
		 }
	}
	
	/*if (existingphonenumber.length==0){
		try{
		alert('Please enter a mobile device number.');
		document.getElementById("imgLoadingChangePhone").style.display = "none";
		}catch(err){
			document.getElementById("imgLoadingChangePhone").style.display = "none";
		}
		return false;
	}*/

}

function removephonenumber(currentUserID){

	try{
		var confirmques = confirm('Are you sure you want to remove the mobile device number?');
		if(confirmques){
			document.getElementById("imgLoadingChangePhone").style.display = "block";
			try{
				  new Ajax.Request("/index.cfm?event=user.removephonenumber&currentUserID="+currentUserID,{ 
						
						onSuccess: function(returnHtml) { 
			
						 //Element.update("div_cellphonenumber", returnHtml.responseText);
						 document.getElementById("imgLoadingChangePhone").style.display = "none";
						 CancelCloseChangecellphonenumber();
						}, 
						onFailure: function(){ 
						document.getElementById("imgLoadingChangePhone").style.display = "none";
						alert('Oops...mistake on server');
						} 
						});
				}catch(err){
					document.getElementById("imgLoadingChangePhone").style.display = "none";
				}
		}
	}catch(err){
		document.getElementById("imgLoadingChangePhone").style.display = "none";
	}
}