var root='';
var $dialog = {};
var $accordion;
var __startPeriod = "", __endPeriod = "", __selectedSurveysList = "", __notselectedSurveysList = "", _step4editCounter = 0, _compilation = '', _selectedMatrixRowId = '';
var _userSelectedGroups = "", identifierLoadStatus = 0, _step2editCounter = 0,  _step6editCounter = 0, filterFieldValuesStatus = 0;
var flag_matrixtrueView=false;

function showLoadingOverlay() {
   $j('#ajaxFilterLoading').css('display','block');
   $j('#ajaxFilterLoading .bg').height('100%');
   $j('#ajaxFilterLoading').fadeIn(300);
   $j("#ajaxFilterLoading").attr("tabindex",-1).focus();
}
function hideLoadingOverlay() {
   $j('#ajaxFilterLoading').css('display','none');
   $j('#ajaxFilterLoading .bg').height('100%');
   $j('#ajaxFilterLoading').fadeOut(300);
}

function showLoadingOverlay2() {
	$j('#ajaxFilterLoading').css('opacity','0');
	$j('#ajaxFilterLoading').css('display','block');
	$j('#ajaxFilterLoading .bg').height('100%');
	$j('#ajaxFilterLoading').fadeIn(300);
	$j("#ajaxFilterLoading").attr("tabindex",-1).focus();
 }
 function hideLoadingOverlay2() {
	$j('#ajaxFilterLoading').css('display','none');
	$j('#ajaxFilterLoading .bg').height('100%');
	$j('#ajaxFilterLoading').fadeOut(300);
	$j('#ajaxFilterLoading').css('opacity','0.3');
 }

function dialogSettings(title, dialogClass, maxWidth, width, maxHeight, height) {
    return {
        modal: true,
        title: title,
        resizable: false,
        maxWidth: maxWidth,
        maxHeight: maxHeight,
        width: width,
        height: height,
        autoOpen: false,
        //position:['center',50],
        dialogClass: dialogClass,
	close: destroyDialog
    }
}

function destroyDialog() {
	$j(this).empty();
}

function checkSession(){	
	var pgmid=$j('#pgmid').val();	
	$j.ajax({
		url: 'index.cfm?event=sl.checkSession&oldlocation="'+window.location.href+'"' ,
		data : {pgmid:pgmid},
		async:false,
		type: "POST",
		beforeSend: function(){			
	 	},
		success:function(response)
		{
				if(response==0){
					window.location.href ='index.cfm?event=user.login&oldlocation=' + escape(window.location.href.substr(window.location.href.indexOf('event=')));
				}
				else if(pgmid!=response){
					window.location.href ='index.cfm?event=user.notauthorized';	
					return false;
				}		
		},
		complete:function()
		{			
		},
		error :function()
		{
			alert('error occurred!!');
		}
	});
}

function enableNextStep(step) // button, next_div_id
{	
	showLoadingOverlay();
	checkSession();
	var stepChangeFlag = true;
	var $sections = $j('div.panelhead');
	var index = step - 1; //Index of Step to Enable (Next Step)
	$j($sections[index]).removeClass('ui-state-disabled');
	$j($sections[index]).next('div.contentBodyPanel').removeClass('ui-state-disabled');
	//setSectionIcon($sections[index], 'edit');

	if (index == 1) {
		if (index == 1 && formData.userSelectedAction == "viewData") {
			$j('div.step6select').closest('div.surveylistgroup').css('display','none');
		} else {
			$j('div.step6select').closest('div.surveylistgroup').css('display','block');
		}
		if(formData.setStep2 == 0) {setSelectedBGinhidden();} //SURVEXPORT-254
	}
	
	if (step > 1) {
		var curindex = step - 2; //Index of Step which was set (Old Step);
		$j($sections[curindex]).next('div.contentBodyPanel').addClass('setDiv');
		setSectionIcon($sections[curindex], 'set');
		//$j($sections[curindex]).next('div.contentBodyPanel').show(); moved accordion activate()
		 
		if (curindex == 2 ) {
			if( $j('#include_raw_questions').prop('checked') == true) {
					 
					var _$accor_head = $j(".panelhead");
					var _$accor = _$accor_head.next('div.contentBodyPanel');				
					$j(_$accor[5]).removeClass('setDiv');					
					setSectionIcon(_$accor_head[5], 'edit');
					$j('#exportOptionSelections').show();
					$j("#btnselectexportoptions").show();		
					$j("#exportOptionSummary").hide();		
					$j("#editcheckstep6").hide();	
					_step6editCounter = 0; //reset edit counter
					formData.setStep6 = 0;
					stepChangeFlag == false;
					$j('#include_raw_questions').prop('checked',false);
					$j('#columnsToInclude').css('display','none');
					$j('#include_raw_questions').trigger('click');
					showhideExportExcelButton();
				}
			if($j('#groupincude_total').prop('checked') == true) {
				 
				var _$accor_head = $j(".panelhead");
				var _$accor = _$accor_head.next('div.contentBodyPanel');				
				$j(_$accor[5]).removeClass('setDiv');					
				setSectionIcon(_$accor_head[5], 'edit');
				$j('#exportOptionSelections').show();
				$j("#btnselectexportoptions").show();		
				$j("#exportOptionSummary").hide();		
				$j("#editcheckstep6").hide();	
				_step6editCounter = 0; //reset edit counter
				formData.setStep6 = 0;
				stepChangeFlag == false;
				$j('#groupincude_total').prop('checked',false);
				$j('#grouptotaloptionsinclude').css('display','none');
				$j('#groupincude_total').trigger('click');
				showhideExportExcelButton();
			}
		}
		if (curindex == 4 ){
		//if (formData.compilation != __compilation || formData.selectedMatrixRowId != __selectedMatrixRowId){
			if( $j('#include_raw_questions').prop('checked') == true) {
					 
					var _$accor_head = $j(".panelhead");
					var _$accor = _$accor_head.next('div.contentBodyPanel');				
					$j(_$accor[5]).removeClass('setDiv');					
					setSectionIcon(_$accor_head[5], 'edit');
					$j('#exportOptionSelections').show();
					$j("#btnselectexportoptions").show();		
					$j("#exportOptionSummary").hide();		
					$j("#editcheckstep6").hide();	
					_step6editCounter = 0; //reset edit counter
					formData.setStep6 = 0;
					stepChangeFlag == false;
					$j('#include_raw_questions').prop('checked',false);
					$j('#columnsToInclude').css('display','none');
					$j('#include_raw_questions').trigger('click');
					showhideExportExcelButton();
				}
			if( $j('#groupincude_total').prop('checked') == true) {
					 
					var _$accor_head = $j(".panelhead");
					var _$accor = _$accor_head.next('div.contentBodyPanel');				
					$j(_$accor[5]).removeClass('setDiv');					
					setSectionIcon(_$accor_head[5], 'edit');
					$j('#exportOptionSelections').show();
					$j("#btnselectexportoptions").show();		
					$j("#exportOptionSummary").hide();		
					$j("#editcheckstep6").hide();	
					_step6editCounter = 0; //reset edit counter
					formData.setStep6 = 0;
					stepChangeFlag == false;
					$j('#groupincude_total').prop('checked',false);
					$j('#grouptotaloptionsinclude').css('display','none');
					$j('#groupincude_total').trigger('click');
					showhideExportExcelButton();
				}
		//}
		}
		
		if (curindex == 3 && _step4editCounter > 0) { //if this is step 4 and values are editted
			if (formData.startPeriod != __startPeriod || formData.endPeriod != __endPeriod 
				|| formData.selectedSurveysList != __selectedSurveysList || formData.notselectedSurveysList != __notselectedSurveysList) {
				//Reset step-5
				$j('#selectedQuestionIdReporting').val(""); //reset question
				$j('#selectedMatrixRowId').val(""); //reset matrix question
				$j('#hdn_SelectdReportRadio').val(""); //reset selected report
				$j('#radio_SelectedreportType_alldata').trigger("click"); //reset radio option | .prop("checked", true)
				
				if(formData.setStep5 == 1) {
					$j('.lblSummarySurveyData').css('display', 'none');	
					$j('#btneditselecteddata').trigger("click"); //reset radio option | .prop("checked", true)
					var _$accor_head = $j(".panelhead");
					var _$accor = _$accor_head.next('div.contentBodyPanel');				
					$j(_$accor[4]).removeClass('setDiv');
					//$j(_$accor[4]).hide(); //SURVEXPORT-264 - if accordion already active content not displayed
					setSectionIcon(_$accor_head[4], 'set');
					formData.setStep5 == 0;
					showhideExportExcelButton();
				}	
				if( $j('#include_raw_questions').prop('checked') == true) {
					 
					var _$accor_head = $j(".panelhead");
					var _$accor = _$accor_head.next('div.contentBodyPanel');				
					$j(_$accor[5]).removeClass('setDiv');					
					setSectionIcon(_$accor_head[5], 'edit');
					$j('#exportOptionSelections').show();
					$j("#btnselectexportoptions").show();		
					$j("#exportOptionSummary").hide();		
					$j("#editcheckstep6").hide();	
					_step6editCounter = 0; //reset edit counter
					formData.setStep6 = 0;
					stepChangeFlag == false;
					$j('#include_raw_questions').prop('checked',false);
					$j('#columnsToInclude').css('display','none');
					$j('#include_raw_questions').trigger('click');
					showhideExportExcelButton();
				}		
			   if( $j('#groupincude_total').prop('checked') == true) {
					 
					var _$accor_head = $j(".panelhead");
					var _$accor = _$accor_head.next('div.contentBodyPanel');				
					$j(_$accor[5]).removeClass('setDiv');					
					setSectionIcon(_$accor_head[5], 'edit');
					$j('#exportOptionSelections').show();
					$j("#btnselectexportoptions").show();		
					$j("#exportOptionSummary").hide();		
					$j("#editcheckstep6").hide();	
					_step6editCounter = 0; //reset edit counter
					formData.setStep6 = 0;
					stepChangeFlag == false;
					$j('#groupincude_total').prop('checked',false);
					$j('#grouptotaloptionsinclude').css('display','none');
					$j('#groupincude_total').trigger('click');
					showhideExportExcelButton();
				}																						
			}
			else {
				stepChangeFlag = false; //setSectionIcon($sections[index], 'set');
			}
			_step4editCounter = 0; //reset edit counter
		}
				
		if (curindex == 1 && (_step2editCounter > 0 || _step6editCounter > 0)) { //if this is step 2 and values are editted
			if (formData.userSelectedGroups != _userSelectedGroups) {
				//Reset step-3 and step-6 to default				
				var _$accor_head = $j(".panelhead");
				var _$accor = _$accor_head.next('div.contentBodyPanel');			
				if(formData.setStep3 == 1) {														
					$j(_$accor[2]).removeClass('setDiv');					
					setSectionIcon(_$accor_head[2], 'edit');
					setIdentifiersIncludeSection();
					_step2editCounter = 0; //reset edit counter
					stepChangeFlag == false;
					formData.setStep3 == 0;
					showhideExportExcelButton();
				}
				
				if(formData.setStep6 == 1 && $j('#rad_customize_views_excel').prop('checked') == true && ($j('#ProfileField').prop('checked') || $j('#incudeIdentifier').prop('checked'))) {					
					$j(_$accor[5]).removeClass('setDiv');					
					setSectionIcon(_$accor_head[5], 'edit');		
					$j('#exportOptionSelections').show();
					$j("#btnselectexportoptions").show();		
					$j("#exportOptionSummary").hide();		
					$j("#editcheckstep6").hide();	
					if($j('#ProfileField').prop('checked')) {
						$j('#ProfileField').prop('checked',false);
						$j('#totalprofilefield').css('display','none');
					}
					if($j('#incudeIdentifier').prop('checked')) {
						$j('#incudeIdentifier').prop('checked',false);
						$j('#includeIdentifierfield').css('display','none');
						$j('#arrangepanelfields').css('display','none');
					}
					_step6editCounter = 0; //reset edit counter
					formData.setStep6 = 0;
					stepChangeFlag == false;
					showhideExportExcelButton();
				}
			}
			else {
				stepChangeFlag = false; //setSectionIcon($sections[index], 'set');
			}			
		}
	}
	if (typeof($accordion) == 'object') {
		if (formData['setStep'+step] > 0) { //Check if step is already set
			var chkStep = step + 1;			
			var lblStep;
			for (chkStep;chkStep<5;chkStep++) {
				if (lblStep in formData) { //key exist in formData
					lblStep = 'setStep'+chkStep;
					if (formData[lblStep] == 0) { //step is not set
						index = chkStep-1;
						break;//return false;
					}
				} else {
					break;
				}
			}
		}
		if ($accordion.accordion( "option", "active" ) != index && stepChangeFlag == true && $j($sections[index]).next('div.contentBodyPanel').hasClass('setDiv') == false) {
			$accordion.accordion({active:index});
			setSectionIcon($sections[index], 'edit');
		}else{
			hideLoadingOverlay();
		}
	}	
	if($j('#hdn_submitted_steps').val() < index)	
		$j('#hdn_submitted_steps').attr('value',index);	
}

function setSectionIcon(div, mode) { //div - div.panelhead, mode - edit/set (button value)	
	if (mode == 'set') {
		$j(div).removeClass('step-edit-mode').addClass('step-set-mode');
	}else {	//else if (mode == 'edit') //default mode on active
		$j(div).removeClass('step-set-mode').addClass('step-edit-mode');
	}
}

function SetSurveyFormPreviewLink()
{
	formID = $j('#selSurveyFormID').val();
	if(formID != "0"){
		var url = 'index.cfm?event=survey.previewsurvey&surveyaction=preview&sfid='+formID;
		$j('#linkViewForm').prop('href', url);
		$j('#linkViewForm').show();	
		$j('#btnSelectSurveys').css('display', 'block');		
	}else{
		$j('#linkViewForm').hide();		
		$j('#btnSelectSurveys').css('display', 'none');	
	}
}

/* FOR STEP 5 | Select Data to Include */

function trclose(trname)
{
	document.getElementById(trname).style.display = 'none';
}

//this is the function to show the available to programwide sitewide and associatiion wide and also the counter for survey report name field

function CounterAndSelectionTableShow(field,max)
{			
	var firstCharacter = field.value.substring(0, 1);
	var nowCount;
	if (firstCharacter == ' '){
		alert("Please enter a report title that begins with a letter or a number.");
		field.value = "";
		document.getElementById(field.name+"_cnt").childNodes[0].nodeValue = max;
	}
	else {			
		if (/^[a-z\s\d]*$/i.test(firstCharacter)){
			//this is for the counter to show
					
			if (field.value.length > max){
				field.value = field.value.substring(0, max);
			} 
			else { 	
				nowCount = max - field.value.length;
				
				if (field.id == 'txt_ReportName'){
					if (nowCount < 140){
						document.getElementById("ReportAvailableTable").style.display = 'block';
					}
					else{
						document.getElementById("ReportAvailableTable").style.display = 'none';
						
						//unchecking the checkboxes report availability 
						document.getElementById("chkbx_report1").checked = false;
						document.getElementById("chkbx_report2").checked = false;
					}
				}						
					document.getElementById(field.name+"_cnt").childNodes[0].nodeValue = nowCount;
			}
		}
		else{
			alert("Please enter a report title that begins with a letter or a number.");
			field.value = "";
			document.getElementById(field.name+"_cnt").childNodes[0].nodeValue = max;
		}
	}	  
}

//this is for the pop up when edit report is clicked
function tutorAnsweredPopUp(surveyId) {
	window.open("index.cfm?event=survey.getuserstatusforsurvey&surveyid="+surveyId,"CompletionStatus","height=310,width=582,status=0,menubar=0,titlebar=0,resizable=1,scrollbars=1")
}

function AllorNoneSelectedSites(typeSelected, listid, clean_data){		
	var sites = document.getElementsByName(listid);		
	for (i = 0; i < sites.length; i++)
	{
		if(typeSelected == "all"){
			sites[i].checked = true;
		}else{
			sites[i].checked = false;
		}
	}
}

function getRoleList(appendTo, selectedRoles){
	if (appendTo == undefined){
		appendTo = '#availTo_rolelist';
		var name = 'roleid'; }
		else {
			var name = 'roleid_report'; }
		if (selectedRoles == undefined){
			selectedRoles = []; }

	$j.ajax({
		url: root+'survey.rolelistingsection',
		type: "POST",
		beforeSend: function() {
			showLoadingOverlay();
		},
		success : function(response)
		{			
			var parsedRolelist = $j.parseJSON(response);
			var rolelist = parsedRolelist.data;
			var listLen = rolelist.length;
			var htmlEle = '<div id="role-box" class="">';
			var thisRole;
			for (var i=0; i<listLen;i++){
				thisRole = rolelist[i];
				htmlEle = htmlEle +'<div class="formField showToogleRole" style="padding-top: 8px;">'+
					'<span class="verticalMiddle">'+
					'<input type="checkbox" class="showToogleRole chkShowRole" name="'+name+'" id="role_'+thisRole.roleid+'" value="'+thisRole.roleid+'" >'+
					'</span>'+
					'<span class=""><label for="role_'+thisRole.roleid+'">'+thisRole.rolename+'</label></span></div>';
			}
			htmlEle = htmlEle + '</div>';
			$j(appendTo).html(htmlEle).show();				
			
			setTimeout(function(){
				if (selectedRoles.length) {
					for (var r=0;r<selectedRoles.length;r++) {
						if ($j('#role_'+selectedRoles[r]).length) {
							$j('#role_'+selectedRoles[r]).prop('checked', true);						
							/* $j('input[name='+name+'][id=role_'+selectedRoles[r]+']').prop('checked', 'checked'); */
						}
					}
				}
			},0);						
		},	
		complete: function()
		{
			hideLoadingOverlay();
		},
		error: function() {
				alert("failure");
			}
		});	
}

function assignMatrixRowstoHiddenField(passedMatrixRowsID) {
	if (document.getElementById("selectedMatrixRowId").value == '') { // if there is no elemen selected
		document.getElementById("selectedMatrixRowId").value = passedMatrixRowsID;
	} else {
		document.getElementById("showorhidequestions").style.display = 'block';
		var hiddenvalue = document.getElementById("selectedMatrixRowId").value;
		var hiddenvaluearray = hiddenvalue.split('^^^');
		var elementexists = 0;
		for (var i = 0; i < hiddenvaluearray.length; i++) {
			if (hiddenvaluearray[i] == passedMatrixRowsID) {
				hiddenvaluearray.splice(hiddenvaluearray.indexOf(hiddenvaluearray[i]), 1);
				elementexists = 1;
			}
		}
		if (elementexists != 1) {
			if (document.getElementById("selectedMatrixRowId").value != '') {
				document.getElementById("selectedMatrixRowId").value = document.getElementById("selectedMatrixRowId").value + "^^^" + passedMatrixRowsID;
			} else {
				document.getElementById("selectedMatrixRowId").value = passedMatrixRowsID;
			}
		} else {
			document.getElementById("selectedMatrixRowId").value = '';
			for (var i = 0; i < hiddenvaluearray.length; i++) {
				if (hiddenvaluearray[i] != passedMatrixRowsID) {
					if (document.getElementById("selectedMatrixRowId").value == '') {
						document.getElementById("selectedMatrixRowId").value = hiddenvaluearray[i];
					} else {
						document.getElementById("selectedMatrixRowId").value = document.getElementById("selectedMatrixRowId").value + "^^^" + hiddenvaluearray[i];
					}
				}
			}
		}
	}
}

function removeMatrixRowstoHiddenField(passedMatrixRowsID) {

	document.getElementById("showorhidequestions").style.display = 'block';
	/* get hidden value */
	var hiddenvalue = document.getElementById("selectedMatrixRowId").value;
	var hiddenvaluearray = hiddenvalue.split('^^^');
	var elementexists = 0;
	for (var i = 0; i < hiddenvaluearray.length; i++) {
		if (hiddenvaluearray[i] == passedMatrixRowsID) {
			hiddenvaluearray.splice(hiddenvaluearray.indexOf(hiddenvaluearray[i]), 1);
			elementexists = 1;
		}
	}
	if (elementexists == 1) {
		document.getElementById("selectedMatrixRowId").value = '';
		for (var i = 0; i < hiddenvaluearray.length; i++) {
			if (hiddenvaluearray[i] != passedMatrixRowsID) {
				if (document.getElementById("selectedMatrixRowId").value == '') {
					document.getElementById("selectedMatrixRowId").value = hiddenvaluearray[i];
				} else {
					document.getElementById("selectedMatrixRowId").value = document.getElementById("selectedMatrixRowId").value + "^^^" + hiddenvaluearray[i];
				}
			}
		}
	}
}

function closeandOpenEachCategoryQuestions(passedCategoryID)
{
	var passedCategoryID = passedCategoryID ;
	var imagenameid = "img_"+passedCategoryID;
	var trid = "tr_"+passedCategoryID;
	document.getElementById(imagenameid).style.display = "block";
	if (document.getElementById(trid).style.display != 'none'){
		document.getElementById(trid).style.display = "none";
	}
	else{
		document.getElementById(trid).style.display = "block";
	}
	document.getElementById(imagenameid).style.display = "none";
}

function closeAnswerSectionEditOnly(trnamePassed,process)
{

	if (process == "edit") {
		if (trnamePassed == "reqquestioncheckbox") {
			trnamePassed = "tr"+trnamePassed+"edit";
		}
		else if (trnamePassed == "retquestioncheckbox") {
			trnamePassed = "tr"+trnamePassed+"edit";
		}
		else {
			trnamePassed = "tr_"+trnamePassed+"_datarowedit";
		}
	}
	else {
		if (trnamePassed == "reqquestioncheckbox") {
			trnamePassed = "tr"+trnamePassed+"clone";
		}
		else if (trnamePassed == "retquestioncheckbox") {
			trnamePassed = "tr"+trnamePassed+"clone";
		}
		else {
			trnamePassed = "tr_"+trnamePassed+"_datarowclone";
		}
	}
	
	document.getElementById(trnamePassed).style.display = "none";
}

function closeAnswerSectionEditOnlyfor1(trnamePassed)
{
	if (trnamePassed == "reqquestioncheckbox")
	{
		trnamePassed = "tr"+trnamePassed+"edit1";
	}
	else if (trnamePassed == "retquestioncheckbox")
	{
		trnamePassed = "tr"+trnamePassed+"edit1";
	}
	else
	{
		trnamePassed = "tr_"+trnamePassed+"_datarowedit1";
	}
	
	document.getElementById(trnamePassed).style.display = "none";
}

function displayDataForCategoryReportedit(categoryname,selPrograms,imgname,process)
{
	if(process == 'edit') {
		try {
			selectedQuestions = document.getElementById("txt_selectedquestionidfileidlist").value;
			selectedQuestions = selectedQuestions.replace(/,/g, '^^^');
		}
		catch(err) {
			selectedQuestions = document.getElementById("getCurrentQuestionIDFileIDList").value;
			selectedQuestions = selectedQuestions.replace(/,/g, '^^^');
		}
	
					imgnamepassed = "img_"+imgname+"edit";
	
					if (categoryname == 'alrq') {
						if (document.getElementById("trreqquestioncheckboxedit").style.display == 'none') {
							document.getElementById(imgnamepassed).style.display = 'block';
							new Ajax.Request("/index.cfm?event=survey.getdataforsurveycategoryreportedit",{
							method: 'post',
							parameters: {categoryname: categoryname, selPrograms: selPrograms,imgname:imgname,selectedQuestions:selectedQuestions,process:process},
							
							onSuccess: function(returnHtml) { 
							document.getElementById("trreqquestioncheckboxedit").style.display = 'block';
							Element.update("tdreqquestioncheckboxedit", returnHtml.responseText); 
							document.getElementById(imgnamepassed).style.display = 'none';
							}, 
							onFailure: function()
							{ 
								alert('Oops...mistake on server');
							} 
							});
						}
						else {
							trclose('trreqquestioncheckboxedit');
						}
					}
					if (categoryname == 'alretq') {
						
						if (document.getElementById("trretquestioncheckboxedit").style.display == 'none') {
							document.getElementById(imgnamepassed).style.display = 'block';
							new Ajax.Request("/index.cfm?event=survey.getdataforsurveycategoryreportedit&categoryname="+categoryname+"&selPrograms="+selPrograms+"&imgname="+imgname+"&selectedQuestions="+selectedQuestions+"&process="+process,{ 
							onSuccess: function(returnHtml) { 
						
							document.getElementById("trretquestioncheckboxedit").style.display = 'block';
							Element.update("tdretquestioncheckboxedit", returnHtml.responseText); 
							document.getElementById(imgnamepassed).style.display = 'none';
							}, 
							onFailure: function()
							{ 
								alert('Oops...mistake on server');
							} 
							});
	
						}
						else {
							trclose('trretquestioncheckboxedit');
						}
					}
					if (categoryname != 'alretq' && categoryname != 'alrq') {
							categorynamefortableelements = categoryname.replace(/ /g, '');
							trcategorynamedatarow = "tr_"+categorynamefortableelements+"_datarowedit";
							tdcategorynamedatarow = "td_"+categorynamefortableelements+"_datarowedit";
							
							if (document.getElementById(trcategorynamedatarow).style.display == 'none') {
								document.getElementById(imgnamepassed).style.display = 'block';
								categoryname = categoryname.replace(/&/g, 'amper~~');
								imgname = imgname.replace(/&/g, 'amper~~');
								new Ajax.Request("/index.cfm?event=survey.getdataforsurveycategoryreportedit&categoryname="+categoryname+"&selPrograms="+selPrograms+"&imgname="+imgname+"&selectedQuestions="+selectedQuestions+"&process="+process,{ 
								onSuccess: function(returnHtml) { 
								document.getElementById(trcategorynamedatarow).style.display = 'block';
								Element.update(tdcategorynamedatarow, returnHtml.responseText); 
								document.getElementById(imgnamepassed).style.display = 'none';
								}, 
								onFailure: function()
								{ 
									alert('Oops...mistake on server');
								} 
								});
							}
							else {
								trclose(trcategorynamedatarow);
							}
					}
	}
	
	if (process == 'edit1') {
		try {
			selectedQuestions = document.getElementById("txt_selectedquestionidfileidlist").value;
			selectedQuestions = selectedQuestions.replace(/,/g, '^^^');
		}
		catch(err) {
			selectedQuestions = document.getElementById("getCurrentQuestionIDFileIDList").value;
			selectedQuestions = selectedQuestions.replace(/,/g, '^^^');
		}
	
					imgnamepassed = "img_"+imgname+"edit1";
	
					if (categoryname == 'alrq') {
						if (document.getElementById("trreqquestioncheckboxedit1").style.display == 'none') {
							document.getElementById(imgnamepassed).style.display = 'block';
							new Ajax.Request("/index.cfm?event=survey.getdataforsurveycategoryreportedit&categoryname="+categoryname+"&selPrograms="+selPrograms+"&imgname="+imgname+"&selectedQuestions="+selectedQuestions,{ 
							onSuccess: function(returnHtml) { 
							document.getElementById("trreqquestioncheckboxedit1").style.display = 'block';
							Element.update("tdreqquestioncheckboxedit1", returnHtml.responseText); 
							document.getElementById(imgnamepassed).style.display = 'none';
							}, 
							onFailure: function()
							{ 
								alert('Oops...mistake on server');
							} 
							});
						}
						else {
							trclose('trreqquestioncheckboxedit1');
						}
					}
					if (categoryname == 'alretq') {
						
						if (document.getElementById("trretquestioncheckboxedit1").style.display == 'none') {
							document.getElementById(imgnamepassed).style.display = 'block';
							new Ajax.Request("/index.cfm?event=survey.getdataforsurveycategoryreportedit&categoryname="+categoryname+"&selPrograms="+selPrograms+"&imgname="+imgname+"&selectedQuestions="+selectedQuestions,{ 
							onSuccess: function(returnHtml) { 
						
							document.getElementById("trretquestioncheckboxedit1").style.display = 'block';
							Element.update("tdretquestioncheckboxedit1", returnHtml.responseText); 
							document.getElementById(imgnamepassed).style.display = 'none';
							}, 
							onFailure: function()
							{ 
								alert('Oops...mistake on server');
							} 
							});
	
						}
						else {
							trclose('trretquestioncheckboxedit1');
						}
					}
					if (categoryname != 'alretq' && categoryname != 'alrq') {
							categorynamefortableelements = categoryname.replace(/ /g, '');
							trcategorynamedatarow = "tr_"+categorynamefortableelements+"_datarowedit1";
							tdcategorynamedatarow = "td_"+categorynamefortableelements+"_datarowedit1";
							categoryname = categoryname.replace(/&/g, 'amper~~');
							imgname = imgname.replace(/&/g, 'amper~~');
							if (document.getElementById(trcategorynamedatarow).style.display == 'none')
							{
								document.getElementById(imgnamepassed).style.display = 'block';
								categoryname = categoryname.replace(/&/g, 'amper~~');
								new Ajax.Request("/index.cfm?event=survey.getdataforsurveycategoryreportedit&categoryname="+categoryname+"&selPrograms="+selPrograms+"&imgname="+imgname+"&selectedQuestions="+selectedQuestions,{ 
								onSuccess: function(returnHtml) { 
								document.getElementById(trcategorynamedatarow).style.display = 'block';
								Element.update(tdcategorynamedatarow, returnHtml.responseText); 
								document.getElementById(imgnamepassed).style.display = 'none';
								}, 
								onFailure: function()
								{ 
									alert('Oops...mistake on server');
								} 
								});
							}
							else {
								trclose(trcategorynamedatarow);
							}
					}
	}
	
	if (process == 'clone') {
		try {
			selectedQuestions = document.getElementById("txt_selectedquestionidfileidlist").value;
			selectedQuestions = selectedQuestions.replace(/,/g, '^^^');
		}
		catch(err) {
			selectedQuestions = document.getElementById("getCurrentQuestionIDFileIDList").value;
			selectedQuestions = selectedQuestions.replace(/,/g, '^^^');
		}
	
			imgnamepassed = "img_"+imgname+"clone";

			if (categoryname == 'alrq') {
				if (document.getElementById("trreqquestioncheckboxclone").style.display == 'none')
				{
					document.getElementById(imgnamepassed).style.display = 'block';
					new Ajax.Request("/index.cfm?event=survey.getdataforsurveycategoryreportedit&categoryname="+categoryname+"&selPrograms="+selPrograms+"&imgname="+imgname+"&selectedQuestions="+selectedQuestions,{ 
					onSuccess: function(returnHtml) { 
					document.getElementById("trreqquestioncheckboxclone").style.display = 'block';
					Element.update("tdreqquestioncheckboxclone", returnHtml.responseText); 
					document.getElementById(imgnamepassed).style.display = 'none';
					}, 
					onFailure: function()
					{ 
						alert('Oops...mistake on server');
					} 
					});
				}
				else {
					trclose('trreqquestioncheckboxclone');
				}
			}
			if (categoryname == 'alretq') {
				
				if (document.getElementById("trretquestioncheckboxclone").style.display == 'none') {
					document.getElementById(imgnamepassed).style.display = 'block';
					new Ajax.Request("/index.cfm?event=survey.getdataforsurveycategoryreportedit&categoryname="+categoryname+"&selPrograms="+selPrograms+"&imgname="+imgname+"&selectedQuestions="+selectedQuestions,{ 
					onSuccess: function(returnHtml) { 
				
					document.getElementById("trretquestioncheckboxclone").style.display = 'block';
					Element.update("tdretquestioncheckboxclone", returnHtml.responseText); 
					document.getElementById(imgnamepassed).style.display = 'none';
					}, 
					onFailure: function()
					{ 
						alert('Oops...mistake on server');
					} 
					});

				}
				else {
					trclose('trretquestioncheckboxclone');
				}
			}
			if (categoryname != 'alretq' && categoryname != 'alrq') {
					categorynamefortableelements = categoryname.replace(/ /g, '');
					trcategorynamedatarow = "tr_"+categorynamefortableelements+"_datarowclone";
					tdcategorynamedatarow = "td_"+categorynamefortableelements+"_datarowclone";
					
					if (document.getElementById(trcategorynamedatarow).style.display == 'none') {
						document.getElementById(imgnamepassed).style.display = 'block';
						categoryname = categoryname.replace(/&/g, 'amper~~');
						imgname = imgname.replace(/&/g, 'amper~~');
						new Ajax.Request("/index.cfm?event=survey.getdataforsurveycategoryreportedit&categoryname="+categoryname+"&selPrograms="+selPrograms+"&imgname="+imgname+"&selectedQuestions="+selectedQuestions,{ 
						onSuccess: function(returnHtml) { 
						document.getElementById(trcategorynamedatarow).style.display = 'block';
						Element.update(tdcategorynamedatarow, returnHtml.responseText); 
						document.getElementById(imgnamepassed).style.display = 'none';
						}, 
						onFailure: function()
						{ 
							alert('Oops...mistake on server');
						} 
						});
					}
					else {
						trclose(trcategorynamedatarow);
					}
			}
	}	
}

function EditSelectedData($this) {
	//$j('#ui-id-3').trigger('click');
	checkSession();
	$j('.lblSummarySurveyData').slideUp(100);
	$j('#editselectdatacheck').slideUp(100);
	var selectedradioval = $j.trim($j('input[name=radio_SelectedreportType]:checked').val());	
	if (selectedradioval == 'selecteddata') {		
		if ($j('#showorhidequestions').text().trim() == "Only Display Selected Items") {
			//$j('input#txt_ReportName').val('');
			//CounterAndSelectionTableShow($j('input#txt_ReportName')[0],140);
			ShowSelectedData();
		}
	}
	$j('.container_selectedreportType').slideDown(700);
	formData.setStep5 = 0;
	//$j($this).closest('div.contentBodyPanel').removeClass('setDiv');
	var accor_div = $j($this).closest('div.contentBodyPanel').prev('div.panelhead')[0];
	setSectionIcon(accor_div, 'edit');
	showhideExportExcelButton();
}

//FUNCTION for carrying out validations in the report cloning pop up
function checkreportCloneValidation()
{
	if (document.getElementById("txt_selectedquestionidfileidlist").value == '') {
		//if no questions are selected
		alert("Please select atleast one question.");
	}
	else {
		//if questions are already selected
		
		//if no name is given for the project
		if (document.getElementById("txt_ReportNameClone").value == '') {
			alert("Please give a name for the report.");
		}
		else {
			checkalreadythere = 0;
			
			if (document.getElementById("txt_ReportNameClone").value.trim() == document.getElementById("txt_ReportNameClone").defaultValue.trim()) {
				checkalreadythere = 1;
			}
			
			if (checkalreadythere) {
				alert("This report already exists for the program.\nPlease select another name for your report.");
				checkalreadythere = 0;
				document.getElementById("txt_ReportNameClone").value = '';$j('#txt_ReportNameClone').focus();
				document.getElementById("txt_ReportNameClone_cnt").innerHTML = '140';
			}
			else {
				if( !checkReportNameAvailability('txt_ReportNameClone') )
					return false;

				var selectedDateBegin = formData.startPeriod;
				var selectedDateEnd = formData.endPeriod;
				var dateStartText = $j("#beginsurvey option:selected").text();
				var dateEndText = $j("#endsurvey option:selected").text();
				var availableTo = $j("input[name=savSel_availToclone]:checked").val();
				var availableIdList = "";
				if(availableTo == 'staffroles') {
					availableIdList = $j("input[type=checkbox][name=roleid_report]:checked").map(function() {return this.value;}).get().join(',');
				} else if (availableTo == 'owner') {
					availableIdList = $j("#currentUserId").val();
				}
				//var submitFunc = function(selectedIDs, notSelectedIDs){
					/* try {
						multipleSurveyWindowClose();
					} catch (e) { notSelectedIDs = '';} */
					//if (!notSelectedIDs) notSelectedIDs = '';
					var scopePassed = document.getElementById("scope").value;
					var reportNameEntered = document.getElementById("txt_ReportNameClone").value;
					var CombinedSelectedDate = dateStartText + '~`' + dateEndText;
					
					var checkboxselection1 = 0;
					if (document.getElementById("chkbx_report1edit").checked) {
						checkboxselection1 = document.getElementById("chkbx_report1edit").value;
					}
					var checkboxselection2 = 0;
					if (document.getElementById("chkbx_report2edit").checked) {
						checkboxselection2 = document.getElementById("chkbx_report2edit").value;
					}
					var checkboxselection3 = 0;
					if (document.getElementById("chkbx_report3edit").checked) {
						checkboxselection3 = document.getElementById("chkbx_report3edit").value;
					}
					var checkboxselection4 = 0;
					if (document.getElementById("chkbx_report4edit").checked) {
						checkboxselection4 = document.getElementById("chkbx_report4edit").value;
					}
					var checkboxselection5 = 0;
					if (document.getElementById('chkbx_report5edit') != null && document.getElementById("chkbx_report5edit").checked) {
						checkboxselection5 = document.getElementById("chkbx_report5edit").value;
					}
					var reportidselected = document.getElementById("selectedReportID").value;
					var compilationSelected = document.getElementById("txt_selectedquestionidfileidlist").value;
					var selectedMatrixRowId = document.getElementById("txt_selectedmatrixRowidlist").value; //SURVEXPORT-352

					new Ajax.Request("/index.cfm?event=survey.cloneaddsurveyreportid",{
						method: "post",
						/* Removing few arg as they are not set here, notSelectedIDs: notSelectedIDs */
						parameters: { reportNameEntered: reportNameEntered, beginsurvey: selectedDateBegin, endsurvey: selectedDateEnd, compilation: compilationSelected, checkboxselection1: checkboxselection1, checkboxselection2: checkboxselection2, checkboxselection3: checkboxselection3, checkboxselection4: checkboxselection4, checkboxselection5: checkboxselection5, reportidselected: reportidselected, BEGINENDSURVEYDATESELECTED: CombinedSelectedDate,availableTo:availableTo,availableIdList:availableIdList, scope: scopePassed},
						onSuccess: function(returnHtml){
							document.getElementById("hdn_SelectdReportRadio").value = returnHtml.responseText.replace(/^\s+|\s+$/g, '');
							SurveyQuestionsSelection("selectedreport");
							CloseReportCloningWindow();
						},
						onFailure: function(){
							alert('Oops...mistake on server');
						}
					});
			}
		}
	}
}

function checkReportNameAvailability(ExportNameID)
{
	var _return_ = true;	
	var ExportName = $j('#'+ExportNameID).val().trim();	
	var checkDuplicate = false;	

	if( ExportNameID == 'txt_ReportName' ) {
		var defVal1 = $j('#hdn_txt_ReportName').val().trim();
		if( defVal1.length == 0 || defVal1 != ExportName ) { //if name set for 1st time or already set
			checkDuplicate = true;
		}
	} else if ((ExportNameID == 'txt_ReportNameEdit' && ExportName != $j('#txt_ReportNameEdit').prop('defaultValue').trim()) || (ExportNameID == 'txt_ReportNameClone' && ExportName != $j('#txt_ReportNameClone').prop('defaultValue').trim())) {
		checkDuplicate = true;
	}
					
	$j.ajax({			
		url: 'index.cfm?event=survey.checkReportNameAvailability',
		data : {				 
				 'ReportName': ExportName			
			   },
		type: "POST",
		async: false,	
		dataType: 'json',					
		success:function(response) {				
			if(	response.RESULT > 0 ) {
				if(checkDuplicate) {
					_return_ = false;
					alert("A saved report by that name already exists on your site. Please enter a new name.");
					checkalreadythere = 1;	
					$j('#'+ExportNameID).focus();
				}
			}						
		},
		error :function()
		{
			_return_ = false;
		  	alert('error occurred!!');
		}
	});		
	return _return_;	
}
/* For Question listing */

$j(document).on('click', '.edit_question_listing', function(e){

	var attrName = $j(this).attr('name');
	var isChecked = $j(this).prop('checked');
	
	if(isChecked) {				
		$j(".matrix-row-chk").each(function(){
			if($j(this).attr('attr-val') != undefined) {
				if($j(this).attr('rel') == attrName) {
					$j(this).prop('checked',true);
					assignMatrixRowstoHiddenField($j(this).attr("name"));					
				}
			}				
		});
		assignQuestiontoHiddenField($j(this).attr("attr-value"));
	} else {		
		$j(".matrix-row-chk:checked").each(function(){			
			if($j(this).attr('attr-val') != undefined) {
				if($j(this).attr('rel') == attrName) {
					$j(this).prop('checked',false);
					removeMatrixRowstoHiddenField($j(this).attr("name"));
				}
			}				
		});	
		removeQuestiontoHiddenField($j(this).attr("attr-value"));
	}
});
	/* For Question listing-END */

$j(document).on('click', 'input[name=savSel_availToedit], input[name=savSel_availToclone]', function(e){
	if ($j(this).value != "staffroles") {
		$j('.staffsectionbox').slideUp(100);
	}
});

/* STEP 2: END */

function sorted(a,b) {
	return a-b
}

function TestInput(str)
{
	str = str.trim();
    /*var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;*/
    var format = /[\[\]~`#%^&=+<>"\\]/
	if( str.match(format) ){
 	  return true;    
	}else{
	  return false;     
	}
}

/* Start: Step 1 */

$j(document).ready(function(){
	$accordion = $j("#accordion").accordion({ header: ".panelhead", collapsible: true, active:0 });
	
	/* Disable All other section other than active section */	 	
	$j(".panelhead:not(.ui-state-active)").addClass('ui-state-disabled'); //$active_panel =
	$j(".panelhead:not(.ui-state-active)").next('div.contentBodyPanel').addClass('ui-state-disabled'); //$active_body
	
	$j( "#accordion" ).accordion({
		activate: function( event, ui ) {
			if ($j(ui.oldPanel).hasClass('setDiv')) {
				$j(ui.oldPanel).show();}				
				hideLoadingOverlay();			
		}
	});
	
	$j(".panelhead").unbind('click'); // Prevent click on the section header
	/* Disable All other section other than active section */
	
	formData.allowablesitelist = $j('#surveySumittedForSubmanagerSites').val();

	var optionTemp  = $j("#surveydate option").clone(true);		
	var selected =  $j("#beginsurvey option:selected").attr('rel');		
	$j("#endsurvey").empty();
	for(i=0; i <= selected; i++) {
		$j("#endsurvey").append(optionTemp[i]);
	}	
	var w = $j("#beginsurvey").css("width");
	$j("#endsurvey").css("width",w);
	
	var datebegin_survey = $j("#beginsurvey").val();
	var dateend_survey = $j("#endsurvey").val();
	var programID = $j("#pgmid").val();
	var sortcolumn = "";
	var sorttype = "";	
	loadSurveyTable(datebegin_survey,dateend_survey,programID,sortcolumn,sorttype,0,0);
	loadIndividualTable(datebegin_survey,dateend_survey,programID);
	loadSiteTable(datebegin_survey,dateend_survey,programID);
	loadAssociationTable(datebegin_survey,dateend_survey,programID);
	root = $j('#root').val();
	
	$dialog.editSavedSelectionExport = $j('<div></div>').dialog(dialogSettings('Edit Export Option', 'editSavedSelectionExport', 552, 552, 600, 600));
	$dialog.cloneSavedSelectionExport = $j('<div></div>').dialog(dialogSettings('Clone Export Option', 'cloneSavedSelectionExport', 552, 552, 600, 600));

	$j('input[name=radio_availTo]').click(function(e){
		if ($j(this).value != "staffroles") {
			$j('.staffsectionbox').slideUp(100);
		}
	});

	$j("#attibuteid").select2();
});

function loadSurveyTable(beginDate,endDate,programID,sortcolumn,sorttype,checkedSurveys,checkedSurveysInTable) {
	var status = false;
	
	//To handle error if startdate or end date or program id are empty
	if(beginDate ==null ||endDate==null || programID==null ) {
		return false;
	}
	var data = {
           SelectedbeginDate: beginDate,
           SelectedendDate: endDate,
           programID: programID,
		   sortcolumn: sortcolumn,
		   sorttype: sorttype,
		   checkedSurveys: checkedSurveys
       };
	   
    $j.ajax({
        type: "POST",
        url: "index.cfm?event=survey.getTableSurveysListing",
        data: data,
        dataType: "json",
        beforeSend: function() {			
            showLoadingOverlay2();
        },
        success: function(survey) {
			prepareviewSurveySection(survey.data,checkedSurveysInTable,survey.recordcount,survey.AllAvailableSurveys);
			$j("#allavailableSurveyIds").val(survey.AllAvailableSurveys);
			if(sortcolumn != "" && sorttype != "") 
			{
				if (sorttype === 'desc') {			
					$j("#"+sortcolumn).attr('data-sort', 'asc');
				} else {			
					$j("#"+sortcolumn).attr("data-sort","desc");
				}		 
			}
			hideLoadingOverlay2();
        },
        complete: function() {			
            //hideLoadingOverlay();
        },
        error: function(data) {		 
            status = false;
	    	hideLoadingOverlay2();
        }
    });	 
    return status;
}  

function prepareviewSurveySection(data,checkedSurveysInTable,recordcount,AllAvailableSurveys) {

	 var surveySection = $j('#survey_table');	 		
	 surveySection.html('');
	 var $str_viewsurveySection = '<table cellspacing="0"  class="listing-table table-layout" id="my_survey_table"><thead><tr><th class="headers" style="width:230px;"><input type="checkbox" id="check_all_surveys" name="check_all_surveys" style="margin-top:3px">&nbsp;<a id="daterange" title="Sort by Launch & Due Dates" href="" data-column="daterange" data-sort="desc" style="color:#FFFFFF;">Launch & Due Dates</a></th><th class="headers" style="width:210px;"><a id="FormName" title="Sort by Form Name" href="" data-column="FormName" data-sort="asc" style="color:#FFFFFF;">Form Name</a></th><th class="headers" style="width:249px;"><a id="HyperText" title="Sort by Customized Hyperlink" href="" data-column="HyperText" data-sort="asc" style="color:#FFFFFF;">Customized Hyperlink</a></th></tr></thead>';
	 
	if (recordcount < 14) {	  
		var $str_viewsurveySection = $str_viewsurveySection + '<tbody class="sur_tab1">';
	} else {	 
		var $str_viewsurveySection = $str_viewsurveySection + '<tbody class="sur_tab">';
	}
	  
	 var DateBegin = "";
	 var DateEnd = "";
	 var FormName = "";
	 var FormID = "";
	 var SurveyLinkText = "";
	 var allavailableSurveys = AllAvailableSurveys;
	 var allSurveys = new Array();
	 $j.each(data, function(index, survey) {
		var m_names = new Array("Jan", "Feb", "Mar", 
		"Apr", "May", "Jun", "Jul", "Aug", "Sep", 
		"Oct", "Nov", "Dec");
		
		allSurveys.push(survey["SurveyId"]);
		if (survey["FormName"] != null && survey["FormName"].length > 0) {
	
			DateBegin = survey["DateBegin"];
			DateEnd = survey["DateEnd"];
			FormName = survey["FormName"];
			FormID = survey["FormID"];
			SurveyLinkText = survey["SurveyLinkText"];
			SurveyId = survey["SurveyId"];
			var d1 = new Date(DateBegin);
			var d2 = new Date(DateEnd);
			
			$str_viewsurveySection = $str_viewsurveySection + '<tr class="my_survey_table_class" rel="'+SurveyId+'" style="border-bottom:1px solid #000!important">';
			
			var curr_day1 = d1.getDate();
			var curr_month1 = d1.getMonth();
			var curr_year1 = d1.getFullYear();
		
			var curr_day2 = d2.getDate();
			var curr_month2 = d2.getMonth();
			var curr_year2 = d2.getFullYear();
			var surveyChecked = false;
			  
			if (checkedSurveysInTable != 0) {			 
				if(checkedSurveysInTable.indexOf(SurveyId) >= 0) {				 
					surveyChecked = true;
				}
			}		 		 
			$str_viewsurveySection = $str_viewsurveySection + '<td class="sscb fnt surveyid_list" style="width:230px;word-break:break-word;"><input style="margin-top:3px" type="checkbox" name="surveyid_list" class="surveyid_list" id="surveyid_'+SurveyId+'" value="'+SurveyId+'"';
			if(surveyChecked) {		 
				$str_viewsurveySection = $str_viewsurveySection + ' checked';
			}
			$str_viewsurveySection = $str_viewsurveySection + '>&nbsp;'+m_names[curr_month1]+' '+curr_day1+', '+curr_year1+' - '+m_names[curr_month2]+' '+curr_day2+', '+curr_year2+'</td>';
			$str_viewsurveySection = $str_viewsurveySection + '<td class="fnt" style="width:200px;word-break:break-word;"><a id="formname_'+SurveyId+'" href="index.cfm?event=survey.previewsurvey&sfid='+FormID+'+&surveyaction=preview" target="_blank">'+FormName+'</a></td>';
			$str_viewsurveySection = $str_viewsurveySection + '<td class="fnt" style="width:249px;word-break:break-word;">'+SurveyLinkText+'</td>';				
		}
		$str_viewsurveySection = $str_viewsurveySection + '</tr>';
	});
	$str_viewsurveySection = $str_viewsurveySection + '</tbody></table>';
	surveySection.html($str_viewsurveySection);		 
	allSurveys = allSurveys.toString();
	$j("#allavailableSurveyIds").val(allavailableSurveys);
	
	var totalSurveyIds = $j('input[type=checkbox][class=surveyid_list]').length;
	var totalSurveyIdsChecked = $j('input[type=checkbox][class=surveyid_list]:checked').length;	
	if (totalSurveyIds == totalSurveyIdsChecked) {
		$j('input[type=checkbox][id=check_all_surveys]').prop('checked', true);	
	} else {
		$j('input[type=checkbox][id=check_all_surveys]').prop('checked', false);
	}
	 
	return true;
}

function loadIndividualTable(beginDate,endDate,programID) {
	var status = false;
	
	//To handle error if startdate or end date or program id are empty
	if(beginDate ==null ||endDate==null || programID==null ) {
		return false;
	}
	var data = {
           SelectedbeginDate: beginDate,
           SelectedendDate: endDate,
           programID: programID
       };
	   
    $j.ajax({
        type: "POST",
        url: "index.cfm?event=survey.getSurveyIndividualTable",
        data: data,
        dataType: "json",
        beforeSend: function() {
           showLoadingOverlay2();
        },
        success: function(individual) {
			prepareviewIndividualSection(individual.data,individual.dataExist);
			hideLoadingOverlay2();
        },
        complete: function() {
           //hideLoadingOverlay();
        },
        error: function(data) {
		console.log('inside error'+data);
            status = false;
	    	hideLoadingOverlay2();
        }
    });
	 
    return status;
} 

function prepareviewIndividualSection(data,exist) {
  
	 var individualSection = $j('#div_Surveysection1');	 
	 individualSection.html('');
	 
	 if (exist == 0) {
		var $str_viewindividualSection = '<table width="380px" style="width:380px; height:132px;" ><tr><td style="font-weight:normal;text-align:left;height:75px;padding: 5% 3% 0;" align="left" height="55px">Reporting and Reflection log were not targeted to individual '+ volunteerAliasPlural +' during the selected time period.</td></tr></table>'; 
		document.getElementById("individual_available").style.display = "none";
		document.getElementById("individual_available_none").style.display = "block";
		document.getElementById("updateMemberSurveys").style.display = "none";  
	 } else {
		document.getElementById("individual_available").style.display = "block";
		document.getElementById("individual_available_none").style.display = "none";
		document.getElementById("updateMemberSurveys").style.display = "none";
		var $str_viewindividualSection = '<table cellspacing="0" id="individual_table" style="width: 100%;" class="table-layout tbborder"><tbody><tr><td style="text-align:right;padding-bottom:0px;line-height:22px;padding-right:7px"><a href="javascript:void(0);" class="selallnone_individual" id="select_all_individual" rel="individual_checkbox">Select All</a></td></tr></tbody></table><table cellspacing="0"  class="table-layout tbborder" style="width: 100%" id="individual_table">';
		var FullName = "";
		var Email = "";
		var UserId = "";		
		$j.each(data, function(index, individual) {
		 
			$str_viewindividualSection = $str_viewindividualSection + '<tr>';
			 
			if (individual["FullName"] != null && individual["FullName"].length > 0) {			
				FullName = individual["FullName"];
				Email = individual["Email"];
				UserID = individual["UserID"];
				Surveys = individual["Surveys"];				 				
				$str_viewindividualSection = $str_viewindividualSection + '<td>'+FullName+'</td>';
				$str_viewindividualSection = $str_viewindividualSection + '<td >'+Email+'</td>';
				$str_viewindividualSection = $str_viewindividualSection + '<td style="padding-right:7px"><input type="checkbox" class="individual_checkbox selectedSurveys" name="individual_checkbox" value="'+Surveys+'" onchange="showMemberUpdateLink();"></td>';						
			}
			$str_viewindividualSection = $str_viewindividualSection + '</tr>';
		});
	 	$str_viewindividualSection = $str_viewindividualSection + '</tbody></table>';
	 }
	 individualSection.html($str_viewindividualSection);	
	 
	 var datebegin_survey = $j("#beginsurvey").val();
	 var dateend_survey = $j("#endsurvey").val();
	 var programID = $j("#pgmid").val();
	 var sortcolumn = $j("#sortcolumn").val();
	 var sorttype = $j("#sorttype").val();
	 var checkedSurveys = 0;			
	 if(exist != 0 && $j("#individualmember").prop('checked') == true) {
		checkedSurveys = $j('input[name="individual_checkbox"]').map(function() {return this.value;}).get().join(',');
		if(checkedSurveys == '' || checkedSurveys == null) {
			checkedSurveys = 0;			
		}
		setTimeout(function() { 
			loadSurveyTable(datebegin_survey,dateend_survey,programID,sortcolumn,sorttype,checkedSurveys,0);
		},100);
	 }
	
	 return true;
}

function prepareviewAssociationSection(data,associations,exist) { 	 
	 var associationSection = $j('#div_Surveysection3');
	 associationSection.html('');	 
	 if (exist == 0) {
		 var $str_viewassociationSection = '<table width="380px" style="width:380px;" ><tr><td style="font-weight:normal;text-align:left;height:75px;padding: 5% 3% 0;" align="left" height="55px">Reporting and Reflection log were not targeted by Association during the selected time period.</td></tr></table>  ';
		 document.getElementById("association_available").style.display = "none";
		 document.getElementById("association_available_none").style.display = "block";
		 document.getElementById("updateAssociationSurveys").style.display = "none";	 
	 } else {
		 document.getElementById("association_available").style.display = "block";
		 document.getElementById("association_available_none").style.display = "none";
		 document.getElementById("updateAssociationSurveys").style.display = "none";
		 var associationContainingData = new Array();
	 
		 $j.each(data, function(index, associationitem) {
			associationContainingData.push(associationitem["associationid"]);
		 });
		 
		 var $str_viewassociationSection = '<table id="mainTable" style="background-color:white;" class="tblTargetAssoList" width="100%">';
		 var SiteName = "";
		 var Surveys = "";
		 $j.each(associations, function(index, associations) {	  
	   		if(associationContainingData.indexOf(associations["associationid"]) > -1) {	  
	  			$str_viewassociationSection = $str_viewassociationSection + '<tr>';	  
	  			$str_viewassociationSection = $str_viewassociationSection + '<td style="padding:7px;font-size:12px;width:110px;vertical-align:top; font-weight:normal;">'+associations["title"]+'</td>';
	  
	  			$str_viewassociationSection = $str_viewassociationSection + '<td style="padding:7px;font-size:12px; font-weight:normal;" valign="top"><a onclick="listAssociationItems('+associations["associationid"]+')" style="cursor:pointer;color:#0000FF;text-decoration: underline;" id="assign'+associations["associationid"]+'">Filter</a><div id="assoItemsFor'+associations["associationid"]+'" style="background-color:white;border:dashed;border-color:navy;border-width:1px;display:none;width:230px;"><table class="tblTargetAssoItemList" width="100%" cellspacing="0px">';
	  			$str_viewassociationSection = $str_viewassociationSection + '<tr style="background-color:#ffffff;"><td style="text-align:right;padding-bottom:0px;line-height:22px;" colspan="2"><a href="javascript:void(0);" class="selallnone_association selallnone_association_' + associations["associationid"] + '" id="select_all_association" rel="association_checkbox_'+associations["associationid"]+'">Select All</a></td></tr>';
	  			$j.each(data, function(index, associationitem) {
					if (associationitem["associationid"] == associations["associationid"]) {
						associationitemvalue = associationitem["ItemValue"];
						associationitemid = associationitem["associationitemid"];
						associationitemidSurveys = associationitem["Surveys"];
						
						$str_viewassociationSection = $str_viewassociationSection + '<tr id="tblIndividualItem_'+associationitemid+'" class="tblIndividualItemClass_'+associations["associationid"]+'">';					
						$str_viewassociationSection = $str_viewassociationSection + '<td>'+associationitemvalue+'</td>';				
						$str_viewassociationSection = $str_viewassociationSection + '<td style="padding-right:18px; text-align:right;"><input type="checkbox"  name="theAssoItemId_'+associationitemid+'" id="theAssoItemId_'+associationitemid+'" class="theAssoItemClass_'+associations["associationid"]+' association_checkbox_'+associations["associationid"]+' association_checkbox selectedSurveys" value="'+associationitemidSurveys+'" onchange="showAssociationUpdateLink('+associations["associationid"]+');"></td>';				
					}
					$str_viewassociationSection = $str_viewassociationSection + '</tr>';
				});
				$str_viewassociationSection = $str_viewassociationSection + '</table>';
				$str_viewassociationSection = $str_viewassociationSection + '</div></td></tr>';
			}
		});
	 	$str_viewassociationSection = $str_viewassociationSection + '</table>';
	 }
	 associationSection.html($str_viewassociationSection);
	 
	 var datebegin_survey = $j("#beginsurvey").val();
	 var dateend_survey = $j("#endsurvey").val();
	 var programID = $j("#pgmid").val();
	 var sortcolumn = $j("#sortcolumn").val();
	 var sorttype = $j("#sorttype").val();
	 var checkedSurveys = 0;			
	 if(exist != 0 && $j("#memberbyassociation").prop('checked') == true) {
		checkedSurveys = $j('.association_checkbox').map(function() {return this.value;}).get().join(',');
		if(checkedSurveys == '' || checkedSurveys == null) {
			checkedSurveys = 0;			
		}
		setTimeout(function() { 
			loadSurveyTable(datebegin_survey,dateend_survey,programID,sortcolumn,sorttype,checkedSurveys,0);
		}, 100);
	 }
	
	 return true;
}

function loadAssociationTable(beginDate,endDate,programID) {
	var status = false;	 

	//To handle error if startdate or end date or program id are empty
	if(beginDate ==null ||endDate==null || programID==null ) {
		return false;
	}
	var data = {
           SelectedbeginDate: beginDate,
           SelectedendDate: endDate,
           programID: programID
       };	
    $j.ajax({
        type: "POST",
        url: "index.cfm?event=survey.getSurveyAssociationTable",
        data: data,
        dataType: "json",
        beforeSend: function() {			
            showLoadingOverlay2();
        },
        success: function(association) {
			prepareviewAssociationSection(association.data,association.associations,association.dataExist);
			hideLoadingOverlay2();
        },
        complete: function() {			
            //hideLoadingOverlay();
        },
        error: function(data) {		 
			status = false;
			hideLoadingOverlay2();
        }
    });	 
    return status;
}  

function loadSiteTable(beginDate,endDate,programID) {
	var status = false;	 

	//To handle error if startdate or end date or program id are empty
	if(beginDate ==null ||endDate==null || programID==null ) {
		return false;
	}

	var data = {
           SelectedbeginDate: beginDate,
           SelectedendDate: endDate,
           programID: programID
       };
	   
    $j.ajax({
        type: "POST",
        url: "index.cfm?event=survey.getSurveySiteTable",
        data: data,
        dataType: "json",
        beforeSend: function() {
           showLoadingOverlay2();
        },
        success: function(site) {
			prepareviewSiteSection(site.data,site.dataExist);
			hideLoadingOverlay2();
        },
        complete: function() {
           //hideLoadingOverlay();
        },
        error: function(data) {
			console.log('inside error'+data);
			status = false;
			hideLoadingOverlay2();
        }
    });	 
    return status;
}

function prepareviewSiteSection(data,exist) {  
	 var siteSection = $j('#div_Surveysection2');	
	 siteSection.html('');	 
	 if (exist == 0) {
		var $str_viewsiteSection = '<table width="380px" style="width:380px;" ><tr><td style="font-weight:normal;text-align:left;height:75px;padding: 5% 3% 0;" align="left" height="55px">Reporting and Reflection log were not targeted to '+volunteerAliasPlural+' at '+siteAlias+' during the selected time period.</td></tr></table>  ';
		document.getElementById("site_available").style.display = "none";
		document.getElementById("site_available_none").style.display = "block";
		document.getElementById("updateSiteSurveys").style.display = "none";	 
	 } else {
	 	document.getElementById("site_available").style.display = "block";
	  	document.getElementById("site_available_none").style.display = "none";
	  	document.getElementById("updateSiteSurveys").style.display = "none";
	  
	 	var $str_viewsiteSection = '<table cellspacing="0" id="selectall_site_table" style="width: 100%;" class="table-layout  tbborder"><tbody><tr><td style="text-align:right;padding-bottom:0px;line-height:22px;font-weight:normal;"><a href="javascript:void(0);" class="selallnone_site" id="select_all_site" rel="site_checkbox" style="padding-right:3px;">Select All</a></td></tr></tbody></table><table cellspacing="0" class="table-layout tbborder services-table" style="width: 100%" id="site_table">';
	 	var SiteName = "";
	 	var Surveys = "";	  
	  	$j.each(data, function(index, site) {		 
			$str_viewsiteSection = $str_viewsiteSection + '<tr>';		 
			if (site["SiteName"] != null && site["SiteName"].length > 0) {
				SiteName = site["SiteName"];
				Surveys = site["Surveys"];		
				$str_viewsiteSection = $str_viewsiteSection + '<td>'+SiteName+'</td>';
				$str_viewsiteSection = $str_viewsiteSection + '<td style="padding-right:15px;text-align:right"><input type="checkbox" class="site_checkbox selectedSurveys" name="site_checkbox" value="'+Surveys+'" onchange="showSiteUpdateLink();"></td>';				
			}
			$str_viewsiteSection = $str_viewsiteSection + '</tr>';
		});
		$str_viewsiteSection = $str_viewsiteSection + '</tbody></table>';
	 }
	 siteSection.html($str_viewsiteSection);
	 
	 var datebegin_survey = $j("#beginsurvey").val();
	 var dateend_survey = $j("#endsurvey").val();
	 var programID = $j("#pgmid").val();
	 var sortcolumn = $j("#sortcolumn").val();
	 var sorttype = $j("#sorttype").val();
	 var checkedSurveys = 0;			
	 if(exist != 0 && $j("#memberbysite").prop('checked') == true) {
		checkedSurveys = $j('.association_checkbox').map(function() {return this.value;}).get().join(',');
		if(checkedSurveys == '' || checkedSurveys == null) {
			checkedSurveys = 0;			
		}
		setTimeout(function() { 
			loadSurveyTable(datebegin_survey,dateend_survey,programID,sortcolumn,sorttype,checkedSurveys,0);
		}, 100);
	 }
	
	 return true;
}

function LoadSurveyTableForAllVolunteers() {
	
	var datebegin_survey =$j("#beginsurvey").val();
	var dateend_survey =$j("#endsurvey").val();
	var programID =$j("#pgmid").val();
	var sortcolumn = $j("#sortcolumn").val();
	var sorttype = $j("#sorttype").val();
	
	loadSurveyTable(datebegin_survey,dateend_survey,programID,sortcolumn,sorttype,0,0);
}

$j(document).on('click', 'a.expandSection_filter', function(e){	
	var openLinkObj = $j(this);	
	if(!$j('#selectspecificreportlink').hasClass('sliding')) {
		section = $j.trim(openLinkObj.attr('rel'));
		$j('#imgLoading_section3_filter').show();
		openLinkObj.addClass('sliding');
		Effect.SlideDown('div_' + section, { 
			afterFinish: function () { 			 
				openLinkObj.removeClass('sliding').removeClass('expandSection_filter').addClass('collapseSection_filter'); 	 
				$j('#imgLoading_' + section).hide(); 			
				$j('#closesurveyfiltersection').show();
				document.getElementById("is_surveytable_open").value ="1";
			}
		});
	}
	return false;
});

$j(document).on('click', 'a.collapseSection_filter', function(e){
	var closeLinkObj = $j(this);	 
	if(!$j('#selectspecificreportlink').hasClass('sliding')) {
		section = jQuery.trim(closeLinkObj.attr('rel'));	
		$j('#imgLoading_section3').hide();	
		closeLinkObj.addClass('sliding');	
		Effect.SlideUp('div_' + section,
			{ afterFinish: function () {
				closeLinkObj.removeClass('sliding').removeClass('collapseSection_filter').addClass('expandSection_filter');
				$j('#closesurveyfiltersection').hide();
				document.getElementById("is_surveytable_open").value ="0";	
			}
		});
	}
	return false;
});

function showMemberUpdateLink() {	
	var showUpdateLink = false;
	var totalindividual_checkbox = $j('input[name="individual_checkbox"]').length;
	var totalindividual_checkbox_checked = $j('input[name="individual_checkbox"]:checked').length;
	if(totalindividual_checkbox_checked) {  
		showUpdateLink = true;		
    }
	
	if(totalindividual_checkbox == totalindividual_checkbox_checked) {
		$j('#select_all_individual').text('Select None');
	} else {
		$j('#select_all_individual').text('Select All');
	}
	
	if(showUpdateLink) {
		$j('#updateMemberSurveys').show();
	} else { 
		$j('#updateMemberSurveys').hide();
	}
}

function showSiteUpdateLink() {	
	var showUpdateLink = false;	
	var totalsite_checkbox = $j('input[name="site_checkbox"]').length;
	var totalsite_checkbox_checked = $j('input[name="site_checkbox"]:checked').length;
	if(totalsite_checkbox_checked) {  
		showUpdateLink = true;		
    }
	
	if(totalsite_checkbox == totalsite_checkbox_checked) {
		$j('#select_all_site').text('Select None');
	} else {
		$j('#select_all_site').text('Select All');
	}	    
	
	if(showUpdateLink) {
		$j('#updateSiteSurveys').show();
	} else { 
		$j('#updateSiteSurveys').hide();
	}
}

function showAssociationUpdateLink(assoId) {	
	var showUpdateLink = false;
	var totalassociation_checkbox_checked = $j('.association_checkbox:checkbox:checked').length;
	if(totalassociation_checkbox_checked) {  
		showUpdateLink = true;		
    	}
	
	var currentCheckboxClass = 'association_checkbox_' + assoId;	
	var totalcurrentCheckbox = $j('.' + currentCheckboxClass + ':checkbox').length;
	var totalcurrentCheckbox_checked = $j('.' + currentCheckboxClass + ':checkbox:checked').length;
	
	if(totalcurrentCheckbox == totalcurrentCheckbox_checked) {
		$j('.selallnone_association_'+assoId).text('Select None');
	} else {
		$j('.selallnone_association_'+assoId).text('Select All');
	}
	
	if(showUpdateLink) {
		$j('#updateAssociationSurveys').show();
	} else{ 
		$j('#updateAssociationSurveys').hide();
	}
}

$j(document).on('click', '#closesurveyfiltersection', function(e) {
	if(!$j('#selectspecificreportlink').hasClass('sliding')){
		section = 'section3_filter';
		$j('#div_section3_filter').hide();
		$j('#selectspecificreportlink').addClass('sliding');
		$j('#individualmember').prop('checked', false);
		$j('#individualmember').removeClass('collapseSectionSurvey').addClass('expandSectionSurvey');
		$j('#memberbysite').prop('checked', false);
		$j('#memberbysite').removeClass('collapseSectionSurvey').addClass('expandSectionSurvey');
		$j('#memberbyassociation').prop('checked', false);
		$j('#memberbyassociation').removeClass('collapseSectionSurvey').addClass('expandSectionSurvey');	
		$j('.div_Surveysection').each(function(){
			$j(this).hide();		
		}); 
		var datebegin_survey = $j("#beginsurvey").val();
		var dateend_survey = $j("#endsurvey").val();
		var programID = $j("#pgmid").val();
		var sortcolumn = $j("#sortcolumn").val();
		var sorttype = $j("#sorttype").val();
		
		$j('#all_active_members').prop('checked', true);
		loadSurveyTable(datebegin_survey,dateend_survey,programID,sortcolumn,sorttype,0,0);
		
		$j('#selectspecificreportlink').removeClass('sliding');
		if(!$j('#selectspecificreportlink').hasClass('expandSection_filter')){
			Effect.SlideUp('div_' + section, { 
				afterFinish: function () {
					jQuery('#selectspecificreportlink').removeClass('collapseSection_filter').addClass('expandSection_filter');			
				}
			});
		}	
	}
	document.getElementById("is_surveytable_open").value ="0" ;		
	$j('#closesurveyfiltersection').hide();
	$j('#updateMemberSurveys').hide();  
	$j('#updateSiteSurveys').hide(); 
	$j('#updateAssociationSurveys').hide(); 
	return false;
});

function listAssociationItems(assoId) {	
	var assoItemDiv = document.getElementById('assoItemsFor'+assoId);
	$j('#assoItemsFor'+assoId).toggle("slow", function() {		
	});	
}

$j(document).on('click', '.selallnone_individual', function(e) {
	thisRelvar = $j(this).attr('rel');
	thisTextvar = $j(this).text();
	if($j.trim(thisTextvar) == 'Select All') {
		$j('input[name="individual_checkbox"]').prop('checked',true);
		$j(this).text('Select None');
		$j('#updateMemberSurveys').show();
	} else {
		$j('input[name="individual_checkbox"]').prop('checked',false);
		$j(this).text('Select All');
		$j('#updateMemberSurveys').hide();

	}
});

$j(document).on('click', '.selallnone_site', function(e) {
	thisRelvar = $j(this).attr('rel');
	thisTextvar = $j(this).text();
	if($j.trim(thisTextvar) == 'Select All'){
		$j('input[name="site_checkbox"]').prop('checked',true);
		$j(this).text('Select None');
		$j('#updateSiteSurveys').show();
	} else {
		$j('input[name="site_checkbox"]').prop('checked',false);
		$j(this).text('Select All');
		$j('#updateSiteSurveys').hide();

	}
});

$j(document).on('click', '.selallnone_association', function(e) {
	thisRelvar = $j(this).attr('rel');
	thisTextvar = $j(this).text();
	if($j.trim(thisTextvar) == 'Select All') {
		$j('.'+thisRelvar).prop('checked',true);
		$j(this).text('Select None');
		$j('#updateAssociationSurveys').show();
	} else {
		$j('.'+thisRelvar).prop('checked',false);
		$j(this).text('Select All');
		$j('#updateAssociationSurveys').hide();
	}
});


$j(document).on('click', '#updateMemberSurveys', function(e) {
	var datebegin_survey = $j("#beginsurvey").val();
	var dateend_survey = $j("#endsurvey").val();
	var programID = $j("#pgmid").val();
	var sortcolumn = $j("#sortcolumn").val();
	var sorttype = $j("#sorttype").val();
	var checkedSurveys = $j('.selectedSurveys:checked').map(function() {return this.value;}).get().join(',');

	if(checkedSurveys == '' || checkedSurveys == null) {
		checkedSurveys = 0;
	}
	
	loadSurveyTable(datebegin_survey,dateend_survey,programID,sortcolumn,sorttype,checkedSurveys,0);
	
	return false;
}); 

$j(document).on('click', '#updateSiteSurveysLink', function(e) { 
	var datebegin_survey = $j("#beginsurvey").val();
	var dateend_survey = $j("#endsurvey").val();
	var programID = $j("#pgmid").val();
	var sortcolumn = $j("#sortcolumn").val();
	var sorttype = $j("#sorttype").val();
	var checkedSurveys = $j('.selectedSurveys:checked').map(function() {return this.value;}).get().join(',');

	if(checkedSurveys == '' || checkedSurveys == null) {
		checkedSurveys = 0;
	}
	
	loadSurveyTable(datebegin_survey,dateend_survey,programID,sortcolumn,sorttype,checkedSurveys,0);
	
	return false;
}); 


$j(document).on('click', '#updateAssociationSurveysLink', function(e) {  
	var datebegin_survey = $j("#beginsurvey").val();
	var dateend_survey = $j("#endsurvey").val();
	var programID = $j("#pgmid").val();
	var sortcolumn = $j("#sortcolumn").val();
	var sorttype = $j("#sorttype").val();
	var checkedSurveys = $j('.selectedSurveys:checked').map(function() {return this.value;}).get().join(',');
	
	if(checkedSurveys == '' || checkedSurveys == null) {
		checkedSurveys = 0;
	}
	
	loadSurveyTable(datebegin_survey,dateend_survey,programID,sortcolumn,sorttype,checkedSurveys,0);
	
	return false;
});

$j(document).on('change', '#beginsurvey', function(e) {  
	var datebegin_survey =$j("#beginsurvey").val();	
	var programID = $j("#pgmid").val();
	var sortcolumn = $j("#sortcolumn").val();
	var sorttype = $j("#sorttype").val();
	var checkedSurveys = $j('.selectedSurveys:checked').map(function() {return this.value;}).get().join(',');
	
	if(checkedSurveys == '' || checkedSurveys == null) {
		checkedSurveys = 0;
	}
	
	var checkedSurveysInTable = $j('.surveyid_list:checked').val();
	if(checkedSurveysInTable == '' || checkedSurveysInTable == null) {
		checkedSurveysInTable = 0;
	}
	
	var optionTemp  = $j("#surveydate option").clone(true);		
	var selected =  $j("#beginsurvey option:selected").attr('rel');		
	$j("#endsurvey").empty();
	for(i=0; i <= selected; i++) {
		$j("#endsurvey").append(optionTemp[i]);
	}	
	var w = $j("#beginsurvey").css("width");
	$j("#endsurvey").css("width",w);
	var dateend_survey =$j("#endsurvey").val();
	
	loadIndividualTable(datebegin_survey,dateend_survey,programID);	
	loadSiteTable(datebegin_survey,dateend_survey,programID);	
	loadAssociationTable(datebegin_survey,dateend_survey,programID);	
	loadSurveyTable(datebegin_survey,dateend_survey,programID,sortcolumn,sorttype,0,checkedSurveysInTable);	
	return false;
});

$j(document).on('change', '#endsurvey', function(e) {
	var datebegin_survey =$j("#beginsurvey").val();
	var dateend_survey =$j("#endsurvey").val();
	var programID = $j("#pgmid").val();
	var sortcolumn = $j("#sortcolumn").val();
	var sorttype = $j("#sorttype").val();
	var checkedSurveys = $j('.selectedSurveys:checked').map(function() {return this.value;}).get().join(',');
	
	if(checkedSurveys == '' || checkedSurveys == null) {
		checkedSurveys = 0;
	}
	var checkedSurveysInTable = $j('.surveyid_list:checked').val();
	if(checkedSurveysInTable == '' || checkedSurveysInTable == null) {
		checkedSurveysInTable = 0;
	}
	
	loadSurveyTable(datebegin_survey,dateend_survey,programID,sortcolumn,sorttype,0,checkedSurveysInTable);
	loadIndividualTable(datebegin_survey,dateend_survey,programID);
	loadSiteTable(datebegin_survey,dateend_survey,programID);
	loadAssociationTable(datebegin_survey,dateend_survey,programID);
	return false;
});


$j(document).on('change', 'input[type=radio][name=launch_selection]', function(e) {
	if($j(this).hasClass('expandSectionSurvey')){	
		$j('.selectedSurveys').prop('checked',false);		
		if($j(this).attr('id') == 'individualmember') {			 			 
			 var datebegin_survey =$j("#beginsurvey").val();
			 var dateend_survey =$j("#endsurvey").val();
			 var programID =$j("#pgmid").val();
			 $j('.site_checkbox').removeAttr('checked');
			 $j('.association_checkbox').removeAttr('checked');
			 loadIndividualTable(datebegin_survey,dateend_survey,programID);
		} else if($j(this).attr('id') == 'memberbysite') {	
			 var datebegin_survey =$j("#beginsurvey").val();
			 var dateend_survey =$j("#endsurvey").val();
			 var programID =$j("#pgmid").val();
			 $j('.individual_checkbox').removeAttr('checked');
			 $j('.association_checkbox').removeAttr('checked');
			 loadSiteTable(datebegin_survey,dateend_survey,programID);
		} else if($j(this).attr('id') == 'memberbyassociation') {			
			 var datebegin_survey =$j("#beginsurvey").val();
			 var dateend_survey =$j("#endsurvey").val();
			 var programID =$j("#pgmid").val();
			 $j('.individual_checkbox').removeAttr('checked');
			 $j('.site_checkbox').removeAttr('checked');
			 loadAssociationTable(datebegin_survey,dateend_survey,programID);
		}
		
		var openLinkObj = $j(this);
		openLinkObj.attr('checked', true);
		if(!$j('#individualmember').hasClass('sliding') && !$j('#memberbysite').hasClass('sliding') && !$j('#memberbyassociation').hasClass('sliding')) {
			section = $j.trim(openLinkObj.attr('rel'));		
			$j('#imgLoading_Surveysection1').hide();
			$j('#imgLoading_Surveysection2').hide();
			$j('#imgLoading_Surveysection3').hide();
			$j('#imgLoading_' + section).show();
							 
			$j('.div_Surveysection').each(function(){
				$j(this).hide();
				$j(this).removeAttr("checked");	
			});
			
			openLinkObj.addClass('sliding');
			 
			$j('.linkToSectionSurvey').each(function(){ 
				$j(this).addClass('expandSectionSurvey').removeClass('collapseSectionSurvey'); 
			});
		 
			$j('#updateMemberSurveys').hide();
			$j('#updateSiteSurveys').hide();
			$j('#updateAssociationSurveys').hide();  
			
			var sectionlength = section.length;
			if(sectionlength) {			
				Effect.SlideDown('div_' + section,
					{ afterFinish: function () {  						 
						openLinkObj.removeClass('sliding').removeClass('expandSectionSurvey').addClass('collapseSectionSurvey');							
						$j('#imgLoading_' + section).hide();						
					}
				});
			}	
		}
	}
});

$j(document).on('change', '#check_all_surveys', function(e) {
	if ($j(this).is(':checked')) {
		$j('input[name=surveyid_list]').prop('checked', true);	
	} else {
		$j('input[name=surveyid_list]').prop('checked', false);
	}	
});

$j(document).on('change', '.surveyid_list', function(e) {
	var totalSurveyIds = $j('input[type=checkbox][class=surveyid_list]').length;
	var totalSurveyIdsChecked = $j('input[type=checkbox][class=surveyid_list]:checked').length;	
	if (totalSurveyIds == totalSurveyIdsChecked) {
		$j('input[type=checkbox][id=check_all_surveys]').prop('checked', true);	
	} else {
		$j('input[type=checkbox][id=check_all_surveys]').prop('checked', false);
	}	
});

$j(document).on('mouseover mouseout', '#my_survey_table tbody tr', function(e) {
	if (event.type == 'mouseover') {
		thisRelvar = $j(this).attr('rel');	
		$j('#formname_'+thisRelvar).css('color','#0000FF');
		$j('#formname_'+thisRelvar).css('text-decoration','underline');
	} else {
		thisRelvar = $j(this).attr('rel');	
		$j('#formname_'+thisRelvar).css('color','#333333');
		$j('#formname_'+thisRelvar).css('text-decoration','none');
	}
});

$j(document).on('click', '.headers a', function(e) {
	e.preventDefault();
	var sortColumn = $j(this).attr("data-column");
	var sortType = $j(this).attr("data-sort");
	
	var datebegin_survey = $j("#beginsurvey").val();
	var dateend_survey = $j("#endsurvey").val();
	var programID = $j("#pgmid").val();
	var checkedSurveys = $j('.selectedSurveys:checked').map(function() {return this.value;}).get().join(',');
	var checkedSurveysInTable = $j('.surveyid_list:checked').map(function() {return this.value;}).get().join(',');
	
	if(checkedSurveys == '' || checkedSurveys == null) {
		checkedSurveys = 0;
	}
	if(checkedSurveysInTable == '' || checkedSurveysInTable == null) {
		checkedSurveysInTable = 0;
	}	
	loadSurveyTable(datebegin_survey,dateend_survey,programID,sortColumn,sortType,checkedSurveys,checkedSurveysInTable);		
});

function SetSurveyDateRange(obj) {	
	checkSession();
	if($j(obj).is('div'))
		var buttonText = $j(obj).text().trim().toLowerCase();
	else	
		var buttonText = $j(obj).val().trim().toLowerCase();
	
	if(buttonText == 'set') {
		var datebegin_survey = $j("#beginsurvey").val();
		var dateend_survey = $j("#endsurvey").val();		
		var dateStartText = $j("#beginsurvey option:selected").text().split('-')[0];
		var dateEndText = $j("#endsurvey option:selected").text().split('-')[1];		
		var selectedSurveysList = [];
		var notselectedSurveysList = [];
		
		var is_surveytable_open = $j("#is_surveytable_open").val() ;		
		if(is_surveytable_open == 1 && $j('input[name="surveyid_list"]:checked').length == 0) {
			alert('Please select at least one '+ surveyalias +' from the table, or click the "close and remove filter" link just above the table.');
			return false;
		}
		
		$j('input[name="surveyid_list"]:checked').each(function () {
			selectedSurveysList.push(this.value); 
		});		
		selectedSurveysList = selectedSurveysList.toString();		
		
		formData.startPeriod = datebegin_survey;
		formData.endPeriod = dateend_survey;
		formData.selectedSurveysList = "";
		formData.notselectedSurveysList = "";
		formData.fromSelectedSurvey = 0;
		if($j('input[name="surveyid_list"]:checked').length > 0) {					 
			formData.selectedSurveysList = selectedSurveysList;			
			formData.fromSelectedSurvey = 1;
		}
						
		$j("#startSurveyDatePeriod").hide();
		$j("#endSurveyDatePeriod").hide();
		$j("#tableDatSelection").hide();
		$j("#btnSelectSurveys").hide();
		$j("#editcheckstep4").show();
		$j("#lblSummarySurveyPeriods").show();
		if($j('input[name="surveyid_list"]:checked').length == 0) {			
			$j("#lblSummarySurveySelectedPeriods").html(dateStartText + ' - ' + dateEndText);
			$j("#lblSummarySurveySelectedPeriods").show();
		} else {
			$j("#lblSummarySurveySelectedPeriods").html('Selected ' + surveyalias + 's from ' + dateStartText + ' - ' + dateEndText);
			$j("#lblSummarySurveySelectedPeriods").show();
		}
		if($j("#currentUserType").val() == 'submanager' ){
			$j.ajax({
				url: './index.cfm?event=survey.checkResultAccess',
				type: "POST",
				data: formData,
				dataType:'json',
				beforeSend: function() {
					showLoadingOverlay();
				},
				success : function(response){ 
					hideLoadingOverlay();
					if(response.AccessibleQueCount == 0 && response.TotalQueCount > 0){
						$j("#divDataSelection").hide();
						$j("#divNotAccess").show();						
					}else{
						$j("#divDataSelection").show();
						$j("#divNotAccess").hide();	
					}
					formData.setStep4 = 1;
					enableNextStep(5);
				},
				error : function(xhr, status, error){					
				  	alert('error occurred!!');
					hideLoadingOverlay();
				}
			});
		}else{
			formData.setStep4 = 1;
			enableNextStep(5);
		}
		
	} else {
		$j("#startSurveyDatePeriod").show();
		$j("#endSurveyDatePeriod").show();
		$j("#tableDatSelection").show();
		$j("#btnSelectSurveys").show();		
		$j("#lblSummarySurveyPeriods").hide();
		$j("#lblSummarySurveySelectedPeriods").hide();
		$j("#editcheckstep4").hide();
		formData.setStep4 = 0;
		//$j("#ui-id-1").trigger( "click" );	
		//$j(obj).closest('div.contentBodyPanel').removeClass('setDiv');
		var accor_div = $j(obj).closest('div.contentBodyPanel').prev('div.panelhead')[0];
		setSectionIcon(accor_div, 'edit');
		//to reset dependent steps
		_step4editCounter = 1; 
		__startPeriod = formData.startPeriod;
		__endPeriod = formData.endPeriod;
		__selectedSurveysList = formData.selectedSurveysList;
		__notselectedSurveysList = formData.notselectedSurveysList;
	}	
	showhideExportExcelButton();
}

/* End: Step 1 */

function Back() {
	var SubmittedSteps = Number($j('#hdn_submitted_steps').val());
	if(SubmittedSteps) {
		$j('#backLink').attr('rel','1');
		ClearStepsPopup();						 		 
	} else {
		window.location.href = "index.cfm?event=mc.surveydata"; 
	}
}

function ClearStepsPopup()  {
	var submittedSteps = Number($j('#hdn_submitted_steps').val());
	$j(document).find('#stepSubmittedList').html("");
	if(submittedSteps > 0) {	
		$j('.panelhead:visible').each(function (index, value) {			 
		  $j(document).find('#stepSubmittedList').append("<div style='float:left;width:10px'>-</div><div style='float:left;width:470px;'>"+$j(this).text().slice(7)+"</div><div style='height:2px;' class='clear'></div>");
		  	if(submittedSteps == (index+1)) {
				return false;
			}
		});						
		ColdFusion.Window.show("clearStep");
		$j("#clearStep_body").css("height", 225+(submittedSteps*20) );
		$j(".x-window-body").css("height", 'auto');
	}
}

function HideCPWindow(id) {  
	if(id == 'clearStep') {
		$j('#backLink').attr('rel','0')
	}
	ColdFusion.Window.hide(id);  	    
}

function ClearSteps() {	    	
 	ColdFusion.Window.destroy("clearStep");
	backFlag = Number($j('#backLink').attr('rel'));
	if(backFlag)
		window.location.href = "index.cfm?event=mc.surveydata";  
	else
		window.location.href = "index.cfm?event=survey.beneficiarygroupexport";  
}

/* Start: Step 6 */


$j(document).on('click', '#add_excel_columns', function(e) {
	var options = $j('#avl_column_excel option:selected').sort().clone();
	$j('#sel_column_excel').append(options);

	var foo = [];
	if($j('#ajaxFilterLoading').length && options.length > 50) {
		$j('#ajaxFilterLoading').show();
	}
	setTimeout( function() {
		$j('#avl_column_excel :selected').each(function(i, selected) { 
			foo[i] = $j(selected).val(); 
			$j(this).hideOption();
		});	
		if($j('#ajaxFilterLoading').length) {
			$j('#ajaxFilterLoading').hide();
		} 
	} , 1);
	return;
}); 

$j(document).on('click', '#remove_excel_columns', function(e) {
	var foo = [];
	if($j('#ajaxFilterLoading').length && $j('#sel_column_excel :selected').length > 50) {
		$j('#ajaxFilterLoading').show();
	}
	setTimeout( function() {
		$j('#sel_column_excel :selected').each(function(i, selected) { 
			foo[i] = $j(selected).val(); 
			$j('#avl_column_excel option[value="' + (foo[i]) + '"]').showOption();
		});	
		$j('#sel_column_excel option:selected').remove(); 
		if($j('#ajaxFilterLoading').length){ 
			$j('#ajaxFilterLoading').hide();
		} 
	} , 1);
	return;
});

$j(document).on('click', '#include_raw_questions', function(e) {
	
     if ($j(this).is(":checked")) {
		var selectedGroupList = formData.userSelectedGroups;
		var associationid = selectedGroupList;
		var startPeriod=formData.startPeriod  ;
		var endPeriod=formData.endPeriod;
		var identifiersIdList=formData.identifiersIdList;
		
		var selectedSurveysList = formData.selectedSurveysList ;
		var notselectedSurveysList = formData.notselectedSurveysList;
		var compilation = formData.compilation;
		var scopePassed = document.getElementById("scope").value;
		 
		var loadUrl="index.cfm?event=survey.getExportColumns";
		$j.ajax({			
			url: loadUrl,
			data : {association:associationid,startPeriod:startPeriod,endPeriod:endPeriod,identifiersIdList:identifiersIdList,selectedSurveysList:selectedSurveysList,notselectedSurveysList:notselectedSurveysList,compilation:compilation,scopePassed:scopePassed},
			type: "POST",												
			beforeSend: function(){
					showLoadingOverlay();
			},						
			success:function(response)
			{				
				$j("#columnsToInclude").html(response);
				$j('#columnsToIncludes').slideDown(700);												
			},
			complete:function()
			{
				hideLoadingOverlay();									
			},
			error :function()
			{
			  alert('error occurred!!');
			}
		});			
		 $j('#columnsToInclude').slideDown(700);
     } else {		 
		  $j('#columnsToInclude').slideUp(700);
     }
});


$j(document).on('click', '#groupincude_total', function(e) {
												 
     var selectedGroupList = formData.userSelectedGroups;
     if ($j(this).is(":checked")) {
		var selectedGroupList = formData.userSelectedGroups;
		var associationid = selectedGroupList;
		var startPeriod=formData.startPeriod  ;
		var endPeriod=formData.endPeriod;
		var identifiersIdList=formData.identifiersIdList;
		var selectedSurveysList = formData.selectedSurveysList ;
		var notselectedSurveysList = formData.notselectedSurveysList;
		var compilation = formData.compilation;
		var scopePassed = document.getElementById("scope").value;
		var loadUrl="index.cfm?event=survey.getTotalSheets";
		$j.ajax({			
			url: loadUrl,
			data : {association:associationid,startPeriod:startPeriod,endPeriod:endPeriod,identifiersIdList:identifiersIdList,selectedSurveysList:selectedSurveysList,notselectedSurveysList:notselectedSurveysList,compilation:compilation,scopePassed:scopePassed},
			type: "POST",												
			beforeSend: function(){
					showLoadingOverlay();
			},						
			success:function(response)
			{				
				$j("#grouptotaloptionsinclude").html(response);
				$j('#grouptotaloptionsinclude').slideDown(700);												
			},
			complete:function()
			{
				hideLoadingOverlay();									
			},
			error :function()
			{
			  alert('error occurred!!');
			}
		});			
		 $j('#grouptotaloptionsinclude').slideDown(700);
     } else {		 
		  $j('#grouptotaloptionsinclude').slideUp(700);
     }
});



$j.fn.showOption = function() {
	this.each(function() {
		if( this.tagName == "OPTION" ) {
			var opt = this;
			if( $j(this).parent().get(0).tagName == "SPAN" ) {
				var span = $j(this).parent().get(0);
				$j(span).replaceWith(opt);
				$j(span).remove();
			}
			opt.disabled = false;
			$j(opt).show();
		}
	});
	return this;
}
		
$j.fn.hideOption = function() {
	this.each(function() {
		if( this.tagName == "OPTION" ) {
			var opt = this;
			if( $j(this).parent().get(0).tagName == "SPAN" ) {
				var span = $j(this).parent().get(0);
				$j(span).hide();
			} else {
				$j(opt).wrap("span").hide();
			}
			opt.disabled = true;
			$j(opt).removeAttr('selected');
		}
	});
	return this;
}

$j(document).on('click', '#top_excel', function(e) {
	return  $j('#sel_column_excel option:selected').prependTo('#sel_column_excel') ;  
}); 

$j(document).on('click', '#bottom_excel', function(e) { 
	return  $j('#sel_column_excel option:selected').remove().appendTo('#sel_column_excel'); 
});

function CounterAndSelectionTableShowExport(field,max,type) {
	var firstCharacter = field.value.substring(0, 1);
	var nowCount;	
	if (firstCharacter == ' ') {
		alert("Please enter a export option name that begins with a letter or a number.");
		field.value = "";
		document.getElementById(field.name+"_cnt").childNodes[0].nodeValue = max;
	} else {
		if (/^[a-z\s\d]*$/i.test(firstCharacter)) {				
			if (field.value.length > max) {
				field.value = field.value.substring(0, max);
			} else { 	
				nowCount = max - field.value.length;
				if(field.id == 'save_selection_excel_text') {
					if (nowCount < 140) {
						//$j("#ExportAvailableTableExcel").css('display','block');
						if($j("#exportSavedOptionAvl").val() == 1) {						
							$j("#ExportSavedOption").css('display','block');
						}					
					} else {
						//$j("#ExportAvailableTableExcel").css('display','none');				
						//document.getElementById("check_excel_saved_report_1").checked = false;
						//document.getElementById("check_excel_saved_report_2").checked = false;
						//document.getElementById("check_excel_saved_report_3").checked = false;
						//document.getElementById("check_excel_saved_report_4").checked = false;
						$j("#ExportSavedOption").css('display','none');	
					}
				}
				document.getElementById(field.name+"_cnt").childNodes[0].nodeValue = nowCount;
			}
		} else {
			alert("Please enter a export option name that begins with a letter or a number.");
			field.value = "";
			document.getElementById(field.name+"_cnt").childNodes[0].nodeValue = max;
		}
	}
}
 
function getStaffRoleList(){	

	$j.ajax({
		url: root+'survey.rolelistingsection',
		type: "POST",
		beforeSend: function() {
			showLoadingOverlay();
		},
		success : function(response)
		{			
			var parsedRolelist = $j.parseJSON(response);
			var rolelist = parsedRolelist.data;
			var listLen = rolelist.length;
			var htmlEle = '<div id="role-box" class="">';
			var thisRole;
			for (var i=0; i<listLen;i++){
				thisRole = rolelist[i];
				htmlEle = htmlEle +'<div class="roleListOptions">'+
					'<span class="verticalMiddle">'+
					'<input type="checkbox" class="staffroleoption" name="staffroleoption" id="role_'+thisRole.roleid+'" value="'+thisRole.roleid+'" >'+
					'</span>'+
					'<span class="staffrolename">'+thisRole.rolename+'</span></div>';
			}
			htmlEle = htmlEle + '</div>';			
			$j('#exportsavedoption_rolelist').html(htmlEle);		
			$j('#exportsavedoption_rolelist').slideDown(700);
		},	
		complete: function()
		{
			hideLoadingOverlay();
		},
		error: function() {
				alert("failure");
			}
		});	
}

$j(document).on('click', 'input[type="radio"][name="savedoptionavailable"]', function(e) {
	if($j('#exportsavedoption_rolelist').css('display') == 'block' && ($j('#optiononlyme').is(":checked") || $j('#optionstaffaccess').is(":checked"))) {		
		$j('#exportsavedoption_rolelist').slideUp(100);
	}
});


function loadStatusHandler(status) {
	if (status == "error") {
		var msg = "Sorry but there was an error.";
		alert(msg);
	}
}

$j.fn.loadDialogContent = function (url) {
	this.load(url, {}, function (response, status, xhr) {
		loadStatusHandler(status);
	});
}

$j(document).on('click', 'input#closeDialog', function () {
	var dialog = $j(this).attr('data-dialog');
	$dialog[dialog].dialog('close').empty();
});

function edit_addSelectedColumn() {
	var options = $j('#edit_avl_column option:selected').sort().clone();	
	$j('#edit_sel_column').append(options);	
	//hiding options in available select box
	var foo = [];
	if($j('#ajaxFilterLoading').length && options.length > 50){$j('#ajaxFilterLoading').show();}
	setTimeout( function(){
		$j('#edit_avl_column :selected').each(function(i, selected){ 
		foo[i] = $j(selected).val(); 		  		 
		$j(this).hideOption();
	});	
	if($j('#ajaxFilterLoading').length){$j('#ajaxFilterLoading').hide();} } , 1);			
}
	
function edit_removeSelectedColumn () {
	var foo = [];	
	if($j('#ajaxFilterLoading').length && $j('#edit_sel_column :selected').length > 50){$j('#ajaxFilterLoading').show();} //SE-140 : 3
	setTimeout( function(){
		$j('#edit_sel_column :selected').each(function(i, selected){ 
		foo[i] = $j(selected).val(); 			
		$j('#edit_avl_column option[value="' + (foo[i]) + '"]').showOption();		
	});	
	//removing options from selected box
	$j('#edit_sel_column option:selected').remove(); 
	if($j('#ajaxFilterLoading').length){$j('#ajaxFilterLoading').hide();} } , 1);
}

function moveUp(selectId) {	 
	var selectList = document.getElementById(selectId);
	var selectOptions = selectList.getElementsByTagName('option');	 
	for (var i = 1; i < selectOptions.length; i++) {
		var opt = selectOptions[i];		 
		if (opt.selected) {
			selectList.removeChild(opt);
			selectList.insertBefore(opt, selectOptions[i - 1]);
		}
	}
}
 
function moveDown(selectId) {	 
	var selectList = document.getElementById(selectId);
	var selectOptions = selectList.getElementsByTagName('option');
	for (var i = selectOptions.length - 2; i >= 0; i--) {
		var opt = selectOptions[i];
		if (opt.selected) {
		   var nextOpt = selectOptions[i + 1];
		   opt = selectList.removeChild(opt);
		   nextOpt = selectList.replaceChild(opt, nextOpt);
		   selectList.insertBefore(nextOpt, opt);
		}
	}
}

function moveOptionsTop(selectId) {
	var selectList = document.getElementById(selectId);
	var selectOptions = selectList.getElementsByTagName('option');
	var iMoved = 0;
	for (var i = 1; i < selectOptions.length; i++) {
		var opt = selectOptions[i];
		if (opt.selected) {
			selectList.removeChild(opt);
			selectList.insertBefore(opt, selectOptions[iMoved]);
			iMoved++;
		}
	}
}

function moveOptionsBottom(selectId) {
	var selectList = document.getElementById(selectId);
	var selectOptions = selectList.getElementsByTagName('option');
	var iLen = selectOptions.length;
	for (var i = 1; i < selectOptions.length; i++) {
		moveDown(selectId);
	}
}

$j(document).on('click', 'input[type="radio"][name="edit_savedoptionavailable"]', function(e) {		
	if($j('input[type="radio"][name="edit_savedoptionavailable"]:checked').attr('id') == 'edit_optionstaffbyrole') {		
		$j('#edit_exportsavedoption_rolelist').slideDown(700);
	} else if($j('#edit_exportsavedoption_rolelist').css('display') == 'block'){
		$j('#edit_exportsavedoption_rolelist').slideUp(700);
	}
});

$j(document).on('click', '#edit_include_raw_questions', function(e) {
     if ($j(this).is(":checked")) {		 
		$j('#edit_columnsToInclude').slideDown(700);
     } else {		 
		 $j('#edit_columnsToInclude').slideUp(700);
     }
});

function checkExportNameAvailability(ExportType, ExportNameID, chkContainerID, Scope, associationType, action) {
	var _return_ = true;	
	var scope_list = [];	
	var ExportName = $j('#'+ExportNameID).val().trim();	
		
	scope_list.push(Scope);			
	$j('#'+chkContainerID+' :checkbox:checked').each(function(){ 
		var sc = this.value.trim().toLowerCase();
		switch(sc) {
		  case "i":
			scope_list.push('individual');
			break;	
		  case "p":
			scope_list.push('program');
			break;
		  case "s":
			scope_list.push('site');
			break;
		  case "a1":
			scope_list.push('association1');
			break;
		  case "a3":
			scope_list.push('association3');
			break;	
		  default: console.log('sc = ' + sc);
		}
																		
	});
					
	$j.ajax({			
		url: 'index.cfm?event=survey.checkSavedExportNameAvailability',
		data : {
				 'scope_list' 		: scope_list.join(","),
				 'ExportName' 		: ExportName,
				 'ExportType' 		: ExportType,
				 'associationtype' 	: associationType
			   },
		type: "POST",
		async: false,	
		dataType: 'json',					
		success:function(response) {				
			if(response.RESULT > 0) {
				if(ExportNameID != 'edit_save_selection_text' || (ExportNameID === 'edit_save_selection_text' && document.getElementById('edit_save_selection_text').defaultValue.trim() != document.getElementById('edit_save_selection_text').value.trim()) || (ExportNameID === 'edit_save_selection_text' && action == 'Clone' && document.getElementById('edit_save_selection_text').defaultValue.trim() == document.getElementById('edit_save_selection_text').value.trim()) || (ExportNameID === 'save_selection_excel_text' && action == 'Create')) {
					_return_ = false;
					alert("An Export Option by that name already exists. Please enter a new name.");	
					$j('#'+ExportNameID).focus();
				}
			}						
		},
		error :function() {
		  alert('error occurred!!');
		}
	});	
	
	return _return_;	
}

$j(document).on('click', '.edit_changeArrow', function(e) {
	var _this = $j(this);
	var child_elem_name = _this.attr('attr-panel'); 
	var child_elem_divid = child_elem_name + 'List'; 
	if (_this.hasClass('showarrow')) {		
		_this.removeClass("showarrow");
		_this.addClass("hidearrow");
		_this.siblings('#'+child_elem_divid).slideToggle(1000);					
		$j('input[id='+child_elem_name+']').attr('checked','checked');			
	} else {		
		_this.removeClass("hidearrow");
		_this.addClass("showarrow");
		_this.siblings('#'+child_elem_divid).slideUp(1000);		
		$j('input[id=' + child_elem_name + ']').removeAttr('checked');			
	}
});

function checkMultipleSurvey() {
	$j('#excelExportBtn').prop('disabled', true);
	checkSession();
	setTimeout(function(){
		var siteId = 0;
		var programId = $j('#pgmid').val();
		var dataParam = {
			beginSurvey: document.getElementById('beginsurvey').value,
			endSurvey: document.getElementById('endsurvey').value,
			userid: 0,
			siteId: siteId,
			selprograms: programId
		};
		/* SURVEXPORT-275 */
		if (formData.compilation != ""){
			dataParam.compilation = formData.compilation;
		}/* SURVEXPORT-275 */
		if ($j('.surveyid_list:checked').length == 0) {
			showLoadingOverlay();
			new Ajax.Request('index.cfm?event=survey.checkMultipleSurveys', {
				method: "post",
				parameters: dataParam,
				onSuccess: function(response){
					hideLoadingOverlay();
					var surveyIds = response.responseText.replace(/^\s+|\s+$/g, '');
					if (surveyIds == "") 
						surveyIds = response.responseText.replace(/^\s+|\s+$/g, '');
					if (surveyIds == "") 
						return;
					if (surveyIds == "false") {
						callReportPop();
					} else {
						multipleSurveyWindow(surveyIds);
					}
				},
				onFailure: function(){
					alert('Connection failed');
					$j('#excelExportBtn').prop('disabled', false);
					hideLoadingOverlay();
				}
			});
		} else {
			//submitFucnForSelectedSurveys(submitFunc);
			callReportPop();
		}
		return false;
	},1000);
}

function multipleSurveyWindow(surveyIds)
{
	showLoadingOverlay();
	new Ajax.Request('index.cfm?event=survey.getMultipleSurveyForExport', {
		method: "post",
		parameters: {
			surveyIds: surveyIds
		},
		onSuccess: function(response , data){
			ColdFusion.Window.create("ViewCompletionWindow","View Completion Info.","",{modal:true,width:552,height:600,center:true,draggable:true,initshow:true});			
			//ColdFusion.Window.show('ViewCompletionWindow');
			document.getElementById('ViewCompletionWindow-body').innerHTML = response.responseText;
			//onshow('ViewCompletionWindow');
			//document.getElementById(ColdFusion.Window.getWindowObject("ViewCompletionWindow").header.id).className = "windowHdr";
			//document.getElementById(ColdFusion.Window.getWindowObject("ViewCompletionWindow").header.id).style.display = "block";
			ColdFusion.Window.onHide("ViewCompletionWindow" , function(){ multipleSurveyWindowClose(); });
			hideLoadingOverlay();
		}			
	});		
}

function multipleSurveyWindowClose(enableExport=true) {		
	ColdFusion.Window.destroy("ViewCompletionWindow",true);
	if (enableExport) { $j('#excelExportBtn').prop('disabled', false); }
}

/* End: Step 6 */

//form submit on new tab TS-280
function callReportPop(){
	try {
		multipleSurveyWindowClose(false);
	} catch (err) {}
	
	var timeOut = 0;
	if($j('#save_selection_excel_text').val().trim() != '') {
		saveSurveyExportOptions();
		timeOut = 1000;
	}
	saveCustomizeSelectionData();
  
	setTimeout(function(){
		if(formData.userSelectedAction == 'viewData') {			
			$j('input[type=hidden]#beginsurvey').val(formData.startPeriod);
			$j('input[type=hidden]#endsurvey').val(formData.endPeriod);
			$j('input[type=hidden]#association').val(formData.userSelectedGroups);
			$j('input[type=hidden]#typethreeassociations').val(formData.userSelectedGroups);
			$j('input[type=hidden]#is_surveytable_open').val($j("#is_surveytable_open").val());
									
			var allassociations = "";
			var thirdtypeassociations = "";
			var selectedassociations = formData.userSelectedGroups;
			var selectedGroupListId = selectedassociations.split(',');				
			for( var i =0; i< selectedGroupListId.length;i++) {
				var associationitemschecked = [];
				if(selectedGroupListId.length == 1) {
					associationitemschecked = associationitemschecked.toString();
					associationitemschecked = formData.identifiersIdList;
				} else {
					associationitemschecked = [];				
					$j(".associationItem_" + selectedGroupListId[i] + ":checked").each(function(){	
						associationitemschecked.push($j(this).val());																								
					});	
					associationitemschecked = associationitemschecked.toString();
				}				
																				
				allassociations = allassociations + associationitemschecked.replace(/,/g,"`") + ',';
				thirdtypeassociations = thirdtypeassociations + associationitemschecked.replace(/,/g,"|") + ',';
				
				var inputItemHidden = document.createElement("input");
				inputItemHidden.setAttribute("type", "hidden");				
				inputItemHidden.setAttribute("name", "associationitem_" + selectedGroupListId[i]);	
				inputItemHidden.setAttribute("id", "associationitem_" + selectedGroupListId[i]);	
				inputItemHidden.setAttribute("value", associationitemschecked);								
				document.getElementById("surveyformexcelviewdata").appendChild(inputItemHidden);
				
				var inputTypeHidden = document.createElement("input");
				inputTypeHidden.setAttribute("type", "hidden");				
				inputTypeHidden.setAttribute("name", "includetype_" + selectedGroupListId[i]);	
				inputTypeHidden.setAttribute("id", "includetype_" + selectedGroupListId[i]);	
				inputTypeHidden.setAttribute("value", "any");								
				document.getElementById("surveyformexcelviewdata").appendChild(inputTypeHidden);								
			}
			allassociations = allassociations.substring(0, allassociations.length - 1);
			thirdtypeassociations = thirdtypeassociations.substring(0, thirdtypeassociations.length - 1);
				
			if($j('input.attributeindvalue:checked').length) {
				var omitArray = [];
				var includeArray = [];
				$j('input.attributeindvalue:checkbox:not(:checked)').each(function () {
				inputName = $j(this).attr('name').split('_')[1];
				if($j.inArray( inputName, omitArray ) === -1)
						omitArray.push( inputName );
				});
				$j('input.attributeindvalue:checkbox:checked').each(function () {
				inputName = $j(this).attr('name').split('_')[1];
				if($j.inArray( inputName, includeArray ) === -1)
						includeArray.push( inputName );
				});
				var diffArray = $j(omitArray).not(includeArray).get();					
				var diffArrayList = diffArray.join(",");
				var omitListAttributeList = diffArray.join(",");
				var includeListAttributeList = includeArray.join(",");					
				omitListAttributeList = omitArray.join(",");
				$j('input[type=hidden]#omitAttributeList').val(omitListAttributeList);	
			}
		
			var groupProfileField = [];
			$j('input.groupProfileType:checked').each(function(){	
				groupProfileField.push($j(this).val());																								
			});
			if (groupProfileField.length) {
				for( var i =0; i< groupProfileField.length;i++) {
					var attributeValues = [];
					$j('input.attributeindvalue_' + groupProfileField[i] +':checked').each(function(){	
						if ($j(this).attr('attr-encryptvalue') != undefined){ /* SURVEXPORT-260:S */
							attributeValues.push($j(this).attr('attr-encryptvalue'));
						}else{
							attributeValues.push($j(this).val());
						} /* SURVEXPORT-260:E */
					});
					var attributeValueSelected = attributeValues.join("^").toString();
					
					var inputTypeHidden = document.createElement("input");
					inputTypeHidden.setAttribute("type", "hidden");				
					inputTypeHidden.setAttribute("name", "attributeindvalue_" + groupProfileField[i]);	
					inputTypeHidden.setAttribute("id", "attributeindvalue_" + groupProfileField[i]);	
					inputTypeHidden.setAttribute("value", attributeValueSelected);								
					document.getElementById("surveyformexcelviewdata").appendChild(inputTypeHidden);
				}
				$j('input[type=hidden]#includetype_attribute').val('any');
			} else {
				$j('input[type=hidden]#includetype_attribute').val('none');
			}
												
			$j('input[type=hidden]#allassociations').val(allassociations);
			$j('input[type=hidden]#thirdtypeassociations').val(thirdtypeassociations);
			
			var beginsurveytext = $j("#beginsurvey option:selected").text();
			var endsurveytext = $j("#endsurvey option:selected").text()	;
			$j('input[type=hidden]#beginendsurveydateselected').val(beginsurveytext + "~`" + endsurveytext);
			
			var selectedradioval = $j.trim($j('input[name=radio_SelectedreportType]:checked').val());
			var selectedReportVal = "";
			if (selectedradioval == 'selectedreport') {
				selectedReportVal = $j.trim($j('input[name=radio_ReportIDSelection]:checked').val());
			}
			$j('input[type=hidden]#radio_SelectedreportType').val(selectedradioval);
			$j('input[type=hidden]#radio_ReportIDSelection').val(selectedReportVal);
			$j('input[type=hidden]#form_hdn_selectedQuestionIdReporting').val(formData.compilation);
			$j('input[type=hidden]#form_hdn_selectedMatrixRowId').val(formData.selectedMatrixRowId);
			$j('input[type=hidden]#form_hdn_mRowList').val($j('#mRowList').val());
			$j('input[type=hidden]#notSelectedIDs').val(formData.notselectedSurveysList);
			$j('input[type=hidden]#SelectedIDs').val(formData.selectedSurveysList);
			$j('input[type=hidden]#surveyid_list').val(formData.selectedSurveysList);
			$j('input[type=hidden]#fromSelectedSurvey').val(formData.fromSelectedSurvey);
			$j('input[type=hidden]#launch_selection').val($j('input[name=launch_selection]').val());
			
			document.Survey.submit();			
		} else {
			wnd = window.open("","AssignItems","height=520,width=800,status=0,menubar=0,titlebar=0,resizable=1,scrollbars=1");
			//wnd.document.write("Loading...");	
			new Ajax.Request('index.cfm?event=survey.openBenificiaryExportPopUp', {
				method: "post",
				parameters: formData,
				onSuccess: function(response , data){
					wnd.document.write(response.responseText);
					wnd.document.close();
					$j('#excelExportBtn').prop('disabled', false);				
				},
				onFailure: function(response){
					alert('Connection failed');
					wnd.document.write(response.responseText);
					wnd.document.close();
					$j('#excelExportBtn').prop('disabled', false);
				}			
			});
		}
	},timeOut);
}

function MultipleSurveyWindow_OnSubmit() {	
	$j('#multipleSurveySubmitDiv').html('<a href="javascript:void(0);" style="color:#0066FF;">Submit</a>');
	checkSession();
	var anySurveyChecked = jQuery('td.tblChkBoxSurveys input:checkbox:checked').length;
	//SurveyExport-431
	/*if (anySurveyChecked == 0) {
		alert("Please select at least one form or click 'Cancel' and choose another period of time to compile data for.");
		$j('#multipleSurveySubmitDiv').html('<a id="multipleSurveySubmit" style="color:#0066FF;"  onclick="this.disabled=true;MultipleSurveyWindow_OnSubmit();">Submit</a>');
		return false;
	}*/
	formData.notselectedSurveysList = "";
	setTimeout(function(){
		var notSelectedSurveyIdsCheckBox = $j('td.tblChkBoxSurveys input[type=checkbox].chkBoxSurveys:not(:checked)');
		/* var selectedSurveyIds = "", notSelectedSurveyIds = ""; */
	
		if (notSelectedSurveyIdsCheckBox.length) {
			/* for (var indx=0; indx<notSelectedSurveyIdsCheckBox.length; indx++) {
				notSelectedSurveyIds = notSelectedSurveyIds +','+ $j(notSelectedSurveyIdsCheckBox[indx]).val();
			}
			formData.notselectedSurveysList = notSelectedSurveyIds.slice(1); //remove the first comma sign; */
			formData.notselectedSurveysList = notSelectedSurveyIdsCheckBox.map(function() {return this.value;}).get().join(',');
		}
		callReportPop();
	
		/* Only set notselectedSurveysList */
		/* formData.selectedSurveysList = $j('td.tblChkBoxSurveys input[type=checkbox].chkBoxSurveys:checked').map(function() {return this.value;}).get().join(','); */
	}, 1000);
}

function selectForm(selectOpt) {

	var allSurveyIdsCheckBox = $j('input[type=checkbox].chkBoxSurveys');

	if (selectOpt == 1) {
		$j(allSurveyIdsCheckBox).prop('checked', true);
		/* for (var indx=0; indx<selectedSurveyIds.length; indx++) {
			selectedSurveyIds = selectedSurveyIds +','+ selectedSurveyIdsCheckBox[indx];
		} */		
	}
	else if (selectOpt == 0) {
		$j(allSurveyIdsCheckBox).prop('checked', false);
		/* for (var indx=0; indx<selectedSurveyIds.length; indx++) {
			selectedSurveyIds = selectedSurveyIds +','+ selectedSurveyIdsCheckBox[indx];
		} */		
	}
}

function showhideExportExcelButton() {
	/* if(formData.setStep1 == 1 && formData.setStep2 == 1 && formData.setStep3 == 1 && formData.setStep4 == 1 && formData.setStep5 == 1 && formData.setStep6 == 1) */
	if( (formData.setStep1 == 1 && formData.setStep2 == 1 && formData.setStep3 == 1 && formData.setStep4 == 1 && formData.setStep5 == 1) && ( (formData.userSelectedAction == "exportData" && formData.setStep6 == 1) || formData.userSelectedAction == 'viewData')) {
		if(formData.userSelectedAction == 'viewData') {
			$j("#excelExportBtn").val("View Data");
		} else {
			$j("#excelExportBtn").val("Export to Excel");
		}
		$j("#exportExcelButtonDiv").show();
	} else {
		$j("#exportExcelButtonDiv").hide();
	}
}



/* Start: STEP 1 | Select Operation */
function setUserActionSelection(obj) {	
	checkSession();
	if($j(obj).is('div'))
		var buttonText = $j(obj).text().trim().toLowerCase();
	else	
		var buttonText = $j(obj).val().trim().toLowerCase();
	
	if(buttonText == 'set') {		
		$j("#editcheckuseraction").show();
		$j("#lblSummaryAction").show();
		$j(".bgformgroupitem").hide();
		$j("#btnuseraction").hide();
		if($j('input[name="useractionoption"]:checked').val() == 'export') {
			formData.userSelectedAction = 'exportData';
			$j("#lblSummaryActionOption").html('Export Data to Excel');			
		} else {
			formData.userSelectedAction = 'viewData';
			$j("#lblSummaryActionOption").html('View Data');			
		}
		$j("#lblSummaryActionOption").show();		
		formData.setStep1 = 1;
		enableNextStep(2);
	} else {		
		$j(".bgformgroupitem").show();
		$j("#btnuseraction").show();		
		$j("#lblSummaryAction").hide();
		$j("#lblSummaryActionOption").hide();
		$j("#editcheckuseraction").hide();
		formData.setStep1 = 0;		
		var accor_div = $j(obj).closest('div.contentBodyPanel').prev('div.panelhead')[0];
		setSectionIcon(accor_div, 'edit');			
	}
	
	if(formData.userSelectedAction == 'viewData') {		
		if(formData.userSelectedGroups != '') {
			checkProfileAndFieldsAvailability();
		}
	} else {
		$j('#filterbyfield').hide();
	}
	
	showhideExportExcelButton();
}

/* End: STEP 1 | Select Operation */

/* STEP 2 | Select Groups */
$j(document).on('change', '#attibuteid', function (e) {	
	var attridVal= $j(this).val();
	if(attridVal != ''){
		var targetURL = "index.cfm?event=association.getAttributeValBasedAssociations_Ajax"
	}
	else{
		var targetURL = "index.cfm?event=association.getAllAssociationsWithData_Ajax";
		$j('table.bg-wrt-field').remove();
		$j("table.bg-list-onload input.bg-checkbox").prop("checked", false);  //checkSelectedBGboxes();
		$j('table.bg-list-onload').show();
		$j("input[type=hidden][name='hdn_bg-selected-view']").val(0);
		$j("input[type=hidden][name='hdn_bg-selected']").val("");
		ShowHideGroupsSetbtn();
		hideLoadingOverlay();
		return false;
	}
		$j.ajax({
		type: "post",
		async:true,
		dataType: "json",
		data: {attrid:attridVal},
		url: targetURL,
		beforeSend: function() {
			showLoadingOverlay();
		},
		error: function(data) { hideLoadingOverlay(); return false; },
		success: function(data) { 
			if(attridVal != ''){
				//$j('.filteredAssociationList').html('');
				$j('table.bg-list-onload').hide();
				$j('table.bg-wrt-field').remove();
				var counter = 1;
				var dataHTML = '<table width="100%" class="bg-wrt-field">';
				if(data.length == 0) {
					dataHTML = dataHTML+'<tr><td colspan="2" style="font-weight:normal; padding:10px 0px 0px 10px;">Data is not available for this field.</td></tr>';
				} else if(data.length > 1) {
					dataHTML = dataHTML+'<tr><td colspan="2" style="padding:10px 0px 10px;color:blue;"><a class="selectalltype3association select-all" id="section2_selectall" onclick="selectalltype3association(this);">Select All</a></td></tr>'; // <!--- MCR-50 & 47 / MCR-70 --->
				}
				else {
					dataHTML = dataHTML+'<tr><td colspan="2" style="padding:10px 0px 10px;"></td></tr>'; // <!--- MCR-50 & 47 / MCR-70--->
				}
				$j.each(data, function(index, attribute) {	
					dataHTML = dataHTML+'<tr><td colspan="2">';
										
					dataHTML = dataHTML+'<table width="100%" style="padding:0px 0px 5px;">';
					dataHTML = dataHTML + '<tr><td colspan="2"><lable style="font-weight:bold; margin-bottom:10px;">'+attribute.attrVal.toString().trim()+'</lable></td></tr>';
					if(attribute.assolist.length > 1) {
						dataHTML = dataHTML + '<tr><td colspan="2" style="font-weight:normal; color:blue;"><span><a id="section2_selectall_'+attribute.attrid+'_'+counter+'"  class="select-all selectall" onclick="selectAttrValAssociation(this,'+attribute.attrid+','+counter+');">Select All</a></span></td></tr>';
					} else {
						dataHTML = dataHTML + '<tr><td colspan="2" style="font-weight:normal; color:blue;display:none;"><span><a id="section2_selectall_'+attribute.attrid+'_'+counter+'"  class="select-all selectall" onclick="selectAttrValAssociation(this,'+attribute.attrid+','+counter+');">Select All</a></span></td></tr>';	
					}
					$j.each(attribute.assolist, function(index, association) {
						dataHTML = dataHTML + '<tr><div class="margin-bottom-5"><td valign="top" width="20"><input type="checkbox" id="association-'+association.assoId+'_attribute_'+attribute.attrid+'_'+counter+'" name="association" style="margin-top:0px !important" class="bg-checkbox section2 attribute_'+attribute.attrid+'_'+counter+'" value="'+association.assoId+'"></div></td><td class="section_name"><div class="margin-bottom-5"><label for="association-'+association.assoId+'_attribute_'+attribute.attrid+'_'+counter+'">'+association.assoTitle+'</label><a href="index.cfm?event=association.editbeneficiary&associationid=' + association.assoId + '&statusAttrVal=1" class="externallink-url" target="_blank"><img src="../../../images/icons/external-link.png" class="externallink-img"/></a></div></td></tr>';
					});
					dataHTML = dataHTML + '</table><div style="height:10px" class="clear"></div>';	
					counter = counter + 1;						
					dataHTML = dataHTML + '</td></tr>';
				});
				dataHTML = dataHTML + '</table>';
				//$j('.filteredAssociationList').html(dataHTML);
				$j("input[type=hidden][name='hdn_bg-selected-view']").val(1);
				$j("input[type=hidden][name='hdn_bg-selected']").val("");
				$j('.filteredAssociationList').append(dataHTML);
			}
			/* else {
				var dataHTML = '<table width="100%">';
				if(data.length > 1){
				dataHTML = dataHTML + '<tr><td colspan="2" style="font-weight:normal; padding:10px 0px 5px;color:blue;"><a style="cursor:pointer;" class="selectalltype3association" id="section2_selectall">Select All</a></td></tr>';
				}
				$j.each(data, function(index, association) {
					dataHTML = dataHTML+'<tr><td valign="top" width="20"><input onclick="selectalltype3linktoggle(this)" type="checkbox" id="association-'+association.associationid+'" name="association" class="section2" value="'+association.associationid+'"></td><td class="padding-top-1">'+association.title+'</td></tr>';
				});						

				$j('.filteredAssociationList').html(dataHTML);
			} */
			ShowHideGroupsSetbtn();
			hideLoadingOverlay();
		}
				
	});		
});

$j(document).on("click", ".filteredAssociationList .bg-checkbox", function (e) {
	var ids = [];
	var $bg_chckbx = $j(this);
	var selected_bg_ids = $j("input[type=hidden][name='hdn_bg-selected']").val();
	var bgView = $j("input[type=hidden][name='hdn_bg-selected-view']").val(); //view selected
	ids = selected_bg_ids.split(",");
	
	var $tableObj = $j(this).closest('table'); //$j('input.bg-checkbox:checked').first().closest('table').css('display')
	var tableClass = $tableObj.attr('class');

	if ($bg_chckbx.prop("checked") == true) {
		if (ids.indexOf($bg_chckbx.val()) < 0) { //only if value does not exist in list
			if (selected_bg_ids.trim().length ==  0) {
				selected_bg_ids = $bg_chckbx.val();
			} else {
				selected_bg_ids = selected_bg_ids + ',' + $bg_chckbx.val();
			}
			$j("input[type=hidden][name='hdn_bg-selected']").val(selected_bg_ids);
		}		
	} else { //unchecked
		if (ids.indexOf($bg_chckbx.val()) > -1) { //only if value exist in list
			if (bgView == 1) { //tableClass == 'bg-wrt-field'
				//get all checkbox with value = $bg_chckbx.val()
				var checkedLen = $j("table.bg-wrt-field input.bg-checkbox[value="+ $bg_chckbx.val() +"]:checked").length;
				if (checkedLen == 0) { //all checkbox unchecked only then remove
					$j(ids).remove($bg_chckbx.val());	
				}
			} else {
				$j(ids).remove($bg_chckbx.val());
			}
		}		
		/* for (var i=0;i<ids.length;i++) {
			if (ids.indexOf($bg_chckbx.val()) > -1) {				
				ids.remove($bg_chckbx.val());
			}
		} */
		$j("input[type=hidden][name='hdn_bg-selected']").val(ids.join(","));
	}
	
	if (bgView == 1) { 
		selectall_FieldView_LableCheck($bg_chckbx);
	}
	selectall_LableCheck();
	ShowHideGroupsSetbtn();
});

function selectall_LableCheck(){
	var bgView = $j("input[type=hidden][name='hdn_bg-selected-view']").val(); //view selected
	
	if (bgView == 1) { //tableClass == 'bg-wrt-field'
		var allCheckBoxLen = $j("table.bg-wrt-field input.bg-checkbox").length;
		var checkedBoxLen = $j("table.bg-wrt-field input.bg-checkbox:checked").length;
		var $a_selectAll = $j("table.bg-wrt-field a#section2_selectall");
	} else {		
		var allCheckBoxLen = $j("table.bg-list-onload input.bg-checkbox").length;
		var checkedBoxLen = $j("table.bg-list-onload input.bg-checkbox:checked").length;
		var $a_selectAll = $j("table.bg-list-onload a#section2_selectall");
	}
	
	if (checkedBoxLen == allCheckBoxLen) { //all checkbox checked
		$a_selectAll.removeClass("selectalltype3association").addClass("selectnonetype3association");
		$a_selectAll.html("Select None");		
	} else {		
		$a_selectAll.removeClass("selectnonetype3association").addClass("selectalltype3association");		
		$a_selectAll.html("Select All");
	}
}

function selectall_FieldView_LableCheck($bgc){	 //sv - selected checbox obj
	var bgView = $j("input[type=hidden][name='hdn_bg-selected-view']").val(); //view selected

	if (bgView == 1) {
		var $fld_selectAll = $bgc.closest('table').find('a.select-all');
		var checkBoxClass = $bgc.attr('class').split(" ").join('.').toString();
		var allCheckBoxLen = $j("table.bg-wrt-field input."+ checkBoxClass).length; //checkBoxClass +"]"
		var checkedBoxLen = $j("table.bg-wrt-field input."+ checkBoxClass +":checked").length;
		
		if (checkedBoxLen == allCheckBoxLen) { //all checkbox checked
			$fld_selectAll.removeClass("selectall").addClass("selectnone");
			$fld_selectAll.html("Select None");	
		} else {
			$fld_selectAll.removeClass("selectnone").addClass("selectall");
			$fld_selectAll.html("Select All");
		}
	}
}

function selectalltype3association(e){	
	var ids = [];
	if($j(e).hasClass("selectalltype3association")){
		$j(".bg-checkbox").each(function(){
			$j(this).prop("checked",true);
			if (ids.indexOf($j(this).val()) < 0) {
				ids.push($j(this).val());
			}
		});
		$j(e).removeClass("selectalltype3association").addClass("selectnonetype3association");
		$j(e).html("Select None");		
		$j("input[type=hidden][name='hdn_bg-selected']").val(ids.join(","));		
		
		$j(".selectall").each(function(){
			$j(this).removeClass("selectall").addClass("selectnone");
			$j(this).html("Select None");
		});
	}else{
		$j(".bg-checkbox").each(function(){		
			$j(this).prop("checked",false);
		});
		$j(e).removeClass("selectnonetype3association").addClass("selectalltype3association");		
		$j(e).html("Select All");
		$j("input[type=hidden][name='hdn_bg-selected']").val("");	
		
		$j(".selectnone").each(function(){
			$j(this).removeClass("selectnone").addClass("selectall");
			$j(this).html("Select All");
		});
	}
	ShowHideGroupsSetbtn();	
}

function selectAttrValAssociation(e,attrid,counter){	
	var ids = [];	
	if($j(e).hasClass("selectall")){
		$j('.attribute_'+attrid+'_'+counter).each(function(){
			$j(this).prop("checked",true);
			if (ids.indexOf($j(this).val()) < 0) {
				ids.push($j(this).val());
			}
		});
		$j(e).removeClass("selectall");
		$j(e).addClass("selectnone");
		$j(e).html("Select None");		
	}else{
		var selected_bg_ids = $j("input[type=hidden][name='hdn_bg-selected']").val();
		ids = selected_bg_ids.split(",");

		$j('.attribute_'+attrid+'_'+counter).each(function(){
			$j(this).prop("checked",false);
			if (ids.indexOf($j(this).val()) > -1) {				
				var checkedLen = $j("table.bg-wrt-field input.bg-checkbox[value="+ $j(this).val() +"]:checked").length;
				if (checkedLen == 0) { //all checkbox unchecked only then remove
					$j(ids).remove($j(this).val());	
				}
			}			
		});
		$j(e).removeClass("selectnone");
		$j(e).addClass("selectall");		
		$j(e).html("Select All");		
	}
	$j("input[type=hidden][name='hdn_bg-selected']").val(ids.join(","));
	
	var lengthofA = $j(".filteredAssociationList a").length-2;
	var countselectnone = 0;
	$j(".filteredAssociationList a").each(function(){				
		if($j(this).hasClass("selectnone")){
			countselectnone++;
		}			
	});
	if(countselectnone<lengthofA){
		$j('.selectnonetype3association').addClass("selectalltype3association");
			$j('.selectnonetype3association').removeClass("selectnonetype3association");				
			$j('.selectalltype3association').html("Select All");//<!--- MCR-47 / MCR-70 --->
	}
	else{
		$j('.selectalltype3association').addClass("selectnonetype3association");
			$j('.selectalltype3association').removeClass("selectalltype3association");				
			$j('.selectnonetype3association').html("Select None");//<!--- MCR-47 / MCR-70 --->
	}
	ShowHideGroupsSetbtn();
}

function checkSelectedBGboxes(){
	var ids = [];
	var selected_bg_ids = $j("input[type=hidden][name='hdn_bg-selected']").val();
	ids = selected_bg_ids.split(",");

	$j(".bg-checkbox").each(function(){
		$j(this).prop("checked",false);
		if (ids.indexOf($j(this).val()) > -1) {
			$j(this).prop("checked",true);
		}
	});
	ShowHideGroupsSetbtn();
}

function setSelectedBGinhidden(){ //SURVEXPORT-254:S
	var ids = $j("input.bg-checkbox:checked").map(function() {return this.value;}).get().join();
	$j("input[type=hidden][name='hdn_bg-selected']").val(ids);
	ShowHideGroupsSetbtn();
} //SURVEXPORT-254:E

function ShowHideGroupsSetbtn(){
	var checkedLen = $j("input.bg-checkbox:checked").length;
	var selectedBgLen = $j("input[type=hidden][name='hdn_bg-selected']").val().trim().length;

	if(checkedLen > 0 && selectedBgLen > 0)
		$j('#btnSelectGroup').show();
	else
		$j('#btnSelectGroup').hide();
}

function ShowHideGroupsSectionLabel(obj){
	
	if($j(obj).is('div'))
		var buttonText = $j(obj).text().trim().toLowerCase();
	else	
		var buttonText = $j(obj).val().trim().toLowerCase();

	if(buttonText == 'set') {		
		var bgTableView = $j("input[type=hidden][name='hdn_bg-selected-view']").val();
		
		if (bgTableView == 1) {
			var bgCheckboxesLbl = "table.bg-wrt-field input.bg-checkbox";
		}else {
			var bgCheckboxesLbl = "table.bg-list-onload input.bg-checkbox";
		}
		var $bgCheckboxes = $j(bgCheckboxesLbl+":checked");
		var checkedLen = $bgCheckboxes.length;
		var selectedBgLen = $j("input[type=hidden][name='hdn_bg-selected']").val().trim().length;

		var labelText = "";		 		
		var ids_new = [];
		if(checkedLen > 0 && selectedBgLen > 0) {			
			/* var selected_bg_ids = $j("input[type=hidden][name='hdn_bg-selected']").val();
			var ids = selected_bg_ids.split(","); */			
			$bgCheckboxes.each(function(){
				if (ids_new.indexOf($j(this).val()) == -1) {
					if (labelText.trim() == "") {
						labelText = $j(this).closest('tr').find('label').text();
					} else {
						labelText = labelText + ', '+ $j(this).closest('tr').find('label').text();
					}
					ids_new.push($j(this).val());			
				}
			});
			$j("input[type=hidden][name='hdn_bg-selected']").val(ids_new.join(',').toString());

			$j('#lblSummaryGroups').html(labelText);
			$j('#btnSelectGroup').hide();
			$j('#div_section2').slideUp();
			$j('.group-label').slideDown();
			$j('#editcheckselectgroup').show();
			formData.userSelectedGroups = ids_new.join(',').toString();
			formData.setStep2 = 1;	
			if(formData.userSelectedGroups != _userSelectedGroups) {
				setIdentifiersIncludeSection();
				if($j('#rad_saved_views_excel').prop('checked') == true) {
					$j('#rad_saved_views_excel').prop('checked',false);
					$j('#SavedSelectionExcel').css('display','none');
					$j('#SavedSelectionExcel').html('');
					$j('#btnselectexportoptions').css('display','none');
				}
			}
			enableNextStep(3);
		} else {
			alert("Please select at least one association to view data for.");
			$j('#btnSelectGroup').hide();
		}
	} else {		
		$j('.group-label').slideUp();
		$j('#editcheckselectgroup').hide();
		$j('#div_section2').slideDown();
		var accor_div = $j(obj).closest('div.contentBodyPanel').prev('div.panelhead')[0];
		setSectionIcon(accor_div, 'edit');
		formData.setStep2 = 0;
		ShowHideGroupsSetbtn();
		_step2editCounter = 1; 
		_userSelectedGroups = formData.userSelectedGroups;
	}	
}

/* STEP 2 | Select Groups */

/* Start: STEP 3 | Select Group Identifiers */

function setIdentifiersIncludeSection() {
	var selectedGroupList = formData.userSelectedGroups;
	var selectedGroupIdList = selectedGroupList.split(',');
	
	$j('#identifierSummary').hide();		
	$j('#selectIdentifiersSection').show();
	$j('#singlegroupidentifierlisting').hide();
	$j('#singlegroupidentifierlisting').html('');
	$j('#multigroupidentifierlisting').hide();
	$j('#multigroupidentifierlisting').html('');
	$j('#btnselectidentifiers').hide();
	//_step2editCounter = 0; 
	identifierLoadStatus = 0;
	filterFieldValuesStatus = 0;
	formData.setStep3 = 0;
	showhideExportExcelButton();
	var _current_time_cache = new Date().getTime();		
	if (selectedGroupIdList.length == 1) {
		$j('#singleGroupIdentifier').show();			
		var associationId = formData.userSelectedGroups;
		var reportsDivContent = "";
		var url = "index.cfm?event=survey.getAllSavedIdentifierExportReport&associationId=" + associationId + "&currenttimestamp=" + _current_time_cache;		
		$j.ajax({			
			url:url,	
			dataType: 'html',
			beforeSend: function() {
				showLoadingOverlay();
			},
			success: function(savedReportsData) { 				
				savedReportsData = JSON.parse(savedReportsData);
				var totalReports = savedReportsData.data.length;
				if(totalReports == 0) {
					$j('#savedexportidentifier').css('display','none');	
					$j("#savedexportfiltersection").css('color','#999999');
					$j("#savedexportfiltersection").html('<a style="color:#999999;text-decoration: underline;" disabled="true">Use a saved filter from the Identifier export page.</a> (<a style="color:blue;" href="index.cfm?event=association.exportassociationidentifiers&associationid=' + associationId + '" target="_blank">Create a filter.</a>)');
					$j('#btnselectidentifiers').hide();
				} else {					
					for (var i = 0; i < totalReports; ++i) {							
						reportsDivContent += '<div class="saved_report_item margin-bottom-5"><div class="font-normal"><span class="pull-left" style="margin:2px"><input name="report_name" type="radio" value="' + savedReportsData.data[i].ReportId + '" ';
						if(i == 0) {
							reportsDivContent += 'checked';
						}						
						reportsDivContent += '></span><span id="exportReport_' + savedReportsData.data[i].ReportId + '" style="float: left; word-break: break-word; width: 200px; margin:2px 3px">' + savedReportsData.data[i].ReportName + '</span><span id="preview_' + savedReportsData.data[i].ReportId + '" class="previewReport">(<a href="index.cfm?event=association.exportassociationidentifiers&associationid=' + associationId + '&reportId=' + savedReportsData.data[i].ReportId + '" class="previewReportLink" target="_blank">Preview</a>)</span></div></div><div class="clear"></div>';
					}		
					$j("#savedexportfiltersection").css('color','#0000FF ');
					$j("#savedexportfiltersection").html('<a href="javascript:void(0);" id="usesavedfilterlink" style="color:#0000FF ;text-decoration: underline;">Use a saved filter from the Identifier export page.</a>');
					$j('#savedexportidentifier').html(reportsDivContent);					
				}
			},
			complete: function() {				
				hideLoadingOverlay();
			},
			error: function() {
				alert('Oops...mistake on server');	
				hideLoadingOverlay();
			}
		});
		$j('#multiGroupIdentifier').hide();			
	} else {
		$j('#multiGroupIdentifier').show();
		$j('#singleGroupIdentifier').hide();				
	}	
	
	if(formData.userSelectedGroups != '') {
		var selectedGroupList = formData.userSelectedGroups;
		showLoadingOverlay();
		/* Start: Code to disbale Saved Options in Step 6, if its not available for Selected BG */		
		var savedSelectionBGIds = $j('#savedSelectionBeneficiaryGroup').val();	
		var savedSelectionBGArray = savedSelectionBGIds.split('~');		
		if(savedSelectionBGArray.indexOf(selectedGroupList) == -1) {
			if($j('#rad_saved_views_excel').prop('checked') == true) {
				$j('#rad_saved_views_excel').prop('checked',false);
				$j('#btnselectexportoptions').css('display','none');
			}
			
			$j('#rad_saved_views_excel').prop('disabled',true);			
			$j('#savedexportoption').css('color','##999999');
			$j('#SavedSelectionExcel').css('display','none');
		} else {
			$j('#rad_saved_views_excel').prop('disabled',false);
			$j('#savedexportoption').css('color','##333333');
		}
		/* End: Code to disbale Saved Options in Step 6, if its not available for Selected BG */
		
		var url = "index.cfm?event=survey.getAttributeIdsForSurveyExport&currenttimestamp=" + _current_time_cache;	
		$j.ajax({			
			url:url,
			type: "POST",
			data : {association:selectedGroupList},			
			success: function(associationAttributeList) {	
				associationAttributeList = associationAttributeList.replace(/\"/g, "");
				$j('#Availableattributeslist').val(associationAttributeList);									
			},			
			error: function() {
				alert('Oops...mistake on server');	
				hideLoadingOverlay();
			}
		});					
		checkProfileAndFieldsAvailability();
		hideLoadingOverlay();
	}
}

$j(document).on('click', '#usesavedfilterlink', function(e) {	

	if($j('#singlegroupidentifierlisting').css('display') == 'block') {
		var associationId = formData.userSelectedGroups;
		$j('#singlegroupidentifierlisting').slideUp(100);	
		$j('.associationItemCheckbox').prop('checked',false);			
	}
	
	if($j('#savedexportidentifier').css('display') == 'block') {		
		$j('#savedexportidentifier').slideUp(700);	
		$j('#btnselectidentifiers').hide();
	} else {	
		if($j("#usesavedfilterlink").html() == 'Use a saved filter from the Identifier export page.') {
			$j('#savedexportidentifier').slideDown(700);
			$j('#btnselectidentifiers').show();
		}
	}														 
});
		
function selectIdentifiersToInclude(obj) {
	
	if($j(obj).is('div'))
		var buttonText = $j(obj).text().trim().toLowerCase();
	else	
		var buttonText = $j(obj).val().trim().toLowerCase();

	if(buttonText == 'set') {
		var selectedGroupList = formData.userSelectedGroups;
		var selectedGroupIdList = selectedGroupList.split(',');
		formData.identifiersIdList = "";
		
		if (selectedGroupIdList.length == 1) {
			
			if($j('#savedexportidentifier').css('display') == 'block') {
				
				var _current_time_cache = new Date().getTime();	
				var selectedReportId = $j('input[name=report_name]:checked').val();	
				var url = "index.cfm?event=survey.getSavedExportReportIdentifiers&associationId=" + selectedGroupList + "&reportId=" + selectedReportId + "&currenttimestamp=" + _current_time_cache;	
				$j.ajax({			
					url:url,	
					dataType: 'html',
					beforeSend: function() {
						showLoadingOverlay();
					},
					success: function(savedReportsIdentifiers) { 	
					
						if(savedReportsIdentifiers != "") {							
							formData.identifiersIdList = savedReportsIdentifiers.replaceAll('"','');							
						} 
					},
					complete: function() {				
						hideLoadingOverlay();
					},
					error: function() {
						alert('Oops...mistake on server');	
						hideLoadingOverlay();
					}
				});		
				
				if(formData.userSelectedAction == 'viewData') {
					var confirmationMsg = '';					
					if($j('input.groupProfileType:checked').length && $j('input.attributeindvalue:checked').length == 0 ) {
						confirmationMsg = "In the Filter by Fields: Field values were not selected, so none will be included in the result.";
					}
					
					var userResponse = true;
					if(confirmationMsg != '') {
						userResponse = confirm(confirmationMsg);
					}
					
					if(!userResponse) {
						return false;
					}
				}				
				$j('#lblSummaryIdentifiersOption').html($j('#exportReport_' + selectedReportId).html());				
			} else {
				var associationIdentifiersSelected = [];
				$j(".associationItemCheckbox:checked").each(function(){	
					associationIdentifiersSelected.push($j(this).val());																								
				});
				formData.identifiersIdList = associationIdentifiersSelected.toString();
				$j('#lblSummaryIdentifiersOption').html('Selected Identifiers');
			}
		} else {
			var validationMsg = "";
			for(var i=0; i< selectedGroupIdList.length; i++) {
				if($j('.associationItem_' + selectedGroupIdList[i] + ':checked').length == 0) {
					validationMsg = validationMsg + "Please select at least one identifier from each " + beneficiaryAliasSingular + " Group.";
				}
			}
			
			if(validationMsg != '') {
				alert(validationMsg);
				return false;
			}
						
			if(formData.userSelectedAction == 'viewData') {
				var confirmationMsg = '';				
				if($j('input.groupProfileType:checked').length && $j('input.attributeindvalue:checked').length == 0 ) {
					confirmationMsg = "In the Filter by Fields: Field values were not selected, so none will be included in the result.";
				}
				
				var userResponse = true;
				if(confirmationMsg != '') {
					userResponse = confirm(confirmationMsg);
				}
				
				if(!userResponse) {
					return false;
				}
			}
			
			var associationIdentifiersSelected = [];
			$j(".associationItemCheckbox:checked").each(function(){	
				associationIdentifiersSelected.push($j(this).val());																								
			});
		
			formData.identifiersIdList = associationIdentifiersSelected.toString();
		
			$j('#lblSummaryIdentifiersOption').html('Selected Identifiers');
		}
		$j('#selectIdentifiersSection').hide();
		$j('#btnselectidentifiers').hide();
		$j('#identifierSummary').show();	
		formData.setStep3 = 1;
		enableNextStep(4);
	} else {
		$j('#identifierSummary').hide();		
		$j('#selectIdentifiersSection').show();
		$j('#btnselectidentifiers').show();
		formData.setStep3 = 0;		
		var accor_div = $j(obj).closest('div.contentBodyPanel').prev('div.panelhead')[0];
		setSectionIcon(accor_div, 'edit');
	}
	showhideExportExcelButton();
}

function displayGroupIdentifiersListing(currentDivSection) {
	var selectedGroupList = formData.userSelectedGroups;	
	var _current_time_cache = new Date().getTime();
	
	if($j('#savedexportidentifier').css('display') == 'block') {
		$j('#savedexportidentifier').slideUp(700);
		if($j('.associationItemCheckbox:checked').length == 0) {
			$j('#btnselectidentifiers').hide();
		}
	}
	
	if($j('#' + currentDivSection).css('display') == 'block') {
		$j('#' + currentDivSection).slideUp(700);
	} else {
		if(identifierLoadStatus == 1) {
			$j('#' + currentDivSection).slideDown(700);
		} else {
			var url = "index.cfm?event=survey.getBeneficiaryGroupIdentifiersWithFields&currenttimestamp=" + _current_time_cache;	
			$j.ajax({			
				url:url,
				type: "POST",
				data : {associations:selectedGroupList},		
				beforeSend: function() {
					showLoadingOverlay();
				},
				success: function(beneficiaryGroupIdentifiers) {	
					$j('#' + currentDivSection).html('');
					$j('#' + currentDivSection).html(beneficiaryGroupIdentifiers);			
					$j('#' + currentDivSection).css('display','block');
					identifierLoadStatus = 1;					
				},
				complete: function() {		
					var selectedGroupListId = selectedGroupList.split(',');				
					for( var i =0; i< selectedGroupListId.length;i++) {						
						showActiveArchivedIdentifiers(selectedGroupListId[i])
					}
					hideLoadingOverlay();
				},
				error: function() {
					alert('Oops...mistake on server');	
					hideLoadingOverlay();
				}
			});	
		}
	}
}

$j(document).on('click', '.selectallnone', function(e) {
	var currentAssociationId = $j(this).attr('attr-assoid');	
	if($j('#selectallnone_' + currentAssociationId).html() == 'Select All') {
		$j('#selectallnone_' + currentAssociationId).html('Select None');
		$j('.associationItem_' + currentAssociationId + ':visible').prop('checked',true);
	} else {
		$j('#selectallnone_' + currentAssociationId).html('Select All');
		$j('.associationItem_' + currentAssociationId + ':visible').prop('checked',false);
	}
	
	if($j('#associationFields_' + currentAssociationId + ' option:selected').val() != 0) {
		if($j('#selectallnone_' + currentAssociationId).html() == 'Select None') {
			$j('.select_all_itemsforfield_' + currentAssociationId).html('Select None');
		} else {
			$j('.select_all_itemsforfield_' + currentAssociationId).html('Select All');
		}				
	}	
	selectIdentifiersButton();
});

$j(document).on('change', '.typeofidentifier', function(e) {	
	var currentAssociationId = $j(this).attr('attr-assoid');
	showActiveArchivedIdentifiers(currentAssociationId);
	selectIdentifiersButton();
});

$j(document).on('change', '.associationItemCheckbox', function(e) {
	var currentAssociationId = $j(this).attr('attr-assoid');	
	var currentGroupIdentifierCount = $j('.associationItem_' + currentAssociationId + ':visible').length;
	var currentGroupIdentifierCheckedCount = $j('.associationItem_' + currentAssociationId + ':visible:checked').length;
	
	if(currentGroupIdentifierCount == currentGroupIdentifierCheckedCount) {
		$j("#selectallnone_" + currentAssociationId).html("Select None");
	} else {
		$j("#selectallnone_" + currentAssociationId).html("Select All");
	}
		
	if($j('#associationFields_' + currentAssociationId + ' option:selected').val() != 0) {
		var currentSelect = $j(this).attr('attr-select-index');		
		var chkCount = $j('.associationItem_' + currentAssociationId + '_' + currentSelect + ':visible').not(':checked').length;		
		if(chkCount == 0){
			$j("#select_all_itemsforfield_" + currentAssociationId + '_' + currentSelect).html("Select None");
		} else if(chkCount > 0){
			$j("#select_all_itemsforfield_" + currentAssociationId + '_' + currentSelect).html("Select All");
		}
		
	}
	selectIdentifiersButton();	
});

function selectIdentifiersButton() {	
	var associationItemVisibleCount = $j('.associationItemCheckbox:visible').length;
	var associationItemsCheckedCount = $j('.associationItemCheckbox:visible:checked').length;
	if(associationItemVisibleCount > 0 && associationItemsCheckedCount > 0) {
		$j('#btnselectidentifiers').show();
	} else {
		$j('#btnselectidentifiers').hide();
	}
}

$j(document).on('change', '.associationFields', function(e) {
	var currentAssociationId = $j(this).attr('attr-assoid');														 
	var attridVal = $j('#associationFields_' + currentAssociationId + ' option:selected').val();	
	var _current_time_cache = new Date().getTime();
	var targetURL = "index.cfm?event=survey.attributeValBasedGroupIdentifiers&associationid=" + currentAssociationId + "&currenttimestamp=" + _current_time_cache;
		
	var typeofIdentifiers = [];
	$j(".typeofidentifier_" + currentAssociationId + ":checked").each(function(){			
		typeofIdentifiers.push($j(this).val());			
	});		
	
	$j('.associationItem_' + currentAssociationId).prop('checked',false);	
	var identifierpluralalias = $j('#idenPlural_' + currentAssociationId).val();
	showLoadingOverlay();
	var dataHTML = '';
	$j.ajax({
		type: "post",
		async:true,
		dataType: "json",
		data: {attrid:attridVal},
		url: targetURL,		
		success: function(responseData) {			
			if(responseData.length > 0) {							
				if(attridVal == 0) {
					dataHTML = dataHTML + '<a href="javascript:void(0);" id="selectallnone_' + currentAssociationId + '" class="link selectallnone selectallnone_' + currentAssociationId + '" attr-assoid="' + currentAssociationId + '" style="padding-bottom:10px;">Select All</a>';
					$j.each(responseData, function(index, itemData) {												   												
						dataHTML = dataHTML + '<div class="identifiercheckbox identifiercheckbox_' + currentAssociationId + '" attr-iden-status="' + itemData.isActive + '">';						
						dataHTML = dataHTML + '<input type="checkbox" name="associationItem_' + currentAssociationId + '" class="associationItemCheckbox associationItem_' + currentAssociationId + '" value="' + itemData.assoItemId + '" attr-assoId="' + currentAssociationId + '">';						
						dataHTML = dataHTML + itemData.assoItemValue;
						dataHTML = dataHTML + '</div>';
						dataHTML = dataHTML + '<div class="clearfix"></div>';   												   						
					});				
				} else {					
					var atrVal = '';
					dataHTML = dataHTML + '<a href="javascript:void(0);" id="selectallnone_' + currentAssociationId + '" class="link selectallnone selectallnone_' + currentAssociationId + '" attr-assoid="' + currentAssociationId + '" style="padding-bottom:10px;">Select All</a>';
					dataHTML = dataHTML + '<input type="hidden" id="fieldValueCount_' + currentAssociationId + '" value="' + responseData.length + '">';					
					$j.each(responseData, function(itemValueId, itemData) {	
												   
						dataHTML = dataHTML + '<div id="assoc_itemvalue_title_' + currentAssociationId + '_' + itemValueId + '"class="assoc_itemvalue_title" style="font-weight: bold;min-height:25px;">';
						atrVal = itemData.attrVal.toString();
						if(atrVal.toUpperCase() == '"YES"' || atrVal.toUpperCase() == '"NO"' || atrVal.toUpperCase() == '"TRUE"' || atrVal.toUpperCase() == '"FALSE"' || atrVal === '"1"' || atrVal === '"0"') {
							dataHTML = dataHTML + itemData.attrVal.replace(/"/gi, "") + '</div>';
						} else {
							dataHTML = dataHTML + itemData.attrVal + '</div>';
						}
						
						dataHTML = dataHTML + '<div class="clear"></div>';
						
						if(itemData.assolist.length > 1) {
							dataHTML = dataHTML + '<div id="assoc_item_title_' + currentAssociationId + '_' + itemValueId + '" class="assoc_item assoc_item_title" style="padding-bottom:8px;"><a href="javascript:void(0);" class="select_all_itemsforfield select_all_itemsforfield_' + currentAssociationId + ' select_all_itemsforfield_' + currentAssociationId + '_' + itemValueId + '" id="select_all_itemsforfield_' + currentAssociationId + '_' + itemValueId + '" attr-select-index="' + itemValueId + '" attr-assoid="' + currentAssociationId + '">Select All</a></div>';
						}
						
						$j.each(itemData.assolist, function(index, itemDataValue) {														
							dataHTML = dataHTML + '<div class="identifiercheckbox identifiercheckbox_' + currentAssociationId + ' identifiercheckbox_' + currentAssociationId + '_' + itemValueId + '" attr-iden-status="' + itemDataValue.isActive + '" attr-select-index="' + itemValueId + '">';						
							dataHTML = dataHTML + '<input type="checkbox" name="associationItem_' + currentAssociationId + '" class="associationItemCheckbox associationItem_' + currentAssociationId + ' associationItem_' + currentAssociationId + '_' + itemValueId + '" value="' + itemDataValue.assoItemId + '" attr-assoId="' + currentAssociationId + '" attr-select-index="' + itemValueId + '">';						
							dataHTML = dataHTML + itemDataValue.assoItemValue;
							dataHTML = dataHTML + '</div>';
							dataHTML = dataHTML + '<div class="clearfix"></div>';																																																																					
						});	
						dataHTML = dataHTML + '<div id="itemvaluespace_' + currentAssociationId + '_' + itemValueId + '" style="height:25px"></div>';						
					});					
				}
				$j('#identifierListing_' + currentAssociationId).html(dataHTML);
				$j('.typeofidentifier_' + currentAssociationId).prop('checked',true);	
				$j('#identifierListing_' + currentAssociationId).show();
				$j('#checkboxIdentifierListNone_' + currentAssociationId).hide();
			} else {				
				$j('#identifierListing_' + currentAssociationId).html('<div style="margin-bottom:10px;">No ' + identifierpluralalias + ' exists.</div>');
			}
			if($j('.associationItemCheckbox:checked').length == 0) {
				$j('#btnselectidentifiers').hide();
			}
			
			if(typeofIdentifiers.length == 0) {
				$j('.typeofidentifier_' + currentAssociationId).prop('checked',false);
			} else if (typeofIdentifiers.length == 1) {
				$j('.typeofidentifier_' + currentAssociationId).each(function(){			
					if($j(this).val() == typeofIdentifiers[0]) {
						$j(this).prop('checked',true);
					} else {
						$j(this).prop('checked',false);
					}
				});
			}
			
			showActiveArchivedIdentifiers(currentAssociationId);
		},
		complete: function(data) {						
			hideLoadingOverlay();			
		},
		error: function(data) { 
			alert('oops mistake on server');
			return false; 
		}
	});			
});

$j(document).on('click', '.select_all_itemsforfield', function(e) {
	var currentAssociationId = $j(this).attr('attr-assoid');	
	var currentSelect = $j(this).attr('attr-select-index');
	if($j('#select_all_itemsforfield_' + currentAssociationId + '_' + currentSelect).html() == 'Select All') {
		$j('#select_all_itemsforfield_' + currentAssociationId + '_' + currentSelect).html('Select None');
		$j('.associationItem_' + currentAssociationId + '_' + currentSelect +':visible').prop('checked',true);
	} else {
		$j('#select_all_itemsforfield_' + currentAssociationId + '_' + currentSelect).html('Select All');
		$j('.associationItem_' + currentAssociationId + '_' + currentSelect +':visible').prop('checked',false);
	}
	
	var chkCount = $j('.associationItem_' + currentAssociationId + ':visible').not(':checked').length;		
	if(chkCount == 0){
		$j("#selectallnone_" + currentAssociationId).html("Select None");
	} else if(chkCount > 0){
		$j("#selectallnone_" + currentAssociationId).html("Select All");
	}
	
	selectIdentifiersButton();
});
 
/* End: STEP 3 | Select Group Identifiers */

/*Start Step-6 */
$j(document).on('click', '.totalWorksheets', function(e) {
	var _this = $j(this);
	var child_elem_name = _this.attr('attr-panel'); 
	var checkedValue = _this.val();	
	var selectedGroupList = formData.userSelectedGroups;	
	var associationid = selectedGroupList;
	
	if (_this.is(":checked") && checkedValue=="TF") {		
		var loadUrl="index.cfm?event=survey.getTotalProfileField";
		$j.ajax({			
			url: loadUrl,
			data : {association:associationid,checkedValue:checkedValue,startPeriod:formData.startPeriod,endPeriod:formData.endPeriod,selectedSurveysList:formData.selectedSurveysList},
			type: "POST",												
			beforeSend: function(){
					showLoadingOverlay();
			},						
			success:function(response)
			{				
				$j("#totalprofilefield").html(response);
				$j('#totalprofilefield').slideDown(700);												
			},
			complete:function()
			{
				hideLoadingOverlay();									
			},
			error :function()
			{
			  alert('error occurred!!');
			}
		});				
	} else if(_this.is(":checked")==false && checkedValue=="TF"){		
		$j('#totalprofilefield').slideUp(700);		
	}
		
	if (_this.is(":checked") && checkedValue=="IF") {		
		var loadUrl="index.cfm?event=survey.getIncludeIdentifierField";
		$j.ajax({			
			url: loadUrl,
			data : {association:associationid,checkedValue:checkedValue},
			type: "POST",												
			beforeSend: function(){
					showLoadingOverlay();
			},						
			success:function(response)
			{				
				$j("#includeIdentifierfield").html(response);	
				$j('#includeIdentifierfield').slideDown(700);
				$j('#includeIdentifierfield').css('display','block');	
				$j('#arrangepanelfields').css('display','block');				
			},
			complete:function()
			{
				hideLoadingOverlay();									
			},
			error :function()
			{
			  alert('error occurred!!');
			}
		});
		
		/* Start: For BG Shared Fields */				
		var selectedGroupIdList = selectedGroupList.split(',');
		if(selectedGroupIdList.length > 1 ) {
			var loadUrl="index.cfm?event=survey.getSharedBeneficiaryFields";
			$j.ajax({			
				url: loadUrl,
				data : {association:associationid},
				type: "POST",												
				beforeSend: function() {
						showLoadingOverlay();
				},						
				success:function(response) {
					var parseSharedFields = $j.parseJSON(response);
					var parseSharedFieldsList = parseSharedFields.data;
					var thisField;										
					var htmlSharedFields = '<div class="sharedFieldsSection"><a class="selectallsharedfields" id="selectallsharedfields">Select All</a>';
					htmlSharedFields = htmlSharedFields + '<div class="clearfix"></div><div class="sharedFieldsOptions">';
					for (var i=0; i<parseSharedFieldsList.length;i++){
						thisField = parseSharedFieldsList[i];	
						htmlSharedFields = htmlSharedFields + '<div class="sharedFieldsOptionsList sharedFieldsOptionsList_' + thisField.attributeid + '" style="margin-bottom: 5px; display:none;">';
						htmlSharedFields = htmlSharedFields + '<div class="sharedFieldCheckbox"><input id="sharedFields_' + thisField.attributeid + '" class="sharedFieldsOption sharedFieldsOption_' + thisField.attributeid + '" name="sharedFieldsOption" type="checkbox" attr-id="' + thisField.attributeid + '" value="' + thisField.attributeid + '"></div>';
						htmlSharedFields = htmlSharedFields + '<span class="sharedFieldsLbl">' + thisField.attributename + '</span>';
						htmlSharedFields = htmlSharedFields + '</div><div class="clearfix"></div>';
					}															
					htmlSharedFields = htmlSharedFields + '</div></div>';
					$j('#sharedfieldslist').html(htmlSharedFields);												
				},
				complete:function() {
					hideLoadingOverlay();									
				},
				error :function() {
				  alert('error occurred!!');
				}
			});
		}
		/* End: For BG Shared Fields */
		
	}else if(_this.is(":checked")==false && checkedValue=="IF"){			
		$j('#arrangepanelfields').css('display','none');		
		$j('#incudeIdentifier').prop('checked',false);
		$j('#includeIdentifierfield').slideUp(700);
		
		disableSharedFields();
	}
	
	if (_this.is(":checked") && checkedValue=="T") {			
		//$j("#grouptotalentireperiodbreakout").prop("disabled", false);	
		$j('#allbreakout').slideDown(700);
	}else if(_this.is(":checked")==false && checkedValue=="T"){
		//$j("#grouptotalentireperiodbreakout").prop("disabled", true);	
		$j('#grouptotalentireperiodbreakout').prop('checked',false);	
		$j('#allbreakout').slideUp(700);
	}
	
	if (_this.is(":checked") && checkedValue=="TSP") {	
		//$j("#totalperiodbreakoutsurvey").prop("disabled", false);	
		$j('#surveybreakout').slideDown(700);
	}else if(_this.is(":checked")==false && checkedValue=="TSP"){
		//$j("#totalperiodbreakoutsurvey").prop("disabled", true);	
		$j('#totalperiodbreakoutsurvey').prop('checked',false);	
		$j('#surveybreakout').slideUp(700);
	}
	
	if (_this.is(":checked") && checkedValue=="TP") {	
		//$j("#totalperiodbreakout").prop("disabled", false);	
		$j("#totalbreakout").slideDown(700);
	}else if(_this.is(":checked")==false && checkedValue=="TP"){
		//$j("#totalperiodbreakout").prop("disabled", true);	
		$j('#totalperiodbreakout').prop('checked',false);	
		$j("#totalbreakout").slideUp(700);
	}
		
	if(($j('#grouptotalentireperiod').is(":checked") || $j('#totalperiod').is(":checked") || $j('#totalsurveyperiod').is(":checked")) && $j('#includeIdentifierFields').val() != '0') {		//|| $j('#totalmatrixview').is(":checked")
		$j('#incudeIdentifier').prop('disabled',false);
	} else {
		$j('.assoattributeindvalue_field').prop('checked',false);
		$j('#includeIdentifierfield').css('display','none');	
		$j('#arrangepanelfields').css('display','none');		
		$j('#incudeIdentifier').prop('checked',false);
		$j('#incudeIdentifier').prop('disabled',true);
		
		disableSharedFields();		
	}
	
});
$j(document).on('change', '#groupincude_total', function(e) {  		
	if ($j(this).is(":checked")) {		
		$j('#grouptotaloptionsinclude').slideDown(700);	
		$j("#totalperiodbreakout").prop("checked", false);	
	} else {
		$j('#grouptotaloptionsinclude').slideUp(700);
		$j('#grouptotalentireperiod').prop('checked',false);
		//$j("#grouptotalentireperiodbreakout").prop("disabled", true);	
		$j('#grouptotalentireperiodbreakout').prop('checked',false);
		$j('#allbreakout').slideUp(700);
		$j('#totalperiod').prop('checked',false);
		$j('#totalBreakoutMember').prop('checked',false);
		//$j('#allBreakoutMember').prop('checked',false);
		$j('#ProfileField').prop('checked',false);
		$j("#ProfileField").prop("disabled", false);			
		$j('#incudeIdentifier').prop('checked',false);
		$j('.assoattributeindvalue_field').prop('checked',false);
		$j('#incudeIdentifier').prop('disabled',true);
		$j('#totalprofilefield').css('display','none');
		$j('#includeIdentifierfield').css('display','none');
		$j('#arrangepanelfields').css('display','none');
		//$j("#totalperiodbreakout").prop("disabled", true);
		$j("#totalperiodbreakout").prop("checked", false);
		$j("#totalbreakout").slideUp(700);
		$j("#totalsurveyperiod").prop("checked", false);
		$j("#totalperiodbreakoutsurvey").prop("checked", false);
		$j("#totalmatrixview").prop("checked", false);
		$j("#surveybreakout").slideUp(700);
		disableSharedFields();
	}													
});

$j(document).on('change', '#edit_groupincude_total', function(e) {  		
	if ($j(this).is(":checked")) {		
		$j('#edit_grouptotaloptionsinclude').slideDown(700);		
	} else {
		$j('#edit_grouptotaloptionsinclude').slideUp(700);
		$j('#edit_grouptotalentireperiod').prop('checked',false);
		$j('#edit_grouptotalentireperiodbreakout').prop('checked',false);
		//$j("#edit_grouptotalentireperiodbreakout").prop("disabled", true);	
		$j('#edit_allbreakout').slideUp(700);
		$j('#edit_totalperiod').prop('checked',false);
		$j('#edit_totalperiodbreakout').prop('checked',false);
		//$j("#edit_totalperiodbreakout").prop("disabled", true);	
		$j('#edit_totalbreakout').slideUp(700);
		$j('#edit_totalperiodbreakoutSurvey').prop('checked',false);
		$j('#edit_totalperiodSurvey').prop('checked',false);
		$j('#edit_totalmatrixview').prop('checked',false);
		//$j("#edit_totalperiodbreakoutSurvey").prop("disabled", true);
		$j('#edit_surveybreakout').slideUp(700);
		$j('.edit_attributeindvalue').prop('checked',false);
		$j('#edit_totalprofilefield').css('display','none');
		$j('#edit_ProfileField').prop('checked',false);				
		$j('.edit_assoattributeindvalue_field').prop('checked',false);
		$j('#edit_includeIdentifierfield').css('display','none');
		$j('#edit_arrangepanelfields').css('display','none');
		$j('#edit_incude_total').prop('checked',false);		
		$j('#edit_incude_total').prop('disabled',true);		
		$j('#totalprofilefield').css('display','none');
		$j('#includeIdentifierfield').css('display','none');				
		edit_disableSharedFields()				
	}													
});

$j(document).on('click', 'input[type="checkbox"][name="groupProfileType"]', function(e) {	
	var panelTypeId = $j(this).attr('attr-id');	
	var _this = $j(this);	
	if ($j(this).is(":checked")) {
		_this.parent().siblings('.groupProfileArrow,.groupIdentifierArrow').removeClass("showarrow");
		_this.parent().siblings('.groupProfileArrow,.groupIdentifierArrow').addClass("hidearrow");	
		$j('#' + panelTypeId + 'List').css('display','block');		
		$j('#' + panelTypeId + 'List').slideDown(700);		
	} else {		
		$j('#' + panelTypeId + 'List').find('input[type=checkbox]').prop('checked',false);
		$j('#' + panelTypeId + 'List').find('.innerselall').html('Select All');			
		_this.parent().siblings('.groupProfileArrow,.groupIdentifierArrow').removeClass("hidearrow");
		_this.parent().siblings('.groupProfileArrow,.groupIdentifierArrow').addClass("showarrow");				
		$j('#' + panelTypeId + 'List').slideUp(700);	
		$j('#selectProfileFields').html('Select All');
	}
});

$j(document).on('click', '.groupProfileArrow', function(e) {
	var _this = $j(this);
	var child_elem_name = _this.attr('attr-panel'); 
	var child_elem_divid = child_elem_name + 'List'; 
	if (_this.hasClass('showarrow')) {		
		_this.removeClass("showarrow");
		_this.addClass("hidearrow");
		_this.siblings('#'+child_elem_divid).slideToggle(700);	
		$j('#' + child_elem_name).prop('checked',true);	
		$j('#' + child_elem_divid).css('display','block');
		$j('.groupIdentifierPanelList').css('display','block');
	} else {		
		_this.removeClass("hidearrow");
		_this.addClass("showarrow");
		_this.siblings('#'+child_elem_divid).slideUp(700);		
		//$j('#' + child_elem_name).prop('checked',false);						
	}
});
$j(document).on('click', '.groupIdentifierArrow', function(e) {
	var _this = $j(this);
	var child_elem_name = _this.attr('attr-panel'); 
	var child_elem_divid = child_elem_name + 'List'; 
	if (_this.hasClass('showarrow')) {		
		_this.removeClass("showarrow");
		_this.addClass("hidearrow");
		_this.siblings('#'+child_elem_divid).slideToggle(700);	
		$j('#' + child_elem_name).prop('checked',true);	
		$j('#' + child_elem_divid).css('display','block');
		$j('.groupIdentifierPanelList').css('display','block');
	} else {		
		_this.removeClass("hidearrow");
		_this.addClass("showarrow");
		_this.siblings('#'+child_elem_divid).slideUp(700);		
		//$j('#' + child_elem_name).prop('checked',false);						
	}
});
$j(document).on('click', '#selectProfileFields', function(e) {
	if($j('#selectProfileFields').html() == 'Select All') {
		$j('#selectProfileFields').html('Select None');
		$j('.innerselall').html('Select None');
		$j('.groupProfileType').prop('checked',true);
		$j('.attributeindvalue').prop('checked',true);		
		if($j('.groupProfileArrow').hasClass('showarrow')) {
			$j('.groupProfileArrow').removeClass('showarrow').addClass('hidearrow');
		}
	//	if($j('.standardPanelList').css('display') == 'none') {
			$j('.standardPanelList').css('display','block');	
			$j('.standardPanelList').slideDown(700);
			//$j('#selectProfileFields').html('Select None');
		//}								
	} else {
		$j('#selectProfileFields').html('Select All');
		$j('.innerselall').html('Select All');
		$j('.groupProfileType').prop('checked',false);
		$j('.attributeindvalue').prop('checked',false);
		
		if($j('.groupProfileArrow').hasClass('hidearrow')) {
			$j('.groupProfileArrow').removeClass('hidearrow').addClass('showarrow');
		}
		//if($j('.standardPanelList').css('display') == 'block') {
			$j('.standardPanelList').css('display','none');	
			$j('.standardPanelList').slideUp(700);
			//$j('#selectProfileFields').html('Select All');
		//}				
	}
});

function SetSurveyExportOption(obj) {
	checkSession();
	if($j(obj).is('div'))
		var buttonText = $j(obj).text().trim().toLowerCase();
	else	
		var buttonText = $j(obj).val().trim().toLowerCase();					
	
	if(buttonText == 'set') {				
		var totalsWorksheetIncluded = [];		
		var rawDataIncluded = "No";
		var groupFieldsIncluded = "No";
		var identifierFieldsIncluded = "No";
		var includedWorksheets = [];
		var associationProfileFieldList = [];
		var associationIdentifierStdFieldList = [];
		var associationIdentifierUsrFieldList = [];
		var associationIdentifierFieldList = [];
		var assSharedFieldList = [];
		var arrangeby = "";
		var rawDataSelectedColumns = [];
		var reportId = "";
		var reportName = "";
				
		if($j('input[type=radio][name=view_excel_saved_selection]:checked').val() == 'excelcustomizeselection') {
			
			if($j('#groupincude_total').prop('checked') == false && $j('#include_raw_questions').prop('checked') == false) {
				alert('Please select atleast one sheet to include in the export.');
				return false;
			}
			/*if (document.getElementById('groupincude_total').checked && $j('#grouptotalentireperiod').prop('checked') == false && $j('#totalperiod').prop('checked') == false && $j('#totalsurveyperiod').prop('checked') == false && $j('#ProfileField').prop('checked') == false) {
                		alert('In the Pre-formatted Sheets section, please either uncheck the Pre-formatted Sheets box or select one of the options in that section.');
                		return false;
            		}

            		if (document.getElementById('groupincude_total').checked && $j('#grouptotalentireperiod').prop('checked') == true && $j('#grouptotalentireperiodbreakout').prop('checked') == false) {
                		alert(' Please either uncheck the Quantifiable Totals for the Entire Period Sheets box or select one of the options in that section.');
                		return false;
            		}

            		if (document.getElementById('groupincude_total').checked && $j('#totalperiod').prop('checked') == true && $j('#totalperiodbreakout').prop('checked') == false) {
                		alert(' Please either uncheck the Data Grouped by Question Sheets box or select one of the options in that section.');
                		return false;
            		}

            		if (document.getElementById('groupincude_total').checked && $j('#totalsurveyperiod').prop('checked') == true && $j('#totalperiodbreakoutsurvey').prop('checked') == false) {
                		alert(' Please either uncheck the Data Grouped by Reporting & Reflection Log Period Sheets box or select one of the options in that section.');
                		return false;
            		}
			if (document.getElementById('groupincude_total').checked && $j('#grouptotalentireperiod').prop('checked') == false && $j('#ProfileField').prop('checked') == false) {
                		alert(' Please either uncheck the Quantifiable Totals for the Entire Period Sheets box or select one of the options in that section.');
                		return false;
            		}*/
			if (document.getElementById('groupincude_total').checked && $j('input[type="checkbox"][class="totalWorksheets"]:checked').length == 0) {
                		alert('In the Pre-formatted Sheets section, please either uncheck the Pre-formatted Sheets box or select one of the options in that section.');
                		return false;
            		}
			if($j('#groupincude_total').prop('checked') == false && $j('#include_raw_questions').prop('checked') == true && $j("#sel_column_excel option").length == 0) {				
				alert('Please select atleast one Raw Data column.');
				return false;
			}
			
			if($j('#grouptotalentireperiod').prop('checked') == false && $j('#totalperiod').prop('checked') == false && $j('#totalsurveyperiod').prop('checked') == false && $j('#totalmatrixview').prop('checked') == false && $j('#ProfileField').prop('checked') == true && $j('input.attributeindvalue:checked').length == 0) {				
				alert('In the Profile Fields: please either uncheck the Profile Fields box or select one of the options in that section.');
				return false;
			}
			
			if(document.getElementById('groupincude_total').checked && $j('#grouptotalentireperiod').prop('checked') == false && $j('#totalperiod').prop('checked') == false && $j('#totalsurveyperiod').prop('checked') == false && $j('#totalmatrixview').prop('checked') == false && $j('#ProfileField').prop('checked') == false) {
				alert('In the Pre-formatted Sheets section, please either uncheck the Pre-formatted Sheets box or select one of the options in that section.');
				return false;
			}
			
			var confirmationMsg = "";			
			if($j('#ProfileField').is(":checked") && $j('input.attributeindvalue:checked').length == 0 ) {
				confirmationMsg = "Profile Fields: Fields were not selected, so none will be included in the export.";
			}
			if($j('#incudeIdentifier').is(":checked") && $j('input.assoattributeindvalue_field:checked').length == 0 ) {
				confirmationMsg = confirmationMsg + "\n" +  "Identifier Fields: Fields were not selected, so none will be included in the export.";
			}
			if($j('#sharedfields').is(":checked") && $j('input.sharedFieldsOption:visible:checked').length == 0 ) {
				confirmationMsg = confirmationMsg + "\n" +  "Shared Fields: Fields were not selected, so seperate columns will be created in the export.";
			}
			if($j('#include_raw_questions').is(":checked") && document.getElementById("sel_column_excel").options.length == 0) {
				confirmationMsg = confirmationMsg + "\n" +  "Raw Data: Columns were not selected, so no raw data will be included in the export.";
			}
			
			var userResponse = true;
			if(confirmationMsg != '') {
				userResponse = confirm(confirmationMsg);
			}
			
			if(userResponse) {
				
				if($j('#grouptotalentireperiod').is(":checked") || $j('#totalperiod').is(":checked") || $j('#totalsurveyperiod').is(":checked") || $j('#totalmatrixview').is(":checked")) {					
					if($j('#grouptotalentireperiod').is(":checked")) {
						includedWorksheets.push($j('#grouptotalentireperiod').val());
						totalsWorksheetIncluded.push('Quantifiable Totals for the Entire Period');						
					}
					if($j('#grouptotalentireperiodbreakout').is(":checked")){						
						includedWorksheets.push($j('#grouptotalentireperiodbreakout').val());					
					}
					if($j('#totalperiod').is(":checked")) {
						includedWorksheets.push($j('#totalperiod').val());
						totalsWorksheetIncluded.push('Data Grouped by Question');
					}
					if($j('#totalperiodbreakout').is(":checked")){
						includedWorksheets.push($j('#totalperiodbreakout').val());						
					}
					if($j('#totalsurveyperiod').is(":checked")) {
						includedWorksheets.push($j('#totalsurveyperiod').val());
						totalsWorksheetIncluded.push('Data Grouped by ' + surveyalias + ' Period');
					}
					if($j('#totalperiodbreakoutsurvey').is(":checked")){
						includedWorksheets.push($j('#totalperiodbreakoutsurvey').val());						
					}
					
					if($j('#totalmatrixview').is(":checked")) {
						includedWorksheets.push($j('#totalmatrixview').val());
						totalsWorksheetIncluded.push('Matrix True View');
					}
					
					totalsWorksheetIncluded = totalsWorksheetIncluded.toString();
					if($j('#grouptotalentireperiodbreakout').is(":checked") || $j('#totalperiodbreakout').is(":checked") || $j('#totalperiodbreakoutsurvey').is(":checked")){		
						totalsWorksheetIncluded = totalsWorksheetIncluded + " (With Breakouts by " + volunteerAlias + ")";
					}					
				}								
				
				if($j('#include_raw_questions').is(":checked")) {										
					var rawDataColumns = document.getElementById("sel_column_excel");		
					for (var i = 0; i < rawDataColumns.length; i++) {			
						rawDataSelectedColumns.push(rawDataColumns.options[i].value);												
					}
				}	
				
				if($j('#include_raw_questions').is(":checked") && rawDataSelectedColumns.length > 0) {
					includedWorksheets.push($j('#include_raw_questions').val());
					if($j('#include_zero_values').is(":checked")) {
						includedWorksheets.push($j('#include_zero_values').val());
					}
					rawDataIncluded = "Yes";					
				}
				
				if($j('#include_raw_questions').prop('checked') == true && rawDataIncluded == "No") {					
					$j('#include_raw_questions').trigger('click');
				}
				
						
				var assProfileFieldList='';
				if($j('#ProfileField').is(":checked")){
					$j('input[type=checkbox][class=groupProfileType]:checked').each(function(index,element) {
						var assoAttrRel = $j(this).attr('attr-id');
						var assoAttrId = $j(this).val();
						var assoProArr='';									
						//$j('#'+assoAttrRel+'List'+' input[type=checkbox][class=attributeindvalue]:checked').each(function(index,element) {
						$j('#'+assoAttrRel+'List'+' input.attributeindvalue[type=checkbox]:checked').each(function(index,element) {
							var assoProfileFieldVal= $j(this).val().trim();
							if(assoProArr!='')
								assoProArr=assoProArr+'^'+assoProfileFieldVal;	
							else
								assoProArr=assoProfileFieldVal;	
							
							groupFieldsIncluded = "Yes";
						});				
						if(assoProArr !=''){
							if(assProfileFieldList.length){
								assProfileFieldList=assProfileFieldList+'~'+assoAttrId+"_"+assoProArr;	
							} else {							
								assProfileFieldList=assoAttrId+"_"+assoProArr;	
							}
						}							
					});
					if(assProfileFieldList.length){
						includedWorksheets.push($j('#ProfileField').val());
						if(totalsWorksheetIncluded == '') {
							totalsWorksheetIncluded = 'Totals by Identifier Fields';
						} else {
							totalsWorksheetIncluded = totalsWorksheetIncluded + '; Totals by Identifier Fields';
						}
					}					
					associationProfileFieldList.push(assProfileFieldList);										
				}
				
				var assIdentifierFieldList='';
				var assIdentifierStdFieldList='';
				var assIdentifierUsrFieldList='';
				if($j('#incudeIdentifier').is(":checked")){
					$j('input[type=checkbox][class=groupIdentifierType]:checked').each(function(index,element) {
						var assoAttrRel = $j(this).attr('attr-id');
						var assoAttrId = $j(this).val();
						var assoIdentifierArr='';
						var assoIdentifierStdArr = '';
						var assoIdentifierUsrArr = '';
						//$j('#'+assoAttrRel+'List'+' input[type=checkbox][class=assoattributeindvalue_field]:checked').each(function(index,element) {
						$j('#'+assoAttrRel+'List'+' input.assoattributeindvalue_field[type=checkbox]:checked').each(function(index,element) {
							var assoIdentifierFieldVal= $j(this).val().trim();
							if(assoIdentifierArr!='')
								assoIdentifierArr=assoIdentifierArr+','+assoIdentifierFieldVal;	//^ -> ,
							else
								assoIdentifierArr=assoIdentifierFieldVal;
							
							/* Start: Code to seperate Standrad Fields & UserFields List */
							if(assoIdentifierFieldVal == 'Group' || assoIdentifierFieldVal == 'Status' || assoIdentifierFieldVal == 'CreatedOn' || assoIdentifierFieldVal == 'AssignedTo' || assoIdentifierFieldVal == 'PreviousAssignment') {
								if(assoIdentifierStdArr!='')
									assoIdentifierStdArr=assoIdentifierStdArr+','+assoIdentifierFieldVal;	//^ -> ,
								else
									assoIdentifierStdArr=assoIdentifierFieldVal;								
							} else {
								if(assoIdentifierUsrArr!='')
									assoIdentifierUsrArr=assoIdentifierUsrArr+','+assoIdentifierFieldVal;	//^ -> ,
								else
									assoIdentifierUsrArr=assoIdentifierFieldVal;
							}
							/* End: Code to seperate Standrad Fields & UserFields List */
							identifierFieldsIncluded = "Yes";
						});
						
						if(assoIdentifierArr !='') {
							if(assIdentifierFieldList.length){
								assIdentifierFieldList=assIdentifierFieldList+'~'+assoAttrId+"_"+assoIdentifierArr;	
							} else {						
								assIdentifierFieldList=assoAttrId+"_"+assoIdentifierArr;	
							}
							
							/* Start: Code to seperate Standrad Fields & UserFields List */
							if(assoIdentifierStdArr !='') {
								if(assIdentifierStdFieldList.length){
									assIdentifierStdFieldList=assIdentifierStdFieldList+'~'+assoAttrId+"_"+assoIdentifierStdArr;	
								} else {						
									assIdentifierStdFieldList=assoAttrId+"_"+assoIdentifierStdArr;	
								}
							}
							
							if(assoIdentifierUsrArr !='') {
								if(assIdentifierUsrFieldList.length){
									assIdentifierUsrFieldList=assIdentifierUsrFieldList+'~'+assoAttrId+"_"+assoIdentifierUsrArr;	
								} else {						
									assIdentifierUsrFieldList=assoAttrId+"_"+assoIdentifierUsrArr;	
								}
							}
							/* End: Code to seperate Standrad Fields & UserFields List */
						}
						
					});	
					if(assIdentifierFieldList.length) {
						includedWorksheets.push($j('#incudeIdentifier').val());
					}					
					associationIdentifierFieldList.push(assIdentifierFieldList);
					associationIdentifierStdFieldList.push(assIdentifierStdFieldList);
					associationIdentifierUsrFieldList.push(assIdentifierUsrFieldList);
				}				
								
				/*$j('input[type=checkbox][class=assoattributeindvalue_field]:checked').each(function(index,element) {
					var assoIdentifierFieldId = $j(this).val();
					associationIdentifierFieldList.push(assoIdentifierFieldId);			
				});*/
				if($j('input.assoattributeindvalue_field:checked').length) {
					arrangeby = $j('input[type=radio][name=arrangeFieldsRadio]:checked').val();	
				}
								
				if($j('#sharedfields').is(":checked")){
					$j('input.sharedFieldsOption:visible:checked').each(function(index,element) {
						var assoFieldId = $j(this).attr('attr-id');
						assSharedFieldList.push(assoFieldId);
					});
					if(assSharedFieldList.length) {
						includedWorksheets.push($j('#sharedfields').val());
					}
				}													
				
				includedWorksheets = includedWorksheets.toString();	
																										
				if($j('#save_selection_excel_text').val().trim() != '') {
					var ExportType = 'excel';
					var ExportNameID = 'save_selection_excel_text';	
					var chkContainerID = 'ExportAvailableTable';
					var Scope = document.getElementById("scope").value.trim();
					var action = "Create";
					var associationtype = 1;
					if(!checkExportNameAvailability(ExportType,ExportNameID,chkContainerID,Scope,associationtype,action))
						return false;											
				} 
								
				if(totalsWorksheetIncluded == '') {
					totalsWorksheetIncluded = 'No';
				}
				totalsWorksheetIncluded = totalsWorksheetIncluded.replace(/,/g,'; ');
				$j("#lblTotalWorksheetSelected").html(totalsWorksheetIncluded);	
				$j("#lblVolunteerFieldsSelected").html(groupFieldsIncluded);
				$j("#lblIdentifierFieldsSelected").html(identifierFieldsIncluded);
				$j("#lblRawDataSelected").html(rawDataIncluded);
												
				$j("#exportOptionSummary").show();
				$j("#exportOptionSummaryLbl").show();
				$j("#editcheckstep6").css('padding-top','25px');
				$j("#exportOptionSavedSelectionSummaryLbl").hide();	
				
				$j("#exportOptionSelections").hide();
				$j("#btnselectexportoptions").hide();
				$j("#editcheckstep6").show();		
				formData.setStep6 = 1;				
			}
		} else {
			if($j("input[type=radio][name=radio_ExportIDSelection]:checked").length) {
				reportId = $j("input[type=radio][name=radio_ExportIDSelection]:checked").attr('attr-report-id');
				reportName = $j("#savedSelectionReportName_" + reportId).html();
				
				associationProfileFieldList = associationProfileFieldList.toString();
				associationIdentifierFieldList = associationIdentifierFieldList.toString();
				
				includedWorksheets = $j("input[type=radio][name=radio_ExportIDSelection]:checked").attr('attr-worksheet');				
				associationProfileFieldList = $j("input[type=radio][name=radio_ExportIDSelection]:checked").attr('attr-profilefields');
				associationIdentifierFieldList = $j("input[type=radio][name=radio_ExportIDSelection]:checked").attr('attr-identifierfields');
				arrangeby = $j("input[type=radio][name=radio_ExportIDSelection]:checked").attr('attr-arrangeby');
				rawDataSelectedColumns = $j("input[type=radio][name=radio_ExportIDSelection]:checked").attr('attr-rawcolumns');
				assSharedFieldList = $j("input[type=radio][name=radio_ExportIDSelection]:checked").attr('attr-sharedfieldid');	
				
				/* Start: Code to seperate Standrad Fields & UserFields List */				
				associationIdentifierFieldList = associationIdentifierFieldList.toString().replace(/"/g, "");
				if(associationIdentifierFieldList != '') {
					var assIdentifierStdFieldList='';
					var assIdentifierUsrFieldList='';
					var assAllFieldDetails = associationIdentifierFieldList.split('~');					
					for (var i=0; i<assAllFieldDetails.length;i++) {
						var assoIdentifierStdArr = "";
						var assoIdentifierUsrArr = "";
						var assoAttrDetails = assAllFieldDetails[i].split('_');
						var assoId = assoAttrDetails[0];
						var assoAttrId = assoAttrDetails[1];
						var assoAttrIdArr = assoAttrId.split(','); 
						for (var j=0;j<assoAttrIdArr.length;j++) {
							var attrId = assoAttrIdArr[j];
							if(attrId == 'Group' || attrId == 'Status' || attrId == 'CreatedOn' || attrId == 'AssignedTo' || attrId == 'PreviousAssignment') {
								if(assoIdentifierStdArr!='')
									assoIdentifierStdArr=assoIdentifierStdArr+','+attrId;	//^ -> ,
								else
									assoIdentifierStdArr=attrId;								
							} else {
								if(assoIdentifierUsrArr!='')
									assoIdentifierUsrArr=assoIdentifierUsrArr+','+attrId;	//^ -> ,
								else
									assoIdentifierUsrArr=attrId;
							}							
						}						
						if(assoIdentifierStdArr !='') {
							if(assIdentifierStdFieldList.length){
								assIdentifierStdFieldList=assIdentifierStdFieldList+'~'+assoId+"_"+assoIdentifierStdArr;	
							} else {						
								assIdentifierStdFieldList=assoId+"_"+assoIdentifierStdArr;	
							}
						}
						
						if(assoIdentifierUsrArr !='') {
							if(assIdentifierUsrFieldList.length){
								assIdentifierUsrFieldList=assIdentifierUsrFieldList+'~'+assoId+"_"+assoIdentifierUsrArr;	
							} else {						
								assIdentifierUsrFieldList=assoId+"_"+assoIdentifierUsrArr;	
							}
						}						
					}
					associationIdentifierStdFieldList.push(assIdentifierStdFieldList);
					associationIdentifierUsrFieldList.push(assIdentifierUsrFieldList);
				}
				/* End: Code to seperate Standrad Fields & UserFields List */
				
				$j("#lblSavedSectionSelected").html(reportName);
				$j("#exportOptionSavedSelectionSummaryLbl").show();
				$j("#editcheckstep6").css('padding-top','0px');
				$j("#exportOptionSummary").show();
				$j("#exportOptionSummaryLbl").hide();
				
				$j("#exportOptionSelections").hide();
				$j("#btnselectexportoptions").hide();
				$j("#editcheckstep6").show();		
				formData.setStep6 = 1;
			}
		}
		
		if($j('#hdn_submitted_steps').val() == '5'){
			$j('#hdn_submitted_steps').attr('value','6');
		}
		var $sections = $j('div.panelhead');		
		var index = 6;		
		$j($sections[5]).next('div.contentBodyPanel').addClass('setDiv');		
		if (typeof($accordion) == 'object') {
			if ($accordion.accordion( "option", "active" ) != index) {
				$accordion.accordion({active:index});
			} else {
				hideLoadingOverlay();
			}
		}		
		_step6editCounter = 1;
		formData.includedWorksheets = includedWorksheets.toString();	
		formData.selectedattributevalueidlist = associationProfileFieldList.toString(); //key associationProfileFieldList change selectedattributevalueidlist
		formData.identifierFieldList = associationIdentifierFieldList.toString();
		formData.identifierStdFieldList = associationIdentifierStdFieldList.toString();
		formData.identifierUsrFieldList = associationIdentifierUsrFieldList.toString();
		formData.sharedFields = assSharedFieldList.toString();	
		formData.arrangeby = arrangeby;
		formData.rawDataSelectedColumns = rawDataSelectedColumns.toString();
		var accor_div = $j(obj).closest('div.contentBodyPanel').prev('div.panelhead')[0];		
		setSectionIcon(accor_div, 'set');		
	} else {
		$j('#exportOptionSelections').show();
		$j("#btnselectexportoptions").show();		
		$j("#exportOptionSummary").hide();		
		$j("#editcheckstep6").hide();		
		formData.setStep6 = 0;
		_step6editCounter = 1;
		var accor_div = $j(obj).closest('div.contentBodyPanel').prev('div.panelhead')[0];
		setSectionIcon(accor_div, 'edit');
	}
	showhideExportExcelButton();	
}

function saveSurveyExportOptions() {	
	var ExportType = 'excel';
	var ExportNameID = 'save_selection_excel_text';	
	var chkContainerID = 'ExportAvailableTable';
	var Scope = document.getElementById("scope").value.trim();
	var action = "Create";
	var associationtype = 1;				
	var includedWorksheets = formData.includedWorksheets;			
	var associationProfileFieldList = formData.selectedattributevalueidlist; //associationProfileFieldList key change selectedattributevalueidlist
	var associationIdentifierFieldList = formData.identifierFieldList; //associationIdentifierFieldList key change identifierFieldList
	var arrangeby = formData.arrangeby;
	var rawDataSelectedColumns = formData.rawDataSelectedColumns;
	var associationList = $j("input[type=hidden][name='hdn_bg-selected']").val();
	var SavedSelectionExportId = 0;
	var exportOptionName = $j('#save_selection_excel_text').val();				
	var availableTo = 'owner';
	var availableIdList = $j("#currentUserId").val();
	var sharedFieldIdList = formData.sharedFields;	
	var checkboxselection1 = "";
	var checkboxselection2 = "";
	var checkboxselection3 = "";
	var checkboxselection4 = "";
	var checkboxselection5 = "";	
	if($j('#exportSavedOptionAvl').val()) {
		availableTo = $j("input[name=savedoptionavailable]:checked").val();
	}
			
	if(availableTo == 'staffroles') {
		availableIdList = $j("input[type=checkbox][name=staffroleoption]:checked").map(function() {return this.value;}).get().join(',');
	}
			
	/*if ($j('#check_excel_saved_report_1').prop("checked") == true) {
		checkboxselection1 = $j('#check_excel_saved_report_1').val();
	}
				
	if ($j('#check_excel_saved_report_2').prop("checked") == true) {
		checkboxselection2 = $j('#check_excel_saved_report_2').val();
	}
				
	if ($j('#check_excel_saved_report_3').prop("checked") == true) {
		checkboxselection3 = $j('#check_excel_saved_report_3').val();
	}
				
	if ($j('#check_excel_saved_report_4').prop("checked") == true) {
		checkboxselection4 = $j('#check_excel_saved_report_4').val();
	}
	
	if ($j('#check_excel_saved_report_5').prop("checked") == true) {
		checkboxselection5 = $j('#check_excel_saved_report_5').val();
	}*/
	
	var omitFieldIdList = "";
	if($j('#ProfileField').is(":checked")) {
		var omitArray = [];
		var includeArray = [];
		$j('input.attributeindvalue:checkbox:not(:checked)').each(function () {
		inputName = $j(this).attr('name').split('_')[1];
		if($j.inArray( inputName, omitArray ) === -1)
				omitArray.push( inputName );
		});
		$j('input.attributeindvalue:checkbox:checked').each(function () {
		inputName = $j(this).attr('name').split('_')[1];
		if($j.inArray( inputName, includeArray ) === -1)
				includeArray.push( inputName );
		});
		var diffArray = $j(omitArray).not(includeArray).get();					
		var diffArrayList = diffArray.join(",");
		var omitListAttributeList = diffArray.join(",");
		var includeListAttributeList = includeArray.join(",");					
		omitListAttributeList = omitArray.join(",");
		omitFieldIdList = omitListAttributeList.toString();	
	}
						
	var url = "/index.cfm?event=survey.saveSurveyExportOptions";																		
	new Ajax.Request(url,{
					method: 'post',
					parameters: {scope: Scope,edit_save_selection_text: exportOptionName,associationProfileFieldList:associationProfileFieldList,arrangeFieldsBy:arrangeby,associationIdentifierFieldList:associationIdentifierFieldList,edit_selected_columns:rawDataSelectedColumns,availableTo:availableTo,availableIdList:availableIdList,SheetsIncluded:includedWorksheets,exportType:ExportType,SavedSelectionExportId:SavedSelectionExportId,associationtype:associationtype,associationList:associationList,sharedFieldIdList:sharedFieldIdList,omitFieldIdList:omitFieldIdList},
		onSuccess: function(returnHtml){							
			if($j('#rad_saved_views_excel').attr('disabled') == 'disabled') {
				$j('#rad_saved_views_excel').attr('disabled',false);
				$j('#savedexportoption').css('color','rgb(0, 0, 0)');
			}
		},
		onFailure: function(){
			alert('Oops...mistake on server');
		}
	});			
}
function ExcelSelection(SelectionType,Popup,exporttype,associationtype,currentReportId) {
	showLoadingOverlay();
	if (SelectionType == "excelsavedselection") {
		$j('#rad_saved_views_excel').prop('disabled',true); 
		$j('#rad_customize_views_excel').prop('disabled',true);
		$j('#rad_customize_views_excel').prop('checked',false);	
		if(Popup == 0){
			document.getElementById("img_loaderexcelsaved").style.display = "block";
			if ($j('#SavedSelectionExcel').css('display') == 'none') {		
				$j('#SavedSelectionExcel').slideDown(700);			
				if ($j('#customize_section_excel').css('display') == 'block'){
					$j('#customize_section_excel').slideUp(700);
				}
			
			} else {
				$j('#SavedSelectionExcel').slideUp(700);
			}
		} 
		document.getElementById("img_loaderexcelsaved").style.display = "none";		
		var scopePassed = document.getElementById("scope").value;		
		new Ajax.Request("/index.cfm?event=survey.getallsavedselectionsexport",{
			method: 'post',
			parameters: {scope:'association', exporttype:exporttype, associationtype:associationtype,groupSelected:formData.userSelectedGroups},
			onSuccess: function(returnHtml) {
				Element.update("SavedSelectionExcel", returnHtml.responseText); 
				//selectedCheckBox = document.getElementById("hdn_SelectdReportRadioEx").value;				
				var chkbxs = document.getElementsByName('radio_ExportIDSelection');			
				for(var i = 0; i < chkbxs.length; i++){				
					if(chkbxs[i].getAttribute("attr-report-id") == currentReportId){
						chkbxs[i].checked = true;
						break;
					}
				}
			}, 
			onComplete:	function() {
				if($j('.savedSelectionReportDetails').find('input[type=radio][name=radio_ExportIDSelection]').length == 0) {					
					if($j('#SavedSelectionExcel').css('display') == 'block') {
						$j('#SavedSelectionExcel').css('display','none')
					}
					$j('#savedexportoption').css('color','#999999');
					$j('#rad_saved_views_excel').prop('disabled',true); 
					$j('#rad_saved_views_excel').prop('checked',false);
					$j('#btnselectexportoptions').hide();
				}
			},
			onFailure: function() { 
				alert('Oops...mistake on server');
			} 
		}); 
		$j('#rad_saved_views_excel').prop('disabled',false);
		$j('#rad_customize_views_excel').prop('disabled',false);			
	} else if (SelectionType == "excelcustomizeselection") {
		$j('#rad_customize_views_excel').prop('disabled',true); 
		$j('#rad_saved_views_excel').prop('disabled',true); 
		$j('#rad_saved_views_excel').prop('checked',false);		 
		document.getElementById("img_loaderexcelcustomize").style.display = "block";		
		if ($j('#customize_section_excel').css('display') == 'none') {		
			$j('#customize_section_excel').slideDown(700);		
			if ($j('#SavedSelectionExcel').css('display') == 'block'){
				$j('#SavedSelectionExcel').slideUp(700);
			}		
		} else {
			$j('#customize_section_excel').slideUp(700);
		}
		document.getElementById("img_loaderexcelcustomize").style.display = "none";
	}			
	
	var selectedGroupList = formData.userSelectedGroups;				
	var savedSelectionBGIds = $j('#savedSelectionBeneficiaryGroup').val();				
	if($j('#SavedSelectionAvailable').val() == 1 && savedSelectionBGIds.indexOf(selectedGroupList) != -1 && $j('#savedexportoption').css('color') == 'rgb(51, 51, 51)') {
		$j('#rad_saved_views_excel').prop('disabled',false);
	}			
	if($j('input[name="view_excel_saved_selection"]:checked').length && $j('#btnselectexportoptions').css('display') == 'none') {
		document.getElementById("btnselectexportoptions").style.display = "block";
	}
	$j('#rad_customize_views_excel').prop('disabled',false); 
	hideLoadingOverlay();
}

function EditSurveySelectionExport(SavedSelectionID,passedScope,associationtype) {
	var action = 'edit';	
	var startPeriod = formData.startPeriod; // SURVEXPORT-387
	var endPeriod = formData.endPeriod;  // SURVEXPORT-387
	var selectedGroupList = formData.userSelectedGroups;	
	$j.ajax({
		url: root + 'survey.savedAssociationselectionexport',
		data : {SavedSelectionID:SavedSelectionID,passedscope:passedScope,associationtype:associationtype,association:selectedGroupList,action:action,startPeriod:startPeriod,endPeriod:endPeriod},
		type: "post",
		beforeSend: function(){	
			showLoadingOverlay();
	 	},
		success: function (data) {   
			$dialog.editSavedSelectionExport.html('');
			$dialog.editSavedSelectionExport.dialog('open').html(data);			
			$j('.editSavedSelectionExport').addClass('export-option-popup-ui');
			showhidematrixviewcheckbox();
		},
		complete:function() {
			hideLoadingOverlay();
		},
		error :function() {
			alert('error occurred!!');
		}
	});	
}

function ConfirmExportDeletion(scopePassed,programID,SavedSelectionExportId,SavedSelectionExportName,exportType,associationtype) {	

	var reportNameUnformated = SavedSelectionExportName;	
	SavedSelectionExportName = reportNameUnformated.replace(/`~`/g, '\"');
	SavedSelectionExportName = SavedSelectionExportName.replace(/`~~`/g, "\'");	
	
	if (SavedSelectionExportId == 0) 	{
		var userSelection = true;
	} else {
		var dialogMessage = "Are you sure that you want to delete the saved export called \"" + SavedSelectionExportName+ "\"?\n\n";
		dialogMessage = dialogMessage + "Deleting this saved export will not delete any "+ surveyalias + " data.";
		var userSelection = confirm(dialogMessage);
	}
   	
	if (userSelection) {
		new Ajax.Request("/index.cfm?event=survey.deletesurveyselectionexportid&SavedSelectionExportId="+SavedSelectionExportId,{
			onSuccess: function(returnHtml) {							
				ExcelSelection('excelsavedselection',1,exportType,associationtype,0);				
			},
			onFailure: function() {
				alert('Oops...mistake on server');
			}
		});
	}   
}

function checkexportEditValidation(associationtype) {
	
	var action = $j('#btnUpdateExportDetails').val();
	var ExportType = document.getElementById("exportType").value;
	var ExportNameID = 'edit_save_selection_text';	
	var chkContainerID = 'ExportAvailableTableEdit';
	var Scope = document.getElementById("scope").value.trim();
	var associationList = $j('#edit_groupidlist').val();
	/*var checkboxselection1 = 0;
	var checkboxselection2 = 0;
	var checkboxselection3 = 0;
	var checkboxselection4 = 0;
	var checkboxselection5 = 0;*/
	
	var validationMsg = '';
	if (document.getElementById("edit_save_selection_text").value.trim() == '') {
		validationMsg = "Please give a name for the export.\n";
	}
	
	if($j('#edit_groupincude_total').prop('checked') == false && $j('#edit_include_raw_questions').prop('checked') == false) {
		validationMsg = validationMsg + "Please select atleast one sheet to include in the export.\n";		
	}
	
	if($j('#edit_groupincude_total').prop('checked') == false && $j('#edit_include_raw_questions').prop('checked') == true && $j("#edit_sel_column option").length == 0) {				
		validationMsg = validationMsg + "Please select atleast one Raw Data column.";		
	}
					
	if(document.getElementById('edit_groupincude_total').checked && $j('#edit_grouptotalentireperiod').prop("checked") == false && $j('#edit_totalperiod').prop("checked") == false && $j('#edit_totalperiodSurvey').prop("checked") == false && $j('#edit_ProfileField').prop("checked") == false && $j('#edit_totalmatrixview').prop("checked") == false) {
		validationMsg = validationMsg + "\n" + "In the Pre-formatted Sheets section, please either uncheck the Pre-formatted Sheets box or select one of the options in that section.";
	}
	
	if($j('#edit_grouptotalentireperiod').prop('checked') == false && $j('#edit_totalperiod').prop('checked') == false && $j('#edit_totalperiodSurvey').prop('checked') == false && $j('#edit_ProfileField').prop('checked') == true && $j('input.edit_attributeindvalue:checked').length == 0) {				
		validationMsg = validationMsg + "\n" + "In the Profile Fields: please either uncheck the Profile Fields box or select one of the options in that section.";		
	}
	
	if(validationMsg != '') {
		alert(validationMsg);
		return false;
	}	
	
		
	if(!checkExportNameAvailability(ExportType,ExportNameID,chkContainerID,Scope,associationtype,action))
		return false;
	
	
	var obj = document.getElementById("edit_sel_column");
	for (var i=0; i<obj.options.length; i++) {
		obj.options[i].selected = true;
    	}
	
	var confirmationMsg = "";	
	if($j('#edit_ProfileField').is(":checked") && $j('input.edit_attributeindvalue:checked').length == 0) {
		confirmationMsg = " Profile Fields: Fields were not selected, so none will be included in the export.";
	}
	if($j('#edit_incude_total').is(":checked") && $j('input.edit_assoattributeindvalue_field:checked').length == 0) {
		confirmationMsg = confirmationMsg + "\n" +  "Identifier Fields: Fields were not selected, so none will be included in the export.";
	}
	if($j('#edit_sharedfields').is(":checked") && $j('input.edit_sharedFieldsOption:visible:checked').length == 0 ) {
		confirmationMsg = confirmationMsg + "\n" +  "Shared Fields: Fields were not selected, so seperate columns will be created in the export.";
	}
	if($j('#edit_include_raw_questions').is(":checked") && document.getElementById("edit_sel_column").options.length == 0) {
		confirmationMsg = confirmationMsg + "\n" +  "Raw Data: Columns were not selected, so no raw data will be included in the export.";
	}	
	
	var userResponse = true;
	if(confirmationMsg != '') {
		userResponse = confirm(confirmationMsg);
	}
	var arr_sheets = [];
		if($j('#edit_grouptotalentireperiod').is(":checked") || $j('#edit_totalperiod').is(":checked") || $j('#edit_totalperiodSurvey').is(":checked") || $j('#edit_totalmatrixview').is(":checked")) {			
			if($j('#edit_grouptotalentireperiod').is(":checked")) {
				arr_sheets.push($j('#edit_grouptotalentireperiod').val());
			}
			if($j('#edit_grouptotalentireperiodbreakout').is(":checked")){
				arr_sheets.push($j('#edit_grouptotalentireperiodbreakout').val());						
			}
			if($j('#edit_totalperiod').is(":checked")) {
				arr_sheets.push($j('#edit_totalperiod').val());
			}
			if($j('#edit_totalperiodbreakout').is(":checked")){
				arr_sheets.push($j('#edit_totalperiodbreakout').val());						
			}
			if($j('#edit_totalperiodSurvey').is(":checked")) {
				arr_sheets.push($j('#edit_totalperiodSurvey').val());
			}
			if($j('#edit_totalperiodbreakoutSurvey').is(":checked")){
				arr_sheets.push($j('#edit_totalperiodbreakoutSurvey').val());						
			}
			if($j('#edit_totalmatrixview').is(":checked")){
				arr_sheets.push($j('#edit_totalmatrixview').val());						
			}
			
		}
	
		var assProfileFieldList='';
		var arrangeFieldsBy = "";
		var assIdentifierFieldList='';
		var associationIdentifierFieldList=[];
		var associationProfileFieldList=[];
		
		if($j('#edit_ProfileField').is(":checked")){
			$j('input.edit_groupProfileType:checked').each(function(index,element) {
				var assoAttrRel = $j(this).attr('attr-id');
				var assoAttrId = $j(this).val();
				var assoProArr='';									
				$j('#'+assoAttrRel+'List'+' input.edit_attributeindvalue:checked').each(function(index,element) {
					var assoProfileFieldVal= $j(this).val().trim();
					if(assoProArr!='')
						assoProArr=assoProArr+'^'+assoProfileFieldVal;	
					else
						assoProArr=assoProfileFieldVal;	
				});
				if(assoProArr !=''){
					if(assProfileFieldList.length)
						assProfileFieldList=assProfileFieldList+'~'+assoAttrId+"_"+assoProArr;	
					else
						assProfileFieldList=assoAttrId+"_"+assoProArr;
				}
			
			});		
			if(assProfileFieldList.length){
				arr_sheets.push($j('#edit_ProfileField').val());
			}	
			associationProfileFieldList.push(assProfileFieldList);
		}	
		
		if($j('#edit_incude_total').is(":checked")){
		
			$j('input.edit_groupIdentifierType:checked').each(function(index,element) {
				var assoAttrRel = $j(this).attr('attr-id');
				var assoAttrId = $j(this).val();
				var assoIdentifierArr='';									
				$j('#'+assoAttrRel+'List'+' input.edit_assoattributeindvalue_field:checked').each(function(index,element) {
					var assoIdentifierFieldVal= $j(this).val().trim();
					if(assoIdentifierArr!='')
						assoIdentifierArr=assoIdentifierArr+','+assoIdentifierFieldVal;	
					else
						assoIdentifierArr=assoIdentifierFieldVal;	
				});
				if(assoIdentifierArr !=''){
					if(assIdentifierFieldList.length)
						assIdentifierFieldList=assIdentifierFieldList+'~'+assoAttrId+"_"+assoIdentifierArr;	
					else
						assIdentifierFieldList=assoAttrId+"_"+assoIdentifierArr;
				}
			});	
			if(assIdentifierFieldList.length) {
				arr_sheets.push($j('#edit_incude_total').val());
			}	
			associationIdentifierFieldList.push(assIdentifierFieldList);
		}
		
		if($j('input.edit_assoattributeindvalue_field:checked').length) {
			arrangeFieldsBy = $j('input[type=radio][name=edit_arrangeFieldsRadio]:checked').val();	
		}
		
		var sharedFieldIdList = [];
		if($j('#edit_sharedfields').is(":checked")){
			$j('input.edit_sharedFieldsOption:visible:checked').each(function(index,element) {
				var assoFieldId = $j(this).attr('attr-id');
				sharedFieldIdList.push(assoFieldId);
			});
			if(sharedFieldIdList.length) {
				arr_sheets.push($j('#edit_sharedfields').val());
			}
		}
		sharedFieldIdList = sharedFieldIdList.toString();
		
		var edit_selected_columns_selected = [];
		if (document.getElementById('edit_include_raw_questions').checked) {			 			
			edit_selected_columns = document.getElementById("edit_sel_column");			
			for (var i = 0; i < edit_selected_columns.length; i++) {
				if (edit_selected_columns.options[i].selected) 
				edit_selected_columns_selected.push(edit_selected_columns.options[i].value);
			} 
			
		}
		
		if(document.getElementById('edit_include_raw_questions').checked && edit_selected_columns_selected.length > 0) {
			 var include_raw_questions = document.getElementById('edit_include_raw_questions').value;
			 arr_sheets.push(include_raw_questions);
			 if (document.getElementById('edit_include_zero_values').checked) {				
				var include_zero_values = document.getElementById('edit_include_zero_values').value;
				arr_sheets.push(include_zero_values);
			}			
		}
		
		var availableTo = 'owner';
		if($j('#exportSavedOptionAvl').val()) {
			availableTo = $j("input[name=edit_savedoptionavailable]:checked").val();
		}
		var availableIdList = "";
		if(availableTo == 'staffroles') {
			availableIdList = $j("input[type=checkbox][name=staffroleoption]:checked").map(function() {return this.value;}).get().join(',');
		} else if (availableTo == 'owner') {
			availableIdList = $j("#currentUserId").val();
		}
		
	if (userResponse) {		
		var scopePassed = document.getElementById("scope").value;
		var edit_save_selection_text = document.getElementById("edit_save_selection_text").value;		
		var edit_selected_columns = "";		
	
		exportType = document.getElementById("exportType").value;
			
		
		
		arr_sheets = arr_sheets.toString();
		associationIdentifierFieldList = associationIdentifierFieldList.toString();
		associationProfileFieldList = associationProfileFieldList.toString();
		edit_selected_columns = edit_selected_columns_selected.toString();
		
		document.getElementById("SheetsIncluded").value = arr_sheets;		
	
		SheetsIncluded = document.getElementById("SheetsIncluded").value;
	
		SavedSelectionExportId = document.getElementById("SavedSelectionExportId").value;
	
		/*if ($j('.optioncheckpanel #excel_saved_report_1').prop("checked") == true) {
			checkboxselection1 = $j('.optioncheckpanel #excel_saved_report_1').val();
		}
					
		if ($j('.optioncheckpanel #excel_saved_report_2').prop("checked") == true) {
			checkboxselection2 = $j('.optioncheckpanel #excel_saved_report_2').val();
		}
					
		if ($j('.optioncheckpanel #excel_saved_report_3').prop("checked") == true) {
			checkboxselection3 = $j('.optioncheckpanel #excel_saved_report_3').val();
		}
					
		if ($j('.optioncheckpanel #excel_saved_report_4').prop("checked") == true) {
			checkboxselection4 = $j('.optioncheckpanel #excel_saved_report_4').val();
		}
		if ($j('.optioncheckpanel #excel_saved_report_5').prop("checked") == true) {
			checkboxselection5 = $j('.optioncheckpanel #excel_saved_report_5').val();
		}*/
		
		var omitFieldIdList = "";
		if($j('#edit_ProfileField').is(":checked")) {
			var omitArray = [];
			var includeArray = [];
			$j('input.edit_attributeindvalue:checkbox:not(:checked)').each(function () {
			inputName = $j(this).attr('name').split('_')[1];
			if($j.inArray( inputName, omitArray ) === -1)
					omitArray.push( inputName );
			});
			$j('input.edit_attributeindvalue:checkbox:checked').each(function () {
			inputName = $j(this).attr('name').split('_')[1];
			if($j.inArray( inputName, includeArray ) === -1)
					includeArray.push( inputName );
			});
			var diffArray = $j(omitArray).not(includeArray).get();					
			var diffArrayList = diffArray.join(",");
			var omitListAttributeList = diffArray.join(",");
			var includeListAttributeList = includeArray.join(",");					
			omitListAttributeList = omitArray.join(",");
			omitFieldIdList = omitListAttributeList.toString();	
		}
		
		var savedOptionId = "";
		if(action == 'Edit') {
			var url = "/index.cfm?event=survey.updateSavedSurveyExport";
		} else {
			var url = "/index.cfm?event=survey.saveSurveyExportOptions";
			//SavedSelectionExportId = 0;
		}
		new Ajax.Request(url,{
						method: 'post',
						parameters: {action:action,scope: scopePassed,edit_save_selection_text: edit_save_selection_text,associationProfileFieldList:associationProfileFieldList,arrangeFieldsBy:arrangeFieldsBy,associationIdentifierFieldList:associationIdentifierFieldList,edit_selected_columns:edit_selected_columns,availableTo:availableTo,availableIdList:availableIdList,SheetsIncluded:SheetsIncluded,exportType:exportType,SavedSelectionExportId:SavedSelectionExportId,associationtype:associationtype,associationList:associationList,sharedFieldIdList:sharedFieldIdList,omitFieldIdList:omitFieldIdList},
			onSuccess: function(response){
				savedOptionId = response.responseText;
				ExcelSelection('excelsavedselection',1,exportType,associationtype,savedOptionId);								
				$j("#closeDialog").click(); 				
			},
			onFailure: function(){
				alert('Oops...mistake on server');
			}
		});				
	}
	
}

function CloneSurveySelectionExport(SavedSelectionID,passedScope,associationtype) {				
	var action = 'clone';
	var selectedGroupList = formData.userSelectedGroups;	
	var startPeriod = formData.startPeriod; // SURVEXPORT-387
	var endPeriod = formData.endPeriod;  // SURVEXPORT-387
	$j.ajax({
		url: root + 'survey.savedAssociationselectionexport',
		data : {SavedSelectionID:SavedSelectionID,passedscope:passedScope,associationtype:associationtype,association:selectedGroupList,action:action,startPeriod:startPeriod,endPeriod:endPeriod},
		type: "post",
		beforeSend: function(){	
			showLoadingOverlay();
	 	},
		success: function (data) {    
			$dialog.cloneSavedSelectionExport.html('');
			$dialog.cloneSavedSelectionExport.dialog('open').html(data);			
			$j('.cloneSavedSelectionExport').addClass('export-option-popup-ui');
			showhidematrixviewcheckbox();
		},
		complete:function() {
			hideLoadingOverlay();
		},
		error :function() {
			alert('error occurred!!');
		}
	});						
}

$j(document).on('change', '.attributeindvalue', function(e) {
	var rel = $j(this).attr('rel');	
	toggleSelectProfieldFields(rel);	
});

function toggleSelectProfieldFields (rel) {
	var perticularFieldsCount = 	$j('#'+rel+ ' input.attributeindvalue').length ;
	var perticularFieldsCheckedCount = 	$j('#'+rel+ ' input.attributeindvalue:checked').length ;
	var totalFieldsCount = 	$j('input.attributeindvalue').length ;
	var totalFieldsCheckedCount = 	$j('input.attributeindvalue:checked').length ;	
	if(perticularFieldsCount == perticularFieldsCheckedCount) {
		$j('#'+rel).find('.innerselall').html('Select None');
	} else {
		$j('#'+rel).find('.innerselall').html('Select All');
		$j('#selectProfileFields').html('Select All');
	}
	if(totalFieldsCount == totalFieldsCheckedCount) {
		$j('#selectProfileFields').html('Select None');
	} else {		
		$j('#selectProfileFields').html('Select All');
	}
}

$j(document).on('click', '.innerselall', function(e) {	
	thisRelvar = $j(this).attr('rel');
	thisTextvar = $j(this).text();	
	if(thisTextvar.trim() == 'Select All'){
		$j('#'+thisRelvar).find('.attributeindvalue').prop('checked',true);		
		$j(this).text('Select None');		
	}else{
		$j('#'+thisRelvar).find('.attributeindvalue').prop('checked',false);		
		$j(this).text('Select All');		  
	}
	setTimeout(function(){ 
		var totalFieldsCount = 	$j('input.attributeindvalue').length ;
		var totalFieldsCheckedCount = 	$j('input.attributeindvalue:checked').length ;			
		if(totalFieldsCount == totalFieldsCheckedCount) {
			$j('#selectProfileFields').html('Select None');
		} else {		
			$j('#selectProfileFields').html('Select All');
		}	
	}, 100);
	
});

/* SURVEXPORT-236:S */
$j(document).on('click', '.innerselall-2', function(e) {	
	thisRelvar = $j(this).attr('rel');
	thisTextvar = $j(this).text();	
	if(thisTextvar.trim() == 'Select All'){
		//$j('input.assoattributeindvalue_field[rel='+thisRelvar+']').prop('checked',true);
		$j('#'+thisRelvar+'_section').find('.groupIdentifierSubpanelAttribute').css('display','block')
		$j('#'+thisRelvar+'_section.groupIdentifierPanelAttribute input[type=checkbox]:visible').prop('checked',true);
		$j('#'+thisRelvar+'_section').find('a.selectall').text('Select None');
		$j(this).text('Select None');	
		enableSharedFields();
	}else{
		//$j('input.assoattributeindvalue_field[rel='+thisRelvar+']').prop('checked',false);
		$j('#'+thisRelvar+'_section.groupIdentifierPanelAttribute input[type=checkbox]:visible').prop('checked',false);
		$j('#'+thisRelvar+'_section').find('.groupIdentifierSubpanelAttribute').css('display','none');
		$j('#'+thisRelvar+'_section').find('a.selectall').text('Select All');
		$j(this).text('Select All');
		enableSharedFields();
	}

	setTimeout(function(){
		var totalFieldsCount = 	$j('#'+thisRelvar+'_section').closest('div.panelfieldoption').find('input[type=checkbox]:visible').length
		var totalFieldsCheckedCount = 	$j('#'+thisRelvar+'_section').closest('div.panelfieldoption').find('input[type=checkbox]:visible:checked').length;
		if(totalFieldsCount == totalFieldsCheckedCount) {
			$j('#'+thisRelvar+'_section').closest('div.panelfieldoption').find('a.outerselall-2').html('Select None');
		} else {
			$j('#'+thisRelvar+'_section').closest('div.panelfieldoption').find('a.outerselall-2').html('Select All');
		}	
	}, 100);
	
});

$j(document).on('click', '.innerselall-sp', function(e) {	
	thisRelvar = $j(this).attr('rel');
	thisTextvar = $j(this).text();	
	if(thisTextvar.trim() == 'Select All'){
		$j('#'+thisRelvar+'_section input.assoattributeindvalue_field[type=checkbox][rel='+thisRelvar+']:visible').prop('checked',true);
		$j('#'+thisRelvar+'_section').closest('div.groupIdentifierPanelAttribute').find('a.innerselall-2').html('Select None');
		$j(this).text('Select None');
		enableSharedFields();
	}else{		
		$j('#'+thisRelvar+'_section input.assoattributeindvalue_field[type=checkbox][rel='+thisRelvar+']:visible').prop('checked',false);
		$j('#'+thisRelvar+'_section').closest('div.groupIdentifierPanelAttribute').find('a.innerselall-2').html('Select All');
		$j(this).text('Select All');	
		enableSharedFields();
	}

	setTimeout(function(){
		var totalFieldsCount = 	$j('#'+thisRelvar+'_section').closest('div.panelfieldoption').find('input[type=checkbox]:visible').length
		var totalFieldsCheckedCount = 	$j('#'+thisRelvar+'_section').closest('div.panelfieldoption').find('input[type=checkbox]:visible:checked').length;
		if(totalFieldsCount == totalFieldsCheckedCount) {
			$j('#'+thisRelvar+'_section').closest('div.panelfieldoption').find('a.outerselall-2').html('Select None');
		} else {
			$j('#'+thisRelvar+'_section').closest('div.panelfieldoption').find('a.outerselall-2').html('Select All');
		}	
	}, 100);
	
});

$j(document).on('click', '.outerselall-2', function(e) {
	thisRelvar = $j(this).attr('rel');
	thisTextvar = $j(this).text();
	if(thisTextvar.trim() == 'Select All'){
		$j('#'+thisRelvar).find('.groupIdentifierSubpanelAttribute').css('display','block');
		$j('#'+thisRelvar).find('div.groupIdentifierPanelAttribute').css('display','block');
		$j('#'+thisRelvar).find('div.groupIdentifierSubpanelAttribute').css('display','block');
		$j('#'+thisRelvar+'.assoattributedeatils input[type=checkbox]:visible').prop('checked',true);
		$j('#'+thisRelvar).find('a.selectall').text('Select None');
		$j(this).text('Select None');
		enableSharedFields();
	}else{
		$j('#'+thisRelvar+'.assoattributedeatils input[type=checkbox]:visible').prop('checked',false);
		$j('#'+thisRelvar).find('.groupIdentifierSubpanelAttribute').css('display','none');
		$j('#'+thisRelvar).find('div.groupIdentifierPanelAttribute').css('display','none');
		$j('#'+thisRelvar).find('div.groupIdentifierSubpanelAttribute').css('display','none');
		$j('#'+thisRelvar).find('a.selectall').text('Select All');
		$j(this).text('Select All');
		enableSharedFields();
	}
});

/* FOR EDIT/CLONE POP-START */
$j(document).on('click', '.edit_innerselall-2', function(e) {	
	var thisRelvar = $j(this).attr('rel');
	thisTextvar = $j(this).text();	
	if(thisTextvar.trim() == 'Select All'){
		//$j('input.assoattributeindvalue_field[rel='+thisRelvar+']').prop('checked',true);
		$j('#'+thisRelvar+'_Section').find('.groupIdentifierSubpanelAttribute').css('display','block')
		$j('#'+thisRelvar+'_Section input[type=checkbox]:visible').prop('checked',true);
		$j(this).text('Select None');	
		edit_enableSharedFields();
	}else{
		//$j('input.assoattributeindvalue_field[rel='+thisRelvar+']').prop('checked',false);
		$j('#'+thisRelvar+'_Section input[type=checkbox]:visible').prop('checked',false);
		$j('#'+thisRelvar+'_Section').find('.groupIdentifierSubpanelAttribute').css('display','none');
		$j(this).text('Select All');		
		edit_enableSharedFields();
	}

	setTimeout(function(){
		var totalFieldsCount = 	$j('#'+thisRelvar+'_Section').closest('div.panelfieldoption').find('input[type=checkbox]:visible').length
		var totalFieldsCheckedCount = 	$j('#'+thisRelvar+'_Section').closest('div.panelfieldoption').find('input[type=checkbox]:visible:checked').length;
		if(totalFieldsCount == totalFieldsCheckedCount) {
			$j('#'+thisRelvar+'_Section').closest('div.panelfieldoption').find('a.edit_outerselall-2').html('Select None');
		} else {
			$j('#'+thisRelvar+'_Section').closest('div.panelfieldoption').find('a.edit_outerselall-2').html('Select All');
		}	
	}, 100);
	
});

$j(document).on('click', '.edit_innerselall-psp', function(e) {	
	thisRelvar = $j(this).attr('rel');
	thisTextvar = $j(this).text();	
	if(thisTextvar.trim() == 'Select All'){
		$j('#edit'+thisRelvar+'_Section').find('.groupIdentifierSubpanelAttribute').css('display','block');
		$j('#edit'+thisRelvar+'_Section input[type=checkbox]:visible').prop('checked',true); //input[type=checkbox][rel='+thisRelvar+']:visible
		$j('#edit'+thisRelvar+'_Section').find('a.selectall').text('Select None');
		$j(this).text('Select None');	
		edit_enableSharedFields();
	}else{		
		$j('#edit'+thisRelvar+'_Section input[type=checkbox]:visible').prop('checked',false); //input[type=checkbox][rel='+thisRelvar+']:visible
		$j('#edit'+thisRelvar+'_Section').find('.groupIdentifierSubpanelAttribute').css('display','none');
		$j('#edit'+thisRelvar+'_Section').find('a.selectall').text('Select All');		
		$j(this).text('Select All');	
		edit_enableSharedFields();
	}

	setTimeout(function(){
		var totalFieldsCount = $j('#edit'+thisRelvar+'_Section').closest('div.panelfieldoption').find('input[type=checkbox]:visible').length
		var totalFieldsCheckedCount = $j('#edit'+thisRelvar+'_Section').closest('div.panelfieldoption').find('input[type=checkbox]:visible:checked').length;
		if(totalFieldsCount == totalFieldsCheckedCount) {
			$j('#edit'+thisRelvar+'_Section').closest('div.panelfieldoption').find('a.edit_outerselall-2').html('Select None');
		} else {
			$j('#edit'+thisRelvar+'_Section').closest('div.panelfieldoption').find('a.edit_outerselall-2').html('Select All');
		}	
	}, 100);
	
});

$j(document).on('click', '.edit_outerselall-2', function(e) {
	thisRelvar = $j(this).attr('rel');
	thisTextvar = $j(this).text();
	if(thisTextvar.trim() == 'Select All'){
		$j('#'+thisRelvar+'List').find('.groupIdentifierSubpanelAttribute').css('display','block');
		$j('#'+thisRelvar+'List').find('div.groupIdentifierPanelAttribute').css('display','block');
		$j('#'+thisRelvar+'List').find('div.groupIdentifierSubpanelAttribute').css('display','block');
		$j('#'+thisRelvar+'List input[type=checkbox]:visible').prop('checked',true);
		$j('#'+thisRelvar+'List').find('a.selectall').text('Select None');
		$j(this).text('Select None');
		edit_enableSharedFields();
	}else{
		$j('#'+thisRelvar+'List input[type=checkbox]:visible').prop('checked',false);
		$j('#'+thisRelvar+'List').find('.groupIdentifierSubpanelAttribute').css('display','none');
		$j('#'+thisRelvar+'List').find('div.groupIdentifierPanelAttribute').css('display','none');
		$j('#'+thisRelvar+'List').find('div.groupIdentifierSubpanelAttribute').css('display','none');
		$j('#'+thisRelvar+'List').find('a.selectall').text('Select All');
		$j(this).text('Select All');
		edit_enableSharedFields();
	}
});
/* FOR EDIT/CLONE POP-END */

function toggleInnerSelectIdentifierFields (thisRelvar,checkedvalue) {
	console.log('start: '+thisRelvar);	
	var $select_div = $j('#'+thisRelvar+'_section'); /* groupIdentifierPanelAttribute .children('div.groupIdentifierList') */
	/* if ($select_div.length == 0) {} */
	var totalFieldsCount1 = $select_div.find('input[type=checkbox]:visible').length
    if (totalFieldsCount1 == 0) {
    	$select_div = $j('#'+thisRelvar+'_section').closest('div.groupIdentifierPanelAttribute');
        totalFieldsCount1 = $select_div.find('input[type=checkbox]:visible').length;
    }
	var totalFieldsCheckedCount1 = $select_div.find('input[type=checkbox]:visible:checked').length
    var $select_anchr = $j('#'+thisRelvar+'_section').find('a.innerselall-2');
    if ($select_anchr.length == 0) {
    	$select_anchr = $j('#'+thisRelvar+'_section').find('a.innerselall-sp');
    	var $select_anchr2 = $j('#'+thisRelvar+'_section').closest('div.groupIdentifierPanelAttribute').find('a.innerselall-2');
	    if ($select_anchr2.length) {
    	    $select_anchr.push($select_anchr2[0]);
        }
    }
	if(totalFieldsCount1 == totalFieldsCheckedCount1) {
		$select_anchr.html('Select None');
	} else {
		$select_anchr.html('Select All');
	}

	var totalFieldsCount = 	$j('#'+thisRelvar+'_section').closest('div.panelfieldoption').find('input[type=checkbox]:visible').length
	var totalFieldsCheckedCount = 	$j('#'+thisRelvar+'_section').closest('div.panelfieldoption').find('input[type=checkbox]:visible:checked').length;
	if(totalFieldsCount == totalFieldsCheckedCount) {
		$j('#'+thisRelvar+'_section').closest('div.panelfieldoption').find('a.outerselall-2').html('Select None');
	} else {
		$j('#'+thisRelvar+'_section').closest('div.panelfieldoption').find('a.outerselall-2').html('Select All');
		$j('#editSelectIdentifierFields').html('Select All');	
	}	
	console.log('End');
}

function edittoggleInnerSelectIdentifierFields (thisRelvar,checkedvalue) {
	console.log('start: '+thisRelvar);
	var $div = $j('#edit'+thisRelvar+'_Section');
	if (thisRelvar.indexOf('assoattributedeatils') >= 0){
		var n_rel = thisRelvar.substr(0,thisRelvar.indexOf('_'));
		if (n_rel == 'assoattributedeatils'){
            $div = $j('#'+thisRelvar+'_Section');
		}
	}

	var $select_anchr = $div.find('a.edit_innerselall-2');
    if ($select_anchr.length == 0) {
    	$select_anchr = $div.closest('div.groupIdentifierPanelAttribute').find('a.edit_innerselall-psp');
    	var $select_anchr2 = $div.closest('div.groupIdentifierPanelAttribute').find('a.edit_innerselall-2');
	    if ($select_anchr2.length) {
    	    $select_anchr.push($select_anchr2[0]);
        }
    }
	var totalFieldsCount1 = $div.find('input[type=checkbox]:visible').length; //[rel='+thisRelvar+']
	var totalFieldsCheckedCount1 = $div.find('input[type=checkbox]:visible:checked').length; //[rel='+thisRelvar+']
	if(totalFieldsCount1 == totalFieldsCheckedCount1) {
		$select_anchr.html('Select None');
	} else {
		$select_anchr.html('Select All');
	}

	var totalFieldsCount = 	$div.closest('div.panelfieldoption').find('input[type=checkbox]:visible').length
	var totalFieldsCheckedCount = 	$div.closest('div.panelfieldoption').find('input[type=checkbox]:visible:checked').length;
	if(totalFieldsCount == totalFieldsCheckedCount) {
		$div.closest('div.panelfieldoption').find('a.edit_outerselall-2').html('Select None');
	} else {
		$div.closest('div.panelfieldoption').find('a.edit_outerselall-2').html('Select All');
		$j('#editSelectIdentifierFields').html('Select All');
	}	
	console.log('End');
}

/* SURVEXPORT-236:E */

$j(document).on('change', '.assoattributeindvalue_field', function(e) {
	var rel = $j(this).attr('rel');	
	var checkedvalue=$j(this).prop("checked");
	toggleSelectIdentifierFields(rel,checkedvalue);	
	toggleInnerSelectIdentifierFields (rel,checkedvalue); //DD
	/* Start: Code to display Selected Shared Fields */
	var selectedGroupList = formData.userSelectedGroups;
	var selectedGroupIdList = selectedGroupList.split(',');
	if(selectedGroupIdList.length > 1 ) {
		enableSharedFields();
		/*var fieldId = $j(this).val();
		var checkFieldIdCount = $j('.assoattributeindvalue_field_' + fieldId +':checked').length;
		var sharedfieldsavl = 0;
		if(selectedGroupIdList.length === checkFieldIdCount) {
			if($j('#sharedfields').prop('disabled') == true) {
				$j('#sharedfields').prop('disabled',false);
			}
			$j('.sharedFieldsOptionsList_' + fieldId).css('display','block');
			$j('#selectallsharedfields').html('Select All');
			sharedfieldsavl = parseInt($j('#sharedfieldsavl').val());
			sharedfieldsavl = sharedfieldsavl + 1;
			$j('#sharedfieldsavl').val(sharedfieldsavl);
		} else {			
			$j('.sharedFieldsOption_' + fieldId).prop('checked',false);
			$j('.sharedFieldsOptionsList_' + fieldId).css('display','none');
			if ($j('#sharedfields').prop('disabled') == false) {
				sharedfieldsavl = parseInt($j('#sharedfieldsavl').val());
				sharedfieldsavl = sharedfieldsavl - 1;
				$j('#sharedfieldsavl').val(sharedfieldsavl);
				if(sharedfieldsavl == 0) {
					$j('#sharedfieldslist').css('display','none');
					$j('.sharedFieldsOption').prop('checked',false);
					$j('#sharedfields').prop('checked',false);
					$j('#sharedfields').prop('disabled',true);				
				}
			}			
		}
		if($j('.sharedFieldsOptionsList:visible').length > 1) {
			$j('#selectallsharedfields').css('display','block');	
		} else {
			$j('#selectallsharedfields').css('display','none');
		}*/
	}
	/* End: Code to display Selected Shared Fields */
});
function toggleSelectIdentifierFields (rel,checkedvalue) {	
	var perticularFieldsCount = 	$j('.assoattributedeatils').find('input.assoattributeindvalue_field').length ;
	var perticularFieldsCheckedCount = 	$j('.assoattributedeatils').find('input.assoattributeindvalue_field:checked').length ;	
	if(perticularFieldsCount == perticularFieldsCheckedCount) {
		$j('#selectIdentifierFields').html('Select None');
	} else {		
		$j('#selectIdentifierFields').html('Select All');
	}	
}
$j(document).on('click', '#selectIdentifierFields', function(e) {
	if($j('#selectIdentifierFields').html() == 'Select All') {
		$j('#selectIdentifierFields').html('Select None');
		$j('a.innerselall-2').html('Select None');
		$j('a.innerselall-sp').html('Select None');
		$j('a.outerselall-2').html('Select None');
		$j('a.outerselall-2').css('display','block');	
		$j('.groupIdentifierPanelList').css('display','block');	
		$j('.assoattributedeatils').css('display','block');	
		$j('.groupIdentifierPanelAttribute').css('display','block');	
		$j('.groupIdentifierSubpanelAttribute').css('display','block');
		$j('.assoattributedeatils').slideDown(700);				
		$j('.groupIdentifierType').prop('checked',true);
		$j('.assoattributeindvalue_panel').prop('checked',true);	
		$j('.assoattributeindvalue_field').prop('checked',true);
		$j('.assoattributeindvalue_subpanel').prop('checked',true);
		$j('.assoattributeindvalue_userpanel').prop('checked',true);
		$j('.assoattributeindvalue_usersubpanel').prop('checked',true);	
		if($j('.groupIdentifierArrow').hasClass('showarrow')) {
			$j('.groupIdentifierArrow').removeClass('showarrow').addClass('hidearrow');
		}	
		enableSharedFields();
	} else {
		$j('#selectIdentifierFields').html('Select All');
		$j('a.innerselall-2').html('Select All');
		$j('a.innerselall-sp').html('Select All');
		$j('a.outerselall-2').html('Select All');
		$j('a.outerselall-2').css('display','none');		
		$j('.assoattributedeatils').css('display','none');	
		$j('.assoattributedeatils').slideUp(700);
		$j('.groupIdentifierPanelList').css('display','none');	
		$j('.groupIdentifierPanelAttribute').css('display','none');	
		$j('.groupIdentifierSubpanelAttribute').css('display','none');		
		$j('.groupIdentifierType').prop('checked',false);
		$j('.assoattributeindvalue_panel').prop('checked',false);
		$j('.assoattributeindvalue_field').prop('checked',false);	
		$j('.assoattributeindvalue_subpanel').prop('checked',false);
		$j('.assoattributeindvalue_userpanel').prop('checked',false);
		$j('.assoattributeindvalue_usersubpanel').prop('checked',false);
		if($j('.groupIdentifierArrow').hasClass('hidearrow')) {
			$j('.groupIdentifierArrow').removeClass('hidearrow').addClass('showarrow');
		}	
		disableSharedFields();
	}
});
$j(document).on('click', 'input[type="checkbox"][name="groupIdentifierType"]', function(e) {	
	var panelTypeId = $j(this).attr('attr-id');	
	var _this = $j(this);	
	if ($j(this).is(":checked")) {
		$j('#' + panelTypeId + 'List').css('display','block');
		$j('#' + panelTypeId + 'List').slideDown(700);	
		$j('.groupIdentifierPanelList').css('display','block');
		var arrowId=$j(this).parents()[1].childNodes[1].id;		
		if($j('#'+arrowId).hasClass('showarrow')) {
			$j('#'+arrowId).removeClass('showarrow').addClass('hidearrow');
		}		
		_this.closest('div.panelfieldoption').find('a.outerselall-2').css('display','inline');
	} else {
		$j('#' + panelTypeId + 'List').css('display','none');
		$j('#' + panelTypeId + 'List').slideUp(700);		
		$j('#' + panelTypeId + 'List').find('.groupIdentifierPanelList').css('display','none');
		$j('#' + panelTypeId + 'List').find('.groupIdentifierSubpanelAttribute').css('display','none');
		$j('#' + panelTypeId + 'List').find('.groupIdentifierPanelAttribute').css('display','none');
		$j('#' + panelTypeId + 'List').find('input[type="checkbox"]').prop('checked',false);
		$j('#selectIdentifierFields').html('Select All');		
		var arrowId=$j(this).parents()[1].childNodes[1].id;
		if($j('#'+arrowId).hasClass('hidearrow')) {
			$j('#'+arrowId).removeClass('hidearrow').addClass('showarrow');
		}
		_this.closest('div.panelfieldoption').find('a.outerselall-2').css('display','none');
		_this.closest('div.panelfieldoption').find('a.outerselall-2').html('Select All');
		enableSharedFields();
	}
});
$j(document).on('click', '.assoattributeindvalue_panel,.assoattributeindvalue_subpanel,.assoattributeindvalue_userpanel,.assoattributeindvalue_usersubpanel', function(e) {
	var rel = $j(this).attr('id');	
	var checkedvalue=$j(this).prop("checked");
	if(checkedvalue){
		$j('#'+rel+'_section').css('display','block');
		$j('#'+rel+'_section').find('.groupIdentifierSubpanelList').css('display','block');
		//$j('.groupIdentifierSubpanelList').css('display','block');
	}
	else{
		$j('#'+rel+'_section').css('display','none');
		$j('#'+rel+'_section').find('.groupIdentifierSubpanelList').css('display','none');
		$j('#'+rel+'_section').find('.groupIdentifierSubpanelAttribute').css('display','none');
		$j('#'+rel+'_section').find('input[type="checkbox"]').prop('checked',false);
		$j('#selectIdentifierFields').html('Select All');
		enableSharedFields();
		//$j('.groupIdentifierSubpanelList').css('display','none');
	}
	toggleInnerSelectIdentifierFields (rel,checkedvalue); //DD
	/*var perticularFieldsCount = 	$j('#'+rel+'_section'+ ' input[class="assoattributeindvalue_field"]').length ;
	var perticularFieldsCheckedCount = 	$j('#'+rel+'_section'+ ' input[class="assoattributeindvalue_field"]:checked').length ;
		
	if(perticularFieldsCount == perticularFieldsCheckedCount) {
		$j('#selectIdentifierFields').html('Select None');
	} else {		
		$j('#selectIdentifierFields').html('Select All');
	}*/	
});


$j(document).on('change', '.edit_attributeindvalue', function(e) {
	var rel = $j(this).attr('rel');		
	edittoggleSelectProfieldFields(rel);	
	});

function edittoggleSelectProfieldFields (rel) {
	var perticularFieldsCount = 	$j('#'+rel+'List input[class="edit_attributeindvalue"]').length ;
	var perticularFieldsCheckedCount = 	$j('#'+rel+'List input[class="edit_attributeindvalue"]:checked').length ;
	
	var totalFieldsCount = 	$j('input[class="edit_attributeindvalue"]').length ;
	var totalFieldsCheckedCount = 	$j('input[class="edit_attributeindvalue"]:checked').length ;	
	
	if(perticularFieldsCount == perticularFieldsCheckedCount) {
		$j('#'+rel+'List').find('.editInnerselall').html('Select None');
		//$j('#'+rel).prop('checked',true);	
	}else if(perticularFieldsCheckedCount < perticularFieldsCount) {
		$j('#'+rel+'List').find('.editInnerselall').html('Select All');	
		//$j('#'+rel).prop('checked',true);
	}
	if(totalFieldsCount == totalFieldsCheckedCount) {
		$j('#editSelectProfileFields').html('Select None');
	} else {		
		$j('#editSelectProfileFields').html('Select All');
	}
}
$j(document).on('click', '.editInnerselall', function(e) {	
	thisRelvar = $j(this).attr('rel');
	thisTextvar = $j(this).text();	
	
	if(thisTextvar.trim() == 'Select All'){
		$j('#'+thisRelvar+'List').find('.edit_attributeindvalue').prop('checked',true);	
		$j('#'+thisRelvar).prop('checked',true);	
		$j(this).text('Select None');		
	}else{
		$j('#'+thisRelvar+'List').find('.edit_attributeindvalue').prop('checked',false);		
		$j(this).text('Select All');
		$j('#'+thisRelvar).prop('checked',false);			
	}
	setTimeout(function(){ 
		var totalFieldsCount = 	$j('input[class="edit_attributeindvalue"]').length ;
		var totalFieldsCheckedCount = 	$j('input[class="edit_attributeindvalue"]:checked').length ;
			
		if(totalFieldsCount == totalFieldsCheckedCount) {
			$j('#editSelectProfileFields').html('Select None');
		} else {		
			$j('#editSelectProfileFields').html('Select All');
		}	
	}, 100);
	
});
$j(document).on('click', '#editSelectProfileFields', function(e) {
	if($j('#editSelectProfileFields').html() == 'Select All') {
		$j('#editSelectProfileFields').html('Select None');
		$j('.editInnerselall').html('Select None');
		
		if($j('.groupProfileArrow').hasClass('showarrow')) {
			$j('.groupProfileArrow').removeClass('showarrow').addClass('hidearrow');
		}
		//if($j('.standardPanelList').css('display') == 'none') {
			$j('.standardPanelList').css('display','block');	
			$j('.standardPanelList').slideDown(700);
			//$j('#selectProfileFields').html('Select None');
		//}			
		$j('.edit_groupProfileType').prop('checked',true);
		$j('.edit_attributeindvalue').prop('checked',true);		
	} else {
		$j('#editSelectProfileFields').html('Select All');
		$j('.editInnerselall').html('Select All');
		
		
		if($j('.groupProfileArrow').hasClass('hidearrow')) {
			$j('.groupProfileArrow').removeClass('hidearrow').addClass('showarrow');
		}
		//if($j('.standardPanelList').css('display') == 'block') {
			$j('.standardPanelList').css('display','none');	
			$j('.standardPanelList').slideUp(700);
			//$j('#selectProfileFields').html('Select All');
		//}				
		$j('.edit_groupProfileType').prop('checked',false);
		$j('.edit_attributeindvalue').prop('checked',false);
	}
});
$j(document).on('click', 'input[type="checkbox"][class="edit_groupProfileType"]', function(e) {	
	var panelTypeId = $j(this).attr('attr-id');	
	var _this = $j(this);	
	if ($j(this).is(":checked")) {
		_this.parent().siblings('.groupProfileArrow,.groupIdentifierArrow').removeClass("showarrow");
		_this.parent().siblings('.groupProfileArrow,.groupIdentifierArrow').addClass("hidearrow");	
		$j('#' + panelTypeId + 'List').css('display','block');		
		$j('#' + panelTypeId + 'List').slideDown(700);		
	} else {		
		$j('#' + panelTypeId + 'List').find('input[class="edit_attributeindvalue"]').prop('checked',false);
		$j('#' + panelTypeId + 'List').css('display','none');			
		_this.parent().siblings('.groupProfileArrow,.groupIdentifierArrow').removeClass("hidearrow");
		_this.parent().siblings('.groupProfileArrow,.groupIdentifierArrow').addClass("showarrow");				
		$j('#' + panelTypeId + 'List').slideUp(700);		
		//$j('#' + panelTypeId + 'List').find('.editInnerselall').html('Select All');
		$j('#editSelectProfileFields').html('Select All');
	}
});
$j(document).on('click', 'input[type="checkbox"][class="edit_groupIdentifierType"]', function(e) {	
	var panelTypeId = $j(this).attr('attr-id');	
	var _this = $j(this);	
	if ($j(this).is(":checked")) {
		$j('#' + panelTypeId + 'List').css('display','block');
		$j('#' + panelTypeId + 'List').slideDown(700);	
		$j('#' + panelTypeId + 'List').find('.groupIdentifierPanelList').css('display','block');
		var arrowId=$j(this).parents()[1].childNodes[1].id;		
		if($j('#'+arrowId).hasClass('showarrow')) {
			$j('#'+arrowId).removeClass('showarrow').addClass('hidearrow');
		}
		_this.closest('div.panelfieldoption').find('a.edit_outerselall-2').css('display','inline');
	} else {
		$j('#' + panelTypeId + 'List').css('display','none');
		$j('#' + panelTypeId + 'List').slideUp(700);		
		$j('#' + panelTypeId + 'List').find('.groupIdentifierPanelList').css('display','none');		
		$j('#' + panelTypeId + 'List').find('.groupIdentifierSubpanelAttribute').css('display','none');
		$j('#' + panelTypeId + 'List').find('.groupIdentifierPanelAttribute').css('display','none');
		$j('#' + panelTypeId + 'List').find('input[type="checkbox"]').prop('checked',false);
		$j('#editSelectIdentifierFields').html('Select All');
		var arrowId=$j(this).parents()[1].childNodes[1].id;
		if($j('#'+arrowId).hasClass('hidearrow')) {
			$j('#'+arrowId).removeClass('hidearrow').addClass('showarrow');
		}	
		_this.closest('div.panelfieldoption').find('a.edit_outerselall-2').css('display','none');
		edit_enableSharedFields();
	}	
});

$j(document).on('change', '#edit_ProfileField', function(e) {
	if ($j(this).is(":checked")) {		
		$j('#edit_totalprofilefield').slideDown(700);
							
	} else {								
		$j('input[type="checkbox"][class="edit_groupProfileType"]').each(function() {																				   
			var panelTypeId = $j(this).attr('attr-id');	
			var _this = $j(this);		
			$j('.' + panelTypeId + 'List').find('input[type=checkbox]:checked').prop('checked',false);
			
			$j('#' + panelTypeId).prop('checked',false);
			_this.parent().siblings('.groupProfileArrow ').removeClass("hidearrow");
			_this.parent().siblings('.groupProfileArrow ').addClass("showarrow");								
			$j('#' + panelTypeId + 'List').css('display','none');
					
		});				
		$j('#edit_totalprofilefield').slideUp(700);
		
	}
});

$j(document).on('change', '#edit_incude_total', function(e) {
	if ($j(this).is(":checked")) {		
		$j('#edit_includeIdentifierfield').slideDown(700);							
	} else {								
		$j('input[type="checkbox"][class="edit_groupIdentifierType"]').each(function() {																				   
			var panelTypeId = $j(this).attr('attr-id');	
			var _this = $j(this);		
			$j('.' + panelTypeId + 'List').find('input[type=checkbox]:checked').prop('checked',false);			
			$j('#' + panelTypeId).prop('checked',false);
			_this.parent().siblings('.groupProfileArrow ').removeClass("hidearrow");
			_this.parent().siblings('.groupProfileArrow ').addClass("showarrow");								
			$j('#' + panelTypeId + 'List').css('display','none');			
		});				
		$j('#edit_includeIdentifierfield').slideUp(700);		
	}
});

function toggleEditSelectProfileIdentifierFields(classes,id) {
	var totalFieldsCount = 	$j('input[class='+classes+']').length ;
	var totalFieldsCheckedCount = 	$j('input[class='+classes+']:checked').length ;
	if(totalFieldsCount == totalFieldsCheckedCount) {
		$j('#'+id).html('Select None');
	} else {
		$j('#'+edit_includeIdentifierfield).html('Select All');
	}
}

$j(document).on('click', '#editSelectIdentifierFields', function(e) {
	
	if($j('#editSelectIdentifierFields').html() == 'Select All') {
		$j('#editSelectIdentifierFields').html('Select None');
		$j('a.edit_innerselall-2').html('Select None');
		$j('a.edit_innerselall-psp').html('Select None');
		$j('a.edit_outerselall-2').css('display','block').html('Select None');
		if($j('.groupIdentifierArrow').hasClass('showarrow')) {
			$j('.groupIdentifierArrow').removeClass('showarrow').addClass('hidearrow');
		}		
		$j('.edit_assoattributedeatils').css('display','block');	
		$j('.edit_assoattributedeatils').slideDown(700);		
		$j('.groupIdentifierPanelList').css('display','block'); //editGroupIdentifierPanelList
		$j('.groupIdentifierPanelAttribute').css('display','block');
		$j('.groupIdentifierSubpanelAttribute').css('display','block');
		$j('.groupIdentifierSubpanelList').css('display','block');
		$j('.edit_groupIdentifierType').prop('checked',true);
		$j('.edit_assoattributeindvalue_field').prop('checked',true);
		$j('.edit_assoattributeindvalue_panel').prop('checked',true);
		$j('.edit_assoattributeindvalue_subpanel').prop('checked',true);
		$j('.edit_assoattributeindvalue_userpanel').prop('checked',true);
		$j('.edit_assoattributeindvalue_usersubpanel').prop('checked',true);
		edit_enableSharedFields();								
	} else {
		$j('#editSelectIdentifierFields').html('Select All');
		$j('a.edit_innerselall-2').html('Select All');
		$j('a.edit_innerselall-psp').html('Select All');
		$j('a.edit_outerselall-2').css('display','none').html('Select All');
		if($j('.groupIdentifierArrow').hasClass('hidearrow')) {
			$j('.groupIdentifierArrow').removeClass('hidearrow').addClass('showarrow');
		}	
		$j('.edit_assoattributedeatils').css('display','none');	
		$j('.edit_assoattributedeatils').slideUp(700);	
		$j('.groupIdentifierPanelList').css('display','none'); //editGroupIdentifierPanelList
		$j('.groupIdentifierPanelAttribute').css('display','none');
		$j('.groupIdentifierSubpanelAttribute').css('display','none');
		$j('.groupIdentifierSubpanelList').css('display','none');		
		$j('.edit_assoattributeindvalue_panel').prop('checked',false);
		$j('.edit_assoattributeindvalue_field').prop('checked',false);	
		$j('.edit_assoattributeindvalue_subpanel').prop('checked',false);
		$j('.edit_assoattributeindvalue_userpanel').prop('checked',false);
		$j('.edit_assoattributeindvalue_usersubpanel').prop('checked',false);
		$j('.edit_groupIdentifierType').prop('checked',false);	
		edit_disableSharedFields()
	}
});

$j(document).on('change', '.edit_assoattributeindvalue_field', function(e) {
	var rel = $j(this).attr('rel');	
	var checkedvalue=$j(this).prop("checked");
	edittoggleSelectIdentifierFields(rel,checkedvalue);	
	edittoggleInnerSelectIdentifierFields(rel,checkedvalue); //DD
	
	/* Start: Code to display Selected Shared Fields */
	var selectedGroupList = formData.userSelectedGroups;
	var selectedGroupIdList = selectedGroupList.split(',');
	if(selectedGroupIdList.length > 1 ) {
		edit_enableSharedFields();
		/*var fieldId = $j(this).val();
		var checkFieldIdCount = $j('.edit_assoattributeindvalue_field_' + fieldId +':checked').length;
		var sharedfieldsavl = 0;
		if(selectedGroupIdList.length === checkFieldIdCount) {
			if($j('#edit_sharedfields').prop('disabled') == true) {
				$j('#edit_sharedfields').prop('disabled',false);
			}
			$j('.edit_sharedFieldsOptionsList_' + fieldId).css('display','block');
			$j('#edit_selectallsharedfields').html('Select All');
			sharedfieldsavl = parseInt($j('#edit_sharedfieldsavl').val());
			sharedfieldsavl = sharedfieldsavl + 1;
			$j('#edit_sharedfieldsavl').val(sharedfieldsavl);
		} else {			
			$j('.edit_sharedFieldsOption_' + fieldId).prop('checked',false);
			$j('.edit_sharedFieldsOptionsList_' + fieldId).css('display','none');
			if ($j('#edit_sharedfields').prop('disabled') == false) {
				sharedfieldsavl = parseInt($j('#edit_sharedfieldsavl').val());
				sharedfieldsavl = sharedfieldsavl - 1;
				$j('#edit_sharedfieldsavl').val(sharedfieldsavl);
				if(sharedfieldsavl == 0) {
					$j('#edit_sharedfieldslist').css('display','none');
					$j('.edit_sharedFieldsOption').prop('checked',false);
					$j('#edit_sharedfields').prop('checked',false);
					$j('#edit_sharedfields').prop('disabled',true);				
				}
			}			
		}
		if($j('.edit_sharedFieldsOptionsList:visible').length > 1) {
			$j('#edit_selectallsharedfields').css('display','block');	
		} else {
			$j('#edit_selectallsharedfields').css('display','none');
		}*/
	}
	/* End: Code to display Selected Shared Fields */
	
});

function edittoggleSelectIdentifierFields (rel,checkedvalue) {
	
	var totalIdentifierCount = 	$j('.edit_assoattributedeatils'+' input[class="edit_assoattributeindvalue_field"]').length ;
	var totralIdentifierCheckedCount = 	$j('.edit_assoattributedeatils'+' input[class="edit_assoattributeindvalue_field"]:checked').length ;	
	if(totalIdentifierCount == totralIdentifierCheckedCount) {
		$j('#editSelectIdentifierFields').html('Select None');
	} else {		
		$j('#editSelectIdentifierFields').html('Select All');
	}	
}

$j(document).on('click', '.edit_assoattributeindvalue_panel,.edit_assoattributeindvalue_subpanel,.edit_assoattributeindvalue_userpanel,.edit_assoattributeindvalue_usersubpanel', function(e) {
	var rel = $j(this).attr('id');	
	var checkedvalue=$j(this).prop("checked");
	if(checkedvalue){
		$j('#'+rel+'_Section').css('display','block');
		$j('#'+rel+'_Section').find('.groupIdentifierSubpanelList').css('display','block');
		//$j('.groupIdentifierSubpanelList').css('display','block');
	}
	else{
		$j('#'+rel+'_Section').css('display','none');
		$j('#'+rel+'_Section').find('.groupIdentifierSubpanelList').css('display','none');
		$j('#'+rel+'_Section').find('.groupIdentifierSubpanelAttribute').css('display','none');
		$j('#'+rel+'_Section').find('input[type="checkbox"]').prop('checked',false);
		$j('#editSelectIdentifierFields').html('Select All');
		edit_enableSharedFields();
		//$j('.groupIdentifierSubpanelList').css('display','none');
	}	
	edittoggleInnerSelectIdentifierFields($j(this).attr('rel'),checkedvalue); //DD	
});

$j(document).on('click', '.edit_totalWorksheets', function(e) {
	var _this = $j(this);
	var child_elem_name = _this.attr('attr-panel'); 
	var checkedValue = _this.val();	
	var selectedGroupList = formData.userSelectedGroups;	
	var associationid = selectedGroupList;
	if (_this.is(":checked") && checkedValue=="TF") {		
		$j('#edit_totalprofilefield').css('display','block');	
		$j('#edit_totalprofilefield').slideDown(700);
	}else if(_this.is(":checked")==false && checkedValue=="TF"){
		$j('#edit_totalprofilefield').slideUp(700);
		$j('#edit_totalprofilefield').css('display','none');	
	}
	if (_this.is(":checked") && checkedValue=="IF") {	
		$j('#edit_includeIdentifierfield').css('display','block');	
		$j('#edit_includeIdentifierfield').slideDown(700);
        $j('#edit_arrangepanelfields').css('display','block');
	}else if(_this.is(":checked")==false && checkedValue=="IF"){		
		$j('#edit_arrangepanelfields').css('display','none');
		$j('#edit_includeIdentifierfield').find('a.edit_outerselall-2').css('display','none');	
		$j('#edit_includeIdentifierfield').find('input[type=checkbox]').prop('checked', false);
	    $j('#edit_includeIdentifierfield').find('div.groupIdentifierSubpanelAttribute').css('display','none');
	    $j('#edit_includeIdentifierfield').find('div.groupIdentifierPanelAttribute').css('display','none');
		$j('#edit_includeIdentifierfield').slideUp(700);
		$j('#edit_includeIdentifierfield').find('span.groupIdentifierArrow').addClass('showarrow').removeClass('hidearrow');
		
		$j('#edit_sharedfields').prop('checked',false);
		$j('.edit_sharedFieldsOption').prop('checked',false); 
		$j('#edit_sharedfieldslist').css('display','none');
		$j('#edit_sharedfields').prop('disabled',true);				
	}
	
	if (_this.is(":checked") && checkedValue=="T") {			
		//$j("#edit_grouptotalentireperiodbreakout").prop("disabled", false);	
		$j("#edit_allbreakout").slideDown(700);
	}else if(_this.is(":checked")==false && checkedValue=="T"){
		$j("#edit_grouptotalentireperiodbreakout").prop("checked", false);
		//$j("#edit_grouptotalentireperiodbreakout").prop("disabled", true);	
		$j("#edit_allbreakout").slideUp(700);
	}
	
	if (_this.is(":checked") && checkedValue=="TSP") {	
		//$j("#edit_totalperiodbreakoutSurvey").prop("disabled", false);	
		$j('#edit_surveybreakout').slideDown(700);
	}else if(_this.is(":checked")==false && checkedValue=="TSP"){
		$j("#edit_totalperiodbreakoutSurvey").prop("checked", false);
		//$j("#edit_totalperiodbreakoutSurvey").prop("disabled", true);	
		$j('#edit_surveybreakout').slideUp(700);
	}
	
	if (_this.is(":checked") && checkedValue=="TP") {			
		//$j("#edit_totalperiodbreakout").prop("disabled", false);
		$j("#edit_totalbreakout").slideDown(700);
	}else if(_this.is(":checked")==false && checkedValue=="TP"){
		$j("#edit_totalperiodbreakout").prop("checked", false);
		//$j("#edit_totalperiodbreakout").prop("disabled", true);	
		$j("#edit_totalbreakout").slideUp(700);
	}
	
	if($j('#edit_grouptotalentireperiod').is(":checked") || $j('#edit_totalperiod').is(":checked") || $j('#edit_totalperiodSurvey').is(":checked")) { //|| $j('#edit_totalmatrixview').is(":checked")
		$j('#edit_incude_total').prop('disabled',false);
	} else {
		$j('.edit_assoattributeindvalue_field').prop('checked',false);
		$j('#edit_includeIdentifierfield').css('display','none');	
		$j('#edit_arrangepanelfields').css('display','none');		
		$j('#edit_incude_total').prop('checked',false);
		$j('#edit_incude_total').prop('disabled',true);
		
		$j('#edit_sharedfields').prop('checked',false);
		$j('.edit_sharedFieldsOption').prop('checked',false); 
		$j('#edit_sharedfieldslist').css('display','none');
		$j('#edit_sharedfields').prop('disabled',true);		
	}
	
});
/*End Step-6 */

/* Start- Step-5 */

function setSelectedData() {	
	checkSession();
	var selectedradioval = $j.trim($j('input[name=radio_SelectedreportType]:checked').val());	
	var displaytxt = $j('#selectedreportType_'+selectedradioval).find('label').first().text();
	formData.selectedDataReportid = 0;
	__compilation = formData.compilation;
	__selectedMatrixRowId = formData.selectedMatrixRowId;
	formData.compilation = "";
	formData.selectedMatrixRowId = "";

	if (selectedradioval == 'selectedreport') { /* If Saved report selected Then append the report name */		
		var selectedReportId = $j.trim($j('input[name=radio_ReportIDSelection]:checked').attr('report-id'));
		var selectedReportname = $j('.label_report_'+selectedReportId + ' .sel-name').text();
		displaytxt = "Saved Selection: "+selectedReportname; //displaytxt + ": "+selectedReportname;
		formData.selectedDataReportid = selectedReportId;
		var hasMatrix = $j.trim($j('input[name=radio_ReportIDSelection]:checked').attr('data-has-matrix'));
		if ( hasMatrix == "YES" ) {
			flag_matrixtrueView=true; }
		else {
			flag_matrixtrueView=false; }
	}
	else if (selectedradioval == 'selecteddata') { /* If Customize data selected Then check the report name and save */
		var reportNameToSave = $j.trim( $j('#txt_ReportName').val() );
		/* /checking the saved selection text field			
		if( TestInput(reportNameToSave) ) {
			alert("Please remove the following characters from your Saved Selection name: [ ] ~ ` # % ^ & = + < > \" \\ ");
			$j('#txt_ReportName').focus();
			return false;
		} SURVEXPORT-244 */
		var selectedQues = $j.trim( $j('#selectedQuestionIdReporting').val() );
		var selectedMatrixRowId = $j.trim( $j('#selectedMatrixRowId').val() );
		if ( selectedQues == "" ) {
			alert("Please select atleast one question.");
			return false;
		}

		if (checkReportNameAvailability('txt_ReportName') == false) {
			$j('#hdn_txt_ReportName').val("");
			return false;
		}else {
			$j('#hdn_txt_ReportName').val(reportNameToSave);
		}

		formData.compilation = selectedQues;
		formData.selectedMatrixRowId = selectedMatrixRowId;		
		displaytxt = "Customized Selection";
		if ( selectedMatrixRowId != "" ) {
			flag_matrixtrueView=true; }
		else {
			flag_matrixtrueView=false; }
	}
	else {
		/* If any matrix question in All Data */
		var startPeriod = formData.startPeriod;
		var endPeriod = formData.endPeriod;
		var selectedSurveysList = formData.selectedSurveysList;
		showLoadingOverlay();
		setTimeout(function(){
		new Ajax.Request("/index.cfm?event=survey.getdataforsurveycategoryexport",
		{
			method: 'post',
			parameters: {categoryname: '',startPeriod:startPeriod,endPeriod:endPeriod, selectedSurveysList:selectedSurveysList, ajaxcall:true},
			onSuccess: function(returnHtml) {
				var parsedjson = $j.parseJSON(returnHtml.responseText);
				//console.log(parsedjson);
				if ( parsedjson.matrixrowid == true || parsedjson.matrixrowid == 'true' ) {
					flag_matrixtrueView=true; }
				else {
					flag_matrixtrueView=false; }
				showhidematrixviewcheckbox();
				$j('#lblSummarySurveySelectedData').html(displaytxt);
				$j('.container_selectedreportType').hide();
				$j('#editselectdatacheck').show();
				$j('.lblSummarySurveyData').show();
				hideLoadingOverlay();
				formData.setStep5 = 1;
				showhideExportExcelButton();
				enableNextStep(6);
			}, 
			onFailure: function() {hideLoadingOverlay();alert('Oops...mistake on server, please try again.');},
		});
		}, 2);
	}
	if (selectedradioval == 'selectedreport' || selectedradioval == 'selecteddata'){
		showhidematrixviewcheckbox();

		$j('#lblSummarySurveySelectedData').html(displaytxt);
		$j('.container_selectedreportType').hide();
		$j('#editselectdatacheck').show();
		$j('.lblSummarySurveyData').show();
		hideLoadingOverlay();
		formData.setStep5 = 1;
		showhideExportExcelButton();
		enableNextStep(6);
	}
}

function showhidematrixviewcheckbox() {
	if ( flag_matrixtrueView == true || flag_matrixtrueView == 'true' ) {
		if ($j('#totalmatrixview').length) {
			$j('#totalmatrixview').parent('div').show();
		}
		if ($j('#edit_totalmatrixview').length) {
			$j('#edit_totalmatrixview').parent('div').show();
		}
	}
	else {
		if ($j('#totalmatrixview').length) {
			$j('#totalmatrixview').parent('div').hide();
		}
		if ($j('#edit_totalmatrixview').length) {
			$j('#edit_totalmatrixview').parent('div').hide();
		}
	}
	//console.log('called flag_matrixtrueView-'+flag_matrixtrueView);
}

function displayDataForCategory(categoryname,selPrograms,imgname)
{
	checkSession();		
	selectedQuestions = document.getElementById("selectedQuestionIdReporting").value;
	selectedMatrixRows = document.getElementById("selectedMatrixRowId").value; //Added by Bala SQM-6
	var startPeriod = formData.startPeriod;
	var endPeriod = formData.endPeriod;
	var selectedSurveysList = formData.selectedSurveysList;
	
	imgnamepassed = "img_"+imgname;
	if (document.getElementById("showorhidequestions").innerHTML == "Only Display Selected Items")
	{
		questionSelectionLinkStatus = "all";
	}
	else
	{
		questionSelectionLinkStatus = "selected";
	}
	if (categoryname == 'alrq')
	{
		if (document.getElementById("trreqquestioncheckbox").style.display == 'none')
		{
			document.getElementById(imgnamepassed).style.display = '';
			new Ajax.Request("/index.cfm?event=survey.getdataforsurveycategoryexport",{
			method: 'post',
			parameters: {categoryname: categoryname, selPrograms: selPrograms,imgname:imgname,selectedQuestions:selectedQuestions,questionSelectionLinkStatus:questionSelectionLinkStatus,selectedMatrixRows:selectedMatrixRows,startPeriod:startPeriod,endPeriod:endPeriod, selectedSurveysList:selectedSurveysList},
				
			onSuccess: function(returnHtml) { 
		
			document.getElementById("trreqquestioncheckbox").style.display = '';
			Element.update("tdreqquestioncheckbox", returnHtml.responseText); 
			document.getElementById(imgnamepassed).style.display = 'none';
			}, 
			onFailure: function()
			{ 
				alert('Oops...mistake on server');
			},
			onComplete: function()
			{
				var i = 0,
					archiveFolderSelector = document.getElementsByClassName("ArchiveFolder"),
					numOfArchiveFolder = archiveFolderSelector.length,
					showArchiveQuestion = document.getElementById("showArchivedCategory").checked;
				while (i < numOfArchiveFolder) {
					if (showArchiveQuestion === true) {
						archiveFolderSelector[i].parentElement.style.display = 'block';
					} else if (showArchiveQuestion === false) {
						archiveFolderSelector[i].parentElement.style.display = 'none';
					}
					i++;
				}
			}
			});
		}
		else
		{
			trclose('trreqquestioncheckbox');
		}
	}
	if (categoryname == 'alretq')
	{
		
		if (document.getElementById("trretquestioncheckbox").style.display == 'none')
		{
			document.getElementById(imgnamepassed).style.display = '';
			new Ajax.Request("/index.cfm?event=survey.getdataforsurveycategoryexport",
			{
			method: 'post',
			parameters: {categoryname: categoryname, selPrograms: selPrograms,imgname:imgname,selectedQuestions:selectedQuestions,questionSelectionLinkStatus:questionSelectionLinkStatus,selectedMatrixRows:selectedMatrixRows,startPeriod:startPeriod,endPeriod:endPeriod, selectedSurveysList:selectedSurveysList},						 
			onSuccess: function(returnHtml) { 					
				document.getElementById("trretquestioncheckbox").style.display = '';
				Element.update("tdretquestioncheckbox", returnHtml.responseText); 
				document.getElementById(imgnamepassed).style.display = 'none';
			}, 
			onFailure: function()
			{ 
				alert('Oops...mistake on server');
			},
			onComplete: function()
			{
				var i = 0,
					archiveFolderSelector = document.getElementsByClassName("ArchiveFolder"),
					numOfArchiveFolder = archiveFolderSelector.length,
					showArchiveQuestion = document.getElementById("showArchivedCategory").checked;
				while (i < numOfArchiveFolder) {
					if (showArchiveQuestion === true) {
						archiveFolderSelector[i].parentElement.style.display = 'block';
					} else if (showArchiveQuestion === false) {
						archiveFolderSelector[i].parentElement.style.display = 'none';
					}
					i++;
				}
			}
			});

		}
		else
		{
			trclose('trretquestioncheckbox');
		}
	}
	if (categoryname != 'alretq' && categoryname != 'alrq')
	{
			categorynamefortableelements = categoryname.replace(/ /g, '');
			categorynamefortableelements = categorynamefortableelements.replace(/\\/g, '\\\\');
			imgnamepassed = imgnamepassed.replace(/\\/g, '\\\\');
			trcategorynamedatarow = "tr_"+categorynamefortableelements+"_datarow";
			tdcategorynamedatarow = "td_"+categorynamefortableelements+"_datarow";
			categoryname = categoryname.replace(/&/g, 'amper~~');
			imgname = imgname.replace(/&/g, 'amper~~');
			if (document.getElementById(trcategorynamedatarow).style.display == 'none')
			{
				document.getElementById(imgnamepassed).style.display = '';
				new Ajax.Request("/index.cfm?event=survey.getdataforsurveycategoryexport",{
				method: 'post',
				parameters: {categoryname: categoryname, selPrograms: selPrograms,imgname:imgname,selectedQuestions:selectedQuestions,questionSelectionLinkStatus:questionSelectionLinkStatus,selectedMatrixRows:selectedMatrixRows,startPeriod:startPeriod,endPeriod:endPeriod, selectedSurveysList:selectedSurveysList},
					
				onSuccess: function(returnHtml) { 
				
				document.getElementById(trcategorynamedatarow).style.display = '';
				Element.update(tdcategorynamedatarow, returnHtml.responseText); 
				document.getElementById(imgnamepassed).style.display = 'none';
				}, 
				onFailure: function()
				{ 
					alert('Oops...mistake on server');
				},
				onComplete: function()
				{
					var i = 0,
						archiveFolderSelector = document.getElementsByClassName("ArchiveFolder"),
						numOfArchiveFolder = archiveFolderSelector.length,
						showArchiveQuestion = document.getElementById("showArchivedCategory").checked;
					while (i < numOfArchiveFolder) {
						if (showArchiveQuestion === true) {
							archiveFolderSelector[i].parentElement.style.display = 'block';
						} else if (showArchiveQuestion === false) {
							archiveFolderSelector[i].parentElement.style.display = 'none';
						}
						i++;
					}
					var len = $j(".data-viewing-title").filter("#"+imgname+" input[type=checkbox]").length;
					var outerchkdlen = $j('.data-viewing-title').filter("#"+imgname+" :checked").length;
					
					if(outerchkdlen >= 1){
						if(outerchkdlen==len)
							$j("#a_"+imgname).text('Select None');
						else
							$j("#a_"+imgname).text('Select All');
					}else{
						$j("#a_"+imgname).text('Select All');
					}
				} 
				});
			}
			else
			{
				trclose(trcategorynamedatarow);
			}	
	}				
}

function assignQuestiontoHiddenField(passedQuestionID)
{
	setTimeout(function(){ 
		try {					
			if(document.getElementById(passedQuestionID).checked)
			{			
				if(document.getElementById("selectedQuestionIdReporting").value.length == 0){
					document.getElementById("selectedQuestionIdReporting").value = passedQuestionID;
				}else{
					document.getElementById("selectedQuestionIdReporting").value = document.getElementById("selectedQuestionIdReporting").value + "^^^" + passedQuestionID;
					var hiddenval=document.getElementById("selectedQuestionIdReporting").value;				
					hiddenval=hiddenval.split("^^^");			
					var uniqearray=[];
					for(i=0;i<hiddenval.length;i++){				
						if(uniqearray.indexOf(hiddenval[i])<0){					
							uniqearray.push(hiddenval[i]);
						}
					}			
					uniqearray=uniqearray.toString().replaceAll(",","^^^");							
					document.getElementById("selectedQuestionIdReporting").value = uniqearray; 
				}
			
			}else{
				var hiddenvalue=document.getElementById("selectedQuestionIdReporting").value;
				var splitlen=hiddenvalue.split("^^^");		
				if(splitlen.length==1){
					hiddenvalue=hiddenvalue.replace(passedQuestionID,'');
				}else{
					hiddenvalue=hiddenvalue.replace("^^^"+passedQuestionID,'');
				}	
				document.getElementById("selectedQuestionIdReporting").value=hiddenvalue;
			} 
			
		}catch(err) {
			console.log(err.message);
		}
		if (document.getElementById("selectedQuestionIdReporting").value.length > 0)
			{
				document.getElementById("SelectedDataDiv").style.display = 'block';
				document.getElementById("showorhidequestions").style.display = 'block';				
				//this is to show the report saving name block
				document.getElementById("tableReportSaving").style.display = "block";
				document.getElementById("btnsetselecteddata").style.display = "block"; //Show Set Button
			}
			else
			{
				document.getElementById("btnsetselecteddata").style.display = "none"; //Show Set Button	
				document.getElementById("tableReportSaving").style.display = "none";
				document.getElementById("ReportAvailableTable").style.display = 'none';
				if(document.getElementById("showorhidequestions").text =='Only Display Selected Items'){
					document.getElementById("SelectedDataDiv").style.display = 'none'; 
					document.getElementById("showorhidequestions").style.display = 'none';	
				}			
			}			
		}, 100);	
}

function removeQuestiontoHiddenField(passedQuestionID)
{		
	var hiddenvalue=document.getElementById("selectedQuestionIdReporting").value;

	var splitlen=hiddenvalue.split("^^^");		
	if(splitlen.length==1){
		hiddenvalue=hiddenvalue.replace(passedQuestionID,'');
	}else{
		hiddenvalue=hiddenvalue.replace("^^^"+passedQuestionID,'');
		hiddenvalue=hiddenvalue.replace(passedQuestionID,'');
	}	
	document.getElementById("selectedQuestionIdReporting").value=hiddenvalue;
	
	if (document.getElementById("selectedQuestionIdReporting").value.length > 0)
	{
		document.getElementById("btnsetselecteddata").style.display = "block"; //Show Set Button
	} else {
		document.getElementById("btnsetselecteddata").style.display = "none"; //Hide Set Button	
		document.getElementById("tableReportSaving").style.display = "none";
		document.getElementById("ReportAvailableTable").style.display = 'none';		
		if(document.getElementById("showorhidequestions").text =='Only Display Selected Items'){
		document.getElementById("SelectedDataDiv").style.display = 'none'; 
		document.getElementById("showorhidequestions").style.display = 'none';	
		}
	}	
}

function ShowSelectedData()
{
	if (document.getElementById("showorhidequestions").innerHTML == "Only Display Selected Items")
	{
		showLoadingOverlay();//document.getElementById("img_loaderselecteddata").style.display = 'block';
		
		//selected questions list
		var selectedQuestionidFileidlist = document.getElementById("selectedQuestionIdReporting").value;
		
		//selected matrix rows list - Added by Bala SQM-6
		var selectedRowidFileidlist = document.getElementById("selectedMatrixRowId").value;
		
		// these all are the selected programs
		var selprograms = document.getElementById("pgmid").value;
		
		//ajax call
		/* new Ajax.Request("/index.cfm?event=survey.showselecteddatafromhidden1",{
		method: "post",
		parameters: {
			selectedQuestionidFileidlist: selectedQuestionidFileidlist,
			selprograms: selprograms,
			selectedRowidFileidlist:selectedRowidFileidlist
		},
		onSuccess: function(returnHtml) { 
			Element.update("SelectedDataQuestionsDiv", returnHtml.responseText); 
			Effect.Appear("SelectedDataQuestionsDiv");
			
			//changing the link text
			document.getElementById("showorhidequestions").innerHTML = 'Display All Items';
			
			hideLoadingOverlay();//document.getElementById("img_loaderselecteddata").style.display = 'none';
			}, 
			onFailure: function()
			{ 
				alert('Oops...mistake on server');
			} 
			}); */
			$j.ajax({
				url: 'index.cfm?event=survey.showselecteddatafromhidden1',
				type: "POST",
				data: {
					selectedQuestionidFileidlist: selectedQuestionidFileidlist,
					selprograms: selprograms,
					selectedRowidFileidlist:selectedRowidFileidlist
				},
				/* beforeSend: function() {
					showLoadingOverlay();
				}, */
				success : function(returnHtml)
				{			
					//$j('#SelectedDataQuestionsDiv').html(returnHtml).slideDown(100);				
					//$j('table#CategoryTable').hide();
					//$j('table#surveyselectedquestioniddetailsselectedtable').remove();
					$j('#SelectedDataQuestionsDiv').html(returnHtml).slideDown(100);			
					document.getElementById("showorhidequestions").innerHTML = 'Display All Items';
					hideLoadingOverlay();
				},	
				complete: function()
				{
					hideLoadingOverlay();
				},
				error: function() {
					alert("failure");
				}
			});	
	}
	else
	{
		showLoadingOverlay();//document.getElementById("img_loaderselecteddata").style.display = 'block';

		//selected questions list
		var selectedQuestionidFileidlist = "All";
		
		// these all are the selected programs
		var selprograms = document.getElementById("pgmid").value;

		//ajax call
		var sdate = formData.startPeriod;		
		var edate = formData.endPeriod;
		var selSurveys = formData.selectedSurveysList;
		var dataArg = {
			programID: selprograms,
			SelectedbeginDate: sdate,
			SelectedendDate: edate,
			checkedSurveys: selSurveys
		};
		/* new Ajax.Request("/index.cfm?event=survey.showquestionidsforexport&programID="+selprograms,{ 
			method: "post",
			parameters: dataArg,
			onSuccess: function(returnHtml) { 
			Element.update("SelectedDataQuestionsDiv", returnHtml.responseText); 
			Effect.Appear("SelectedDataQuestionsDiv");
			
			document.getElementById("showorhidequestions").innerHTML = 'Only Display Selected Items';
			
			hideLoadingOverlay();//document.getElementById("img_loaderselecteddata").style.display = 'none';
			}, 
			onFailure: function()
			{ 
				alert('Oops...mistake on server');
			} 
			}); */	
			$j('table#surveyselectedquestioniddetailsselectedtable').hide();
			$j('table#CategoryTable').show();
			$j('#SelectedDataQuestionsDiv').slideDown(100);
			document.getElementById("showorhidequestions").innerHTML = 'Only Display Selected Items';
			hideLoadingOverlay();
			//return false;

			$j.ajax({
				url: 'index.cfm?event=survey.showquestionidsforexport',
				type: "POST",
				data: dataArg,
				/* beforeSend: function() {
					showLoadingOverlay();
				}, */
				success : function(returnHtml)
				{			
					$j('#SelectedDataQuestionsDiv').html(returnHtml).slideDown(100);				
					if(document.getElementById("selectedQuestionIdReporting").value.length > 0){
						document.getElementById("showorhidequestions").innerHTML = 'Only Display Selected Items';
					}else{
						document.getElementById("showorhidequestions").innerHTML = 'Only Display Selected Items';
						document.getElementById("SelectedDataDiv").style.display = 'none';
						document.getElementById("showorhidequestions").style.display = 'none';
					}	
					hideLoadingOverlay();
				},	
				complete: function()
				{
					hideLoadingOverlay();
				},
				error: function() {
						alert("failure");
					}
			});		
	}	
}

$j(document).on('click', '.data-viewing-title', function(e){
	var attrName = $j(this).attr('name'),
	newStr = attrName.split("|"),
	qid = newStr[1];
	var isChecked = $j(this).prop('checked');
	var relName = $j(this).attr('rel');		
	var len = $j(".data-viewing-title").filter("#"+relName+" input[type=checkbox]").length;
	var outerchkdlen = $j('.data-viewing-title').filter("#"+relName+" :checked").length;	
	if(outerchkdlen >= 1){
		if(outerchkdlen==len)
			$j("#a_"+relName).text('Select None');
		else
			$j("#a_"+relName).text('Select All');
	}else{
		$j("#a_"+relName).text('Select All');
	}
	if(isChecked)
	{
		var chkdlen = $j("#matrix-row_"+qid+" input[type=checkbox]:checked").length;
		if(chkdlen > 0){
			$j("#matrix-row_"+qid + " input[type=checkbox]:checked").each(function(){
				removeMatrixRowstoHiddenField($j(this).attr("id"));
				//$j(this).removeAttr("checked");
				document.getElementById($j(this).attr("id")).checked = false;
			});
		}else{
			$j("#matrix-row-select_"+qid).text('Select None');
			$j("#matrix-row_"+qid + " input[type=checkbox]").each(function(){
				//$j(this).attr("checked","checked");
				document.getElementById($j(this).attr("id")).checked = true;
				assignMatrixRowstoHiddenField($j(this).attr("id"));
			});
		}	
	}
	else
	{
		$j("#matrix-row-select_"+qid).text('Select All');
		$j("#matrix-row_"+qid + " input[type=checkbox]").each(function(){				
			//$j(this).removeAttr("checked");
			document.getElementById($j(this).attr("id")).checked = false;
			removeMatrixRowstoHiddenField($j(this).attr("id"));
		});	
		removeQuestiontoHiddenField($j(this).attr("id"));
	};	
});

function editassignQuestiontoHiddenField(passedQuestionID)
{
	setTimeout(function(){ 
		try {
		
			var checkboxId='';		
			if(passedQuestionID.indexOf("::")>0){
				var splitval=passedQuestionID.split("::");
				checkboxId=splitval[0];
				passedQuestionID=splitval[1];
			}else{
				checkboxId=passedQuestionID;
			}
			var EleCheckBoxChecked = $j("input[name='"+checkboxId+"']").prop('checked');
			if (document.getElementById(checkboxId) != null) {
				EleCheckBoxChecked = document.getElementById(checkboxId).checked}
			
			if(EleCheckBoxChecked)
			{			
				if(document.getElementById("selectedQuestionIdReporting").value.length == 0){
					document.getElementById("selectedQuestionIdReporting").value = passedQuestionID;
				}else{
					document.getElementById("selectedQuestionIdReporting").value = document.getElementById("selectedQuestionIdReporting").value + "^^^" + passedQuestionID;
					var hiddenval=document.getElementById("selectedQuestionIdReporting").value;				
					hiddenval=hiddenval.split("^^^");			
					var uniqearray=[];
					for(i=0;i<hiddenval.length;i++){				
						if(uniqearray.indexOf(hiddenval[i])<0){					
							uniqearray.push(hiddenval[i]);
						}
					}			
					uniqearray=uniqearray.toString().replaceAll(",","^^^");							
					document.getElementById("selectedQuestionIdReporting").value = uniqearray; 
				}
			
			}else{
				var hiddenvalue=document.getElementById("selectedQuestionIdReporting").value;
				var splitlen=hiddenvalue.split("^^^");		
				if(splitlen.length==1){
					hiddenvalue=hiddenvalue.replace(passedQuestionID,'');
				}else{
					hiddenvalue=hiddenvalue.replace("^^^"+passedQuestionID,'');
				}	
				document.getElementById("selectedQuestionIdReporting").value=hiddenvalue;
			} 
			
		}catch(err) {			
			console.log(err.message);
		}
		if (document.getElementById("selectedQuestionIdReporting").value.length > 0)
			{
				document.getElementById("SelectedDataDiv").style.display = 'block';
				document.getElementById("showorhidequestions").style.display = 'block';				
				//this is to show the report saving name block
				document.getElementById("tableReportSaving").style.display = "block";
				document.getElementById("btnsetselecteddata").style.display = "block"; //Show Set Button
			}
			else
			{
				document.getElementById("btnsetselecteddata").style.display = "none"; //Show Set Button	
				document.getElementById("tableReportSaving").style.display = "none";
				document.getElementById("ReportAvailableTable").style.display = 'none';
				if(document.getElementById("showorhidequestions").text =='Only Display Selected Items'){
					document.getElementById("SelectedDataDiv").style.display = 'none'; 
					document.getElementById("showorhidequestions").style.display = 'none';	
				}			
			}			
		}, 100);	
}

$j(document).on('click', '.matrix-row-chk', function(e){
//$j(".matrix-row-chk").click(function(){
	var attrId = $j(this).attr('id');
	var newStr = attrId.split("|"),
		qid = newStr[0];
	var len = $j("#matrix-row_"+qid+" input[type=checkbox]").length;
	var chkdlen = $j("#matrix-row_"+qid+" input[type=checkbox]:checked").length;
	var relName = $j(this).attr('rel');
	if (document.getElementById(relName) == null && $j(this).attr('attr-val') != undefined) {
		relName = $j(this).attr('attr-val');
	}
	
	if(chkdlen >= 1){
		if(chkdlen==len)
			$j("#matrix-row-select_"+qid).text('Select None');
		else
			$j("#matrix-row-select_"+qid).text('Select All');
		//$j("input[name='"+relName+"']").attr("checked","checked");
		document.getElementById(relName).checked = true;
		assignMatrixRowstoHiddenField(attrId);		
	}else{
		$j("#matrix-row-select_"+qid).text('Select All');
		assignMatrixRowstoHiddenField(attrId);		
	}
	
	if(chkdlen == 0){
		//$j("input[name='"+relName+"']").removeAttr("checked");
		document.getElementById(relName).checked = false;
		if($j(this).attr('attr-val') != undefined) {
			relName = $j(this).attr('attr-val');
		}
		removeQuestiontoHiddenField(relName);
	}else if (chkdlen == 1) {
		if($j(this).attr('attr-val') != undefined) {
			attrval = $j(this).attr('attr-val');
			editassignQuestiontoHiddenField(relName+"::"+attrval);
		}else{
			assignQuestiontoHiddenField(relName);
		}
	}
});

function saveCustomizeSelectionData() {
	//save selected data
	var datebegin_survey = formData.startPeriod;
	var dateend_survey = formData.endPeriod;
	var selectedQues = formData.compilation;
	var selectedMatrixRowId = formData.selectedMatrixRowId;
	var reportNameToSave = $j.trim( $j('#txt_ReportName').val());
	var selectedradioval = $j.trim($j('input[name=radio_SelectedreportType]:checked').val());
	var dateStartText = $j("#beginsurvey option:selected").text();
	var dateEndText = $j("#endsurvey option:selected").text();
	var availableTo = $j("input[name=radio_availTo]:checked").val();
	var availableIdList = "";
	var scope = document.getElementById("scope").value;
	if(availableTo == 'staffroles') {
		availableIdList = $j("input[type=checkbox][name=roleid]:checked").map(function() {return this.value;}).get().join(',');
	} else if (availableTo == 'owner') {
		availableIdList = $j("#currentUserId").val();
	}
	var checkboxselection1 = 0;
	if ($j("#chkbx_report1").prop('checked')) {
		checkboxselection1 = $j("#chkbx_report1").val();
	}
	var checkboxselection2 = 0;
	if ($j("#chkbx_report2").prop('checked')) {
		checkboxselection2 = $j("#chkbx_report2").val();
	}
	var checkboxselection3 = 0;
	if ($j("#chkbx_report3").prop('checked')) {
		checkboxselection3 = $j("#chkbx_report3").val();
	}
	var checkboxselection4 = 0;
	if ($j("#chkbx_report4").prop('checked')) {
		checkboxselection4 = $j("#chkbx_report4").val();
	}
	var checkboxselection5 = 0;
	if ($j("#chkbx_report5").length && $j("#chkbx_report5").prop('checked')) {
		checkboxselection5 = $j("#chkbx_report5").val();
	}
	if (reportNameToSave.trim().length == 0) {
		return false;
	}

	if ( $j('#hdn_txt_ReportName').val().trim().length > 0 && $j('#hdn_txt_ReportID').val().trim().length > 0 && $j('#hdn_txt_ReportID').val().trim() > 0) {
		var urlEvent = "survey.updatesurveyreportid";
		var CombinedSelectedDate = dateStartText + '~`' + dateEndText;
		var reportidselected = $j('#hdn_txt_ReportID').val();
		var dataParam = { 
			reportNameEntered: reportNameToSave,
			beginsurvey: datebegin_survey,
			endsurvey: dateend_survey,
			compilation: selectedQues,
			checkboxselection1: checkboxselection1, checkboxselection2: checkboxselection2, checkboxselection3: checkboxselection3, checkboxselection4: checkboxselection4, checkboxselection5: checkboxselection5,
			reportidselected: reportidselected,
			BEGINENDSURVEYDATESELECTED: CombinedSelectedDate,
			availableTo:availableTo,availableIdList:availableIdList,
			scope: scope
		};
	}else {
		var urlEvent = "survey.saveReportFromExport";
		var dataParam = {
			txt_reportname: reportNameToSave,
			beginsurvey: datebegin_survey,
			endsurvey: dateend_survey,
			selectedQuestionIdReporting: selectedQues,
			radio_SelectedreportType: selectedradioval,
			BEGINSURVEYTEXT: dateStartText,
			ENDSURVEYTEXT: dateEndText,
			selectedMatrixRowId: selectedMatrixRowId,
			availableTo:availableTo, availableIdList:availableIdList,
			chkbx_report1: checkboxselection1, chkbx_report2: checkboxselection2, chkbx_report3: checkboxselection3, chkbx_report4: checkboxselection4, chkbx_report5: checkboxselection5,
			scope: scope
		};
	}
	//console.log(selectedQues);
	var _current_time_cache = new Date().getTime();
	$j.ajax({
		url: root+urlEvent+"&currenttimestamp="+_current_time_cache,
		data:dataParam,
		type: "POST",
		beforeSend: function() {
			//showLoadingOverlay();
		},
		success : function(response) {
			//console.log(response);
			if (urlEvent == "survey.saveReportFromExport") {
				$j('#hdn_txt_ReportName').val(reportNameToSave);
				var parsedjson = jQuery.parseJSON(response);
				$j('#hdn_txt_ReportID').val(parsedjson.reportid);
			}
		},	
		complete: function() {},
		error: function() {
				console.log("failure");
				hideLoadingOverlay();
			}
		});
}	

function SurveyQuestionsSelection(SelectionType)
{
	showLoadingOverlay();
	checkSession();
	//this is to empty the hidden filed when the all data is clicked	
	var sdate = formData.startPeriod;		
	var edate = formData.endPeriod;
	var selSurveys = formData.selectedSurveysList;
	var selectedprograms = $j("#pgmid").val();
	
	var dataArg = {
		programID: selectedprograms,
		SelectedbeginDate: sdate,
		SelectedendDate: edate,
		checkedSurveys: selSurveys
	}
	document.getElementById("selectedQuestionIdReporting").value = "";
	document.getElementById("selectedMatrixRowId").value = "";
	document.getElementById("btnsetselecteddata").style.display = 'none'; //hide the Set button
		
	if (SelectionType == "alldata")
	{
		
		document.getElementById("SelectedDataQuestionsDiv").style.display = 'none';
		document.getElementById("SelectedReportQuestionsDiv").style.display = 'none';
		document.getElementById("tableReportSaving").style.display = 'none';
		document.getElementById("SelectedDataDiv").style.display = 'none';
		document.getElementById("btnsetselecteddata").style.display = 'block'; //show the Set button
		
		//getting rid of the report saving and availability area
		ClearReportGenerationArea();
		
		hideLoadingOverlay();
	}
	if (SelectionType == "selecteddata")
	{
		document.getElementById("btnsetselecteddata").style.display = 'none'; //hide the Set button

		$j.ajax({
			url: 'index.cfm?event=survey.showquestionidsforexport' ,
			data : dataArg,
			//async:false,
			type: "POST",
			beforeSend: function(){			
			 },
			success:function(returnHtml)
			{				
				$j('#SelectedDataQuestionsDiv').html(returnHtml);
				$j('#SelectedDataQuestionsDiv').slideDown(100);

				//div for reports
				document.getElementById("showorhidequestions").innerHTML = "Only Display Selected Items";
				document.getElementById("SelectedReportQuestionsDiv").style.display = 'none';
				
				//getting the selected or all data link disappear
				document.getElementById("SelectedDataDiv").style.display = 'none';
			
				//getting rid of the report saving and availability area
				ClearReportGenerationArea();

				hideLoadingOverlay();
			},
			complete:function()
			{			
			},
			error :function()
			{
				alert('Oops...mistake on server');				
				//getting the selected or all data link disappear
				document.getElementById("SelectedDataDiv").style.display = 'none';		
				//getting rid of the report saving and availability area
				ClearReportGenerationArea();				
				hideLoadingOverlay();
			}
		});
	}
	if (SelectionType == "selectedreport")
	{
		
		var scopePassed = document.getElementById("scope").value;
		var dataArg = {
			SelectedbeginDate: sdate,
			SelectedendDate: edate,
			scope: scopePassed			
		}
		new Ajax.Request("/index.cfm?event=survey.getallreportnamesforexport",{ //&scope="+scopePassed
		method: 'post',
		parameters: dataArg,			
		onSuccess: function(returnHtml) {
			Element.update("SelectedReportQuestionsDiv", returnHtml.responseText); 
			//div for questions showing
			selectedCheckBox = document.getElementById("hdn_SelectdReportRadio").value;			
			var chkbxs = document.getElementsByName('radio_ReportIDSelection');			
			var _showSetButton = false;			
			for(var i = 0; i < chkbxs.length; i++){				
				if(chkbxs[i].getAttribute("type") == "radio"){
					_showSetButton = true;
				}
				if(chkbxs[i].getAttribute("report-id") == selectedCheckBox){
					chkbxs[i].checked = true;
					break;
				}
			}
			Effect.Appear('SelectedReportQuestionsDiv');			

			//div for questions showing
			document.getElementById("SelectedDataQuestionsDiv").style.display = 'none';
			if (chkbxs.length && _showSetButton) {
				document.getElementById("btnsetselecteddata").style.display = 'block'; //show the Set button
			}
			document.getElementById("SelectedDataDiv").style.display = 'none';
			
			//getting rid of the report saving and availability area
			ClearReportGenerationArea();
			
			//div for reports
			//document.getElementById("SelectedReportQuestionsDiv").style.display = 'block';
			
			hideLoadingOverlay();
			//document.getElementById("CategoryTable").style.display = 'block';
			
			}, 
			onFailure: function()
			{ 
				alert('Oops...mistake on server');
				document.getElementById("radio_SelectedreportType_alldata").checked = true;
				hideLoadingOverlay();
			} 
		});
	}
}

function ClearReportGenerationArea()
{
	//this is to hide the report saving name block
	document.getElementById("tableReportSaving").style.display = "none";
	
	//this is to hide whether to show the report in other scopes
	document.getElementById("ReportAvailableTable").style.display = "none";
	
	//making the text null when no quesiton selected
	document.getElementById("txt_ReportName").value = "";
	
	//making the text character counter back to 40
	document.getElementById("txt_ReportName_cnt").innerHTML = 140;
	
	//making the selected question hidden field to null
	document.getElementById("selectedQuestionIdReporting").value = "";
}

function EditSurveyReport(passedReportID,passedScope)
{
	document.getElementById("hdn_SelectdReportRadio").value = passedReportID;
	winHeight = window.innerHeight;
	popupHeight = 600;
	if(winHeight >= 600)
		popupHeight = 600;
	else	
		popupHeight = winHeight - 20;
					
	var sdate = formData.startPeriod;		
	var edate = formData.endPeriod;
	ColdFusion.Window.create("ReportEditingWindow","Edit Saved Report","index.cfm?event=survey.editselectionwithid&passedScope="+passedScope+"&editreportid="+passedReportID+"&SelectedbeginDate="+sdate+"&SelectedendDate="+edate,{modal:true,width:552,height:600,center:true,draggable:true});

	//document.getElementById(ColdFusion.Window.getWindowObject("ReportEditingWindow").header.id).className = "windowHdr";	
	document.getElementById(ColdFusion.Window.getWindowObject("ReportEditingWindow").header.id).style.display = "block";
}

function CloneSurveyReport(passedReportID,passedScope)
{
	winHeight = window.innerHeight;
	popupHeight = 600;
	if(winHeight >= 600)
		popupHeight = 600;
	else	
		popupHeight = winHeight - 20;
	
	var sdate = formData.startPeriod;		
	var edate = formData.endPeriod;
	ColdFusion.Window.create("ReportCloningWindow","Clone Saved Report","index.cfm?event=survey.cloneselectionwithid&passedScope="+passedScope+"&editreportid="+passedReportID+"&SelectedbeginDate="+sdate+"&SelectedendDate="+edate,{modal:true,width:552,height:600,center:true,draggable:true})
	document.getElementById(ColdFusion.Window.getWindowObject("ReportCloningWindow").header.id).style.display = "block";
}

function CloseReportEditingWindow() {
	setTimeout("ColdFusion.Window.hide('ReportEditingWindow')",100);
	//ColdFusion.Window.destroy('ReportEditingWindow',true);
}

function CloseReportCloningWindow() {
	setTimeout("ColdFusion.Window.hide('ReportCloningWindow')",100);
	//ColdFusion.Window.destroy('ReportCloningWindow',true);
}

function ConfirmReportDeletion(scopePassed,programID,reportID,surveyName,reportName)
{
	var reportNameUnformated = reportName;
	reportName = reportNameUnformated.replace(/`~`/g, '\"');
	reportName = reportName.replace(/`\^`/g, "\'");
	
	if (reportID == 0) {
		var userSelection = true;
	}
	else {
		var dialogMessage = "Are you sure that you want to delete the report called \"" + reportName+ "\".\n\n";
		dialogMessage = dialogMessage + "Deleting this report will only delete this one saved presentation of your data. Your "+ surveyName + " data will be saved."
		var userSelection = confirm(dialogMessage);
	}
	
	//if the user selected ok
	if (userSelection) {
		new Ajax.Request("/index.cfm?event=survey.deleteSurveyReportFromExport",{ 
		method: "post",
		parameters: {programID: programID, reportID: reportID},
		onSuccess: function(returnHtml) {
			var parsedjson = $j.parseJSON(returnHtml.responseText);
			//console.log(parsedjson); 
			/* Element.update("SelectedReportQuestionsDiv", returnHtml.responseText); 
			Effect.Appear("SelectedReportQuestionsDiv"); */
			if (parsedjson == "success"){
				$j("tr.report_"+reportID).remove();
				if ($j('input[type=radio][name=radio_ReportIDSelection]').length){
					$j('input[type=radio][name=radio_ReportIDSelection]:first').prop('checked',true).focus();
				}else{
					Element.update("SelectedReportQuestionsDiv", '<table><tbody><tr><td style="font-weight:normal;" align="left">You do not have any available saved report forms.<br><br>To view data, please select "All Data" or "Customize".</td></tr></tbody></table>');
				}
			}
		}, 
		onFailure: function() { 
			alert('Oops...something went wrong.');
		} 
		});
	}
	
}

//FUNCTION for carrying out validations in the report editting pop up
function checkreportEditValidation()
{
	if (document.getElementById("txt_selectedquestionidfileidlist").value == '') {
	//if no questions are selected
		alert("Please select atleast one question.");
	}
	else {
		//if questions are already selected
		
		//if no name is given for the project
		if (document.getElementById("txt_ReportNameEdit").value == '') {
			alert("Please give a name for the report.");
		}
		else {
			checkalreadythere = 0;
			
			//var Scope = document.getElementById("scopeSelected").value.trim();
			if( !checkReportNameAvailability('txt_ReportNameEdit') )
			return false;
			
			if (checkalreadythere) {
				alert("This report already exists for the program.\nPlease select another name for your report.");
				document.getElementById("txt_ReportNameEdit").value = '';
				document.getElementById("txt_ReportNameEdit_cnt").value = '140';
			}
			else {				 
				var selectedDateBegin = formData.startPeriod;
				var selectedDateEnd = formData.endPeriod;
				var dateStartText = $j("#beginsurvey option:selected").text();
				var dateEndText = $j("#endsurvey option:selected").text();
				var availableTo = $j("input[name=savSel_availToedit]:checked").val();
				var availableIdList = "";
				if(availableTo == 'staffroles') {
					availableIdList = $j("input[type=checkbox][name=roleid_report]:checked").map(function() {return this.value;}).get().join(',');
				} else if (availableTo == 'owner') {
					availableIdList = $j("#currentUserId").val();
				}

				//var submitFunc = function(selectedIDs, notSelectedIDs){
					/* try {
						multipleSurveyWindowClose();
					} catch (e) { notSelectedIDs = '';} */
					//if (!notSelectedIDs) notSelectedIDs = '';
					var scopePassed = document.getElementById("scope").value;
					var reportNameEntered = document.getElementById("txt_ReportNameEdit").value;
					var CombinedSelectedDate = dateStartText + '~`' + dateEndText;
					var checkboxselection1 = 0;
					if (document.getElementById("chkbx_report1edit").checked) {
						checkboxselection1 = document.getElementById("chkbx_report1edit").value;
					}
					var checkboxselection2 = 0;
					if (document.getElementById("chkbx_report2edit").checked) {
						checkboxselection2 = document.getElementById("chkbx_report2edit").value;
					}
					var checkboxselection3 = 0;
					if (document.getElementById("chkbx_report3edit").checked) {
						checkboxselection3 = document.getElementById("chkbx_report3edit").value;
					}
					var checkboxselection4 = 0;
					if (document.getElementById("chkbx_report4edit").checked) {
						checkboxselection4 = document.getElementById("chkbx_report4edit").value;
					}
					var checkboxselection5 = 0;
					if (document.getElementById('chkbx_report5edit') != null && document.getElementById("chkbx_report5edit").checked) {
						checkboxselection5 = document.getElementById("chkbx_report5edit").value;
					}
					var reportidselected = document.getElementById("selectedReportID").value;
					var compilationSelected = document.getElementById("txt_selectedquestionidfileidlist").value;

					new Ajax.Request("/index.cfm?event=survey.updatesurveyreportid", {
						method: "post",
						/* Removing few arg as they are not set here, notSelectedIDs: notSelectedIDs  */
						parameters: { reportNameEntered: reportNameEntered, beginsurvey: selectedDateBegin, endsurvey: selectedDateEnd, compilation: compilationSelected, checkboxselection1: checkboxselection1, checkboxselection2: checkboxselection2, checkboxselection3: checkboxselection3, checkboxselection4: checkboxselection4, checkboxselection5: checkboxselection5, reportidselected: reportidselected, BEGINENDSURVEYDATESELECTED: CombinedSelectedDate,availableTo:availableTo,availableIdList:availableIdList, scope: scopePassed},
						onSuccess: function(returnHtml){
							SurveyQuestionsSelection("selectedreport");
							CloseReportEditingWindow();
						},
						onFailure: function(){
							alert('Oops...mistake on server');
						}
					});
			}
		}
	}
}

function ShowSelectedDataEdit()
{
	// these all are the selected programs	
	var selprograms = document.getElementById("pgmid").value;
	//selected questions list
	var selectedQuestionidFileidlist = document.getElementById("txt_selectedquestionidfileidlist").value;

	if (document.getElementById("showorhidequestionsedit").innerHTML == "Only Display Selected Items") {
			document.getElementById("img_reportedit").style.display = 'block';					

			//ajax call
			new Ajax.Request("/index.cfm?event=survey.showselectedquestiondatafromhiddenfield",{ 
			method: "post",
				parameters: {
					selectedQuestionidFileidlist: selectedQuestionidFileidlist,
					selprograms: selprograms
				},
			onSuccess: function(returnHtml) { 
				Element.update("SelectedDataQuestionsDivEdit", returnHtml.responseText); 
				Effect.Appear("SelectedDataQuestionsDivEdit");
				
				//changing the link text
				document.getElementById("showorhidequestionsedit").innerHTML = 'Display All Items';
				
				document.getElementById("img_reportedit").style.display = 'none';
				}, 
				onFailure: function()
				{ 
					alert('Oops...mistake on server');
				} 
			});
		}
		else {
			//loading the image loader
			document.getElementById("img_reportedit").style.display = 'block';
	
			//ajax call
			new Ajax.Request("/index.cfm?event=survey.getCategoryDetailseditforExport",{ 
				method: "post",
				parameters: {
					selectedQuestionidFileidlist: selectedQuestionidFileidlist,
					selprograms: selprograms,
					SelectedbeginDate: formData.startPeriod,
					SelectedendDate: formData.endPeriod
				},
				onSuccess: function(returnHtml) { 
				Element.update("SelectedDataQuestionsDivEdit", returnHtml.responseText); 
				Effect.Appear("SelectedDataQuestionsDivEdit");
				
				document.getElementById("showorhidequestionsedit").innerHTML = 'Only Display Selected Items';
				
				document.getElementById("img_reportedit").style.display = 'none';
				}, 
				onFailure: function()
				{ 
					alert('Oops...mistake on server');
				} 
			});			
		}	
}

function closeandOpenEachCategoryQuestions1(passedCategoryID)
{
	var passedCategoryID = passedCategoryID ;
	var imagenameid = "img1_"+passedCategoryID;
	var trid = "tr1_"+passedCategoryID;
	document.getElementById(imagenameid).style.display = "block";
	if (document.getElementById(trid).style.display != 'none') {
		document.getElementById(trid).style.display = "none";
	}
	else {
		document.getElementById(trid).style.display = "block";
	}
	document.getElementById(imagenameid).style.display = "none";
}

function assignQuestiontoHiddenFieldReportEdit(passedQuestionID)
{

	if (document.getElementById("txt_selectedquestionidfileidlist").value == '') {// if there is no elemen selected
		document.getElementById("txt_selectedquestionidfileidlist").value = passedQuestionID;
	}
	else {

		document.getElementById("showorhidequestions").style.display = 'block';
		var hiddenvalue = document.getElementById("txt_selectedquestionidfileidlist").value;
		
		var hiddenvaluearray = hiddenvalue.split('^^^');
		var elementexists = 0;
		
		for(var i =0;i<hiddenvaluearray.length;i++)
		{
			if (hiddenvaluearray[i] == passedQuestionID) {			
				hiddenvaluearray.splice(hiddenvaluearray.indexOf(hiddenvaluearray[i]),1);
				elementexists = 1;
			}
		}

		if (elementexists != 1) {
			if (document.getElementById("txt_selectedquestionidfileidlist").value != '') {
				document.getElementById("txt_selectedquestionidfileidlist").value = document.getElementById("txt_selectedquestionidfileidlist").value + "^^^" + passedQuestionID;
			}
			else {
				document.getElementById("txt_selectedquestionidfileidlist").value =  passedQuestionID;
			}
		}
		else {				
			document.getElementById("txt_selectedquestionidfileidlist").value = '';
			for(var i =0;i<hiddenvaluearray.length;i++)
			{
				if (hiddenvaluearray[i] != passedQuestionID) {
					if (document.getElementById("txt_selectedquestionidfileidlist").value == '') {
						document.getElementById("txt_selectedquestionidfileidlist").value = hiddenvaluearray[i];
					}
					else {
						document.getElementById("txt_selectedquestionidfileidlist").value =  document.getElementById("txt_selectedquestionidfileidlist").value + "^^^" + hiddenvaluearray[i];
					}
				}	
			}
		}			
	}
	
	
	if (document.getElementById("txt_selectedquestionidfileidlist").value == "") {
		document.getElementById("showorhidequestionsedit").innerHTML == "Only Display Selected Items";
		ShowSelectedDataEdit();
	}	
}

function displayDataForCategoryReportedit1(categoryname,selPrograms,imgname)
{
	try {
		selectedQuestions = document.getElementById("txt_selectedquestionidfileidlist").value;
		selectedQuestions = selectedQuestions.replace(/,/g, '^^^');
	}
	catch(err) {
		selectedQuestions = document.getElementById("getCurrentQuestionIDFileIDList").value;
		selectedQuestions = selectedQuestions.replace(/,/g, '^^^');
	}
	
	imgnamepassed = "img_"+imgname+"edit1";

	if (categoryname == 'alrq') {
		if (document.getElementById("trreqquestioncheckboxedit1").style.display == 'none')
		{
			document.getElementById(imgnamepassed).style.display = 'block';
			new Ajax.Request("/index.cfm?event=survey.getdataforsurveycategoryreporteditafterselectingall&categoryname="+categoryname+"&selPrograms="+selPrograms+"&imgname="+imgname+"&selectedQuestions="+selectedQuestions,{ 
			onSuccess: function(returnHtml) { 
			document.getElementById("trreqquestioncheckboxedit1").style.display = 'block';
			Element.update("tdreqquestioncheckboxedit1", returnHtml.responseText); 
			document.getElementById(imgnamepassed).style.display = 'none';
			}, 
			onFailure: function()
			{ 
				alert('Oops...mistake on server');
			} 
			});
		}
		else {
			trclose('trreqquestioncheckboxedit1');
		}
	}
	if (categoryname == 'alretq') {
		
		if (document.getElementById("trretquestioncheckboxedit1").style.display == 'none') {
			
			document.getElementById(imgnamepassed).style.display = 'block';
			new Ajax.Request("/index.cfm?event=survey.getdataforsurveycategoryreporteditafterselectingall&categoryname="+categoryname+"&selPrograms="+selPrograms+"&imgname="+imgname+"&selectedQuestions="+selectedQuestions,{ 
			onSuccess: function(returnHtml) { 
		
			document.getElementById("trretquestioncheckboxedit1").style.display = 'block';
			Element.update("tdretquestioncheckboxedit1", returnHtml.responseText); 
			document.getElementById(imgnamepassed).style.display = 'none';
			}, 
			onFailure: function()
			{ 
				alert('Oops...mistake on server');
			} 
			});
		}
		else {
			trclose('trretquestioncheckboxedit1');
		}
	}
	if (categoryname != 'alretq' && categoryname != 'alrq') {
		categorynamefortableelements = categoryname.replace(/ /g, '');
		trcategorynamedatarow = "tr_"+categorynamefortableelements+"_datarowedit1";
		tdcategorynamedatarow = "td_"+categorynamefortableelements+"_datarowedit1";
		
		if (document.getElementById(trcategorynamedatarow).style.display == 'none') {
			document.getElementById(imgnamepassed).style.display = 'block';
			categoryname = categoryname.replace(/&/g, 'amper~~');
			imgname = imgname.replace(/&/g, 'amper~~');
			new Ajax.Request("/index.cfm?event=survey.getdataforsurveycategoryreporteditafterselectingall&categoryname="+categoryname+"&selPrograms="+selPrograms+"&imgname="+imgname+"&selectedQuestions="+selectedQuestions,{ 
			onSuccess: function(returnHtml) { 
			document.getElementById(trcategorynamedatarow).style.display = 'block';
			Element.update(tdcategorynamedatarow, returnHtml.responseText); 
			document.getElementById(imgnamepassed).style.display = 'none';
			}, 
			onFailure: function()
			{ 
				alert('Oops...mistake on server');
			} 
			});
		}
		else {
			trclose(trcategorynamedatarow);
		}
	}
}

$j(document).on('click', '.matrix-row-select', function(e){
//$j(".matrix-row-select").click(function(){
	var href = $j(this).attr('href');
	var relName = $j(this).attr('rel');
	newStr = href.split("_");
	qid = newStr[1];
	if($j(this).text().trim() == 'Select All')
	{
		$j(this).text('Select None');
		
		if($j("#"+href + " input[type=checkbox]:checked").length > 0)
		{
			$j("#"+href + " input[type=checkbox]:not(:checked)").each(function(){
				//$j(this).attr("checked","checked");
				document.getElementById($j(this).attr("id")).checked = true;
				assignMatrixRowstoHiddenField($j(this).attr("id"));				
			});				
		}else{
			$j("#"+href + " input[type=checkbox]").each(function(){
				//$j(this).attr("checked","checked");
				//$j("input[name='"+relName+"']").attr("checked","checked");
				document.getElementById($j(this).attr("id")).checked = true;
				assignMatrixRowstoHiddenField($j(this).attr("id"));				
			});
		}
		//question id checkbox
		document.getElementById(relName).checked = true;
		assignQuestiontoHiddenField(relName);
	}
	else
	{
		$j(this).text('Select All');
		$j("#"+href + " input[type=checkbox]:checked").each(function(){
			//$j(this).removeAttr("checked");
			//$j("input[name='"+relName+"']").removeAttr("checked");
			document.getElementById($j(this).attr("id")).checked = false;
			removeMatrixRowstoHiddenField($j(this).attr("id"));			
		});
		//question id checkbox
		document.getElementById(relName).checked = false;
		removeQuestiontoHiddenField(relName);
	}	
	return false;
});

function closeAnswerSection(trnamePassed,process)
{
	if (process == "simple"){
		if (trnamePassed == 'reqquestioncheckbox'){
			trnamePassed = "trreqquestioncheckbox";
			document.getElementById(trnamePassed).style.display = 'none';
		}
		if (trnamePassed == 'retquestioncheckbox'){
			trnamePassed = "trretquestioncheckbox";
			document.getElementById(trnamePassed).style.display = 'none';
		}
		if (trnamePassed != 'reqquestioncheckbox' && trnamePassed != 'retquestioncheckbox'){
			trnamePassed = trnamePassed.replace(/\\/g, '\\\\');
			trnamePassed = trnamePassed.replace(/amper~~/g, '&');
			 trnamePassed =  "tr_"+trnamePassed+"_datarow";
			 document.getElementById(trnamePassed).style.display = 'none';
		}
	}
	else{
		if (trnamePassed == 'reqquestioncheckboxedit'){
			trnamePassed = "trreqquestioncheckboxedit";
		}
		else if (trnamePassed == 'retquestioncheckboxedit'){
			trnamePassed = "trretquestioncheckboxedit";
		}
		else if (trnamePassed == 'reqquestioncheckboxedit1'){
			trnamePassed = "trreqquestioncheckboxedit1";
		}
		else if (trnamePassed == 'retquestioncheckboxedit1'){
			trnamePassed = "trretquestioncheckboxedit1";
		}
		else if (trnamePassed == 'reqquestioncheckboxclone'){
			trnamePassed = "trretquestioncheckboxclone";
		}
		else if (trnamePassed == 'retquestioncheckboxclone'){
			trnamePassed = "trretquestioncheckboxclone";
		}
		else{
			trnamePassed =  "tr_"+trnamePassed+"_datarow";
			trnamePassed = trnamePassed + process;
		}
		document.getElementById(trnamePassed).style.display = 'none';
	}	
}
/* End- Step-5 */

$j(document).on('change', '#sharedfields', function(e) {
	if($j(this).is(":checked")) {
		$j('#sharedfieldslist').slideDown(700);
		if($j('.sharedFieldsOptionsList:visible').length > 1) {
			$j('#selectallsharedfields').html('Select All');
			$j('#selectallsharedfields').css('display','block');			
		} else {
			$j('#selectallsharedfields').css('display','none');
		}
	} else {
		$j('.sharedFieldsOption').prop('checked',false); 
		$j('#sharedfieldslist').slideUp(700);
	}
});

$j(document).on('change', '#edit_sharedfields', function(e) {
	if($j(this).is(":checked")) {
		$j('#edit_sharedfieldslist').slideDown(700);
		if($j('.edit_sharedFieldsOptionsList:visible').length > 1) {
			$j('#edit_selectallsharedfields').html('Select All');
			$j('#edit_selectallsharedfields').css('display','block');	
		} else {
			$j('#edit_selectallsharedfields').css('display','none');
		}
	} else {
		$j('.edit_sharedFieldsOption').prop('checked',false); 
		$j('#edit_sharedfieldslist').slideUp(700);
	}
});

$j(document).on('click', '.selectallsharedfields', function(e) {																	
	if($j('#selectallsharedfields').html() == 'Select All') {
		$j('#selectallsharedfields').html('Select None');
		$j('.sharedFieldsOption:visible').prop('checked',true);
	} else {
		$j('#selectallsharedfields').html('Select All');
		$j('.sharedFieldsOption:visible').prop('checked',false);
	}
});

$j(document).on('click', '.edit_selectallsharedfields', function(e) {																	
	if($j('#edit_selectallsharedfields').html() == 'Select All') {
		$j('#edit_selectallsharedfields').html('Select None');
		$j('.edit_sharedFieldsOption:visible').prop('checked',true);
	} else {
		$j('#edit_selectallsharedfields').html('Select All');
		$j('.edit_sharedFieldsOption:visible').prop('checked',false);
	}
});

$j(document).on('change', '.sharedFieldsOption', function(e) {
	var sharedFieldsOptionCount = $j('.sharedFieldsOption:visible').length;
	var sharedFieldsOptionCheckedCount = $j('.sharedFieldsOption:visible:checked').length;
	if(sharedFieldsOptionCount === sharedFieldsOptionCheckedCount) {
		$j('#selectallsharedfields').html('Select None');		
	} else {
		$j('#selectallsharedfields').html('Select All');		
	}		
});

$j(document).on('change', '.edit_sharedFieldsOption', function(e) {
	var sharedFieldsOptionCount = $j('.edit_sharedFieldsOption:visible').length;
	var sharedFieldsOptionCheckedCount = $j('.edit_sharedFieldsOption:visible:checked').length;
	if(sharedFieldsOptionCount === sharedFieldsOptionCheckedCount) {
		$j('#edit_selectallsharedfields').html('Select None');		
	} else {
		$j('#edit_selectallsharedfields').html('Select All');		
	}		
});

function enableSharedFields() {
	var sharedFieldsCount = 0;
	var bgSelected = formData.userSelectedGroups;
	var bgSelectedCount = bgSelected.split(',').length;
	if(bgSelectedCount > 1) {
		$j('input.assoattributeindvalue_field:checked').each(function( index,element ) {
			var attrId = $j(this).val();			
			var identifierAttributeCheckedCount = $j('.assoattributeindvalue_field_' + attrId + ':checked').length;		
			if(bgSelectedCount == identifierAttributeCheckedCount) {
				if($j('#sharedfields').prop('disabled') == true) {
					$j('#sharedfields').prop('disabled',false);
				}
				$j('.sharedFieldsOptionsList_' + attrId).css('display','block');
				sharedFieldsCount = sharedFieldsCount + 1;
			}
		});
		
		$j('input.assoattributeindvalue_field:not(:checked)').each(function( index,element ) {
			var attrId = $j(this).val();	
			$j('.sharedFieldsOption_' + attrId).prop('checked',false);
			$j('.sharedFieldsOptionsList_' + attrId).css('display','none');
		});
		
		if($j('.sharedFieldsOptionsList:visible').length > 1) {
			$j('#selectallsharedfields').css('display','block');
			$j('#selectallsharedfields').html('Select All');
		} else {
			$j('#selectallsharedfields').css('display','none');
		} 
	}
	
	if(sharedFieldsCount == 0) {
		disableSharedFields();
	}
}

function disableSharedFields() {		
	$j('.sharedFieldsOption').prop('checked',false);	
	$j('#sharedfieldslist').css('display','none');
	$j('.sharedFieldsOptionsList').css('display','none');
	$j('#sharedfields').prop('checked',false);
	$j('#sharedfields').prop('disabled',true);			
}

function edit_enableSharedFields() {
	var edit_SharedFieldsCount = 0;
	var bgSelected = formData.userSelectedGroups;
	var bgSelectedCount = bgSelected.split(',').length;
	if(bgSelectedCount > 1) {
		$j('input.edit_assoattributeindvalue_field:checked').each(function( index,element ) {
			var attrId = $j(this).val();
			
			var identifierAttributeCheckedCount = $j('.edit_assoattributeindvalue_field_' + attrId + ':checked').length;		
			if(bgSelectedCount == identifierAttributeCheckedCount) {
				if($j('#edit_sharedfields').prop('disabled') == true) {
					$j('#edit_sharedfields').prop('disabled',false);
				}
				$j('.edit_sharedFieldsOptionsList_' + attrId).css('display','block');
				edit_SharedFieldsCount = edit_SharedFieldsCount + 1;
			}
		});
		
		$j('input.edit_assoattributeindvalue_field:not(:checked)').each(function( index,element ) {
			var attrId = $j(this).val();	
			$j('.sharedFieldsOption_' + attrId).prop('checked',false);
			$j('.sharedFieldsOptionsList_' + attrId).css('display','none');
		});
		
		if($j('.edit_sharedFieldsOptionsList:visible').length > 1) {
			$j('#edit_selectallsharedfields').css('display','block');
			$j('#edit_selectallsharedfields').html('Select All');
		} else {
			$j('#edit_selectallsharedfields').css('display','none');
		}
	}
	
	if(edit_SharedFieldsCount == 0) {
		edit_disableSharedFields();
	}
}

function edit_disableSharedFields() {		
	$j('.edit_sharedFieldsOption').prop('checked',false);	
	$j('#edit_sharedfieldslist').css('display','none');
	$j('.edit_sharedFieldsOptionsList').css('display','none');
	$j('#edit_sharedfields').prop('checked',false);
	$j('#edit_sharedfields').prop('disabled',true);	
}

$j(document).on('click', '#filterbyfieldlink', function(e) {		
	var selectedGroupList = formData.userSelectedGroups;	
	var associationid = selectedGroupList;			
	
	if($j('#filterbyfieldlisting').css('display') == 'block') {
		$j('#filterbyfieldlisting').slideUp(700);
	} else {
		if(filterFieldValuesStatus == 1) {
			$j('#filterbyfieldlisting').slideDown(700);
		} else {	
			var loadUrl="index.cfm?event=survey.getTotalProfileField";
			$j.ajax({			
				url: loadUrl,
				data : {association:associationid,checkedValue:"TF"},
				type: "POST",												
				beforeSend: function() {
					showLoadingOverlay();
				},						
				success:function(response) {				
					$j("#filterbyfieldlisting").html(response);
					$j('#filterbyfieldlisting').slideDown(700);	
					filterFieldValuesStatus = 1;
				},
				complete:function() {
					hideLoadingOverlay();									
				},
				error :function() {
				  alert('error occurred!!');
				}
			});	
		}
	}
});

function checkProfileAndFieldsAvailability() {
	var selectedGroupList = formData.userSelectedGroups;
	/**Start: Check Total Profile Field Available for Selected Group(If not Disabled Checkbox)*/
	$j('#filterbyfield').hide();
	var loadUrl="index.cfm?event=survey.getTotalProfileAndIdentifierFieldCount";
	$j.ajax({			
		url: loadUrl,
		data : {association:selectedGroupList},
		type: "POST",												
		beforeSend: function(){
				showLoadingOverlay();
		},						
		success:function(response)
		{			
			var jparse=JSON.parse(response);				
			if($j("#ProfileField").prop("checked") == true) {
				$j("#ProfileField").prop("checked", false);
				$j(".attributeindvalue").prop("checked", false);
				$j(".groupProfileType").prop("checked", false);	
				$j("#totalprofilefield").css("display","none");
			}
			if(jparse.profilefield==0){			
				$j("#totalprofilefield").css('display','none');
				$j("#profileFieldOption").css('display','none');
				//$j("#ProfileField").prop("disabled", true);
				
				if(formData.userSelectedAction == 'viewData') {
					$j('#filterbyfield').hide();
					$j('#filterbyfieldlisting').css('display','none');	
					$j("#filterbyfieldsection").css('display','none');
					/*$j("#filterbyfieldsection").css('color','#999999');
					$j("#filterbyfieldsection").html('<a style="color:#999999;text-decoration: underline;" disabled="true">Filter by field</a> (Fields have not been available for this Group)');*/
				}
			} else {
				//$j("#ProfileField").prop("disabled", false);
				$j("#profileFieldOption").css('display','block');
				if(formData.userSelectedAction == 'viewData') {
					$j('#filterbyfield').show();
					$j("#filterbyfieldsection").css('display','block');
					$j('#filterbyfieldlisting').css('display','none');					
					$j("#filterbyfieldsection").html('<a id="filterbyfieldlink" href="javascript:void(0);">Filter by field</a>');
				}
			}
							
			if($j("#incudeIdentifier").prop("checked")) {
				$j("#incudeIdentifier").prop("checked", false);					
				$j(".assoattributeindvalue_field").prop("checked", false);
				$j(".assoattributeindvalue_panel").prop("checked", false);
				$j(".groupIdentifierType").prop("checked", false);
				$j("#arrangepanelfields").css("display","none");
				$j("#includeIdentifierfield").css("display","none");
				
				$j(".sharedFieldsOption").prop("checked",false);
				$j("#sharedfieldslist").css("display","none");
				$j("#sharedfields").prop("checked",false); 					
				$j("#sharedfields").prop("disabled",true);					
			}
			if(jparse.IncludeIdentifier==0){					
				//$j("#incudeIdentifier").prop("disabled", true);
				$j("#incudeIdentifierOption").css("display","none");
				$j("#sharedfieldsOption").css("display","none");
				$j("#lblIdentifierFields").css("display","none");
				$j("#lblIdentifierFieldsSelected").css("display","none");
			} else {
				$j("#incudeIdentifierOption").css("display","block");
				$j("#sharedfieldsOption").css("display","block");
				$j("#lblIdentifierFields").css("display","block");
				$j("#lblIdentifierFieldsSelected").css("display","block");
			}
			
			if(jparse.profilefield==0 && jparse.IncludeIdentifier==0) {
				$j("#identifierFieldsSection").css("display","none");
			} else {
				$j("#identifierFieldsSection").css("display","block");
			}
			
			$j('#includeIdentifierFields').val(jparse.IncludeIdentifier);
			$j('#selattrgroupcount').val(jparse.profilefield);
			$j('#omitAttributeList').val(jparse.profilefieldidlist);
		},
		complete:function()
		{
			hideLoadingOverlay();									
		},
		error :function()
		{
		  alert('error occurred!!');
		}
	});
	/**End: Check Total Profile Field Available for Selected Group*/
}

function showActiveArchivedIdentifiers(currentAssociationId) {
	
	var check_count = $j('.typeofidentifier_' + currentAssociationId + ':checked').length;
	
	if(check_count == 0){		
		$j('#identifierListing_' + currentAssociationId).hide();	
		$j("#checkboxIdentifierListNone_" + currentAssociationId).show();
		$j('.associationItem_' + currentAssociationId).prop("checked",false);
	} else if(check_count == 2) {	
		$j('#identifierListing_' + currentAssociationId).show();
		$j(".identifiercheckbox_" + currentAssociationId).show();		
		$j("#selectallnone_" + currentAssociationId).html("Select All");
		$j("#checkboxIdentifierListNone_" + currentAssociationId).hide();		
	} else if(check_count == 1) {		
		$j("#checkboxIdentifierListNone_" + currentAssociationId).hide();		
		var check_id = $j('.typeofidentifier_' + currentAssociationId + ':checked').attr("id");
		var check_status = $j("#"+check_id).prop('checked');
		var activeId = "activeStatusIdentifier_" + currentAssociationId;
		var archivedId = "archivedStatusIdentifier_" + currentAssociationId;
		
		if(check_id == activeId){
			if(check_status == true) {
				$j(".identifiercheckbox_" + currentAssociationId).each(function(){										
					if($j(this).attr("attr-iden-status") == "1"){												
						$j(this).show();						
					} else {
						$j(this).find('input[type=checkbox]').prop("checked",false);	
						$j(this).hide();
					}
				});	
				$j("#selectallnone_" + currentAssociationId).html("Select All");
			} else {
				$j(".identifiercheckbox_" + currentAssociationId).each(function(){																							
					if($j(this).attr("attr-iden-status") == "1"){
						$j(this).find('input[type=checkbox]').prop("checked",false);						
						$j(this).hide();						
					}
				});	
			}						
		}		

		if(check_id == archivedId) {
			if(check_status == true) {
				$j(".identifiercheckbox_" + currentAssociationId).each(function(){																									
					if($j(this).attr("attr-iden-status") == "0"){											
						$j(this).show();						
					} else {
						$j(this).find('input[type=checkbox]').prop("checked",false);
						$j(this).hide();
					}
				});
				$j("#selectallnone_" + currentAssociationId).html("Select All");
			} else {
				$j(".identifiercheckbox_" + currentAssociationId).each(function(){
					if($j(this).attr("attr-iden-status") == "0"){
						$j(this).find('input[type=checkbox]').prop("checked",false);						
						$j(this).hide();						
					}
				});
			}			
		}
		$j('#identifierListing_' + currentAssociationId).show();
	}
	
	if($j('#associationFields_' + currentAssociationId + ' option:selected').val() != 0) {
		var fieldValueCount = $j('#fieldValueCount_' + currentAssociationId).val();
		for (var i = 0; i < fieldValueCount; i++) {
			if($j('.associationItem_' + currentAssociationId + '_' + i + ':visible').length == 0) {
				$j('#assoc_itemvalue_title_' + currentAssociationId + '_' + i).css('display','none');
				$j('#assoc_item_title_' + currentAssociationId + '_' + i).css('display','none');
				$j('#itemvaluespace_' + currentAssociationId + '_' + i).css('display','none');
			} else {
				$j('#assoc_itemvalue_title_' + currentAssociationId + '_' + i).css('display','block');
				$j('#assoc_item_title_' + currentAssociationId + '_' + i).css('display','block');
				$j('#itemvaluespace_' + currentAssociationId + '_' + i).css('display','block');
			}
		}		 
	}
		
	var chkCount = $j('.associationItem_' + currentAssociationId + ':visible').not(':checked').length;		
	if(chkCount == 0){
		$j("#selectallnone_" + currentAssociationId).html("Select None");
	} else if(chkCount > 0){
		$j("#selectallnone_" + currentAssociationId).html("Select All");
	}
	
	if($j('.associationItem_' + currentAssociationId + ':visible').length > 0) {		
		$j('#identifierListing_' + currentAssociationId).show();
		$j("#selectallnone_" + currentAssociationId).show();
		$j("#checkboxIdentifierListNone_" + currentAssociationId).hide();		
	} else {
		$j('#identifierListing_' + currentAssociationId).hide();	
		$j("#selectallnone_" + currentAssociationId).hide();
		$j("#checkboxIdentifierListNone_" + currentAssociationId).show();		
	}	
	
	/* Start: Code is Show/Hide Select All/None Link */
	var attridVal = $j('#associationFields_' + currentAssociationId + ' option:selected').val();
	var itemcount = parseInt($j('#fieldValueCount_' + currentAssociationId).val());	
	if(parseInt(attridVal) != 0) {		
		for( var i = 0 ;i < itemcount; i++) {		
			if($j('.identifiercheckbox_' + currentAssociationId + '_' + i + ':visible').length > 1) {
				$j('#assoc_item_title_' + currentAssociationId + '_' + i).css('display','block');
			} else {
				$j('#assoc_item_title_' + currentAssociationId + '_' + i).css('display','none');
			}
			
			var chkitemCount = $j('.associationItem_' + currentAssociationId + '_' + i + ':visible').not(':checked').length;			
			if(chkitemCount == 0){
				$j("#select_all_itemsforfield_" + currentAssociationId + '_' + i).html("Select None");
			} else if(chkCount > 0){
				$j("#select_all_itemsforfield_" + currentAssociationId + '_' + i).html("Select All");
			}
		}				
	}	
		
	if($j('.identifiercheckbox_' + currentAssociationId + ':visible').length > 1) {
		$j('#selectallnone_' + currentAssociationId).show();
	} else {
		$j('#selectallnone_' + currentAssociationId).hide();
	}
	/* End: Code is Show/Hide Select All/None Link */
}

/*SurveyExport-431 */
function checkMultipleSurveyForSurveyExport() {
	$j('#excelExportBtn').prop('disabled', true);
	checkSession();
	setTimeout(function(){
		var siteId = 0;
		var programId = $j('#pgmid').val();
		var dataParam = {
			beginSurvey: document.getElementById('beginsurvey').value,
			endSurvey: document.getElementById('endsurvey').value,
			userid: 0,
			siteId: siteId,
			selprograms: programId
		};
		/* SURVEXPORT-275 */
		if (formData.compilation != ""){
			dataParam.compilation = formData.compilation;
		}/* SURVEXPORT-275 */
		if ($j('.surveyid_list:checked').length == 0) {
			showLoadingOverlay();
			new Ajax.Request('index.cfm?event=survey.checkMultipleSurveysForExport', {
				method: "post",
				parameters: dataParam,
				onSuccess: function(response){
					hideLoadingOverlay();
					var surveyIds = response.responseText.replace(/^\s+|\s+$/g, '');
					if (surveyIds == "") 
						surveyIds = response.responseText.replace(/^\s+|\s+$/g, '');
					if (surveyIds == "") 
						return;
					if (surveyIds == "false") {
						callReportPop();
					} else {
						multipleSurveyWindow(surveyIds);
					}
				},
				onFailure: function(){
					alert('Connection failed');
					$j('#excelExportBtn').prop('disabled', false);
					hideLoadingOverlay();
				}
			});
		} else {
			//submitFucnForSelectedSurveys(submitFunc);
			callReportPop();
		}
		return false;
	},1000);
}
function changeSelectOption() {

	var allSurveyIdsCheckBox = $j('input[type=checkbox].chkBoxSurveys:checked');
	 var arr = [];
	 $j.each(allSurveyIdsCheckBox, function(){
                  arr.push($j(this).val());
	});
	if (arr.length >0) {
		$j("#selectNoOptions").prop('checked', false);
	}
	else {
		$j("#selectNoOptions").prop('checked', true);
	}
}
/* SurveyExport-431 */
