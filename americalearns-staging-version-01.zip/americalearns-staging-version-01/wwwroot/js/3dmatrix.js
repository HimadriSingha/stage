var survey_name = '';
/*This to avoid the conflict caused using '$' in both scriptaculous and jquery.*/
if($j === undefined){
	var $j = jQuery.noConflict();
}
$j(document).ready(function(){
	//$j('.required').hide();
	//$j('.optional').hide();
	survey_name = $j('#survey_name').val();
	//console.log(survey_name);
	
	chkImage = "<img src='../../images/icons/check20.gif' style='padding:5px 0px;'>";/*---SQM-816-ui */
});

//3D Matrix Rows Add
function rowsLabelAdd(num,qcount){
	addAnother = "<div id='add_another_row' ><a href=\"javascript:rowsLabelAdd("+num+","+qcount+");\">Add Another Row</a></div>";
	moveUp = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabel_moveUp("+num+",upID);\">Move Up</a></div>";
	moveDown = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabel_moveDown("+num+",downID);\">Move Down</a></div>";
	
	var count = $j("#matrix_"+num+"_row_count").val();
	var rowLength = $j("#matrix_"+num+"_row .rowsLabelList tr").length;
	var rowItem = $j("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+rowLength+"_name']").val();
	var stepText = "["+document.getElementById("jSubNumbering_"+num).innerText +"]";
	stepCounter = qcount-num+1;
	//SQM-965
	var dividcount=rowLength+1;
	helpTextDiv='<div id="helptextdiv_'+num+dividcount+'" class="help_text_div" style="display: none;"><div style="display:grid"><label class="helplabel" style="margin-top: 0px;">Row '+dividcount+'\'s Help Text:</label><textarea id="helptextarea'+num+dividcount+'" name="helptextarea'+num+dividcount+'" class="helptextarea'+num+'" style="width: 395px;height: 70px;" rows="3" cols="60" onKeyDown="CountLeft(this,500);" onKeyUp="CountLeft(this,500);" onFocus="CountLeft(this,500);" onfouceout="CountLeft(this,500);" onchange="helptextDisplay('+num+',this,'+dividcount+');CountLeft(this,500);" rindex='+dividcount+' num='+num+'></textarea><div style="padding-left: 254px;margin-top:3px;text-align: right;"><span id="helptextarea'+num+dividcount+'_cnt">500</span> characters remaining</div><div class="deletehelptextlink_'+num+dividcount+' helpdelete"><a href="javascript:void(0)" class="deletehelptext" onclick="closetext('+num+','+dividcount+');"><img src="../images/icons/delete.png" width="15" height="15" style="vertical-align:text-bottom;">\ \Remove the "Help Text" for this row.</a></div></div></div>';

	
	//showtext = "<div id='add_help_text_show_"+num+dividcount+"' style='float:left; padding:0px 15px 15px 0px;display:none;'><a href=\"javascript:helptext("+num+","+dividcount+");\">Show | Edit Help Text (Row "+dividcount+")</a></div>";
	//closetext = "<div id='add_help_text_edit_"+num+dividcount+"' style='float:left; padding:0px 15px 15px 0px;display:none;'><a href=\"javascript:closetext("+num+","+dividcount+");\">Hide | Edit Help Text (Row "+dividcount+")</a></div>";
	optionaltext = "<div class='addHelpText' id='add_help_text_"+num+dividcount+"' style='float:left; padding:10px 15px 0px 0px;'><a href=\"javascript:helptext("+num+","+dividcount+");\">Optional: Add \"Help Text\" for this row.</a></div>";

	
	if(rowItem != ""){
		count = parseInt(count)+1;
		$j("#matrix_"+num+"_row_count").val(count);
		$j("#matrix_"+num+"_row #add_another_row").hide();
		
		var rowCount = $j("#matrix_"+num+"_row .rowsLabelList tr").length + 1;
		
		if(rowCount == 2){
			if($j("#matrix_"+num+"_row .rowsLabelList tr:eq(0) td div.action").length){
				$j("#matrix_"+num+"_row .rowsLabelList tr:eq(0) td div.action").append("<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabelDelete("+num+",1,"+qcount+");\">Delete</a></div>");
			}else{
				$j("#matrix_"+num+"_row .rowsLabelList tr:eq(0) td").append("<div class='action' style='padding-top:10px;'><div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabelDelete("+num+",1,"+qcount+");\">Delete</a></div></div>");
			}
			
		}
		/*onfocusout=\"javascript:validate_empty("+num+","+rowCount+",'row');\"*/
		$j("#matrix_"+num+"_row .rowsLabelList").append("<tr class='rowLabel_"+rowCount+"'><td><input type='text' name='matrix_"+num+"_row_"+rowCount+"_name' id='matrix_"+num+"_row_"+rowCount+"_name' value='' style='width:400px; height:15px; padding:5px;' onChange=\"javascript:rowsOnChange("+num+",this,"+rowCount+");\">"+helpTextDiv+"<div style='display:grid'><div class='action' style='padding-top:10px;'><div style='float:left; padding:0px 15px 15px 0px;'><a href='javascript:rowsLabelDelete("+num+","+rowCount+","+qcount+")'>Delete</a></div></div></div></td></tr>");
		
		var rowCount = $j("#matrix_"+num+"_row .rowsLabelList tr").length;
		
		if(rowCount == 2){
			var moveUp = moveUp.replace("upID","2");
			var moveDown = moveDown.replace("downID","1");		
			$j("#matrix_"+num+"_row .rowsLabelList tr:eq(1) td:eq(0) div.action").before(optionaltext);
			$j("#matrix_"+num+"_row .rowsLabelList tr:eq(0) td:eq(0) div.action").find("div:nth-child(1)").after(moveDown);
			$j("#matrix_"+num+"_row .rowsLabelList tr:eq(1) td:eq(0) div.action").find("div:first-child").before(moveUp);
			$j("#matrix_"+num+"_row .rowsLabelList tr:eq(1) td:eq(0) div.action").find("div:last-child").after(addAnother);
			//SQM_965
			//$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+i+") td:eq(0) div.action").append(optionaltext+showtext+closetext);
		}else{
			for(i = 1; i < rowCount; i++){
				var dividcount=i+1;
				//$j11('#helptextdiv_'+num+i).hide();
				
				moveUp = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabel_moveUp("+num+",upID);\">Move Up</a></div></div>";
				moveDown = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabel_moveDown("+num+",downID);\">Move Down</a></div></div>";
				//SQM-965
				optionaltext = "<div class='addHelpText' id='add_help_text_"+num+dividcount+"' style='float:left; padding:10px 15px 0px 0px;'><a href=\"javascript:helptext("+num+",optID);\">Optional: Add \"Help Text\" for this row.</a></div>";
				
				//showtext = "<div id='add_help_text_show_"+num+dividcount+"' style='float:left; padding:0px 15px 15px 0px;display:none;'><a href=\"javascript:helptext("+num+",optID);\">Show | Edit Help Text (Row "+dividcount+")</a></div>";
				//closetext = "<div id='add_help_text_edit_"+num+dividcount+"' style='float:left; padding:0px 15px 15px 0px;display:none;'><a href=\"javascript:closetext("+num+",optID);\">Hide | Edit Help Text (Row "+dividcount+")</a></div>";
				var moveUp = moveUp.replace("upID",parseInt(i+1));
				var moveDown =  moveDown.replace("downID",parseInt(i+1));
				var optionaltext =  optionaltext.replace("optID",parseInt(i+1));
				//var showtext =  showtext.replace("optID",parseInt(i+1));
				//var closetext =  closetext.replace("optID",parseInt(i+1));
				$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+i+") td:eq(0) div.action").html(moveUp+moveDown+"<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabelDelete("+num+","+parseInt(i+1)+","+qcount+");\">Delete</a></div>");
				$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rowCount-1)+") td:eq(0) div.action").html(moveUp+"<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabelDelete("+num+","+parseInt(i+1)+","+qcount+");\">Delete</a></div>"+addAnother);
				$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rowCount-1)+") td:eq(0) .addHelpText").remove();
				$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rowCount-1)+") td:eq(0) div.action").before(optionaltext);
				
				
				
			}
		}
	}else{
		alert(stepText+": Before creating a new row, please enter a name for the blank row.");
		$j("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+rowLength+"_name']").val("");
		$j("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+rowLength+"_name']").focus();
	}	
	//closetextall(1,num);
}

//3D Matrix Rows Moveup functionality
function rowsLabel_moveUp(num,rownumber){
	
	var nextmovedown=rownumber-1;
	var rowChoiceText = $j("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+rownumber+"_name']").val();
	var rowChoiceTextnospace = rowChoiceText
	var rowChoiceText_up = $j("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+parseInt(rownumber-1)+"_name']").val();
	var rowChoiceTextnospace_up = rowChoiceText_up
	
	if(rowChoiceTextnospace == ""){
		alert("Please enter a name for the blank row.");
		$j("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+rownumber+"_name']").focus();
	}
	if(rowChoiceTextnospace_up == ""){
		alert("Please enter a name for the blank row.");
		$j("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+parseInt(rownumber-1)+"_name']").focus();
	}
	if(rowChoiceTextnospace != "" && rowChoiceTextnospace_up != ""){
		var moveUp = $j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-1)+") input[id='matrix_"+num+"_row_"+rownumber+"_name']").attr('value');
		var moveDown = $j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-2)+") input[id='matrix_"+num+"_row_"+nextmovedown+"_name']").attr('value');
		//SQM-965
		var moveUPhelp = $j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-1)+") #helptextdiv_"+num+rownumber+" textarea#helptextarea"+num+rownumber).val();
		var moveDownhelp  = $j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-2)+") #helptextdiv_"+num+nextmovedown+" textarea#helptextarea"+num+nextmovedown).val();
		var moveUPhelpcnt = $j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-1)+") #helptextdiv_"+num+rownumber+" span#helptextarea"+num+rownumber+"_cnt").html();
		var moveDownhelpcnt  = $j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-2)+") #helptextdiv_"+num+nextmovedown+" span#helptextarea"+num+nextmovedown+"_cnt").html();
		$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-2)+") td:eq(0) input[id='matrix_"+num+"_row_"+nextmovedown+"_name']").attr('value',moveUp);
		$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-1)+") td:eq(0) input[id='matrix_"+num+"_row_"+rownumber+"_name']").attr('value',moveDown);
		//SQM-965
		$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-2)+") td:eq(0) textarea#helptextarea"+num+nextmovedown).val(moveUPhelp);
		$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-1)+") td:eq(0) textarea#helptextarea"+num+rownumber).val(moveDownhelp);
		$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-2)+") td:eq(0) span#helptextarea"+num+nextmovedown+"_cnt").html(moveUPhelpcnt);
		$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-1)+") td:eq(0) span#helptextarea"+num+rownumber+"_cnt").html(moveDownhelpcnt);
		//Grid Section
		var grid_moveUp = $j("#matrix_"+num+"_grid .table-bordered tr:eq("+parseInt(rownumber)+")").html();
		var grid_moveDown = $j("#matrix_"+num+"_grid .table-bordered tr:eq("+parseInt(rownumber-1)+")").html();
		$j("#matrix_"+num+"_grid .table-bordered tr:eq("+parseInt(rownumber-1)+")").html(grid_moveUp);
		$j("#matrix_"+num+"_grid .table-bordered tr:eq("+parseInt(rownumber)+")").html(grid_moveDown);
        /*--- SQM-811 by Inderjeet ---*/
		var currentrow = $j(".matrixContainer"+num+" .tab_head tr[id='"+parseInt(rownumber-1)+"']").children().clone();
		var nextrow = $j(".matrixContainer"+num+" .tab_head tr[id='"+parseInt(rownumber)+"']").children().clone();
		$j(".matrixContainer"+num+" .tab_head tr[id='"+parseInt(rownumber-1)+"']").html(nextrow);
		$j(".matrixContainer"+num+" .tab_head tr[id='"+parseInt(rownumber)+"']").html(currentrow);
		$j(".matrixContainer"+num+" .tab_head tr#0 td").each(function(i){
			changefieldnames(num,parseInt(rownumber-1),i,'prevrow');
			changefieldnames(num,parseInt(rownumber),i,'nextrow');
			});
		 /* --- End --- */
		$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+parseInt(rownumber)+" td.gridtd").each(function(){
			var attrName = $j(this).find("input").attr("name");
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[3] = parseInt(rownumber);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$j(this).find("input").attr("name", newName);
			
			var attrID = $j(this).attr("onclick");
			newID = attrID.split(",");
			newID[1] = parseInt(rownumber);
			var on_click_td = ""+newID[0]+","+newID[1]+","+newID[2]+"";
			$j(this).attr('onclick', on_click_td);
		});
		
		$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+parseInt(rownumber-1)+" td.gridtd").each(function(){
			var attrName = $j(this).find("input").attr("name");
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[3] = parseInt(rownumber-1);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$j(this).find("input").attr("name", newName);
			
			var attrID = $j(this).attr("onclick");
			newID = attrID.split(",");
			newID[1] = parseInt(rownumber-1);
			var on_click_td = ""+newID[0]+","+newID[1]+","+newID[2]+"";
			$j(this).attr('onclick', on_click_td);
		});
		$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+parseInt(rownumber)+" td.gridRow").each(function(){
			var attrID = $j(this).attr("onclick");
			newID = attrID.split(",");
			newID[1] = parseInt(rownumber);
			var on_click_td = ""+newID[0]+","+newID[1]+","+newID[2]+"";
			$j(this).attr('onclick', on_click_td);
		});
		$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+parseInt(rownumber-1)+" td.gridRow").each(function(){
			var attrID = $j(this).attr("onclick");
			newID = attrID.split(",");
			newID[1] = parseInt(rownumber-1);
			var on_click_td = ""+newID[0]+","+newID[1]+","+newID[2]+"";
			$j(this).attr('onclick', on_click_td);
		});
	}
	//closetextall(0,num);
}

//3D Matrix Rows Movedown functionality
function rowsLabel_moveDown(num,rownumber){
	var nextrow=rownumber+1;
	var rowChoiceText = $j("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+parseInt(rownumber)+"_name']").val();
	var rowChoiceTextnospace = rowChoiceText
	var rowChoiceText_down = $j("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+parseInt(rownumber+1)+"_name']").val();
	var rowChoiceTextnospace_down = rowChoiceText_down
	
	if(rowChoiceTextnospace == ""){
		alert("Please enter a name for the blank row.");
		$j("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+parseInt(rownumber)+"_name']").focus();
	}
	if(rowChoiceTextnospace_down == ""){
		alert("Please enter a name for the blank row.");
		$j("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+parseInt(rownumber+1)+"_name']").focus();
	}
	if(rowChoiceTextnospace != "" && rowChoiceTextnospace_down !=""){
		var moveDown = $j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-1)+") input[id='matrix_"+num+"_row_"+rownumber+"_name']").attr('value');
		var moveUp = $j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber)+") input[id='matrix_"+num+"_row_"+nextrow+"_name']").attr('value');
		//SQM-965
		var moveDownhelp = $j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-1)+") #helptextdiv_"+num+rownumber+" textarea#helptextarea"+num+rownumber).val();
		var moveUPhelp = $j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber)+") #helptextdiv_"+num+nextrow+" textarea#helptextarea"+num+nextrow).val();
		var moveDownhelpcnt = $j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-1)+") #helptextdiv_"+num+rownumber+" #helptextarea"+num+rownumber+"_cnt").html();
		var moveUPhelpcnt = $j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber)+") #helptextdiv_"+num+nextrow+" #helptextarea"+num+nextrow+"_cnt").html();
		$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber)+") td:eq(0) input[id='matrix_"+num+"_row_"+nextrow+"_name']").attr('value',moveDown);
		$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-1)+") td:eq(0) input[id='matrix_"+num+"_row_"+rownumber+"_name']").attr('value',moveUp);
		//SQM-965
		$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber)+") td:eq(0) textarea#helptextarea"+num+nextrow).val(moveDownhelp);
		$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-1)+") td:eq(0) textarea#helptextarea"+num+rownumber).val(moveUPhelp);
		$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber)+") td:eq(0) #helptextarea"+num+nextrow+"_cnt").html(moveDownhelpcnt);
		$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-1)+") td:eq(0) #helptextarea"+num+rownumber+"_cnt").html(moveUPhelpcnt);
		//Grid Section
		var grid_moveDown = $j("#matrix_"+num+"_grid .table-bordered tr:eq("+parseInt(rownumber)+")").html();
		var grid_moveUp = $j("#matrix_"+num+"_grid .table-bordered tr:eq("+parseInt(rownumber+1)+")").html();
		$j("#matrix_"+num+"_grid .table-bordered tr:eq("+parseInt(rownumber+1)+")").html(grid_moveDown);
		$j("#matrix_"+num+"_grid .table-bordered tr:eq("+parseInt(rownumber)+")").html(grid_moveUp);
		
        /*--- SQM-811 by Inderjeet ---*/
		var currentrow = $j(".matrixContainer"+num+" .tab_head tr[id='"+parseInt(rownumber+1)+"']").children().clone();
		var nextrow = $j(".matrixContainer"+num+" .tab_head tr[id='"+parseInt(rownumber)+"']").children().clone();
		$j(".matrixContainer"+num+" .tab_head tr[id='"+parseInt(rownumber+1)+"']").html(nextrow);
		$j(".matrixContainer"+num+" .tab_head tr[id='"+parseInt(rownumber)+"']").html(currentrow);
		$j(".matrixContainer"+num+" .tab_head tr#0 td").each(function(i){
		changefieldnames(num,parseInt(rownumber),i,'prevrow');
		changefieldnames(num,parseInt(rownumber+1),i,'nextrow');
	    });
		/* --- End --- */
		$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+parseInt(rownumber)+" td.gridtd").each(function(){
			var attrName = $j(this).find("input").attr("name");
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[3] = parseInt(rownumber);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$j(this).find("input").attr("name", newName);
			
			var attrID = $j(this).attr("onclick");
			newID = attrID.split(",");
			newID[1] = parseInt(rownumber);
			var on_click_td = ""+newID[0]+","+newID[1]+","+newID[2]+"";
			$j(this).attr('onclick', on_click_td);
		});
		
		$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+parseInt(rownumber+1)+" td.gridtd").each(function(){
			var attrName = $j(this).find("input").attr("name");
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[3] = parseInt(rownumber+1);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$j(this).find("input").attr("name", newName);
			
			var attrID = $j(this).attr("onclick");
			newID = attrID.split(",");
			newID[1] = parseInt(rownumber+1);
			var on_click_td = ""+newID[0]+","+newID[1]+","+newID[2]+"";
			$j(this).attr('onclick', on_click_td);
		});
		$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+parseInt(rownumber)+" td.gridRow").each(function(){
			var attrID = $j(this).attr("onclick");
			newID = attrID.split(",");
			newID[1] = parseInt(rownumber);
			var on_click_td = ""+newID[0]+","+newID[1]+","+newID[2]+"";
			$j(this).attr('onclick', on_click_td);
		});
		$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+parseInt(rownumber+1)+" td.gridRow").each(function(){
			var attrID = $j(this).attr("onclick");
			newID = attrID.split(",");
			newID[1] = parseInt(rownumber+1);
			var on_click_td = ""+newID[0]+","+newID[1]+","+newID[2]+"";
			$j(this).attr('onclick', on_click_td);
		});
	}
	//closetextall(0,num);
}

//3D Matrix Rows delete
function rowsLabelDelete(num,id,qcount){
	addAnother = "<div style='float:left; padding:0px 15px 15px 0px;'><a href='javascript:rowsLabelAdd("+num+","+qcount+");'>Add Another Row</a></div>";
	moveUp = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabel_moveUp("+num+",upID);\">Move Up</a></div>";
	moveDown = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabel_moveDown("+num+",downID);\">Move Down</a></div>";
	
	$j("#matrix_"+num+"_row .rowsLabelList .rowLabel_"+id).remove();
	count = $j("#matrix_"+num+"_row_count").val();
	newCount = parseInt(count)-1;
	$j("#matrix_"+num+"_row_count").val(newCount);
	
	var rowCount = $j("#matrix_"+num+"_row .rowsLabelList tr").length;
	var dividcount = 2;
	
	//showtext = "<div id='add_help_text_show_"+num+dividcount+"' style='float:left; padding:0px 15px 15px 0px;display:none;'><a href=\"javascript:helptext("+num+","+dividcount+");\">Show | Edit Help Text (Row "+dividcount+")</a></div>";
	//var closetext = "<div id='add_help_text_edit_"+num+dividcount+"' style='float:left; padding:0px 15px 15px 0px;display:none;'><a href=\"javascript:closetext("+num+","+dividcount+");\">Hide | Edit Help Text (Row "+dividcount+")</a></div>";
	optionaltext = "<div class='addHelpText' id='add_help_text_"+num+dividcount+"' style='float:left; padding:10px 15px 0px 0px;'><a href=\"javascript:helptext("+num+","+dividcount+");\">Optional: Add \"Help Text\" for this row.</a></div>";
	helptitle="<label class='helplabel' style='margin-top:0px;'>\"Help Text\" Column Title:</label><input type='text' name='helptexttitle_"+num+"' id='helptexttitle_"+num+"'  style='width:387px; height:15px; padding:5px;' onKeyUp='TitleValidation("+num+",this,"+id+")' onchange='helptexttitleDisplay("+num+",this,"+id+")'>";
	var i = 1;
	if(id==1){
		$j("#matrix_"+num+"_row .rowsLabelList tr:eq(0) td:eq(0) .help_text_div div:first-child label").remove();
		$j("#matrix_"+num+"_row .rowsLabelList tr:eq(0) td:eq(0) .help_text_div div:first-child ").prepend('<label class="helplabel">Row 1\'s Help Text:</label>');
		$j("#matrix_"+num+"_row .rowsLabelList tr:eq(0) td:eq(0) .help_text_div div:first-child ").prepend(helptitle);	
		$j("#matrix_"+num+"_row .rowsLabelList tr:eq(0) td:eq(0) .help_text_div .deletehelptext").html('<img src="../images/icons/delete.png" width="15" height="15" style="vertical-align:text-bottom;">\ \Delete the "Help Text" Column for this Question.');
		var helptitle = $j("#helptext_"+num).html();
		$j("#helptexttitle_"+num).val(helptitle);
		$j("#matrix_"+num+"_row .rowsLabelList tr:eq(0) td:eq(0) .help_text_div").show();	
	}
	$j("#matrix_"+num+"_row .rowsLabelList tr").each(function(){
		var k=i+1;
		$j(this).attr('class','rowLabel_'+i);
 		//$j(this).find("td:eq(0) a").attr('href','javascript:rowsLabelDelete('+num+','+i+','+qcount+')');
		$j(this).find("td:eq(0) input[id='matrix_"+num+"_row_"+k+"_name']").attr('name','matrix_'+num+'_row_'+i+'_name');
		$j(this).find("td:eq(0) input[id='matrix_"+num+"_row_"+k+"_name']").attr('id','matrix_'+num+'_row_'+i+'_name');
		$j(this).find("td:eq(0) .help_text_div").attr('id','helptextdiv_'+num+i);
		$j(this).find("td:eq(0) .help_text_div .helptextarea"+num+"").attr({id:'helptextarea'+num+i, name:'helptextarea'+num+i, class:'helptextarea'+num+'', rindex:i, num:num, onchange:'helptextDisplay('+num+',this,'+i+')' });
		$j(this).find("td:eq(0) .help_text_div span").attr('id','helptextarea'+num+i+'_cnt');
		var on_change_input = "javascript:rowsOnChange("+num+",this,"+i+");";
		$j(this).find("td:eq(0) input[id='matrix_"+num+"_row_"+i+"_name']").attr('onchange', on_change_input);
		if(i > 1){
			$j(this).find("td:eq(0) .help_text_div div:first-child label").remove();
			$j(this).find("td:eq(0) .help_text_div div:first-child").prepend('<label class="helplabel">Row '+i+'\'s Help Text:</label>');
			$j(this).find("td:eq(0) .help_text_div .deletehelptext").html('<img src="../images/icons/delete.png" width="15" height="15" style="vertical-align:text-bottom;">\ \Remove the "Help Text" for this row.');
		}	
 		i = i+1;
 	});
		
    var j = 1;
    $j("#matrix_"+num+"_row .rowsLabelList tr").each(function(){
		if(j == 2){
			var moveUp = moveUp.replace("upID","2");
			var moveDown = moveDown.replace("downID","1");
			$j("#matrix_"+num+"_row .rowsLabelList tr:eq(0) td:eq(0) div.action").append(moveDown);
			$j("#matrix_"+num+"_row .rowsLabelList tr:eq(1) td:eq(0) div.action").append(moveUp);
			$j("#matrix_"+num+"_row .rowsLabelList tr:eq(1) td:eq(0) .addHelpText").remove();
			$j("#matrix_"+num+"_row .rowsLabelList tr:eq(1) td:eq(0) div.action").before(optionaltext);
			//$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+i+") td:eq(0) div.action").append(optionaltext+showtext+closetext);
		}else{
			for(j = 1; j < rowCount; j++){
				var dividcount=j+1;
				
				moveUp = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabel_moveUp("+num+",upID);\">Move Up</a></div></div>";
				moveDown = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabel_moveDown("+num+",downID);\">Move Down</a></div></div>";
				optionaltext = "<div class='addHelpText' id='add_help_text_"+num+dividcount+"' style='float:left; padding:10px 15px 0px 0px;'><a href=\"javascript:helptext("+num+",optID);\">Optional: Add \"Help Text\" for this row.</a></div>";
				
				//showtext = "<div id='add_help_text_show_"+num+dividcount+"' style='float:left; padding:0px 15px 15px 0px;display:none;'><a href=\"javascript:helptext("+num+",optID);\">Show | Edit Help Text (Row "+dividcount+")</a></div>";
				//var closetext = "<div id='add_help_text_edit_"+num+dividcount+"' style='float:left; padding:0px 15px 15px 0px;display:none;'><a href=\"javascript:closetext("+num+",optID);\">Hide | Edit Help Text (Row "+dividcount+")</a></div>";
				var moveUp = moveUp.replace("upID",parseInt(j+1));
				var moveDown =  moveDown.replace("downID",parseInt(j+1));
				var optionaltext =  optionaltext.replace("optID",parseInt(j+1));
				//var showtext =  showtext.replace("optID",parseInt(j+1));
				//var closetext =  closetext.replace("optID",parseInt(j+1));
				$j("#matrix_"+num+"_row .rowsLabelList tr:eq(0) td:eq(0) .addHelpText").remove();
				$j("#matrix_"+num+"_row .rowsLabelList tr:eq(0) td:eq(0) div.action").before("<div class='addHelpText' id='add_help_text_show_"+num+"1' style='float:left; padding:10px 15px 0px 0px;'><a href=\"javascript:helptext("+num+",1);\">Optional: Add a column to hold \"Help Text\" for this or any other row.</a></div>");
				$j("#matrix_"+num+"_row .rowsLabelList tr:eq(0) td:eq(0) div.action").html("<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabel_moveDown("+num+",1);\">Move Down</a></div><div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabelDelete("+num+",1,"+qcount+");\">Delete</a></div>");
				$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+j+") td:eq(0) div.action").html(moveUp+moveDown+"<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabelDelete("+num+","+parseInt(j+1)+","+qcount+");\">Delete</a></div>");
				$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rowCount-1)+") td:eq(0) div.action").html(moveUp+"<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabelDelete("+num+","+parseInt(j+1)+","+qcount+");\">Delete</a></div>"+addAnother);
				//if(j > 1){
				//$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+j+") td:eq(0) .addHelpText").remove();
				//$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+j+") td:eq(0) div.action").before(optionaltext);
				
				$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rowCount-1)+") td:eq(0) .addHelpText").remove();
				$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rowCount-1)+") td:eq(0) div.action").before(optionaltext);
				if($j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rowCount-1)+") td:eq(0) .help_text_div:visible").length){
					$j("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rowCount-1)+") td:eq(0) .addHelpText").hide();
				}
			}
			
			if(rowCount == 1){
				
				add_another = "<div id='add_another_row' ><a href='javascript:rowsLabelAdd("+num+","+qcount+");'>Add Another Row</a></div>"
				//showtext = "<div id='add_help_text_show_"+num+rowCount+"' style='float:left; padding:0px 15px 15px 0px;display:none;'><a href=\"javascript:helptext("+num+","+rowCount+");\">Show | Edit Help Text (Row "+rowCount+")</a></div>";
				//closetext = "<div id='add_help_text_edit_"+num+rowCount+"' style='float:left; padding:0px 15px 15px 0px;display:none;'><a href=\"javascript:closetext("+num+","+rowCount+");\">Hide | Edit Help Text (Row "+rowCount+")</a></div>";
				optionaltext = "<div class='addHelpText' id='add_help_text_show_"+num+rowCount+"' style='float:left; padding:10px 15px 0px 0px;display: none;'><a href=\"javascript:helptext("+num+","+rowCount+");\">Optional: Add a column to hold \"Help Text\" for this or any other row.</a></div>";
	
				$j("#matrix_"+num+"_row .rowsLabelList .rowLabel_1 div.action div").remove();
				$j("#matrix_"+num+"_row .rowsLabelList .rowLabel_1 div.action").html(add_another);
				$j("#matrix_"+num+"_row .rowsLabelList .rowLabel_1 .addHelpText").remove()
				$j("#matrix_"+num+"_row .rowsLabelList .rowLabel_1 div.action").before(optionaltext);
			}	
		
		}
	 		j = j+1;
			
  	 });
	 if($j("#matrix_"+num+"_row .rowsLabelList tr:eq(0) td:eq(0) .help_text_div:visible").length){
		$j("#matrix_"+num+"_row .rowsLabelList tr:eq(0) td:eq(0) .addHelpText").hide();	
	 }
	   //closetextall(0,num);
	 //Grid Section
	 $j("#matrix_"+num+"_grid .table-bordered").find("tr#"+id+"").remove();
	 $j(".matrixContainer"+num+" .tab_head tr[id='"+id+"']").remove();/*--- SQM-811 by Inderjeet ---*/
	 
	 for(k = id; k <= newCount; k++){
		$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+parseInt(k+1)+"").attr('id', k);
		/*--- SQM-811 by Inderjeet ---*/
		$j(".matrixContainer"+num+" .tab_head tr[id='"+parseInt(k+1)+"']").attr('id',k);
		$j(".matrixContainer"+num+" .tab_head tr#0 td").each(function(i){
			changefieldnames(num,parseInt(k),i,'prevrow');
		});
		if($j(".matrixContainer"+num+" .tab_head tr[id='"+k+"']").attr('class') == 'even'){
		$j(".matrixContainer"+num+" .tab_head tr[id='"+k+"']").attr('class', 'odd');}
        else if($j(".matrixContainer"+num+" .tab_head tr[id='"+k+"']").attr('class') == 'odd'){
			$j(".matrixContainer"+num+" .tab_head tr[id='"+k+"']").attr('class', 'even');}
		 /* --- End --- */
		
		$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+parseInt(k)+" td.gridtd").each(function(){
			var attrName = $j(this).find("input").attr("name");
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[3] = parseInt(k);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$j(this).find("input").attr("name", newName);
			
			var attrID = $j(this).attr("onclick");
			newID = attrID.split(",");
			newID[1] = parseInt(k);
			var on_click_td = ""+newID[0]+","+newID[1]+","+newID[2]+"";
			$j(this).attr('onclick', on_click_td);
		});
		$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+parseInt(k)+" td.gridRow").each(function(){
			var attrID = $j(this).attr("onclick");
			newID = attrID.split(",");
			newID[1] = parseInt(k);
			var on_click_td = ""+newID[0]+","+newID[1]+","+newID[2]+"";
			$j(this).attr('onclick', on_click_td);
		});
		$j('.deletehelptextlink_'+num+parseInt(k+1)).attr('class','deletehelptextlink_'+num+parseInt(k)+' helpdelete');
		$j('.deletehelptextlink_'+num+parseInt(k)+' a').attr('onclick','closetext('+num+','+parseInt(k)+')');
	}
}


//3D Matrix Columns
function showAddAnother(num){
	var col = $j("#matrix_"+num+"_column input[name='matrix_"+num+"_column_1_name']").val();
	
	if(col !== ''){
		$j("#matrix_"+num+"_column #add_another_column").show();
	}else{
		$j("#matrix_"+num+"_column #add_another_column").hide();
	}
}

function removeDuplicates(num,Numvalue,sid){
	if($j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #'+sid).length > 1){
		$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' .columnsLabelList tr:eq(1) td #'+sid).first().remove();
	}
}

function questionTypeChange(num,select){
	var attrID = select.id;
	Numvalue = attrID.match(/\d+$/); //Numvalue = attrName.match(/\d+/g); for finding all digits.
	//console.log(Numvalue);
	var qntype = select.value;
	
	count = $j("#matrix_"+num+"_grid .table-bordered").find('tr').length;
    col = $j("#matrix_"+num+"_grid .table-bordered tr:eq(0)").find('td').length;/*--- SQM-811 by Inderjeet ---*/
	
	if(qntype != ''){
		$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' div#questionTypeResp_'+Numvalue).show();

		if(qntype == 'Date Field'){
			var sid = 'datefield_'+Numvalue;
			removeDuplicates(num,Numvalue,sid);
			//$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).is(':visible')
			
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #datefield_'+Numvalue).css('display','table');
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #textBox_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue).hide();

			for(i=1;i<=count;i++){
				//$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #p3d').empty();
				$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] .pclass').hide();
				$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] .datesection').show();
				//$j('#matrix_'+num+'_pstartenddate_'+Numvalue+'_'+i+' span').html('<input type="text" name="matrix_'+num+'_sbasicDate_'+Numvalue+'_'+i+'" id="matrix_'+num+'_sbasicDate_'+Numvalue+'_'+i+'" placeholder="Select Dates" data-input>');
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' .datetype').each(function(){
					//console.log($j(this).attr('chcked'));
					if($j(this).attr('chcked') == 'checked'){	
						var dname = $j(this).val().split("_");
						var dtype = dname[1];
						$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] .mpquestion_'+Numvalue+'_'+dtype).show();
					}
				});
		  }
			  
		}
		
		if(qntype == 'Free Text Response'){
			var sid = 'freeText_'+Numvalue;
			removeDuplicates(num,Numvalue,sid);
			//$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).is(':visible')
			
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).show();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #datefield_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #textBox_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue).hide();
			
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue+' input:eq(0)').attr('name', 'matrix_'+num+'_freetext_'+Numvalue+'_name');
		    $j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue+' input:eq(0)').attr('onchange', 'javascript:p3dfreetextchange(this,'+Numvalue+');');/*--- SQM-811 by Inderjeet ---*/
            /*--- SQM-811 by Inderjeet ---*/
			for(i=1;i<=count;i++){
			  //$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #p3d').empty();
			  $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] .pclass').hide();
			  $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_freeText_'+i+'_'+Numvalue+'').show();
			  
			  
		}
		}
		if(qntype == 'Text Box'){
			var sid = 'textBox_'+Numvalue;
			removeDuplicates(num,Numvalue,sid);
			
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #textBox_'+Numvalue).show();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #datefield_'+Numvalue).hide();
            /*--- SQM-811 by Inderjeet ---*/
			for(i=1;i<=count;i++){
				$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] .pclass').hide();
				$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_textBox_'+i+'_'+Numvalue+'').show();
			}
		}
		if(qntype == 'Quantitative Checkbox without Other Option' || qntype == 'Quantitative Checkbox with Other Option'){
			if(qntype == 'Quantitative Checkbox without Other Option'){
				var sid = 'quanChkbox_'+Numvalue;
				removeDuplicates(num,Numvalue,sid);
				
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue).show();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #textBox_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #datefield_'+Numvalue).hide();
				
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue+' input:eq(0)').attr('name', 'matrix_'+num+'_quanCheckFrom_'+Numvalue+'_name');
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue+' input:eq(1)').attr('name', 'matrix_'+num+'_quanCheckTo_'+Numvalue+'_name');
				/*--- SQM-811 by Inderjeet ---*/
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue+' input:eq(0)').attr({
					onchange: 'javascript:onchangefrom('+num+','+Numvalue+',this)',
					id: 'matrix_'+num+'_quanCheckFrom_'+Numvalue+'_name'
				});
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue+' input:eq(1)').attr({
					onchange: 'javascript:onchangeto('+num+','+Numvalue+',this)',
					id: 'matrix_'+num+'_quanCheckTo_'+Numvalue+'_name'
				});
				for(i=1;i<=count;i++){
					$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] .pclass').hide();
					$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dquancheck').html('<table class="matrixColumnInputTable" align="center" style="min-width:220px;border-spacing:0px;min-height: 50px;margin-top: -1px;"></table>');
					$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dquancheck').attr('id','matrix_'+num+'_p3dquanchk_'+i+'_'+Numvalue+''); 
				    $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dquanchk_'+i+'_'+Numvalue+'').show();
				}
			}else{
				var sid = 'quanChkboxWithOther_'+Numvalue;
				removeDuplicates(num,Numvalue,sid);
				
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue).show();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #textBox_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #datefield_'+Numvalue).hide();
				
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue+' input:eq(0)').attr('name', 'matrix_'+num+'_quanCheckWithOtherFrom_'+Numvalue+'_name');
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue+' input:eq(1)').attr('name', 'matrix_'+num+'_quanCheckWithOtherTo_'+Numvalue+'_name');
				
				/*--- SQM-811 by Inderjeet ---*/
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue+' input:eq(0)').attr({
					onchange: 'javascript:onchangefrom('+num+','+Numvalue+',this)',
					id: 'matrix_'+num+'_quanCheckWithOtherFrom_'+Numvalue+'_name'
				});
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue+' input:eq(1)').attr({
					onchange: 'javascript:onchangeto('+num+','+Numvalue+',this)',
					id: 'matrix_'+num+'_quanCheckWithOtherTo_'+Numvalue+'_name'
				});
			
			    for(i=1;i<=count;i++){
					$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] .pclass').hide();
					$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dquancheckwith').html('<table class="matrixColumnInputTable" align="center" style="min-width:220px;border-spacing:0px;min-height: 50px;margin-top: -1px;"></table>')
					$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dquancheckwith').attr('id','matrix_'+num+'_p3dquanchkwith_'+i+'_'+Numvalue+'');
				    $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dquanchkwith_'+i+'_'+Numvalue+'').show();
				}
			}
		}
		if(qntype == 'Quantitative Drop-Down' || qntype == 'Quantitative Radio'){
			if(qntype == 'Quantitative Drop-Down'){
				var sid = 'quanDropDown_'+Numvalue;
				removeDuplicates(num,Numvalue,sid);
				
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue).show();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #textBox_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #datefield_'+Numvalue).hide();
				
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue+' input:eq(0)').attr('name', 'matrix_'+num+'_quanDropDownFrom_'+Numvalue+'_name');
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue+' input:eq(1)').attr('name', 'matrix_'+num+'_quanDropDownTo_'+Numvalue+'_name');
				
				/*--- SQM-811 by Inderjeet ---*/
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue+' input:eq(0)').attr({
					onchange: 'javascript:onchangefrom('+num+','+Numvalue+',this)',
					id: 'matrix_'+num+'_quanDropDownFrom_'+Numvalue+'_name'
				});
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue+' input:eq(1)').attr({
					onchange: 'javascript:onchangeto('+num+','+Numvalue+',this)',
					id: 'matrix_'+num+'_quanDropDownTo_'+Numvalue+'_name'
				});
			
			    for(i=1;i<=count;i++){
					$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] .pclass').hide();
					if($j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dquandropdown_'+i+'_'+Numvalue+' select').attr('id') != 'matrix_'+num+'_p3dnumdd_'+i+'_'+Numvalue+''){
					$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dquandropdown_'+i+'_'+Numvalue+'').html('<select id="matrix_'+num+'_p3dnumdd_'+i+'_'+Numvalue+'"  class="select-box" style="min-width:190px;max-width:190px;"><option value="-987698798">Select</option></select>');}
				    $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dquandropdown_'+i+'_'+Numvalue+'').show();
				}
			}else{
				var sid = 'quanRadio_'+Numvalue;
				removeDuplicates(num,Numvalue,sid);
				
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue).show();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #textBox_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #datefield_'+Numvalue).hide();
			
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue+' input:eq(0)').attr('name', 'matrix_'+num+'_quanRadioFrom_'+Numvalue+'_name');
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue+' input:eq(1)').attr('name', 'matrix_'+num+'_quanRadioTo_'+Numvalue+'_name');
				
				/*--- SQM-811 by Inderjeet ---*/
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue+' input:eq(0)').attr({
					onchange: 'javascript:onchangefrom('+num+','+Numvalue+',this)',
					id: 'matrix_'+num+'_quanRadioFrom_'+Numvalue+'_name'
				});
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue+' input:eq(1)').attr({
					onchange: 'javascript:onchangeto('+num+','+Numvalue+',this)',
					id: 'matrix_'+num+'_quanRadioTo_'+Numvalue+'_name'
				});
				
			    for(i=1;i<=count;i++){
					$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] .pclass').hide();
					if($j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dquanradio_'+i+'_'+Numvalue+' table').length){
				    $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dquanradio_'+i+'_'+Numvalue+'').show();
					}else{
						$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dquanradio_'+i+'_'+Numvalue+'').html('<table class="matrixColumnInputTable" align="center" style="min-width:220px;border-spacing:0px;min-height: 50px;margin-top: -1px;"></table>').show();
					}
				}
			}
		}
		if(qntype == 'Qualitative Checkbox without Other Option' || qntype == 'Qualitative Checkbox with Other Option'){
			if(qntype == 'Qualitative Checkbox without Other Option'){
				var sid = 'qualChkbox_'+Numvalue;
				removeDuplicates(num,Numvalue,sid);
				
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue).show();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #textBox_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #datefield_'+Numvalue).hide();
				
				//$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue+' textarea').attr('name', 'matrix_'+num+'_qualCheck_'+Numvalue+'_name');
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue+' .qualitativeValueSelectAddUpdate textarea').attr('name', 'qualitativeValueSelect_'+num+'_qualCheck_'+Numvalue);
				/*--- SQM-811 by Inderjeet ---*/
			    for(i=1;i<=count;i++){
					$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] .pclass').hide();
				    $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dqualcheck').html('<table class="matrixColumnInputTable" align="center" style="min-width:220px;border-spacing:0px;min-height: 50px;"></table>');
					$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dqualcheck').attr('id','matrix_'+num+'_p3dqualchk_'+i+'_'+Numvalue+''); 
				    $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dqualchk_'+i+'_'+Numvalue+'').show();
				}
			}else{
				var sid = 'qualChkboxWithOther_'+Numvalue;
				removeDuplicates(num,Numvalue,sid);
				
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue).show();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #textBox_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #datefield_'+Numvalue).hide();
				
				//$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue+' textarea').attr('name', 'matrix_'+num+'_qualCheckWithOther_'+Numvalue+'_name');
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue+' .qualitativeValueSelectAddUpdate textarea').attr('name', 'qualitativeValueSelect_'+num+'_qualCheckWithOther_'+Numvalue);
				/*--- SQM-811 by Inderjeet ---*/
			    for(i=1;i<=count;i++){
				    $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] .pclass').hide();
					$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dqualcheckwith').html('<table class="matrixColumnInputTable" align="center" style="min-width:220px;border-spacing:0px;min-height: 50px;"></table>');
					$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dqualcheckwith').attr('id','matrix_'+num+'_p3dqualchkwith_'+i+'_'+Numvalue+'');
				    $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dqualchkwith_'+i+'_'+Numvalue+'').show();
				}
			}
		}
		if(qntype == 'Qualitative Drop-Down' || qntype == 'Qualitative Radio'){
			if(qntype == 'Qualitative Drop-Down'){
				var sid = 'qualDropDown_'+Numvalue;
				removeDuplicates(num,Numvalue,sid);
				
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue).show();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #textBox_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #datefield_'+Numvalue).hide();
				
				//$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue+' textarea').attr('name', 'matrix_'+num+'_qualDropDown_'+Numvalue+'_name');
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue+' .qualitativeValueSelectAddUpdate textarea').attr('name', 'qualitativeValueSelect_'+num+'_qualDropDown_'+Numvalue);
			/*--- SQM-811 by Inderjeet ---*/	
			    for(i=1;i<=count;i++){
					$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] .pclass').hide();
					if($j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dqualdropdown_'+i+'_'+Numvalue+' select').attr('id') != 'matrix_'+num+'_p3dnonnumdd_'+i+'_'+Numvalue+''){
					$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dqualdropdown_'+i+'_'+Numvalue+'').html('<select id="matrix_'+num+'_p3dnonnumdd_'+i+'_'+Numvalue+'"  class="select-box" style="min-width:190px;max-width:190px;"><option value="-987698798">Select</option></select>');}
				    $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dqualdropdown_'+i+'_'+Numvalue+'').show();
				}
			}else{
				var sid = 'qualRadio_'+Numvalue;
				removeDuplicates(num,Numvalue,sid);
				
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue).show();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #textBox_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue).hide();
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #datefield_'+Numvalue).hide();
				
				//$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue+' textarea').attr('name', 'matrix_'+num+'_qualRadio_'+Numvalue+'_name');
				$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue+' .qualitativeValueSelectAddUpdate textarea').attr('name', 'qualitativeValueSelect_'+num+'_qualRadio_'+Numvalue);
			/*--- SQM-811 by Inderjeet ---*/	
				for(i=1;i<=count;i++){
					$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] .pclass').hide();
					if($j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dqualradio_'+i+'_'+Numvalue+' table').length){
				    $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dqualradio_'+i+'_'+Numvalue+'').show();
					}else{
						$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_p3dqualradio_'+i+'_'+Numvalue+'').html('<table class="matrixColumnInputTable" align="center" style="min-width:220px;border-spacing:0px;min-height: 50px;"></table>').show();	
					}
				}
			}
		}
		if(qntype == 'Time5Min_1HourMax' || qntype == 'Time5Min' || qntype == 'Time15Min_20HourMax' || qntype == 'Time15Min_300HourMax' || qntype == 'Time15Min' || qntype == 'Time30Min' || qntype == 'Time60Min' || qntype == 'Time5Min_75HourMax' || qntype == 'Time5Min_300HourMax' || qntype == 'Time30Min_500HourMax'){/* SQM-455 */ /* ADMINFUNCT-192 */ /*SQM-490*/
			var sid = 'timeQns_'+Numvalue;
			removeDuplicates(num,Numvalue,sid);
			
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue).show();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #textBox_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #datefield_'+Numvalue).hide();
			$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue+' input').attr({
				name: 'matrix_'+num+'_chkSpecialTimeSeries_'+Numvalue+'_name',
				id: 'matrix_'+num+'_chkSpecialTimeSeries_'+Numvalue+'_name',
			    onclick: 'MakeNone_matrix(this)'
			}); //Added For SurveyComp-115
			/*--- SQM-811 by Inderjeet ---*/
			if(qntype == 'Time5Min_300HourMax' || qntype == 'Time30Min_500HourMax'){
				var str = qntype.replace("Time","selectTime_");
			}
			else{
			var s = qntype.replace("Min","minute");
			var str = s.replace("Time","selectTime_");
		    }
			var cloneDiv = $j("."+str).html();
			
			if(count == 1){
				limit = 1;
			}else{
				limit = count-1;
			}
			for(i=1;i<=limit;i++){
				
				   // $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] #matrix_'+num+'_timeQuns_'+i+'_'+Numvalue+' .tclass').hide();
			       // $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] #matrix_'+num+'_timeQuns_'+i+'_'+Numvalue+' .'+str).html(cloneDiv);
					$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] .pclass').hide();
				    $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_timeQuns_'+i+'_'+Numvalue+'').empty().html(cloneDiv);
					$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] #matrix_'+num+'_timeQuns_'+i+'_'+Numvalue+'').show();
					
					if($j('#matrix_'+num+'_chkSpecialTimeSeries_'+Numvalue+'_name').is(':checked')){
						$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] #matrix_'+num+'_timeQuns_'+i+'_'+Numvalue+' select').find('[value="0"]').attr("selected","selected");
					 }else{
						 $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] #matrix_'+num+'_timeQuns_'+i+'_'+Numvalue+' select').find('[value="Select"]').attr("selected","selected");
					 }
			}
			
		}
		if(col > 1 && count > 1){
			$j('.matrixContainer'+num+' .tab_head').show();
		}
	}
	else{
		$j('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' div#questionTypeResp_'+Numvalue).hide();
	/*--- SQM-811 by Inderjeet ---*/
	    for(i=1;i<=count;i++){
			$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+Numvalue+'"] .pclass').hide();
		}
		if(col == 1 && count == 1){
			$j('.matrixContainer'+num+' .tab_head').hide();
		}
	}
}

//3D Matrix Columns Add
function columnsLabelAdd(num,qcount){
	addAnother = "<div style='float:left; padding:10px 15px 0px 0px;'><a href='javascript:columnsLabelAdd("+num+","+qcount+");'>Add Another Column</a></div>";
	moveUp = "<div style='float:left; padding:10px 15px 0px 0px;'><a href=\"javascript:columnsLabel_moveUp("+num+",upID);\">Move Up</a></div>";
	moveDown = "<div style='float:left; padding:10px 15px 0px 0px;'><a href=\"javascript:columnsLabel_moveDown("+num+",downID);\">Move Down</a></div>";
	
	var count = $j("#matrix_"+num+"_column_count").val();
	
	var columnItem = $j(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+count+"_name']").val();
	var qnType = $j(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList select[name='matrix_"+num+"_questionType_"+count+"_name']").val();
	var stepText = "["+document.getElementById("jSubNumbering_"+num).innerText +"]";
	
	stepCounter = qcount-num+1;
	
	if(columnItem.trim() != "" && qnType != ""){
		
		var validationstatus = matrixColumnValidation(num,qnType,count,stepCounter,0);
		
		if(validationstatus == true){
			count = parseInt(count) + 1;
			$j("#matrix_" + num + "_column_count").val(count);
			$j("#matrix_" + num + "_column #add_another_column").remove();
			
			$j('#3dMatrix_Step2_add .3DMatrixStep2').each(function(){
				var attrID = this.id;
				Numvalue = attrID.match(/\d+$/);
				var newID = attrID.replace('_' + Numvalue, '_' + parseInt(count));
				$j(this).attr('id', newID);
				/*--- SQM-811 by Inderjeet ---*/
				if(attrID.search(/questionTypeSelect/) != -1){
					$j(this).attr('id','questionTypeSelect_'+num+'_'+parseInt(count)+'');
				}
			});
			
			var labelText = stringifyNumber(count);
			$j("#3dMatrix_Step2_add #columnsAdd_" + count + " span#colLabel_" + count).text(labelText + " Column's Label:");
			var qnTypeText = stringifyNumber(count);
			$j("#3dMatrix_Step2_add #columnsAdd_" + count + " span#colQnType_" + count).text(qnTypeText + " Column's Question Type:");
			
			$j('#3dMatrix_Step2_add_clone').html($j('#3dMatrix_Step2_add').html());
			
			$j('#3dMatrix_Step2_add .3DMatrixStep2Name').each(function(){
				var attrName = this.name;
				newStr = attrName.split("_");
				newStr[1] = num;
				newStr[3] = count;
				var newName = "" + newStr[0] + "_" + newStr[1] + "_" + newStr[2] + "_" + newStr[3] + "_" + newStr[4] + "";
				$j(this).attr('name', newName);
			});
			
			$j('#3dMatrix_Step2_add .matrixQualElements').each(function(){
				if(this.name || this.id){
					if(this.id.length != 0){
						var attrName = this.id;
					}else{
						var attrName = this.name;
					}
					newStr = attrName.split("_");
					newStr[1] = num;
					newStr[3] = count;
					var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"";
					if($j(this).attr("name")){$j(this).attr('name', newName);}
					if($j(this).attr("id")){$j(this).attr('id', newName);}
				}
			});
			
			content = $j('#3dMatrix_Step2_add').html();
			$j('.3dMatrix_Step2 #matrix_' + num + '_column').append(content);
			
			$j('#3dMatrix_Step2_add').html($j('#3dMatrix_Step2_add_clone').html());
			$j('#3dMatrix_Step2_add_clone').html("");
			
			var on_change_input = "javascript:columnsOnChange(" + num + ",this," + count + ");";
			$j(".3dMatrix_Step2 #matrix_" + num + "_column #columnsAdd_" + count + " .columnsLabelList input[name='matrix_" + num + "_column_" + count + "_name']").attr('onchange', on_change_input);
			chngematrixdatefield(num,count);
			setstartendlink(count);
			/*
			 var on_focusout_input = "javascript:validate_empty(" + num + "," + count +  ",'column');";
			$j(".3dMatrix_Step2 #matrix_" + num + "_column #columnsAdd_" + count + " .columnsLabelList input[name='matrix_" + num + "_column_" + count + "_name']").attr('onfocusout', on_focusout_input);
			*/
			var on_change_select = "javascript:questionTypeChange(" + num + ",this);";
			$j(".3dMatrix_Step2 #matrix_" + num + "_column #columnsAdd_" + count + " .columnsLabelList select").attr('onchange', on_change_select);
			
			if ($j('.3dMatrix_Step2 #matrix_' + num + '_column .add_Another').length > 0) {
				$j('.3dMatrix_Step2 #matrix_' + num + '_column .add_Another').remove();
			}
			
			$j("#matrix_" + num + "_column #columnsAdd_" + count + " .columnsLabelList tr:eq(1) td").append("<div class='action'>" + addAnother + "<div style='float:left; padding:10px 15px 0px 0px;'><a href='javascript:columnsLabelDelete(" + num + "," + count + "," + qcount + ");'>Delete</a></div></div>");
			
			if(count == 2){
				if ($j("#matrix_" + num + "_column #columnsAdd_1 .columnsLabelList tr:eq(1) td div.action").length) {
					$j('.3dMatrix_Step2 #matrix_' + num + '_column #columnsAdd_1 .columnsLabelList .action').remove();
				}
				var moveUp = moveUp.replace("upID", "2");
				var moveDown = moveDown.replace("downID", "1");
				$j("#matrix_" + num + "_column .columnsLabelList tr:eq(1) td").append("<div class='action'><div style='float:left; padding:10px 15px 0px 0px;'><a href=\"javascript:columnsLabelDelete(" + num + ",1," + qcount + ");\">Delete</a></div></div>");
				$j("#matrix_" + num + "_column .columnsLabelList tr:eq(1) td:eq(0) div.action").find("div:first-child").before(moveDown);
				$j("#matrix_" + num + "_column #columnsAdd_" + count + " .columnsLabelList tr:eq(1) td:eq(0) div.action").find("div:first-child").after(moveUp);
				
			}
			else {
				for (i = 2; i < count; i++) {
					moveUp = "<div style='float:left; padding:10px 15px 0px 0px;'><a href=\"javascript:columnsLabel_moveUp(" + num + ",upID);\">Move Up</a></div></div>";
					moveDown = "<div style='float:left; padding:10px 15px 0px 0px;'><a href=\"javascript:columnsLabel_moveDown(" + num + ",downID);\">Move Down</a></div></div>";
					var moveUp = moveUp.replace("upID", parseInt(i));
					var moveDown = moveDown.replace("downID", parseInt(i));
					$j("#matrix_" + num + "_column #columnsAdd_" + parseInt(i) + " .columnsLabelList tr:eq(1) td:eq(0) div.action").html(moveUp + moveDown + "<div style='float:left; padding:10px 15px 0px 0px;'><a href=\"javascript:columnsLabelDelete(" + num + "," + parseInt(i) + ","+qcount+");\">Delete</a></div>");
					
					move_Up = "<div style='float:left; padding:10px 15px 0px 0px;'><a href=\"javascript:columnsLabel_moveUp(" + num + ",upID);\">Move Up</a></div></div>";
					var move_Up = move_Up.replace("upID", parseInt(i + 1));
					$j("#matrix_" + num + "_column #columnsAdd_" + parseInt(i + 1) + " .columnsLabelList tr:eq(1) td:eq(0) div.action").html(addAnother + move_Up + "<div style='float:left; padding:10px 15px 15px 0px;'><a href=\"javascript:columnsLabelDelete(" + num + "," + parseInt(i + 1) + ","+qcount+");\">Delete</a></div>");
				}
			}
		}
	}else{
		if(columnItem.trim() == ""){
			alert(stepText+": Please enter a name for the column you just created before adding a new one.");
			$j("#matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+count+"_name']").val("");
			$j("#matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+count+"_name']").focus();
		}else{
			alert(stepText+": Before adding another column, please select a Question Type for the columns you already created.");
			$j("#matrix_"+num+"_column .columnsLabelList select[name='matrix_"+num+"_questionType_"+count+"_name']").focus();
		}
	}
}

//3D Matrix Columns MoveUp
function columnsLabel_moveUp(num,colnumber){
	
	var columnChoiceText = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" .columnsLabelList input[name='matrix_"+num+"_column_"+colnumber+"_name']").val();
	var columnChoiceTextnospace = columnChoiceText.replace(/ /g, "");
	var columnChoiceText_up = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" .columnsLabelList input[name='matrix_"+num+"_column_"+parseInt(colnumber-1)+"_name']").val();
	var columnChoiceTextnospace_up = columnChoiceText_up.replace(/ /g, "");
	
	var namepattern= /^[a-z\d()\-'\":_,.&\#%\\@\*!\$\+={}\[\]\|\/\?\s]+$/i; 
	var isvalid = 0;
	
	if(columnChoiceTextnospace == "") {
		alert("Please enter a name for the blank column."); 
		$j(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+colnumber+"_name']").focus();
	} else if(columnChoiceTextnospace.length > 250) {
		alert("Please enter a column name less than or equal to 250 characters."); 
		$j(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+colnumber+"_name']").focus();
	} else if (!columnChoiceTextnospace.match(namepattern)) {
	  	//alert('Invalid option value. Please enter alphanumeric characters, spaces, (, ), :, -, _, &, #, %, @, !, $, +, =, {, }, [, ], |, /, ?, <, >, *, or periods.');
		alert("The following characters may not be included in column names.  Please remove them. ~ ` ^ ; < >"); 
		$j(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+colnumber+"_name']").focus();
	}else{
		isvalid++;	
	}
	
	if(columnChoiceTextnospace_up == "") {
		alert("Please enter a name for the blank column.");
		$j(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+parseInt(colnumber-1)+"_name']").focus();
	} else if(columnChoiceTextnospace_up.length > 250) {
		alert("Please enter a column name less than or equal to 250 characters.");
		$j(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+parseInt(colnumber-1)+"_name']").focus();
	} else if (!columnChoiceTextnospace_up.match(namepattern)) {
	  	//alert('Invalid option value. Please enter alphanumeric characters, spaces, (, ), :, -, _, &, #, %, @, !, $, +, =, {, }, [, ], |, /, ?, <, >, *, or periods.');
		alert("The following characters may not be included in column names.  Please remove them. ~ ` ^ ; < >");
		$j(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+parseInt(colnumber-1)+"_name']").focus();
	}else{
		isvalid++;	
	}
	
	/*
	if(columnChoiceTextnospace == ""){
		alert("Please enter a name for the blank column.");
		$j(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+colnumber+"_name']").focus();
	}
	if(columnChoiceTextnospace_up == ""){
		alert("Please enter a name for the blank column.");
		$j(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+parseInt(colnumber-1)+"_name']").focus();
	}
	*/
	if(isvalid == 2){
		var attrInputValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" .columnsLabelList tr:eq(0) input").attr('value');
		var attrSelectValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" .columnsLabelList select").attr('value');
		var attrFreeTextValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #freeText_"+colnumber+" input:eq(0)").attr('value');
		var attrQuanCheckFromValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkbox_"+colnumber+" input:eq(0)").attr('value');
		var attrQuanCheckToValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkbox_"+colnumber+" input:eq(1)").attr('value');
		var attrQuanCheckWithOtherFromValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkboxWithOther_"+colnumber+" input:eq(0)").attr('value');
		var attrQuanCheckWithOtherToValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkboxWithOther_"+colnumber+" input:eq(1)").attr('value');
		var attrQuanDropDownFromValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanDropDown_"+colnumber+" input:eq(0)").attr('value');
		var attrQuanDropDownToValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanDropDown_"+colnumber+" input:eq(1)").attr('value');
		var attrQuanRadioFromValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanRadio_"+colnumber+" input:eq(0)").attr('value');
		var attrQuanRadioToValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanRadio_"+colnumber+" input:eq(1)").attr('value');
		var attrQualCheckValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualChkbox_"+colnumber+" .qualitativeValueSelectAddUpdate textarea:visible").val();
		var attrQualCheckWithOtherValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualChkboxWithOther_"+colnumber+" .qualitativeValueSelectAddUpdate textarea:visible").val();
		var attrQualDropDownValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualDropDown_"+colnumber+" .qualitativeValueSelectAddUpdate textarea:visible").val();
		var attrQualRadioValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualRadio_"+colnumber+" .qualitativeValueSelectAddUpdate textarea:visible").val();
		
		var attrInputValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" .columnsLabelList tr:eq(0) input").attr('value');
		var attrSelectValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" .columnsLabelList select").attr('value');
		var attrFreeTextValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #freeText_"+parseInt(colnumber-1)+" input:eq(0)").attr('value');
		var attrQuanCheckFromValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanChkbox_"+parseInt(colnumber-1)+" input:eq(0)").attr('value');
		var attrQuanCheckToValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanChkbox_"+parseInt(colnumber-1)+" input:eq(1)").attr('value');
		var attrQuanCheckWithOtherFromValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanChkboxWithOther_"+parseInt(colnumber-1)+" input:eq(0)").attr('value');
		var attrQuanCheckWithOtherToValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanChkboxWithOther_"+parseInt(colnumber-1)+" input:eq(1)").attr('value');
		var attrQuanDropDownFromValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanDropDown_"+parseInt(colnumber-1)+" input:eq(0)").attr('value');
		var attrQuanDropDownToValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanDropDown_"+parseInt(colnumber-1)+" input:eq(1)").attr('value');
		var attrQuanRadioFromValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanRadio_"+parseInt(colnumber-1)+" input:eq(0)").attr('value');
		var attrQuanRadioToValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanRadio_"+parseInt(colnumber-1)+" input:eq(1)").attr('value');
		var attrQualCheckValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #qualChkbox_"+parseInt(colnumber-1)+" .qualitativeValueSelectAddUpdate textarea:visible").val();
		var attrQualCheckWithOtherValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #qualChkboxWithOther_"+parseInt(colnumber-1)+" .qualitativeValueSelectAddUpdate textarea:visible").val();
		var attrQualDropDownValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #qualDropDown_"+parseInt(colnumber-1)+" .qualitativeValueSelectAddUpdate textarea:visible").val();
		var attrQualRadioValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #qualRadio_"+parseInt(colnumber-1)+" .qualitativeValueSelectAddUpdate textarea:visible").val();
	
		var moveUp = $j('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber)).html();
		var moveDown = $j('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber-1)).html();
		$j('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber-1)).html(moveUp);
		$j('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber)).html(moveDown);
		
		var action1 = $j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber)+" .columnsLabelList tr:eq(1) td:eq(0) div.action").html();
		var action2 = $j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" .columnsLabelList tr:eq(1) td:eq(0) div.action").html();
		$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber)+" .columnsLabelList tr:eq(1) td:eq(0) div.action").html(action2);
		$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" .columnsLabelList tr:eq(1) td:eq(0) div.action").html(action1);
		
		var on_change_input_up = "javascript:columnsOnChange("+num+",this,"+parseInt(colnumber-1)+");";
		var on_change_input_down = "javascript:columnsOnChange("+num+",this,"+parseInt(colnumber)+");";
		$j('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber-1)+' .columnsLabelList input').attr('onchange', on_change_input_up);
		$j('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber)+' .columnsLabelList input').attr('onchange', on_change_input_down);
		/*--- SQM-811 by Inderjeet ---*/
		$j('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber-1)+' .columnsLabelList input').each(function(){
			if($j(this).attr('rel') == "sort"){
				$j(this).attr('onchange','');
			}
			});
			$j('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber)+' .columnsLabelList input').each(function(){
			if($j(this).attr('rel') == "sort"){
				$j(this).attr('onchange','');
			}
			});
		
		$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber)+" .3DMatrixStep2").each(function(){
			var attrID = this.id;
			Numvalue = attrID.match(/\d+$/);
			var newID = attrID.replace('_'+Numvalue,'_'+parseInt(colnumber));
			$j(this).attr('id', newID);
			/*--- SQM-811 by Inderjeet ---*/
			if(attrID.search(/questionTypeSelect/) != -1){
				$j(this).attr('id','questionTypeSelect_'+num+'_'+parseInt(colnumber)+'');
				
			}
			
			var labelText = stringifyNumber(colnumber);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" span#colLabel_"+colnumber).text(labelText+" Column's Label:");
			var qnTypeText = stringifyNumber(colnumber);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" span#colQnType_"+colnumber).text(qnTypeText+" Column's Question Type:");
			
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" .columnsLabelList tr:eq(0) input").attr('value', attrInputValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" .columnsLabelList select").attr('value', attrSelectValue2);		
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #freeText_"+colnumber+" input:eq(0)").attr('value', attrFreeTextValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkbox_"+colnumber+" input:eq(0)").attr('value', attrQuanCheckFromValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkbox_"+colnumber+" input:eq(1)").attr('value', attrQuanCheckToValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkboxWithOther_"+colnumber+" input:eq(0)").attr('value', attrQuanCheckWithOtherFromValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkboxWithOther_"+colnumber+" input:eq(1)").attr('value', attrQuanCheckWithOtherToValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanDropDown_"+colnumber+" input:eq(0)").attr('value', attrQuanDropDownFromValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanDropDown_"+colnumber+" input:eq(1)").attr('value', attrQuanDropDownToValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanRadio_"+colnumber+" input:eq(0)").attr('value', attrQuanRadioFromValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanRadio_"+colnumber+" input:eq(1)").attr('value', attrQuanRadioToValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualChkbox_"+colnumber+" .qualitativeValueSelectAddUpdate textarea").val(attrQualCheckValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualChkboxWithOther_"+colnumber+" .qualitativeValueSelectAddUpdate textarea").val(attrQualCheckWithOtherValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualDropDown_"+colnumber+" .qualitativeValueSelectAddUpdate textarea").val(attrQualDropDownValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualRadio_"+colnumber+" .qualitativeValueSelectAddUpdate textarea").val(attrQualRadioValue2);
         /*--- SQM-811 by Inderjeet ---*/
		    $j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #freeText_"+colnumber+" input:eq(0)").attr('onchange','javascript:p3dfreetextchange(this,'+parseInt(colnumber)+')');
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkbox_"+colnumber+" input:eq(0)").attr('onchange','javascript:onchangefrom('+num+','+parseInt(colnumber)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkbox_"+colnumber+" input:eq(1)").attr('onchange','javascript:onchangeto('+num+','+parseInt(colnumber)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkboxWithOther_"+colnumber+" input:eq(0)").attr('onchange','javascript:onchangefrom('+num+','+parseInt(colnumber)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkboxWithOther_"+colnumber+" input:eq(1)").attr('onchange','javascript:onchangeto('+num+','+parseInt(colnumber)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanDropDown_"+colnumber+" input:eq(0)").attr('onchange','javascript:onchangefrom('+num+','+parseInt(colnumber)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanDropDown_"+colnumber+" input:eq(1)").attr('onchange','javascript:onchangeto('+num+','+parseInt(colnumber)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanRadio_"+colnumber+" input:eq(0)").attr('onchange','javascript:onchangefrom('+num+','+parseInt(colnumber)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanRadio_"+colnumber+" input:eq(1)").attr('onchange','javascript:onchangeto('+num+','+parseInt(colnumber)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #timeQns_"+colnumber+" input:eq(0)").attr('onchange','');
	 	});
		
		$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber)+" .3DMatrixStep2Name").each(function(){
			var attrName = this.name;
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[3] = parseInt(colnumber);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$j(this).attr('name', newName);
            /*--- SQM-811 by Inderjeet ---*/   
			var a = attrName.search(/quan/);
			if(a != -1){
				$j(this).attr('id', newName);
			}
			
			if(this.id == 'questionTypeSelect_'+parseInt(colnumber)+'' || this.id == 'questionTypeSelect_'+num+'_'+parseInt(colnumber)+''){
				$j(this).attr('id','questionTypeSelect_'+num+'_'+parseInt(colnumber)+'');
			}
		});
		
		$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber)+" .matrixQualElements").each(function(){
			if(this.name || this.id){
				if(this.id.length != 0){
					var attrName = this.id;
				}else{
					var attrName = this.name;
				}
				newStr = attrName.split("_");
				newStr[1] = num;
				newStr[3] = parseInt(colnumber);
				var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"";
				if($j(this).attr("name")){$j(this).attr('name', newName);}
				if($j(this).attr("id")){$j(this).attr('id', newName);}
			}
	 	});
		
		$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" .3DMatrixStep2").each(function(){
			var attrID = this.id;
			Numvalue = attrID.match(/\d+$/);
			var newID = attrID.replace('_'+Numvalue,'_'+parseInt(colnumber-1));
			$j(this).attr('id', newID);
			/*--- SQM-811 by Inderjeet ---*/
			if(attrID.search(/questionTypeSelect/) != -1){
				$j(this).attr('id','questionTypeSelect_'+num+'_'+parseInt(colnumber-1)+'');
				
			}
			
			var labelText = stringifyNumber(parseInt(colnumber-1));
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" span#colLabel_"+parseInt(colnumber-1)).text(labelText+" Column's Label:");
			var qnTypeText = stringifyNumber(parseInt(colnumber-1));
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" span#colQnType_"+parseInt(colnumber-1)).text(qnTypeText+" Column's Question Type:");
			
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" .columnsLabelList tr:eq(0) input").attr('value', attrInputValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" .columnsLabelList select").attr('value', attrSelectValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #freeText_"+parseInt(colnumber-1)+" input:eq(0)").attr('value', attrFreeTextValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanChkbox_"+parseInt(colnumber-1)+" input:eq(0)").attr('value', attrQuanCheckFromValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanChkbox_"+parseInt(colnumber-1)+" input:eq(1)").attr('value', attrQuanCheckToValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanChkboxWithOther_"+parseInt(colnumber-1)+" input:eq(0)").attr('value', attrQuanCheckWithOtherFromValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanChkboxWithOther_"+parseInt(colnumber-1)+" input:eq(1)").attr('value', attrQuanCheckWithOtherToValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanDropDown_"+parseInt(colnumber-1)+" input:eq(0)").attr('value', attrQuanDropDownFromValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanDropDown_"+parseInt(colnumber-1)+" input:eq(1)").attr('value', attrQuanDropDownToValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanRadio_"+parseInt(colnumber-1)+" input:eq(0)").attr('value', attrQuanRadioFromValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanRadio_"+parseInt(colnumber-1)+" input:eq(1)").attr('value', attrQuanRadioToValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #qualChkbox_"+parseInt(colnumber-1)+" textarea").val(attrQualCheckValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #qualChkboxWithOther_"+parseInt(colnumber-1)+" textarea").val(attrQualCheckWithOtherValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #qualDropDown_"+parseInt(colnumber-1)+" textarea").val(attrQualDropDownValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #qualRadio_"+parseInt(colnumber-1)+" textarea").val(attrQualRadioValue1);
          /*--- SQM-811 by Inderjeet ---*/
		    $j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #freeText_"+parseInt(colnumber-1)+" input:eq(0)").attr('onchange','javascript:p3dfreetextchange(this,'+parseInt(colnumber-1)+')');
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanChkbox_"+parseInt(colnumber-1)+" input:eq(0)").attr('onchange','javascript:onchangefrom('+num+','+parseInt(colnumber-1)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanChkbox_"+parseInt(colnumber-1)+" input:eq(1)").attr('onchange','javascript:onchangeto('+num+','+parseInt(colnumber-1)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanChkboxWithOther_"+parseInt(colnumber-1)+" input:eq(0)").attr('onchange','javascript:onchangefrom('+num+','+parseInt(colnumber-1)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanChkboxWithOther_"+parseInt(colnumber-1)+" input:eq(1)").attr('onchange','javascript:onchangeto('+num+','+parseInt(colnumber-1)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanDropDown_"+parseInt(colnumber-1)+" input:eq(0)").attr('onchange','javascript:onchangefrom('+num+','+parseInt(colnumber-1)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanDropDown_"+parseInt(colnumber-1)+" input:eq(1)").attr('onchange','javascript:onchangeto('+num+','+parseInt(colnumber-1)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanRadio_"+parseInt(colnumber-1)+" input:eq(0)").attr('onchange','javascript:onchangefrom('+num+','+parseInt(colnumber-1)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanRadio_"+parseInt(colnumber-1)+" input:eq(1)").attr('onchange','javascript:onchangeto('+num+','+parseInt(colnumber-1)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #timeQns_"+parseInt(colnumber-1)+" input:eq(0)").attr('onchange','');
	 	});
		
		$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" .3DMatrixStep2Name").each(function(){
			var attrName = this.name;
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[3] = parseInt(colnumber-1);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$j(this).attr('name', newName);
          /*--- SQM-811 by Inderjeet ---*/
			$j(this).attr('name', newName);
			var a = attrName.search(/quan/);
			if(a != -1){
				$j(this).attr('id', newName);
			}
			
			if(this.id == 'questionTypeSelect_'+parseInt(colnumber)+'' || this.id == 'questionTypeSelect_'+num+'_'+parseInt(colnumber)+''){
				$j(this).attr('id','questionTypeSelect_'+num+'_'+parseInt(colnumber-1)+'');
			}
	 	});
		
		$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" .matrixQualElements").each(function(){
			if(this.name || this.id){
				if(this.id.length != 0){
					var attrName = this.id;
				}else{
					var attrName = this.name;
				}
				newStr = attrName.split("_");
				newStr[1] = num;
				newStr[3] = parseInt(colnumber-1);
				var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"";
				if($j(this).attr("name")){$j(this).attr('name', newName);}
				if($j(this).attr("id")){$j(this).attr('id', newName);}
			}
	 	});
		
		//Grid Section
		$j("#matrix_"+num+"_grid .table-bordered tr").each(function(){
			var grid_moveUp = $j(this).find("td#"+parseInt(colnumber)+"").html();
			var grid_moveDown = $j(this).find("td#"+parseInt(colnumber-1)+"").html();
			$j(this).find("td#"+parseInt(colnumber-1)+"").html(grid_moveUp);
			$j(this).find("td#"+parseInt(colnumber)+"").html(grid_moveDown);
		});
       /*--- SQM-811 by Inderjeet ---*/
		$j(".matrixContainer"+num+" .tab_head tr").each(function(i){
			var pgrid_moveUp_name = $j(this).find("td#"+parseInt(colnumber)+"").html();
			var pgrid_moveDown_name = $j(this).find("td#"+parseInt(colnumber-1)+"").html();
			var pgrid_moveUp = $j(this).find("td#p3dtd"+parseInt(colnumber)+"").children().clone();
			var pgrid_moveDown = $j(this).find("td#p3dtd"+parseInt(colnumber-1)+"").children().clone();
			
			$j(this).find("td#"+parseInt(colnumber-1)+"").html(pgrid_moveUp_name);
			$j(this).find("td#"+parseInt(colnumber)+"").html(pgrid_moveDown_name);
			$j(this).find("td#p3dtd"+parseInt(colnumber-1)+"").html(pgrid_moveUp);
			$j(this).find("td#p3dtd"+parseInt(colnumber)+"").html(pgrid_moveDown);
			if(isNaN(($j(this).attr('id'))) == false){
				var rindex = $j(this).attr('id');
				changefieldnames(num,rindex,parseInt(colnumber-1),'prevcol');
				changefieldnames(num,rindex,parseInt(colnumber),'nextcol');
				chngematrixdatefield(num,parseInt(colnumber-1));
				chngematrixdatefield(num,parseInt(colnumber));
				setstartendlink(parseInt(colnumber-1));
				setstartendlink(parseInt(colnumber));
				//console.log(rindex);
			}
		});
		/*--- end ---*/
		$j("#matrix_"+num+"_grid .table-bordered").find("tr td#"+parseInt(colnumber)+".gridtd").each(function(){
			var attrName = $j(this).find("input").attr("name");
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[4] = parseInt(colnumber);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$j(this).find("input").attr("name", newName);
		});
		
		$j("#matrix_"+num+"_grid .table-bordered").find("tr td#"+parseInt(colnumber-1)+".gridtd").each(function(){
			var attrName = $j(this).find("input").attr("name");
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[4] = parseInt(colnumber-1);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$j(this).find("input").attr("name", newName);
		});
	}
}

//3D Matrix Columns MoveDown
function columnsLabel_moveDown(num,colnumber){
	
	var columnChoiceText = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber)+" .columnsLabelList input[name='matrix_"+num+"_column_"+parseInt(colnumber)+"_name']").val();
	var columnChoiceTextnospace = columnChoiceText.replace(/ /g, "");
	var columnChoiceText_down = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" .columnsLabelList input[name='matrix_"+num+"_column_"+parseInt(colnumber+1)+"_name']").val();
	var columnChoiceTextnospace_down = columnChoiceText_down.replace(/ /g, "");
	
	var namepattern= /^[a-z\d()\-'\":_,.&\#%\\@\*!\$\+={}\[\]\|\/\?\s]+$/i; 
	var isvalid = 0;
	
	if(columnChoiceTextnospace == "") {
		alert("Please enter a name for the blank column.");
		$j(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+parseInt(colnumber)+"_name']").focus();
	} else if(columnChoiceTextnospace.length > 250) {
		alert("Please enter a column name less than or equal to 250 characters.");
		$j(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+parseInt(colnumber)+"_name']").focus();
	} else if (!columnChoiceTextnospace.match(namepattern)) {
	  	//alert('Invalid option value. Please enter alphanumeric characters, spaces, (, ), :, -, _, &, #, %, @, !, $, +, =, {, }, [, ], |, /, ?, <, >, *, or periods.');
		alert("The following characters may not be included in column names.  Please remove them. ~ ` ^ ; < >");
		$j(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+parseInt(colnumber)+"_name']").focus();
	}else{
		isvalid++;	
	}
	
	if(columnChoiceTextnospace_down == "") {
		alert("Please enter a name for the blank column.");
		$j(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+parseInt(colnumber+1)+"_name']").focus();
	} else if(columnChoiceTextnospace_down.length > 250) {
		alert("Please enter a column name less than or equal to 250 characters.");
		$j(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+parseInt(colnumber+1)+"_name']").focus();
	} else if (!columnChoiceTextnospace_down.match(namepattern)) {
	  	//alert('Invalid option value. Please enter alphanumeric characters, spaces, (, ), :, -, _, &, #, %, @, !, $, +, =, {, }, [, ], |, /, ?, <, >, *, or periods.');
		alert("The following characters may not be included in column names.  Please remove them. ~ ` ^ ; < >");
		$j(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+parseInt(colnumber+1)+"_name']").focus();
	}else{
		isvalid++;	
	}
	/*
	if (columnChoiceTextnospace == ""){
		alert("Please enter a name for the blank column.");
		$j(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+parseInt(colnumber)+"_name']").focus();
	}
	if (columnChoiceTextnospace_down == ""){
		alert("Please enter a name for the blank column.");
		$j(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+parseInt(colnumber+1)+"_name']").focus();
	}
	*/
	if (isvalid == 2){
		var attrInputValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" .columnsLabelList tr:eq(0) input").attr('value');
		var attrSelectValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" .columnsLabelList select").attr('value');
		var attrFreeTextValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #freeText_"+colnumber+" input:eq(0)").attr('value');
		var attrQuanCheckFromValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkbox_"+colnumber+" input:eq(0)").attr('value');
		var attrQuanCheckToValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkbox_"+colnumber+" input:eq(1)").attr('value');
		var attrQuanCheckWithOtherFromValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkboxWithOther_"+colnumber+" input:eq(0)").attr('value');
		var attrQuanCheckWithOtherToValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkboxWithOther_"+colnumber+" input:eq(1)").attr('value');
		var attrQuanDropDownFromValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanDropDown_"+colnumber+" input:eq(0)").attr('value');
		var attrQuanDropDownToValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanDropDown_"+colnumber+" input:eq(1)").attr('value');
		var attrQuanRadioFromValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanRadio_"+colnumber+" input:eq(0)").attr('value');
		var attrQuanRadioToValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanRadio_"+colnumber+" input:eq(1)").attr('value');
		var attrQualCheckValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualChkbox_"+colnumber+" textarea:visible").val();
		var attrQualCheckWithOtherValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualChkboxWithOther_"+colnumber+" textarea:visible").val();
		var attrQualDropDownValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualDropDown_"+colnumber+" textarea:visible").val();
		var attrQualRadioValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualRadio_"+colnumber+" textarea:visible").val();
		
		var attrQualCheckValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualChkbox_"+colnumber+" textarea:visible").val();
		var attrQualCheckWithOtherValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualChkboxWithOther_"+colnumber+" textarea:visible").val();
		var attrQualDropDownValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualDropDown_"+colnumber+" textarea:visible").val();
		var attrQualRadioValue1 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualRadio_"+colnumber+" textarea:visible").val();
		
		var attrInputValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" .columnsLabelList tr:eq(0) input").attr('value');
		var attrSelectValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" .columnsLabelList select").attr('value');
		var attrFreeTextValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #freeText_"+parseInt(colnumber+1)+" input:eq(0)").attr('value');
		var attrQuanCheckFromValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanChkbox_"+parseInt(colnumber+1)+" input:eq(0)").attr('value');
		var attrQuanCheckToValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanChkbox_"+parseInt(colnumber+1)+" input:eq(1)").attr('value');
		var attrQuanCheckWithOtherFromValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanChkboxWithOther_"+parseInt(colnumber+1)+" input:eq(0)").attr('value');
		var attrQuanCheckWithOtherToValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanChkboxWithOther_"+parseInt(colnumber+1)+" input:eq(1)").attr('value');
		var attrQuanDropDownFromValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanDropDown_"+parseInt(colnumber+1)+" input:eq(0)").attr('value');
		var attrQuanDropDownToValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanDropDown_"+parseInt(colnumber+1)+" input:eq(1)").attr('value');
		var attrQuanRadioFromValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanRadio_"+parseInt(colnumber+1)+" input:eq(0)").attr('value');
		var attrQuanRadioToValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanRadio_"+parseInt(colnumber+1)+" input:eq(1)").attr('value');
		var attrQualCheckValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #qualChkbox_"+parseInt(colnumber+1)+" textarea:visible").val();
		var attrQualCheckWithOtherValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #qualChkboxWithOther_"+parseInt(colnumber+1)+" textarea:visible").val();
		var attrQualDropDownValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #qualDropDown_"+parseInt(colnumber+1)+" textarea:visible").val();
		var attrQualRadioValue2 = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #qualRadio_"+parseInt(colnumber+1)+" textarea:visible").val();
		
		var moveDown = $j('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber)).html();
		var moveUp = $j('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber+1)).html();
		$j('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber+1)).html(moveDown);
		$j('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber)).html(moveUp);

		var action1 = $j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber)+" .columnsLabelList tr:eq(1) td:eq(0) div.action").html();
		var action2 = $j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" .columnsLabelList tr:eq(1) td:eq(0) div.action").html();
		$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber)+" .columnsLabelList tr:eq(1) td:eq(0) div.action").html(action2);
		$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" .columnsLabelList tr:eq(1) td:eq(0) div.action").html(action1);
		
		var on_change_input_down = "javascript:columnsOnChange("+num+",this,"+parseInt(colnumber+1)+");";
		var on_change_input_up = "javascript:columnsOnChange("+num+",this,"+parseInt(colnumber)+");";
		$j('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber+1)+' .columnsLabelList input').attr('onchange', on_change_input_down);
		$j('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber)+' .columnsLabelList input').attr('onchange', on_change_input_up);
		/*--- SQM-811 by Inderjeet ---*/
		$j('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber+1)+' .columnsLabelList input').each(function(){
		if($j(this).attr('rel') == "sort"){
			$j(this).attr('onchange','');
		}
	    });
		$j('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber)+' .columnsLabelList input').each(function(){
		if($j(this).attr('rel') == "sort"){
			$j(this).attr('onchange','');
		}
	    });
		$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber)+" .3DMatrixStep2").each(function(){
			var attrID = this.id;
			Numvalue = attrID.match(/\d+$/);
			var newID = attrID.replace('_'+Numvalue,'_'+parseInt(colnumber));
			$j(this).attr('id', newID);
			/*--- SQM-811 by Inderjeet ---*/
			if(attrID.search(/questionTypeSelect/) != -1){
				$j(this).attr('id','questionTypeSelect_'+num+'_'+parseInt(colnumber)+'');
				
			}
			
			var labelText = stringifyNumber(colnumber);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" span#colLabel_"+colnumber).text(labelText+" Column's Label:");
			var qnTypeText = stringifyNumber(colnumber);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" span#colQnType_"+colnumber).text(qnTypeText+" Column's Question Type:");
			
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" .columnsLabelList tr:eq(0) input").attr('value', attrInputValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" .columnsLabelList select").attr('value', attrSelectValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #freeText_"+colnumber+" input:eq(0)").attr('value', attrFreeTextValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkbox_"+colnumber+" input:eq(0)").attr('value', attrQuanCheckFromValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkbox_"+colnumber+" input:eq(1)").attr('value', attrQuanCheckToValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkboxWithOther_"+colnumber+" input:eq(0)").attr('value', attrQuanCheckWithOtherFromValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkboxWithOther_"+colnumber+" input:eq(1)").attr('value', attrQuanCheckWithOtherToValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanDropDown_"+colnumber+" input:eq(0)").attr('value', attrQuanDropDownFromValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanDropDown_"+colnumber+" input:eq(1)").attr('value', attrQuanDropDownToValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanRadio_"+colnumber+" input:eq(0)").attr('value', attrQuanRadioFromValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanRadio_"+colnumber+" input:eq(1)").attr('value', attrQuanRadioToValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualChkbox_"+colnumber+" textarea").val(attrQualCheckValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualChkboxWithOther_"+colnumber+" textarea").val(attrQualCheckWithOtherValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualDropDown_"+colnumber+" textarea").val(attrQualDropDownValue2);
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualRadio_"+colnumber+" textarea").val(attrQualRadioValue2);
       /*--- SQM-811 by Inderjeet ---*/
	        $j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #freeText_"+colnumber+" input:eq(0)").attr('onchange','javascript:p3dfreetextchange(this,'+parseInt(colnumber)+')');
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkbox_"+colnumber+" input:eq(0)").attr('onchange','javascript:onchangefrom('+num+','+parseInt(colnumber)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkbox_"+colnumber+" input:eq(1)").attr('onchange','javascript:onchangeto('+num+','+parseInt(colnumber)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkboxWithOther_"+colnumber+" input:eq(0)").attr('onchange','javascript:onchangefrom('+num+','+parseInt(colnumber)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkboxWithOther_"+colnumber+" input:eq(1)").attr('onchange','javascript:onchangeto('+num+','+parseInt(colnumber)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanDropDown_"+colnumber+" input:eq(0)").attr('onchange','javascript:onchangefrom('+num+','+parseInt(colnumber)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanDropDown_"+colnumber+" input:eq(1)").attr('onchange','javascript:onchangeto('+num+','+parseInt(colnumber)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanRadio_"+colnumber+" input:eq(0)").attr('onchange','javascript:onchangefrom('+num+','+parseInt(colnumber)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanRadio_"+colnumber+" input:eq(1)").attr('onchange','javascript:onchangeto('+num+','+parseInt(colnumber)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #timeQns_"+colnumber+" input:eq(0)").attr('onchange','');
	 	});
		
		$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber)+" .3DMatrixStep2Name").each(function(){
			var attrName = this.name;
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[3] = parseInt(colnumber);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$j(this).attr('name', newName);
			
			/*--- SQM-811 by Inderjeet ---*/
			if(this.id == 'questionTypeSelect_'+num+'_'+parseInt(colnumber+1)+'' || this.id == 'questionTypeSelect_'+parseInt(colnumber+1)+''){
				$j(this).attr('id','questionTypeSelect_'+num+'_'+parseInt(colnumber)+'');
			}
			var a = attrName.search(/quan/);
			
			if(a != -1){
				$j(this).attr('id', newName);
			}
	 	});
		
		$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber)+" .matrixQualElements").each(function(){
			if(this.name || this.id){
				if(this.id.length != 0){
					var attrName = this.id;
				}else{
					var attrName = this.name;
				}
				newStr = attrName.split("_");
				newStr[1] = num;
				newStr[3] = parseInt(colnumber);
				var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"";
				if($j(this).attr("name")){$j(this).attr('name', newName);}
				if($j(this).attr("id")){$j(this).attr('id', newName);}
			}
	 	});
		
		$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" .3DMatrixStep2").each(function(){
			var attrID = this.id;
			Numvalue = attrID.match(/\d+$/);
			var newID = attrID.replace('_'+Numvalue,'_'+parseInt(colnumber+1));
			$j(this).attr('id', newID);
			if(attrID.search(/questionTypeSelect/) != -1){
				$j(this).attr('id','questionTypeSelect_'+num+'_'+parseInt(colnumber+1)+'');
				
			}
			
			var labelText = stringifyNumber(parseInt(colnumber+1));
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" span#colLabel_"+parseInt(colnumber+1)).text(labelText+" Column's Label:");
			var qnTypeText = stringifyNumber(parseInt(colnumber+1));
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" span#colQnType_"+parseInt(colnumber+1)).text(qnTypeText+" Column's Question Type:");
			
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" .columnsLabelList tr:eq(0) input").attr('value', attrInputValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" .columnsLabelList select").attr('value', attrSelectValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #freeText_"+parseInt(colnumber+1)+" input:eq(0)").attr('value', attrFreeTextValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanChkbox_"+parseInt(colnumber+1)+" input:eq(0)").attr('value', attrQuanCheckFromValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanChkbox_"+parseInt(colnumber+1)+" input:eq(1)").attr('value', attrQuanCheckToValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanChkboxWithOther_"+parseInt(colnumber+1)+" input:eq(0)").attr('value', attrQuanCheckWithOtherFromValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanChkboxWithOther_"+parseInt(colnumber+1)+" input:eq(1)").attr('value', attrQuanCheckWithOtherToValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanDropDown_"+parseInt(colnumber+1)+" input:eq(0)").attr('value', attrQuanDropDownFromValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanDropDown_"+parseInt(colnumber+1)+" input:eq(1)").attr('value', attrQuanDropDownToValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanRadio_"+parseInt(colnumber+1)+" input:eq(0)").attr('value', attrQuanRadioFromValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanRadio_"+parseInt(colnumber+1)+" input:eq(1)").attr('value', attrQuanRadioToValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #qualChkbox_"+parseInt(colnumber+1)+" textarea").val(attrQualCheckValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #qualChkboxWithOther_"+parseInt(colnumber+1)+" textarea").val(attrQualCheckWithOtherValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #qualDropDown_"+parseInt(colnumber+1)+" textarea").val(attrQualDropDownValue1);
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #qualRadio_"+parseInt(colnumber+1)+" textarea").val(attrQualRadioValue1);
		/*--- SQM-811 by Inderjeet ---*/
		    $j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #freeText_"+parseInt(colnumber+1)+" input:eq(0)").attr('onchange','javascript:p3dfreetextchange(this,'+parseInt(colnumber+1)+')');
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanChkbox_"+parseInt(colnumber+1)+" input:eq(0)").attr('onchange','javascript:onchangefrom('+num+','+parseInt(colnumber+1)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanChkbox_"+parseInt(colnumber+1)+" input:eq(1)").attr('onchange','javascript:onchangeto('+num+','+parseInt(colnumber+1)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanChkboxWithOther_"+parseInt(colnumber+1)+" input:eq(0)").attr('onchange','javascript:onchangefrom('+num+','+parseInt(colnumber+1)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanChkboxWithOther_"+parseInt(colnumber+1)+" input:eq(1)").attr('onchange','javascript:onchangeto('+num+','+parseInt(colnumber+1)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanDropDown_"+parseInt(colnumber+1)+" input:eq(0)").attr('onchange','javascript:onchangefrom('+num+','+parseInt(colnumber+1)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanDropDown_"+parseInt(colnumber+1)+" input:eq(1)").attr('onchange','javascript:onchangeto('+num+','+parseInt(colnumber+1)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanRadio_"+parseInt(colnumber+1)+" input:eq(0)").attr('onchange','javascript:onchangefrom('+num+','+parseInt(colnumber+1)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanRadio_"+parseInt(colnumber+1)+" input:eq(1)").attr('onchange','javascript:onchangeto('+num+','+parseInt(colnumber+1)+',this)');
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #timeQns_"+parseInt(colnumber+1)+" input:eq(0)").attr('onchange','');
	 	});
		
		$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" .3DMatrixStep2Name").each(function(){
			var attrName = this.name;
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[3] = parseInt(colnumber+1);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$j(this).attr('name', newName);
           /*--- SQM-811 by Inderjeet ---*/
			if(this.id == 'questionTypeSelect_'+parseInt(colnumber+1)+'' || this.id == 'questionTypeSelect_'+num+'_'+parseInt(colnumber+1)+''){
				$j(this).attr('id','questionTypeSelect_'+num+'_'+parseInt(colnumber+1)+'');
			}
			var a = attrName.search(/quan/);
			
			if(a != -1){
				$j(this).attr('id', newName);
			}
	 	});
		
		$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" .matrixQualElements").each(function(){
			if(this.name || this.id){
				if(this.id.length != 0){
					var attrName = this.id;
				}else{
					var attrName = this.name;
				}
				newStr = attrName.split("_");
				newStr[1] = num;
				newStr[3] = parseInt(colnumber+1);
				var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"";
				if($j(this).attr("name")){$j(this).attr('name', newName);}
				if($j(this).attr("id")){$j(this).attr('id', newName);}
			}
	 	});
		
		//Grid Section
		$j("#matrix_"+num+"_grid .table-bordered tr").each(function(){
			var grid_moveDown = $j(this).find("td#"+parseInt(colnumber)+"").html();
			var grid_moveUp = $j(this).find("td#"+parseInt(colnumber+1)+"").html();
			$j(this).find("td#"+parseInt(colnumber+1)+"").html(grid_moveDown);
			$j(this).find("td#"+parseInt(colnumber)+"").html(grid_moveUp);
		});
        /*--- SQM-811 by Inderjeet ---*/
		$j(".matrixContainer"+num+" .tab_head tr").each(function(i){
			var pgrid_moveDown_name = $j(this).find("td#"+parseInt(colnumber)+"").html();
			var pgrid_moveUp_name = $j(this).find("td#"+parseInt(colnumber+1)+"").html();
			var pgrid_moveDown = $j(this).find("td#p3dtd"+parseInt(colnumber)+"").children().clone();
			var pgrid_moveUp = $j(this).find("td#p3dtd"+parseInt(colnumber+1)+"").children().clone();
			
			$j(this).find("td#"+parseInt(colnumber+1)+"").html(pgrid_moveDown_name);
			$j(this).find("td#"+parseInt(colnumber)+"").html(pgrid_moveUp_name);
			$j(this).find("td#p3dtd"+parseInt(colnumber+1)+"").html(pgrid_moveDown);
			$j(this).find("td#p3dtd"+parseInt(colnumber)+"").html(pgrid_moveUp);
			if(isNaN(($j(this).attr('id'))) == false){
				var rindex = $j(this).attr('id');
			changefieldnames(num,rindex,parseInt(colnumber),'prevcol');
			changefieldnames(num,rindex,parseInt(colnumber+1),'nextcol');
			chngematrixdatefield(num,parseInt(colnumber));
			chngematrixdatefield(num,parseInt(colnumber+1));
			setstartendlink(parseInt(colnumber));
			setstartendlink(parseInt(colnumber+1));
			}
			
		});
		/*    end    */
		$j("#matrix_"+num+"_grid .table-bordered").find("tr td#"+parseInt(colnumber)+".gridtd").each(function(){
			var attrName = $j(this).find("input").attr("name");
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[4] = parseInt(colnumber);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$j(this).find("input").attr("name", newName);
		});
		
		$j("#matrix_"+num+"_grid .table-bordered").find("tr td#"+parseInt(colnumber+1)+".gridtd").each(function(){
			var attrName = $j(this).find("input").attr("name");
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[4] = parseInt(colnumber+1);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$j(this).find("input").attr("name", newName);
		});
	}	
}

//3D Matrix Columns Delete
function columnsLabelDelete(num,id,qcount){
	addAnother = "<div style='float:left; padding:10px 15px 0px 0px;'><a href='javascript:columnsLabelAdd("+num+","+qcount+");'>Add Another Column</a></div>";
	moveUp = "<div style='float:left; padding:10px 15px 0px 0px;'><a href=\"javascript:columnsLabel_moveUp("+num+",upID);\">Move Up</a></div>";
	moveDown = "<div style='float:left; padding:10px 15px 0px 0px;'><a href=\"javascript:columnsLabel_moveDown("+num+",downID);\">Move Down</a></div>";
	
	$j(".3dMatrix_Step2 #matrix_"+num+"_column").find("#columnsAdd_"+id).remove();
	//$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+id).parent('div').remove();
	
	count = $j("#matrix_"+num+"_column_count").val();
	newCount = parseInt(count)-1;
	$j("#matrix_"+num+"_column_count").val(newCount);
	
	for(i = id; i <= newCount; i++){
		$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(i+1)+" .3DMatrixStep2").each(function(){
			var attrID = this.id;
			Numvalue = attrID.match(/\d+$/);
			var newID = attrID.replace('_'+Numvalue,'_'+parseInt(i));
			$j(this).attr('id', newID);
			/*--- SQM-811 by Inderjeet ---*/
			if(attrID.search(/questionTypeSelect/) != -1){
				$j(this).attr('id','questionTypeSelect_'+num+'_'+parseInt(i)+'');
				//console.log(num);
			}
			
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(i+1)+" .columnsLabelList tr:eq(1) td:eq(0) div.action > div:nth-child(3) a").attr('href','javascript:columnsLabelDelete('+num+','+i+','+qcount+')');
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(i+1)).attr('id','columnsAdd_'+i)
	 	});
		
		var labelText = stringifyNumber(i);
		$j("#matrix_"+num+"_column #columnsAdd_"+i+" span#colLabel_"+i).text(labelText+" Column's Label:");
		var qnTypeText = stringifyNumber(i);
		$j("#matrix_"+num+"_column #columnsAdd_"+i+" span#colQnType_"+i).text(qnTypeText+" Column's Question Type:");
		
		var on_change_input = "javascript:columnsOnChange("+num+",this,"+parseInt(i)+");";
		$j('#matrix_'+num+'_column #columnsAdd_'+parseInt(i)+' .columnsLabelList input').attr('onchange', on_change_input);
		$j('#matrix_'+num+'_column #columnsAdd_'+parseInt(i)+' .columnsLabelList input').each(function(){
			if($j(this).attr('rel') == "sort"){
				$j(this).attr('onchange','');
			}
			});
			$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(i)+" #timeQns_"+parseInt(i)+" input:eq(0)").attr('onchange','');
		
		$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(i)+" .3DMatrixStep2Name").each(function(){
			var attrName = this.name;
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[3] = parseInt(i);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$j(this).attr('name', newName);

			var a = attrName.search(/quan/);
			if(a != -1){
				$j(this).attr('id', newName);
			}
			if(this.id == 'questionTypeSelect_'+parseInt(i)+'' || this.id == 'questionTypeSelect_'+num+'_'+parseInt(i)+''){
				$j(this).attr('id','questionTypeSelect_'+num+'_'+parseInt(i)+'');
			}
	 	});
		$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(i)+" .matrixQualElements").each(function(){
			if(this.name || this.id){
				if(this.id.length != 0){
					var attrName = this.id;
				}else{
					var attrName = this.name;
				}
				newStr = attrName.split("_");
				newStr[1] = num;
				newStr[3] = parseInt(i);
				var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"";
				if($j(this).attr("name")){$j(this).attr('name', newName);}
				if($j(this).attr("id")){$j(this).attr('id', newName);}
			}
	 	});
	}	
	
	 var j = 1;
	 $j('.3dMatrix_Step2 #matrix_'+num+'_column tr:eq(1)').each(function(){
	 	if(j == 2){
			var moveUp = moveUp.replace("upID","2");
			var moveDown = moveDown.replace("downID","1");
			$j("#matrix_"+num+"_column .columnsLabelList tr:eq(1) td:eq(0) div.action").find("div:first-child").before(moveDown);
			$j("#matrix_"+num+"_column #columnsAdd_2 .columnsLabelList tr:eq(1) td:eq(0) div.action").find("div:first-child").after(moveUp);
		}else{
			for(j = 1; j <= newCount; j++){
				moveUp = "<div style='float:left; padding:10px 15px 0px 0px;'><a href=\"javascript:columnsLabel_moveUp("+num+",upID);\">Move Up</a></div></div>";
				moveDown = "<div style='float:left; padding:10px 15px 0px 0px;'><a href=\"javascript:columnsLabel_moveDown("+num+",downID);\">Move Down</a></div></div>";
				var moveUp = moveUp.replace("upID",parseInt(j));
				var moveDown =  moveDown.replace("downID",parseInt(j));
				$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(j)+" .columnsLabelList tr:eq(1) td:eq(0) div.action").html(moveUp+moveDown+"<div style='float:left; padding:10px 15px 0px 0px;'><a href=\"javascript:columnsLabelDelete("+num+","+parseInt(j)+","+qcount+");\">Delete</a></div>");
				
				if(j == 1){
					$j("#matrix_"+num+"_column #columnsAdd_1 .columnsLabelList tr:eq(1) td:eq(0) div.action > div:nth-child(1)").remove();
				} 
				 
				move_Up = "<div style='float:left; padding:10px 15px 0px 0px;'><a href=\"javascript:columnsLabel_moveUp("+num+",upID);\">Move Up</a></div></div>";
				var move_Up = move_Up.replace("upID",parseInt(j+3));
				$j("#matrix_"+num+"_column #columnsAdd_"+parseInt(newCount)+" .columnsLabelList tr:eq(1) td:eq(0) div.action").html(addAnother+moveUp+"<div style='float:left; padding:10px 15px 15px 0px;'><a href=\"javascript:columnsLabelDelete("+num+","+parseInt(j)+","+qcount+");\">Delete</a></div>");
			}	
		
			if(newCount == 1){
				add_another = "<div class='add_Another'><div style='float:left; padding:10px 15px 0px 0px;'><a href='javascript:columnsLabelAdd("+num+","+qcount+");'>Add Another Column</a></div></div>";
				$j("#matrix_"+num+"_column #columnsAdd_1 div.action").remove();
				$j("#matrix_"+num+"_column #columnsAdd_1 .columnsLabelList tr:eq(1) td:eq(0)").append(add_another);
			}
			
			j = j+1;
	  	}	
	});	
	
	//Grid Section
	$j("#matrix_"+num+"_grid .table-bordered tr").each(function(){
		$j(this).find("td#"+id+"").remove();
	});	
	/*--- SQM-811 by Inderjeet ---*/
	
	$j(".matrixContainer"+num+" .tab_head").find("td#"+id+"").remove();
	$j(".matrixContainer"+num+" .tab_head").find("td#p3dtd"+id+"").remove();
		

	for(k = id; k <= newCount; k++){
		$j("#matrix_"+num+"_grid .table-bordered").find("tr td#"+parseInt(k+1)+"").attr('id', k);
		$j(".matrixContainer"+num+" .tab_head").find("td#"+parseInt(k+1)+"").attr('id',k);/*--- SQM-811 by Inderjeet ---*/
		$j(".matrixContainer"+num+" .tab_head").find("td#p3dtd"+parseInt(k+1)+"").attr('id','p3dtd'+k+'');/*--- SQM-811 by Inderjeet ---*/
		$j(".matrixContainer"+num+" .tab_head tr").each(function(i){/*--- SQM-811 by Inderjeet ---*/
		 if(isNaN(($j(this).attr('id'))) == false){
			var rindex = $j(this).attr('id');
		    changefieldnames(num,rindex,parseInt(k),'prevcol'); 
			chngematrixdatefield(num,parseInt(k));
			setstartendlink(parseInt(k));
		 } 
	    });

		$j("#matrix_"+num+"_grid .table-bordered").find("tr td#"+parseInt(k)+".gridtd").each(function(){
			var attrName = $j(this).find("input").attr("name");
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[4] = parseInt(k);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$j(this).find("input").attr("name", newName);
			
			var attrID = $j(this).attr("onclick");
			newID = attrID.split(",");
			newID[2] = parseInt(k);
			var on_click_td = ""+newID[0]+","+newID[1]+","+newID[2]+");";
			$j(this).attr('onclick', on_click_td);
		});
		$j("#matrix_"+num+"_grid .table-bordered").find("tr td#"+parseInt(k)+".gridColumn").each(function(){
			var attrID = $j(this).attr("onclick");
			newID = attrID.split(",");
			newID[1] = parseInt(k);
			var on_click_td = ""+newID[0]+","+newID[1]+","+newID[2]+"";
			$j(this).attr('onclick', on_click_td);
		});
	}
}

function rowsOnChange(num,attr,rindex){
	var rowObjs=[];
	var html = "";
    var obj = {
        "ROW_ID" : rindex,
        "ROW_NAME" : attr.value
    }   
 
    if(attr.value.trim() != ""){
		// add object
	    rowObjs.push(obj);
	   
    	if($j("#matrix_"+num+"_grid .table-bordered").find('tr:eq('+rindex+') td:eq(0)').length){
			// update existing rows value in the table
			$j("#matrix_"+num+"_grid .table-bordered").find('tr:eq('+rindex+') td:eq(0)').html(obj['ROW_NAME']);
			//$j(".matrixContainer"+num+" .tab_head ").find('tr[id="'+rindex+'"] td:eq(0) div').html(obj['ROW_NAME']);
         
			if($j('input[name=MaximumNumber'+num+']').val() > 1){
			var rcnt = $j("#matrix_"+num+"_grid .table-bordered").find('tr').length;
			for(let r=1;r < rcnt; r++){
			$j("#matrix_"+num+"_grid .table-bordered").find('tr:eq('+r+') td:eq(0)').html(obj['ROW_NAME']+' '+r);
			}
		   }
               
			$j('.required').show();
		}else{
		    // dynamically create rows in the table
		    html = "<tr id="+ obj['ROW_ID'] + " class='gridtr'><td id='0' class='gridRow' onclick=\"javascript:checkUncheckImageRowColumn("+num+","+obj['ROW_ID']+",'row');\">"+ obj['ROW_NAME'] + "</td></tr>";
			//add to the table
			rowtoappend = rindex-1;
			
				

			
			$j("#matrix_"+num+"_grid .table-bordered").append(html);
			//$j(".matrixContainer"+num+" .tab_head ").append("<tr id="+ obj['ROW_ID'] +" class='"+cls+"'><td id='0' ><div class='matrixRowLabel questiontext'>"+ obj['ROW_NAME'] + "</div></td></tr>");
			
			count = $j("#matrix_"+num+"_grid .table-bordered").find('tr:eq(0) td').length;
			//var c = parseInt(count-1);
			
			for(i = 1; i <= count-1; i++){
				//var j =  $j("#matrix_"+num+"_grid .table-bordered").find('tr:eq('+obj['ROW_ID']+') td').length
				//console.log(j);
				$j("#matrix_"+num+"_grid .table-bordered").find('tr:eq('+obj['ROW_ID']+')').append("<td id="+parseInt(i)+" class='gridtd' onclick=\"javascript:checkUncheckImage("+num+","+obj['ROW_ID']+","+i+");\"><input type='checkbox' name='matrix_"+num+"_required_"+obj['ROW_ID']+"_"+i+"' id='matrix_"+num+"_required_"+obj['ROW_ID']+"_"+i+"' value='1' style='display:none;'></td>");
			}
			
			$j("#matrix_"+num+"_grid .table-bordered").show();
			/*$j('.required').show();*/
			
			if($j("#matrix_"+num+"_grid .optional").length){
				$j('.required').show();
				$j('.optional').hide();
			}else if($j("#matrix_"+num+"_grid .required").length){
				$j('.optional').show();
				$j('.required').hide();
			}else{
				$j('.required').show();
			}
		}
		/*--- SQM-811 by Inderjeet ---*/
			
		if(($j(".matrixContainer"+num+" .tab_head ").find('tr[id="'+rindex+'"] td:eq(0)').length)){
			$j(".matrixContainer"+num+" .tab_head ").find('tr[id="'+rindex+'"] td:eq(0) div').html(obj['ROW_NAME']);
			$j('.addnewrow'+num+' a').html("<img src='../../images/icons/add.png' width='15' height='15' style='vertical-align:top;margin-right:3px;'>Add New "+obj['ROW_NAME']);
			if($j('input[name=MaximumNumber'+num+']').val() > 1){
				var rcnt = $j("#matrix_"+num+"_grid .table-bordered").find('tr').length;
				for(let r=1;r < rcnt; r++){
					$j(".matrixContainer"+num+" .tab_head ").find('tr[id="'+r+'"] td:eq(0) div').html(obj['ROW_NAME']+' '+r);
				}
			}
		}else{
			$j(".matrixContainer"+num+" .tab_head ").append('<tr id="'+rindex+'" class="even"><td id="0" ><div class="matrixRowLabel questiontext">'+ obj['ROW_NAME'] + '</div></td><td class ="helptdcls'+num+'" id ="helptd'+num+rindex+'" style="min-width:240px;display:none;" ><div  id="helptext_'+num+rindex+'" style="margin: 10px 10px 10px 0px;"></div></td></tr>');//SQM-965
			
			if(rowtoappend >= 1){
			var prevRow = $j(".matrixContainer"+num+" .tab_head tr[id='"+rowtoappend+"']").children('td').slice(2).clone();
			$j(".matrixContainer"+num+" .tab_head tr[id='"+obj['ROW_ID']+"']").append(prevRow);
			
			for(i = 1;i <= count; i++){
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"]  #matrix_'+num+'_textBox_'+rowtoappend+'_'+i+'').attr('id','matrix_'+num+'_textBox_'+obj['ROW_ID']+'_'+i+'')
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"]  #matrix_'+num+'_textBox_'+obj['ROW_ID']+'_'+i+' #matrix_'+num+'_textBox_'+obj['ROW_ID']+'_'+i+'').attr({
					name: 'matrix_'+num+'_textBox_'+obj['ROW_ID']+'_'+i+'',
					id: 'matrix_'+num+'_textBox_'+obj['ROW_ID']+'_'+i+'',
					value: ''
				 });
				 $j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] #matrix_'+num+'_textBox_'+obj['ROW_ID']+'_'+i+' #matrix_'+num+'_textBox_'+rowtoappend+'_'+i+'_cnt').html(15);
				 $j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] #matrix_'+num+'_textBox_'+obj['ROW_ID']+'_'+i+' #matrix_'+num+'_textBox_'+rowtoappend+'_'+i+'_cnt').attr('id','matrix_'+num+'_textBox_'+obj['ROW_ID']+'_'+i+'_cnt');
				 
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] #matrix_'+num+'_freeText_'+rowtoappend+'_'+i+'').attr('id','matrix_'+num+'_freeText_'+obj['ROW_ID']+'_'+i+'') 
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] #matrix_'+num+'_freeText_'+obj['ROW_ID']+'_'+i+' #freeText_'+rowtoappend+'_'+i+'_cnt_div').attr('id','freeText_'+obj['ROW_ID']+'_'+i+'_cnt_div');
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] #matrix_'+num+'_freeText_'+obj['ROW_ID']+'_'+i+' #matrix_'+num+'_freeText_'+rowtoappend+'_'+i+'_cnt').attr('id','matrix_'+num+'_freeText_'+obj['ROW_ID']+'_'+i+'_cnt');
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] #matrix_'+num+'_freeText_'+obj['ROW_ID']+'_'+i+' #matrix_'+num+'_freeText_'+obj['ROW_ID']+'_'+i+'').attr({
					name: 'matrix_'+num+'_freeText_'+obj['ROW_ID']+'_'+i+'',
					id: 'matrix_'+num+'_freeText_'+obj['ROW_ID']+'_'+i+'',
					value: ''
				});
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] td[id="p3dtd'+i+'"] #matrix_'+num+'_psingledate_'+rowtoappend+'_'+i+'').attr({id :'matrix_'+num+'_psingledate_'+obj['ROW_ID']+'_'+i+'',class: 'matrixColumnInput mpquestion'+parseInt(i)+' mpquestion_'+parseInt(i)+'_Single pclass'});
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] td[id="p3dtd'+i+'"] #matrix_'+num+'_pmultipledate_'+rowtoappend+'_'+i+'').attr({id :'matrix_'+num+'_pmultipledate_'+obj['ROW_ID']+'_'+i+'',class: 'matrixColumnInput mpquestion'+parseInt(i)+' mpquestion_'+parseInt(i)+'_Any pclass'});
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] td[id="p3dtd'+i+'"] #matrix_'+num+'_pstartenddate_'+rowtoappend+'_'+i+'').attr({id :'matrix_'+num+'_pstartenddate_'+obj['ROW_ID']+'_'+i+'',class: 'matrixColumnInput mpquestion'+parseInt(i)+' mpquestion_'+parseInt(i)+'_StartEnd pclass'});
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] td[id="p3dtd'+i+'"] #matrix_'+num+'_psurvaydate_'+rowtoappend+'_'+i+'').attr({id :'matrix_'+num+'_psurvaydate_'+obj['ROW_ID']+'_'+i+'',class: 'matrixColumnInput mpquestion'+parseInt(i)+' mpquestion_'+parseInt(i)+'_SurveyLaunch pclass'});
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] td[id="p3dtd'+i+'"] #matrix_'+num+'_prangedate_'+rowtoappend+'_'+i+'').attr({id :'matrix_'+num+'_prangedate_'+obj['ROW_ID']+'_'+i+'',class: 'matrixColumnInput mpquestion'+parseInt(i)+' mpquestion_'+parseInt(i)+'_Range pclass'});
				
				 textcount = parseInt($j("input[name = matrix_"+num+"_freetext_"+i+"_name]").val());
			//	console.log(textcount,i);
				 if(textcount != ''){
				  if(isNaN(textcount)){
						$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] #matrix_'+num+'_freeText_'+obj['ROW_ID']+'_'+i+' #matrix_'+num+'_freeText_'+obj['ROW_ID']+'_'+i+'_cnt').html(0);
					}else{
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] #matrix_'+num+'_freeText_'+obj['ROW_ID']+'_'+i+' #matrix_'+num+'_freeText_'+obj['ROW_ID']+'_'+i+'_cnt').html(parseInt(textcount));}
			    }else{
					$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] #matrix_'+num+'_freeText_'+obj['ROW_ID']+'_'+i+' #matrix_'+num+'_freeText_'+obj['ROW_ID']+'_'+i+'_cnt').html(0);
				}

				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] #matrix_'+num+'_p3dquanchk_'+rowtoappend+'_'+i+'').attr('id','matrix_'+num+'_p3dquanchk_'+obj['ROW_ID']+'_'+i+'');
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] #matrix_'+num+'_p3dquanchkwith_'+rowtoappend+'_'+i+'').attr('id','matrix_'+num+'_p3dquanchkwith_'+obj['ROW_ID']+'_'+i+'');
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] #matrix_'+num+'_p3dquandropdown_'+rowtoappend+'_'+i+'').attr('id','matrix_'+num+'_p3dquandropdown_'+obj['ROW_ID']+'_'+i+'');
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] #matrix_'+num+'_p3dquandropdown'+obj['ROW_ID']+''+i+' #matrix_'+num+'_p3dnumdd_'+rowtoappend+'_'+i+'').attr({
					id: 'matrix_'+num+'_p3dnumdd_'+obj['ROW_ID']+'_'+i+'',
					name: 'p3dnumdd'+obj['ROW_ID']+''+i+''
				});
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] #matrix_'+num+'_p3dquanradio_'+rowtoappend+'_'+i+'').attr('id','matrix_'+num+'_p3dquanradio_'+obj['ROW_ID']+'_'+i+''); 

				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] #matrix_'+num+'_p3dqualchk_'+rowtoappend+'_'+i+'').attr('id','matrix_'+num+'_p3dqualchk_'+obj['ROW_ID']+'_'+i+'');
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] #matrix_'+num+'_p3dqualchkwith_'+rowtoappend+'_'+i+'').attr('id','matrix_'+num+'_p3dqualchkwith_'+obj['ROW_ID']+'_'+i+'');
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] #matrix_'+num+'_p3dqualdropdown_'+rowtoappend+'_'+i+'').attr('id','matrix_'+num+'_p3dqualdropdown_'+obj['ROW_ID']+'_'+i+'');
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] #matrix_'+num+'_p3dqualdropdown_'+obj['ROW_ID']+'_'+i+' #matrix_'+num+'_p3dnonnumdd_'+rowtoappend+'_'+i+'').attr({
					id: 'matrix_'+num+'_p3dnonnumdd_'+obj['ROW_ID']+'_'+i+'',
					name: 'p3dnonnumdd'+obj['ROW_ID']+''+i+''
				});
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] #matrix_'+num+'_p3dqualradio_'+rowtoappend+'_'+i+'').attr('id','matrix_'+num+'_p3dqualradio_'+obj['ROW_ID']+'_'+i+'');
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] #matrix_'+num+'_timeQuns_'+rowtoappend+'_'+i+'').attr('id','matrix_'+num+'_timeQuns_'+obj['ROW_ID']+'_'+i+''); 
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] #matrix_'+num+'_timeQuns_'+obj['ROW_ID']+'_'+i+' select').attr({
					name:'timeQns_'+obj['ROW_ID']+'_'+i+'',
					class: 'select-box timeQns_'+num+'_'+i+'',
				});
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] td[id="p3dtd'+i+'"] #matrix_'+num+'_psingledate_'+obj['ROW_ID']+'_'+i+' input').attr({name :'matrix_'+num+'_basicDate_'+obj['ROW_ID']+'_'+i+'',id :'matrix_'+num+'_basicDate_'+obj['ROW_ID']+'_'+i+''});
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] td[id="p3dtd'+i+'"] #matrix_'+num+'_pmultipledate_'+obj['ROW_ID']+'_'+i+' input').attr({name :'matrix_'+num+'_multidate_'+obj['ROW_ID']+'_'+i+'',id :'matrix_'+num+'_multidate_'+obj['ROW_ID']+'_'+i+''});
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] td[id="p3dtd'+i+'"] #matrix_'+num+'_pstartenddate_'+obj['ROW_ID']+'_'+i+' input').attr({name :'matrix_'+num+'_sbasicDate_'+obj['ROW_ID']+'_'+i+'',id :'matrix_'+num+'_sbasicDate_'+obj['ROW_ID']+'_'+i+''});
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] td[id="p3dtd'+i+'"] #matrix_'+num+'_psurvaydate_'+obj['ROW_ID']+'_'+i+' input').attr({name :'matrix_'+num+'_slaunchdate_'+obj['ROW_ID']+'_'+i+'',id :'matrix_'+num+'_slaunchdate_'+obj['ROW_ID']+'_'+i+''});
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] td[id="p3dtd'+i+'"] #matrix_'+num+'_prangedate_'+obj['ROW_ID']+'_'+i+' input').attr({name :'matrix_'+num+'_rangeDate_'+obj['ROW_ID']+'_'+i+'',id :'matrix_'+num+'_rangeDate_'+obj['ROW_ID']+'_'+i+''});
				copypicker('matrix_'+num+'_basicDate_'+obj['ROW_ID']+'_'+i+'',0);
				copypicker('matrix_'+num+'_multidate_'+obj['ROW_ID']+'_'+i+'',0);
				copypicker('matrix_'+num+'_sbasicDate_'+obj['ROW_ID']+'_'+i+'',0);
				copypicker('matrix_'+num+'_slaunchdate_'+obj['ROW_ID']+'_'+i+'',0);
				copypicker('matrix_'+num+'_rangeDate_'+obj['ROW_ID']+'_'+i+'',0);
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] td[id="p3dtd'+i+'"] #matrix_'+num+'_psingledate_'+obj['ROW_ID']+'_'+i+' input').val('');
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] td[id="p3dtd'+i+'"] #matrix_'+num+'_pmultipledate_'+obj['ROW_ID']+'_'+i+' input').val('');
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] td[id="p3dtd'+i+'"] #matrix_'+num+'_pstartenddate_'+obj['ROW_ID']+'_'+i+' input').val('');
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] td[id="p3dtd'+i+'"] #matrix_'+num+'_psurvaydate_'+obj['ROW_ID']+'_'+i+' input').val('');
				$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] td[id="p3dtd'+i+'"] #matrix_'+num+'_prangedate_'+obj['ROW_ID']+'_'+i+' input').val('');
				if($j('#matrix_'+num+'_chkSpecialTimeSeries_'+i+'_name').is(':checked')){
				   $j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] #matrix_'+num+'_timeQuns_'+obj['ROW_ID']+'_'+i+' select').find('[value="0"]').attr("selected","selected");
				}else{
					$j('.matrixContainer'+num+' .tab_head tr[id="'+obj['ROW_ID']+'"] #matrix_'+num+'_timeQuns_'+obj['ROW_ID']+'_'+i+' select').find('[value="Select"]').attr("selected","selected");
				}
			    if($j("#matrix_"+num+"_grid .table-bordered tr[id='"+obj['ROW_ID']+"'] td[id='"+i+"']").find("img").length){
					$j(".matrixContainer"+num+" .tab_head tr[id='"+obj['ROW_ID']+"'] td[id='p3dtd"+i+"']").find(".requiredD").remove();
					$j(".matrixContainer"+num+" .tab_head tr[id='"+obj['ROW_ID']+"'] td[id='p3dtd"+i+"']").find(".pclass:not('.datesection')").prepend('<div class="requiredD"><span class="required1 star_req" style="display:; width: 4px;" >*</span></div>');
				}else{
					$j(".matrixContainer"+num+" .tab_head tr[id='"+obj['ROW_ID']+"'] td[id='p3dtd"+i+"']").find(".requiredD").remove();
				}
				$j(".matrixContainer"+num+" .tab_head tr[id='"+obj['ROW_ID']+"'] .allRadioInput").each(function(){
					$j(this).attr('name','3d_'+num+'_radio_'+obj['ROW_ID']+'_'+i+'');
				    $j(this).attr('checked',false);
			    });
			}
			}
			if($j(".matrixContainer"+num+" .tab_head tr[id='"+obj['ROW_ID']+"']").attr('class') == 'even'){
				if(rindex%2 == 0){
			$j(".matrixContainer"+num+" .tab_head tr[id='"+rowtoappend+"']").attr('class', 'odd');}}
			
			if($j(".matrixContainer"+num+" .tab_head tr[id='"+obj['ROW_ID']+"']").attr('class') == 'even'){
				if(rindex%2 != 0){
				$j(".matrixContainer"+num+" .tab_head tr[id='"+obj['ROW_ID']+"']").attr('class', 'odd');}}
		}
		if(obj['ROW_NAME'] != ''){
		$j('.matrixContainer'+num+' .tab_head').show();}
		/* end */
	}else{
		$j("#matrix_"+num+"_grid .table-bordered").find('tr:eq('+rindex+') td:eq(0)').empty();
		$j(".matrixContainer"+num+" .tab_head ").find('tr[id="'+rindex+'"] td:eq(0) div').empty();
	}	
	//SQM-965
	if($j("#helptexttitle_"+num).val()!=''){
		$j('.helptdcls'+num).css('display','');
		var helptextareatext = $j("#helptextarea"+num+rindex).val();
			$j("#helptext_"+num+rindex).html(helptextareatext);
			$j("#helptext_"+num+rindex).show();
	}
}

function columnsOnChange(num,attr,cindex){
	//closetextall(1,num);
	var colObjs=[];
	var html = "";
    var obj = {
        "COL_ID" : cindex,
        "COL_NAME" : attr.value
    }   
	
    if(attr.value.trim() != ""){
		// add object
	    colObjs.push(obj);
		
		if($j("#matrix_"+num+"_grid .table-bordered").find('tr:eq(0) td:eq('+cindex+')').length){
			// update existing columns value in the table
			$j("#matrix_"+num+"_grid .table-bordered").find('tr:eq(0) td:eq('+cindex+')').html(obj['COL_NAME']);
		}else{
		    // dynamically create columns in the table
		    html = "<td id=" + obj['COL_ID'] +" class='gridColumn' onclick=\"javascript:checkUncheckImageRowColumn("+num+","+obj['COL_ID']+",'column');\"" + ">" + obj['COL_NAME'] + "</td>";
		    //add to the table
	     	//$j(".matrixContainer"+num+" .tab_head ").find('tr:eq(0) td#c1').remove();
		    $j("#matrix_"+num+"_grid .table-bordered tr:eq(0)").append(html);
			count = $j("#matrix_"+num+"_grid .table-bordered").find('tr').length;
			
			for(i = 1; i < count; i++){
				var j = $j("#matrix_"+num+"_grid .table-bordered").find('tr:eq('+i+') td').length;
			    $j("#matrix_"+num+"_grid .table-bordered").find('tr:eq('+i+')').append("<td id="+parseInt(j)+" class='gridtd' onclick=\"javascript:checkUncheckImage("+num+","+i+","+j+");\"><input type='checkbox' name='matrix_"+num+"_required_"+i+"_"+obj['COL_ID']+"' id='matrix_"+num+"_required_"+i+"_"+obj['COL_ID']+"'  value='1' style='display:none;'></td>"); 
			}
		    $j("#matrix_"+num+"_grid .table-bordered").show();
		}	
		
			var count = $j("#matrix_"+num+"_grid .table-bordered").find('tr').length;
			if(count < 2){
				count = 2;
			}
		  
			for(i = 1; i <= count-1; i++){
				var cnum = $j("#matrix_"+num+"_grid .table-bordered").find('tr[id="'+i+'"] td').length;
			    //$j("#matrix_"+num+"_grid .table-bordered").find('tr:eq('+i+')').append("<td id="+parseInt(j)+" class='gridtd' onclick=\"javascript:checkUncheckImage("+num+","+i+","+j+");\"><input type='checkbox' name='matrix_"+num+"_required_"+i+"_"+obj['COL_ID']+"' id='matrix_"+num+"_required_"+i+"_"+obj['COL_ID']+"'  value='1' style='display:none;'></td>"); 
		        var j = cnum - 1;
				
				/*--- SQM-811 by Inderjeet ---*/
				//$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_freeText_'+i+'_'+parseInt(j)+' #freeText_'+i+'_'+parseInt(j)+'_cnt').html(0); 
				/*$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_p3dquancheck').empty().append('<table class="matrixColumnInputTable" align="center" style="min-width:190px;border-spacing:0px;min-height: 100px;"></table>');
				$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_p3dquancheckwith').empty().append('<table class="matrixColumnInputTable" align="center" style="min-width:190px;border-spacing:0px;min-height: 100px;"></table>');
				$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_p3dquanradio_'+i+'_'+parseInt(j)+'').empty().append('<table class="matrixColumnInputTable" align="center" style="min-width:190px;border-spacing:0px;min-height: 100px;"></table>');
				$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_p3dqualcheck').empty().append('<table class="matrixColumnInputTable" align="center" style="min-width:190px;border-spacing:0px;min-height: 100px;"></table>');
				$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_p3dqualcheckwith').empty().append('<table class="matrixColumnInputTable" align="center" style="min-width:190px;border-spacing:0px;min-height: 100px;"></table>');
				$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_p3dqualradio_'+i+'_'+parseInt(j)+'').empty().append('<table class="matrixColumnInputTable" align="center" style="min-width:190px;border-spacing:0px;min-height: 100px;"></table>');
				$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_p3dquancheck').attr('id','matrix_'+num+'_p3dquanchk_'+i+'_'+parseInt(j)+'');
				$j('.matrixContainer'+num+'  .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_p3dquancheckwith').attr('id','matrix_'+num+'_p3dquanchkwith_'+i+'_'+parseInt(j)+'');
				$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_p3dqualcheck').attr('id','matrix_'+num+'_p3dqualchk_'+i+'_'+parseInt(j)+'');
				$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_p3dqualcheckwith').attr('id','matrix_'+num+'_p3dqualchkwith_'+i+'_'+parseInt(j)+'');*/
			    }
				if($j(".matrixContainer"+num+" .tab_head tr:eq(0) td[id='"+cindex+"']").length){
					$j(".matrixContainer"+num+" .tab_head ").find('tr:eq(0) td[id="'+cindex+'"] div').html(obj['COL_NAME']);
					}else{
					$j(".matrixContainer"+num+" .tab_head tr:eq(0)").append('<td id="'+ obj['COL_ID'] +'"><div class="matrixColumnLabel questiontext" style="min-width:240px;padding-right:40px;">'+ obj['COL_NAME'] +'</div></td>');
					
					for(i = 1; i <= count-1; i++){
						var cnum = $j("#matrix_"+num+"_grid .table-bordered").find('tr[id="0"] td').length;
						//$j("#matrix_"+num+"_grid .table-bordered").find('tr:eq('+i+')').append("<td id="+parseInt(j)+" class='gridtd' onclick=\"javascript:checkUncheckImage("+num+","+i+","+j+");\"><input type='checkbox' name='matrix_"+num+"_required_"+i+"_"+obj['COL_ID']+"' id='matrix_"+num+"_required_"+i+"_"+obj['COL_ID']+"'  value='1' style='display:none;'></td>"); 
						var j = cnum - 1;

				if(j>1){
					
				var prev = $j(".matrixContainer1 .tab_head tr[id='1'] td[id='p3dtd1']").children().clone();
				//console.log(prev);
				
				$j(".matrixContainer"+num+" .tab_head ").find('tr[id='+i+']').append("<td id='p3dtd"+parseInt(j)+"' style='min-width:240px;padding-right:40px;'></td>");
				$j(".matrixContainer"+num+" .tab_head tr[id="+i+"] td[id='p3dtd"+parseInt(j)+"']").html(prev);
				$j(".matrixContainer"+num+" .tab_head tr[id="+i+"] td[id='p3dtd"+parseInt(j)+"'] .datesection div").hide();
				$j(".matrixContainer"+num+" .tab_head tr").each(function(){
				if($j(this).find("div#removerow"+num).length){
					$j(this).find("div#removerow"+num).remove();
					$j(this).append('<div style="text-align: right; cursor: pointer;display: table-cell;vertical-align:bottom;margin-right: 5px;margin-bottom:5px;padding-right: 10px;padding-bottom: 10px;" id="removerow'+num+'"><a onclick = "javascript:removerow('+num+','+i+')" >remove</a></div>');
				}
			    });
				//console.log($j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_1_p3dquandropdown_1_1 select').length);
				changefieldnames(num,i,parseInt(j),'');
				if($j("#matrix_"+num+"_grid .table-bordered tr[id='"+i+"'] td[id='"+parseInt(j)+"']").find("img").length){
					$j(".matrixContainer"+num+" .tab_head tr[id='"+i+"'] td[id='p3dtd"+parseInt(j)+"']").find(".requiredD").remove();
					$j(".matrixContainer"+num+" .tab_head tr[id='"+i+"'] td[id='p3dtd"+parseInt(j)+"']").find(".pclass:not('.datesection')").prepend('<div class="requiredD"><span class="required1 star_req" style="display:; width: 4px;" >*</span></div>');
				}else{
					$j(".matrixContainer"+num+" .tab_head tr[id='"+i+"'] td[id='p3dtd"+parseInt(j)+"']").find(".requiredD").remove();
				}
				//console.log($j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_p3dquandropdown_'+i+'_'+parseInt(j)+' select').length);
				$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_freeText_'+i+'_'+parseInt(j)+' #matrix_'+num+'_freeText_'+i+'_'+parseInt(j)+'_cnt').html(0);  
				$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] .pclass').hide();
				$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_p3dquanchk_'+i+'_'+parseInt(j)+' table').empty();
				$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_p3dquanchkwith_'+i+'_'+parseInt(j)+' table').empty();
				$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_p3dquanradio_'+i+'_'+parseInt(j)+' table').empty();
				$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_p3dqualchk_'+i+'_'+parseInt(j)+' table').empty();
				$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_p3dqualchkwith_'+i+'_'+parseInt(j)+' table').empty();
				$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_p3dqualradio_'+i+'_'+parseInt(j)+' table').empty();
				$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_p3dqualdropdown_'+i+'_'+parseInt(j)+' #matrix_'+num+'_p3dnonnumdd_'+i+'_'+parseInt(j)+' option:not(:first)').remove();
				$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_p3dquandropdown_'+i+'_'+parseInt(j)+' #matrix_'+num+'_p3dnumdd_'+i+'_'+parseInt(j)+' option:not(:first)').remove();
			    if($j('#matrix_'+num+'_chkSpecialTimeSeries_'+parseInt(j)+'_name').is(':checked')){
					$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] #matrix_'+num+'_timeQuns_'+i+'_'+parseInt(j)+' select').find('[value="0"]').attr("selected","selected");
				 }else{
					 $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] #matrix_'+num+'_timeQuns_'+i+'_'+parseInt(j)+' select').find('[value="Select"]').attr("selected","selected");
				 }	
		    	}
			}
		}
		if(obj['COL_NAME'] != '' && cindex == 1){
			$j('.matrixContainer'+num+' .tab_head').show();}
		
		 /* end */	
			
	}else{
		$j("#matrix_"+num+"_grid .table-bordered").find('tr:eq(0) td:eq('+cindex+')').empty();
		$j(".matrixContainer"+num+" .tab_head ").find('tr:eq(0) td[id="'+cindex+'"] div').empty();
	}	
}

function checkUncheckImage(num,trid,tdid){
	var img = $j("#matrix_"+num+"_grid .table-bordered").find("tr#"+trid+" td#"+tdid+" img").length;
	if (img != 0){
	//if ($j("#matrix_"+num+"_grid .table-bordered").find("tr#"+trid+" td#"+tdid+" input[type='checkbox']").is(':checked')){
		$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+trid+" td#"+tdid+" img").remove();
		$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+trid+" td#"+tdid+" input[type='checkbox']").prop("checked",false);
		$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+trid+" td#"+tdid+" input[type='checkbox']").attr("value",0);
		if($j('.addrowmatrix'+num).is(':checked')){
			var count = $j("#matrix_"+num+"_grid .table-bordered").find('tr:not(":first")').length;	
			var def = parseInt($j('input[name=DefaultNumber'+num+']').val());
			if(count <= def){
				var rcount = def;
			}else{
				var rcount = count;
			}

			for(let r=1;r<=rcount;r++){
				$j('.matrixContainer'+num+' .tab_head tr[id="'+r+'"] td[id="p3dtd'+tdid+'"] .requiredD').remove();
			}
		}else{
		$j('.matrixContainer'+num+' .tab_head tr[id="'+trid+'"] td[id="p3dtd'+tdid+'"] .requiredD').remove();
		}
	}else{
		$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+trid+" td#"+tdid+"").append(chkImage);
		$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+trid+" td#"+tdid+" input[type='checkbox']").prop("checked",true);
		$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+trid+" td#"+tdid+" input[type='checkbox']").attr("value",1);
		if($j('.addrowmatrix'+num).is(':checked')){
			var count = $j("#matrix_"+num+"_grid .table-bordered").find('tr:not(":first")').length;
			var def = parseInt($j('input[name=DefaultNumber'+num+']').val());
			if(count <= def){
				var rcount = def;
			}else{
				var rcount = count;
			}	
			for(let r=1;r<=rcount;r++){
				$j('.matrixContainer'+num+' .tab_head tr[id="'+r+'"] td[id="p3dtd'+tdid+'"] .pclass:not(".datesection")').prepend('<div class="requiredD"><span class="required1 star_req" style="display:; width: 4px;" >*</span></div>');
			}
		}else{
            $j('.matrixContainer'+num+' .tab_head tr[id="'+trid+'"] td[id="p3dtd'+tdid+'"] .pclass:not(".datesection")').prepend('<div class="requiredD"><span class="required1 star_req" style="display:; width: 4px;" >*</span></div>');/*--- SQM-811 by Inderjeet ---*/
		}
	}
	
	var len = $j("#matrix_"+num+"_grid .table-bordered").find("tr:not(:first-child) td:not(:first-child)").length;
	var imgLen = $j("#matrix_"+num+"_grid .table-bordered").find("tr:not(:first-child) td:not(:first-child) img").length;
	if (imgLen < len){
		$j("#matrix_"+num+"_grid .required").show();
		$j("#matrix_"+num+"_grid .optional").hide();
	}else{
		$j("#matrix_"+num+"_grid .optional").show();
		$j("#matrix_"+num+"_grid .required").hide();
	}
}

function checkUncheckImageRowColumn(num,id,type){
	if(type=='row'){
		var tdLen = $j("#matrix_"+num+"_grid .table-bordered").find("tr#"+id+" td:not(:first-child)").length;
		var tdImgLen = $j("#matrix_"+num+"_grid .table-bordered").find("tr#"+id+" td img").length;
		
		if (tdImgLen < tdLen){
			$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+id+" td img").remove();	
			$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+id+" td:not(:first-child)").append(chkImage);
			
			$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+id+" td:not(:first-child) input[type='checkbox']").prop("checked",true);
			$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+id+" td:not(:first-child) input[type='checkbox']").prop("value",1);
			/*--- SQM-811 by Inderjeet ---*/
			$j('.matrixContainer'+num+' .tab_head tr#0 td').each(function(i){
				$j('.matrixContainer'+num+' .tab_head').find("tr#"+id+":not(:first-child) td#p3dtd"+i+"").each(function(){
					$j(this).find(".requiredD").remove();	
					$j(this).find(".pclass:not('.datesection')").prepend('<div class="requiredD"><span class="required1 star_req" style="display:; width: 4px;" >*</span></div>');
				});
		    });
			/* end */
		}else{
			$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+id+" td img").remove();
			
			$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+id+" td:not(:first-child) input[type='checkbox']").prop("checked",false);
			$j("#matrix_"+num+"_grid .table-bordered").find("tr#"+id+" td:not(:first-child) input[type='checkbox']").prop("value",0);
			$j('.matrixContainer'+num+' .tab_head tr[id="'+id+'"] .requiredD').remove();/*--- SQM-811 by Inderjeet ---*/
			
		}
	}else{
		var tdLen = $j("#matrix_"+num+"_grid .table-bordered").find("tr:not(:first-child) td#"+id+"").length;
		var tdImgLen = $j("#matrix_"+num+"_grid .table-bordered").find("tr:not(:first-child) td#"+id+" img").length;
	
		if (tdImgLen < tdLen){
			$j("#matrix_"+num+"_grid .table-bordered").find("tr:not(:first-child) td#"+id+"").each(function(){
				$j(this).find("img").remove();	
				$j(this).append(chkImage);
				
				$j(this).find("input[type='checkbox']").prop("checked",true);
				$j(this).find("input[type='checkbox']").prop("value",1);
			});
			/*--- SQM-811 by Inderjeet ---*/
			$j('.matrixContainer'+num+' .tab_head').find("tr:not(:first-child) td#p3dtd"+id+"").each(function(){
				$j(this).find(".requiredD").remove();	
				$j(this).find(".pclass:not('.datesection')").prepend('<div class="requiredD"><span class="required1 star_req" style="display:; width: 4px;" >*</span></div>');
			});
			/* end */
		}else{
			$j("#matrix_"+num+"_grid .table-bordered").find("tr:not(:first-child) td#"+id+"").each(function(){
				$j(this).find("img").remove();
				
				$j(this).find("input[type='checkbox']").prop("checked",false);
				$j(this).find("input[type='checkbox']").prop("value",0);
			});
			/*--- SQM-811 by Inderjeet ---*/
			$j('.matrixContainer'+num+' .tab_head').find("tr:not(:first-child) td#p3dtd"+id+"").each(function(){
				$j(this).find(".requiredD").remove();
			});	
		}
	}
	
	var len = $j("#matrix_"+num+"_grid .table-bordered").find("tr:not(:first-child) td:not(:first-child)").length;
	var imgLen = $j("#matrix_"+num+"_grid .table-bordered").find("tr:not(:first-child) td:not(:first-child) img").length;
	if (imgLen < len){
		$j("#matrix_"+num+"_grid .required").show();
		$j("#matrix_"+num+"_grid .optional").hide();
	}else{
		$j("#matrix_"+num+"_grid .optional").show();
		$j("#matrix_"+num+"_grid .required").hide();
	}	
}

function requiredClick(num){
	$j("#matrix_"+num+"_grid .optional").show();
	$j("#matrix_"+num+"_grid .required").hide();
	
	$j("#matrix_"+num+"_grid .table-bordered tr td").find("img").remove();
	
	$j("#matrix_"+num+"_grid .table-bordered tr td:not(:first-child)").append(chkImage);
	$j("#matrix_"+num+"_grid .table-bordered tr:eq(0) td").find("img").remove();
	
	$j("#matrix_"+num+"_grid .table-bordered tr td:not(:first-child) input[type='checkbox']").prop("checked",true);
	$j("#matrix_"+num+"_grid .table-bordered tr td:not(:first-child) input[type='checkbox']").prop("value",1);
	/*--- SQM-811 by Inderjeet ---*/
	$j('.matrixContainer'+num+' .tab_head tr#0 td').each(function(i){
		$j('.matrixContainer'+num+' .tab_head').find("tr:not(:first-child) td#p3dtd"+i+"").each(function(){
			$j(this).find(".requiredD").remove();	
			$j(this).find(".pclass:not('.datesection')").prepend('<div class="requiredD"><span class="required1 star_req" style="display:; width: 4px;" >*</span></div>');
		});
	});
	$j('.matrixContainer'+num+' .tab_head tr:eq(0) td').find(".requiredD").remove();
}
	
function optionalClick(num){
	$j("#matrix_"+num+"_grid .required").show();
	$j("#matrix_"+num+"_grid .optional").hide();
	$j("#matrix_"+num+"_grid .table-bordered tr td").find("img").remove();
	
	$j("#matrix_"+num+"_grid .table-bordered tr td input[type='checkbox']").prop("checked",false);
	$j("#matrix_"+num+"_grid .table-bordered tr td input[type='checkbox']").prop("value",0);
	$j('.matrixContainer'+num+' .tab_head tr td').find(".requiredD").remove();/*--- SQM-811 by Inderjeet ---*/
}

function stringifyNumber(n){
	var special = ['Zeroth', 'First', 'Second', 'Third', 'Fourth', 'Fifth', 'Sixth', 'Seventh', 'Eighth', 'Ninth', 'Tenth', 'Eleventh', 'Twelvth', 'Thirteenth', 'Fourteenth', 'Fifteenth', 'Sixteenth', 'Seventeenth', 'Eighteenth', 'Nineteenth'];
	var deca = ['Twent', 'Thirt', 'Fourt', 'Fift', 'Sixt', 'Sevent', 'Eight', 'Ninet'];
	var big = ['','Hundred','Two Hundred','Three Hundred','Four Hundred','Five Hundred','Six Hundred','Seven Hundred','Eight Hundred','Nine Hundred'];
	if(n<100)
    {
    	if (n < 20) return special[n];
		if (n%10 === 0) return deca[Math.floor(n/10)-2] + 'ieth';
		return deca[Math.floor(n/10)-2] + 'y ' + special[n%10];
    }
	else{
		var str= big[Math.floor(n/100)];
		n=n%100;
        if ( n > 0)			
            return str+=' '+stringifyNumber(n);
        else
        	return str+ 'ieth';
		
	}
	//if (n < 20) return special[n];
	//if (n%10 === 0) return deca[Math.floor(n/10)-2] + 'ieth';
	//return deca[Math.floor(n/10)-2] + 'y ' + special[n%10];
}

function matrixValidation(num, stepCounter){
	var row_count = document.getElementById("matrix_"+num+"_row_count").value;
	var stepText = "["+document.getElementById("jSubNumbering_"+num).innerText +"]";
	
	for (i = 1; i <= row_count; i++) {
		var rowChoiceText = $j("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+i+"_name']").val();
		if($j(".addrowmatrix"+num).is(':checked')){
			var rowChoiceText = $j("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_1_name']").val();
		}
		var rowChoiceTextnospace = rowChoiceText;
		
		var namepattern= /^[a-z\d()\-\:_,.&\#%\\@\*!\$\+={}\[\]\|\/\?\s]+$/i; 
		if($j(".addrowmatrix"+num).is(':checked')){
		if (!rowChoiceTextnospace.match(namepattern)) {
			alert(stepText+": Please remove the following characters from the question’s Row Names:  ~ ` ^ ; < > ' ''");
			$j("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+i+"_name']").focus();
			return false;
		}
     	}
		
		if (rowChoiceTextnospace == "") {
			alert(stepText+": Please enter a name for the blank row.");
			$j("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+i+"_name']").focus();
			return false;
		}
	}		
	
	var column_count = document.getElementById("matrix_"+num+"_column_count").value;
	
	for (j = 1; j <= column_count; j++){
		
		var columnChoiceText = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" .columnsLabelList input[name='matrix_"+num+"_column_"+j+"_name']").val();
		var columnChoiceTextnospace = columnChoiceText;
		var columnQuestionTypeChoice = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" .columnsLabelList select[name='matrix_"+num+"_questionType_"+j+"_name']").val();
		
		var namepattern= /^[a-z\d()\-'\":_,.&\#%\\@\*!\$\+={}\[\]\|\/\?\s]+$/i; 
		
		if(columnChoiceTextnospace == "") {
			alert(stepText+": Please enter a name for the blank column.");
			$j(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+j+"_name']").focus();
			return false;
		} else if(columnChoiceTextnospace.length > 250) {
			alert(stepText+": Please enter a column name less than or equal to 250 characters.");
			$j(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+j+"_name']").focus();
			return false;
		} else if (!columnChoiceTextnospace.match(namepattern)) {
			//alert('Invalid option value. Please enter alphanumeric characters, spaces, (, ), :, -, _, &, #, %, @, !, $, +, =, {, }, [, ], |, /, ?, <, >, *, or periods.');
			alert(stepText+": The following characters can not be included in column names.  Please remove them. ~ ` ^ ; < >");
			$j(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+j+"_name']").focus();
			return false;
		}
		/*
		if (columnChoiceTextnospace == ""){
			alert("[Step "+stepCounter+"]: Please enter a name for the blank column.");
			$j(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+j+"_name']").focus();
			return false;
		}
		*/
		if (columnQuestionTypeChoice == ""){
			alert(stepText+": Please select a Question Type for the columns you already created.");
			$j(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList select[name='matrix_"+num+"_questionType_"+j+"_name']").focus();
			return false;
		}
		
		validationstatus = matrixColumnValidation(num,columnQuestionTypeChoice,j,stepCounter,1);
		if(validationstatus == false){
			return false;
		}
	}
	return true;
}

function matrixColumnValidation(num,columnQuestionTypeChoice,j,stepCounter,isSubmit){
	var vm= '';
	 var stepText = "["+document.getElementById("jSubNumbering_"+num).innerText +"]";
	 if(columnQuestionTypeChoice == "Date Field"){
		var TypeVal = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #datefield_"+j+" .multisection input[type='radio']").attr('chcked');
		var seTypeVal = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #datefield_"+j+" .multisection input[type='radio']:eq(1)").attr('chcked');
		var sTypeVal = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #datefield_"+j+" .multisection input[type='radio']:eq(2)").attr('chcked');
		var qnTypeVal = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #datefield_"+j+" input[type='radio']").attr('chcked');
		var rTypeVal = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #datefield_"+j+" input[type='radio']:eq(5)").attr('chcked');
		var startTypeVal = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #datefield_"+j+" input.hidden").val();
		var endTypeVal = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #datefield_"+j+" input.hidden:eq(3)").val();
		if(TypeVal == "checked" || seTypeVal == "checked" || sTypeVal == "checked" || rTypeVal == "checked"){
			qnTypeVal = "checked";
		}
		if(qnTypeVal != "checked"){
			valdiationMsg("[Step "+stepCounter+"]: The column you just created does not selected date type assigned to it. Please select a date type.",
							$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" .datetype"));
			return false;
		}
		if(seTypeVal == "checked"){
		if(startTypeVal == ''){
			valdiationMsg("[Step "+stepCounter+"]: The column you just created does not selected start date assigned to it. Please select a start date.",
							$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #datefield_"+j+" input.hidden"));
			return false;
		}
		if(endTypeVal == ''){
			valdiationMsg("[Step "+stepCounter+"]: The column you just created does not selected end date assigned to it. Please select a end date.",
							$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #datefield_"+j+" input.hidden:eq(3)"));
			return false;
		}}
	}
	 if(columnQuestionTypeChoice == "Free Text Response"){
		var qnTypeVal = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #freeText_"+j+" input:eq(0)").val();
		if(qnTypeVal == ""){
			valdiationMsg(stepText+": The column you just created does not yet have a character limit assigned to it. Please add a character limit.",
							$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #freeText_"+j+" input:eq(0)"));
			return false;
		}else if(qnTypeVal == 0){
			valdiationMsg(stepText+":  Please add a character limit greater than zero",
							$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #freeText_"+j+" input:eq(0)"));
			return false;
		}
		else{
			validateNumeric = checkNumeric(num,$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #freeText_"+j+" input:eq(0)"),'free',stepCounter);
			if(validateNumeric == false){
		 		return false;
		 	}
		}
	}
	if(columnQuestionTypeChoice == "Quantitative Checkbox without Other Option"){
		var qnTypeValFrom = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkbox_"+j+" input:eq(0)").val(); 
		var qnTypeValTo = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkbox_"+j+" input:eq(1)").val();
		if(qnTypeValFrom == "" || qnTypeValTo == ""){
			if(qnTypeValFrom == ""){
				if(isSubmit == 0){
					vm = 'Before creating a new column, please enter answer choices for the column you just created.';
				}else{
					vm = 'Please enter answer choices for the column you just created.';
				}
				valdiationMsg(stepText+": "+vm,
								$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkbox_"+j+" input:eq(0)"));
				return false;
			}
			else{
				if(isSubmit == 0){
					vm = 'Before creating a new column, please enter answer choices for the column you just created.';
				}else{
					vm = 'Please enter answer choices for the column you just created.';
				}
				valdiationMsg(stepText+": "+vm,
								$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkbox_"+j+" input:eq(1)"));
				return false;
			}
		}else if(qnTypeValFrom != "" && qnTypeValTo != ""){
			validateNumericFrom = checkNumeric(num,$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkbox_"+j+" input:eq(0)"),'from',stepCounter);
			if(validateNumericFrom == true){
				validateNumericTo = checkNumeric(num,$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkbox_"+j+" input:eq(1)"),'to',stepCounter);
				if(validateNumericTo == true){
			 		var validationstatus = comparefromto($j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkbox_"+j+" input:eq(0)"), $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkbox_"+j+" input:eq(1)"));
				 	if(validationstatus == false){
				 		return false;
				 	}
				}
				else{
					return false;
				}	
			}
			else{
				return false;
			}	
		}
	}
	if(columnQuestionTypeChoice == "Quantitative Checkbox with Other Option"){
		var qnTypeValFrom = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkboxWithOther_"+j+" input:eq(0)").val(); 
		var qnTypeValTo = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkboxWithOther_"+j+" input:eq(1)").val();
		if(qnTypeValFrom == "" || qnTypeValTo == ""){
			if(qnTypeValFrom == ""){
				if(isSubmit == 0){
					vm = 'Before creating a new column, please enter answer choices for the column you just created.';
				}else{
					vm = 'Please enter answer choices for the column you just created.';
				}
				valdiationMsg(stepText+": "+vm,
								$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkboxWithOther_"+j+" input:eq(0)"));
				return false;
			}
			else{
				if(isSubmit == 0){
					vm = 'Before creating a new column, please enter answer choices for the column you just created.';
				}else{
					vm = 'Please enter answer choices for the column you just created.';
				}
				valdiationMsg(stepText+": "+vm,
								$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkboxWithOther_"+j+" input:eq(1)"));
				return false;
			}
		}else if(qnTypeValFrom != "" && qnTypeValTo != ""){
			validateNumericFrom = checkNumeric(num,$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkboxWithOther_"+j+" input:eq(0)"),'from',stepCounter);
			if(validateNumericFrom == true){
				validateNumericTo = checkNumeric(num,$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkboxWithOther_"+j+" input:eq(1)"),'to',stepCounter);
				if(validateNumericTo == true){
			 		var validationstatus = comparefromto($j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkboxWithOther_"+j+" input:eq(0)"), $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkboxWithOther_"+j+" input:eq(1)"));
				 	if(validationstatus == false){
				 		return false;
				 	}
				}
				else{
					return false;
				}	
			}
			else{
				return false;
			}	
		}
	}
	if(columnQuestionTypeChoice == "Quantitative Drop-Down"){
		var qnTypeValFrom = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanDropDown_"+j+" input:eq(0)").val(); 
		var qnTypeValTo = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanDropDown_"+j+" input:eq(1)").val();
		if(qnTypeValFrom == "" || qnTypeValTo == ""){
			if(qnTypeValFrom == ""){
				if(isSubmit == 0){
					vm = 'Before creating a new column, please enter answer choices for the column you just created.';
				}else{
					vm = 'Please enter answer choices for the column you just created.';
				}
				valdiationMsg(stepText+": "+vm,
								$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanDropDown_"+j+" input:eq(0)"));
				return false;
			}
			else{
				if(isSubmit == 0){
					vm = 'Before creating a new column, please enter answer choices for the column you just created.';
				}else{
					vm = 'Please enter answer choices for the column you just created.';
				}
				valdiationMsg(stepText+": "+vm,
								$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanDropDown_"+j+" input:eq(1)"));
				return false;
			}
		}else if(qnTypeValFrom != "" && qnTypeValTo != ""){
			validateNumericFrom = checkNumeric(num,$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanDropDown_"+j+" input:eq(0)"),'from',stepCounter);
			if(validateNumericFrom == true){
				validateNumericTo = checkNumeric(num,$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanDropDown_"+j+" input:eq(1)"),'to',stepCounter);
				if(validateNumericTo == true){
			 		var validationstatus = comparefromto($j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanDropDown_"+j+" input:eq(0)"), $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanDropDown_"+j+" input:eq(1)"));
				 	if(validationstatus == false){
				 		return false;
				 	}
				}
				else{
					return false;
				}	
			}
			else{
				return false;
			}	
		}
	}
	if(columnQuestionTypeChoice == "Quantitative Radio"){
		var qnTypeValFrom = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanRadio_"+j+" input:eq(0)").val(); 
		var qnTypeValTo = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanRadio_"+j+" input:eq(1)").val();
		if(qnTypeValFrom == "" || qnTypeValTo == ""){
			if(qnTypeValFrom == ""){
				if(isSubmit == 0){
					vm = 'Before creating a new column, please enter answer choices for the column you just created.';
				}else{
					vm = 'Please enter answer choices for the column you just created.';
				}
				valdiationMsg(stepText+": "+vm,
								$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanRadio_"+j+" input:eq(0)"));
				return false;
			}
			else{
				if(isSubmit == 0){
					vm = 'Before creating a new column, please enter answer choices for the column you just created.';
				}else{
					vm = 'Please enter answer choices for the column you just created.';
				}
				valdiationMsg(stepText+": "+vm,
								$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanRadio_"+j+" input:eq(1)"));
				return false;
			}
		}else if(qnTypeValFrom != "" && qnTypeValTo != ""){
			validateNumericFrom = checkNumeric(num,$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanRadio_"+j+" input:eq(0)"),'from',stepCounter);
			if(validateNumericFrom == true){
				validateNumericTo = checkNumeric(num,$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanRadio_"+j+" input:eq(1)"),'to',stepCounter);
				if(validateNumericTo == true){
			 		var validationstatus = comparefromto($j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanRadio_"+j+" input:eq(0)"), $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanRadio_"+j+" input:eq(1)"));
				 	if(validationstatus == false){
				 		return false;
				 	}
				}
				else{
					return false;
				}	
			}
			else{
				return false;
			}	
		}
	}	
	if(columnQuestionTypeChoice == "Qualitative Checkbox without Other Option"){
		var qnTypeVal = $j('#validValues_'+num+'_qualCheck_'+j+' option').length; 
		if(qnTypeVal == 0){
			if(isSubmit == 0){
				vm = 'Before creating a new column, please enter answer choices for the column you just created.';
			}else{
				vm = 'Please enter answer choices for the column you just created.';
			}
			valdiationMsg(stepText+": "+vm,
							$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #qualChkbox_"+j+" .qualitativeValueSelectAddUpdate textarea"));
			return false;
		}
	}if(columnQuestionTypeChoice == "Qualitative Checkbox with Other Option"){
		var qnTypeVal = $j('#validValues_'+num+'_qualCheckWithOther_'+j+' option').length; 
		if(qnTypeVal == 0){
			if(isSubmit == 0){
				vm = 'Before creating a new column, please enter answer choices for the column you just created.';
			}else{
				vm = 'Please enter answer choices for the column you just created.';
			}
			valdiationMsg(stepText+": "+vm,
							$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #qualChkboxWithOther_"+j+" .qualitativeValueSelectAddUpdate textarea"));
			return false;
		}
	}if(columnQuestionTypeChoice == "Qualitative Drop-Down"){
		var qnTypeVal = $j('#validValues_'+num+'_qualDropDown_'+j+' option').length; 
		if(qnTypeVal == 0){
			if(isSubmit == 0){
				vm = 'Before creating a new column, please enter answer choices for the column you just created.';
			}else{
				vm = 'Please enter answer choices for the column you just created.';
			}
			valdiationMsg(stepText+": "+vm,
							$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #qualDropDown_"+j+" .qualitativeValueSelectAddUpdate textarea"));
			return false;
		}
	}if(columnQuestionTypeChoice == "Qualitative Radio"){
		var qnTypeVal = $j('#validValues_'+num+'_qualRadio_'+j+' option').length; 
		if(qnTypeVal == 0){
			if(isSubmit == 0){
				vm = 'Before creating a new column, please enter answer choices for the column you just created.';
			}else{
				vm = 'Please enter answer choices for the column you just created.';
			}
			valdiationMsg(stepText+": "+vm,
							$j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #qualRadio_"+j+" .qualitativeValueSelectAddUpdate textarea"));
			return false;
		}
	}
	return true;
}

//setting validation message for 3D Matrix Question type
function valdiationMsg(msg,container){
	alert(msg);
	container.focus();
}

//checking whether the to field and the from field of 3D Matrix Question type difference is 10001
function comparefromto(fromContainer, toContainer){
 	var fromnum = $j(fromContainer).val();
    var tonum = $j(toContainer).val();
	var fromtodifference = Number(tonum) - Number(fromnum);
    
    if(Number(fromnum) < Number(tonum)){
		if(fromtodifference < 10001){
	    	return true;
    	}
    	else{
    		alert("[Step 1]: Please enter the range of less than 10001 in the number series answer choices field.");
    		fromContainer.focus();
    		return false;
    	}
    }
    else{
        alert("[Step 1]: In the \"Number Series Answer Choices\" area, please enter a number in the \"From\" field that is less than the number in the \"To\" field.");
        fromContainer.val('');
        //toContainer.val('');
        fromContainer.focus();
        return false;
    }
}

//checking whether the to field and the from field is numeric.
function checkNumeric(num,container,field,stepCounter){
	controlnamevalue = container.val();
    var regexp = new RegExp("^[0-9]+$");
	var stepText = "["+document.getElementById("jSubNumbering_"+num).innerText +"]";
    currenttext = (controlnamevalue).replace(" ","");
    if(currenttext != ""){
    	if(controlnamevalue.match(regexp)){
        	return true;
        }
       	else{
			if(field == "from"){
            	alert(stepText+": Please enter a whole, positive integer in the \"From\" field.");
				container.val('');
				container.focus();
				return false;
            }
            if(field == "to"){
            	alert(stepText+": Please enter a whole, positive integer in the \"To\" field.");
				container.val('');
				container.focus();
				return false;
            }
			if(field == "free"){
				
 				alert(stepText+": Please update the character limit of the column you just created so that the limit is represented by a single, whole, positive number.");
				container.val('');
				container.focus();
				return false;
			}
    	}
    }
    /*else{
		if(num == 1){
	        if (field == "from"){
	            alert("[Step "+stepCounter+"]: In the column you just created, please enter your answer choices before creating a new column.");
				container.focus();
				return false;
	         }
	         if (field == "to"){
	            alert("[Step "+stepCounter+"]: In the column you just created, please enter your answer choices before creating a new column.");
				container.focus();
				return false;
	         }
		}	 
	    else{
    		if (field == "from"){
	            alert("[Step "+stepCounter+"]: In the column you just created, please enter your answer choices before creating a new column.");
				container.focus();
				return false;
	         }
	         if (field == "to"){
	            alert("[Step "+stepCounter+"]: In the column you just created, please enter your answer choices before creating a new column.");
				container.focus();
				return false;
	         }
	    }
     //container.focus();
     //return false;
	}*/
}

Array.prototype.max = function() {
  return Math.max.apply(null, this);
};

//View Data for 3DMatrix Question Type
function showResponseMatrix(bShowAnswers,quid,scope,sites,pgmid,dateBegin,dateEnd,notSelectedIds,orderBy,questionType,selectedRowID,selectedColumnID,associationuserlist,completeidlist,qsurveysiteuserid,omitattributelist,includetype_attribute,addedAttributeIDList,type3QuestionsList,chkdItemList){	 	
	globalQuid = quid;
	var prefix = '/index.cfm?event=';
	var questionID = quid;
	beginSurvey = dateBegin;
	endSurvey = dateEnd;
	
	//show loading img
	if(bShowAnswers == 'rowTotal' || bShowAnswers == 'rowTotal_beneficiaryAlias' || bShowAnswers == 'rowTotal_beneficiaryAliasDynamic'){/*SQM-816*/
		nowEl = 'loadingImg_rowTotal_' + quid;	
        jQuery("#"+nowEl).css('visibility', 'visible');       
	}
	else if(bShowAnswers == 'launchDate' || bShowAnswers == 'rowVariables' || bShowAnswers == 'launchDate_beneficiaryAlias'){
		nowEl = 'loadingImg_launchDate_' + quid;	
		document.getElementById(nowEl).style.visibility = "visible";
	}
	else if(bShowAnswers == 'rowTotal_rowBreakout' || bShowAnswers == 'rowTotal_rowBreakoutHide' || bShowAnswers == 'launchDate_rowBreakout' || bShowAnswers == 'launchDate_rowBreakoutHide'){
		nowEl = 'loadingImg_rowBreakout_' + quid;	
		document.getElementById(nowEl).style.visibility = "visible";
	}
	/*else if(bShowAnswers == 'rowVariables' || bShowAnswers == 'launchDate_surveyAliasTotal'){
		nowEl = 'loadingImg_rowVariables_' + quid;	
		document.getElementById(nowEl).style.visibility = "visible";
	}*/
	else if(bShowAnswers == 'rowTotal_col' || bShowAnswers == 'launchDate_col' || bShowAnswers == 'rowTotal_rowBreakout_col' || bShowAnswers == 'rowTotal_rowBreakoutHide_col' || bShowAnswers == 'launchDate_rowBreakout_col' || bShowAnswers == 'launchDate_rowBreakoutHide_col'){
		nowEl = 'loadingImg_col_' + quid;	
		document.getElementById(nowEl).style.visibility = "visible";
	}
	/*SQM-816*/
	else if(bShowAnswers == 'rowTotal_volunteerAlias' || bShowAnswers == 'rowTotal_volunteerAliasDynamic'){
		nowEl = 'loadingImg_rowTotal_' + quid;	
        jQuery("#"+nowEl).css('visibility', 'visible');
	}/*SQM-816*/
	
	if (bShowAnswers != 0 && selectedRowID.trim() == "") { //SURVEXPORT-355
		selectedRowID = document.getElementById("_selectedRowID").value; //if selected data 
	}

	$j('#chkdItemList_'+quid).val(chkdItemList);
	
	var url;
	
	url = "survey.showMatrixQuesAnswers";
	
	url = prefix + url;

	try{
		attributeString = (jQuery('#attributeString' + questionID).length > 0 ) ? jQuery('#attributeString' + questionID).val():'';
		neededAssociationItems = (jQuery('#theListOfAssociationItems' + questionID).length > 0 ) ? jQuery('#theListOfAssociationItems' + questionID).val() : '';
		allassociationitems = (jQuery('#hidden_allassociationitems').length > 0 ) ? jQuery('#hidden_allassociationitems').val():'';
		associationitemidcollectionselected = (jQuery('#hidden_associationitemidcollectionselected').length > 0 ) ? jQuery('#hidden_associationitemidcollectionselected').val():'';
		if(typeof getUrlVars == 'function'){
			parameterVar = getUrlVars(attributeString);
		}else{
			parameterVar = {};
		}
		parameterVar = jQuery.extend({},parameterVar,{
			questionid : questionID, scope : scope, sites : sites, pgmid : pgmid, beginsurvey : beginSurvey, endsurvey : endSurvey, 
			notselectedids : notSelectedIds, orderBy : orderBy, questionType : questionType, viewType : bShowAnswers, selectedRowID: selectedRowID, selectedColumnID: selectedColumnID, 
			associationuserlist : associationuserlist, completeidlist : completeidlist, qsurveysiteuserid : qsurveysiteuserid, 
		    omitattributelist : omitattributelist, includetype_attribute : includetype_attribute, addedAttributeIDList : addedAttributeIDList,
	        type3QuestionsList : type3QuestionsList, chkdItemList : chkdItemList
		});
	}
	catch(err){
		parameterVar = {
			questionid : questionID, scope : scope, sites : sites, pgmid : pgmid, beginsurvey : beginSurvey, endsurvey : endSurvey, 
			notselectedids : notSelectedIds, orderBy : orderBy, questionType : questionType, viewType : bShowAnswers, selectedRowID: selectedRowID, selectedColumnID: selectedColumnID, 
			associationuserlist : associationuserlist, completeidlist : completeidlist, qsurveysiteuserid : qsurveysiteuserid, 
		    omitattributelist : omitattributelist, includetype_attribute : includetype_attribute, addedAttributeIDList : addedAttributeIDList,
	        type3QuestionsList : type3QuestionsList, chkdItemList : chkdItemList
		}
	}
	new Ajax.Request(encodeURI(url), {
		method: 'post',
		parameters: parameterVar,
		onSuccess: function (returnHtml) {
			document.getElementById("txtAnswerBox_"+globalQuid).innerHTML = returnHtml.responseText;
			if($j("input[id='launchDate_beneficiaryAlias-"+quid+"']").is(':checked')){/*SQM-816*/
				$j("div #totals-"+quid).hide();
				$j("div #totals_all-"+quid).hide();
			}
			resizeContainer();
			/*if(bShowAnswers == 'rowTotal' || bShowAnswers == '0' || bShowAnswers == 'launchDate'){
			$j(".main").attr('style','border-radius: 14px; padding-top: 15px;');	
		    }*/
		},
		onFailure: function () {
			alert('Oops...mistake on server');
		}
	});

}

//View Data Dashboard for 3DMatrix Question Type
function showResponse3DMatrixDashboard(bShowAnswers,quid,scope,sites,pgmid,dateBegin,dateEnd,notSelectedIds,orderBy,questionType,associationitemid,selecteduserid,selectedColumnID){
	globalQuid = quid;
	var prefix = '/index.cfm?event=';
	var questionID = quid;
	beginSurvey = dateBegin;
	endSurvey = dateEnd;
	
	if(bShowAnswers){
		if(bShowAnswers == 'volunteerAlias'){
			nowEl = 'loadingImg_' + globalQuid;
			$j('#'+nowEl).show();	
			//document.getElementById(nowEl).style.visibility = "visible";
		}
		else if(bShowAnswers == 'rowVariables'){
			nowEl = 'loadingImg_rowVariables_' + globalQuid;	
			document.getElementById(nowEl).style.visibility = "visible";
		}
		else if(bShowAnswers == 'volunteerAlias_col' || bShowAnswers == 'rowVariables_col'){
			nowEl = 'loadingImg_col_' + globalQuid;	
			document.getElementById(nowEl).style.visibility = "visible";
		}
		
		var url;
		
		url = "survey.viewMatrixAnswersDashboard";
		
		url = prefix + url;
	
		try{
			parameterVar = jQuery.extend({},parameterVar,{
				questionid : questionID, scope : scope, sites : sites, pgmid : pgmid, beginsurvey : beginSurvey, endsurvey : endSurvey, 
				notselectedids : notSelectedIds, orderBy : orderBy, questionType : questionType, associationitemid : associationitemid,  
				selecteduserid: selecteduserid, selectedColumnID: selectedColumnID, viewType : bShowAnswers
			});
		}
		catch(err){
			parameterVar = {
				questionid : questionID, scope : scope, sites : sites, pgmid : pgmid, beginsurvey : beginSurvey, endsurvey : endSurvey, 
				notselectedids : notSelectedIds, orderBy : orderBy, questionType : questionType, associationitemid : associationitemid,  
				selecteduserid: selecteduserid, selectedColumnID: selectedColumnID, viewType : bShowAnswers
			}
		}
		new Ajax.Request(encodeURI(url), {
			method: 'post',
			parameters: parameterVar,
			onSuccess: function (returnHtml) {
				
					$j('#'+nowEl).hide();
				 	$j('#viewdetails_'+globalQuid).text('Hide Results');
				 	
				 	selColumnID = $j('#selectedMatrixColumnId_'+globalQuid).val();
				 	
				 	var on_click = "showResponse3DMatrixDashboard(0,"+quid+",'"+scope+"','"+sites+"','"+pgmid+"','"+dateBegin+"','"+dateEnd+"','"+notSelectedIds+"','"+orderBy+"','"+questionType+"','"+associationitemid+"','"+selecteduserid+"','"+selColumnID+"');";
					$j('#viewdetails_'+globalQuid).attr('onclick', on_click);
					
					$j(".showquestionanswer_row").css('width','597px');
					$j("div.txtAnswerBox").css('width','584px');
				 	
				 	if(returnHtml.length !=0)	
				 		$j("#txtAnswerBox_"+globalQuid).html(returnHtml.responseText);
				 		//$j("#txtAnswerBox_"+globalQuid).innerHTML = returnHtml.responseText;
					else
				 		$j("#txtAnswerBox_"+globalQuid).html('<div style="text-align:center;padding:5px;">No response available for this question</div>');
					 	$j("#txtAnswerBox_"+globalQuid).slideDown('slow');
					 	
					 	resizeContainer();	
		    	}, 
		    // this runs if an error 
			onFailure: function () {
		 		alert('Internal Error');
		 		$j('#'+nowEl).hide();
		 		$j("#txtAnswerBox_"+globalQuid).html('');
			}
		});
	}else{
		$j("#txtAnswerBox_"+globalQuid).slideUp({
			complete:function(){
				$j("#txtAnswerBox_"+globalQuid).html('');
				$j('#viewdetails_'+globalQuid).text('View Results');
				
				selColumnID = $j('#selectedMatrixColumnId_'+globalQuid).val();
				
				var on_click = "showResponse3DMatrixDashboard('default',"+quid+",'"+scope+"','"+sites+"','"+pgmid+"','"+dateBegin+"','"+dateEnd+"','"+notSelectedIds+"','"+orderBy+"','"+questionType+"','"+associationitemid+"','"+selecteduserid+"','"+selColumnID+"');";
				$j('#viewdetails_'+globalQuid).attr('onclick', on_click);
				resizeContainer();	
			}
		});
	}
}

function showResponseMatrix_volunteers(bShowAnswers,quid,scope,sites,pgmid,dateBegin,dateEnd,notSelectedIds,orderBy,questionType,selectedRowID,selectedColumnID,associationuserlist,completeidlist,qsurveysiteuserid,chkdItemList,volunteeruserid){
	globalQuid = quid;
	var prefix = '/index.cfm?event=';
	var questionID = quid;
	beginSurvey = dateBegin;
	endSurvey = dateEnd;
	
	//show loading img
	if(bShowAnswers == 'rowTotal' || bShowAnswers == 'rowTotal_beneficiaryAlias' || bShowAnswers == 'rowTotal_beneficiaryAliasDynamic'){/*SQM-816*/
		nowEl = 'loadingImg_rowTotal_' + quid;	
		document.getElementById(nowEl).style.visibility = "visible";
	}
	else if(bShowAnswers == 'launchDate' || bShowAnswers == 'rowVariables' || bShowAnswers == 'launchDate_beneficiaryAlias'){
		nowEl = 'loadingImg_launchDate_' + quid;	
		document.getElementById(nowEl).style.visibility = "visible";
	}
	else if(bShowAnswers == 'rowTotal_rowBreakout' || bShowAnswers == 'rowTotal_rowBreakoutHide' || bShowAnswers == 'launchDate_rowBreakout' || bShowAnswers == 'launchDate_rowBreakoutHide'){
		nowEl = 'loadingImg_rowBreakout_' + quid;	
		document.getElementById(nowEl).style.visibility = "visible";
	}
	/*else if(bShowAnswers == 'rowVariables' || bShowAnswers == 'launchDate_surveyAliasTotal'){
		nowEl = 'loadingImg_rowVariables_' + quid;	
		document.getElementById(nowEl).style.visibility = "visible";
	}*/
	else if(bShowAnswers == 'rowTotal_col' || bShowAnswers == 'launchDate_col' || bShowAnswers == 'rowTotal_rowBreakout_col' || bShowAnswers == 'rowTotal_rowBreakoutHide_col' || bShowAnswers == 'launchDate_rowBreakout_col' || bShowAnswers == 'launchDate_rowBreakoutHide_col'){
		nowEl = 'loadingImg_col_' + quid;	
		document.getElementById(nowEl).style.visibility = "visible";
	}
	/*SQM-816*/
	else if(bShowAnswers == 'rowTotal_volunteerAlias' || bShowAnswers == 'rowTotal_volunteerAliasDynamic'){/*SQM-816*/
		nowEl = 'loadingImg_rowTotal_' + quid;	
		document.getElementById(nowEl).style.visibility = "visible";
	}
	
	$j('#chkdItemList_'+quid).val(chkdItemList);
	
	var url;
	
	url = "survey.showMatrixQuesAnswers";
	
	url = prefix + url;

	try{
		parameterVar = jQuery.extend({},parameterVar,{
			questionid : questionID, scope : scope, sites : sites, pgmid : pgmid, beginsurvey : beginSurvey, endsurvey : endSurvey, 
			notselectedids : notSelectedIds, orderBy : orderBy, questionType : questionType, viewType : bShowAnswers, selectedRowID: selectedRowID, selectedColumnID: selectedColumnID, 
			associationuserlist : associationuserlist, completeidlist : completeidlist, qsurveysiteuserid : qsurveysiteuserid, chkdItemList:chkdItemList,
			volunteeruserid : volunteeruserid
		});
	}
	catch(err){
		parameterVar = {
			questionid : questionID, scope : scope, sites : sites, pgmid : pgmid, beginsurvey : beginSurvey, endsurvey : endSurvey, 
			notselectedids : notSelectedIds, orderBy : orderBy, questionType : questionType, viewType : bShowAnswers, selectedRowID: selectedRowID, selectedColumnID: selectedColumnID, 
			associationuserlist : associationuserlist, completeidlist : completeidlist, qsurveysiteuserid : qsurveysiteuserid, chkdItemList:chkdItemList,
			volunteeruserid : volunteeruserid
		}
	}
	new Ajax.Request(encodeURI(url), {
		method: 'post',
		parameters: parameterVar,
		onSuccess: function (returnHtml) {
			document.getElementById("txtAnswerBox_"+globalQuid).innerHTML = returnHtml.responseText;
			resizeContainer();
		},
		onFailure: function () {
			alert('Oops...mistake on server');
		}
	});
}

function resizeContainer(){
	var widthArray = [];
	var mainDiv = $j('body').children('.main:first');
	var newMainWidth = '';
	var newSubWidth = '';
	if($j('.qualDataTable:visible').length > 0){
		$j('.qualDataTable:visible').each(function(){
			widthArray.push($j(this).width());
		});
		if(widthArray.max() > 660 ){
			newMainWidth = widthArray.max() + 115;
			newSubWidth = widthArray.max() + 14;
			mainDiv
				.css('width', newMainWidth + 'px')
				.find('.vres').css('width',newSubWidth + 'px')
				.find('table.compile').css('width','100%');
			mainDiv
				.find('.vrestop').css('width',newSubWidth + 'px');
			mainDiv
				.find('.fullpagetop table').css('width','100%');	
			mainDiv
				.find('hr').css('width','95%');
			mainDiv
				.find('.showquestionanswer_row').css('width','99%');
		}else{
			mainDiv
				.removeAttr('style')
				.find('.vres').removeAttr('style');
			mainDiv
				.find('.vrestop').removeAttr('style');
			mainDiv
				.find('.fullpagetop table').removeAttr('style');
			mainDiv
				.find('hr').removeAttr('style');
		}
	}else{
		mainDiv = $j('body').children('.main:first');
		mainDiv
			.removeAttr('style')
			.find('.vres').removeAttr('style');
		mainDiv
			.find('.vrestop').removeAttr('style');
		mainDiv
			.find('.fullpagetop table').removeAttr('style');
		mainDiv
			.find('hr').removeAttr('style');
	}
	$j(".main").attr('style','border-radius: 14px; padding-top: 15px;');	
}
	
$j(".show-details").live('click',function(){
	var attrID = $j(this).attr('id');
	//newID = attrID.split("_");
	
	$j(".qualDataTable tr td.hd_"+attrID+"").show();
	$j(".qualDataTable tr td.sd_"+attrID+"").hide();
	
	resizeContainer();
	
	//$j(".qualDataTable tr td.hd_"+attrID+"").attr("id","column_"+newID[1]);
	//$j(".qualDataTable tr td.sd_"+attrID+"").removeAttr("id");
	
});
	
$j(".hide-details").live('click',function(){
	var attrID = $j(this).attr('id');
	//newID = attrID.split("_");
	
	$j(".qualDataTable tr td.sd_"+attrID+"").show();
	$j(".qualDataTable tr td.hd_"+attrID+"").hide();
	
	resizeContainer();
	
	//$j(".qualDataTable tr td.sd_"+attrID+"").attr("id","column_"+newID[1]);
	//$j(".qualDataTable tr td.hd_"+attrID+"").removeAttr("id");
	
	//var class_exist = "hd_"+attrID;
	//var class_new = "matrixColumn_"+newID[3];
	
	//$j(".qualDataTable tr td.sd_"+attrID).attr("class", ""+class_exist+" "+class_new);
});


function assignMatrixColumnstoHiddenField(passedMatrixColumnsID,qid) {
	if (document.getElementById("selectedMatrixColumnId_"+qid).value == '') { // if there is no elemen selected
		document.getElementById("selectedMatrixColumnId_"+qid).value = passedMatrixColumnsID;
	} else {
		var hiddenvalue = document.getElementById("selectedMatrixColumnId_"+qid).value;
		var hiddenvaluearray = hiddenvalue.split('^^^');
		var elementexists = 0;
		for (var i = 0; i < hiddenvaluearray.length; i++) {
			if (hiddenvaluearray[i] == passedMatrixColumnsID) {
				hiddenvaluearray.splice(hiddenvaluearray.indexOf(hiddenvaluearray[i]), 1);
				elementexists = 1;
			}
		}
		if (elementexists != 1) {
			if (document.getElementById("selectedMatrixColumnId_"+qid).value != '') {
				document.getElementById("selectedMatrixColumnId_"+qid).value = document.getElementById("selectedMatrixColumnId_"+qid).value + "^^^" + passedMatrixColumnsID;
			} else {
				document.getElementById("selectedMatrixColumnId_"+qid).value = passedMatrixColumnsID;
			}
		} else {
			document.getElementById("selectedMatrixColumnId_"+qid).value = '';
			for (var i = 0; i < hiddenvaluearray.length; i++) {
				if (hiddenvaluearray[i] != passedMatrixColumnsID) {
					if (document.getElementById("selectedMatrixColumnId_"+qid).value == '') {
						document.getElementById("selectedMatrixColumnId_"+qid).value = hiddenvaluearray[i];
					} else {
						document.getElementById("selectedMatrixColumnId_"+qid).value = document.getElementById("selectedMatrixColumnId_"+qid).value + "^^^" + hiddenvaluearray[i];
					}
				}
			}
		}
	}
}

function assignMatrixChkBox(chkBoxName,qid) {
	if (document.getElementById("chkdItemList_"+qid).value == '') { // if there is no elemen selected
		document.getElementById("chkdItemList_"+qid).value = chkBoxName;
	} else {
		var hiddenvalue = document.getElementById("chkdItemList_"+qid).value;
		var hiddenvaluearray = hiddenvalue.split('^^^');
		var elementexists = 0;
		for (var i = 0; i < hiddenvaluearray.length; i++) {
			if (hiddenvaluearray[i] == chkBoxName) {
				hiddenvaluearray.splice(hiddenvaluearray.indexOf(hiddenvaluearray[i]), 1);
				elementexists = 1;
			}
		}
		if (elementexists != 1) {
			if (document.getElementById("chkdItemList_"+qid).value != '') {
				document.getElementById("chkdItemList_"+qid).value = document.getElementById("chkdItemList_"+qid).value + "^^^" + chkBoxName;
			} else {
				document.getElementById("chkdItemList_"+qid).value = chkBoxName;
			}
		} else {
			document.getElementById("chkdItemList_"+qid).value = '';
			for (var i = 0; i < hiddenvaluearray.length; i++) {
				if (hiddenvaluearray[i] != chkBoxName) {
					if (document.getElementById("chkdItemList_"+qid).value == '') {
						document.getElementById("chkdItemList_"+qid).value = hiddenvaluearray[i];
					} else {
						document.getElementById("chkdItemList_"+qid).value = document.getElementById("chkdItemList_"+qid).value + "^^^" + hiddenvaluearray[i];
					}
				}
			}
		}
	}
}

function getUrlVars(queryString){
	var vars = {}, hash;
	var hashes = queryString.split('&');
	for(var i = 0; i < hashes.length; i++){
		hash = hashes[i].split('=');
		vars[hash[0]] = hash[1];
	}
	return vars;
}

function checkFreeTextLimit(num,colnumber,previousvalue,newvalue,stepCounter){
	container = $j(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #freeText_"+colnumber+" input:eq(0)");
	validateNumeric = checkNumeric(num,container,'free',stepCounter);
	if(validateNumeric == false){
 		return false;
 	}else{
		if(newvalue >= previousvalue){
			return true;
		}else{
			var stepText = "["+document.getElementById("jSubNumbering_"+num).innerText +"]";
			alert(stepText+": Please enter a value which is greater than existing ["+previousvalue+"] one.");
			container.val("");
			setTimeout(function(){
				container.focus();
				if($j.browser.mozilla){
					window.getSelection().removeAllRanges();
				}
			},1);
			return false;
		}	
	}
}
function validate_empty(num,rownumber,type){
	if(type=='row')
		var	selectiontext = "#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+rownumber+"_name']";
	else if(type=='column')
		var selectiontext = ".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+rownumber+" .columnsLabelList input[name='matrix_"+num+"_column_"+rownumber+"_name']";
	var ChoiceText = $j(selectiontext).val();
	var ChoiceTextnospace = ChoiceText.replace(/ /g, "");
	if(ChoiceTextnospace == ""){
		alert("Please enter a name for the blank "+ type + ".");
		$j(selectiontext).focus();
	}
}
/*--- SQM-811 by Inderjeet ---*/
function p3dfreetextchange(val, cindex){
	var charlimit = parseInt(val.value);
	var arrId = $j(val).attr('name').split('_');
	var num = arrId[1];
	var valid = false;

	var row = $j("#matrix_"+num+"_grid .table-bordered").find('tr').length;
	if(row < 2){
		row = 2;
	}
	if(charlimit > 10000){
		alert("Please enter the range of less than 10001 in the number series answer choices field.");
	}
	else if(isNaN(charlimit)){
		 alert("Please enter a whole, positive integer in the \"Free Text limit\" field.");
		 
	}
	else if(Math.sign(charlimit) == -1){
		 alert("Please enter a whole, positive integer in the \"Free Text limit\" field.");
	}else{
		valid = true;
	}
	if(valid){
	for(r = 1; r < row; r++){
	for (i = 1; i <= cindex; i++) {
		$j('.matrixContainer'+num+' .tab_head #freeText_'+r+'_'+cindex+'_cnt_div').empty();
		$j('.matrixContainer'+num+' .tab_head #freeText_'+r+'_'+cindex+'_cnt_div').append('<span id="matrix_'+num+'_freeText_'+r+'_'+cindex+'_cnt">'+charlimit+'</span> characters remaining');
	    $j('.matrixContainer'+num+' .tab_head #matrix_'+num+'_freeText_'+r+'_'+cindex+'').attr({
		onKeyUp: 'CountLeft(this,'+charlimit+')',
		onKeyDown: 'CountLeft(this,'+charlimit+')',
		value: ''
	});
	$j('.matrixContainer'+num+' .tab_head #matrix_'+num+'_freeText_'+r+'_'+cindex+'_cnt').val(charlimit);
	}}}
	else{
		for(r = 1; r < row; r++){
			for (i = 1; i <= cindex; i++) {
			   $j('.matrixContainer'+num+' .tab_head #matrix_'+num+'_freeText_'+r+'_'+cindex+'').attr({
				   onKeyUp: 'CountLeft(this,"")',
				   onKeyDown: 'CountLeft(this,"")',
				   value: ''
			   });
			   $j('.matrixContainer'+num+' .tab_head #matrix_'+num+'_freeText_'+r+'_'+cindex+'_cnt').html(0);
			}
		   }
	}
}
function onchangefrom(num,Numvalue,str){
    
	var row = $j("#matrix_"+num+"_grid .table-bordered").find('tr').length;
	if($j("#matrix_"+num+"_grid .table-bordered").find('tr').length == 1){
		row = 2;
	}

	if(str.name == 'matrix_'+num+'_quanCheckFrom_'+Numvalue+'_name'){
		var chkstart = parseInt(str.value);
		var chkend = parseInt($j('#matrix_'+num+'_quanCheckTo_'+Numvalue+'_name').val());
		if(numrange_from_validation(chkstart,chkend,str)){	
			for(let i=1;i<row;i++){
			//	console.log(i,Numvalue);
				p3dchkboxppend('matrix_'+num+'_p3dquanchk_'+i+'_'+Numvalue+'',chkstart,chkend);
			}
		}else{
			for(let i=1;i<row;i++){
				$j('#matrix_'+num+'_p3dquanchk_'+i+'_'+Numvalue+' table').empty();
			}
		}
	}
	if(str.name == 'matrix_'+num+'_quanCheckWithOtherFrom_'+Numvalue+'_name'){
		var chkwithstart = parseInt(str.value);
		var chkwithend = parseInt($j('#matrix_'+num+'_quanCheckWithOtherTo_'+Numvalue+'_name').val());
		if(numrange_from_validation(chkwithstart,chkwithend,str)){
			for(let i=1;i<row;i++){
				p3dchkboxppend('matrix_'+num+'_p3dquanchkwith_'+i+'_'+Numvalue+'',chkwithstart,chkwithend);
			}
		}else{
			for(let i=1;i<row;i++){
				$j('#matrix_'+num+'_p3dquanchkwith_'+i+'_'+Numvalue+' table').empty();
			}
		}
	}
	if(str.name == 'matrix_'+num+'_quanDropDownFrom_'+Numvalue+'_name'){
		var dropstart = parseInt(str.value);
		var dropend = parseInt($j('#matrix_'+num+'_quanDropDownTo_'+Numvalue+'_name').val());
		if(numrange_from_validation(dropstart,dropend,str)){
			for(let i=1;i<row;i++){
				$j("#matrix_"+num+"_p3dnumdd_"+i+"_"+Numvalue+" option:not(:first)").remove();
				var count = 0;
		        for (let j = dropstart; j <= dropend;++j){
				if(count > 50){
					$j("#matrix_"+num+"_p3dnumdd_"+i+"_"+Numvalue+" option:not(:first)").remove();
                    $j("#matrix_"+num+"_p3dnumdd_"+i+"_"+Numvalue+"").append('<option>'+dropstart+'</option><option>...</option><option>'+dropend+'</option>');
				}else{
		        $j("#matrix_"+num+"_p3dnumdd_"+i+"_"+Numvalue).append(new Option(j, j));}
			   count++
			}
			  
			}
		}else{
			for(let i=1;i<row;i++){
				$j("#matrix_"+num+"_p3dnumdd_"+i+"_"+Numvalue+" option:not(:first)").remove();
			}
		}
	}
	if(str.name == 'matrix_'+num+'_quanRadioFrom_'+Numvalue+'_name'){
		var radiostart = parseInt(str.value);
		var radioend = parseInt($j('#matrix_'+num+'_quanRadioTo_'+Numvalue+'_name').val());
		if(numrange_from_validation(radiostart,radioend,str)){
			for(let i=1;i<row;i++){
				p3dradioappend('matrix_'+num+'_p3dquanradio_'+i+'_'+Numvalue+'',radiostart,radioend);
			}
		}else{
			for(let i=1;i<row;i++){
				$j('#matrix_'+num+'_p3dquanradio_'+i+'_'+Numvalue+' table').empty();
			}
		}
	}

}
function onchangeto(num,Numvalue,str){
    
	var row = $j("#matrix_"+num+"_grid .table-bordered").find('tr').length;
	if($j("#matrix_"+num+"_grid .table-bordered").find('tr').length == 1){
		row = 2;
	}

		if(str.name == 'matrix_'+num+'_quanCheckTo_'+Numvalue+'_name'){
			 chkstart = parseInt($j('#matrix_'+num+'_quanCheckFrom_'+Numvalue+'_name').val());
			 var chkend = parseInt($j('#matrix_'+num+'_quanCheckTo_'+Numvalue+'_name').val());
			// console.log(chkend);
			if(numrange_to_validation(chkstart,chkend,str)){	
				for(let i=1;i<row;i++){
					p3dchkboxppend('matrix_'+num+'_p3dquanchk_'+i+'_'+Numvalue+'',chkstart,chkend);
				}
			}else{
				for(let i=1;i<row;i++){
					$j('#matrix_'+num+'_p3dquanchk_'+i+'_'+Numvalue+' table').empty();
				}
			}
		}
		if(str.name == 'matrix_'+num+'_quanCheckWithOtherTo_'+Numvalue+'_name'){
			 chkwithstart = parseInt($j('#matrix_'+num+'_quanCheckWithOtherFrom_'+Numvalue+'_name').val());
			 var chkwithend = parseInt($j('#matrix_'+num+'_quanCheckWithOtherTo_'+Numvalue+'_name').val());
			if(numrange_to_validation(chkwithstart,chkwithend,str)){
				for(let i=1;i<row;i++){
					//console.log(i,Numvalue);
					p3dchkboxppend('matrix_'+num+'_p3dquanchkwith_'+i+'_'+Numvalue+'',chkwithstart,chkwithend);
				}
			}else{
				for(let i=1;i<row;i++){
					$j('#matrix_'+num+'_p3dquanchkwith_'+i+'_'+Numvalue+' table').empty();
				}
			}
		}
		if(str.name == 'matrix_'+num+'_quanDropDownTo_'+Numvalue+'_name'){
			  dropstart = parseInt($j('#matrix_'+num+'_quanDropDownFrom_'+Numvalue+'_name').val());
			  var dropend = parseInt($j('#matrix_'+num+'_quanDropDownTo_'+Numvalue+'_name').val());
			if(numrange_to_validation(dropstart,dropend,str)){
				
				for(let i=1;i<row;i++){
					$j("#matrix_"+num+"_p3dnumdd_"+i+"_"+Numvalue+" option:not(:first)").remove();
					var count = 0;
					for (let j = dropstart; j <= dropend;++j){
					 if(count > 50){
						$j("#matrix_"+num+"_p3dnumdd_"+i+"_"+Numvalue+" option:not(:first)").remove();
						$j("#matrix_"+num+"_p3dnumdd_"+i+"_"+Numvalue+"").append('<option>'+dropstart+'</option><option>...</option><option>'+dropend+'</option>');
					 }else{
						$j("#matrix_"+num+"_p3dnumdd_"+i+"_"+Numvalue+"").append(new Option(j, j));}
						count++;
					}
				   
				}
			}else{
				for(let i=1;i<row;i++){
					$j("#matrix_"+num+"_p3dnumdd_"+i+"_"+Numvalue+" option:not(:first)").remove();
				}
			}
		}
		if(str.name == 'matrix_'+num+'_quanRadioTo_'+Numvalue+'_name'){
			 radiostart = parseInt($j('#matrix_'+num+'_quanRadioFrom_'+Numvalue+'_name').val());
			 var radioend = parseInt($j('#matrix_'+num+'_quanRadioTo_'+Numvalue+'_name').val());
			if(numrange_to_validation(radiostart,radioend,str)){
				for(let i=1;i<row;i++){
					p3dradioappend('matrix_'+num+'_p3dquanradio_'+i+'_'+Numvalue+'',radiostart,radioend);
				}
			}else{
				for(let i=1;i<row;i++){
					$j('#matrix_'+num+'_p3dquanradio_'+i+'_'+Numvalue+' table').empty();
				}
			}
		}
	
}
function p3dradioappend(id,start,end){
	var valarr = [];
	var cnt = 0;
	var required = '';
	arrId = id.split('_');
	//console.log(arrId[3]);
	num = arrId[1];
	if($j("#matrix_"+num+"_grid .table-bordered tr[id='"+arrId[3]+"'] td[id='"+arrId[4]+"']").find("img").length){
		required = "yes";
	}
	$j("#"+id+" table").empty();
	if(required == "yes"){
		$j("#"+id+"").prepend('<div class="requiredD"><span class="required1 star_req" style="display:; width: 4px;" >*</span></div>');
	}else{
		$j("#"+id+"").find('.requiredD').remove();
	}
	for (let i = start; i <= end; ++i){
	
	if(cnt < 50){	
	//$j("##"+id+"").append('<div class="pull-left" style="width:100%;"><div class="allCheckBoxLayout allInputLayoutWidthAdjested" style="width:100%"><div style="display: flex;align-items: start;word-break:break-word; paddin: 0 3px 0 4px; align-items: center;" class="textmaxlenght80"><div class="allCheckBoxInput" style="padding: 1px 6px 0px 0px; margin-bottom: 3px;"><input type="radio" value="i"></div><div class="allCheckBoxText" style="padding-left:0px;" >'+ i +'</div></div></div></div>');
	valarr[cnt]	= i;
	}
	cnt++
	}
  var rowlen = Math.round(valarr.length/2);
 
  for(let j = 0; j < rowlen; j++){
	$j("#"+id+" table").append('<tr id="abcd1_'+arrId[3]+'_'+arrId[4]+'_'+j+'" class="matrixColumnInputColor" ><td style="min-width:50%;"><div style="display: flex; "><input name="3d_'+arrId[1]+'_radio_'+arrId[3]+'_'+arrId[4]+'" class="allRadioInput" type="radio" style="vertical-align: top;margin-right: 5px;margin-top: 0px;display: inline-block;margin-bottom: 8px;"><div style="display: inline-block;margin-bottom: 8px;margin-right: 27px;padding-top: 1px;">' +valarr[j]+ '</div></div></td></tr>');
	var next = j+rowlen;
   if(next < valarr.length){
	  $j('#'+id+' #abcd1_'+arrId[3]+'_'+arrId[4]+'_'+j).append("<td style='min-width:50%;'><div style='display: flex; '><input name='3d_"+arrId[1]+"_radio_"+arrId[3]+"_"+arrId[4]+"' type='radio' class='allRadioInput' style='vertical-align: top;margin-right: 5px;margin-top: 0px;display: inline-block;margin-bottom: 8px;'><div style='display: inline-block;margin-bottom: 8px;margin-right: 27px;padding-top: 1px;'>"+valarr[next]+"</div></div></td>");
   }
  }

if(cnt > 50){
$j("#"+id+" table").append('<tr class="matrixMessageColor"><td colspan="4"><p style= "padding:0px 0px 0px 0px; color:green;">*On '+survey_name+' forms, radio button values will be '+start+' through '+end+'.</p></td></tr>');}

}
function p3dchkboxppend(id,start,end){
	var required = '';
	arrId = id.split('_');
	num = arrId[1];
	if($j("#matrix_"+num+"_grid .table-bordered tr[id='"+arrId[3]+"'] td[id='"+arrId[4]+"']").find("img").length){
		required = "yes";
	}
	$j("#"+id+" table").empty();
	if(required == "yes"){
		$j("#"+id+"").prepend('<div class="requiredD"><span class="required1 star_req" style="display:; width: 4px;" >*</span></div>');
	}else{
		$j("#"+id+"").find('.requiredD').remove();
	}
	var valarr = [];
	var cnt = 0;
	
	for (let i = start; i <= end; ++i){
	
	if(cnt < 50){	
	//$j("##"+id+"").append('<div class="pull-left" style="width:100%;"><div class="allCheckBoxLayout allInputLayoutWidthAdjested" style="width:100%"><div style="display: flex;align-items: start;word-break:break-word; paddin: 0 3px 0 4px; align-items: center;" class="textmaxlenght80"><div class="allCheckBoxInput" style="padding: 1px 6px 0px 0px; margin-bottom: 3px;"><input type="radio" value="i"></div><div class="allCheckBoxText" style="padding-left:0px;" >'+ i +'</div></div></div></div>');
	valarr[cnt]	= i;
	}
	cnt++
	}
  var rowlen = Math.round(valarr.length/2);
  
 
  if(id == ''+arrId[0]+'_'+arrId[1]+'_p3dquanchk_'+arrId[3]+'_'+arrId[4]+''){
	
  for(let j = 0; j < rowlen; j++){
	
	$j("#"+id+" table").append('<tr id="abcd_'+arrId[3]+'_'+arrId[4]+'_'+j+'" class="matrixColumnInputColor" ><td style="min-width:50%;"><div style="display: flex; "><input type="checkbox" class="allCheckBoxInput" style="vertical-align: top;margin-right: 5px;margin-top: 0px;display: inline-block;margin-bottom: 8px;"><div style="display: inline-block;margin-bottom: 8px;margin-right: 27px;padding-top: 1px;">' +valarr[j]+ '</div></div></td></tr>');
	var next = j+rowlen;
   if(next < valarr.length){
	  $j('#'+id+' #abcd_'+arrId[3]+'_'+arrId[4]+'_'+j).append("<td style='min-width:50%;'><div style='display: flex; '><input type='checkbox' class='allCheckBoxInput' style='vertical-align: top;margin-right: 5px;margin-top: 0px;display: inline-block;margin-bottom: 8px;'><div style='display: inline-block;margin-bottom: 8px;margin-right: 27px;padding-top: 1px;'>"+valarr[next]+"</div></div></td>");
   }
  }
  if(cnt > 50){
	$j("#"+id+" table").append('<tr class="matrixMessageColor"><td colspan="4"><p style= "padding:0px 0px 0px 0px; color:green;">*On '+survey_name+' forms, checkbox values will be '+start+' through '+end+'.</p></td></tr>');}
  }

if(id == ''+arrId[0]+'_'+arrId[1]+'_p3dquanchkwith_'+arrId[3]+'_'+arrId[4]+''){
	for(let j = 0; j < rowlen; j++){
		$j("#"+id+" table").append('<tr id="abcd_'+arrId[3]+'_'+arrId[4]+'_'+j+'" class="matrixColumnInputColor" ><td style="min-width:50%;"><div style="display: flex; "><input class="allCheckBoxInput" type="checkbox" style="vertical-align: top;margin-right: 5px;margin-top: 0px;display: inline-block;margin-bottom: 8px;"><div style="display: inline-block;margin-bottom: 8px;margin-right: 27px;padding-top: 1px;">' +valarr[j]+ '</div></div></td></tr>');
		var next = j+rowlen;
	   if(next < valarr.length){
		  $j('#'+id+' #abcd_'+arrId[3]+'_'+arrId[4]+'_'+j).append("<td style='min-width:50%;'><div style='display: flex; '><input type='checkbox' class='allCheckBoxInput' style='vertical-align: top;margin-right: 5px;margin-top: 0px;display: inline-block;margin-bottom: 8px;'><div style='display: inline-block;margin-bottom: 8px;margin-right: 27px;padding-top: 1px;'>"+valarr[next]+"</div></div></td>");
	   }
	  }
	
	if(cnt > 50){
		$j("#"+id+" table").append('<tr class="matrixMessageColor"><td colspan="4"><p style= "padding:0px 0px 0px 0px; color:green;">*On '+survey_name+' forms, checkbox values will be '+start+' through '+end+'.</p></td></tr>');}
		$j("#"+id+" table").append('<tr class="matrixColumnInputColor"><td colspan="4"><br/><label class="emphasistext">Other:</label><input type="text" value="" size="20" maxlength="510"><br><br></td></tr>');
	}
	
}
function numrange_from_validation(start,end,str){
	var diff = end - start;
	if(diff > 10000){
		alert("Please enter the range of less than 10001 in the number series answer choices field.");
	}
	else if(Math.sign(start) == -1){
		 alert("Please enter a whole, positive integer in the \"From\" field.");
	}
	else if(isNaN(start)){
		 alert("Please enter a whole, positive integer in the \"From\" field.");
	}
	else if(start > end && end != "") {
		alert("In the \"Number Series Answer Choices\" area, please enter a number in the \"From\" field that is less than the number in the \"To\" field.");
		str.value = "";
		str.focus();
	}
	else if(start == end){
		alert("In the \"Number Series Answer Choices\" area, please enter a number in the \"From\" field that is less than the number in the \"To\" field.");
		str.value = "";
		str.focus();
	}
	else{
		return true;
	}
  }
  
  function numrange_to_validation(start,end,str){
	//console.log(end);
	var diff = end - start;
	if(diff > 10000){
		alert("Please enter the range of less than 10001 in the number series answer choices field.");
	}
	else if(isNaN(end)){
		 alert("Please enter a whole, positive integer in the \"To\" field.");
	}
	else if(Math.sign(end) == -1){
		 alert("Please enter a whole, positive integer in the \"To\" field.");
	}
	else if(start > end){
		alert("In the \"Number Series Answer Choices\" area, please enter a number in the \"From\" field that is less than the number in the \"To\" field.");
		str.value = "";
		str.focus();
	}
	else if(start == end){
		alert("In the \"Number Series Answer Choices\" area, please enter a number in the \"From\" field that is less than the number in the \"To\" field.");
		str.value = "";
		str.focus();
	}
	else {
		return true;
	}
  }
function changefieldnames(num,i,j,type){
r = 1; 
c = 1; 
var qnum = 1;
var req = parseInt($j('input[name=RequiredNumber'+num+']').val());
if(type == 'nextrow'){
	r = i-1;
	c = j;
	qnum = num;
}
if(type == 'prevrow'){
	r = i+1;
	c = j;
	qnum = num;
}
if(type == 'nextcol'){
	r = i;
	c = j-1;
	qnum = num;
}
if(type == 'prevcol'){
	r = i;
	c = j+1;
	qnum = num;
}
if(type == 'addrow'){
	r = 1;
	c = j;
	qnum = num;
}
  //console.log(r,i,j,"dd");
		$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+qnum+'_freeText_'+r+'_'+c+'').attr('id','matrix_'+num+'_freeText_'+i+'_'+parseInt(j)+'');
		$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_freeText_'+i+'_'+parseInt(j)+' #freeText_'+r+'_'+c+'_cnt_div').attr('id','freeText_'+i+'_'+parseInt(j)+'_cnt_div');
		//$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_freeText_'+i+'_'+parseInt(j)+' #freeText_'+r+'_'+c+'_cnt').html(0);
		$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_freeText_'+i+'_'+parseInt(j)+' #matrix_'+qnum+'_freeText_'+r+'_'+c+'_cnt').attr('id','matrix_'+num+'_freeText_'+i+'_'+parseInt(j)+'_cnt');
		$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_freeText_'+i+'_'+parseInt(j)+' #matrix_'+num+'_freeText_'+i+'_'+parseInt(j)+'').attr({
			id: 'matrix_'+num+'_freeText_'+i+'_'+parseInt(j)+'',
			name: 'matrix_'+num+'_freeText_'+i+'_'+parseInt(j)+'',
		}); 

		$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+qnum+'_textBox_'+r+'_'+c+'').attr('id','matrix_'+num+'_textBox_'+i+'_'+parseInt(j)+'')				
			$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_textBox_'+i+'_'+parseInt(j)+' #matrix_'+num+'_textBox_'+i+'_'+parseInt(j)+'').attr({
				name: 'matrix_'+num+'_textBox_'+i+'_'+parseInt(j)+'',
				id: 'matrix_'+num+'_textBox_'+i+'_'+parseInt(j)+'',
			});
			//$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_textBox_'+i+'_'+parseInt(j)+' #textBox_'+r+'_'+c+'_cnt').html(15);
			$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_textBox_'+i+'_'+parseInt(j)+' #matrix_'+qnum+'_textBox_'+r+'_'+c+'_cnt').attr('id','matrix_'+num+'_textBox_'+i+'_'+parseInt(j)+'_cnt');

			
		$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+qnum+'_p3dquanchk_'+r+'_'+c+'').attr('id','matrix_'+num+'_p3dquanchk_'+i+'_'+parseInt(j)+'');
		$j('.matrixContainer'+num+'  .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+qnum+'_p3dquanchkwith_'+r+'_'+c+'').attr('id','matrix_'+num+'_p3dquanchkwith_'+i+'_'+parseInt(j)+'');
		$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_1_p3dquancheck').attr('id','matrix_'+num+'_p3dquancheck');
		$j('.matrixContainer'+num+'  .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_1_p3dquancheckwith').attr('id','matrix_'+num+'_p3dquancheckwith');
		$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+qnum+'_p3dquandropdown_'+r+'_'+c+'').attr('id','matrix_'+num+'_p3dquandropdown_'+i+'_'+parseInt(j)+'');
		$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+qnum+'_p3dquandropdown_'+i+'_'+parseInt(j)+' #matrix_'+num+'_p3dnumdd_'+r+'_'+c+'').attr('id','matrix_'+num+'_p3dnumdd_'+i+'_'+parseInt(j)+'');
		$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+qnum+'_p3dquanradio_'+r+'_'+c+'').attr('id','matrix_'+num+'_p3dquanradio_'+i+'_'+parseInt(j)+'');
		$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+qnum+'_p3dqualchk_'+r+'_'+c+'').attr('id','matrix_'+num+'_p3dqualchk_'+i+'_'+parseInt(j)+'');
		$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+qnum+'_p3dqualchkwith_'+r+'_'+c+'').attr('id','matrix_'+num+'_p3dqualchkwith_'+i+'_'+parseInt(j)+'');
		$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_1_p3dqualcheck').attr('id','matrix_'+num+'_p3dqualcheck');
		$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_1_p3dqualcheckwith').attr('id','matrix_'+num+'_p3dqualcheckwith');
		$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+qnum+'_p3dqualdropdown_'+r+'_'+c+'').attr('id','matrix_'+num+'_p3dqualdropdown_'+i+'_'+parseInt(j)+'');
		$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+qnum+'_p3dqualdropdown_'+i+'_'+parseInt(j)+' #matrix_'+num+'_p3dnonnumdd_'+r+'_'+c+'').attr('id','matrix_'+num+'_p3dnonnumdd_'+i+'_'+parseInt(j)+'');
		$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+qnum+'_p3dqualradio_'+r+'_'+c+'').attr('id','matrix_'+num+'_p3dqualradio_'+i+'_'+parseInt(j)+'');
		$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+qnum+'_timeQuns_'+r+'_'+c+'').attr('id','matrix_'+num+'_timeQuns_'+i+'_'+parseInt(j)+'');
		$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_timeQuns_'+i+'_'+parseInt(j)+' select').attr({
			name: 'timeQns_'+i+'_'+parseInt(j)+'',
			class: 'select-box timeQns_'+num+'_'+parseInt(j)+''
		});
		$j('#matrix_'+num+'_column #columnsAdd_'+parseInt(j)+' #timeQns_'+parseInt(j)+' input').attr({
			name: 'matrix_'+num+'_chkSpecialTimeSeries_'+parseInt(j)+'_name',
			id: 'matrix_'+num+'_chkSpecialTimeSeries_'+parseInt(j)+'_name',
		});
		if($j('#matrix_'+num+'_chkSpecialTimeSeries_'+parseInt(j)+'_name').is(':checked')){
			$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] #matrix_'+num+'_timeQuns_'+i+'_'+parseInt(j)+' select').find('[value="0"]').attr("selected","selected");
		 }else{
			 $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] #matrix_'+num+'_timeQuns_'+i+'_'+parseInt(j)+' select').find('[value="Select"]').attr("selected","selected");
		 }
		 $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+qnum+'_psingledate_'+r+'_'+c+' input').attr({name :'matrix_'+num+'_basicDate_'+i+'_'+parseInt(j)+'',id :'matrix_'+num+'_basicDate_'+i+'_'+parseInt(j)+''});
		 $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+qnum+'_pmultipledate_'+r+'_'+c+' input').attr({name :'matrix_'+num+'_multidate_'+i+'_'+parseInt(j)+'',id :'matrix_'+num+'_multidate_'+i+'_'+parseInt(j)+''});
         $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+qnum+'_pstartenddate_'+r+'_'+c+' input').attr({name :'matrix_'+num+'_sbasicDate_'+i+'_'+parseInt(j)+'',id :'matrix_'+num+'_sbasicDate_'+i+'_'+parseInt(j)+''});
         $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+qnum+'_psurvaydate_'+r+'_'+c+' input').attr({name :'matrix_'+num+'_slaunchdate_'+i+'_'+parseInt(j)+'',id :'matrix_'+num+'_slaunchdate_'+i+'_'+parseInt(j)+''});
		 $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+qnum+'_prangedate_'+r+'_'+c+' input').attr({name :'matrix_'+num+'_rangeDate_'+i+'_'+parseInt(j)+'',id :'matrix_'+num+'_rangeDate_'+i+'_'+parseInt(j)+''});
		 $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+qnum+'_psingledate_'+r+'_'+c+'').attr({id :'matrix_'+num+'_psingledate_'+i+'_'+parseInt(j)+'',class: 'matrixColumnInput mpquestion'+parseInt(j)+' mpquestion_'+parseInt(j)+'_Single pclass'});
		 $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+qnum+'_pmultipledate_'+r+'_'+c+'').attr({id :'matrix_'+num+'_pmultipledate_'+i+'_'+parseInt(j)+'',class: 'matrixColumnInput mpquestion'+parseInt(j)+' mpquestion_'+parseInt(j)+'_Any pclass'});
		 $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+qnum+'_pstartenddate_'+r+'_'+c+'').attr({id :'matrix_'+num+'_pstartenddate_'+i+'_'+parseInt(j)+'',class: 'matrixColumnInput mpquestion'+parseInt(j)+' mpquestion_'+parseInt(j)+'_StartEnd pclass'});
		 $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+qnum+'_psurvaydate_'+r+'_'+c+'').attr({id :'matrix_'+num+'_psurvaydate_'+i+'_'+parseInt(j)+'',class: 'matrixColumnInput mpquestion'+parseInt(j)+' mpquestion_'+parseInt(j)+'_SurveyLaunch pclass'});
		 $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+qnum+'_prangedate_'+r+'_'+c+'').attr({id :'matrix_'+num+'_prangedate_'+i+'_'+parseInt(j)+'',class: 'matrixColumnInput mpquestion'+parseInt(j)+' mpquestion_'+parseInt(j)+'_Range pclass'});
		 //SQM-965
		 $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] #helptext_'+num+''+r).attr('id','helptext_'+num+''+i);
		 if(type == '' || type == 'addrow'){	
			$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_psingledate_'+i+'_'+parseInt(j)+' input').val('');
			$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_pmultipledate_'+i+'_'+parseInt(j)+' input').val('');
			$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_pstartenddate_'+i+'_'+parseInt(j)+' input').val('');
			$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_psurvaydate_'+i+'_'+parseInt(j)+' input').val('');
			$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_prangedate_'+i+'_'+parseInt(j)+' input').val('');
		}
		 copypicker('matrix_'+num+'_basicDate_'+i+'_'+parseInt(j)+'',0);
		 copypicker('matrix_'+num+'_multidate_'+i+'_'+parseInt(j)+'',0);
		 copypicker('matrix_'+num+'_sbasicDate_'+i+'_'+parseInt(j)+'',0);
		 copypicker('matrix_'+num+'_slaunchdate_'+i+'_'+parseInt(j)+'',0);
		 copypicker('matrix_'+num+'_rangeDate_'+i+'_'+parseInt(j)+'',0);
	 if(type == ''){
		$j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_freeText_'+i+'_'+parseInt(j)+' #matrix_'+num+'_freeText_'+i+'_'+parseInt(j)+'').attr({onKeyUp: 'CountLeft(this,"")',onKeyDown: 'CountLeft(this,"")',value: ''});
	    $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_textBox_'+i+'_'+parseInt(j)+' #matrix_'+num+'_textBox_'+i+'_'+parseInt(j)+'').attr({onKeyUp: 'CountLeft(this,15)',onKeyDown: 'CountLeft(this,15)',value: ''});	
	    $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_freeText_'+i+'_'+parseInt(j)+' #matrix_'+num+'_freeText_'+i+'_'+parseInt(j)+'_cnt').html(0);  
	    $j('.matrixContainer'+num+' .tab_head tr[id="'+i+'"] td[id="p3dtd'+parseInt(j)+'"] #matrix_'+num+'_textBox_'+i+'_'+parseInt(j)+' #matrix_'+num+'_textBox_'+i+'_'+parseInt(j)+'_cnt').html(15);
	}		
}
function chngematrixdatefield(n,c){
	$j('#matrix_'+n+'_column #datefield_'+c+' .datetype').each(function(){
          var type = $j(this).val();
 		  var on_click = '';
		  
		  $j(this).removeAttr('onchange');
		 if(type == 'multiple'){
			    on_click = "showdateSection(this,"+n+","+c+",'multiple')"
                $j(this).attr({
				class:'matrix_'+n+'_multi_'+c+' datetype Question_margin',
			    onclick: on_click
			});
		 }else{
			$j(this).attr({
				name: 'matrix_'+n+'_dtquestionType_'+c+'_name',
		    });
            
			if(type == 'DateType_Any' || type == 'DateType_StartEnd' || type == 'DateType_SurveyLaunch'){
				on_click = "showdateSection(this,"+n+","+c+",'multiple')"
				$j(this).attr({
					class:'matrix_'+n+'_mdtquestin_'+c+' datetype Question_margin',
					onclick: on_click
				});
			}else{
				on_click = "showdateSection(this,"+n+","+c+",'')"
				$j(this).attr({
					class:'matrix_'+n+'_nonmulti_'+c+' datetype Question_margin',
					onclick: on_click
				});
				
			}
			if(type == 'DateType_StartEnd'){
				$j(this).addClass('m_'+n+'_se_'+c);
			}
		 }
		 if($j(this).attr('chcked') == 'checked'){
			$j(this).prop("checked",true);
		 }
	});

	$j('#matrix_'+n+'_column #datefield_'+c+' .hidden').each(function(){
		var field = $j(this).attr('name').split("_");
		$j(this).removeAttr('onchange');
		if(field[2].search("Start") != -1){
			if( $j(this).attr('name').search("Hidden") != -1){
				$j(this).attr({
					name : ''+field[0]+'_'+n+'_'+field[2]+'_'+field[3]+'_'+c+'',
					id : ''+field[0]+'_'+n+'_'+field[2]+'_'+field[3]+'_'+c+''
				});
	        }else{
				$j(this).attr({
					name : ''+field[0]+'_'+n+'_'+field[2]+'_'+c+'',
					id : ''+field[0]+'_'+n+'_'+field[2]+'_'+c+'',
					'data-count' : ''+field[0]+'_'+n+'_'+field[2]+'_'+c+''
				});
			}
		}else{
			if($j(this).attr('name').search("Hidden") != -1){
				$j(this).attr({
					name : ''+field[0]+'_'+n+'_'+field[2]+'_'+field[3]+'_'+c+'',
					id : ''+field[0]+'_'+n+'_'+field[2]+'_'+field[3]+'_'+c+''
				});
			
	        }else{
				$j(this).attr({
					name : ''+field[0]+'_'+n+'_'+field[2]+'_'+c+'',
					id : ''+field[0]+'_'+n+'_'+field[2]+'_'+c+'',
					'data-count' : ''+field[0]+'_'+n+'_'+field[2]+'_'+c+'',
				});
				
			}
		}
	});
    $j('#matrix_'+n+'_column #datefield_'+c+' .multisection').each(function(){
		$j(this).attr('class','answertext1 matrixdate multisection matrix_'+n+'_multidate_section'+c+'');
	});
	$j('#matrix_'+n+'_column #datefield_'+c+' .fplinks').attr('class','matrix_'+n+'_startdateLabel_'+c+' fplinks');
	$j('#matrix_'+n+'_column #datefield_'+c+' .fplinke').attr('class','matrix_'+n+'_enddateLabel_'+c+' fplinke');
}

function copypicker(id,t){
	var arr = id.split('_');
	var num = arr[1];
	var type = arr[2];
	var rnum = arr[3];
	var cnum = arr[4];
	if(t == 1){
		var rcount = $j("#matrix_"+num+"_grid .table-bordered").find('tr').length;
		if(rcount < 2){
			rcount = 2;
		}
		for(let r=1;r<rcount;r++){
		rnum = r;
		var sdate = $j('#matrix_'+num+'_txtStartDate_Hidden_'+cnum).val();
		var edate = $j('#matrix_'+num+'_txtEndDate_Hidden_'+cnum).val();
			if(type == 'sbasicDate'){
			startendpicker('matrix_'+num+'_sbasicDate_'+rnum+'_'+cnum+'',sdate,edate);
			}
		}
	}else if(t == 2){
		var colcount = $j("#matrix_"+num+"_grid .table-bordered").find('tr:eq(0) td').length;
		var sdate = $j('#matrix_'+num+'_txtStartDate_Hidden_'+cnum).val();
		var edate = $j('#matrix_'+num+'_txtEndDate_Hidden_'+cnum).val();
		for(let c=1;r<colcount;c++){
		cnum = c;
		if(type == 'basicDate'){
			singlepicker('matrix_'+num+'_basicDate_'+rnum+'_'+cnum+'','matrix_'+num+'_sbasicDate_'+rnum+'_'+cnum+'');
			}
		   if(type == 'multidate'){
			anypicker('matrix_'+num+'_multidate_'+rnum+'_'+cnum+'','matrix_'+num+'_bmultidate_'+rnum+'_'+cnum+'');
			}
			if(type == 'sbasicDate'){
			
			startendpicker('matrix_'+num+'_sbasicDate_'+rnum+'_'+cnum+'',sdate,edate);
			}
			if(type == 'rangeDate'){
			rangepicker('matrix_'+num+'_rangeDate_'+rnum+'_'+cnum+'','matrix_'+num+'_brangeDate_'+rnum+'_'+cnum+'');
			}
			if(type == 'slaunchdate'){
			
			}
		}
	}else{
	
	if(type == 'basicDate'){
	singlepicker('matrix_'+num+'_basicDate_'+rnum+'_'+cnum+'','matrix_'+num+'_sbasicDate_'+rnum+'_'+cnum+'');
	}
   if(type == 'multidate'){
	anypicker('matrix_'+num+'_multidate_'+rnum+'_'+cnum+'','matrix_'+num+'_bmultidate_'+rnum+'_'+cnum+'');
	}
	if(type == 'sbasicDate'){
	var sdate = $j('#matrix_'+num+'_txtStartDate_Hidden_'+cnum).val();
	var edate = $j('#matrix_'+num+'_txtEndDate_Hidden_'+cnum).val();
	startendpicker('matrix_'+num+'_sbasicDate_'+rnum+'_'+cnum+'',sdate,edate);
	}
	if(type == 'rangeDate'){
	rangepicker('matrix_'+num+'_rangeDate_'+rnum+'_'+cnum+'','matrix_'+num+'_brangeDate_'+rnum+'_'+cnum+'');
	}
	if(type == 'slaunchdate'){
	launchpicker('matrix_'+num+'_slaunchdate_'+rnum+'_'+cnum+'','matrix_'+num+'_bslaunchdate8_'+rnum+'_'+cnum+'');
	}
  }
}

function updatetotalrows(id){
var attrName = id.name;
var idnum = parseInt(id.value)
var qno = Number(attrName.match(/\d+$/));
var req = 1;
var count = $j("#matrix_"+qno+"_grid .table-bordered").find('tr[id="0"] td').length;
var def = parseInt($j('input[name=DefaultNumber'+qno+']').val());
var add = parseInt($j('input[name=AdditionalNumber'+qno+']').val());
var reqcnt = parseInt($j('input[name=RequiredNumber'+qno+']').val());
var rname = $j('input[name= matrix_'+qno+'_row_1_name').val();
var rcount = $j("#matrix_"+qno+"_grid .table-bordered").find('tr').length;
var row = rcount - 1;
var valid = false;
	//console.log(row);
	if(isNaN(def)){
		def = 0;
	}
	if(isNaN(add)){
		add = 0;
	}
	if(attrName == 'DefaultNumber'+qno+'' ){
       
	    if(def == '0'){
			alert("Please enter a value greater than 1 in the \"Default number of visible rows\" field.");
			id.focus();
			$j(id).val(1);
		}
		else if(Math.sign(idnum) == -1 && idnum != ''){
				alert("Please enter a whole, positive integer in the \"Default number of visible rows\" field.");
				id.focus();
				$j(id).val(1);
		}else{
			valid = true;
		}
   	}
	if(attrName == 'AdditionalNumber'+qno+'' ){
        if(add == '0'){
			$j('.addnewrow'+qno).hide();
		}
		else if(Math.sign(idnum) == -1 && idnum != ''){
				alert("Please enter a whole, positive integer in the \"Total number of additional rows\" field.");
				id.focus();
				$j(id).val('');
				
		}else{
			valid = true;
		}
   	}
	
	if(def > add){
		req = def;
	}else{
		req = add;
	}
	var totl = def + add;
	if(attrName == 'RequiredNumber'+qno+'' && idnum != ''){
        if(Math.sign(idnum) == -1){
				alert("Please enter a whole, positive integer in the \"Number of rows must populate\" field.");
				id.focus();
				$j(id).val('');
		}else{
			valid = true;
		}
   	}
	
	if(valid){
	// console.log(totl);
	var creq = parseInt($j('input[name=RequiredNumber'+qno+']').val());
	$j('.totalrows'+qno).val(parseInt(totl));
	$j('.totalrowslabel'+qno).html('<u>'+parseInt(totl)+'</u>');
	$j('.reqrows'+qno).attr('max',parseInt(totl));
	if(creq >= totl){
		
		$j('.reqrows'+qno).val(parseInt(totl));
		
	}
	if(def != ''){
		if(row > def && row > totl){
			var olddef = def + 1
			for(let r=olddef;r<=row;r++){
			$j(".matrixContainer"+qno+" .tab_head tr[id='"+r+"']").remove();
			$j("#matrix_"+qno+"_grid .table-bordered tr[id='"+r+"']").remove();
			}
		}else if(row > def){
			var olddef = def + 1
			for(let r=olddef;r<=row;r++){
			$j(".matrixContainer"+qno+" .tab_head tr[id='"+r+"']").remove();
			$j("#matrix_"+qno+"_grid .table-bordered tr[id='"+r+"']").remove();
			}
		}
		if(row < def){
		var cnt = 1;
		
		for(let r=rcount;r<=def;r++){
			var rno = r - 1;
			$j("#matrix_"+qno+"_grid .table-bordered tr[id='1'] td[id='0']").html(rname);
			if($j("#matrix_"+qno+"_grid .table-bordered ").find('tr[id="'+r+'"] td:eq(0)').length){
			$j("#matrix_"+qno+"_grid .table-bordered tr[id='"+r+"'] td[id='0']").html(rname);
			}else{
				var rclick = "javascript:checkUncheckImageRowColumn("+qno+","+r+",'row');";
				if(r > 1){
					$j("#matrix_"+qno+"_grid .table-bordered ").append('<tr id="'+r+'" class="gridtr" style="display: none;"><td id="0" class="gridRow" onClick='+rclick+'>'+ rname+' '+r +'</td></tr>');
				}else{
			       $j("#matrix_"+qno+"_grid .table-bordered ").append('<tr id="'+r+'" class="gridtr"><td id="0" class="gridRow" onClick='+rclick+'>'+ rname+' '+r +'</td></tr>');
				}
  		    for(let c=1;c<count;c++){
			$j("#matrix_"+qno+"_grid .table-bordered tr[id='"+r+"']").append("<td id='"+c+"' class='gridtd' onClick='javascript:checkUncheckImage("+qno+","+r+","+c+");'><input type='checkbox' name='matrix_"+qno+"_required_"+r+"_"+c+"' id='matrix_"+qno+"_required_"+r+"_"+c+"' value=''  style='display:none;'></td>");
			}
			
			

			$j(".matrixContainer"+qno+" .tab_head tr[id='1'] td[id='0'] div").html(rname+' '+cnt);
			if(($j(".matrixContainer"+qno+" .tab_head ").find('tr[id="'+r+'"] td:eq(0)').length)){
			$j(".matrixContainer"+qno+" .tab_head tr[id='"+r+"'] td[id='0'] div").html(rname+' '+r);
			}else{
			$j(".matrixContainer"+qno+" .tab_head").append('<tr id="'+r+'" class="even"><td id="0" ><div class="matrixRowLabel questiontext">'+ rname+' '+r + '</div></td></tr>');
			var prevRow = $j(".matrixContainer"+qno+" .tab_head tr[id='1']").children('td:not(:first)').clone();
			$j(".matrixContainer"+qno+" .tab_head tr[id='"+r+"']").append(prevRow);  
			$j(".matrixContainer"+qno+" .tab_head tr[id='"+r+"']").find('.requiredD').remove();
			if($j(".matrixContainer"+qno+" .tab_head tr[id='"+r+"']").attr('class') == 'even'){
				if(r%2 == 0){
			$j(".matrixContainer"+qno+" .tab_head tr[id='"+rno+"']").attr('class', 'odd');}
			}
			if($j(".matrixContainer"+qno+" .tab_head tr[id='"+r+"']").attr('class') == 'even'){
				if(r%2 != 0){
				$j(".matrixContainer"+qno+" .tab_head tr[id='"+r+"']").attr('class', 'odd');}
			}
			}
			}
			for(let c=1;c<count;c++){
			chngematrixdatefield(qno,c);
			changefieldnames(qno,r,c,'addrow');
			var img = $j("#matrix_"+qno+"_grid .table-bordered").find("tr#1 td#"+c+" img").length;
					if(img){
						$j('.matrixContainer'+qno+' .tab_head tr[id="'+r+'"] td[id="p3dtd'+c+'"] .pclass:not(".datesection")').prepend('<div class="requiredD"><span class="required1 star_req" style="display:; width: 4px;" >*</span></div>');
					}
			}
			
		}
		if(add != ''){
			for(let ri=2;ri<rcount;ri++){
			$j(".matrixContainer"+qno+" .tab_head tr[id="+ri+"] #removerow"+qno).remove();
			}
			//$j(".matrixContainer"+qno+" .tab_head tr[id="+rcount+"]").append('<div style="text-align: right; cursor: pointer;display: table-cell;vertical-align:bottom;margin-right: 5px;margin-bottom:5px;" id="removerow'+qno+'"><a onclick = "javascript:removerow('+qno+','+rcount+')" >remove</a></div>');
		}
		}
		/* for(let r=1;r<=reqcnt;r++){
		$j("#matrix_"+qno+"_grid .table-bordered").find("tr#"+r+" td img").remove();	
		$j("#matrix_"+qno+"_grid .table-bordered").find("tr#"+r+" td:not(:first-child)").append(chkImage);
		$j('.matrixContainer'+qno+' .tab_head tr#0 td').each(function(i){
			$j('.matrixContainer'+qno+' .tab_head').find("tr#"+r+":not(:first-child) td#p3dtd"+i+"").each(function(){
				$j(this).find(".requiredD").remove();	
				$j(this).find(".pclass").prepend('<div class="requiredD"><span class="required1 star_req" style="display:; width: 4px;" >*</span></div>');
			});
		});
		}*/
	}


	if($j("#matrix_"+qno+"_grid .table-bordered tr").length == 2){
		$j("#matrix_"+qno+"_grid .table-bordered tr[id='1'] td[id='0']").html(rname);
		$j(".matrixContainer"+qno+" .tab_head tr[id='1'] td#0 div").html(rname);
	}
	if( add != '' && row <= totl){
		var rno =  $j("#matrix_"+qno+"_grid .table-bordered").find('tr').length;
		$j('.addnewrow'+qno+' a').attr('onclick','javascript:addnewrow('+qno+','+rno+')');
		$j('.addnewrow'+qno+' a').html("<img src='../../images/icons/add.png' width='15' height='15' style='vertical-align:top;margin-right:3px;'>Add New "+rname);
		
		$j('.addnewrow'+qno).show();
	}else if(add != '' && row > def){
		$j('.addnewrow'+qno).show();
	}
	else{
		$j('.addnewrow'+qno).hide();
	}
  }
}
function addnewrow(q,r){
	var max = parseInt($j('input[name=MaximumNumber'+q+']').val());
	var def = parseInt($j('input[name=DefaultNumber'+q+']').val());
	var rcount = $j("#matrix_"+q+"_grid .table-bordered").find('tr').length;
	var rno = r + 1;
	var row = r - 1;
	var count = $j("#matrix_"+q+"_grid .table-bordered").find('tr#0 td').length;
	var rname = $j('input[name= matrix_'+q+'_row_1_name').val();
	$j("#matrix_"+q+"_grid .table-bordered tr[id='1'] td[id='0']").html(rname);
	$j(".matrixContainer"+q+" .tab_head tr[id='1'] td#0 div").html(rname+' '+1);
	    if(rcount <= max ){
		//console.log(r);
		
		$j("#matrix_"+q+"_grid .table-bordered ").append('<tr id="'+r+'" class="gridtr" style="display: none;><td id="0" class="gridRow" >'+ rname+'</td></tr>');
		
			
		
			$j(".matrixContainer"+q+" .tab_head ").append('<tr id="'+r+'" class="even"><td id="0" ><div class="matrixRowLabel questiontext">'+ rname+' '+r + '</div></td></tr>');    
			var prevRow = $j(".matrixContainer"+q+" .tab_head tr[id='1']:first").children('td:not(:first)').clone();
			$j(".matrixContainer"+q+" .tab_head tr[id='"+r+"']").append(prevRow);
			$j(".matrixContainer"+q+" .tab_head tr[id='"+r+"']").find('.requiredD').remove();
			$j(".matrixContainer"+q+" .tab_head tr[id='"+r+"']").append('<div style="text-align: right; cursor: pointer;display: table-cell;vertical-align:bottom;margin-right: 5px;margin-bottom:5px; padding-right: 10px;padding-bottom: 10px;" id="removerow'+q+'"><a onclick = "javascript:removerow('+q+','+r+')" >remove</a></div>');
			
			for(let c=1;c<count;c++){
				$j("#matrix_"+q+"_grid .table-bordered tr[id='"+r+"']").append("<td id="+c+" class='gridtd' onClick='javascript:checkUncheckImage("+q+","+r+","+c+");'><input type='checkbox' name='matrix_"+q+"_required_"+r+"_"+c+"' id='matrix_"+q+"_required_"+r+"_"+c+"' value=''  style='display:none;'></td>");
			chngematrixdatefield(q,c);	
			changefieldnames(q,r,c,'addrow');
			var img = $j("#matrix_"+q+"_grid .table-bordered").find("tr#1 td#"+c+" img").length;
					if(img){
						$j('.matrixContainer'+q+' .tab_head tr[id="'+r+'"] td[id="p3dtd'+c+'"] .pclass:not(".datesection")').prepend('<div class="requiredD"><span class="required1 star_req" style="display:; width: 4px;" >*</span></div>');
					}
			
		     }
			 $j('.addnewrow'+q+' a').attr('onclick','javascript:addnewrow('+q+','+rno+')');
	    }
		if($j(".matrixContainer"+q+" .tab_head tr[id='"+r+"']").attr('class') == 'even'){
			if(r%2 == 0){
		$j(".matrixContainer"+q+" .tab_head tr[id='"+row+"']").attr('class', 'odd');}}
		
		if($j(".matrixContainer"+q+" .tab_head tr[id='"+r+"']").attr('class') == 'even'){
			if(r%2 != 0){
			$j(".matrixContainer"+q+" .tab_head tr[id='"+r+"']").attr('class', 'odd');}
		}
		if(r == max){
			$j('.addnewrow'+q).hide();
		}
		/*for(let i=1;i<=reqcnt;i++){
			$j("#matrix_"+q+"_grid .table-bordered").find("tr#"+i+" td img").remove();	
			$j("#matrix_"+q+"_grid .table-bordered").find("tr#"+i+" td:not(:first-child)").append(chkImage);
			$j('.matrixContainer'+q+' .tab_head tr#0 td').each(function(j){
				$j('.matrixContainer'+q+' .tab_head').find("tr#"+i+":not(:first-child) td#p3dtd"+j+"").each(function(){
					$j(this).find(".requiredD").remove();	
					$j(this).find(".pclass").prepend('<div class="requiredD"><span class="required1 star_req" style="display:; width: 4px;" >*</span></div>');
				});
			});
			} */  
}

function removerow(q,r){
	var rname = $j('input[name= matrix_'+q+'_row_1_name').val();
	$j(".matrixContainer"+q+" .tab_head tr[id='"+r+"']").remove();
	$j("#matrix_"+q+"_grid .table-bordered tr[id='"+r+"']").remove();
	count = $j("#matrix_"+q+"_grid .table-bordered").find('tr#0 td').length;
	rcount = $j("#matrix_"+q+"_grid .table-bordered").find('tr').length;
	
	for(let rno=r;rno<rcount;rno++){
		var prevrow = rno + 1;
		$j(".matrixContainer"+q+" .tab_head tr[id='"+prevrow+"']").attr('id',''+rno+'');
		$j("#matrix_"+q+"_grid .table-bordered tr[id='"+prevrow+"']").attr('id',''+rno+'');
	    $j(".matrixContainer"+q+" .tab_head tr[id='"+rno+"'] td#0 div").html(rname+' '+rno);
		$j("#matrix_"+q+"_grid .table-bordered tr[id='"+rno+"'] td:eq(0)").html(rname+' '+rno);
		$j(".matrixContainer"+q+" .tab_head tr[id='"+rno+"'] #removerow"+q+" a").attr('onclick','javascript:removerow('+q+','+rno+')')
	for(let c=1;c<count;c++){
		//console.log(c,rno);
	   	changefieldnames(q,rno,c,'prevrow');
	}
	var i = rno-1;
    
	
	}
	if(i == 1){
		$j(".matrixContainer"+q+" .tab_head tr[id='"+(i+1)+"']").attr('class', 'even');	
	}
	for(let rno=1;rno<rcount;rno++){
		if($j(".matrixContainer"+q+" .tab_head tr[id='"+rno+"']").attr('class') == 'even'){
			if(rno%2 != 0){
		$j(".matrixContainer"+q+" .tab_head tr[id='"+rno+"']").attr('class', 'odd');}}
		if($j(".matrixContainer"+q+" .tab_head tr[id='"+rno+"']").attr('class') == 'odd'){
			if(rno%2 == 0){
		$j(".matrixContainer"+q+" .tab_head tr[id='"+rno+"']").attr('class', 'even');}}
		
				
	}	
	$j('.addnewrow'+q+' a').attr('onclick','javascript:addnewrow('+q+','+rcount+')');
	$j('.addnewrow'+q).show();
}
//SQM-965
	function helptext(num,rindex){
		$j11('#helptextdiv_'+num+rindex).show();
		if($j11("#helptexttitle_"+num).val() != ''){
			$j11('#helptd'+num).show();
			$j11('.helptdcls'+num).show();
		}
		$j11('#add_help_text_show_'+num+rindex).hide();
		$j11('#add_help_text_'+num+rindex).hide();
	}
	function closetext(num,rindex){
		if(rindex == 1){
			var countval='';
			$j(".helptextarea"+num).each(function(i){
				if($j(this).val() !=''){
					countval = 1;
				}
			});
		
			if(countval==1){
				var helptitle = $j("#helptext_"+num).html();
				$j("#helptexttitle_"+num).val(helptitle);
				alert("To delete this section, first click OK and remove the Help text you entered. Then, click the Delete option.");
			}else{
				$j11('#helptextdiv_'+num+rindex).hide();
				$j("#helptext_"+num+rindex).empty();
				$j("#helptext_"+num).empty();
				$j11('.help_text_div').hide();
				$j11('#helptd'+num).hide();
				$j11('.helptdcls'+num).hide();
				$j11('#helptextarea'+num+rindex).val('');
				$j("#helptexttitle_"+num).val('');
				$j11('#add_help_text_show_'+num+rindex).show();
				$j11('.addHelpText').show();
			}
				
		}else{
			$j11('#helptextdiv_'+num+rindex).hide();
			$j("#helptext_"+num+rindex).empty();
			$j11('#helptextarea'+num+rindex).val('');
			$j11('#add_help_text_'+num+rindex).show();
		}
	}
	function closetextall(closeall,num){
		$j11(".helptextarea"+num).each(function(){
		var rindex = $j11(this).attr('rindex');
		var num = $j11(this).attr('num');
		if(closeall==1){
		$j11('#helptextdiv_'+num+rindex).hide();
		}

		if((($j11('#helptextarea'+num+rindex).val() != '') && ($j11('#helptextdiv_'+num+rindex).css('display') != 'none')) ||  (($j11('#helptextarea'+num+rindex).val() == '') && ($j11('#helptextdiv_'+num+rindex).css('display') != 'none'))){
			$j11('#add_help_text_'+num+rindex).hide();
			$j11('#add_help_text_show_'+num+rindex).hide();
			$j11('#add_help_text_edit_'+num+rindex).show();
		}
		else if((($j11('#helptextarea'+num+rindex).val() != '') && ($j11('#helptextdiv_'+num+rindex).css('display') == 'none'))){
			$j11('#add_help_text_'+num+rindex).hide();
			$j11('#add_help_text_show_'+num+rindex).show();
			$j11('#add_help_text_edit_'+num+rindex).hide();
		}
		else{
			$j11('#add_help_text_'+num+rindex).show();
			$j11('#add_help_text_show_'+num+rindex).hide();
			$j11('#add_help_text_edit_'+num+rindex).hide();
		}
	});}

	function TitleValidation(num,arr,rindex){
		var x = $j("#helptexttitle_"+num).val();
		if(x.length>50){
			alert("Please enter title in range of 1-50 characters")
		}
		$j("#helptexttitle_"+num).val(x.slice(0,50));
	}
	function helptextDisplay(num,arr,rindex){
		if($j("#helptexttitle_"+num).val() != ''){
			var x = $j("#helptextarea"+num+rindex).val();
			$j("#helptext_"+num+rindex).html(x);
			$j("#helptext_"+num+rindex).show();
			}
			else{
				alert("Please add Help Text Title of Row 1");
			$j("#helptextarea"+num+rindex).val("");
				return 0;
			}
	}
	function helptexttitleDisplay(num,arr,rindex){
		var x = $j("#helptexttitle_"+num).val();
		var countval='';
		if($j("#helptexttitle_"+num).val() != ''){
			$j("#helptext_"+num).html(x);
			$j("#helptext_"+num).show();
			$j('#helptd'+num).show();
			$j(".helptdcls"+num).show();
		}
		else{
			$j(".helptextarea"+num).each(function(){
				if($j(this).val() !=''){
					countval = 1;
				}
			  });
			if($j("#helptexttitle_"+num).val() == '' && countval == ''){
				$j("#helptext_"+num).html('');
				$j('#helptd'+num).hide();
				$j(".helptdcls"+num).hide();
			}
		}
		if(countval==1){
			var helptitle = $j("#helptext_"+num).html();
			$j("#helptexttitle_"+num).val(helptitle);
			alert("To delete this section, first click OK and remove the Help text you entered. Then, click the Delete option.");
		}
	}
	