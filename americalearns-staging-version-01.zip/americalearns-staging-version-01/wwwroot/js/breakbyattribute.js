//this is the function to show the breAk by attributes area association wide
function breakByAttribute(allassociationitems, loadingImgId, AttributeDataDivId, clickLinkId, questionID, beginSurvey, endSurvey, notSelectedIds, programList, associationitemidcollectionselected, showingstatus, showtutorstudentall, whichanswertable, operationname, qsurveysiteuserid, attributeString, neededAssociationItems, thisElement, scope, questionType,omitattributelist,includetype_attribute, sites, dataForAttribute) {
	var BreakByTutorSelectRadio = "BreakByTutorSelectRadio_"+questionID;
	var BreakByTutorCheckBox = "BreakByTutorCheckBox_"+questionID;
	var BreakByTutorNumberText = "BreakByTutorNumberText_"+questionID;
	var BreakByTutor = "BreakByTutor_"+questionID;
	var BreakByTutorAssociationWideNonNumericCheckBox = "BreakByTutorAssociationWideNonNumericCheckBox_"+questionID;
	var BreakByStudentAssociationWideSelectRadio = "BreakByStudentAssociationWideSelectRadio_"+questionID;
	var BreakByTutorAssociationWideNonNumericSelectRadio = "BreakByTutorAssociationWideNonNumericSelectRadio_"+questionID;
	var BreakByStudentSiteWideCheckBox = "BreakByStudentSiteWideCheckBox_"+questionID;
	var BreakByResponseSelectRadio = "BreakByResponseSelectRadio_"+questionID;
	var BreakByTutorNonNumeric = "BreakByTutorNonNumeric_"+questionID;
	var BreakByResponseCheckBox = "BreakByResponseCheckBox_"+questionID;
	var BreakByStudentAssociationWideCheckBox = "BreakByStudentAssociationWideCheckBox_"+questionID;
	var BreakByTutorCheckBoxAssociationWide = "BreakByTutorCheckBoxAssociationWide_"+questionID;
	var BreakByTutorAssociationWideNumberText = "BreakByTutorAssociationWideNumberText_"+questionID;
	var BreakByStudentSiteWideSelectRadio = "BreakByStudentSiteWideSelectRadio_"+questionID;
	var BreakByTutorNonNumericCheckBox = "BreakByTutorNonNumericCheckBox_"+questionID;
	var BreakByTutorAssociationWideSelectRadio = "BreakByTutorAssociationWideSelectRadio_"+questionID;
	var BreakByResponseAssociationWideCheckBox = "BreakByResponseAssociationWideCheckBox_"+questionID;
	var BreakByTutorAssociationWideTimeSeries = "BreakByTutorAssociationWideTimeSeries_"+questionID;
	var BreakByResponseAssociationWideSelectRadio = "BreakByResponseAssociationWideSelectRadio_"+questionID;
    var BreakByTutorAssociationWideSelectRadioId = document.getElementById(BreakByTutorAssociationWideSelectRadio);
	var BreakByStudentAssociationWideCheckBoxId = document.getElementById(BreakByStudentAssociationWideCheckBox);
	var BreakByTutorAssociationWideNonNumericCheckBoxId = document.getElementById(BreakByTutorAssociationWideNonNumericCheckBox);
    var BreakByTutorSelectRadioId = document.getElementById(BreakByTutorSelectRadio);
	var BreakByTutorAssociationWideNonNumericSelectRadioId = document.getElementById(BreakByTutorAssociationWideNonNumericSelectRadio);
    var BreakByTutorCheckBoxId = document.getElementById(BreakByTutorCheckBox);
	var BreakByResponseAssociationWideSelectRadioId = document.getElementById(BreakByResponseAssociationWideSelectRadio);
	var BreakByTutorNumberTextId = document.getElementById(BreakByTutorNumberText);
	var BreakByStudentAssociationWideSelectRadioId = document.getElementById(BreakByStudentAssociationWideSelectRadio);
	var BreakByTutorNonNumericId = document.getElementById(BreakByTutorNonNumeric);
	var BreakByResponseSelectRadioId = document.getElementById(BreakByResponseSelectRadio);
	var BreakByResponseCheckBoxId = document.getElementById(BreakByResponseCheckBox);
	var BreakByTutorAssociationWideTimeSeriesId = document.getElementById(BreakByTutorAssociationWideTimeSeries);
	var BreakByTutorId = document.getElementById(BreakByTutor);
	var BreakByResponseAssociationWideCheckBoxId = document.getElementById(BreakByResponseAssociationWideCheckBox);
	var BreakByStudentSiteWideCheckBoxId = document.getElementById(BreakByStudentSiteWideCheckBox);	
	var BreakByTutorNonNumericCheckBoxId = document.getElementById(BreakByTutorNonNumericCheckBox);
	var BreakByTutorAssociationWideNumberTextId = document.getElementById(BreakByTutorAssociationWideNumberText);
	var BreakByTutorCheckBoxAssociationWideId = document.getElementById(BreakByTutorCheckBoxAssociationWide);
	var BreakByStudentSiteWideSelectRadioId = document.getElementById(BreakByStudentSiteWideSelectRadio);
    if(BreakByTutorSelectRadioId!== null)
	BreakByTutorSelectRadioId.classList.add("breakOutOtherThanAttribute");
    if(BreakByResponseCheckBoxId !== null)
	BreakByResponseCheckBoxId.classList.add("breakOutOtherThanAttribute");
	if(BreakByStudentSiteWideSelectRadioId !== null)
	BreakByStudentSiteWideSelectRadioId.classList.add("breakOutOtherThanAttribute");
	if(BreakByTutorCheckBoxId !== null)
	BreakByTutorCheckBoxId.classList.add("breakOutOtherThanAttribute");
	if(BreakByTutorNumberTextId !== null)
	BreakByTutorNumberTextId.classList.add("breakOutOtherThanAttribute");
    if(BreakByTutorNonNumericCheckBoxId !== null)
	BreakByTutorNonNumericCheckBoxId.classList.add("breakOutOtherThanAttribute");
    if(BreakByTutorAssociationWideNumberTextId !== null)
	BreakByTutorAssociationWideNumberTextId.classList.add("breakOutOtherThanAttribute");
    if(BreakByTutorCheckBoxAssociationWideId !== null)
	BreakByTutorCheckBoxAssociationWideId.classList.add("breakOutOtherThanAttribute");
    if(BreakByTutorId !== null)
	BreakByTutorId.classList.add("breakOutOtherThanAttribute");
    if(BreakByTutorNonNumericId !== null)
	BreakByTutorNonNumericId.classList.add("breakOutOtherThanAttribute");
    if(BreakByResponseSelectRadioId !== null)
	BreakByResponseSelectRadioId.classList.add("breakOutOtherThanAttribute");
    if(BreakByStudentSiteWideCheckBoxId !== null)
	BreakByStudentSiteWideCheckBoxId.classList.add("breakOutOtherThanAttribute");
    if(BreakByTutorAssociationWideSelectRadioId !== null)
    BreakByTutorAssociationWideSelectRadioId.classList.add("breakOutOtherThanAttribute");
	if(BreakByResponseAssociationWideCheckBoxId !== null)
    BreakByResponseAssociationWideCheckBoxId.classList.add("breakOutOtherThanAttribute"); 
    if(BreakByStudentAssociationWideCheckBoxId  !== null)
    BreakByStudentAssociationWideCheckBoxId .classList.add("breakOutOtherThanAttribute");
    if(BreakByTutorAssociationWideTimeSeriesId  !== null)
    BreakByTutorAssociationWideTimeSeriesId .classList.add("breakOutOtherThanAttribute");
    if( BreakByTutorAssociationWideNonNumericSelectRadioId  !== null)
    BreakByTutorAssociationWideNonNumericSelectRadioId .classList.add("breakOutOtherThanAttribute");
    if( BreakByResponseAssociationWideSelectRadioId  !== null)
    BreakByResponseAssociationWideSelectRadioId .classList.add("breakOutOtherThanAttribute");
    if( BreakByStudentAssociationWideSelectRadioId  !== null)
    BreakByStudentAssociationWideSelectRadioId .classList.add("breakOutOtherThanAttribute");
    if( BreakByTutorAssociationWideNonNumericCheckBoxId  !== null)
    BreakByTutorAssociationWideNonNumericCheckBoxId.classList.add("breakOutOtherThanAttribute");
	
	attributeString = (jQuery('#attributeString' + questionID).length > 0 ) ? jQuery('#attributeString' + questionID).val():'';
	neededAssociationItems = (jQuery('#theListOfAssociationItems' + questionID).length > 0 ) ? jQuery('#theListOfAssociationItems' + questionID).val() : '';
	allassociationitems = (jQuery('#hidden_allassociationitems').length > 0 ) ? jQuery('#hidden_allassociationitems').val():'';
	associationitemidcollectionselected = (jQuery('#hidden_associationitemidcollectionselected').length > 0 ) ? jQuery('#hidden_associationitemidcollectionselected').val():'';
	jQuery('#' + 'AttributeSelectionDiv' + questionID + ' input[type=radio]').attr('disabled',true);
	if (document.getElementById(AttributeDataDivId).style.display == 'none' || showingstatus == 'firsttimemain' || showingstatus == 'z-a' || showingstatus == 'a-z' || showingstatus == 'asc' || showingstatus == 'desc') {
		parameterVar = getUrlVars(attributeString);
		parameterVar = jQuery.extend({},parameterVar,{
			allassociationitems : allassociationitems, allassociations : neededAssociationItems, 
			associationitemidcollectionselected : associationitemidcollectionselected, qsurveysiteuserid : qsurveysiteuserid, scope : scope, sites : sites, 
			questionid : questionID, quid : questionID, beginsurvey : beginSurvey, endsurvey : endSurvey,notselectedids : notSelectedIds, 
			programlist : programList, showingstatus : showingstatus, showtutorstudentall : showtutorstudentall, whichanswertable : whichanswertable, 
			operationname : operationname, neededassociations : neededAssociationItems, questionType : questionType, 
			omitattributelist : omitattributelist, includetype_attribute : includetype_attribute
		});
		/*parameterVar["allassociationitems"] = allassociationitems;
		parameterVar["allassociations"] = neededAssociationItems;
		parameterVar["associationitemidcollectionselected"] = associationitemidcollectionselected;
		parameterVar["qsurveysiteuserid"] = qsurveysiteuserid;
		parameterVar["scope"] = scope;
		parameterVar["sites"] = sites;
		parameterVar["questionid"] = questionID;
		parameterVar["quid"] = questionID;
		parameterVar["beginsurvey"] = beginSurvey;
		parameterVar["endsurvey"] = endSurvey;
		parameterVar["notselectedids"] = notSelectedIds;
		parameterVar["programlist"] = programList;
		parameterVar["showingstatus"] = showingstatus;
		parameterVar["showtutorstudentall"] = showtutorstudentall;
		parameterVar["whichanswertable"] = whichanswertable;
		parameterVar["operationname"] = operationname;
		parameterVar["neededassociations"] = neededAssociationItems;
		parameterVar["questionType"] = questionType;
		parameterVar["omitattributelist"] = omitattributelist;
		parameterVar["includetype_attribute"] = includetype_attribute*/
		document.getElementById(loadingImgId).style.display = 'block';
		/*if (document.getElementById(AttributeDataDivId).style.display != 'none' && showingstatus == 'firsttimemain') {
			document.getElementById(loadingImgId).style.display = 'none';
		} else {*/
		
		if(typeof dataForAttribute === 'undefined'){
			new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbyattributelist" ), {
				method: 'post',
				parameters: parameterVar,
				onSuccess: function(returnHtml) {
					var attributeSelectionDiv = "AttributeSelectionDiv" + questionID; 
					document.getElementById(loadingImgId).style.display = 'none';
					//document.getElementById(clickLinkId).style.display = 'block';
					Element.update(attributeSelectionDiv, returnHtml.responseText);
					var trimedFunctionString = jQuery.trim(thisElement.getAttribute('onclick'));
					trimedFunctionString = trimedFunctionString.substring(0, trimedFunctionString.length - 2);
					jQuery('#' + attributeSelectionDiv + ' input[type=radio]').each(function(){
						jQuery(this).attr('onclick',trimedFunctionString + ',' + jQuery(this).attr('rel') + ');');
					});
					//Effect.toggle(AttributeDataDivId, 'slide');
					var tutdiv = "TutorDataDiv" + questionID;
					var tutorOnlydiv = "TutorOnly" + questionID;
					var studentdiv = "StudentDataDiv" + questionID;
					var blindDownCheck = 0;
					if (typeof (jQuery('#' + tutorOnlydiv).css('display')) === 'undefined') {
						blindDownCheck = 1;
					} else if(jQuery('#' + tutorOnlydiv).css('display') != 'none'){
						//document.getElementById(tutorOnlydiv).style.display = 'none';
						blindDownCheck = 1;
					} else {
						if (document.getElementById(tutdiv).style.display != 'none' || document.getElementById(studentdiv).style.display != 'none') {
							//document.getElementById(tutdiv).style.display = 'none';
							//document.getElementById(studentdiv).style.display = 'none';
							if (showingstatus == 'firsttimemain') {
								blindDownCheck = 1;
							}
						} else {
							if (showingstatus == 'firsttimemain')
								blindDownCheck = 1;
						}
					}
					if(blindDownCheck == 1){
						if(jQuery('#' + attributeSelectionDiv).css('display') == 'none'){
							//Effect.BlindDown(attributeSelectionDiv, { afterFinish:  function () {}});
							if (jQuery('#' + attributeSelectionDiv + ' input[type=radio]').length >= 1) {
								jQuery('#' + tutorOnlydiv + ', #' + tutdiv + ', #' + studentdiv).slideUp();
								//jQuery('#' + tutdiv).slideUp(1500);
								//jQuery('#' + studentdiv).slideUp(1500);
							}
							//jQuery('#' + attributeSelectionDiv).slideDown(1500);
							jQuery('#' + attributeSelectionDiv).show();
						} else{
							document.getElementById(attributeSelectionDiv).style.display = 'block';
						}
						
					}
					if (jQuery('#' + attributeSelectionDiv + ' input[type=radio]').length === 1) 
						jQuery('#' + attributeSelectionDiv + ' input[type=radio]').click().attr('checked', 'checked');
						
					jQuery('#' + attributeSelectionDiv + ' input[type=radio]').attr('disabled',false);
				},
				onFailure: function() {
					alert('Oops...mistake on server');
					jQuery('#' + attributeSelectionDiv + ' input[type=radio]').attr('disabled',false);
				}
			});
		} else {
			parameterVar["dataForAttribute"] = dataForAttribute;
			new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbyattribute"), {
				method: 'post',
				parameters: parameterVar,
				onSuccess: function(returnHtml) {
					document.getElementById(loadingImgId).style.display = 'none';
					document.getElementById(clickLinkId).style.display = 'block';
					Element.update(AttributeDataDivId, returnHtml.responseText);
					//Effect.toggle(AttributeDataDivId, 'slide');
					var tutdiv = "TutorDataDiv" + questionID;
					var tutorOnlydiv = "TutorOnly" + questionID;
					var studentdiv = "StudentDataDiv" + questionID;
					if (typeof (jQuery('#' + tutorOnlydiv).css('display')) === 'undefined') {
						document.getElementById(AttributeDataDivId).style.display = 'block';
					} else if(jQuery('#' + tutorOnlydiv).css('display') != 'none'){
						document.getElementById(AttributeDataDivId).style.display = 'block';
						document.getElementById(tutorOnlydiv).style.display = 'none';
					} else{
						if (document.getElementById(tutdiv).style.display != 'none' || document.getElementById(studentdiv).style.display != 'none') {
							document.getElementById(tutdiv).style.display = 'none';
							document.getElementById(studentdiv).style.display = 'none';
							if (showingstatus == 'firsttimemain') {
								document.getElementById(AttributeDataDivId).style.display = 'block';
							}
						} else {
							if (showingstatus == 'firsttimemain')
								//Effect.BlindDown(AttributeDataDivId);
								jQuery('#' + tutorOnlydiv + ', #' + tutdiv + ', #' + studentdiv).slideUp();
								jQuery('#' + AttributeDataDivId).slideDown(1500);
						}
					}
					jQuery('#' + 'AttributeSelectionDiv' + questionID + ' input[type=radio]').attr('disabled',false);
				},
				onFailure: function() {
					alert('Oops...mistake on server');
					jQuery('#' + 'AttributeSelectionDiv' + questionID + ' input[type=radio]').attr('disabled',false);
				}
			});
		}
		/*}*/
	} else {
		processAndCloseBreakBoxAttributeAssociationWide(AttributeDataDivId, loadingImgId);
	}
}
function breakByAttribute_volunteers(allassociationitems, loadingImgId, AttributeDataDivId, clickLinkId, questionID, beginSurvey, endSurvey, notSelectedIds, programList, associationitemidcollectionselected, showingstatus, showtutorstudentall, whichanswertable, operationname, qsurveysiteuserid, attributeString, neededAssociationItems, thisElement, scope, questionType,omitattributelist,includetype_attribute, sites, volunteeruserid, dataForAttribute) {
	attributeString = (jQuery('#attributeString' + questionID).length > 0 ) ? jQuery('#attributeString' + questionID).val():'';
	neededAssociationItems = (jQuery('#theListOfAssociationItems' + questionID).length > 0 ) ? jQuery('#theListOfAssociationItems' + questionID).val() : '';
	allassociationitems = (jQuery('#hidden_allassociationitems').length > 0 ) ? jQuery('#hidden_allassociationitems').val():'';
	associationitemidcollectionselected = (jQuery('#hidden_associationitemidcollectionselected').length > 0 ) ? jQuery('#hidden_associationitemidcollectionselected').val():'';
	jQuery('#' + 'AttributeSelectionDiv' + questionID + ' input[type=radio]').attr('disabled',true);
	if (document.getElementById(AttributeDataDivId).style.display == 'none' || showingstatus == 'firsttimemain' || showingstatus == 'z-a' || showingstatus == 'a-z' || showingstatus == 'asc' || showingstatus == 'desc') {
		parameterVar = getUrlVars(attributeString);
		parameterVar = jQuery.extend({},parameterVar,{
			allassociationitems : allassociationitems, allassociations : neededAssociationItems, 
			associationitemidcollectionselected : associationitemidcollectionselected, qsurveysiteuserid : qsurveysiteuserid, scope : scope, sites : sites, 
			questionid : questionID, quid : questionID, beginsurvey : beginSurvey, endsurvey : endSurvey,notselectedids : notSelectedIds, 
			programlist : programList, showingstatus : showingstatus, showtutorstudentall : showtutorstudentall, whichanswertable : whichanswertable, 
			operationname : operationname, neededassociations : neededAssociationItems, questionType : questionType, 
			omitattributelist : omitattributelist, includetype_attribute : includetype_attribute, volunteeruserid : volunteeruserid
		});
		/*parameterVar["allassociationitems"] = allassociationitems;
		parameterVar["allassociations"] = neededAssociationItems;
		parameterVar["associationitemidcollectionselected"] = associationitemidcollectionselected;
		parameterVar["qsurveysiteuserid"] = qsurveysiteuserid;
		parameterVar["scope"] = scope;
		parameterVar["sites"] = sites;
		parameterVar["questionid"] = questionID;
		parameterVar["quid"] = questionID;
		parameterVar["beginsurvey"] = beginSurvey;
		parameterVar["endsurvey"] = endSurvey;
		parameterVar["notselectedids"] = notSelectedIds;
		parameterVar["programlist"] = programList;
		parameterVar["showingstatus"] = showingstatus;
		parameterVar["showtutorstudentall"] = showtutorstudentall;
		parameterVar["whichanswertable"] = whichanswertable;
		parameterVar["operationname"] = operationname;
		parameterVar["neededassociations"] = neededAssociationItems;
		parameterVar["questionType"] = questionType;
		parameterVar["omitattributelist"] = omitattributelist;
		parameterVar["includetype_attribute"] = includetype_attribute*/
		document.getElementById(loadingImgId).style.display = 'block';
		/*if (document.getElementById(AttributeDataDivId).style.display != 'none' && showingstatus == 'firsttimemain') {
			document.getElementById(loadingImgId).style.display = 'none';
		} else {*/
		
		if(typeof dataForAttribute === 'undefined'){
			new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbyattributelist" ), {
				method: 'post',
				parameters: parameterVar,
				onSuccess: function(returnHtml) {
					var attributeSelectionDiv = "AttributeSelectionDiv" + questionID; 
					document.getElementById(loadingImgId).style.display = 'none';
					//document.getElementById(clickLinkId).style.display = 'block';
					Element.update(attributeSelectionDiv, returnHtml.responseText);
					var trimedFunctionString = jQuery.trim(thisElement.getAttribute('onclick'));
					trimedFunctionString = trimedFunctionString.substring(0, trimedFunctionString.length - 2);
					jQuery('#' + attributeSelectionDiv + ' input[type=radio]').each(function(){
						jQuery(this).attr('onclick',trimedFunctionString + ',' + jQuery(this).attr('rel') + ');');
					}); 
					//Effect.toggle(AttributeDataDivId, 'slide');
					var tutdiv = "TutorDataDiv" + questionID;
					var tutorOnlydiv = "TutorOnly" + questionID;
					var studentdiv = "StudentDataDiv" + questionID;
					var blindDownCheck = 0;
					if (typeof (jQuery('#' + tutorOnlydiv).css('display')) === 'undefined') {
						blindDownCheck = 1;
					} else if(jQuery('#' + tutorOnlydiv).css('display') != 'none'){
						//document.getElementById(tutorOnlydiv).style.display = 'none';
						blindDownCheck = 1;
					} else {
						if (document.getElementById(tutdiv).style.display != 'none' || document.getElementById(studentdiv).style.display != 'none') {
							//document.getElementById(tutdiv).style.display = 'none';
							//document.getElementById(studentdiv).style.display = 'none';
							if (showingstatus == 'firsttimemain') {
								blindDownCheck = 1;
							}
						} else {
							if (showingstatus == 'firsttimemain')
								blindDownCheck = 1;
						}
					}
					if(blindDownCheck == 1){
						if(jQuery('#' + attributeSelectionDiv).css('display') == 'none'){
							//Effect.BlindDown(attributeSelectionDiv, { afterFinish:  function () {}});
							if (jQuery('#' + attributeSelectionDiv + ' input[type=radio]').length >= 1) {
								jQuery('#' + tutorOnlydiv + ', #' + tutdiv + ', #' + studentdiv).slideUp();
								//jQuery('#' + tutdiv).slideUp(1500);
								//jQuery('#' + studentdiv).slideUp(1500);
							}
							//jQuery('#' + attributeSelectionDiv).slideDown(1500);
							jQuery('#' + attributeSelectionDiv).show();
						} else{
							document.getElementById(attributeSelectionDiv).style.display = 'block';
						}
						
					}
					if (jQuery('#' + attributeSelectionDiv + ' input[type=radio]').length === 1) 
						jQuery('#' + attributeSelectionDiv + ' input[type=radio]').click().attr('checked', 'checked');
						
					jQuery('#' + attributeSelectionDiv + ' input[type=radio]').attr('disabled',false);
				},
				onFailure: function() {
					alert('Oops...mistake on server');
					jQuery('#' + attributeSelectionDiv + ' input[type=radio]').attr('disabled',false);
				}
			});
		} else {
			parameterVar["dataForAttribute"] = dataForAttribute;
			new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbyattribute"), {
				method: 'post',
				parameters: parameterVar,
				onSuccess: function(returnHtml) {
					document.getElementById(loadingImgId).style.display = 'none';
					document.getElementById(clickLinkId).style.display = 'block';
					Element.update(AttributeDataDivId, returnHtml.responseText);
					//Effect.toggle(AttributeDataDivId, 'slide');
					var tutdiv = "TutorDataDiv" + questionID;
					var tutorOnlydiv = "TutorOnly" + questionID;
					var studentdiv = "StudentDataDiv" + questionID;
					if (typeof (jQuery('#' + tutorOnlydiv).css('display')) === 'undefined') {
						document.getElementById(AttributeDataDivId).style.display = 'block';
					} else if(jQuery('#' + tutorOnlydiv).css('display') != 'none'){
						document.getElementById(AttributeDataDivId).style.display = 'block';
						document.getElementById(tutorOnlydiv).style.display = 'none';
					} else{
						if (document.getElementById(tutdiv).style.display != 'none' || document.getElementById(studentdiv).style.display != 'none') {
							document.getElementById(tutdiv).style.display = 'none';
							document.getElementById(studentdiv).style.display = 'none';
							if (showingstatus == 'firsttimemain') {
								document.getElementById(AttributeDataDivId).style.display = 'block';
							}
						} else {
							if (showingstatus == 'firsttimemain')
								//Effect.BlindDown(AttributeDataDivId);
								jQuery('#' + tutorOnlydiv + ', #' + tutdiv + ', #' + studentdiv).slideUp();
								jQuery('#' + AttributeDataDivId).slideDown(1500);
						}
					}
					jQuery('#' + 'AttributeSelectionDiv' + questionID + ' input[type=radio]').attr('disabled',false);
				},
				onFailure: function() {
					alert('Oops...mistake on server');
					jQuery('#' + 'AttributeSelectionDiv' + questionID + ' input[type=radio]').attr('disabled',false);
				}
			});
		}
		/*}*/
	} else {
		processAndCloseBreakBoxAttributeAssociationWide(AttributeDataDivId, loadingImgId);
	}
}
function breakByAttributeInner(allassociationitems,loadingImgId,AttributeDataDivId,clickLinkId,questionID,beginSurvey,endSurvey,notSelectedIds,programList,associationitemidcollectionselected,showingstatus,showtutorstudentall,whichanswertable,qsurveysiteuserid,attributeID,attributeValue,attributeString,neededAssociationItems,scope,questionType,omitattributelist,includetype_attribute,sites,secretkey,AgeDescription,CalculatedCurrentAge){
	attributeString = (jQuery('#attributeString' + questionID).length > 0 ) ? jQuery('#attributeString' + questionID).val():'';
	neededAssociationItems = (jQuery('#theListOfAssociationItems' + questionID).length > 0 ) ? jQuery('#theListOfAssociationItems' + questionID).val() : '';
	allassociationitems = (jQuery('#hidden_allassociationitems').length > 0 ) ? jQuery('#hidden_allassociationitems').val():'';
	associationitemidcollectionselected = (jQuery('#hidden_associationitemidcollectionselected').length > 0 ) ? jQuery('#hidden_associationitemidcollectionselected').val():'';
	if(document.getElementById(AttributeDataDivId).style.display == 'none' || showingstatus == 'firsttimemain' || showingstatus == 'z-a' || showingstatus == 'a-z' || showingstatus == 'asc' || showingstatus == 'desc'){
		parameterVar = getUrlVars(attributeString);
		parameterVar = jQuery.extend({},parameterVar,{
			allassociationitems : allassociationitems, allassociations : neededAssociationItems, 
			associationitemidcollectionselected : associationitemidcollectionselected, qsurveysiteuserid : qsurveysiteuserid, scope : scope, sites : sites, 
			questionid : questionID, quid : questionID, beginsurvey : beginSurvey, endsurvey : endSurvey,notselectedids : notSelectedIds, 
			programlist : programList, showingstatus : showingstatus, showtutorstudentall : showtutorstudentall, whichanswertable : whichanswertable, 
			/*operationname : operationname, */neededassociations : neededAssociationItems, questionType : questionType, 
			omitattributelist : omitattributelist, includetype_attribute : includetype_attribute,
			attributeID : attributeID, attributeValue : attributeValue, secretkey : secretkey,AgeDescription:AgeDescription,CalculatedCurrentAge:CalculatedCurrentAge
		});
		/*parameterVar["allassociationitems"] = allassociationitems;
		parameterVar["allassociations"] = neededAssociationItems;
		parameterVar["associationitemidcollectionselected"] = associationitemidcollectionselected;
		parameterVar["qsurveysiteuserid"] = qsurveysiteuserid;
		parameterVar["scope"] = scope;
		parameterVar["sites"] = sites;
		parameterVar["questionid"] = questionID;
		parameterVar["quid"] = questionID;
		parameterVar["beginsurvey"] = beginSurvey;
		parameterVar["endsurvey"] = endSurvey;
		parameterVar["notselectedids"] = notSelectedIds;
		parameterVar["programlist"] = programList;
		parameterVar["showingstatus"] = showingstatus;
		parameterVar["showtutorstudentall"] = showtutorstudentall;
		parameterVar["whichanswertable"] = whichanswertable;
		//parameterVar["operationname"] = operationname;
		parameterVar["neededassociations"] = neededAssociationItems;
		parameterVar["questionType"] = questionType;
		parameterVar["omitattributelist"] = omitattributelist;
		parameterVar["includetype_attribute"] = includetype_attribute
		parameterVar["attributeID"] = attributeID;
		parameterVar["attributeValue"] = attributeValue;*/
		document.getElementById(loadingImgId).style.display = 'block';
		if (document.getElementById(AttributeDataDivId).style.display != 'none' && showingstatus == 'firsttimemain'){
			document.getElementById(loadingImgId).style.display = 'none';
		} else {
			new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbyattributeinner"),{
				method: 'post',
				parameters: parameterVar,
				onSuccess: function(returnHtml) { 
					document.getElementById(loadingImgId).style.display = 'none';
					document.getElementById(clickLinkId).style.display = 'block';
					//Element.update(AttributeDataDivId, returnHtml.responseText); 
					Element.replace(AttributeDataDivId, returnHtml.responseText); 
					//Effect.toggle(AttributeDataDivId, 'slide');
					if (showingstatus == 'firsttimemain')
					Effect.BlindDown(AttributeDataDivId);
				}, 
				onFailure: function(){ 
				alert('Oops...mistake on server');
				} 
			});
		}
	} else {
		processAndCloseBreakBoxAttributeAssociationWide(AttributeDataDivId,loadingImgId);
	}
}
function breakByAttributeInner_volunteers(allassociationitems,loadingImgId,AttributeDataDivId,clickLinkId,questionID,beginSurvey,endSurvey,notSelectedIds,programList,associationitemidcollectionselected,showingstatus,showtutorstudentall,whichanswertable,qsurveysiteuserid,attributeID,attributeValue,attributeString,neededAssociationItems,scope,questionType,omitattributelist,includetype_attribute,sites,volunteeruserid){
	attributeString = (jQuery('#attributeString' + questionID).length > 0 ) ? jQuery('#attributeString' + questionID).val():'';
	neededAssociationItems = (jQuery('#theListOfAssociationItems' + questionID).length > 0 ) ? jQuery('#theListOfAssociationItems' + questionID).val() : '';
	allassociationitems = (jQuery('#hidden_allassociationitems').length > 0 ) ? jQuery('#hidden_allassociationitems').val():'';
	associationitemidcollectionselected = (jQuery('#hidden_associationitemidcollectionselected').length > 0 ) ? jQuery('#hidden_associationitemidcollectionselected').val():'';
	if(document.getElementById(AttributeDataDivId).style.display == 'none' || showingstatus == 'firsttimemain' || showingstatus == 'z-a' || showingstatus == 'a-z' || showingstatus == 'asc' || showingstatus == 'desc'){
		parameterVar = getUrlVars(attributeString);
		parameterVar = jQuery.extend({},parameterVar,{
			allassociationitems : allassociationitems, allassociations : neededAssociationItems, 
			associationitemidcollectionselected : associationitemidcollectionselected, qsurveysiteuserid : qsurveysiteuserid, scope : scope, sites : sites, 
			questionid : questionID, quid : questionID, beginsurvey : beginSurvey, endsurvey : endSurvey,notselectedids : notSelectedIds, 
			programlist : programList, showingstatus : showingstatus, showtutorstudentall : showtutorstudentall, whichanswertable : whichanswertable, 
			/*operationname : operationname, */neededassociations : neededAssociationItems, questionType : questionType, 
			omitattributelist : omitattributelist, includetype_attribute : includetype_attribute,
			attributeID : attributeID, attributeValue : attributeValue, volunteeruserid : volunteeruserid
		});
		
		document.getElementById(loadingImgId).style.display = 'block';
		/*if (document.getElementById(AttributeDataDivId).style.display != 'none' && showingstatus == 'firsttimemain'){
			document.getElementById(loadingImgId).style.display = 'none';
		}*/
		new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbyattributeinner"),{
			method: 'post',
			parameters: parameterVar,
			onSuccess: function(returnHtml) { 
				document.getElementById(loadingImgId).style.display = 'none';
				document.getElementById(clickLinkId).style.display = 'block';
				//Element.update(AttributeDataDivId, returnHtml.responseText);
				document.getElementById(AttributeDataDivId).style.display = 'block';
				Element.replace(AttributeDataDivId, returnHtml.responseText); 
				//Effect.toggle(AttributeDataDivId, 'slide');
				//if (showingstatus == 'firsttimemain')
					//Effect.BlindDown(AttributeDataDivId);
			}, 
			onFailure: function(){ 
				alert('Oops...mistake on server');
			} 
		});
		
	} else {
		processAndCloseBreakBoxAttributeAssociationWide(AttributeDataDivId,loadingImgId);
	}
}
function processAndCloseBreakBoxAttributeAssociationWide(AttributeDataDivId, loadingImgId) {
	var AttributeSelectionDivId = AttributeDataDivId.replace('Data','Selection');
	document.getElementById(loadingImgId).style.display = 'block';
	Effect.Fade(AttributeDataDivId);
	//Effect.toggle(AttributeDataDivId, 'slide');
	Effect.BlindUp(AttributeDataDivId);
	jQuery('#' + AttributeSelectionDivId).find('input[type=radio]').each(function(){
		jQuery(this).attr('disabled','disabled');
	})
	jQuery('#' + AttributeSelectionDivId).hide("slow");
	document.getElementById(loadingImgId).style.display = 'none';
}

//Read a page's GET URL variables and return them as an associative array.
function getUrlVars(queryString){
	var vars = {}, hash;
	var hashes = queryString.split('&');
	for(var i = 0; i < hashes.length; i++){
		hash = hashes[i].split('=');
		vars[hash[0]] = hash[1];
	}
	return vars;
}