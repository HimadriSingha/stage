//this is the function to show the breAk by tutor area
function BreakByTutorNumberText(scopeName, loadingImgId, TutorDataDivId, clickLinkId, questionID, beginSurvey, endSurvey, notSelectedIds, siteidList, programList, showingstatus, showtutorstudentall) {
	  var BreakByTutorNumberText = "BreakByTutorNumberText_"+questionID;

		var BreakByTutorNumberTextId = document.getElementById(BreakByTutorNumberText);
		
		if (BreakByTutorNumberTextId.classList.contains('breakOutOtherThanAttribute')===true){
		BreakByTutorNumberTextId.classList.remove("breakOutOtherThanAttribute");
	if (document.getElementById(TutorDataDivId).style.display == 'none' || showingstatus == 'firsttimemain' || showingstatus == 'z-a' || showingstatus == 'a-z' || showingstatus == 'asc' || showingstatus == 'desc') {
		document.getElementById(loadingImgId).style.display = 'block';
		// this is for sitewide
		if (scopeName == "site") {
			if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain') {
				//document.getElementById(loadingImgId).style.display = 'block';
				//processAndCloseBreakBoxNumberText(TutorDataDivId,loadingImgId);
				document.getElementById(loadingImgId).style.display = 'none';
				
			} else {
				new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbytutornumbertextsitewide&questionid=" + questionID + "&beginsurvey=" + beginSurvey + "&endsurvey=" + endSurvey + "&notselectedids=" + notSelectedIds + "&siteidlist=" + siteidList + "&programlist=" + programList + "&showingstatus=" + showingstatus + "&showtutorstudentall=" + showtutorstudentall), {
					onSuccess: function(returnHtml) {
						document.getElementById(loadingImgId).style.display = 'none';
						document.getElementById(clickLinkId).style.display = 'block';
						var studentdiv = "StudentDataDiv" + questionID;
						var tutorOnly = "TutorOnly" + questionID;
						var attributeDiv = "AttributeDataDiv" + questionID;
						var attributeSelectionDiv = "AttributeSelectionDiv" + questionID;
						Element.update(TutorDataDivId, returnHtml.responseText);
						if (jQuery('#' + attributeDiv).css('display') != 'none' && typeof(jQuery('#' + attributeDiv).css('display')) !== 'undefined') {
							jQuery('#' + attributeDiv).hide();
							jQuery('#' + attributeSelectionDiv).hide();
							if (showingstatus == 'firsttimemain') {
								document.getElementById(TutorDataDivId).style.display = 'block';
							}
						} else {
							jQuery('#' + attributeSelectionDiv).hide();
							if (showingstatus == 'firsttimemain')
								Effect.BlindDown(TutorDataDivId);
						}
					},
					onFailure: function() {
						alert('Oops...mistake on server');
					}
				});
			}
		}
		//this section is for program wide data display
		else if (scopeName == "program") {
			if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain') {
				//document.getElementById(loadingImgId).style.display = 'block';
				//processAndCloseBreakBoxNumberText(TutorDataDivId,loadingImgId);
				document.getElementById(loadingImgId).style.display = 'none';
				
			} else {
				new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbytutorprogramwidenumbertext&questionid=" + questionID + "&beginsurvey=" + beginSurvey + "&endsurvey=" + endSurvey + "&notselectedids=" + notSelectedIds + "&siteidlist=" + siteidList + "&programlist=" + programList + "&showingstatus=" + showingstatus + "&showtutorstudentall=" + showtutorstudentall), {
					onSuccess: function(returnHtml) {
						document.getElementById(loadingImgId).style.display = 'none';
						document.getElementById(clickLinkId).style.display = 'block';
						var studentdiv = "StudentDataDiv" + questionID;
						var tutorOnly = "TutorOnly" + questionID;
						var attributeDiv = "AttributeDataDiv" + questionID;
						var attributeSelectionDiv = "AttributeSelectionDiv" + questionID;
						Element.update(TutorDataDivId, returnHtml.responseText);
						if (jQuery('#' + attributeDiv).css('display') != 'none' && typeof(jQuery('#' + attributeDiv).css('display')) !== 'undefined') {
							jQuery('#' + attributeDiv).hide();
							jQuery('#' + attributeSelectionDiv).hide();
							if (showingstatus == 'firsttimemain') {
								document.getElementById(TutorDataDivId).style.display = 'block';
							}
						} else {
							jQuery('#' + attributeSelectionDiv).hide();
							if (showingstatus == 'firsttimemain')
								Effect.BlindDown(TutorDataDivId);
						}
					},
					onFailure: function() {
						alert('Oops...mistake on server');
					}
				});
			}
		}
	} else {
		document.getElementById(loadingImgId).style.display = 'block';
		processAndCloseBreakBoxNumberText(TutorDataDivId, loadingImgId);
		document.getElementById(loadingImgId).style.display = 'none';
	}
		}
	
}

function BreakByTutorNumberTextInner(scopeName, loadingImgId, TutorDataDivId, clickLinkId, questionID, beginSurvey, endSurvey, notSelectedIds, siteidList, programList, showingstatus, showtutorstudentall) {
	  
	if (document.getElementById(TutorDataDivId).style.display == 'none' || showingstatus == 'firsttimemain' || showingstatus == 'z-a' || showingstatus == 'a-z' || showingstatus == 'asc' || showingstatus == 'desc') {
		document.getElementById(loadingImgId).style.display = 'block';
		
		// this is for sitewide
		if (scopeName == "site") {
			if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain') {
				//document.getElementById(loadingImgId).style.display = 'block';
				//processAndCloseBreakBoxNumberText(TutorDataDivId,loadingImgId);
				document.getElementById(loadingImgId).style.display = 'none';
				
				
			} else {
				
				new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbytutornumbertextsitewide&questionid=" + questionID + "&beginsurvey=" + beginSurvey + "&endsurvey=" + endSurvey + "&notselectedids=" + notSelectedIds + "&siteidlist=" + siteidList + "&programlist=" + programList + "&showingstatus=" + showingstatus + "&showtutorstudentall=" + showtutorstudentall), {
					onSuccess: function(returnHtml) {
						document.getElementById(loadingImgId).style.display = 'none';
						document.getElementById(clickLinkId).style.display = 'block';
						var studentdiv = "StudentDataDiv" + questionID;
						var tutorOnly = "TutorOnly" + questionID;
						var attributeDiv = "AttributeDataDiv" + questionID;
						var attributeSelectionDiv = "AttributeSelectionDiv" + questionID;
						Element.update(TutorDataDivId, returnHtml.responseText);
						if (jQuery('#' + attributeDiv).css('display') != 'none' && typeof(jQuery('#' + attributeDiv).css('display')) !== 'undefined') {
							jQuery('#' + attributeDiv).hide();
							jQuery('#' + attributeSelectionDiv).hide();
							if (showingstatus == 'firsttimemain') {
								document.getElementById(TutorDataDivId).style.display = 'block';
							}
						} else {
							jQuery('#' + attributeSelectionDiv).hide();
							if (showingstatus == 'firsttimemain')
								Effect.BlindDown(TutorDataDivId);
						}
					},
					onFailure: function() {
						alert('Oops...mistake on server');
					}
				});
			  
			}
			
		}
		//this section is for program wide data display
		else if (scopeName == "program") {
			if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain') {
				//document.getElementById(loadingImgId).style.display = 'block';
				//processAndCloseBreakBoxNumberText(TutorDataDivId,loadingImgId);
				document.getElementById(loadingImgId).style.display = 'none';
				
				
			} else {
				new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbytutorprogramwidenumbertext&questionid=" + questionID + "&beginsurvey=" + beginSurvey + "&endsurvey=" + endSurvey + "&notselectedids=" + notSelectedIds + "&siteidlist=" + siteidList + "&programlist=" + programList + "&showingstatus=" + showingstatus + "&showtutorstudentall=" + showtutorstudentall), {
					onSuccess: function(returnHtml) {
						document.getElementById(loadingImgId).style.display = 'none';
						document.getElementById(clickLinkId).style.display = 'block';
						var studentdiv = "StudentDataDiv" + questionID;
						var tutorOnly = "TutorOnly" + questionID;
						var attributeDiv = "AttributeDataDiv" + questionID;
						var attributeSelectionDiv = "AttributeSelectionDiv" + questionID;
						Element.update(TutorDataDivId, returnHtml.responseText);
						if (jQuery('#' + attributeDiv).css('display') != 'none' && typeof(jQuery('#' + attributeDiv).css('display')) !== 'undefined') {
							jQuery('#' + attributeDiv).hide();
							jQuery('#' + attributeSelectionDiv).hide();
							if (showingstatus == 'firsttimemain') {
								document.getElementById(TutorDataDivId).style.display = 'block';
							}
						} else {
							jQuery('#' + attributeSelectionDiv).hide();
							if (showingstatus == 'firsttimemain')
								Effect.BlindDown(TutorDataDivId);
						}
					},
					onFailure: function() {
						alert('Oops...mistake on server');
					}
				});
			}
		}
	} else {
		document.getElementById(loadingImgId).style.display = 'block';
		processAndCloseBreakBoxNumberText(TutorDataDivId, loadingImgId);
		document.getElementById(loadingImgId).style.display = 'none';
	}
		
	
}
function BreakByTutorNumberText_volunteers(scopeName, loadingImgId, TutorDataDivId, clickLinkId, questionID, beginSurvey, endSurvey, notSelectedIds, siteidList, programList, showingstatus, showtutorstudentall,volunteeruserid) {
	if (document.getElementById(TutorDataDivId).style.display == 'none' || showingstatus == 'firsttimemain' || showingstatus == 'z-a' || showingstatus == 'a-z' || showingstatus == 'asc' || showingstatus == 'desc') {
		document.getElementById(loadingImgId).style.display = 'block';		
		if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain') {
			document.getElementById(loadingImgId).style.display = 'none';
		} else {
			new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbytutorprogramwidenumbertext&questionid=" + questionID + "&beginsurvey=" + beginSurvey + "&endsurvey=" + endSurvey + "&notselectedids=" + notSelectedIds + "&siteidlist=" + siteidList + "&programlist=" + programList + "&showingstatus=" + showingstatus + "&showtutorstudentall=" + showtutorstudentall+ "&volunteeruserid=" + volunteeruserid), {
				onSuccess: function(returnHtml) {
					document.getElementById(loadingImgId).style.display = 'none';
					document.getElementById(clickLinkId).style.display = 'block';
					var studentdiv = "StudentDataDiv" + questionID;
					var tutorOnly = "TutorOnly" + questionID;
					var attributeDiv = "AttributeDataDiv" + questionID;
					var attributeSelectionDiv = "AttributeSelectionDiv" + questionID;
					Element.update(TutorDataDivId, returnHtml.responseText);
					if (jQuery('#' + attributeDiv).css('display') != 'none' && typeof(jQuery('#' + attributeDiv).css('display')) !== 'undefined') {
						jQuery('#' + attributeDiv).hide();
						jQuery('#' + attributeSelectionDiv).hide();
						if (showingstatus == 'firsttimemain' || showingstatus == 'a-z') {
							document.getElementById(TutorDataDivId).style.display = 'block';
						}
					} else {
						jQuery('#' + attributeSelectionDiv).hide();
						if (showingstatus == 'firsttimemain')
							Effect.BlindDown(TutorDataDivId);
						else if(showingstatus == 'a-z'){
							if(jQuery('#' + TutorDataDivId).css('display') != 'none')
								document.getElementById(TutorDataDivId).style.display = 'block';
							else
								Effect.BlindDown(TutorDataDivId);
						}
					}
				},
				onFailure: function() {
					alert('Oops...mistake on server');
				}
			});
		}

	} else {
		document.getElementById(loadingImgId).style.display = 'block';
		processAndCloseBreakBoxNumberText(TutorDataDivId, loadingImgId);
		document.getElementById(loadingImgId).style.display = 'none';
	}
}

function processAndCloseBreakBoxNumberText(TutorDataDivId) {
	Effect.Fade(TutorDataDivId);
	//Effect.toggle(TutorDataDivId, 'slide');
	Effect.BlindUp(TutorDataDivId);
	var questionID = parseInt(TutorDataDivId.match(/[0-9]+/)[0], 10);
	var question1ID = parseInt(TutorDataDivId.match(/[0-9]+/)[0], 10);
	var BreakByTutorNumberText = "BreakByTutorNumberText_"+questionID;
	var BreakByTutorAssociationWideNumberText = "BreakByTutorAssociationWideNumberText_"+question1ID;

		var BreakByTutorNumberTextId = document.getElementById(BreakByTutorNumberText);
		var BreakByTutorAssociationWideNumberTextId = document.getElementById(BreakByTutorAssociationWideNumberText);
		if(BreakByTutorNumberTextId !== null)
	     BreakByTutorNumberTextId.classList.add("breakOutOtherThanAttribute");
	   if(BreakByTutorAssociationWideNumberTextId !== null)
	   BreakByTutorAssociationWideNumberTextId.classList.add("breakOutOtherThanAttribute");
		
		
	

		
         
}