$(document).ready(function () {
  /* go back function */
  $("#goBackBtn").click(function () {
    $("#authpage2").hide();
    $("#authpage1").show();
    $(".authenticator-fail-element").hide();
    $("#email_error2").css("display", "block");
    $("#error_msg").css("display", "none");
    $(".code-input").val("");
    $("#submitOtpBtn").prop("disabled", true);
    $('#auth1btn').prop("disabled", false);
  });
  /* go back function */
  /* page1 continue button click */
  $("#auth1btn").click(function () {
    $(this).prop("disabled", true);
    var selectedValue = $("input[name='verificationMethod']:checked").val();
    if (selectedValue == 1) {
      sendVerificationCode(1);
    } else if (selectedValue == 2) {
      if (userauthstr != "") {
        sendVerificationCode(2);
      } else {
        sendVerificationCode(3);
        // generateAuthstr();
      }
    }
  });
  /* page1 continue button click */

  $("#submitOtpBtn").click(function () {
    $(this).prop("disabled", true);
    $("#error_msg").css("display", "none");
    var methodtype = $("#methodtype").val();
    var mtype = $("#mtype").val();
    if (methodtype == "email") {
      $.ajax({
        url: "index.cfm?event=user.OTPVerification",
        type: "post",
        data: new FormData($("form#frm_verification")[0]),
        processData: false,
        contentType: false,
        datatype: "json",
        beforeSend: function () {
          showLoadingOverlay();
        },
        success: function (data) {
          hideLoadingOverlay();
          var response = JSON.parse(data);
          if (response.RESPONSE == "success") {
            rememberMeFun();
          
          } else if (response.RESPONSE == "expire") {
            otpVerificationFail(3, response.ATTEMPTCOUNT);
          } else {
            otpVerificationFail(1, response.ATTEMPTCOUNT);
          }
        },
        error: function () {
          $(this).prop("disabled", false);
          console.log("verification error");
        },
      });
    } else {
      if (mtype == 2) {
        var inputs = document.querySelectorAll(".code-input");
        var otp = Array.from(inputs)
          .map((input) => input.value)
          .join("");
        var keyvar = atob($("#authStr").val());
        var token = getToken(keyvar);
        if (otp == token) {
          rememberMeFun();
        } else {
          var attemptCount = $("#attemptcount").val();
          otpVerificationFail(2, parseInt(attemptCount) + 1);
        }
      } else if (mtype == 3) {
        $.ajax({
          url: "index.cfm?event=user.OTPVerification",
          type: "post",
          data: new FormData($("form#frm_verification")[0]),
          processData: false,
          contentType: false,
          datatype: "json",
          beforeSend: function () {
            showLoadingOverlay();
          },
          success: function (data) {
            hideLoadingOverlay();
            var response = JSON.parse(data);
            if (response.RESPONSE == "success") {
              $('#submitOtpBtn').prop("disabled", false);
              generateAuthstr();
            } else {
              otpVerificationFail(4, response.ATTEMPTCOUNT);
            }
          },
          error: function () {
            $(this).prop("disabled", false);
            console.log("verification error");
          },
        });
      }
    }
  });

  $("#resendcode").on("click", function(event) {
    event.preventDefault();
    var $this = $(this);
    var secondsLeft = 30;
    var originalText = $this.text();

    // Disable the link
    $this.addClass("disabled").css({"pointer-events": "none", "opacity": "0.5"});
    $this.text("Wait " + secondsLeft + "s to "+ originalText).attr("title", "Wait " + secondsLeft + " seconds");

    var timer = setInterval(function() {
        secondsLeft--;
        $this.text("Wait " + secondsLeft + "s to "+ originalText).attr("title", "Wait " + secondsLeft + " seconds");

        if (secondsLeft <= 0) {
            clearInterval(timer);
            $this.removeClass("disabled").css({"pointer-events": "auto", "opacity": "1"})
                 .text(originalText).attr("title", "Click to send code");
        }
    }, 1000);

    // Trick to refresh tooltip
    setTimeout(function() {
        $this.attr("title", "Wait " + secondsLeft + " seconds").blur().focus();
    }, 100);
});

});

function rememberMeFun() {
  if ($("#rememberthisdevice").is(":checked") == true) {
    var deviceId = generateUUID();
    var rememberMe = 1;
  } else {
    var deviceId = "";
    var rememberMe = 0;
  }
  $.ajax({
    url: "index.cfm?event=user.updateremembermefiled",
    type: "post",
    data: {
      programid,
      credentialId,
      usertype,
      deviceId,
      rememberMe,
    },
    datatype: "json",
    success: function (data) {
      if (data) {
        const eventURL = "index.cfm?event=user.mfaprocesslogin";
        window.location.href = eventURL; 
      }
    },
    error: function () {
      console.log("Error in Saving Device Id");
    },
  });
}

$(".code-input").on("input", function () {
  const currentIndex = $(".code-input").index(this) + 1;
  moveFocus(currentIndex);
});

$(".code-input").on("keydown", function (event) {
  if (event.key === "Backspace" && $(this).val() === "") {
    const prevInput = $(".code-input").eq($(".code-input").index(this) - 1);
    if (prevInput.length) {
      prevInput.focus();
    }
  }
});

$(".code-input").on("paste", function (event) {
  event.preventDefault();
  var pastedData = (
    event.originalEvent.clipboardData || window.clipboardData
  ).getData("text");

  // Remove all non-numeric characters
  pastedData = pastedData.replace(/\D/g, "");

  const $inputs = $(".code-input");

  // Fill inputs with sanitized OTP
  for (var i = 0; i < pastedData.length && i < $inputs.length; i++) {
    $inputs.eq(i).val(pastedData[i]);
  }

  // Move focus to the last filled input
  $inputs.eq(Math.min(pastedData.length, $inputs.length) - 1).focus();

  // Enable the submit button if all fields are filled
  const allFilled = $inputs
    .toArray()
    .every((input) => $(input).val().length === 1);
  $("#submitOtpBtn").prop("disabled", !allFilled);
});

function sendVerificationCode(mtype) {
  $("#error_msg").hide();
  $(".code-input").val("");
  if (mtype == 1) {
    var MethodType = "email";
  } else {
    var MethodType = "app";
  }

  $.ajax({
    url: "index.cfm?event=user.sendVolunteerStaffOTPMail",
    type: "post",
    datatype: "json",
    data: {
      programid,
      credentialId,
      FirstName: first_name,
      email: username,
      UserType: usertype,
      MethodType,
      mtype,
    },
    beforeSend: function () {
      showLoadingOverlay();
    },
    success: function (data) {
      var response = JSON.parse(data);
      if (response.SUCCESS) {
        hideLoadingOverlay();
        if (mtype == 1) {
          switch_page(
            mtype,
            response.DATA.LASTID,
            response.DATA.ATTEMPTCOUNT,
            MethodType,
            ""
          );
        } else if (mtype == 2) {
          switch_page(
            mtype,
            response.DATA.LASTID,
            response.DATA.ATTEMPTCOUNT,
            MethodType,
            ""
          );
        } else if (mtype == 3) {
          switch_page(
            mtype,
            response.DATA.LASTID,
            response.DATA.ATTEMPTCOUNT,
            MethodType,
            ""
          );
        }
      } else {
        // error message
        console.log(response.MESSAGE);
      }
    },
    error: function () {
      console.log("Error In Sending Mail");
    },
  });
}

function switch_page(ftype, attemptid, attemptcount, methodtype, authstr) {
  $("#authpage1").hide();
  $("#authpage2").show();
  if (ftype == 1) {
    $("#head2").text("Use Your E-mail");
    $(".email-element").show();
    $(".authenticator-fail-element").hide();
    $(".auth-step-1").hide();
    $(".auth-step-2").hide();
    $("#mtype").val(ftype);
    $(".remember-div").show();
  } else if (ftype == 2) {
    $("#head2").text("Use an Authenticator App");
    $(".authenticator-fail-element").show();
    $(".auth-step-1").hide();
    $(".auth-step-2").hide();
    $(".email-element").hide();
    $("#mtype").val(ftype);
    $(".remember-div").show();
  } else if (ftype == 3) {
    $("#head2").text("Use an Authenticator App");
    $(".auth-step-1").show();
    $(".auth-step-2").hide();
    $(".email-element").hide();
    $("#email_error2").css("display", "none");
    $(".authenticator-fail-element").hide();
    $("#mtype").val(ftype);
    $(".remember-div").hide();
  } else if (ftype == 4) {
    $("#head2").text("Use an Authenticator App");
    $(".auth-step-1").hide();
    $(".auth-step-2").show();
    $(".email-element").hide();
    $(".authenticator-fail-element").hide();
    $("#mtype").val(2);
    $("#authStr").val(authstr);
    $(".remember-div").show();
    $(".code-input").val("");
    $("#submitOtpBtn").prop("disabled", true);
  }
  $("#attemptid").val(attemptid);
  if (attemptcount != null) {
    $("#attemptcount").val(attemptcount);
  }
  $("#methodtype").val(methodtype);
}

function generateAuthstr() {
  const credentialId = document.getElementById("credentialId").value;
  const issuer = document.getElementById("issuer").value;
  const sceretStrCode = base32
    .encode(credentialId +username)
    .split("=")[0];
  const otpauthUrl = `otpauth://totp/${encodeURIComponent(
    username
  )}?secret=${sceretStrCode}&issuer=${encodeURIComponent(issuer)}`;

  const qr = new QRious({
    value: otpauthUrl, // Data for the QR code
    size: 300, // QR code size
  });

  // Get the generated QR code as a data URL
  const qrDataUrl = qr.toDataURL();

  // Assign the QR code to the <img> and the <a>
  const qrImage = document.getElementById("iqrCode");
  const qrLink = document.getElementById("aqrCode");

  qrImage.src = qrDataUrl;
  qrLink.href = qrDataUrl;

  $.ajax({
    url: "index.cfm?event=user.updateAuthenticationString",
    type: "post",
    data: {programid,
      credentialId,
      usertype,
      authStr: btoa(sceretStrCode),
    },
    datatype: "json",
    beforeSend: function () {
      showLoadingOverlay();
    },
    success: function (data) {
      var response = JSON.parse(data);
      if (response.RESPONSE == "success") {
        hideLoadingOverlay();
        switch_page(4, response.DATA.LASTID, 0, "app", btoa(sceretStrCode));
      } else {
        console.log(response.MESSAGE);
      }
    },
    error: function () {
      console.log("Error in Generating String");
    },
  });
}

function otpVerificationFail(type, AttemptCount) {
  var AttemptID = $("#attemptid").val();
  var AttemptStatus = 0;
  $('#submitOtpBtn').prop("disabled", false);
  if (AttemptCount < 5) {
    $.ajax({
      url: "index.cfm?event=user.updateFailedAttemptCount",
      type: "post",
      datatype: "json",
      data: { AttemptCount, AttemptID, AttemptStatus },
      beforeSend: function () {
        showLoadingOverlay();
      },
      success: function (data) {
        var response = JSON.parse(data);
        if (response.RESPONSE == "success") {
          hideLoadingOverlay();
          $("#error_msg").css("display", "block");
          if (type == 3) {
            $("#error-worngdiv").css("display", "none");
            $("#error-expirediv").css("display", "block");
          } else {
            if (type == 2) {
              $(".authenticator-fail-element").show();
              $(".auth-step-1").hide();
              $(".auth-step-2").hide();
              $("#email_error2").css("display", "none");
            } else if (type == 4) {
              $(".authenticator-fail-element").hide();
              $(".auth-step-1").show();
              $(".auth-step-2").hide();
              $("#email_error2").css("display", "none");
            }
          }

          if (AttemptCount < 4) {
            $("#AttemptDisplay").text(
              5 - parseInt(AttemptCount) + " attempts remain."
            );
          } else {
            $("#AttemptDisplay").text(
              "This is your last try before a temporary account lock-out."
            );
          }
          $("#attemptcount").val(AttemptCount);
          $(".code-input").val("");
          $("#submitOtpBtn").prop("disabled", true);
        } else {
          console.log(response.MESSAGE);
        }
      },
      error: function () {
        console.log("Error in Locking account");
      },
    });
  } else {
    $.ajax({
      url: "index.cfm?event=user.updateAuthFailedStatus",
      type: "post",
      datatype: "json",
      data: { programid,
        credentialId,
        email:username,
        AttemptID },
      beforeSend: function () {
        showLoadingOverlay();
      },
      success: function (data) {
        var response = JSON.parse(data);
        if (response.RESPONSE == "success") {
          hideLoadingOverlay();
          $("#authpage2").hide();
          $("#authpage1").hide();
          $("#authFailLock3").show();
        } else {
          console.log(response.MESSAGE);
        }
      },
      error: function () {
        console.log("Error in Locking account");
      },
    });
  }
}

function moveFocus(currentIndex) {
  const $inputs = $(".code-input");
  const $currentInput = $inputs.eq(currentIndex - 1);
  const $nextInput = $inputs.eq(currentIndex);
  // Automatically focus on the next input if the current one is filled
  if ($currentInput.val().length === 1 && $nextInput.length) {
    $nextInput.focus();
  }
  // Enable the submit button if all fields are filled
  const allFilled = $inputs.toArray().every((input) => $(input).val().length === 1);
  $("#submitOtpBtn").prop("disabled", !allFilled);

  // If all fields are filled, listen for the Enter key press on the last input
  if (allFilled) {
    $inputs.last().on("keydown", function (event) {
      if (event.key === "Enter") {
        event.preventDefault(); // Prevent default form submission
        $("#submitOtpBtn").click();
      }
    });
  }
}

function getToken(key, options) {
  options = options || {};
  let epoch, time, shaObj, hmac, offset, otp;
  options.period = options.period || 30;
  options.algorithm = options.algorithm || "SHA-1";
  options.digits = options.digits || 6;
  options.timestamp = options.timestamp || Date.now();
  key = base32tohex(key);
  epoch = Math.floor(options.timestamp / 1000.0);
  time = leftpad(dec2hex(Math.floor(epoch / options.period)), 16, "0");
  shaObj = new jsSHA(options.algorithm, "HEX");
  shaObj.setHMACKey(key, "HEX");
  shaObj.update(time);
  hmac = shaObj.getHMAC("HEX");
  offset = hex2dec(hmac.substring(hmac.length - 1));
  otp = (hex2dec(hmac.substr(offset * 2, 8)) & hex2dec("7fffffff")) + "";
  otp = otp.substr(Math.max(otp.length - options.digits, 0), options.digits);
  return otp;
}

function hex2dec(s) {
  return parseInt(s, 16);
}

function dec2hex(s) {
  return (s < 15.5 ? "0" : "") + Math.round(s).toString(16);
}

function base32tohex(base32Encoded) {
  let base32chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567",
    bits = "",
    hex = "";
  base32Encoded = base32Encoded.replace(/=+$/, "");
  for (let i = 0; i < base32Encoded.length; i++) {
    let val = base32chars.indexOf(base32Encoded.charAt(i).toUpperCase());
    if (val === -1) throw new Error("Invalid base32 character in key");
    bits += leftpad(val.toString(2), 5, "0");
  }

  for (let i = 0; i + 8 <= bits.length; i += 8) {
    let chunk = bits.substr(i, 8);
    hex = hex + leftpad(parseInt(chunk, 2).toString(16), 2, "0");
  }
  return hex;
}

function leftpad(str, len, pad) {
  if (len + 1 >= str.length) {
    str = Array(len + 1 - str.length).join(pad) + str;
  }
  return str;
}

function isNumber(evt) {
  evt = evt ? evt : window.event;
  var charCode = evt.which ? evt.which : evt.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
  }
  return true;
}

function showLoadingOverlay() {
  $("#ajaxFilterLoading .bg").height("100%");
  $("#ajaxFilterLoading").fadeIn(300);
  $("#ajaxFilterLoading").attr("tabindex", -1).focus();
}

function hideLoadingOverlay() {
  $("#ajaxFilterLoading .bg").height("100%");
  $("#ajaxFilterLoading").fadeOut(300);
}

function generateUUID() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
    const r = (Math.random() * 16) | 0,
      v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

function openFullScreen(event) {
  event.preventDefault();
  const imageURL = event.currentTarget.href;
  const modal = document.createElement("div");
  modal.style.position = "fixed";
  modal.style.top = "0";
  modal.style.left = "0";
  modal.style.width = "100%";
  modal.style.height = "100%";
  modal.style.backgroundColor = "rgba(0, 0, 0, 0.8)";
  modal.style.display = "flex";
  modal.style.alignItems = "center";
  modal.style.justifyContent = "center";
  modal.style.zIndex = "1000";

  const img = document.createElement("img");
  img.src = imageURL;
  img.style.maxWidth = "100%";
  img.style.maxHeight = "100%";

  const closeButton = document.createElement("span");
  closeButton.innerHTML = "&times;";
  closeButton.style.position = "absolute";
  closeButton.style.top = "10px";
  closeButton.style.right = "20px";
  closeButton.style.fontSize = "30px";
  closeButton.style.color = "#fff";
  closeButton.style.cursor = "pointer";

  closeButton.addEventListener("click", () => document.body.removeChild(modal));

  modal.appendChild(img);
  modal.appendChild(closeButton);
  document.body.appendChild(modal);
}
