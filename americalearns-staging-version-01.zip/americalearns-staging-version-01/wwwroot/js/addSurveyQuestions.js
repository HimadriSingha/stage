$j = jQuery.noConflict();
var ajaxSynch,
    ALRQid = $j('#ALRQid').val(),
	infiniteScrollState = false,
	editor = {};

var myScrollHandler = function () {
    if ($j(window).scrollTop() + $j(window).height() > $j(document).height() - 10) {
        if (infiniteScrollState) {
            infiniteScrollState = false;
            infiniteScroll();
        }
    }
}

$j(document).ready(function(){
	$j('.optionTable').hide();
	$j('.QuestionListContainer').hide();
});
	/*---custom scroll fuction----*/
function customScrollProcedure(_Object)
{
	if(_Object == 'getQuestionsForForm'){
	$j(".questionType_3dMatrix_Container").each(function(){ 
			$j(this).find('.questionType_3dMatrix').prev().children().css("width",$j(this).find('.questionType_3dMatrix table').innerWidth()+'px');
    });
	}
	else if(_Object == 'getQuestions'){
	$j(".questionType_3dMatrix_Container").each(function(){ 
			$j(this).find('.matrixContainer').prev().children().css("width",$j(this).find('.matrixContainer table').innerWidth()+'px');
    });
	}
  else{
		if($j(_Object).attr('class') == 'customScrollTop')
		 {
        $j(_Object).next().scrollLeft($j(_Object).scrollLeft());
			}
    else if($j(_Object).attr('class') == 'questionType_3dMatrix' ||$j(_Object).attr('class') == 'matrixContainer')
		{
        $j(_Object).prev().scrollLeft($j(_Object).scrollLeft());
    }
	}		
}
function selectAllNoneLinkChange(inputName, groupSequence){
   //Select link besides the qustion group in survey page
    var $inputItems = $j11("#surveyFormQuestionToInclude input.questionsInEachGroup:checkbox[name='" + inputName + "']:visible"),
        totalLength = $inputItems.length,
        totalCheckedLength = $inputItems.filter(":checked").length,
        $selectLink = $j11("#surveyFormQuestionToInclude #SelectAllSubQuestions_" + groupSequence);

    if(totalLength == totalCheckedLength)
        $selectLink.removeClass('SelectAll SelectNone').addClass('SelectNone').text('Deselect Entire Question');
    else
        $selectLink.removeClass('SelectAll SelectNone').addClass('SelectAll').text('Select Entire Question');
    selectAllNoneStatus(false);
}

function selectAllNoneStatus(subFunctionCall) {
    //Function used to change Main Select Text depending on the checked values in create survey form
    $j('span.selectAllQuestion').each(function () {
        var $this = $j(this),
            $selector = $this.parent().nextUntil('div.QuestionListFolderDiv').find('input.questionsInEachGroup:visible'),
            totalCheckbox = $selector.length,
            totalCheckedCheckbox = $selector.filter(':checked').length;
	
        if (totalCheckbox === totalCheckedCheckbox && $j("#selectedCategoryId").val() !== $j('#ALRQid').val()) {
            $this.html('(<a href="javascript:void(0);">Deselect All Questions</a>)');	
        } else if ($j("#selectedCategoryId").val() !== $j('#ALRQid').val()) {
            $this.html('(<a href="javascript:void(0);">Select All Questions</a>)');
        }
        
        if (subFunctionCall) {
            $selector.each(function () {
                var $this = $j(this),
                    inputName = $this.attr('name'),
                    groupSequence = $j11.trim($this.attr('rel'));
                selectAllNoneLinkChange(inputName, groupSequence);
            });
        }
    });
}

function changeStatusOfButton(viewID) {
    //Statements used to manipulate actions in load/save window
    if ($j(".lsvViewButton input[type='button']").is(':disabled')) {
        $j(".lsvViewButton input[type='button']").removeAttr('disabled');
    }
    if (!($j(".lsvSetDefaultButton input[type='button']").is(':disabled')) && $j("#defaultViewID").val() === viewID) {
        $j(".lsvSetDefaultButton input[type='button']").prop('disabled', true);
    } else {
        $j(".lsvSetDefaultButton input[type='button']").removeAttr('disabled');
    }
}

function categoryColorChange() {
	var elementID =	"#" + $j("#selectedCategoryId").val();
	//$j(".searchContent").css("backgroundColor", "#ebf6ff");
    if (!$j('div#toggleSelectedButton').hasClass('showAllQuestions')) {
	   //$j(elementID).parent(".searchContent").css("backgroundColor", "#D1EAFE");
    }
}

//function to retrieve category list via AJAX
function getCategoryListing(option) {
    var path = '',
        categoryPanelBlock = $j('.qnCategoryList'),
        showQuestionValue = $j('#questionListFilter').val(),
        valueForBreakout = $j("input[name=breakOut]:checked").val();
    if (option === '0' || valueForBreakout === '2') {
        if (valueForBreakout === '1' || valueForBreakout === undefined) {
            path = 'index.cfm?event=questions.showAllCategoryListFilter';
        } else if (valueForBreakout === '2') {
            path = 'index.cfm?event=questions.showAllSurveyListFilter';
			$j('#qnCategoryList').hide();$j('#surveySelectionList').show();$j('#questionCategoryFilter').hide(); $j('#optionCellResponse').show(); $j('#searchCategory').attr("placeholder", "Search by Form Name");
        }
    } else if (option === '1') {
        path = 'index.cfm?event=questions.showMyCategoryFilter';
    } else if (option === '2') {
        path = 'index.cfm?event=questions.getAmericaLearnsCategoryListQuestions';
    } else if (option === '3') {
        path = 'index.cfm?event=questions.getRecentlyUsedCategory';
    } else if (option === '4') {
        path = 'index.cfm?event=questions.getFrequentlyUsedCategory';
    } else if (option === '5') {
        path = 'index.cfm?event=questions.showSuperUmbrellaCategories';
    }
    
    categoryPanelBlock.empty();
	$j.ajax({
        url: path,
        type: "GET",
        data: {
            categoryOption: option,
            questionStatus: showQuestionValue
        },
        success: function (data) {
			categoryPanelBlock.append(data);
			categoryColorChange();//category Colour Change  
			
			//Set GroupSequence in hidden field on page load
			var groupSequenceList = $j(".qnCategoryContent#" + $j('#selectedCategoryId').val()).attr("rel");
			$j("#allQuestionIds").val(groupSequenceList);
        }
    });
}

function loadOptionValues() {
    //Select the category dropdown option
    $j("#questionCategoryFilter input[type='radio'][name='questionCategoryFilter']").each(function () {
        var $this = $j(this);
        if ($this.val() === $j('#categoryFilter').val()) {
            $j('.niceselect.questionCategoryFilter .top').text($this.attr('data-text'));
            $this.attr("checked", "checked");
            $this.parent().addClass("active");
        } else {
            $this.attr("checked", "");
            $this.parent().removeClass("active");
        }
    });
    getCategoryListing($j('#categoryFilter').val());
    
    //Set advanced option state
    if ($j('#advancedOptionPanelState').val() === '1') {
        if ($j('.panel_top').is(':hidden')) {
            $j('.panel_top').slideDown('1000');
            $j('.panel_bottom').html('<img src="../images/icons/hide advanced options.png" alt="hide arrow" /><span>&nbsp; hide options</span>');
        }
    } else if ($j('#advancedOptionPanelState').val() === '0') {
        if ($j('.panel_top').is(':visible')) {
            $j('.panel_top').slideUp('1000');
            $j('.panel_bottom').html('<img src="../images/icons/show advanced options.png" alt="show arrow" /><span>&nbsp; more options</span>');
        }
    }
    
    //Set active, archived or both state
    $j("#showQuestionListFilter input[type='radio'][name='questionTypes']").each(function () {
        var $this = $j(this);
        if ($this.val() === $j('#questionListFilter').val()) {
            $j('.niceselect.questionTypes .top').text($this.attr('data-text'));
            $this.attr("checked", "checked");
            $this.parent().addClass("active");
        } else {
            $this.attr("checked", "");
            $this.parent().removeClass("active");
        }
    });
    
    //Set sort by filter in options bar
    $j("#questionFilterDropdown input[type='radio'][name='questionFilterSelection']").each(function () {
        var $this = $j(this);
        if ($this.val() === $j('#sortByFilterDropdown').val()) {
            $j('.niceselect.questionFilterSelection .top').text($this.attr('data-text'));
            $this.attr("checked", "checked");
            $this.parent().addClass("active");
        } else {
            $this.attr("checked", "");
            $this.parent().removeClass("active");
        }
    });
    
    //Set Date Filter options
    var filterOption = '',
        filterStartDate = '',
        filterEndDate = '',
        filterResult = '',
		months = [ "January", "February", "March", "April", "May", "June",
               "July", "August", "September", "October", "November", "December" ],
        startDate = '',
        endDate = '',
        tagValues = [],
        tempResult;
    
    if ($j('#dateFilter').val() !== '0') {
        filterResult = $j('#dateFilter').val().split('::');
        filterOption = filterResult[0];
        filterStartDate = filterResult[1].split('-');
        filterEndDate = filterResult[2].split('-');
   
        $j('.DateRadInput').each(function (index, $this) {
            if (filterOption === index) {
                $j($this).attr('checked', 'checked');
            }
        });

        startDate = months[Number(filterStartDate[1] - 1)] + ' ' + filterStartDate[2] + ', ' + filterStartDate[0];
        endDate = months[Number(filterEndDate[1] - 1)] + ' ' + filterEndDate[2] + ', ' + filterEndDate[0];
        $j("#calendarDataFieldStartingDate").text(startDate);
        $j("#calendarDataFieldEndDate").text(endDate);
        $j("#optionCellDateSelectDataField").val($j('.DateRadInput:checked').attr("rel") + ': ' + startDate + ' - '  + endDate);
    } else {
        $j("#optionCellDateSelectDataField").val('Filter by Date Range');
    }

    //Set values for created by filter
    if ($j('#createdByFilter').val() !== '0' && $j('#createdByFilter').val() !== 'undefined') {
        var processedcbResponse = $j('#createdByFilter').val().replace(/, _/, ', ').replace(/^_/,'');
        $j('#createdByResponse').text(processedcbResponse);
    } else {
        $j('#createdByResponse').text('Everyone');
    }
    
    //Set values for filter by tag
    if ($j('#tagFilter').val() !== '0') {
        tagValues = $j('#tagFilter').val().split(':::');
        $j('#filterTagsIDs').val(tagValues[0]);
        $j('#filterByTagResponse').html(tagValues[1].split(',').join(', '));
    } else {
        $j('#filterByTagResponse').html('None');
    }
    
    //Set values for table properties
    if ($j('#tablePropertiesFilter').val() !== '0') {
        tempResult = '<li>' + $j('#tablePropertiesFilter').val().split(',').join('</li><li>') + '</li>';
        $j('#tablePropResponse').html(tempResult);
    } else {
        tempResult = '<li> None </li>';
        $j('#tablePropResponse').html(tempResult);
    }
}

/*Search question category LAJIN 01*/
function searchQuestionCategory(query) {
	$j(".searchContent").each(function () {
		var $cur = $j(this);
		if ($cur.text().toLowerCase().indexOf(query.toLowerCase()) === -1) {
			$cur.hide();
		} else {
			$cur.show();
		}
	});
    if ($j('.searchContent').length === $j('.searchContent:not(:visible)').length) {
        $j('#searchContentDisplayMessage').show();
    } else {
        $j('#searchContentDisplayMessage').hide();
    }
}

function destroyCreatedByWindow() {
	ColdFusion.Window.destroy('CreatedByWindow', true);
}

function destroyTablePropertiesWindow() {
	ColdFusion.Window.destroy('TablePropertiesWindow', true);
}

/*Advanced Option Panel: Start */
function showCreatedByWindow(event) {
    var flag = 0,
        theWidth = 400,
        optionValue = $j('#createdByFilter').val();
    if (optionValue.split(',').length === 4 || optionValue === '4' || optionValue === '0') {
        flag = 1;
    }
    ColdFusion.Window.create("CreatedByWindow", "Created By:", "index.cfm?event=questions.createdbywindow&a=" + optionValue + "&b=" + flag, {
        modal: true,
        width: theWidth,
        height: 250,
        center: true,
        draggable: true,
        x: event.pageX - 250,
        y: event.pageY + 20
    });
    document.getElementById(ColdFusion.Window.getWindowObject("CreatedByWindow").header.id).className = "windowHdr";
	ColdFusion.Window.onHide("CreatedByWindow", destroyCreatedByWindow);
}

function showTablePropertiesWindow(event) {
    var	flag = 0,
        theWidth = 230,
        optionValue = $j('#tablePropertiesFilter').val();
    if (optionValue.split(',').length === 9) {
        flag = 1;
    }
    ColdFusion.Window.create("TablePropertiesWindow", "", "index.cfm?event=questions.tablepropertieswindow&a=" + optionValue + "&b=" + flag, {
        modal: true,
        width: theWidth,
        height: 340,
        center: true,
        draggable: true,
        initshow: true,
        x: event.pageX - 200,
        y: event.pageY + 20
    });
    document.getElementById(ColdFusion.Window.getWindowObject("TablePropertiesWindow").header.id).className = "windowHdr";
	ColdFusion.Window.onHide("TablePropertiesWindow", destroyTablePropertiesWindow);
}

function getCheckedOptions(layoutIDName) {
    var itemsArray = [];
    if (layoutIDName === 'createdByLayout') {
        itemsArray = $j('#createdByFilter').val().split(',');
    } else if (layoutIDName === 'tablePropLayout') {
        itemsArray = $j('#tablePropertiesFilter').val().split(',');
    }
    return itemsArray;
}

function checkAllChecked(layoutID) {
    var activeTab = '',
        flag = 0,
        remClassName = '',
        selectAllChecked = $j('#' + layoutID + ' #selectAll').text();
    if (layoutID !== 'contentLayout') {
        remClassName = ".all";
    } else {
        activeTab = $j(".tabs li.active a").attr('href');
        remClassName = activeTab + ' .all';
    }

    $j('#' + layoutID + ' ' + remClassName).each(function () {
        if (!$j(this).is(":checked")) {
            flag = 1;
			return false;
        }
    });
    

    if (flag === 0 && $j.trim(selectAllChecked) !== "Select None") {
        $j('#' + layoutID + ' #selectAll').text('Select None');
    } else {
        $j('#' + layoutID + ' #selectAll').text('Select All');
    }
}
/*Advanced Option Panel: End */

function displayTablePropertySelected() {
    if (getCheckedOptions('tablePropLayout').length) {
        var itemsArray = getCheckedOptions('tablePropLayout'),
            tpLoadingImage = $j(".tablePropertiesLoading"),
            tpContainer = $j('.questionListPropertyContainer'),
            tpTagPresent = $j.inArray("Tags", itemsArray),
            tpDCPresent = $j.inArray("Date Created", itemsArray),
            tpDLUPresent = $j.inArray("Date Last Used", itemsArray),
            tpNLSUPresent = $j.inArray("Number of Launched Surveys Used In", itemsArray),
            tpNRPresent = $j.inArray("Number of Responses", itemsArray),
            tpT1APresent = $j.inArray("Type 1 Associations", itemsArray),
            tpT3APresent = $j.inArray("Type 3 Associations", itemsArray),
            tpSLTPresent = $j.inArray("Sites Linked To", itemsArray),
            tpLMBPresent = $j.inArray("Last Modified By", itemsArray);


        tpLoadingImage.show();
        tpContainer.addClass('blockview');

        (tpTagPresent !== -1) ? $j('.questionListTablePropertyContainer.tpTag').removeClass('blockview') : $j('.questionListTablePropertyContainer.tpTag').addClass('blockview');
        (tpDCPresent !== -1) ? $j('.questionListTablePropertyContainer.tpDC').removeClass('blockview') : $j('.questionListTablePropertyContainer.tpDC').addClass('blockview');
        (tpDLUPresent !== -1) ? $j('.questionListTablePropertyContainer.tpDLU').removeClass('blockview') : $j('.questionListTablePropertyContainer.tpDLU').addClass('blockview');
        (tpNLSUPresent !== -1) ? $j('.questionListTablePropertyContainer.tpNLSU').removeClass('blockview') : $j('.questionListTablePropertyContainer.tpNLSU').addClass('blockview');
        (tpNRPresent !== -1) ? $j('.questionListTablePropertyContainer.tpNR').removeClass('blockview') : $j('.questionListTablePropertyContainer.tpNR').addClass('blockview');
        (tpT1APresent !== -1) ? $j('.questionListTablePropertyContainer.tpT1A').removeClass('blockview') : $j('.questionListTablePropertyContainer.tpT1A').addClass('blockview');
        (tpT3APresent !== -1) ? $j('.questionListTablePropertyContainer.tpT3A').removeClass('blockview') : $j('.questionListTablePropertyContainer.tpT3A').addClass('blockview');
        (tpSLTPresent !== -1) ? $j('.questionListTablePropertyContainer.tpSLT').removeClass('blockview') : $j('.questionListTablePropertyContainer.tpSLT').addClass('blockview');
        (tpLMBPresent !== -1) ? $j('.questionListTablePropertyContainer.tpLMB').removeClass('blockview') : $j('.questionListTablePropertyContainer.tpLMB').addClass('blockview');

        tpContainer.removeClass('blockview');
        tpLoadingImage.hide();
    }
}

/*Infinite Scroll Function LAJIN 01*/
function infiniteScroll() {
    var path = "index.cfm?event=questions.getQuestions",
        questionList = $j("#selectedQuestionList").val(),
        listLength = questionList.split(',').length,
        questionGSList = questionList,
        categoryIdfk = $j("#selectedCategoryId").val(),
        i = 0,
        j = 0,
        questionArray = [],
        questionLimit = 25,
        newListToBeLoadedLater = [],
        newListToBeLoadedNow = [];
	if (!$isBrowseQuestion) {
		path = "index.cfm?event=" + $questionDestinationEvent;
	}
    
	if (ajaxSynch && ajaxSynch.readystate !== 4) {
		ajaxSynch.abort();
	}
    if (listLength >= 1 && questionList !== '') {
        $j("#loadingImage").show();
        //$j.scrollLock( true );
        if (listLength > questionLimit) {
            questionArray = questionList.split(',');
            for (i = questionLimit, j = 0; i < listLength; i++, j++) {
                newListToBeLoadedLater[j] = questionArray[i];
            }
            for (i = 0, j = 0; i < questionLimit; i++, j++) {
                newListToBeLoadedNow[j] = questionArray[i];
            }
            questionGSList = newListToBeLoadedNow.toString();
            $j("input[type='hidden'][name='selectedQuestionList']").val(newListToBeLoadedLater.toString());
        } else {
            $j("input[type='hidden'][name='selectedQuestionList']").val('');
        }
        if (questionGSList !== '0') {
			ajaxSynch = $j.ajax({
				url: path,
				type: "POST",
				data: {
					questionIdsList: questionGSList,
					categoryId: categoryIdfk,
					selectedForForm: (typeof $selectedQuestionIdArray !== 'undefined' && $selectedQuestionIdArray instanceof Array) ? $selectedQuestionIdArray.join(',') : '',
                    selectedQuestionFlag: ($j('div#toggleSelectedButton').hasClass('showAllQuestions'))
				},
				success: function (data) {
					$j("#loadingImage").hide();
					//$j("#questionCategoryNameContainer").show();
					$j("#individualQuestions").append(data);
					if (questionGSList !== '0') {
						displayTablePropertySelected();
					}
					if ($j('#bulkEditSelect').is(":visible")) {
						$j('.QuestionDataCheckBox input').show();
					}
					$j.scrollLock(false);
				},
				error: function () {
					$j.scrollLock(false);
				},
				complete: function () {
                    if (!$isBrowseQuestion) {
                        if ($j("#selectedCategoryId").val() !== ALRQid) {
                            selectAllNoneStatus(true);
                        } else {
                            $j('span.selectAllQuestion').empty();
                        }
                    }
					infiniteScrollState = true;
				}
			});
        }
    }
}
/*Locking scroll LAJIN 01*/
$j.scrollLock = (function scrollLockClosure() {
    'use strict';

    var $jhtml      = $j('html'),
        // State: unlocked by default
        locked     = false,
        // State: scroll to revert to
        prevScroll = {
            scrollLeft : $j(window).scrollLeft(),
            scrollTop  : $j(window).scrollTop()
        },
        // State: styles to revert to
        prevStyles = {},
        lockStyles = {
            'overflow-y' : 'scroll',
            'position'   : 'fixed',
            'width'      : '100%'
        };

    // Instantiate cache in case someone tries to unlock before locking
    saveStyles();

    // Save context's inline styles in cache
    function saveStyles() {
        var styleAttr = $jhtml.attr('style'),
            styleStrs = [],
            styleHash = {};

        if (!styleAttr) {
            return;
        }

        styleStrs = styleAttr.split(/;\s/);

        $j.each(styleStrs, function serializeStyleProp(styleString) {
            if (!styleString) {
                return;
            }

            var keyValue = styleString.split(/\s:\s/);

            if (keyValue.length < 2) {
                return;
            }

            styleHash[keyValue[0]] = keyValue[1];
        });

        $j.extend(prevStyles, styleHash);
    }

    function lock() {
        var appliedLock = {};

        // Duplicate execution will break DOM statefulness
        if (locked) {
            return;
        }

        // Save scroll state...
        prevScroll = {
            scrollLeft: $j(window).scrollLeft(),
            scrollTop : $j(window).scrollTop()
        };

        // ...and styles
        saveStyles();

        // Compose our applied CSS
        $j.extend(appliedLock, lockStyles, {
            // And apply scroll state as styles
            'left': -prevScroll.scrollLeft + 'px',
            'top': -prevScroll.scrollTop  + 'px'
        });

        // Then lock styles...
        $jhtml.css(appliedLock);

        // ...and scroll state
        $j(window)
            .scrollLeft(0)
            .scrollTop(0);

        locked = true;
    }

    function unlock() {
        // Duplicate execution will break DOM statefulness
        if (!locked) {
            return;
        }

        // Revert styles
        $jhtml.attr('style', $j('<x>').css(prevStyles).attr('style') || '');

        // Revert scroll values
        $j(window)
            .scrollLeft(prevScroll.scrollLeft)
            .scrollTop(prevScroll.scrollTop);

        locked = false;
    }

    return function scrollLock(on) {
        // If an argument is passed, lock or unlock depending on truthiness
        if (arguments.length) {
            if (on) {
                lock();
            } else {
                unlock();
            }
        } else {
            if (locked) {
                unlock();
            } else {
                lock();
            }
        }
    };
}());

/*Function for loading search result LAJIN 01*/
function loadSearchResult(state) {
	$j("#individualQuestions").empty();
    $j('span.selectAllQuestion').empty();
    $j("#loadingImage").show();
	var searchresult = $j("#selectedQuestionList").val(),
		isSurveyBreakout = ($isBrowseQuestion) ? 1 : $j("input[name=breakOut]:checked").val(),
		categoryIdfk = (isSurveyBreakout == 2) ? $j("#selectedSurveyId").val() : $j("#selectedCategoryId").val(),
        questionArray = [],
        questionGSList = searchresult,
        questionIdsLoadedNow = 0,
        questionLimit = 25,
        i = 0,
        j = 0,
        newListToBeLoadedLater = [],
        newListToBeLoadedNow = [],
        listLength = questionGSList.split(',').length,
        path = "index.cfm?event=" + $questionDestinationEvent;
	if (listLength > questionLimit) {
        questionArray = questionGSList.split(',');
        for (i = questionLimit, j = 0; i < listLength; i++, j++) {
            newListToBeLoadedLater[j] = questionArray[i];
        }
        for (i = 0, j = 0; i < questionLimit; i++, j++) {
            newListToBeLoadedNow[j] = questionArray[i];
        }
        questionGSList = newListToBeLoadedNow.toString();
    }
	$j("input[type='hidden'][name='selectedQuestionList']").val(newListToBeLoadedLater.toString());
    if (ajaxSynch && ajaxSynch.readystate !== 4) {
		ajaxSynch.abort();
	}
	//all question related changes
	if(($j.inArray("2", $selectedQuestionIdArray) !== -1)){
		if (questionGSList.indexOf('0000') == -1) {
			questionGSList='0000,'+questionGSList;
		}
	}
	//all question related changes
    if (questionGSList !== '0') {
        ajaxSynch = $j.ajax({
            url: path,
            type: "POST",
            data: {
                questionIdsList: questionGSList,
                categoryId: categoryIdfk,
                isSurveyBreakout: isSurveyBreakout,
                selectedForForm: (typeof $selectedQuestionIdArray !== 'undefined' && $selectedQuestionIdArray instanceof Array) ? $selectedQuestionIdArray.join(',') : '',
                selectedQuestionFlag: ($j('div#toggleSelectedButton').hasClass('showAllQuestions')),
                sessionDeleted: state
            },
            success: function (data) {
                $j("#loadingImage").hide();
                if (!$j('div#toggleSelectedButton').hasClass('showAllQuestions')) {
                    $j("#questionCategoryNameContainer").show();
                }
                $j("#individualQuestions").append(data);
                if (questionGSList !== '0') {
                    displayTablePropertySelected();
                }
                if ($j('#bulkEditSelect').is(":visible")) {
                    $j('.QuestionDataCheckBox input').show();
                }

                if ($j(data).length < 2 && !$isBrowseQuestion) {
                    $j("#individualQuestions").append('<p class="notFound">There are no selected questions to show in this category.</p>');
                }
            },
            complete: function () {
                if (!$isBrowseQuestion) {
                    selectAllNoneStatus(true);
                    var $selectAllSelector = $j('span.selectAllQuestion'),
                        $this = $j('div#toggleSelectedButton');
                    if($this.hasClass('showAllQuestions')) {
                        $j('span.selectAllQuestion').html('(<a href="javascript:void(0);">Deselect All Questions</a>)');
                        $j('a.SelectAllSubQuestions').removeClass('SelectAll SelectNone')
                                                        .addClass('SelectNone').text('Deselect Entire Question');
                        $j11('div.eachQuestionBodyBox').each(function () {
                            if ($j(this).hasClass('selected')) {
                                $j(this).siblings('.questionTextBox').find('.questionText').addClass('selected');
                                $j(this).show().siblings().not('.clear').show();
                            } else {
								
                               // $j(this).hide().siblings().not('.clear').hide(); //commneted for Surveyform-18
								
                            }
                        });
                        $j('div#individualQuestions > div > div.QuestionListDatacontainerDiv:visible')
                            .has('.eachQuestionBodyBox:visible')
                            .find('.questionTextBox').show();
                        /*if ($j11('.eachQuestionBodyBox:visible').length) {
                            $selectAllSelector.text('Deselect All Questions');
                        } else {
                            $selectAllSelector.hide()
                        }*/
                    } else {
                        //$j('#questionCategoryNameContainer').show();
                        $j('div.eachQuestionBodyBox').show().siblings().not('.clear').show();
                        $j11('div.eachQuestionBodyBox').each(function () {
                            if ($j(this).hasClass('selected')) {
                                $j(this).siblings('.questionTextBox').find('.questionText').addClass('selected');
                            }
                        });
                        
                        /* Write code to change subquestion select entire question 
                            depending on the number of boxed checked*/
                        /*if ($j('.eachQuestionBodyBox:visible').length ) {
                            $selectAllSelector.text('Select All Questions');
                            $selectAllSelector.show()
                        }*/
                    }
                }
                $j(document).bind('scroll', myScrollHandler);
                infiniteScrollState = true;
            }
        });
    } else {
		$j("#loadingImage").hide();        
		$j('#numOfQuestionsShown').text('(Number Displayed: 0)');
		$j("#individualQuestions").append('<p class="notFound">No questions match your current filter settings.</p>');
    }
}

function destroyLoadAndSaveViewWindow() {
	ColdFusion.Window.destroy('LoadAndSaveViewWindow', true);
}

/*Function for loading search result LAJIN 01*/
function showLoadAndSaveView(event) {
    var argAdvancedOptionPanelState = $j("#advancedOptionPanelState").val(),
        argCategoryFilter = $j("#categoryFilter").val(),
        argCreatedByFilter = $j("#createdByFilter").val(),
        argDateFilter = $j("#dateFilter").val(),
        argQuestionListFilter = $j("#questionListFilter").val(),
        argQuestionTablePropertiesList = $j("#tablePropertiesFilter").val(),
        argQuestionTagList = $j("#filterTagsIDs").val(),
        argSelectedCategory = $j("#selectedCategoryId").val(),
        argSortByFilterDropdown = $j("#sortByFilterDropdown").val(),
		path = "index.cfm?event=questions.loadAndSaveViewWindow&argAdvancedOptionPanelState=" + argAdvancedOptionPanelState + "&argCategoryFilter=" + argCategoryFilter + "&argCreatedByFilter=" + argCreatedByFilter + "&argDateFilter=" + argDateFilter + "&argQuestionListFilter=" + argQuestionListFilter + "&argQuestionTablePropertiesList=" + argQuestionTablePropertiesList + "&argQuestionTagList=" + argQuestionTagList + "&argSelectedCategory=" + argSelectedCategory + "&argSortByFilterDropdown=" + argSortByFilterDropdown;
    ColdFusion.Window.create("LoadAndSaveViewWindow", "", path, {
        modal: true,
        width: 400,
        height: 450,
        center: true,
        draggable: true,
        x: event.pageX - 300,
        y: event.pageY + 25
    });
	ColdFusion.Window.onHide("LoadAndSaveViewWindow", destroyLoadAndSaveViewWindow);
}

/*Function for showing AddNewView  LAJIN 01*/
function showAddNewView(action) {
    var charCount = 80;
    $j(".lsvNameValueContainer").prepend('<div class="overDiv"></div>');
	if (action === 'add') {
		$j("#addNewView").show();
		$j("#addNewViewButton").hide();
	}
	if (action === 'cancel') {
		$j("#addNewView").hide();
		$j("#addNewViewButton").show();
        $j('.lsvNameValueContainer').find('.overDiv').remove();
	}
    $j('#createViewName').val('');
    $j('#viewName_cnt').text(charCount);
}
/*Function for editing view LAJIN 01*/
function editView(action, id) {
	var $this,
        count = 80,
        labelName,
        labelLength,
        selection,
        path;
	if (action === 'edit') {
        labelName = $j('#viewLabel_' + id + ' span').text().trim();
        labelLength = $j('#viewLabel_' + id + ' span').text().trim().length;
        $j('#viewLabel_' + id).hide();
        $j('#Edit_' + id).hide();
        $j('#Name_' + id).show();
        $j('#Check_' + id).show();
        $j('#charRem_' + id).show();
        $j('#Name_' + id).val(labelName);
        if (labelLength) {
            count = 80 - labelLength;
            $j('#charRem_' + id + ' span').text(count);
        } else {
            $j('#charRem_' + id + ' span').text(count);
        }
        $j(".lsvNameValueContainer").each(function () {
            $this = $j(this);
            if ($this[0].id !== 'container_' + id) {
                $this.prepend('<div class="overDiv"></div>');
            }
        });
        $j("#addNewViewButton input[type='button']").prop('disabled', true);
	}
	if (action === 'delete') {
        labelName = $j('#viewLabel_' + id + ' span').text();
		if ($j('#Name_' + id).is(':visible')) {
			$j('#viewLabel_' + id).show();
			$j('#Edit_' + id).show();
			$j('#Name_' + id).hide();
			$j('#Check_' + id).hide();
			$j('#charRem_' + id).hide();
            $j('.lsvNameValueContainer').find('.overDiv').remove();
            $j("#addNewViewButton input[type='button']").removeAttr('disabled');
		} else {
			selection = confirm('Are you sure you want to delete the saved view, "' + labelName + '"?');
			if (selection === true) {
				path = "index.cfm?event=questions.deleteView";
				$j.ajax({
					url: path,
					type: "POST",
					data: {
						argViewId: id
					},
					success: function (data) {
						$j('#container_' + id).hide();
                        $j('#viewDeleteMessage').empty().append('<div class="viewDeleteMessage" id="viewDeleteMessage"><div><img src="../../images/icons/flag_green24.gif" alt="question has been permanently deleted"/></div><div class="messageDivData">View successfully deleted.</div></div>').fadeOut(5000);
					}
				});
			}
		}
	}
}
/*Function for adding view LAJIN 01*/
function saveFilters() {
	var viewName = $j("input[type='text'][name='viewName']").val().trim(),
        categoryFilter = $j("#categoryFilter").val(),
        selectedCategoryId = $j("#selectedCategoryId").val(),
        createdByFilter = $j("#createdByFilter").val(),
        sortByFilterDropdown = $j("#sortByFilterDropdown").val(),
        questionListFilter = $j("#questionListFilter").val(),
        argQuestionTablePropertiesList = $j("#tablePropertiesFilter").val(),
        argAdvancedOptionPanelState = $j("#advancedOptionPanelState").val(),
        argQuestionTagList = $j("#filterTagsIDs").val(),
        argDateFilter = $j("#dateFilter").val(),
        path = "index.cfm?event=questions.saveView",
        existingViewName = $j('#existingViewName').val().split(','),
        alertStatement;

    if (viewName.length) {
        if ($j.inArray(viewName, existingViewName) === -1) {
            $j.ajax({
                url: path,
                type: "POST",
                data: {
                    argViewName: viewName,
                    argCategoryFilter: categoryFilter,
                    argSelectedCategoryId: selectedCategoryId,
                    argCreatedByFilter: createdByFilter,
                    argSortByFilterDropdown: sortByFilterDropdown,
                    argQuestionListFilter: questionListFilter,
                    argQuestionTablePropertiesList: argQuestionTablePropertiesList,
                    argAdvancedOptionPanelState: argAdvancedOptionPanelState,
                    argQuestionTagList: argQuestionTagList,
                    argDateFilter: argDateFilter
                },
                success: function (data) {
                    $j("#viewListing").prepend(data);
                    $j("#addNewView").hide();
                    $j("#addNewViewButton").show();
                    $j("#createViewName").val('');
                    $j(".lsvViewButton input[type='button']").removeAttr('disabled');
                    $j(".lsvSetDefaultButton input[type='button']").removeAttr('disabled');
                    $j('.lsvNameValueContainer').find('.overDiv').remove();
                }
            });
        } else {
            alertStatement = 'A view with this name "' + viewName + '" already exists. Please enter a new name.';
            alert(alertStatement);
        }
    } else {
        alert('View name cannot be left as blank.');
    }
}
/*Function for updating view name LAJIN 01*/
function updateviewName(viewId) {
	var alertStatement,
        viewName = $j("#Name_" + viewId).val(),
        path = "index.cfm?event=questions.updateViewName",
        existingViewName = $j('#existingViewName').val().split(',');
    if ($j.inArray(viewName, existingViewName) === -1) {
        $j.ajax({
            url: path,
            type: "POST",
            data: {
                argViewName: viewName,
                argViewId: viewId
            },
            success: function (data) {
                $j('#viewLabel_' + viewId).show();
                $j('#viewLabel_' + viewId + ' span').text(viewName);
                $j('#Edit_' + viewId).show();
                $j('#Name_' + viewId).hide();
                $j('#Check_' + viewId).hide();
                $j('#charRem_' + viewId).hide();
            }
        });
    } else {
        alertStatement = 'A view with this name, "' + viewName + '", already exists. Please enter a new name.';
        alert(alertStatement);
    }
}
/*Function for setting default view LAJIN 01*/
function setDefaultView() {
	var viewId = 0,
        defaultViewId = 0,
        path;
	$j("#viewListing div input[type='radio']").each(function () {
		if (this.checked) {
			viewId = Number(this.value);
		}
	});
	if ($j("#defaultViewID").val()) {
		defaultViewId = Number($j("#defaultViewID").val());
	}
	if (defaultViewId === viewId) {
		if (defaultViewId === 0 && viewId === 0) {
			alert("Select one view");
		} else {
			alert("This is already the default view");
		}
	} else {
		path = "index.cfm?event=questions.updateDefaultView";
		$j.ajax({
			url: path,
			type: "POST",
			data: {
				argDefaultViewId: defaultViewId,
				argViewId: viewId
			},
			success: function (data) {
				$j("#defaultViewID").val(viewId);
                window.location.replace('index.cfm?event=mc.questionlist');
			}
		});
	}
}

/*Function for loading selected view LAJIN 01*/
function loadSelectedView() {
    var path,
        viewId;
	$j("#viewListing div input[type='radio']").each(function () {
		if (this.checked) {
			$j("#argViewId").val(this.value);
            document.loadViewForm.submit();
		}
	});
}

/*Function for loading selected view LAJIN 01*/
function loadSelectedViewInit() {
    var path, 
		viewId;
	$j("#viewListingInit div input[type='radio']").each(function () {
		if (this.checked) {
			$j("#argViewIdInit").val(this.value);
            document.loadViewFormInit.submit();
		}
	});
}

/*Function for showing survey history of questions window LAJIN 01*/
function showUsedSurveys(questionId) {
	var theWidth = 550;
    ColdFusion.Window.create("SurveyHistoryWindow", "", "index.cfm?event=questions.surveyHistoryWindow&qestnId=" + questionId, {
        modal: true,
        width: theWidth,
        height: 300,
        center: true,
        draggable: true
    });
	ColdFusion.Window.onHide("SurveyHistoryWindow", destroyWindow);
}

function destroyWindow() {
	ColdFusion.Window.destroy('SurveyHistoryWindow', true);
}

/*Function for filtering questions window LAJIN 01*/
function getAllFilterdQuestion() {
	var $selectedQuestionsArrayLocal = (typeof $selectedQuestionsArray !== "undefined") ? $selectedQuestionsArray : '[]',
        $surveySelector = ($isBrowseQuestion) ? false : $j('div#toggleSelectedButton').hasClass('showOnlySelectedQuestions'),
        $surveySelectorAll = ($isBrowseQuestion) ? false : $j('div#toggleSelectedButton').hasClass('showAllQuestions'),
        argAdvancedOptionPanelState = $j("#advancedOptionPanelState").val(),
        argDateFilter = $j("#dateFilter").val(),
        argQuestionTablePropertiesList = $j("#tablePropertiesFilter").val(),
        argQuestionTagList = $j("#filterTagsIDs").val(),
        argSearchTextFilter = $j("#searchTextFilter").val(),
        categoryFilter = $j("#categoryFilter").val(),
        categoryType = '',
        createdByFilter = $j("#createdByFilter").val(),
        isSurveyPage = '',
        path = "index.cfm?event=questions.getAllFilteredQuestion",
        questionListFilter = $j("#questionListFilter").val(),
        selectedCategoryId = $j("#selectedCategoryId").val(),
        selectedSurveyId = '',
        sortByFilterDropdown = $j("#sortByFilterDropdown").val(),
        state = true;
    
    $j(document).unbind('scroll', myScrollHandler);
	/* Added for create survey page*/
	if (!$isBrowseQuestion) {
		categoryType = $j("input[name=breakOut]:checked").val();
		isSurveyPage = 1;
        argDateFilter = '0';
        if ($selectedQuestionsArrayLocal !== '[]' && $surveySelector && $surveySelectorAll) {
            var i = 0,
                selectedSurveyQuestions = $selectedQuestionsArrayLocal.join(','),
                selectedGroupSequence = [],
                temp = selectedSurveyQuestions.match(/[\d]+/g);
            while (i < (selectedSurveyQuestions.split(',').length * 2)) {
                selectedGroupSequence.push(temp[i + 1]);
                i += 2;
            }
            state = false;
        }
	} else {
		categoryType = 1;
		isSurveyPage = 0;
	}
    if (state) {
        if (ajaxSynch && ajaxSynch.readystate !== 4) {
            ajaxSynch.abort();
        }
        $j.ajax({
            url: path,
            type: "POST",
            async: false,
            data: {
                argCategoryFilter: categoryFilter,
                argSelectedCategoryId: selectedCategoryId,
                argCreatedByFilter: createdByFilter,
                argSortByFilterDropdown: sortByFilterDropdown,
                argQuestionListFilter: questionListFilter,
                argQuestionTablePropertiesList: argQuestionTablePropertiesList,
                argAdvancedOptionPanelState: argAdvancedOptionPanelState,
                argQuestionTagList: argQuestionTagList,
                argDateFilter: argDateFilter,
                argSearchTextFilter: argSearchTextFilter,
                categoryType: categoryType,
                isSurveyPage: isSurveyPage,
                selectedQuestionFlag: ($j('div#toggleSelectedButton').hasClass('showAllQuestions')),
                groupSequenceList: $j("#allQuestionIds").val()
            },
            success: function (response) {
                var arrList = $j.trim(response).split(','),
                    isSessionDeleted = arrList.splice(0,1),
                    res = $j.unique(arrList).join(','),
                    categoryId = $j("#selectedCategoryId").val();
                $j("#selectedQuestionList").val(res);
                $j("#restoreUserViewVariable").val(res);
                if (categoryId === ALRQid) {
                    $j("#questionCategoryNameContainer > span").text("(Number Displayed: " + ((res === 0) ? '0' : res.split(',').length + 1-($j("#arqPermission").val())) + ")");
                } else {
                    $j("#questionCategoryNameContainer > span").text("(Number Displayed: " + ((res === 0) ? '0' : res.split(',').length) + ")");
                }               
                loadSearchResult(isSessionDeleted[0]);
            }
        });
    } else {
        $j("#selectedQuestionList").val(selectedGroupSequence.join(','));
        loadSearchResult(false);
    }
}

/*function used for table properties */
function saveList(layoutIDName, responseArea, windowName, isTabbedPane) {
    var $this,
        $selCreatedByFilter = $j("#createdByFilter"),
        $selTablePropertiesFilter = $j("#tablePropertiesFilter"),
        atLeastOne = $j('#' + layoutIDName + ' .secondLayer li').children().is(":checked"),
        itemsArray = [],
        questionId,
        questionIDList = '',
        result = '',
        totalLength = $j('#' + layoutIDName + ' .secondLayer input:checkbox').length;
    if (atLeastOne) {
        if (isTabbedPane) {
            $j('#' + layoutIDName + ' #tab1 .all').each(function () {
                $this = $j(this);
                if ($this.is(':checked')) {
                    itemsArray.push($this.val());
                }
            });
        } else {
            $j('#' + layoutIDName + ' .all').each(function () {
                $this = $j(this);
                if ($this.is(':checked')) {
                    itemsArray.push($this.val());
                }
            });
        }
        if (layoutIDName === 'createdByLayout') {
            if (itemsArray.length === 0) {
                $selCreatedByFilter.val(0);
            } else if (itemsArray.length === 4) {
                $selCreatedByFilter.val(4);
            } else {
                $selCreatedByFilter.val(itemsArray.toString());
            }
        } else if (layoutIDName === 'tablePropLayout') {
            if (itemsArray.length === 0) {
                $selTablePropertiesFilter.val(0);
            } else {
                $selTablePropertiesFilter.val(itemsArray.toString());
            }
        }
    } else {
        if (layoutIDName === 'createdByLayout') {
            if (itemsArray.length === 0) {
                $selCreatedByFilter.val(0);
            } else if (itemsArray.length === 4) {
                $selCreatedByFilter.val(4);
            } else {
                $selCreatedByFilter.val(itemsArray.toString());
            }
        } else if (layoutIDName === 'tablePropLayout') {
            if (itemsArray.length === 0) {
                $selTablePropertiesFilter.val(0);
            }
        }
    }

    switch (layoutIDName) {
    case 'createdByLayout':
        if (itemsArray.length === totalLength || itemsArray.length === 0) {
            while (itemsArray.length !== 0) {
                itemsArray.pop();
            }
            itemsArray.push('Everyone');
        }
        break;
            
    case 'contentLayout':
        if (itemsArray.length === 0) {
            itemsArray.push('None');
        }
        break;
            
    case 'tablePropLayout':
        if (itemsArray.length === 0) {
            itemsArray.push('None');
        }
		displayTablePropertySelected();
        break;
            
    default:
        break;
    }

    if (layoutIDName === 'tablePropLayout') {
        result = itemsArray.join('</li><li>');
        result = '<li>' + result + '</li>';
    } else if(layoutIDName === 'createdByLayout') {
        result = itemsArray.join(', ').replace(/, _/, ', ').replace(/^_/,'');
    } else {
        result = itemsArray.join(', ');
    }
    if (layoutIDName === 'createdByLayout') {
        if (result !== 'Everyone') {
            getAllFilterdQuestion();
        } else {
            questionId = $j("#allQuestionIds").val();
            $j("#selectedQuestionList").val(questionId);
			loadSearchResult(false);
        }
    }
    document.getElementById(responseArea).innerHTML = result;
    ColdFusion.Window.destroy(windowName);
}

/*Search question in a category LAJIN 01*/
function searchQuestionList() {
	if (ajaxSynch && ajaxSynch.readystate !== 4) {
		ajaxSynch.abort();
	}
    $j('#searchTextFilter').val($j("#searchQuestion").val());
    getAllFilterdQuestion();
}
/*Function for cancel search result LAJIN 01*/
function cancelQuestionList() {
	$j("#searchTextFilter").val('');
	getAllFilterdQuestion();
}

// To reset the filters
function clearFilters(enrolledDate) {
    var programStartDate = enrolledDate,
        todayDate = new Date(),
        todayDateFormated = todayDate.getFullYear() 
                            + '-' + (todayDate.getMonth() + 1) 
                            + '-' + todayDate.getDate(),
        defaultDate = '0::' + programStartDate + '::' + todayDateFormated;
    
    $j("#categoryFilter").val(0);
    $j("#createdByFilter").val(0);
    $j("#sortByFilterDropdown").val(0);
    $j("#questionListFilter").val(2);
    $j("#tablePropertiesFilter").val(0);
    $j("#advancedOptionPanelState").val(0);
    $j('#tagFilter').val(0);
    $j("#filterTagsIDs").val('');
    $j("#dateFilter").val(defaultDate);
    $j("#searchTextFilter").val('');
    $j("#searchCategory").val('');
    $j("#searchQuestion").val('');
    $j('.searchCategoryCancelImg').addClass('blockview');
    $j('#optionCellCancelImgId').addClass('blockview');
    
    getAllFilterdQuestion();
    loadOptionValues();
}

/*----Bulk Edit Button changes when Click Category---*/
function bulkEditValueReset() {
	//$j('.searchContent').css('backgroundColor', '#ebf6ff');
	$j("#textHolderArchive span").text("0").attr("id", "0");
	$j("#textHolderDelete span").text("0").attr("id", "0");
	$j("#ArchivedQuestionList").val("");
	$j('#bulkEditSelect').hide();
	$j('#selectQuestionText').hide();
	$j('.QuestionDataCheckBox input').hide();
	$j('#bulkEditMode').css('background', '#fff').attr("rel", "none");
	$j('#bulkEditSelectOptions').css('display', 'none');
	$j(this).css('backgroundColor', '#D1EAFE');
}

// Mediator to set selected category in hidden field
function mediator(content) {
	$j('.optionTable').show();
	$j('.QuestionListContainer').show();
	$j('.searchContent').css('backgroundColor', '');
	$j(content).parent().css( "backgroundColor", "#ebf6ff" );
	$j("#individualQuestions").empty();
	$j("#loadingImage").show();
	bulkEditValueReset();
    var groupSequenceList = $j("#" + content.id).attr("rel");
    $j("#allQuestionIds").val(groupSequenceList);
	/* Added for create survey page*/
	$j("#selectedCategoryId").val(content.id);
	$j('#questionCategoryName').text($j(content).text().trim());
	if (!$isBrowseQuestion) {
		$j("#selectedSurveyId").val(content.id);
	}
	/*if ($j('#Sqm-14_MessageClass').is(':visible')) {
		$j('#Sqm-14_MessageClass').hide();
	}*/
    if(!$isBrowseQuestion) {
        var $this = $j('div#toggleSelectedButton');
        $this.find(".optionCellResponseSelect").text('Show Selected Questions');
        $this.find(".optionCellResponseImgDiv img").attr('src','../../images/icons/create-a-survey---show-all-questions.png');
        $this.removeClass('showAllQuestions').addClass('showOnlySelectedQuestions');
    }
    getAllFilterdQuestion();
    categoryColorChange();
}

function archiveQuestionIdFetch() {
	var path = "index.cfm?event=questions.getBulkEditQuestionCount";
	if ($j.trim($j("#bulkEditMode").attr("rel")) === 'none') {    // prevent more than one ajax call at a time
        $j.ajax({                                               // Ajax call for get archived questions ID
			url: path,
			type: "POST",
			data: {
				categoryId: $j("#selectedCategoryId").val()
			},
			success: function (response) {
				$j("#ArchivedQuestionList").val($j.trim(response));
			}
		});
	}
}
/* Function for question delete operations*/
function questionDeleteCall(qsidList) {
    var path = 'index.cfm?event=questions.deletequestionsNotArchived';
    $j.ajax({
        url: path,
        type: "GET",
        data: {
            qsid: JSON.stringify(qsidList)
        },
        success: function () {
            getCategoryListing($j('#categoryFilter').val());
            $j("#textHolderDelete span").text("0").attr("id", "0");
            if(qsidList.length > 1) {
                alert(qsidList.length + ' questions deleted successfully');
            } else {
                alert(qsidList.length + ' question deleted successfully');
            }
        }
    });
	$j.each(qsidList, function (_List, qsid) {
		$j('#qid_' + qsid).parent().remove();
		//$j('#Sqm-14_MessageClass').css("display", "block");
		var res = Number($j('#numOfQuestionsShown').text().match(/[\d]+/)[0]),
			newCount = res - 1;
		$j('#numOfQuestionsShown').text('(Number Displayed: ' + newCount + ')');
	});
	if (Number($j('#numOfQuestionsShown').text().match(/[\d]+/)[0]) === 0) {
        $j("#selectedCategoryId").val(0);
        $j("#categoryFilter").val(0);
        $j('#questionCategoryName').text($j('#0').text().trim());
        getAllFilterdQuestion();
    }
}
/*This Below function used both checkBox and RadioButton Cases in AmericaLearns Required Questions*/
function aRQ_CheckBoxOrRadioSlideOperation(blockID, Itype) {
	var checkCounter = 0;
	switch (Itype) {
    case 'r':
        $j('.specialContainer_subQuestionList_' + Itype).stop().hide(1);
        $j('input[type=radio][name=pRB_Case_Challenge]').removeAttr('disabled');
        $j('.allRadioInputbuttonARQ').each(function (count, _this) {$j(_this).removeAttr('checked'); });
        $j('.specialContainer_subQuestionList_' + Itype + ' a').stop().show();
        break;
    case 'c':
        if ($j("#specialContainer_" + Itype + '_' + blockID + ':hidden').length) {
            $j('#specialCheckBox_' + Itype + '_' + blockID).attr("disabled", "true");
            $j("#specialContainer_" + Itype + '_' + blockID).stop().slideDown();
        } else {
            $j("#specialContainer_" + Itype + '_'  + blockID).stop().slideUp();
            $j('#specialCheckBox_' + Itype + '_' + blockID).removeAttr('disabled');
            $j('#specialCheckBox_' + Itype + '_' + blockID).removeAttr('checked');
        }
        break;
    case 'cc':
        $j('#specialContainer_' + Itype.slice(0, 1) + '_'  + blockID + ' input[type=checkbox][name=cB_' + blockID + ']').each(function (count, _this) {
            (_this.checked) ? checkCounter++ : checkCounter;
        });
        (checkCounter) ? $j("#specialContainer_" + Itype.slice(0, 1) + '_'  + blockID + ' a').stop().hide() : $j("#specialContainer_" + Itype.slice(0, 1) + '_'  + blockID + ' a').stop().show();
        break;
    case 'rc':
        $j("#specialContainer_" + Itype.slice(0, 1) + '_'  + blockID + ' a').stop().hide();
        break;
			
		
	}
}
function LoadPreviewSurvey() {
	var editorElement = ['Situation', 'Step1', 'Step2', 'Step3', 'Step4', 'Step5'];
	$j.each(editorElement, function (index, value) {
		if ($j('textarea[name="' + value + '"]').length > 0) {
			if (CKEDITOR.instances[value]) {
                CKEDITOR.remove(CKEDITOR.instances[value]);
            }
			editor['editor' + (index + 1)] = CKEDITOR.instances[value];
		}
	});
}

/* Rejith : Tag manager : START */
function toCheckValueInOtherTabs(activeTab) {
	var remainingClasses = '';
	switch (activeTab) {
    case '#tab1':
        remainingClasses = 'recent,frequent';
        break;
    case '#tab2':
        remainingClasses = 'all,frequent';
        break;
    case '#tab3':
        remainingClasses = 'all,recent';
        break;
    default:
        break;
	}
	
}

function selectAllFun(layoutID) {
    var activeTab = $j(".tabs li.active a").attr('href'),
        currentText = $j("#" + layoutID + ' #selectAll').text(),
        remClassName = "";

    if (layoutID !== 'contentLayout') {
        remClassName = ".all";
    } else {
        remClassName = activeTab + ' .all';
    }

    if (currentText === 'Select All') {
        $j("#" + layoutID + " " + remClassName).each(function () {
            $j(this).prop('checked', 'checked');
        });
        $j("#" + layoutID + ' #selectAll').text('Select None');
    } else {
        $j("#" + layoutID + " " + remClassName).each(function () {
            $j(this).prop('checked', '');
        });
        $j("#" + layoutID + ' #selectAll').text('Select All');
    }

    if (layoutID === 'contentLayout') {
        toCheckValueInOtherTabs(activeTab);

    }
}

function showQuestionTagWindow(questionid) {
    var theWidth = 460;
	$dialogTag.dialog('open')
			.html('<table width="100%"><tr><td align="center"><img src="../../images/icons/animated_loading.gif"></td></tr></table>')
			.load('index.cfm?event=questions.managequestiontagwindow&questionid=' + questionid, function (response, status, xhr) {
            if (status === "error") {
                var msg = "Sorry but there was an error.";
                alert(msg);
            }
            $tagsJSON = $j11.parseJSON($j11('#tagsJson').val());
            $existingTagsString = [];
            $existingTagsID = [];
            $newTagsArray = [];
            $j11.each($tagsJSON.DATA, function (i, el) {
                $existingTagsID.push(el[0]);
                $existingTagsString.push($j11.trim(el[1]));
            });
        });
}
function closeTagWindow() {
	$dialogTag.dialog('close');
}
function showFilterByTagWindow(event) {
	var	theWidth = 465;
	selectedFilters = typeof $j11('#filteredTags #filterTagsIDs').val() !== "undefined" ? $j11('#filteredTags #filterTagsIDs').val() : '';
	$dialogTag.dialog('open')
			.html('<table width="100%"><tr><td align="center"><img src="../../images/icons/animated_loading.gif"></td></tr></table>')
			.load('index.cfm?event=questions.filterbytagwindow&btnVal=Filter&isBrowseQuestion=' + $isBrowseQuestion, {selectedTags: selectedFilters}, function (response, status, xhr) {
            if (status === "error") {
                var msg = "Sorry but there was an error.";
                alert(msg);
            }
            $tagsJSON = $j11.parseJSON($j11('#tagsJson').val());
            $existingTagsString = [];
            $existingTagsID = [];
            $newTagsArray = [];
            $j11.each($tagsJSON.DATA, function (i, el) {
                $existingTagsID.push(el[0]);
                $existingTagsString.push($j11.trim(el[1]));
            });
        });
    $j("div.ui-dialog").css({top: event.pageY + 20, left: event.pageX});
}
/* Rejith : Tag manager : END */

$j(document).ready(function () {
    $isBrowseQuestion = typeof $isBrowseQuestion !== 'undefined' ? $isBrowseQuestion : true;
    $j('.change').niceselect();
    $j('.fpminner').removeAttr('style');
    $j(document).click(function (e) {
        var clicked = e.target;
        if (((this.id !== 'optionCellDateSelectFormDiv') &&  !($j(clicked).parents('#optionCellDateSelectFormDiv').length)) && (($j(clicked).attr("class") !== 'ui-icon ui-icon-circle-triangle-w') && ($j(clicked).attr("class") !== 'ui-icon ui-icon-circle-triangle-e'))) {
            $j("#optionCellDateSelectFormDiv").hide();
		}
		if ((this.id !== 'bulkEditSelectOptions') &&  !($j(clicked).parents('#bulkEditSelectOptions').length)) {
			$j("#bulkEditSelectOptions").hide();
		}
	});
    
    if(!$isBrowseQuestion) {
        if ($selectedQuestionsArray.length) {
            processChange();
        }
    }
	
	$j("#datepickerdropDownSelect").on("click", function (event) { //Show Date Panel
		$j(".optionCellDateSelectFormDiv").toggle();
		event.stopPropagation();
	});
	$j("#optionCellDateSelectFormDateBtnApply").on("click", function () {
		$j("#optionCellDateSelectDataField").val($j('.DateRadInput:checked').attr("rel") + ': ' + $j("#calendarDataFieldStartingDate").text() + ' - ' + $j("#calendarDataFieldEndDate").text());
        /*Modified by Lajin02: Start*/
        var buttonValue = 0,
            endDate = $j("#calendarDataFieldEndDate").text(),
            endDateCheck = new Date(endDate),
            startDate = $j("#calendarDataFieldStartingDate").text(),
            startDateCheck = new Date(startDate);
        if ($j('.DateRadInput:checked').attr("rel") === 'Created Between') {
            buttonValue = 0;
        } else if ($j('.DateRadInput:checked').attr("rel") === 'Last Launched Between') {
            buttonValue = 1;
        } else if ($j('.DateRadInput:checked').attr("rel") === 'Last Edited Between') {
            buttonValue = 2;
        }
        if (endDateCheck < startDateCheck) {
            alert("Start date cannot be greater than end date");
        } else { 
            $j('#dateFilter').val(buttonValue + '::' + startDate + '::' + endDate);
            getAllFilterdQuestion();
            /*Modified by Lajin02: End*/
            $j(".optionCellDateSelectFormDiv").hide(1);
        }
	});
	$j(".niceselect .values input[type=radio]:checked").parent().addClass("active");
	/* datePicker Cancel Button Click*/
	$j("#optionCellDateSelectFormDateBtnCancel ").click(function () {
		var temp = $j("#optionCellDateSelectDataField").val().split(/[:\-]+/);
		$j(".DateRadInput[rel='" + temp[0] + "']").prop("checked", "true");
		$j("#calendarDataFieldStartingDate").text(temp[1]);
		$j("#calendarDataFieldEndDate").text(temp[2]);
		$j(".ui-datepicker-group > .ui-datepicker-calendar > tbody > tr >td >a ").removeClass("ui-state-active");
		$j(".ui-datepicker-group > .ui-datepicker-calendar > tbody > tr >td").removeClass(" ui-state-highlight");
		$j(".optionCellDateSelectFormDiv").hide(1);
    });
    $j("#loadingImage").hide();
    $j("#questionCategoryNameContainer").hide();

    /*Search category initialisation LAJIN 01*/
	$j("#searchCategory").on("keydown keyup keypress change", function () {
        var $this = $j(this);
		searchQuestionCategory($this.val());
        if ($this.val().length > 0) {
            if ($j('.searchCategoryCancelImg').hasClass('blockview')) {
                $j('.searchCategoryCancelImg').removeClass('blockview');
            }
        } else {
            if (!($j('.searchCategoryCancelImg').hasClass('blockview'))) {
                $j('.searchCategoryCancelImg').addClass('blockview');
            }
        }
	});
    
    $j('.searchCategoryCancelImg img').on('click', function () {
        $j("#searchCategory").val('');
        $j('.searchCategoryCancelImg').addClass('blockview');
        getCategoryListing($j('#categoryFilter').val());
    });
    
	$j("#searchQuestion").on("keydown keyup keypress change", function (e) {
        var keycode = e.which;
		if ($j(this).val().length > 0) {
            if ($j('.optionCellCancelImg').hasClass('blockview')) {
                $j('.optionCellCancelImg').removeClass('blockview');
            }
            
            if (keycode === 13) {
                searchQuestionList();
            }
        } else {
            if (!($j('.optionCellCancelImg').hasClass('blockview'))) {
                $j('.optionCellCancelImg').addClass('blockview');
            }
            $j('#searchTextFilter').val('');
            
            if (keycode === 13) {
                cancelQuestionList();
            }
        }
	});
    
    $j('.optionCellCancelImg img').on('click', function () {
        $j("#searchQuestion").val('');
        $j('.optionCellCancelImg').addClass('blockview');
    });
    
    //advanced option panel: start
	$j('.panel_bottom').click(function () {
		if ($j('.panel_top').is(':animated')) { return; }
		if ($j(this).parent().children(0).is(':hidden')) {
            $j('#advancedOptionPanelState').val(1);
			$j('.panel_top').slideDown('1000');
			$j('.panel_bottom').html('<img src="../images/icons/hide advanced options.png" alt="hide arrow" /><span>&nbsp; hide options</span>');
		} else {
            $j('#advancedOptionPanelState').val(0);
			$j('.panel_top').slideUp('1000');
			$j('.panel_bottom').html('<img src="../images/icons/show advanced options.png" alt="show arrow" /><span>&nbsp; more options</span>');
		}
	});
		
	$j(document).on('click', '.tabs .tab-links a', function (e) {
        var currentAttrValue = $j(this).attr('href');
 
        // Show/Hide Tabs
        $j('.tabs ' + currentAttrValue).show().siblings(':not(:eq(0))').hide();
 
        // Change/remove current tab to active
        $j(this).parent('li').addClass('active').siblings().removeClass('active');
 
        e.preventDefault();
    });
	//advanced option panel: end  
    
	/* Bulk edit mode: start , here get archived question ID */
    $j('#bulkEditMode').on('click', function (e) {
        if (($j(this).parent().children(1).is(':hidden')) && ($j("#selectedCategoryId").val() !== ALRQid)) {	//bulk edit conditions here neglect AL Questions (ALRQid)
			$j('#bulkEditSelect,.QuestionDataCheckBox input,#selectQuestionText').show(1);
			archiveQuestionIdFetch();
			$j('#bulkEditMode').css('background', '#c9c9c9').attr("rel", "selected");	 // property chage for prevent ajax call
		} else {
			$j('#bulkEditSelect,.QuestionDataCheckBox input,#selectQuestionText').hide(1);
			$j('#bulkEditMode').css('background', '#fff').attr("rel", "none");
			$j("#textHolderArchive span,#textHolderDelete span").text("0");
			$j('.primaryQuestionListClass').removeClass('selectedQuestionCompleteColorChange');
            $j('.subQuestionBorderUp').removeClass('selectedQuestionCompleteColorChange').addClass('subQuestionGradUp');
			$j('.subQuestionBorderDown').removeClass('selectedQuestionCompleteColorChange').addClass('subQuestionGradDown');
            $j('.selectedQuestionCompleteColorChange').addClass('colorPatternClass').removeClass('selectedQuestionCompleteColorChange');
			$j("#ArchivedQuestionList").val("");
            
            if ($j('.QuestionDataCheckBox input[type="checkbox"]').is(":checked")) {
                $j('.QuestionDataCheckBox input[type="checkbox"]').prop('checked', false);
            }
            
            if ($j('#bulkEditSelectOptions').is(':visible')) {
                $j('#bulkEditSelectOptions').hide();
            }
		}
    });
    
    $j('#bulkEditSelect').on('click', function (e) {
        $j('#bulkEditSelectOptions').toggle();
		e.stopPropagation();
    });
    
    $j('.optionStyle').on('click', function (e) {
        $j('#bulkEditSelectOptions').hide();
    });
    
    $j(document).on('click', '.QuestionDataCheckBox input:checkbox', function (e) {
        var $this = $j(this),
			tempID = '';
        if ($this.is(':checked')) {
            tempID = $this.attr('value');
            $j('#qid_' + tempID + ' .primaryQuestionListClass').addClass('selectedQuestionCompleteColorChange');
            $j('#qid_' + tempID + ' .subQuestionBorderUp').addClass('selectedQuestionCompleteColorChange').removeClass('subQuestionGradUp');
            $j('#qid_' + tempID + ' .subQuestionBorderDown').addClass('selectedQuestionCompleteColorChange').removeClass('subQuestionGradDown');
            $j('#qid_' + tempID + ' .colorPatternClass').addClass('selectedQuestionCompleteColorChange');
	    $j('#qid_' + tempID + ' .surveydefault').addClass('selectedQuestionCompleteColorChange');
        } else {
            tempID = $this.attr('value');
            $j('#qid_' + tempID + ' .primaryQuestionListClass').removeClass('selectedQuestionCompleteColorChange');
            $j('#qid_' + tempID + ' .subQuestionBorderUp').removeClass('selectedQuestionCompleteColorChange').addClass('subQuestionGradUp');
            $j('#qid_' + tempID + ' .subQuestionBorderDown').removeClass('selectedQuestionCompleteColorChange').addClass('subQuestionGradDown');
            $j('#qid_' + tempID + ' .colorPatternClass').removeClass('selectedQuestionCompleteColorChange');
	    $j('#qid_' + tempID + ' .surveydefault').removeClass('selectedQuestionCompleteColorChange');
        }
    });
	/* -----------get Bulk Edit Question Count --------------*/
	$j(document).on('change', '.QuestionDataCheckBox input:checkbox', function () {
		var activeTempID = [],
			archivedTempID = [],
			archiveOnlyArray = $j("#ArchivedQuestionList").val().split(',');
		$j.each($j("#QuestionDataCheckBox input[type=checkbox]:checked"), function (list, $this) {
			if ($j.inArray($this.value, archiveOnlyArray) > -1) {
				archivedTempID.push($this.value);
			} else {
				activeTempID.push($this.value);
			}
		});
		$j("#textHolderDelete span").text(activeTempID.length);
		$j("#textHolderArchive span").text(archivedTempID.length);
		$j("#ArchivedQuestionList").attr("rel", archivedTempID.toString());
		$j("#ArchivedQuestionList").attr("del", activeTempID.toString());
	});

	/* ------------Archive Ajax Call Function------- */
	$j("#bulkArchiveQuestion").on("click", function () {
		var questionIDs = $j.trim($j("#ArchivedQuestionList").attr("rel"));
		if (questionIDs.length > 0) {
			$dialog.dialog('open')
					.html('<table width="100%"><tr><td align="center"><img src="../../images/icons/animated_loading.gif"></td></tr></table>')
					.load('index.cfm?event=questions.archivewindow&questionID=' + questionIDs, {}, function (response, status, xhr) {
                    if (status === "error") {
                        var msg = "Sorry but there was an error.";
                        alert(msg);
                    }
                });
		}
	});
/*---------Bulkdelete Function Call -----------*/
	$j("#bulkDeleteQuestion").on("click", function () {
		var Qn = $j("#textHolderDelete span").text(),
            UserReply,
            qsidList;
		if (Number(Qn)) {
			if(Number(Qn) > 1) {
                UserReply = confirm('Are you sure you want to delete ' + Qn + ' questions');
            } else {
                UserReply = confirm('Are you sure you want to delete ' + Qn + ' question');
            }
			if (UserReply === true) {
				qsidList = $j("#ArchivedQuestionList").attr("del").split(',');
				questionDeleteCall(qsidList);
			}
		}
	});
/* Individual Question delete function call */
	$j(document).on("click", "#questionSingleDeleteIconDiv", function () {
		var qsidList = $j.makeArray($j.trim($j(this).attr('rel'))),
			UserReply = confirm('Are you sure you want to permanently delete this question?');
		if (UserReply === true) {
			questionDeleteCall(qsidList);
		}
	});
/* Restore Current User Selected View */
	$j(document).on("click", ".restoreUserViewState", function () {
		var path = "index.cfm?event=questions.restoreCurrentUserView",
			viewRestore = {
				selectedQuestionList: $j("#restoreUserViewVariable").val(),
				categoryFilter: $j("#categoryFilter").val(),
				selectedCategoryId: $j("#selectedCategoryId").val(),
				createdByFilter: $j("#createdByFilter").val(),
				questionListFilter: $j("#questionListFilter").val(),
				sortByFilterDropdown: $j("#sortByFilterDropdown").val(),
				tablePropertiesFilter: $j("#tablePropertiesFilter").val(),
				advancedOptionPanelState: $j("#advancedOptionPanelState").val(),
				dateFilter: $j("#dateFilter").val(),
				tagFilter: $j("#tagFilter").val(),
				searchTextFilter: $j("#searchTextFilter").val()
			};
		$j.ajax({
			url: path,
			type: "POST",
			data: {
                viewRestore: JSON.stringify(viewRestore)
            }
		});
	});

	/*Calling function for filtering category LAJIN 01*/
	$j("#questionCategoryFilter input[type='radio'][name='questionCategoryFilter']").on("change", function () {
        $j('#categoryFilter').val(this.value);
		getCategoryListing(this.value);
	});
	/*Calling function for category navigator in survey page */
	$j("#categoryFilterDropdown input[type='radio'][name='categoryFilterSelection'], input[name=breakOut]").on("change", function () {
        var breakoutValue = $j("input[name=breakOut]:checked").val(),
			categoryOption = $j("#categoryFilterDropdown input[type='radio'][name='categoryFilterSelection']").filter(function () {
                return $j(this).parent().hasClass('active');
            }).val(),
			path = '';

		if ((categoryOption === '5' || categoryOption === '6') && (breakoutValue === '1')) {
			categoryOption = (categoryOption === '5') ? "3" : "4";
			getCategoryListing(categoryOption);
		} else {
			if (breakoutValue === '1') {
				$j11('#loadingImagedbBC').show();
				$j11('#searchCategory').attr("placeholder", "Search Categories");
				path = "index.cfm?event=questions.showMyCategoryFilter&categoryOption=1&questionStatus=0";
			} else if (breakoutValue === '2') {
				$j11('#loadingImagedbBR').show();
				 $j11('#searchCategory').attr("placeholder", "Search by Form Name");
				path = "index.cfm?event=questions.showAllSurveyListFilter";
			}
			$j('.qnCategoryList').empty();
			$j.ajax({
				url: path,
				type: "POST",
				data: {
					categoryOption: categoryOption
				},
				success: function (data) {
					if (breakoutValue === '1') {
						$j('#qnCategoryList.qnCategoryList').append(data);
						categoryColorChange();//category Colour Change  
						
						//Set GroupSequence in hidden field on page load
						var groupSequenceList = $j(".qnCategoryContent#" + $j('#selectedCategoryId').val()).attr("rel");
						$j("#allQuestionIds").val(groupSequenceList);
						$j11('#loadingImagedbBC').hide();
					} else if (breakoutValue === '2') {
						$j('#surveySelectionList.qnCategoryList').append(data);
						$j11('#loadingImagedbBR').hide();
					}
				}
			});
		}
	});
/*Calling function for sorting question LAJIN 01*/
	$j("#questionFilterDropdown input[type='radio'][name='questionFilterSelection']").on("change", function () {
		$j("#sortByFilterDropdown").val(this.value);
		var categoryId = $j("#selectedCategoryId").val();
        getAllFilterdQuestion();
        //Write alternate code to process questions when show selected question function is selected.
	});
    
    $j("#showQuestionListFilter input[type='radio'][name='questionTypes']").on("change", function () {
		$j("#questionListFilter").val(this.value);
        getCategoryListing($j('#categoryFilter').val());
        getAllFilterdQuestion();
	});

    //to display the child elements of a Type 1 Association element
    $j(document).on('click', '.questionListTablePropertyValue.T1A span ul li', function (e) {
        var clickedElement = $j(this);
        if ($j(clickedElement).children().hasClass('blockview')) {
            $j(clickedElement).children().removeClass('blockview');
            if ($j(clickedElement).hasClass('list_right_arrow')) {
                $j(clickedElement).removeClass('list_right_arrow').addClass('list_down_arrow');
            }
        } else {
            $j(clickedElement).children().addClass('blockview');
            if ($j(clickedElement).hasClass('list_down_arrow')) {
                $j(clickedElement).removeClass('list_down_arrow').addClass('list_right_arrow');
            }
        }
    });
    
    /* Retrieve questions on document load LAJIN 01*/
    loadOptionValues(); //load option based on values retireved from database
	if($j11('#initialloadview').length > 0){
		$j('.optionTable').show();
		$j('.QuestionListContainer').show();
   	 getAllFilterdQuestion();
	 archiveQuestionIdFetch();// Get Archived Question Lists 
	}

    /* Infinite scroll on scroll LAJIN 01*/
	/*$j(window).scroll(function () {
		//if ($isBrowseQuestion || ($j('.optionCellResponse#toggleSelectedButton').hasClass('showOnlySelectedQuestions'))) {
			if ($j(window).scrollTop() + $j(window).height() > $j(document).height() - 10) {
				if (infiniteScrollState) {
					infiniteScrollState = false;
					infiniteScroll();
				}
			}
		//}
	});*/
    
    //To load coldfusion window for Created By Functionality
    $j(document).on('click', '#applyCreatedByFilter', function (e) {
        e.preventDefault();
        saveList('createdByLayout', 'createdByResponse', 'CreatedByWindow', false);
    });
		
		
});