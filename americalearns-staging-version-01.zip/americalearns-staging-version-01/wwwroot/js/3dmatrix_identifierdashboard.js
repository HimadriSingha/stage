/*This to avoid the conflict caused using '$' in both scriptaculous and jquery.*/
if($ === undefined){
	var $ = jQuery.noConflict();
}
$(document).ready(function(){
	//$('.required').hide();
	//$('.optional').hide();
	
	chkImage = "<img src='../../images/icons/check20.gif' style='padding:5px;'>";
});

//3D Matrix Rows Add
function rowsLabelAdd(num,qcount){
	addAnother = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabelAdd("+num+","+qcount+");\">Add Another Row</a></div>";
	moveUp = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabel_moveUp("+num+",upID);\">Move Up</a></div>";
	moveDown = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabel_moveDown("+num+",downID);\">Move Down</a></div>";
	
	count = $("#matrix_"+num+"_row_count").val();
	var rowLength = $("#matrix_"+num+"_row .rowsLabelList tr").length;
	var rowItem = $("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+rowLength+"_name']").val();
	
	stepCounter = qcount-num+1;
	
	if(rowItem.trim() != ""){
		count = parseInt(count)+1;
		$("#matrix_"+num+"_row_count").val(count);
		$("#matrix_"+num+"_row #add_another_row").hide();
		
		var rowCount = $("#matrix_"+num+"_row .rowsLabelList tr").length + 1;
		
		if(rowCount == 2){
			if($("#matrix_"+num+"_row .rowsLabelList tr:eq(0) td div.action").length){
				$("#matrix_"+num+"_row .rowsLabelList tr:eq(0) td div.action").append("<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabelDelete("+num+",1,"+qcount+");\">Delete</a></div>");
			}else{
				$("#matrix_"+num+"_row .rowsLabelList tr:eq(0) td").append("<div class='action' style='padding-top:10px;'><div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabelDelete("+num+",1,"+qcount+");\">Delete</a></div></div>");
			}
		}
		/*onfocusout=\"javascript:validate_empty("+num+","+rowCount+",'row');\"*/
		$("#matrix_"+num+"_row .rowsLabelList").append("<tr class='rowLabel_"+rowCount+"'><td><input type='text' name='matrix_"+num+"_row_"+rowCount+"_name' id='matrix_"+num+"_row_"+rowCount+"_name' value='' style='width:400px; height:15px; padding:5px;' onChange=\"javascript:rowsOnChange("+num+",this,"+rowCount+");\"><div class='action' style='padding-top:10px;'>"+addAnother+"<div style='float:left; padding:0px 15px 15px 0px;'><a href='javascript:rowsLabelDelete("+num+","+rowCount+","+qcount+")'>Delete</a></div></div></td></tr>");
		
		var rowCount = $("#matrix_"+num+"_row .rowsLabelList tr").length;
		
		if(rowCount == 2){
			var moveUp = moveUp.replace("upID","2");
			var moveDown = moveDown.replace("downID","1");		
			$("#matrix_"+num+"_row .rowsLabelList tr:eq(0) td:eq(0) div.action").find("div:first-child").before(moveDown);
			$("#matrix_"+num+"_row .rowsLabelList tr:eq(1) td:eq(0) div.action").find("div:first-child").after(moveUp);
		}else{
			for(i = 1; i < rowCount; i++){
				moveUp = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabel_moveUp("+num+",upID);\">Move Up</a></div></div>";
				moveDown = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabel_moveDown("+num+",downID);\">Move Down</a></div></div>";
				var moveUp = moveUp.replace("upID",parseInt(i+1));
				var moveDown =  moveDown.replace("downID",parseInt(i+1));
				$("#matrix_"+num+"_row .rowsLabelList tr:eq("+i+") td:eq(0) div.action").html(moveUp+moveDown+"<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabelDelete("+num+","+parseInt(i+1)+","+qcount+");\">Delete</a></div>");
				$("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rowCount-1)+") td:eq(0) div.action").html(addAnother+moveUp+"<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabelDelete("+num+","+parseInt(i+1)+","+qcount+");\">Delete</a></div>");
			}
		}
	}else{
		alert("[Step "+stepCounter+"]: Before creating a new row, please enter a name for the blank row.");
		$("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+rowLength+"_name']").val("");
		$("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+rowLength+"_name']").focus();
	}	
}

//3D Matrix Rows Moveup functionality
function rowsLabel_moveUp(num,rownumber){
	
	var rowChoiceText = $("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+rownumber+"_name']").val();
	var rowChoiceTextnospace = rowChoiceText.replace(/ /g, "");
	var rowChoiceText_up = $("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+parseInt(rownumber-1)+"_name']").val();
	var rowChoiceTextnospace_up = rowChoiceText_up.replace(/ /g, "");
	
	if(rowChoiceTextnospace == ""){
		alert("Please enter a name for the blank row.");
		$("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+rownumber+"_name']").focus();
	}
	if(rowChoiceTextnospace_up == ""){
		alert("Please enter a name for the blank row.");
		$("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+parseInt(rownumber-1)+"_name']").focus();
	}
	if(rowChoiceTextnospace != "" && rowChoiceTextnospace_up != ""){
		var moveUp = $("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-1)+") input[type='text']").attr('value');
		var moveDown = $("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-2)+") input[type='text']").attr('value');
		$("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-2)+") td:eq(0) input[type='text']").attr('value',moveUp);
		$("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-1)+") td:eq(0) input[type='text']").attr('value',moveDown);
		
		//Grid Section
		var grid_moveUp = $("#matrix_"+num+"_grid .table-bordered tr:eq("+parseInt(rownumber)+")").html();
		var grid_moveDown = $("#matrix_"+num+"_grid .table-bordered tr:eq("+parseInt(rownumber-1)+")").html();
		$("#matrix_"+num+"_grid .table-bordered tr:eq("+parseInt(rownumber-1)+")").html(grid_moveUp);
		$("#matrix_"+num+"_grid .table-bordered tr:eq("+parseInt(rownumber)+")").html(grid_moveDown);
		 
		$("#matrix_"+num+"_grid .table-bordered").find("tr#"+parseInt(rownumber)+" td.gridtd").each(function(){
			var attrName = $(this).find("input").attr("name");
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[3] = parseInt(rownumber);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$(this).find("input").attr("name", newName);
			
			var attrID = $(this).attr("onclick");
			newID = attrID.split(",");
			newID[1] = parseInt(rownumber);
			var on_click_td = ""+newID[0]+","+newID[1]+","+newID[2]+"";
			$(this).attr('onclick', on_click_td);
		});
		
		$("#matrix_"+num+"_grid .table-bordered").find("tr#"+parseInt(rownumber-1)+" td.gridtd").each(function(){
			var attrName = $(this).find("input").attr("name");
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[3] = parseInt(rownumber-1);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$(this).find("input").attr("name", newName);
			
			var attrID = $(this).attr("onclick");
			newID = attrID.split(",");
			newID[1] = parseInt(rownumber-1);
			var on_click_td = ""+newID[0]+","+newID[1]+","+newID[2]+"";
			$(this).attr('onclick', on_click_td);
		});
	}
}

//3D Matrix Rows Movedown functionality
function rowsLabel_moveDown(num,rownumber){
	
	var rowChoiceText = $("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+parseInt(rownumber)+"_name']").val();
	var rowChoiceTextnospace = rowChoiceText.replace(/ /g, "");
	var rowChoiceText_down = $("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+parseInt(rownumber+1)+"_name']").val();
	var rowChoiceTextnospace_down = rowChoiceText_down.replace(/ /g, "");
	
	if(rowChoiceTextnospace == ""){
		alert("Please enter a name for the blank row.");
		$("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+parseInt(rownumber)+"_name']").focus();
	}
	if(rowChoiceTextnospace_down == ""){
		alert("Please enter a name for the blank row.");
		$("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+parseInt(rownumber+1)+"_name']").focus();
	}
	if(rowChoiceTextnospace != "" && rowChoiceTextnospace_down !=""){
		var moveDown = $("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-1)+") input[type='text']").attr('value');
		var moveUp = $("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber)+") input[type='text']").attr('value');
		$("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber)+") td:eq(0) input[type='text']").attr('value',moveDown);
		$("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rownumber-1)+") td:eq(0) input[type='text']").attr('value',moveUp);
		
		//Grid Section
		var grid_moveDown = $("#matrix_"+num+"_grid .table-bordered tr:eq("+parseInt(rownumber)+")").html();
		var grid_moveUp = $("#matrix_"+num+"_grid .table-bordered tr:eq("+parseInt(rownumber+1)+")").html();
		$("#matrix_"+num+"_grid .table-bordered tr:eq("+parseInt(rownumber+1)+")").html(grid_moveDown);
		$("#matrix_"+num+"_grid .table-bordered tr:eq("+parseInt(rownumber)+")").html(grid_moveUp);
		
		$("#matrix_"+num+"_grid .table-bordered").find("tr#"+parseInt(rownumber)+" td.gridtd").each(function(){
			var attrName = $(this).find("input").attr("name");
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[3] = parseInt(rownumber);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$(this).find("input").attr("name", newName);
			
			var attrID = $(this).attr("onclick");
			newID = attrID.split(",");
			newID[1] = parseInt(rownumber);
			var on_click_td = ""+newID[0]+","+newID[1]+","+newID[2]+"";
			$(this).attr('onclick', on_click_td);
		});
		
		$("#matrix_"+num+"_grid .table-bordered").find("tr#"+parseInt(rownumber+1)+" td.gridtd").each(function(){
			var attrName = $(this).find("input").attr("name");
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[3] = parseInt(rownumber+1);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$(this).find("input").attr("name", newName);
			
			var attrID = $(this).attr("onclick");
			newID = attrID.split(",");
			newID[1] = parseInt(rownumber+1);
			var on_click_td = ""+newID[0]+","+newID[1]+","+newID[2]+"";
			$(this).attr('onclick', on_click_td);
		});
	}
}

//3D Matrix Rows delete
function rowsLabelDelete(num,id,qcount){
	addAnother = "<div style='float:left; padding:0px 15px 15px 0px;'><a href='javascript:rowsLabelAdd("+num+","+qcount+");'>Add Another Row</a></div>";
	moveUp = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabel_moveUp("+num+",upID);\">Move Up</a></div>";
	moveDown = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabel_moveDown("+num+",downID);\">Move Down</a></div>";
	
	$("#matrix_"+num+"_row .rowsLabelList .rowLabel_"+id).remove();
	
	count = $("#matrix_"+num+"_row_count").val();
	newCount = parseInt(count)-1;
	$("#matrix_"+num+"_row_count").val(newCount);
	
	var rowCount = $("#matrix_"+num+"_row .rowsLabelList tr").length;
	
	var i = 1;
	$("#matrix_"+num+"_row .rowsLabelList tr").each(function(){
		$(this).attr('class','rowLabel_'+i);
 		$(this).find("td:eq(0) a").attr('href','javascript:rowsLabelDelete('+num+','+i+','+qcount+')');
		$(this).find("td:eq(0) input").attr('name','matrix_'+num+'_row_'+i+'_name');
		$(this).find("td:eq(0) input").attr('id','matrix_'+num+'_row_'+i+'_name');
		var on_change_input = "javascript:rowsOnChange("+num+",this,"+i+");";
		$(this).find("td:eq(0) input").attr('onchange', on_change_input);
 		i = i+1;
 	});
		
    var j = 1;
    $("#matrix_"+num+"_row .rowsLabelList tr").each(function(){
		if(j == 2){
			var moveUp = moveUp.replace("upID","2");
			var moveDown = moveDown.replace("downID","1");
			$("#matrix_"+num+"_row .rowsLabelList tr:eq(0) td:eq(0) div.action").append(moveDown);
			$("#matrix_"+num+"_row .rowsLabelList tr:eq(1) td:eq(0) div.action").append(moveUp);
		}else{
			for(j = 1; j < rowCount; j++){
				moveUp = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabel_moveUp("+num+",upID);\">Move Up</a></div></div>";
				moveDown = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabel_moveDown("+num+",downID);\">Move Down</a></div></div>";
				var moveUp = moveUp.replace("upID",parseInt(j+1));
				var moveDown =  moveDown.replace("downID",parseInt(j+1));
				$("#matrix_"+num+"_row .rowsLabelList tr:eq(0) td:eq(0) div.action").html("<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabel_moveDown("+num+",1);\">Move Down</a></div><div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabelDelete("+num+",1,"+qcount+");\">Delete</a></div>");
				$("#matrix_"+num+"_row .rowsLabelList tr:eq("+j+") td:eq(0) div.action").html(moveUp+moveDown+"<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabelDelete("+num+","+parseInt(j+1)+","+qcount+");\">Delete</a></div>");
				$("#matrix_"+num+"_row .rowsLabelList tr:eq("+parseInt(rowCount-1)+") td:eq(0) div.action").html(addAnother+moveUp+"<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:rowsLabelDelete("+num+","+parseInt(j+1)+","+qcount+");\">Delete</a></div>");
			}
			
			if(rowCount == 1){
				add_another = "<div id='add_another_row' style='margin-top:5px; margin-bottom:20px;'><a href='javascript:rowsLabelAdd("+num+","+qcount+");'>Add Another Row</a></div>"
				$("#matrix_"+num+"_row .rowsLabelList .rowLabel_1 div.action div").remove();
				$("#matrix_"+num+"_row .rowsLabelList .rowLabel_1 div.action").html(add_another);
			}	
		}
	 		j = j+1;
			
  	 });
	 
	 //Grid Section
	 $("#matrix_"+num+"_grid .table-bordered").find("tr#"+id+"").remove();
	 
	 for(k = id; k <= newCount; k++){
		$("#matrix_"+num+"_grid .table-bordered").find("tr#"+parseInt(k+1)+"").attr('id', k);
		
		$("#matrix_"+num+"_grid .table-bordered").find("tr#"+parseInt(k)+" td.gridtd").each(function(){
			var attrName = $(this).find("input").attr("name");
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[3] = parseInt(k);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$(this).find("input").attr("name", newName);
			
			var attrID = $(this).attr("onclick");
			newID = attrID.split(",");
			newID[1] = parseInt(k);
			var on_click_td = ""+newID[0]+","+newID[1]+","+newID[2]+"";
			$(this).attr('onclick', on_click_td);
		});
	}
}

//3D Matrix Columns
function showAddAnother(num){
	var col = $("#matrix_"+num+"_column input[name='matrix_"+num+"_column_1_name']").val();
	
	if(col !== ''){
		$("#matrix_"+num+"_column #add_another_column").show();
	}else{
		$("#matrix_"+num+"_column #add_another_column").hide();
	}
}

function removeDuplicates(num,Numvalue,sid){
	if($('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #'+sid).length > 1){
		$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' .columnsLabelList tr:eq(1) td #'+sid).first().remove();
	}
}

function questionTypeChange(num,select){
	var attrID = select.id;
	Numvalue = attrID.match(/\d+$/); //Numvalue = attrName.match(/\d+/g); for finding all digits.
	//console.log(Numvalue);
	var qntype = select.value;
	//console.log(qntype);
	
	if(qntype != ''){
		$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' div#questionTypeResp_'+Numvalue).show();
		
		if(qntype == 'Free Text Response'){
			var sid = 'freeText_'+Numvalue;
			removeDuplicates(num,Numvalue,sid);
			//$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).is(':visible')
			
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).show();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #textBox_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue).hide();
			
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue+' input:eq(0)').attr('name', 'matrix_'+num+'_freeText_'+Numvalue+'_name');
		}
		if(qntype == 'Text Box'){
			var sid = 'textBox_'+Numvalue;
			removeDuplicates(num,Numvalue,sid);
			
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #textBox_'+Numvalue).show();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue).hide();
		}
		if(qntype == 'Quantitative Checkbox without Other Option' || qntype == 'Quantitative Checkbox with Other Option'){
			if(qntype == 'Quantitative Checkbox without Other Option'){
				var sid = 'quanChkbox_'+Numvalue;
				removeDuplicates(num,Numvalue,sid);
				
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue).show();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #textBox_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue).hide();
				
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue+' input:eq(0)').attr('name', 'matrix_'+num+'_quanCheckFrom_'+Numvalue+'_name');
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue+' input:eq(1)').attr('name', 'matrix_'+num+'_quanCheckTo_'+Numvalue+'_name');	
			}else{
				var sid = 'quanChkboxWithOther_'+Numvalue;
				removeDuplicates(num,Numvalue,sid);
				
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue).show();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #textBox_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue).hide();
				
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue+' input:eq(0)').attr('name', 'matrix_'+num+'_quanCheckWithOtherFrom_'+Numvalue+'_name');
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue+' input:eq(1)').attr('name', 'matrix_'+num+'_quanCheckWithOtherTo_'+Numvalue+'_name');
			}
		}
		if(qntype == 'Quantitative Drop-Down' || qntype == 'Quantitative Radio'){
			if(qntype == 'Quantitative Drop-Down'){
				var sid = 'quanDropDown_'+Numvalue;
				removeDuplicates(num,Numvalue,sid);
				
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue).show();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #textBox_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue).hide();
				
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue+' input:eq(0)').attr('name', 'matrix_'+num+'_quanDropDownFrom_'+Numvalue+'_name');
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue+' input:eq(1)').attr('name', 'matrix_'+num+'_quanDropDownTo_'+Numvalue+'_name');
			}else{
				var sid = 'quanRadio_'+Numvalue;
				removeDuplicates(num,Numvalue,sid);
				
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue).show();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #textBox_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue).hide();
			
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue+' input:eq(0)').attr('name', 'matrix_'+num+'_quanRadioFrom_'+Numvalue+'_name');
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue+' input:eq(1)').attr('name', 'matrix_'+num+'_quanRadioTo_'+Numvalue+'_name');
			}
		}
		if(qntype == 'Qualitative Checkbox without Other Option' || qntype == 'Qualitative Checkbox with Other Option'){
			if(qntype == 'Qualitative Checkbox without Other Option'){
				var sid = 'qualChkbox_'+Numvalue;
				removeDuplicates(num,Numvalue,sid);
				
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue).show();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #textBox_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue).hide();
				
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue+' textarea').attr('name', 'matrix_'+num+'_qualCheck_'+Numvalue+'_name');
			}else{
				var sid = 'qualChkboxWithOther_'+Numvalue;
				removeDuplicates(num,Numvalue,sid);
				
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue).show();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #textBox_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue).hide();
				
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue+' textarea').attr('name', 'matrix_'+num+'_qualCheckWithOther_'+Numvalue+'_name');
			}
		}
		if(qntype == 'Qualitative Drop-Down' || qntype == 'Qualitative Radio'){
			if(qntype == 'Qualitative Drop-Down'){
				var sid = 'qualDropDown_'+Numvalue;
				removeDuplicates(num,Numvalue,sid);
				
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue).show();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #textBox_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue).hide();
				
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue+' textarea').attr('name', 'matrix_'+num+'_qualDropDown_'+Numvalue+'_name');
			}else{
				var sid = 'qualRadio_'+Numvalue;
				removeDuplicates(num,Numvalue,sid);
				
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue).show();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #textBox_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue).hide();
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue).hide();
				
				$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue+' textarea').attr('name', 'matrix_'+num+'_qualRadio_'+Numvalue+'_name');
			}
		}
		if(qntype == 'Time5Min' || qntype == 'Time5Min_1HourMax' || qntype == 'Time15Min_20HourMax' || qntype == 'Time15Min_300HourMax' || qntype == 'Time15Min' || qntype == 'Time30Min' || qntype == 'Time60Min' || qntype == 'Time5Min_75HourMax' || qntype == 'Time5Min_300HourMax' || qntype == 'Time30Min_500HourMax'){/* SQM-455 */ /* ADMINFUNCT-192 */ /* SQM-490 */
			var sid = 'timeQns_'+Numvalue;
			removeDuplicates(num,Numvalue,sid);
			
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue).show();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #freeText_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #textBox_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkbox_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanChkboxWithOther_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanDropDown_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #quanRadio_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkbox_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualChkboxWithOther_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualDropDown_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #qualRadio_'+Numvalue).hide();
			$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' #timeQns_'+Numvalue+' input').attr('name', 'matrix_'+num+'_chkSpecialTimeSeries_'+Numvalue+'_name'); //Added For SurveyComp-115
		}
	}
	else{
		$('#matrix_'+num+'_column #columnsAdd_'+Numvalue+' div#questionTypeResp_'+Numvalue).hide();
	}
}

//3D Matrix Columns Add
function columnsLabelAdd(num,qcount){
	addAnother = "<div style='float:left; padding:0px 15px 15px 0px;'><a href='javascript:columnsLabelAdd("+num+","+qcount+");'>Add Another Column</a></div>";
	moveUp = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:columnsLabel_moveUp("+num+",upID);\">Move Up</a></div>";
	moveDown = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:columnsLabel_moveDown("+num+",downID);\">Move Down</a></div>";
	
	count = $("#matrix_"+num+"_column_count").val();
	
	var columnItem = $(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+count+"_name']").val();
	var qnType = $(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList select[name='matrix_"+num+"_questionType_"+count+"_name']").val();
	
	stepCounter = qcount-num+1;
	
	if(columnItem.trim() != "" && qnType != ""){
		
		var validationstatus = matrixColumnValidation(num,qnType,count,stepCounter);
		
		if(validationstatus == true){
			count = parseInt(count) + 1;
			$("#matrix_" + num + "_column_count").val(count);
			$("#matrix_" + num + "_column #add_another_column").remove();
			
			$('#3dMatrix_Step2_add .3DMatrixStep2').each(function(){
				var attrID = this.id;
				Numvalue = attrID.match(/\d+$/);
				var newID = attrID.replace('_' + Numvalue, '_' + count);
				$(this).attr('id', newID);
			});
			
			var labelText = stringifyNumber(count);
			$("#3dMatrix_Step2_add #columnsAdd_" + count + " span#colLabel_" + count).text(labelText + " Column's Label:");
			var qnTypeText = stringifyNumber(count);
			$("#3dMatrix_Step2_add #columnsAdd_" + count + " span#colQnType_" + count).text(qnTypeText + " Column's Question Type:");
			
			$('#3dMatrix_Step2_add .3DMatrixStep2Name').each(function(){
				var attrName = this.name;
				newStr = attrName.split("_");
				newStr[1] = num;
				newStr[3] = count;
				var newName = "" + newStr[0] + "_" + newStr[1] + "_" + newStr[2] + "_" + newStr[3] + "_" + newStr[4] + "";
				$(this).attr('name', newName);
			});
			
			content = $('#3dMatrix_Step2_add').html();
			$('.3dMatrix_Step2 #matrix_' + num + '_column').append(content);
			
			var on_change_input = "javascript:columnsOnChange(" + num + ",this," + count + ");";
			$(".3dMatrix_Step2 #matrix_" + num + "_column #columnsAdd_" + count + " .columnsLabelList input[name='matrix_" + num + "_column_" + count + "_name']").attr('onchange', on_change_input);
			
			/*
			 var on_focusout_input = "javascript:validate_empty(" + num + "," + count +  ",'column');";
			$(".3dMatrix_Step2 #matrix_" + num + "_column #columnsAdd_" + count + " .columnsLabelList input[name='matrix_" + num + "_column_" + count + "_name']").attr('onfocusout', on_focusout_input);
			*/
			var on_change_select = "javascript:questionTypeChange(" + num + ",this);";
			$(".3dMatrix_Step2 #matrix_" + num + "_column #columnsAdd_" + count + " .columnsLabelList select").attr('onchange', on_change_select);
			
			if ($('.3dMatrix_Step2 #matrix_' + num + '_column .add_Another').length > 0) {
				$('.3dMatrix_Step2 #matrix_' + num + '_column .add_Another').remove();
			}
			
			$("#matrix_" + num + "_column #columnsAdd_" + count + " .columnsLabelList tr:eq(1) td").append("<div class='action' style='padding-top:10px;'>" + addAnother + "<div style='float:left; padding:0px 15px 15px 0px;'><a href='javascript:columnsLabelDelete(" + num + "," + count + "," + qcount + ");'>Delete</a></div></div>");
			
			if(count == 2){
				if ($("#matrix_" + num + "_column #columnsAdd_1 .columnsLabelList tr:eq(1) td div.action").length) {
					$('.3dMatrix_Step2 #matrix_' + num + '_column #columnsAdd_1 .columnsLabelList .action').remove();
				}
				var moveUp = moveUp.replace("upID", "2");
				var moveDown = moveDown.replace("downID", "1");
				$("#matrix_" + num + "_column .columnsLabelList tr:eq(1) td").append("<div class='action' style='padding-top:10px;'><div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:columnsLabelDelete(" + num + ",1," + qcount + ");\">Delete</a></div></div>");
				$("#matrix_" + num + "_column .columnsLabelList tr:eq(1) td:eq(0) div.action").find("div:first-child").before(moveDown);
				$("#matrix_" + num + "_column #columnsAdd_" + count + " .columnsLabelList tr:eq(1) td:eq(0) div.action").find("div:first-child").after(moveUp);
				
			}
			else {
				for (i = 2; i < count; i++) {
					moveUp = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:columnsLabel_moveUp(" + num + ",upID);\">Move Up</a></div></div>";
					moveDown = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:columnsLabel_moveDown(" + num + ",downID);\">Move Down</a></div></div>";
					var moveUp = moveUp.replace("upID", parseInt(i));
					var moveDown = moveDown.replace("downID", parseInt(i));
					$("#matrix_" + num + "_column #columnsAdd_" + parseInt(i) + " .columnsLabelList tr:eq(1) td:eq(0) div.action").html(moveUp + moveDown + "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:columnsLabelDelete(" + num + "," + parseInt(i) + ","+qcount+");\">Delete</a></div>");
					
					move_Up = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:columnsLabel_moveUp(" + num + ",upID);\">Move Up</a></div></div>";
					var move_Up = move_Up.replace("upID", parseInt(i + 1));
					$("#matrix_" + num + "_column #columnsAdd_" + parseInt(i + 1) + " .columnsLabelList tr:eq(1) td:eq(0) div.action").html(addAnother + move_Up + "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:columnsLabelDelete(" + num + "," + parseInt(i + 1) + ","+qcount+");\">Delete</a></div>");
				}
			}
		}
	}else{
		if(columnItem.trim() == ""){
			alert("[Step "+stepCounter+"]: Please enter a name for the column you just created before adding a new one.");
			$("#matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+count+"_name']").val("");
			$("#matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+count+"_name']").focus();
		}else{
			alert("[Step "+stepCounter+"]: Before adding another column, please select a Question Type for the columns you already created.");
			$("#matrix_"+num+"_column .columnsLabelList select[name='matrix_"+num+"_questionType_"+count+"_name']").focus();
		}
	}
}

//3D Matrix Columns MoveUp
function columnsLabel_moveUp(num,colnumber){
	
	var columnChoiceText = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" .columnsLabelList input[name='matrix_"+num+"_column_"+colnumber+"_name']").val();
	var columnChoiceTextnospace = columnChoiceText.replace(/ /g, "");
	var columnChoiceText_up = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" .columnsLabelList input[name='matrix_"+num+"_column_"+parseInt(colnumber-1)+"_name']").val();
	var columnChoiceTextnospace_up = columnChoiceText_up.replace(/ /g, "");

	if(columnChoiceTextnospace == ""){
		alert("Please enter a name for the blank column.");
		$(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+colnumber+"_name']").focus();
	}
	if(columnChoiceTextnospace_up == ""){
		alert("Please enter a name for the blank column.");
		$(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+parseInt(colnumber-1)+"_name']").focus();
	}
	if(columnChoiceTextnospace != "" && columnChoiceTextnospace_up != ""){
		var attrInputValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" .columnsLabelList tr:eq(0) input").attr('value');
		var attrSelectValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" .columnsLabelList select").attr('value');
		var attrFreeTextValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #freeText_"+colnumber+" input:eq(0)").attr('value');
		var attrQuanCheckFromValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkbox_"+colnumber+" input:eq(0)").attr('value');
		var attrQuanCheckToValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkbox_"+colnumber+" input:eq(1)").attr('value');
		var attrQuanCheckWithOtherFromValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkboxWithOther_"+colnumber+" input:eq(0)").attr('value');
		var attrQuanCheckWithOtherToValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkboxWithOther_"+colnumber+" input:eq(1)").attr('value');
		var attrQuanDropDownFromValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanDropDown_"+colnumber+" input:eq(0)").attr('value');
		var attrQuanDropDownToValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanDropDown_"+colnumber+" input:eq(1)").attr('value');
		var attrQuanRadioFromValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanRadio_"+colnumber+" input:eq(0)").attr('value');
		var attrQuanRadioToValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanRadio_"+colnumber+" input:eq(1)").attr('value');
		var attrQualCheckValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualChkbox_"+colnumber+" textarea:visible").val();
		var attrQualCheckWithOtherValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualChkboxWithOther_"+colnumber+" textarea:visible").val();
		var attrQualDropDownValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualDropDown_"+colnumber+" textarea:visible").val();
		var attrQualRadioValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualRadio_"+colnumber+" textarea:visible").val();
		
		var attrInputValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" .columnsLabelList tr:eq(0) input").attr('value');
		var attrSelectValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" .columnsLabelList select").attr('value');
		var attrFreeTextValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #freeText_"+parseInt(colnumber-1)+" input:eq(0)").attr('value');
		var attrQuanCheckFromValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanChkbox_"+parseInt(colnumber-1)+" input:eq(0)").attr('value');
		var attrQuanCheckToValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanChkbox_"+parseInt(colnumber-1)+" input:eq(1)").attr('value');
		var attrQuanCheckWithOtherFromValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanChkboxWithOther_"+parseInt(colnumber-1)+" input:eq(0)").attr('value');
		var attrQuanCheckWithOtherToValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanChkboxWithOther_"+parseInt(colnumber-1)+" input:eq(1)").attr('value');
		var attrQuanDropDownFromValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanDropDown_"+parseInt(colnumber-1)+" input:eq(0)").attr('value');
		var attrQuanDropDownToValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanDropDown_"+parseInt(colnumber-1)+" input:eq(1)").attr('value');
		var attrQuanRadioFromValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanRadio_"+parseInt(colnumber-1)+" input:eq(0)").attr('value');
		var attrQuanRadioToValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanRadio_"+parseInt(colnumber-1)+" input:eq(1)").attr('value');
		var attrQualCheckValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #qualChkbox_"+parseInt(colnumber-1)+" textarea:visible").val();
		var attrQualCheckWithOtherValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #qualChkboxWithOther_"+parseInt(colnumber-1)+" textarea:visible").val();
		var attrQualDropDownValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #qualDropDown_"+parseInt(colnumber-1)+" textarea:visible").val();
		var attrQualRadioValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #qualRadio_"+parseInt(colnumber-1)+" textarea:visible").val();
	
		var moveUp = $('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber)).html();
		var moveDown = $('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber-1)).html();
		$('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber-1)).html(moveUp);
		$('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber)).html(moveDown);
		
		var action1 = $("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber)+" .columnsLabelList tr:eq(1) td:eq(0) div.action").html();
		var action2 = $("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" .columnsLabelList tr:eq(1) td:eq(0) div.action").html();
		$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber)+" .columnsLabelList tr:eq(1) td:eq(0) div.action").html(action2);
		$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" .columnsLabelList tr:eq(1) td:eq(0) div.action").html(action1);
		
		var on_change_input_up = "javascript:columnsOnChange("+num+",this,"+parseInt(colnumber-1)+");";
		var on_change_input_down = "javascript:columnsOnChange("+num+",this,"+parseInt(colnumber)+");";
		$('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber-1)+' .columnsLabelList input').attr('onchange', on_change_input_up);
		$('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber)+' .columnsLabelList input').attr('onchange', on_change_input_down);
		
		$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber)+" .3DMatrixStep2").each(function(){
			var attrID = this.id;
			Numvalue = attrID.match(/\d+$/);
			var newID = attrID.replace('_'+Numvalue,'_'+parseInt(colnumber));
			$(this).attr('id', newID);
			
			var labelText = stringifyNumber(colnumber);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" span#colLabel_"+colnumber).text(labelText+" Column's Label:");
			var qnTypeText = stringifyNumber(colnumber);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" span#colQnType_"+colnumber).text(qnTypeText+" Column's Question Type:");
			
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" .columnsLabelList tr:eq(0) input").attr('value', attrInputValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" .columnsLabelList select").attr('value', attrSelectValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #freeText_"+colnumber+" input:eq(0)").attr('value', attrFreeTextValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkbox_"+colnumber+" input:eq(0)").attr('value', attrQuanCheckFromValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkbox_"+colnumber+" input:eq(1)").attr('value', attrQuanCheckToValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkboxWithOther_"+colnumber+" input:eq(0)").attr('value', attrQuanCheckWithOtherFromValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkboxWithOther_"+colnumber+" input:eq(1)").attr('value', attrQuanCheckWithOtherToValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanDropDown_"+colnumber+" input:eq(0)").attr('value', attrQuanDropDownFromValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanDropDown_"+colnumber+" input:eq(1)").attr('value', attrQuanDropDownToValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanRadio_"+colnumber+" input:eq(0)").attr('value', attrQuanRadioFromValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanRadio_"+colnumber+" input:eq(1)").attr('value', attrQuanRadioToValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualChkbox_"+colnumber+" textarea").val(attrQualCheckValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualChkboxWithOther_"+colnumber+" textarea").val(attrQualCheckWithOtherValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualDropDown_"+colnumber+" textarea").val(attrQualDropDownValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualRadio_"+colnumber+" textarea").val(attrQualRadioValue2);
	 	});
		
		$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber)+" .3DMatrixStep2Name").each(function(){
			var attrName = this.name;
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[3] = parseInt(colnumber);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$(this).attr('name', newName);
			
	 	});
		
		$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" .3DMatrixStep2").each(function(){
			var attrID = this.id;
			Numvalue = attrID.match(/\d+$/);
			var newID = attrID.replace('_'+Numvalue,'_'+parseInt(colnumber-1));
			$(this).attr('id', newID);
			
			var labelText = stringifyNumber(parseInt(colnumber-1));
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" span#colLabel_"+parseInt(colnumber-1)).text(labelText+" Column's Label:");
			var qnTypeText = stringifyNumber(parseInt(colnumber-1));
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" span#colQnType_"+parseInt(colnumber-1)).text(qnTypeText+" Column's Question Type:");
			
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" .columnsLabelList tr:eq(0) input").attr('value', attrInputValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" .columnsLabelList select").attr('value', attrSelectValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #freeText_"+parseInt(colnumber-1)+" input:eq(0)").attr('value', attrFreeTextValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanChkbox_"+parseInt(colnumber-1)+" input:eq(0)").attr('value', attrQuanCheckFromValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanChkbox_"+parseInt(colnumber-1)+" input:eq(1)").attr('value', attrQuanCheckToValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanChkboxWithOther_"+parseInt(colnumber-1)+" input:eq(0)").attr('value', attrQuanCheckWithOtherFromValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanChkboxWithOther_"+parseInt(colnumber-1)+" input:eq(1)").attr('value', attrQuanCheckWithOtherToValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanDropDown_"+parseInt(colnumber-1)+" input:eq(0)").attr('value', attrQuanDropDownFromValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanDropDown_"+parseInt(colnumber-1)+" input:eq(1)").attr('value', attrQuanDropDownToValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanRadio_"+parseInt(colnumber-1)+" input:eq(0)").attr('value', attrQuanRadioFromValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #quanRadio_"+parseInt(colnumber-1)+" input:eq(1)").attr('value', attrQuanRadioToValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #qualChkbox_"+parseInt(colnumber-1)+" textarea").val(attrQualCheckValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #qualChkboxWithOther_"+parseInt(colnumber-1)+" textarea").val(attrQualCheckWithOtherValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #qualDropDown_"+parseInt(colnumber-1)+" textarea").val(attrQualDropDownValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" #qualRadio_"+parseInt(colnumber-1)+" textarea").val(attrQualRadioValue1);
	 	});
		
		$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber-1)+" .3DMatrixStep2Name").each(function(){
			var attrName = this.name;
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[3] = parseInt(colnumber-1);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$(this).attr('name', newName);
	 	});
		
		//Grid Section
		$("#matrix_"+num+"_grid .table-bordered tr").each(function(){
			var grid_moveUp = $(this).find("td#"+parseInt(colnumber)+"").html();
			var grid_moveDown = $(this).find("td#"+parseInt(colnumber-1)+"").html();
			$(this).find("td#"+parseInt(colnumber-1)+"").html(grid_moveUp);
			$(this).find("td#"+parseInt(colnumber)+"").html(grid_moveDown);
		});
		
		$("#matrix_"+num+"_grid .table-bordered").find("tr td#"+parseInt(colnumber)+".gridtd").each(function(){
			var attrName = $(this).find("input").attr("name");
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[4] = parseInt(colnumber);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$(this).find("input").attr("name", newName);
		});
		
		$("#matrix_"+num+"_grid .table-bordered").find("tr td#"+parseInt(colnumber-1)+".gridtd").each(function(){
			var attrName = $(this).find("input").attr("name");
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[4] = parseInt(colnumber-1);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$(this).find("input").attr("name", newName);
		});
	}
}

//3D Matrix Columns MoveDown
function columnsLabel_moveDown(num,colnumber){
	
	var columnChoiceText = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber)+" .columnsLabelList input[name='matrix_"+num+"_column_"+parseInt(colnumber)+"_name']").val();
	var columnChoiceTextnospace = columnChoiceText.replace(/ /g, "");
	var columnChoiceText_down = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" .columnsLabelList input[name='matrix_"+num+"_column_"+parseInt(colnumber+1)+"_name']").val();
	var columnChoiceTextnospace_down = columnChoiceText_down.replace(/ /g, "");

	if (columnChoiceTextnospace == ""){
		alert("Please enter a name for the blank column.");
		$(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+parseInt(colnumber)+"_name']").focus();
	}
	if (columnChoiceTextnospace_down == ""){
		alert("Please enter a name for the blank column.");
		$(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+parseInt(colnumber+1)+"_name']").focus();
	}
	if (columnChoiceTextnospace != "" && columnChoiceTextnospace_down !=""){
		var attrInputValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" .columnsLabelList tr:eq(0) input").attr('value');
		var attrSelectValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" .columnsLabelList select").attr('value');
		var attrFreeTextValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #freeText_"+colnumber+" input:eq(0)").attr('value');
		var attrQuanCheckFromValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkbox_"+colnumber+" input:eq(0)").attr('value');
		var attrQuanCheckToValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkbox_"+colnumber+" input:eq(1)").attr('value');
		var attrQuanCheckWithOtherFromValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkboxWithOther_"+colnumber+" input:eq(0)").attr('value');
		var attrQuanCheckWithOtherToValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkboxWithOther_"+colnumber+" input:eq(1)").attr('value');
		var attrQuanDropDownFromValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanDropDown_"+colnumber+" input:eq(0)").attr('value');
		var attrQuanDropDownToValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanDropDown_"+colnumber+" input:eq(1)").attr('value');
		var attrQuanRadioFromValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanRadio_"+colnumber+" input:eq(0)").attr('value');
		var attrQuanRadioToValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanRadio_"+colnumber+" input:eq(1)").attr('value');
		var attrQualCheckValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualChkbox_"+colnumber+" textarea:visible").val();
		var attrQualCheckWithOtherValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualChkboxWithOther_"+colnumber+" textarea:visible").val();
		var attrQualDropDownValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualDropDown_"+colnumber+" textarea:visible").val();
		var attrQualRadioValue1 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualRadio_"+colnumber+" textarea:visible").val();
		
		var attrInputValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" .columnsLabelList tr:eq(0) input").attr('value');
		var attrSelectValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" .columnsLabelList select").attr('value');
		var attrFreeTextValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #freeText_"+parseInt(colnumber+1)+" input:eq(0)").attr('value');
		var attrQuanCheckFromValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanChkbox_"+parseInt(colnumber+1)+" input:eq(0)").attr('value');
		var attrQuanCheckToValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanChkbox_"+parseInt(colnumber+1)+" input:eq(1)").attr('value');
		var attrQuanCheckWithOtherFromValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanChkboxWithOther_"+parseInt(colnumber+1)+" input:eq(0)").attr('value');
		var attrQuanCheckWithOtherToValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanChkboxWithOther_"+parseInt(colnumber+1)+" input:eq(1)").attr('value');
		var attrQuanDropDownFromValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanDropDown_"+parseInt(colnumber+1)+" input:eq(0)").attr('value');
		var attrQuanDropDownToValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanDropDown_"+parseInt(colnumber+1)+" input:eq(1)").attr('value');
		var attrQuanRadioFromValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanRadio_"+parseInt(colnumber+1)+" input:eq(0)").attr('value');
		var attrQuanRadioToValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanRadio_"+parseInt(colnumber+1)+" input:eq(1)").attr('value');
		var attrQualCheckValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #qualChkbox_"+parseInt(colnumber+1)+" textarea:visible").val();
		var attrQualCheckWithOtherValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #qualChkboxWithOther_"+parseInt(colnumber+1)+" textarea:visible").val();
		var attrQualDropDownValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #qualDropDown_"+parseInt(colnumber+1)+" textarea:visible").val();
		var attrQualRadioValue2 = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #qualRadio_"+parseInt(colnumber+1)+" textarea:visible").val();
		
		var moveDown = $('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber)).html();
		var moveUp = $('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber+1)).html();
		$('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber+1)).html(moveDown);
		$('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber)).html(moveUp);

		var action1 = $("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber)+" .columnsLabelList tr:eq(1) td:eq(0) div.action").html();
		var action2 = $("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" .columnsLabelList tr:eq(1) td:eq(0) div.action").html();
		$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber)+" .columnsLabelList tr:eq(1) td:eq(0) div.action").html(action2);
		$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" .columnsLabelList tr:eq(1) td:eq(0) div.action").html(action1);
		
		var on_change_input_down = "javascript:columnsOnChange("+num+",this,"+parseInt(colnumber+1)+");";
		var on_change_input_up = "javascript:columnsOnChange("+num+",this,"+parseInt(colnumber)+");";
		$('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber+1)+' .columnsLabelList input').attr('onchange', on_change_input_down);
		$('#matrix_'+num+'_column #columnsAdd_'+parseInt(colnumber)+' .columnsLabelList input').attr('onchange', on_change_input_up);
		
		$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber)+" .3DMatrixStep2").each(function(){
			var attrID = this.id;
			Numvalue = attrID.match(/\d+$/);
			var newID = attrID.replace('_'+Numvalue,'_'+parseInt(colnumber));
			$(this).attr('id', newID);
			
			var labelText = stringifyNumber(colnumber);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" span#colLabel_"+colnumber).text(labelText+" Column's Label:");
			var qnTypeText = stringifyNumber(colnumber);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" span#colQnType_"+colnumber).text(qnTypeText+" Column's Question Type:");
			
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" .columnsLabelList tr:eq(0) input").attr('value', attrInputValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" .columnsLabelList select").attr('value', attrSelectValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #freeText_"+colnumber+" input:eq(0)").attr('value', attrFreeTextValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkbox_"+colnumber+" input:eq(0)").attr('value', attrQuanCheckFromValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkbox_"+colnumber+" input:eq(1)").attr('value', attrQuanCheckToValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkboxWithOther_"+colnumber+" input:eq(0)").attr('value', attrQuanCheckWithOtherFromValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanChkboxWithOther_"+colnumber+" input:eq(1)").attr('value', attrQuanCheckWithOtherToValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanDropDown_"+colnumber+" input:eq(0)").attr('value', attrQuanDropDownFromValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanDropDown_"+colnumber+" input:eq(1)").attr('value', attrQuanDropDownToValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanRadio_"+colnumber+" input:eq(0)").attr('value', attrQuanRadioFromValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #quanRadio_"+colnumber+" input:eq(1)").attr('value', attrQuanRadioToValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualChkbox_"+colnumber+" textarea").val(attrQualCheckValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualChkboxWithOther_"+colnumber+" textarea").val(attrQualCheckWithOtherValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualDropDown_"+colnumber+" textarea").val(attrQualDropDownValue2);
			$("#matrix_"+num+"_column #columnsAdd_"+colnumber+" #qualRadio_"+colnumber+" textarea").val(attrQualRadioValue2);
	 	});
		
		$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber)+" .3DMatrixStep2Name").each(function(){
			var attrName = this.name;
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[3] = parseInt(colnumber);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$(this).attr('name', newName);
	 	});
		
		$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" .3DMatrixStep2").each(function(){
			var attrID = this.id;
			Numvalue = attrID.match(/\d+$/);
			var newID = attrID.replace('_'+Numvalue,'_'+parseInt(colnumber+1));
			$(this).attr('id', newID);
			
			var labelText = stringifyNumber(parseInt(colnumber+1));
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" span#colLabel_"+parseInt(colnumber+1)).text(labelText+" Column's Label:");
			var qnTypeText = stringifyNumber(parseInt(colnumber+1));
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" span#colQnType_"+parseInt(colnumber+1)).text(qnTypeText+" Column's Question Type:");
			
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" .columnsLabelList tr:eq(0) input").attr('value', attrInputValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" .columnsLabelList select").attr('value', attrSelectValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #freeText_"+parseInt(colnumber+1)+" input:eq(0)").attr('value', attrFreeTextValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanChkbox_"+parseInt(colnumber+1)+" input:eq(0)").attr('value', attrQuanCheckFromValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanChkbox_"+parseInt(colnumber+1)+" input:eq(1)").attr('value', attrQuanCheckToValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanChkboxWithOther_"+parseInt(colnumber+1)+" input:eq(0)").attr('value', attrQuanCheckWithOtherFromValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanChkboxWithOther_"+parseInt(colnumber+1)+" input:eq(1)").attr('value', attrQuanCheckWithOtherToValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanDropDown_"+parseInt(colnumber+1)+" input:eq(0)").attr('value', attrQuanDropDownFromValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanDropDown_"+parseInt(colnumber+1)+" input:eq(1)").attr('value', attrQuanDropDownToValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanRadio_"+parseInt(colnumber+1)+" input:eq(0)").attr('value', attrQuanRadioFromValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #quanRadio_"+parseInt(colnumber+1)+" input:eq(1)").attr('value', attrQuanRadioToValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #qualChkbox_"+parseInt(colnumber+1)+" textarea").val(attrQualCheckValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #qualChkboxWithOther_"+parseInt(colnumber+1)+" textarea").val(attrQualCheckWithOtherValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #qualDropDown_"+parseInt(colnumber+1)+" textarea").val(attrQualDropDownValue1);
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" #qualRadio_"+parseInt(colnumber+1)+" textarea").val(attrQualRadioValue1);
	 	});
		
		$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(colnumber+1)+" .3DMatrixStep2Name").each(function(){
			var attrName = this.name;
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[3] = parseInt(colnumber+1);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$(this).attr('name', newName);
	 	});
		
		//Grid Section
		$("#matrix_"+num+"_grid .table-bordered tr").each(function(){
			var grid_moveDown = $(this).find("td#"+parseInt(colnumber)+"").html();
			var grid_moveUp = $(this).find("td#"+parseInt(colnumber+1)+"").html();
			$(this).find("td#"+parseInt(colnumber+1)+"").html(grid_moveDown);
			$(this).find("td#"+parseInt(colnumber)+"").html(grid_moveUp);
		});
		
		$("#matrix_"+num+"_grid .table-bordered").find("tr td#"+parseInt(colnumber)+".gridtd").each(function(){
			var attrName = $(this).find("input").attr("name");
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[4] = parseInt(colnumber);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$(this).find("input").attr("name", newName);
		});
		
		$("#matrix_"+num+"_grid .table-bordered").find("tr td#"+parseInt(colnumber+1)+".gridtd").each(function(){
			var attrName = $(this).find("input").attr("name");
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[4] = parseInt(colnumber+1);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$(this).find("input").attr("name", newName);
		});
	}	
}

//3D Matrix Columns Delete
function columnsLabelDelete(num,id,qcount){
	addAnother = "<div style='float:left; padding:0px 15px 15px 0px;'><a href='javascript:columnsLabelAdd("+num+","+qcount+");'>Add Another Column</a></div>";
	moveUp = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:columnsLabel_moveUp("+num+",upID);\">Move Up</a></div>";
	moveDown = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:columnsLabel_moveDown("+num+",downID);\">Move Down</a></div>";
	
	$(".3dMatrix_Step2 #matrix_"+num+"_column").find("#columnsAdd_"+id).remove();
	//$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+id).parent('div').remove();
	
	count = $("#matrix_"+num+"_column_count").val();
	newCount = parseInt(count)-1;
	$("#matrix_"+num+"_column_count").val(newCount);
	
	for(i = id; i <= newCount; i++){
		$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(i+1)+" .3DMatrixStep2").each(function(){
			var attrID = this.id;
			Numvalue = attrID.match(/\d+$/);
			var newID = attrID.replace('_'+Numvalue,'_'+parseInt(i));
			$(this).attr('id', newID);
			
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(i+1)+" .columnsLabelList tr:eq(1) td:eq(0) div.action > div:nth-child(3) a").attr('href','javascript:columnsLabelDelete('+num+','+i+','+qcount+')');
			$("#matrix_"+num+"_column #columnsAdd_"+parseInt(i+1)).attr('id','columnsAdd_'+i)
	 	});
		
		var labelText = stringifyNumber(i);
		$("#matrix_"+num+"_column #columnsAdd_"+i+" span#colLabel_"+i).text(labelText+" Column's Label:");
		var qnTypeText = stringifyNumber(i);
		$("#matrix_"+num+"_column #columnsAdd_"+i+" span#colQnType_"+i).text(qnTypeText+" Column's Question Type:");
		
		var on_change_input = "javascript:columnsOnChange("+num+",this,"+parseInt(i)+");";
		$('#matrix_'+num+'_column #columnsAdd_'+parseInt(i)+' .columnsLabelList input').attr('onchange', on_change_input);
		
		$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+parseInt(i)+" .3DMatrixStep2Name").each(function(){
			var attrName = this.name;
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[3] = parseInt(i);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$(this).attr('name', newName);
	 	});
	}	
	
	 var j = 1;
	 $('.3dMatrix_Step2 #matrix_'+num+'_column tr:eq(1)').each(function(){
	 	if(j == 2){
			var moveUp = moveUp.replace("upID","2");
			var moveDown = moveDown.replace("downID","1");
			$("#matrix_"+num+"_column .columnsLabelList tr:eq(1) td:eq(0) div.action").find("div:first-child").before(moveDown);
			$("#matrix_"+num+"_column #columnsAdd_2 .columnsLabelList tr:eq(1) td:eq(0) div.action").find("div:first-child").after(moveUp);
		}else{
			for(j = 1; j <= newCount; j++){
				moveUp = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:columnsLabel_moveUp("+num+",upID);\">Move Up</a></div></div>";
				moveDown = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:columnsLabel_moveDown("+num+",downID);\">Move Down</a></div></div>";
				var moveUp = moveUp.replace("upID",parseInt(j));
				var moveDown =  moveDown.replace("downID",parseInt(j));
				$("#matrix_"+num+"_column #columnsAdd_"+parseInt(j)+" .columnsLabelList tr:eq(1) td:eq(0) div.action").html(moveUp+moveDown+"<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:columnsLabelDelete("+num+","+parseInt(j)+","+qcount+");\">Delete</a></div>");
				
				if(j == 1){
					$("#matrix_"+num+"_column #columnsAdd_1 .columnsLabelList tr:eq(1) td:eq(0) div.action > div:nth-child(1)").remove();
				} 
				 
				move_Up = "<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:columnsLabel_moveUp("+num+",upID);\">Move Up</a></div></div>";
				var move_Up = move_Up.replace("upID",parseInt(j+3));
				$("#matrix_"+num+"_column #columnsAdd_"+parseInt(newCount)+" .columnsLabelList tr:eq(1) td:eq(0) div.action").html(addAnother+moveUp+"<div style='float:left; padding:0px 15px 15px 0px;'><a href=\"javascript:columnsLabelDelete("+num+","+parseInt(j)+","+qcount+");\">Delete</a></div>");
			}	
		
			if(newCount == 1){
				add_another = "<div class='add_Another' style='padding-top:10px;'><div style='float:left; padding:0px 15px 15px 0px;'><a href='javascript:columnsLabelAdd("+num+","+qcount+");'>Add Another Column</a></div></div>";
				$("#matrix_"+num+"_column #columnsAdd_1 div.action").remove();
				$("#matrix_"+num+"_column #columnsAdd_1 .columnsLabelList tr:eq(1) td:eq(0)").append(add_another);
			}
			
			j = j+1;
	  	}	
	});	
	
	//Grid Section
	$("#matrix_"+num+"_grid .table-bordered tr").each(function(){
		$(this).find("td#"+id+"").remove();
	});	
	
	for(k = id; k <= newCount; k++){
		$("#matrix_"+num+"_grid .table-bordered").find("tr td#"+parseInt(k+1)+"").attr('id', k);
		
		$("#matrix_"+num+"_grid .table-bordered").find("tr td#"+parseInt(k)+".gridtd").each(function(){
			var attrName = $(this).find("input").attr("name");
			newStr = attrName.split("_");
			newStr[1] = num;
			newStr[4] = parseInt(k);
			var newName = ""+newStr[0]+"_"+newStr[1]+"_"+newStr[2]+"_"+newStr[3]+"_"+newStr[4]+"";
			$(this).find("input").attr("name", newName);
			
			var attrID = $(this).attr("onclick");
			newID = attrID.split(",");
			newID[2] = parseInt(k);
			var on_click_td = ""+newID[0]+","+newID[1]+","+newID[2]+");";
			$(this).attr('onclick', on_click_td);
		});
	}
}

function rowsOnChange(num,attr,rindex){
	var rowObjs=[];
	var html = "";
    var obj = {
        "ROW_ID" : rindex,
        "ROW_NAME" : attr.value
    }   
 
    if(attr.value.trim() != ""){
		// add object
	    rowObjs.push(obj);
	   
    	if($("#matrix_"+num+"_grid .table-bordered").find('tr:eq('+rindex+') td:eq(0)').length){
			// update existing rows value in the table
			$("#matrix_"+num+"_grid .table-bordered").find('tr:eq('+rindex+') td:eq(0)').html(obj['ROW_NAME']);
			$('.required').show();
		}else{
		    // dynamically create rows in the table
		    html = "<tr id="+ obj['ROW_ID'] + " class='gridtr'><td id='0' class='gridRow' onclick=\"javascript:checkUncheckImageRowColumn("+num+","+obj['ROW_ID']+",'row');\">"+ obj['ROW_NAME'] + "</td></tr>";
			//add to the table
			$("#matrix_"+num+"_grid .table-bordered").append(html);
			
			count = $("#matrix_"+num+"_grid .table-bordered").find('tr:eq(0) td').length;
			for(i = 1; i <= count-1; i++){
				//var j =  $("#matrix_"+num+"_grid .table-bordered").find('tr:eq('+obj['ROW_ID']+') td').length
				//console.log(j);
				$("#matrix_"+num+"_grid .table-bordered").find('tr:eq('+obj['ROW_ID']+')').append("<td id="+parseInt(i)+" class='gridtd' onclick=\"javascript:checkUncheckImage("+num+","+obj['ROW_ID']+","+i+");\"><input type='checkbox' name='matrix_"+num+"_required_"+obj['ROW_ID']+"_"+i+"' id='matrix_"+num+"_required_"+obj['ROW_ID']+"_"+i+"' value='1' style='display:none;'></td>");
			}
			
			$("#matrix_"+num+"_grid .table-bordered").show();
			/*$('.required').show();*/
			
			if($("#matrix_"+num+"_grid .optional").length){
				$('.required').show();
				$('.optional').hide();
			}else if($("#matrix_"+num+"_grid .required").length){
				$('.optional').show();
				$('.required').hide();
			}else{
				$('.required').show();
			}
		}
	}else{
		$("#matrix_"+num+"_grid .table-bordered").find('tr:eq('+rindex+') td:eq(0)').empty();
	}	
}

function columnsOnChange(num,attr,cindex){
	var colObjs=[];
	var html = "";
    var obj = {
        "COL_ID" : cindex,
        "COL_NAME" : attr.value
    }   
	
    if(attr.value.trim() != ""){
		// add object
	    colObjs.push(obj);
		
		if($("#matrix_"+num+"_grid .table-bordered").find('tr:eq(0) td:eq('+cindex+')').length){
			// update existing columns value in the table
			$("#matrix_"+num+"_grid .table-bordered").find('tr:eq(0) td:eq('+cindex+')').html(obj['COL_NAME']);
		}else{
		    // dynamically create columns in the table
		    html = "<td id=" + obj['COL_ID'] +" class='gridColumn' onclick=\"javascript:checkUncheckImageRowColumn("+num+","+obj['COL_ID']+",'column');\"" + ">" + obj['COL_NAME'] + "</td>";
		    //add to the table
		    $("#matrix_"+num+"_grid .table-bordered tr:eq(0)").append(html);
			
			count = $("#matrix_"+num+"_grid .table-bordered").find('tr').length;
			for(i = 1; i <= count-1; i++){
				var j = $("#matrix_"+num+"_grid .table-bordered").find('tr:eq('+i+') td').length;
				$("#matrix_"+num+"_grid .table-bordered").find('tr:eq('+i+')').append("<td id="+parseInt(j)+" class='gridtd' onclick=\"javascript:checkUncheckImage("+num+","+i+","+j+");\"><input type='checkbox' name='matrix_"+num+"_required_"+i+"_"+obj['COL_ID']+"' id='matrix_"+num+"_required_"+i+"_"+obj['COL_ID']+"'  value='1' style='display:none;'></td>");
			}
			
			$("#matrix_"+num+"_grid .table-bordered").show();
		}	
	}else{
		$("#matrix_"+num+"_grid .table-bordered").find('tr:eq(0) td:eq('+cindex+')').empty();
	}	
}

function checkUncheckImage(num,trid,tdid){
	var img = $("#matrix_"+num+"_grid .table-bordered").find("tr#"+trid+" td#"+tdid+" img").length;
	if (img != 0){
	//if ($("#matrix_"+num+"_grid .table-bordered").find("tr#"+trid+" td#"+tdid+" input[type='checkbox']").is(':checked')){
		$("#matrix_"+num+"_grid .table-bordered").find("tr#"+trid+" td#"+tdid+" img").remove();
		$("#matrix_"+num+"_grid .table-bordered").find("tr#"+trid+" td#"+tdid+" input[type='checkbox']").prop("checked",false);
		$("#matrix_"+num+"_grid .table-bordered").find("tr#"+trid+" td#"+tdid+" input[type='checkbox']").attr("value",0);
	}else{
		$("#matrix_"+num+"_grid .table-bordered").find("tr#"+trid+" td#"+tdid+"").append(chkImage);
		$("#matrix_"+num+"_grid .table-bordered").find("tr#"+trid+" td#"+tdid+" input[type='checkbox']").prop("checked",true);
		$("#matrix_"+num+"_grid .table-bordered").find("tr#"+trid+" td#"+tdid+" input[type='checkbox']").attr("value",1);
	}
	
	var len = $("#matrix_"+num+"_grid .table-bordered").find("tr:not(:first-child) td:not(:first-child)").length;
	var imgLen = $("#matrix_"+num+"_grid .table-bordered").find("tr:not(:first-child) td:not(:first-child) img").length;
	if (imgLen < len){
		$("#matrix_"+num+"_grid .required").show();
		$("#matrix_"+num+"_grid .optional").hide();
	}else{
		$("#matrix_"+num+"_grid .optional").show();
		$("#matrix_"+num+"_grid .required").hide();
	}
}

function checkUncheckImageRowColumn(num,id,type){
	if(type=='row'){
		var tdLen = $("#matrix_"+num+"_grid .table-bordered").find("tr#"+id+" td:not(:first-child)").length;
		var tdImgLen = $("#matrix_"+num+"_grid .table-bordered").find("tr#"+id+" td img").length;
		
		if (tdImgLen < tdLen){
			$("#matrix_"+num+"_grid .table-bordered").find("tr#"+id+" td img").remove();	
			$("#matrix_"+num+"_grid .table-bordered").find("tr#"+id+" td:not(:first-child)").append(chkImage);
			
			$("#matrix_"+num+"_grid .table-bordered").find("tr#"+id+" td:not(:first-child) input[type='checkbox']").prop("checked",true);
			$("#matrix_"+num+"_grid .table-bordered").find("tr#"+id+" td:not(:first-child) input[type='checkbox']").prop("value",1);
		}else{
			$("#matrix_"+num+"_grid .table-bordered").find("tr#"+id+" td img").remove();
			
			$("#matrix_"+num+"_grid .table-bordered").find("tr#"+id+" td:not(:first-child) input[type='checkbox']").prop("checked",false);
			$("#matrix_"+num+"_grid .table-bordered").find("tr#"+id+" td:not(:first-child) input[type='checkbox']").prop("value",0);
		}
	}else{
		var tdLen = $("#matrix_"+num+"_grid .table-bordered").find("tr:not(:first-child) td#"+id+"").length;
		var tdImgLen = $("#matrix_"+num+"_grid .table-bordered").find("tr:not(:first-child) td#"+id+" img").length;
	
		if (tdImgLen < tdLen){
			$("#matrix_"+num+"_grid .table-bordered").find("tr:not(:first-child) td#"+id+"").each(function(){
				$(this).find("img").remove();	
				$(this).append(chkImage);
				
				$(this).find("input[type='checkbox']").prop("checked",true);
				$(this).find("input[type='checkbox']").prop("value",1);
			});
		}else{
			$("#matrix_"+num+"_grid .table-bordered").find("tr:not(:first-child) td#"+id+"").each(function(){
				$(this).find("img").remove();
				
				$(this).find("input[type='checkbox']").prop("checked",false);
				$(this).find("input[type='checkbox']").prop("value",0);
			});
		}
	}
	
	var len = $("#matrix_"+num+"_grid .table-bordered").find("tr:not(:first-child) td:not(:first-child)").length;
	var imgLen = $("#matrix_"+num+"_grid .table-bordered").find("tr:not(:first-child) td:not(:first-child) img").length;
	if (imgLen < len){
		$("#matrix_"+num+"_grid .required").show();
		$("#matrix_"+num+"_grid .optional").hide();
	}else{
		$("#matrix_"+num+"_grid .optional").show();
		$("#matrix_"+num+"_grid .required").hide();
	}	
}

function requiredClick(num){
	$("#matrix_"+num+"_grid .optional").show();
	$("#matrix_"+num+"_grid .required").hide();
	
	$("#matrix_"+num+"_grid .table-bordered tr td").find("img").remove();
	
	$("#matrix_"+num+"_grid .table-bordered tr td:not(:first-child)").append(chkImage);
	$("#matrix_"+num+"_grid .table-bordered tr:eq(0) td").find("img").remove();
	
	$("#matrix_"+num+"_grid .table-bordered tr td:not(:first-child) input[type='checkbox']").prop("checked",true);
	$("#matrix_"+num+"_grid .table-bordered tr td:not(:first-child) input[type='checkbox']").prop("value",1);
}
	
function optionalClick(num){
	$("#matrix_"+num+"_grid .required").show();
	$("#matrix_"+num+"_grid .optional").hide();
	$("#matrix_"+num+"_grid .table-bordered tr td").find("img").remove();
	
	$("#matrix_"+num+"_grid .table-bordered tr td input[type='checkbox']").prop("checked",false);
	$("#matrix_"+num+"_grid .table-bordered tr td input[type='checkbox']").prop("value",0);
}

function stringifyNumber(n){
	var special = ['Zeroth', 'First', 'Second', 'Third', 'Fourth', 'Fifth', 'Sixth', 'Seventh', 'Eighth', 'Ninth', 'Tenth', 'Eleventh', 'Twelfth', 'Thirteenth', 'Fourteenth', 'Fifteenth', 'Sixteenth', 'Seventeenth', 'Eighteenth', 'Nineteenth'];
	var deca = ['Twent', 'Thirt', 'Fourt', 'Fift', 'Sixt', 'Sevent', 'Eight', 'Ninet'];

	if (n < 20) return special[n];
	if (n%10 === 0) return deca[Math.floor(n/10)-2] + 'ieth';
	return deca[Math.floor(n/10)-2] + 'y ' + special[n%10];
}

function matrixValidation(num, stepCounter){
	var row_count = document.getElementById("matrix_"+num+"_row_count").value;
	
	for (i = 1; i <= row_count; i++) {
		var rowChoiceText = $("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+i+"_name']").val();
		var rowChoiceTextnospace = rowChoiceText.replace(/ /g, "");
		
		if (rowChoiceTextnospace == "") {
			alert("[Step "+stepCounter+"]: Please enter a name for the blank row.");
			$("#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+i+"_name']").focus();
			return false;
		}
	}		
	
	var column_count = document.getElementById("matrix_"+num+"_column_count").value;
	
	for (j = 1; j <= column_count; j++){
		
		var columnChoiceText = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" .columnsLabelList input[name='matrix_"+num+"_column_"+j+"_name']").val();
		var columnChoiceTextnospace = columnChoiceText.replace(/ /g, "");
		var columnQuestionTypeChoice = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" .columnsLabelList select[name='matrix_"+num+"_questionType_"+j+"_name']").val();

		if (columnChoiceTextnospace == ""){
			alert("[Step "+stepCounter+"]: Please enter a name for the blank column.");
			$(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList input[name='matrix_"+num+"_column_"+j+"_name']").focus();
			return false;
		}
		if (columnQuestionTypeChoice == ""){
			alert("[Step "+stepCounter+"]: Please select a Question Type for the columns you already created.");
			$(".3dMatrix_Step2 #matrix_"+num+"_column .columnsLabelList select[name='matrix_"+num+"_questionType_"+j+"_name']").focus();
			return false;
		}
		
		validationstatus = matrixColumnValidation(num,columnQuestionTypeChoice,j,stepCounter);
		if(validationstatus == false){
			return false;
		}
	}
	return true;
}

function matrixColumnValidation(num,columnQuestionTypeChoice,j,stepCounter){
	if(columnQuestionTypeChoice == "Free Text Response"){
		var qnTypeVal = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #freeText_"+j+" input:eq(0)").val();
		if(qnTypeVal == ""){
			valdiationMsg("[Step "+stepCounter+"]: The column you just created does not yet have a character limit assigned to it. Please add a character limit.",
							$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #freeText_"+j+" input:eq(0)"));
			return false;
		}else if(qnTypeVal == 0){
			valdiationMsg("[Step "+stepCounter+"]: Please add a character limit greater than zero",
							$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #freeText_"+j+" input:eq(0)"));
			return false;
		}
		else{
			validateNumeric = checkNumeric(num,$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #freeText_"+j+" input:eq(0)"),'free',stepCounter);
			if(validateNumeric == false){
		 		return false;
		 	}
		}
	}
	if(columnQuestionTypeChoice == "Quantitative Checkbox without Other Option"){
		var qnTypeValFrom = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkbox_"+j+" input:eq(0)").val(); 
		var qnTypeValTo = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkbox_"+j+" input:eq(1)").val();
		if(qnTypeValFrom == "" || qnTypeValTo == ""){
			if(qnTypeValFrom == ""){
				valdiationMsg("[Step "+stepCounter+"]: Before creating a new column, please enter answer choices for the column you just created.",
								$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkbox_"+j+" input:eq(0)"));
				return false;
			}
			else{
				valdiationMsg("[Step "+stepCounter+"]: Before creating a new column, please enter answer choices for the column you just created.",
								$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkbox_"+j+" input:eq(1)"));
				return false;
			}
		}else if(qnTypeValFrom != "" && qnTypeValTo != ""){
			validateNumericFrom = checkNumeric(num,$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkbox_"+j+" input:eq(0)"),'from',stepCounter);
			if(validateNumericFrom == true){
				validateNumericTo = checkNumeric(num,$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkbox_"+j+" input:eq(1)"),'to',stepCounter);
				if(validateNumericTo == true){
			 		var validationstatus = comparefromto($(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkbox_"+j+" input:eq(0)"), $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkbox_"+j+" input:eq(1)"));
				 	if(validationstatus == false){
				 		return false;
				 	}
				}
				else{
					return false;
				}	
			}
			else{
				return false;
			}	
		}
	}
	if(columnQuestionTypeChoice == "Quantitative Checkbox with Other Option"){
		var qnTypeValFrom = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkboxWithOther_"+j+" input:eq(0)").val(); 
		var qnTypeValTo = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkboxWithOther_"+j+" input:eq(1)").val();
		if(qnTypeValFrom == "" || qnTypeValTo == ""){
			if(qnTypeValFrom == ""){
				valdiationMsg("[Step "+stepCounter+"]: Before creating a new column, please enter answer choices for the column you just created.",
								$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkboxWithOther_"+j+" input:eq(0)"));
				return false;
			}
			else{
				valdiationMsg("[Step "+stepCounter+"]: Before creating a new column, please enter answer choices for the column you just created.",
								$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkboxWithOther_"+j+" input:eq(1)"));
				return false;
			}
		}else if(qnTypeValFrom != "" && qnTypeValTo != ""){
			validateNumericFrom = checkNumeric(num,$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkboxWithOther_"+j+" input:eq(0)"),'from',stepCounter);
			if(validateNumericFrom == true){
				validateNumericTo = checkNumeric(num,$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkboxWithOther_"+j+" input:eq(1)"),'to',stepCounter);
				if(validateNumericTo == true){
			 		var validationstatus = comparefromto($(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkboxWithOther_"+j+" input:eq(0)"), $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanChkboxWithOther_"+j+" input:eq(1)"));
				 	if(validationstatus == false){
				 		return false;
				 	}
				}
				else{
					return false;
				}	
			}
			else{
				return false;
			}	
		}
	}
	if(columnQuestionTypeChoice == "Quantitative Drop-Down"){
		var qnTypeValFrom = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanDropDown_"+j+" input:eq(0)").val(); 
		var qnTypeValTo = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanDropDown_"+j+" input:eq(1)").val();
		if(qnTypeValFrom == "" || qnTypeValTo == ""){
			if(qnTypeValFrom == ""){
				valdiationMsg("[Step "+stepCounter+"]: Before creating a new column, please enter answer choices for the column you just created.",
								$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanDropDown_"+j+" input:eq(0)"));
				return false;
			}
			else{
				valdiationMsg("[Step "+stepCounter+"]: Before creating a new column, please enter answer choices for the column you just created.",
								$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanDropDown_"+j+" input:eq(1)"));
				return false;
			}
		}else if(qnTypeValFrom != "" && qnTypeValTo != ""){
			validateNumericFrom = checkNumeric(num,$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanDropDown_"+j+" input:eq(0)"),'from',stepCounter);
			if(validateNumericFrom == true){
				validateNumericTo = checkNumeric(num,$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanDropDown_"+j+" input:eq(1)"),'to',stepCounter);
				if(validateNumericTo == true){
			 		var validationstatus = comparefromto($(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanDropDown_"+j+" input:eq(0)"), $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanDropDown_"+j+" input:eq(1)"));
				 	if(validationstatus == false){
				 		return false;
				 	}
				}
				else{
					return false;
				}	
			}
			else{
				return false;
			}	
		}
	}
	if(columnQuestionTypeChoice == "Quantitative Radio"){
		var qnTypeValFrom = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanRadio_"+j+" input:eq(0)").val(); 
		var qnTypeValTo = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanRadio_"+j+" input:eq(1)").val();
		if(qnTypeValFrom == "" || qnTypeValTo == ""){
			if(qnTypeValFrom == ""){
				valdiationMsg("[Step "+stepCounter+"]: Before creating a new column, please enter answer choices for the column you just created.",
								$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanRadio_"+j+" input:eq(0)"));
				return false;
			}
			else{
				valdiationMsg("[Step "+stepCounter+"]: Before creating a new column, please enter answer choices for the column you just created.",
								$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanRadio_"+j+" input:eq(1)"));
				return false;
			}
		}else if(qnTypeValFrom != "" && qnTypeValTo != ""){
			validateNumericFrom = checkNumeric(num,$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanRadio_"+j+" input:eq(0)"),'from',stepCounter);
			if(validateNumericFrom == true){
				validateNumericTo = checkNumeric(num,$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanRadio_"+j+" input:eq(1)"),'to',stepCounter);
				if(validateNumericTo == true){
			 		var validationstatus = comparefromto($(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanRadio_"+j+" input:eq(0)"), $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #quanRadio_"+j+" input:eq(1)"));
				 	if(validationstatus == false){
				 		return false;
				 	}
				}
				else{
					return false;
				}	
			}
			else{
				return false;
			}	
		}
	}	
	if(columnQuestionTypeChoice == "Qualitative Checkbox without Other Option"){
		var qnTypeVal = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #qualChkbox_"+j+" textarea").val(); 
		if(qnTypeVal == ""){
			valdiationMsg("[Step "+stepCounter+"]: Before creating a new column, please enter answer choices for the column you just created.",
							$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #qualChkbox_"+j+" textarea"));
			return false;
		}
	}
	if(columnQuestionTypeChoice == "Qualitative Checkbox with Other Option"){
		var qnTypeVal = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #qualChkboxWithOther_"+j+" textarea").val(); 
		if(qnTypeVal == ""){
			valdiationMsg("[Step "+stepCounter+"]: Before creating a new column, please enter answer choices for the column you just created.",
							$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #qualChkboxWithOther_"+j+" textarea"));
			return false;
		} 
	}
	if(columnQuestionTypeChoice == "Qualitative Drop-Down"){
		var qnTypeVal = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #qualDropDown_"+j+" textarea").val();
		if(qnTypeVal == ""){
			valdiationMsg("[Step "+stepCounter+"]: Before creating a new column, please enter answer choices for the column you just created.",
							$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #qualDropDown_"+j+" textarea"));
			return false;
		} 
	}
	if(columnQuestionTypeChoice == "Qualitative Radio"){
		var qnTypeVal = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #qualRadio_"+j+" textarea").val();
		if(qnTypeVal == ""){
			valdiationMsg("[Step "+stepCounter+"]: Before creating a new column, please enter answer choices for the column you just created.",
							$(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+j+" #qualRadio_"+j+" textarea"));
			return false;
		}
	}
	return true;
}

//setting validation message for 3D Matrix Question type
function valdiationMsg(msg,container){
	alert(msg);
	container.focus();
}

//checking whether the to field and the from field of 3D Matrix Question type difference is 10001
function comparefromto(fromContainer, toContainer){
 	var fromnum = $(fromContainer).val();
    var tonum = $(toContainer).val();
	var fromtodifference = Number(tonum) - Number(fromnum);
    
    if(Number(fromnum) < Number(tonum)){
		if(fromtodifference < 10001){
	    	return true;
    	}
    	else{
    		alert("[Step 1]: Please enter the range of less than 10001 in the number series answer choices field.");
    		fromContainer.focus();
    		return false;
    	}
    }
    else{
        alert("[Step 1]: In the \"Number Series Answer Choices\" area, please enter a number in the \"From\" field that is less than the number in the \"To\" field.");
        fromContainer.val('');
        //toContainer.val('');
        fromContainer.focus();
        return false;
    }
}

//checking whether the to field and the from field is numeric.
function checkNumeric(num,container,field,stepCounter){
	controlnamevalue = container.val();
    var regexp = new RegExp("^[0-9]+$");
    currenttext = (controlnamevalue).replace(" ","");
    if(currenttext != ""){
    	if(controlnamevalue.match(regexp)){
        	return true;
        }
       	else{
			if(field == "from"){
            	alert("[Step "+stepCounter+"]: Please enter a whole, positive integer in the \"From\" field.");
				container.val('');
				container.focus();
				return false;
            }
            if(field == "to"){
            	alert("[Step "+stepCounter+"]: Please enter a whole, positive integer in the \"To\" field.");
				container.val('');
				container.focus();
				return false;
            }
			if(field == "free"){
				alert("[Step "+stepCounter+"]: Please update the character limit of the column you just created so that the limit is represented by a single, whole, positive number.");
				container.val('');
				container.focus();
				return false;
			}
    	}
    }
    /*else{
		if(num == 1){
	        if (field == "from"){
	            alert("[Step "+stepCounter+"]: In the column you just created, please enter your answer choices before creating a new column.");
				container.focus();
				return false;
	         }
	         if (field == "to"){
	            alert("[Step "+stepCounter+"]: In the column you just created, please enter your answer choices before creating a new column.");
				container.focus();
				return false;
	         }
		}	 
	    else{
    		if (field == "from"){
	            alert("[Step "+stepCounter+"]: In the column you just created, please enter your answer choices before creating a new column.");
				container.focus();
				return false;
	         }
	         if (field == "to"){
	            alert("[Step "+stepCounter+"]: In the column you just created, please enter your answer choices before creating a new column.");
				container.focus();
				return false;
	         }
	    }
     //container.focus();
     //return false;
	}*/
}

Array.prototype.max = function() {
  return Math.max.apply(null, this);
};

//View Data for 3DMatrix Question Type
function showResponseMatrix(bShowAnswers,quid,scope,sites,pgmid,dateBegin,dateEnd,notSelectedIds,orderBy,questionType,selectedRowID,selectedColumnID,associationuserlist,completeidlist,qsurveysiteuserid,omitattributelist,includetype_attribute,addedAttributeIDList,type3QuestionsList,chkdItemList){	 	
	globalQuid = quid;
	var prefix = '/index.cfm?event=';
	var questionID = quid;
	beginSurvey = dateBegin;
	endSurvey = dateEnd;	
	//show loading img
	if(bShowAnswers == 'rowTotal' || bShowAnswers == 'rowTotal_beneficiaryAlias'){
		nowEl = 'loadingImg_rowTotal_' + quid;	
        jQuery("#"+nowEl).css('visibility', 'visible');       
	}
	else if(bShowAnswers == 'launchDate' || bShowAnswers == 'rowVariables' /*|| bShowAnswers == 'launchDate_beneficiaryAlias'*/){
		nowEl = 'loadingImg_launchDate_' + quid;	
		document.getElementById(nowEl).style.visibility = "visible";
	}
	else if(bShowAnswers == 'rowTotal_rowBreakout' || bShowAnswers == 'rowTotal_rowBreakoutHide' || bShowAnswers == 'launchDate_rowBreakout' || bShowAnswers == 'launchDate_rowBreakoutHide'){
		nowEl = 'loadingImg_rowBreakout_' + quid;	
		document.getElementById(nowEl).style.visibility = "visible";
	}
	/*else if(bShowAnswers == 'rowVariables' || bShowAnswers == 'launchDate_surveyAliasTotal'){
		nowEl = 'loadingImg_rowVariables_' + quid;	
		document.getElementById(nowEl).style.visibility = "visible";
	}*/
	else if(bShowAnswers == 'rowTotal_col' || bShowAnswers == 'launchDate_col' || bShowAnswers == 'rowTotal_rowBreakout_col' || bShowAnswers == 'rowTotal_rowBreakoutHide_col' || bShowAnswers == 'launchDate_rowBreakout_col' || bShowAnswers == 'launchDate_rowBreakoutHide_col'){
		nowEl = 'loadingImg_col_' + quid;	
		document.getElementById(nowEl).style.visibility = "visible";
	}
	
	$('#chkdItemList_'+quid).val(chkdItemList);
	
	var url;
	
	url = "survey.showMatrixQuesAnswers";
	
	url = prefix + url;
    try{
		attributeString = (jQuery('#attributeString' + questionID).length > 0 ) ? jQuery('#attributeString' + questionID).val():'';
		neededAssociationItems = (jQuery('#theListOfAssociationItems' + questionID).length > 0 ) ? jQuery('#theListOfAssociationItems' + questionID).val() : '';
		allassociationitems = (jQuery('#hidden_allassociationitems').length > 0 ) ? jQuery('#hidden_allassociationitems').val():'';
		associationitemidcollectionselected = (jQuery('#hidden_associationitemidcollectionselected').length > 0 ) ? jQuery('#hidden_associationitemidcollectionselected').val():'';
		if(typeof getUrlVars == 'function'){
			parameterVar = getUrlVars(attributeString);
		}else{
			parameterVar = {};
		}
		parameterVar = jQuery.extend({},parameterVar,{
			questionid : questionID, scope : scope, sites : sites, pgmid : pgmid, beginsurvey : beginSurvey, endsurvey : endSurvey, 
			notselectedids : notSelectedIds, orderBy : orderBy, questionType : questionType, viewType : bShowAnswers, selectedRowID: selectedRowID, selectedColumnID: selectedColumnID, 
			associationuserlist : associationuserlist, completeidlist : completeidlist, qsurveysiteuserid : qsurveysiteuserid, 
		    omitattributelist : omitattributelist, includetype_attribute : includetype_attribute, addedAttributeIDList : addedAttributeIDList,
	        type3QuestionsList : type3QuestionsList, chkdItemList : chkdItemList
		});
	}
	catch(err){
		parameterVar = {
			questionid : questionID, scope : scope, sites : sites, pgmid : pgmid, beginsurvey : beginSurvey, endsurvey : endSurvey, 
			notselectedids : notSelectedIds, orderBy : orderBy, questionType : questionType, viewType : bShowAnswers, selectedRowID: selectedRowID, selectedColumnID: selectedColumnID, 
			associationuserlist : associationuserlist, completeidlist : completeidlist, qsurveysiteuserid : qsurveysiteuserid, 
		    omitattributelist : omitattributelist, includetype_attribute : includetype_attribute, addedAttributeIDList : addedAttributeIDList,
	        type3QuestionsList : type3QuestionsList, chkdItemList : chkdItemList
		}
	}
	new Ajax.Request(encodeURI(url), {
		method: 'post',
		parameters: parameterVar,
		onSuccess: function (returnHtml) {
			document.getElementById("txtAnswerBox_"+globalQuid).innerHTML = returnHtml.responseText;
			if($("input[name='launchDate_beneficiaryAlias-"+quid+"']").is(':checked')){
				$("div #totals-"+quid).hide();
				$("div #totals_all-"+quid).hide();
			}
			resizeContainer();
		},
		onFailure: function () {
			alert('Oops...mistake on server');
		}
	}); 
	/*$.ajax({
        type: "POST",
        url: encodeURI(url),
        parameters: parameterVar,
		 
        success: function(returnHtml) {		
			document.getElementById("txtAnswerBox_"+globalQuid).innerHTML = returnHtml.responseText;
			if($("input[name='launchDate_beneficiaryAlias-"+quid+"']").is(':checked')){
				$("div #totals-"+quid).hide();
				$("div #totals_all-"+quid).hide();
			}
			resizeContainer();						
        },  
        error: function(data) {
            alert('Oops...mistake on server');
        }
    }); */
}

//View Data Dashboard for 3DMatrix Question Type
function showResponse3DMatrixDashboard(bShowAnswers,quid,scope,sites,pgmid,dateBegin,dateEnd,notSelectedIds,orderBy,questionType,associationitemid,selecteduserid,selectedColumnID){
	globalQuid = quid;
	var prefix = '/index.cfm?event=';
	var questionID = quid;
	beginSurvey = dateBegin;
	endSurvey = dateEnd;
	
	if(bShowAnswers){
		if(bShowAnswers == 'default'){
			nowEl = 'loadingImg_' + globalQuid;
			$('#'+nowEl).show();	
			//document.getElementById(nowEl).style.visibility = "visible";
		}
		else if(bShowAnswers == 'volunteerAlias'){
			nowEl = 'loadingImg_' + globalQuid;
			$('#'+nowEl).show();
		}
		else if(bShowAnswers == 'default_col' || bShowAnswers == 'volunteerAlias_col'){
			nowEl = 'loadingImg_col_' + globalQuid;	
			document.getElementById(nowEl).style.visibility = "visible";
		}
		
		var url;
		
		url = "survey.viewMatrixAnswersDashboard";
		
		url = prefix + url;
	
		try{
			parameterVar = jQuery.extend({},parameterVar,{
				questionid : questionID, scope : scope, sites : sites, pgmid : pgmid, beginsurvey : beginSurvey, endsurvey : endSurvey, 
				notselectedids : notSelectedIds, orderBy : orderBy, questionType : questionType, associationitemid : associationitemid,  
				selecteduserid: selecteduserid, selectedColumnID: selectedColumnID, viewType : bShowAnswers
			});
		}
		catch(err){
			parameterVar = {
				questionid : questionID, scope : scope, sites : sites, pgmid : pgmid, beginsurvey : beginSurvey, endsurvey : endSurvey, 
				notselectedids : notSelectedIds, orderBy : orderBy, questionType : questionType, associationitemid : associationitemid,  
				selecteduserid: selecteduserid, selectedColumnID: selectedColumnID, viewType : bShowAnswers
			}
		}
		/*new Ajax.Request(encodeURI(url), {
			method: 'post',
			parameters: parameterVar,
			onSuccess: function (returnHtml) {
				
					$('#'+nowEl).hide();
				 	$('#viewdetails_'+globalQuid).text('Hide Results');
				 	
				 	selColumnID = $('#selectedMatrixColumnId_'+globalQuid).val();
				 	
				 	var on_click = "showResponse3DMatrixDashboard(0,"+quid+",'"+scope+"','"+sites+"','"+pgmid+"','"+dateBegin+"','"+dateEnd+"','"+notSelectedIds+"','"+orderBy+"','"+questionType+"','"+associationitemid+"','"+selecteduserid+"','"+selColumnID+"');";
					$('#viewdetails_'+globalQuid).attr('onclick', on_click);
					
					$(".showquestionanswer_row").css('width','597px');
					$("div.txtAnswerBox").css('width','584px');
				 	
				 	if(returnHtml.length !=0)	
				 		$("#txtAnswerBox_"+globalQuid).html(returnHtml.responseText);
				 		//$("#txtAnswerBox_"+globalQuid).innerHTML = returnHtml.responseText;
					else
				 		$("#txtAnswerBox_"+globalQuid).html('<div style="text-align:center;padding:5px;">No response available for this question</div>');
					 	$("#txtAnswerBox_"+globalQuid).slideDown('slow');
					 	
					 	resizeContainer();	
		    	}, 
		    // this runs if an error 
			onFailure: function () {
		 		alert('Internal Error');
		 		$('#'+nowEl).hide();
		 		$("#txtAnswerBox_"+globalQuid).html('');
			}
		});*/
		/*$.ajax({
        type: "GET",
        url: encodeURI(url),
        parameters: parameterVar,
		 
        success: function(returnHtml) {	
	
			$('#'+nowEl).hide();
			$('#viewdetails_'+globalQuid).text('Hide Results');
			
			selColumnID = $('#selectedMatrixColumnId_'+globalQuid).val();
			
			var on_click = "showResponse3DMatrixDashboard(0,"+quid+",'"+scope+"','"+sites+"','"+pgmid+"','"+dateBegin+"','"+dateEnd+"','"+notSelectedIds+"','"+orderBy+"','"+questionType+"','"+associationitemid+"','"+selecteduserid+"','"+selColumnID+"');";
			$('#viewdetails_'+globalQuid).attr('onclick', on_click);
			
			$(".showquestionanswer_row").css('width','597px');
			$("div.txtAnswerBox").css('width','584px');
			
			if(returnHtml.length !=0)	
				$("#txtAnswerBox_"+globalQuid).html(returnHtml.responseText);
				//$("#txtAnswerBox_"+globalQuid).innerHTML = returnHtml.responseText;
			else
				$("#txtAnswerBox_"+globalQuid).html('<div style="text-align:center;padding:5px;">No response available for this question</div>');
				$("#txtAnswerBox_"+globalQuid).slideDown('slow');
				
				resizeContainer();							
        },  
        error: function(data) {
            alert('Internal Error');
			$('#'+nowEl).hide();
			$("#txtAnswerBox_"+globalQuid).html('');
        }
    }); */
		var data = [];
	
	  
	data.push({
			"name": "questionid",
			"value": questionID
	});	
	data.push({
			"name": "scope",
			"value": scope
	});
	data.push({
			"name": "sites",
			"value": sites
	});	
	data.push({
			"name": "pgmid",
			"value": pgmid
	});
	data.push({
			"name": "beginsurvey",
			"value": beginSurvey
	});
	data.push({
			"name": "endsurvey",
			"value": endSurvey
	});
	data.push({
			"name": "notselectedIds",
			"value": notSelectedIds
	});
	data.push({
			"name": "orderBy",
			"value": orderBy
	});
	data.push({
			"name": "questionType",
			"value": questionType
	});
	data.push({
			"name": "viewType",
			"value": bShowAnswers
	});
	data.push({
			"name": "selecteduserid",
			"value": selecteduserid
	});
	data.push({
			"name": "selectedColumnID",
			"value": selectedColumnID
	});
	data.push({
			"name": "associationitemid",
			"value": associationitemid
	});
	

$.ajax({
        type: "POST",
        url: "index.cfm?event=survey.viewMatrixAnswersDashboard",
        data: data,
		
        success: function(returnHtml) {		
			 console.log('returnHtml'+returnHtml);
			$('#'+nowEl).hide();
			$('#viewdetails_'+globalQuid).text('Hide Results');
			
			selColumnID = $('#selectedMatrixColumnId_'+globalQuid).val();
			
			var on_click = "showResponse3DMatrixDashboard(0,"+quid+",'"+scope+"','"+sites+"','"+pgmid+"','"+dateBegin+"','"+dateEnd+"','"+notSelectedIds+"','"+orderBy+"','"+questionType+"','"+associationitemid+"','"+selecteduserid+"','"+selColumnID+"');";
			$('#viewdetails_'+globalQuid).attr('onclick', on_click);
			
			$(".showquestionanswer_row").css('width','597px');
			$("div.txtAnswerBox").css('width','584px');
			
			if(returnHtml.length !=0)	
				$("#txtAnswerBox_"+globalQuid).html(returnHtml);
				//$("#txtAnswerBox_"+globalQuid).innerHTML = returnHtml.responseText;
			else
				$("#txtAnswerBox_"+globalQuid).html('<div style="text-align:center;padding:5px;">No response available for this question</div>');
				$("#txtAnswerBox_"+globalQuid).slideDown('slow');
				
				resizeContainer();							
        }, 
		
        error: function(data) {
            alert('Internal Error');
			$('#'+nowEl).hide();
			$("#txtAnswerBox_"+globalQuid).html('');
        }
    }); 
	}
	
	else{
		$("#txtAnswerBox_"+globalQuid).slideUp({
			complete:function(){
				$("#txtAnswerBox_"+globalQuid).html('');
				$('#viewdetails_'+globalQuid).text('View Results');
				
				selColumnID = $('#selectedMatrixColumnId_'+globalQuid).val();
				
				var on_click = "showResponse3DMatrixDashboard('default',"+quid+",'"+scope+"','"+sites+"','"+pgmid+"','"+dateBegin+"','"+dateEnd+"','"+notSelectedIds+"','"+orderBy+"','"+questionType+"','"+associationitemid+"','"+selecteduserid+"','"+selColumnID+"');";
				$('#viewdetails_'+globalQuid).attr('onclick', on_click);
				resizeContainer();	
			}
		});
	}
}

function showResponseMatrix_volunteers(bShowAnswers,quid,scope,sites,pgmid,dateBegin,dateEnd,notSelectedIds,orderBy,questionType,selectedRowID,selectedColumnID,associationuserlist,completeidlist,qsurveysiteuserid,chkdItemList,volunteeruserid){
	globalQuid = quid;
	var prefix = '/index.cfm?event=';
	var questionID = quid;
	beginSurvey = dateBegin;
	endSurvey = dateEnd;
	
	//show loading img
	if(bShowAnswers == 'rowTotal'){
		nowEl = 'loadingImg_rowTotal_' + quid;	
		document.getElementById(nowEl).style.visibility = "visible";
	}
	else if(bShowAnswers == 'launchDate' || bShowAnswers == 'rowVariables'){
		nowEl = 'loadingImg_launchDate_' + quid;	
		document.getElementById(nowEl).style.visibility = "visible";
	}
	else if(bShowAnswers == 'rowTotal_rowBreakout' || bShowAnswers == 'rowTotal_rowBreakoutHide' || bShowAnswers == 'launchDate_rowBreakout' || bShowAnswers == 'launchDate_rowBreakoutHide'){
		nowEl = 'loadingImg_rowBreakout_' + quid;	
		document.getElementById(nowEl).style.visibility = "visible";
	}
	/*else if(bShowAnswers == 'rowVariables' || bShowAnswers == 'launchDate_surveyAliasTotal'){
		nowEl = 'loadingImg_rowVariables_' + quid;	
		document.getElementById(nowEl).style.visibility = "visible";
	}*/
	else if(bShowAnswers == 'rowTotal_col' || bShowAnswers == 'launchDate_col' || bShowAnswers == 'rowTotal_rowBreakout_col' || bShowAnswers == 'rowTotal_rowBreakoutHide_col' || bShowAnswers == 'launchDate_rowBreakout_col' || bShowAnswers == 'launchDate_rowBreakoutHide_col'){
		nowEl = 'loadingImg_col_' + quid;	
		document.getElementById(nowEl).style.visibility = "visible";
	}
	
	$('#chkdItemList_'+quid).val(chkdItemList);
	
	var url;
	
	url = "survey.showMatrixQuesAnswers";
	
	url = prefix + url;

	try{
		parameterVar = jQuery.extend({},parameterVar,{
			questionid : questionID, scope : scope, sites : sites, pgmid : pgmid, beginsurvey : beginSurvey, endsurvey : endSurvey, 
			notselectedids : notSelectedIds, orderBy : orderBy, questionType : questionType, viewType : bShowAnswers, selectedRowID: selectedRowID, selectedColumnID: selectedColumnID, 
			associationuserlist : associationuserlist, completeidlist : completeidlist, qsurveysiteuserid : qsurveysiteuserid, chkdItemList:chkdItemList,
			volunteeruserid : volunteeruserid
		});
	}
	catch(err){
		parameterVar = {
			questionid : questionID, scope : scope, sites : sites, pgmid : pgmid, beginsurvey : beginSurvey, endsurvey : endSurvey, 
			notselectedids : notSelectedIds, orderBy : orderBy, questionType : questionType, viewType : bShowAnswers, selectedRowID: selectedRowID, selectedColumnID: selectedColumnID, 
			associationuserlist : associationuserlist, completeidlist : completeidlist, qsurveysiteuserid : qsurveysiteuserid, chkdItemList:chkdItemList,
			volunteeruserid : volunteeruserid
		}
	}
	new Ajax.Request(encodeURI(url), {
		method: 'post',
		parameters: parameterVar,
		onSuccess: function (returnHtml) {
			document.getElementById("txtAnswerBox_"+globalQuid).innerHTML = returnHtml.responseText;
			resizeContainer();
		},
		onFailure: function () {
			alert('Oops...mistake on server');
		}
	}); 
	/*$.ajax({
        type: "POST",
        url: encodeURI(url),
        parameters: parameterVar,
		 
        success: function(returnHtml) {		
			document.getElementById("txtAnswerBox_"+globalQuid).innerHTML = returnHtml.responseText;
			resizeContainer();						
        },  
        error: function(data) {
            alert('Oops...mistake on server');
        }
    }); */
}

function resizeContainer(){
	var widthArray = [];
	var mainDiv = $('body').children('.main:first');
	var newMainWidth = '';
	var newSubWidth = '';
	if($('.qualDataTable:visible').length > 0){
		$('.qualDataTable:visible').each(function(){
			widthArray.push($(this).width());
		});
		if(widthArray.max() > 660 ){
			newMainWidth = widthArray.max() + 115;
			newSubWidth = widthArray.max() + 14;
			mainDiv
				.css('width', newMainWidth + 'px')
				.find('.vres').css('width',newSubWidth + 'px')
				.find('table.compile').css('width','100%');
			mainDiv
				.find('.vrestop').css('width',newSubWidth + 'px');
			mainDiv
				.find('.fullpagetop table').css('width','100%');	
			mainDiv
				.find('hr').css('width','95%');
			mainDiv
				.find('.showquestionanswer_row').css('width','99%');
		}else{
			mainDiv
				.removeAttr('style')
				.find('.vres').removeAttr('style');
			mainDiv
				.find('.vrestop').removeAttr('style');
			mainDiv
				.find('.fullpagetop table').removeAttr('style');
			mainDiv
				.find('hr').removeAttr('style');
		}
	}else{
		mainDiv = $('body').children('.main:first');
		mainDiv
			.removeAttr('style')
			.find('.vres').removeAttr('style');
		mainDiv
			.find('.vrestop').removeAttr('style');
		mainDiv
			.find('.fullpagetop table').removeAttr('style');
		mainDiv
			.find('hr').removeAttr('style');
	}
}
	
$(document).on('click', '.show-details', function () {
//$(".show-details").on('click',function(){
	var attrID = $(this).attr('id');
	//newID = attrID.split("_");
	
	$(".qualDataTable tr td.hd_"+attrID+"").show();
	$(".qualDataTable tr td.sd_"+attrID+"").hide();
	
	resizeContainer();
	
	//$(".qualDataTable tr td.hd_"+attrID+"").attr("id","column_"+newID[1]);
	//$(".qualDataTable tr td.sd_"+attrID+"").removeAttr("id");
	
});

$(document).on('click', '.hide-details', function () {	
//$(".hide-details").on('click',function(){
	var attrID = $(this).attr('id');
	//newID = attrID.split("_");
	
	$(".qualDataTable tr td.sd_"+attrID+"").show();
	$(".qualDataTable tr td.hd_"+attrID+"").hide();
	
	resizeContainer();
	
	//$(".qualDataTable tr td.sd_"+attrID+"").attr("id","column_"+newID[1]);
	//$(".qualDataTable tr td.hd_"+attrID+"").removeAttr("id");
	
	//var class_exist = "hd_"+attrID;
	//var class_new = "matrixColumn_"+newID[3];
	
	//$(".qualDataTable tr td.sd_"+attrID).attr("class", ""+class_exist+" "+class_new);
});


function assignMatrixColumnstoHiddenField(passedMatrixColumnsID,qid) {
	if (document.getElementById("selectedMatrixColumnId_"+qid).value == '') { // if there is no elemen selected
		document.getElementById("selectedMatrixColumnId_"+qid).value = passedMatrixColumnsID;
	} else {
		var hiddenvalue = document.getElementById("selectedMatrixColumnId_"+qid).value;
		var hiddenvaluearray = hiddenvalue.split('^^^');
		var elementexists = 0;
		for (var i = 0; i < hiddenvaluearray.length; i++) {
			if (hiddenvaluearray[i] == passedMatrixColumnsID) {
				hiddenvaluearray.splice(hiddenvaluearray.indexOf(hiddenvaluearray[i]), 1);
				elementexists = 1;
			}
		}
		if (elementexists != 1) {
			if (document.getElementById("selectedMatrixColumnId_"+qid).value != '') {
				document.getElementById("selectedMatrixColumnId_"+qid).value = document.getElementById("selectedMatrixColumnId_"+qid).value + "^^^" + passedMatrixColumnsID;
			} else {
				document.getElementById("selectedMatrixColumnId_"+qid).value = passedMatrixColumnsID;
			}
		} else {
			document.getElementById("selectedMatrixColumnId_"+qid).value = '';
			for (var i = 0; i < hiddenvaluearray.length; i++) {
				if (hiddenvaluearray[i] != passedMatrixColumnsID) {
					if (document.getElementById("selectedMatrixColumnId_"+qid).value == '') {
						document.getElementById("selectedMatrixColumnId_"+qid).value = hiddenvaluearray[i];
					} else {
						document.getElementById("selectedMatrixColumnId_"+qid).value = document.getElementById("selectedMatrixColumnId_"+qid).value + "^^^" + hiddenvaluearray[i];
					}
				}
			}
		}
	}
}

function assignMatrixChkBox(chkBoxName,qid) {
	if (document.getElementById("chkdItemList_"+qid).value == '') { // if there is no elemen selected
		document.getElementById("chkdItemList_"+qid).value = chkBoxName;
	} else {
		var hiddenvalue = document.getElementById("chkdItemList_"+qid).value;
		var hiddenvaluearray = hiddenvalue.split('^^^');
		var elementexists = 0;
		for (var i = 0; i < hiddenvaluearray.length; i++) {
			if (hiddenvaluearray[i] == chkBoxName) {
				hiddenvaluearray.splice(hiddenvaluearray.indexOf(hiddenvaluearray[i]), 1);
				elementexists = 1;
			}
		}
		if (elementexists != 1) {
			if (document.getElementById("chkdItemList_"+qid).value != '') {
				document.getElementById("chkdItemList_"+qid).value = document.getElementById("chkdItemList_"+qid).value + "^^^" + chkBoxName;
			} else {
				document.getElementById("chkdItemList_"+qid).value = chkBoxName;
			}
		} else {
			document.getElementById("chkdItemList_"+qid).value = '';
			for (var i = 0; i < hiddenvaluearray.length; i++) {
				if (hiddenvaluearray[i] != chkBoxName) {
					if (document.getElementById("chkdItemList_"+qid).value == '') {
						document.getElementById("chkdItemList_"+qid).value = hiddenvaluearray[i];
					} else {
						document.getElementById("chkdItemList_"+qid).value = document.getElementById("chkdItemList_"+qid).value + "^^^" + hiddenvaluearray[i];
					}
				}
			}
		}
	}
}

function getUrlVars(queryString){
	var vars = {}, hash;
	var hashes = queryString.split('&');
	for(var i = 0; i < hashes.length; i++){
		hash = hashes[i].split('=');
		vars[hash[0]] = hash[1];
	}
	return vars;
}

function checkFreeTextLimit(num,colnumber,previousvalue,newvalue,stepCounter){
	container = $(".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+colnumber+" #freeText_"+colnumber+" input:eq(0)");
	validateNumeric = checkNumeric(num,container,'free',stepCounter);
	if(validateNumeric == false){
 		return false;
 	}else{
		if(newvalue >= previousvalue){
			return true;
		}else{
			alert("[Step "+stepCounter+"]: Please enter a value which is greater than existing ["+previousvalue+"] one.");
			container.val("");
			setTimeout(function(){
				container.focus();
				if($.browser.mozilla){
					window.getSelection().removeAllRanges();
				}
			},1);
			return false;
		}	
	}
}
function validate_empty(num,rownumber,type){
	if(type=='row')
		var	selectiontext = "#matrix_"+num+"_row .rowsLabelList input[name='matrix_"+num+"_row_"+rownumber+"_name']";
	else if(type=='column')
		var selectiontext = ".3dMatrix_Step2 #matrix_"+num+"_column #columnsAdd_"+rownumber+" .columnsLabelList input[name='matrix_"+num+"_column_"+rownumber+"_name']";
	var ChoiceText = $(selectiontext).val();
	var ChoiceTextnospace = ChoiceText.replace(/ /g, "");
	if(ChoiceTextnospace == ""){
		alert("Please enter a name for the blank "+ type + ".");
		$(selectiontext).focus();
	}
}