
/* Lucky : Start */
var globalQuid, $dialog = {};
var $loadingImageTable = '<table width="100%"><tr><td align="center"><img src="../../images/icons/animated_loading.gif"></td></tr></table>';
var $restoreLink = $('<a href="javascript:void(0)" style="display:none;" class="restoreThis">Restore</a>');

function dialogSettings(title, dialogClass, maxWidth, width, maxHeight, height) {
    return {
        modal: true,
        title: title,
        resizable: false,
        maxWidth: maxWidth,
        maxHeight: maxHeight,
        width: width,
        height: height,
        autoOpen: false,
        //position:['center',50],
        dialogClass: dialogClass
    }
}
$(document).ready(function () { 
	
	/*CPORT-130/CPORT-149:Start*/
	var paneltype = $('.CommunicationsPortalEnable').val(); 
    var paneldisplay = $('.CommunicationsPortalDisplayEnable').val();
    if(paneltype === "CommunicationsPortalEnable" && paneldisplay === "CommunicationsPortalDisplayEnable"){
		console.log("CommunicationsPortal BG");
		var getTargetdDiv = $('.communicationsPortalFlag').attr('rel');
		$('a[rel='+getTargetdDiv+'].showHide.pull-left.hideIt').toggleClass('hideIt showIt');
		communicationPortalEmailSMSEnableDisable(paneltype,getTargetdDiv); 
	}
	/*CPORT-130/CPORT-149:Stops*/

    if ($('body').find('#ajaxFilterLoading').attr('id') != 'ajaxFilterLoading') {
        var html = '<div id="ajaxFilterLoading" style="display:none"><img id="loading" src="../../images/icons/animated_loading.gif"><div>';
        html += '<div></div></div><div class="bg"></div></div>'
        $('body').append(html);
    }

	$dialog.EditPanel = $('<div></div>').dialog(dialogSettings('Edit Panel', 'EditPanel', 500, 500, 500, 500));
    var height = $('body').outerHeight();
    var width = $('body').outerWidth();
    $('#ajaxFilterLoading').css({
        'width': '100%',
        'height': '100%',
        'position': 'fixed',
        'z-index': '10000000',
        'top': '0',
        'left': '0'
    });

    $('#ajaxFilterLoading .bg').css({
        'background': '#000000',
        'opacity': '0.15',
        'width': '100%',
        'height': '100%',
        'position': 'absolute',
        'top': '0'
    });

    $('#ajaxFilterLoading > div:first').css({
        'width': '100%',
        'text-align': 'center',
        'position': 'absolute',
        'left': '0',
        'top': '48%',
        'font-size': '16px',
        'z-index': '10',
        'color': '#ffffff'
    });
    

    function loadStatusHandler(status) {
        if (status == "error") {
            var msg = "Sorry but there was an error.";
           // handledAlert(msg);
        }
    }
	/* BG 591 Changes */
    $.fn.loadDialogContent = function (url, data) {
        this.load(url, data, function (response, status, xhr) {
            loadStatusHandler(status);
        });
    }

    $(document).on('click', 'input.closeDialog', function () {
        var dialog = $(this).attr('data-dialog');
		if(typeof dialog != "undefined")//JS Error Fix
		$dialog[dialog].dialog('close').empty();
	});
	
	//BG-146 : Start
	$(document).on('click', 'button.ui-dialog-titlebar-close', function () {
		$dialog['EditPanel'].dialog('close').empty();
	});
	//BG-146 : Stops
});


function initDatePickerinPopup() {

	 $( ".hiddendate" ).datepicker({
	 changeMonth: true,
	 changeYear: true,
	 dateFormat:'m/d/yy',
	 yearRange: '1900:2100'
	});   
	
	$(document).on('click', '.datelink', function (e) {
	
		theid = $(this).attr('rel'); 
		$('#ui-datepicker-div').removeClass('datePickSelect'); // BG-239
		$('#'+theid).focus();
		/*datepicker({
          changeMonth: true,
          changeYear: true,
		  dateFormat:'m/d/yy',
          yearRange: '1900:2024'
     	});*/
		$(this).text('Edit');
	});
	$(document).on('change', '.hiddendate', function (e) {
		var id = $( this ).attr('rel'); 
		$('#'+id).val($(this).val());
	}); 

	//BG-110 : Start
    $( ".hiddendateAnother" ).datepicker({
		changeMonth: true,
		changeYear: true,
		dateFormat:'m/d/yy',
		yearRange: '1900:2100',
		maxDate: 0
	   });
	$(document).on('click', '.datelinkAnother', function (e) {
		theid = $(this).attr('rel');
		//$('#ui-datepicker-div').addClass('datePickSelect'); // BG-239 // BG-307
		$('#ui-datepicker-div').removeClass('datePickSelect'); // BG-307
		$('.UIDatePicker').append($('#ui-datepicker-div')); // BG-239
		$('#'+theid).focus();		
	});
	$(document).on('change', '.hiddendateAnother', function (e) {
		var id = $( this ).attr('rel'); 
		$('#'+id).val($(this).val());
		
		$('#'+id).css("display","block");
		$('#'+id+"_linkText").text('Edit');
	});
	//BG-110 : End
}

function hideSelectedDate(id){
	$('#attribute_'+id+'_label').val('');
	$('#attribute_'+id).val('');
	//$('#attribute_'+id+'_linkText').css("padding-left","19px");
	$('#attribute_'+id+'_linkText').html('Set');
	$('#attribute_'+id+'_dateClear').html('');
}
function showDateClear(id){
	selectedValue = $('#attribute_'+id).val();
	if(selectedValue != null){
		$('#attribute_'+id+'_dateClear').html('Clear Date');
	}
}

function isValidDate2(input) {
	  var regexes = [
		/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/,
		/^(\d{1,2})\-(\d{1,2})\-(\d{4})$/
	  ];

  for (var i = 0; i < regexes.length; i++)
  {
		var r = regexes[i];
		if(!r.test(input)) {
		  continue;
		}
		var a = input.match(r), d = new Date(a[3],a[1] - 1,a[2]);
		if(d.getFullYear() != a[3] || d.getMonth() + 1 != a[1] || d.getDate() != a[2]) {
		  continue;
		}
		// All checks passed:
		return true;
  }

  return false;
}

function isValidMobileNumber(mobile) {
	/*mobile = mobile.replace(/-/g,'');
	var mob = /^[1-9]{1}[0-9]{9}$/;        
	if (mob.test(mobile) == false) {
		return false;
	}*/
	
	mobilelength = mobile.length;
	if(mobilelength != 12){
		return false;
	}
	return true;
}

$(document).on('keypress', '.monthdatefield', function (e) {               
	var regex = new RegExp("^[0-9/\b\t]+$");
	//alert(e.charCode);
	var specialKeys = new Array();
		specialKeys.push(8); //Backspace
		specialKeys.push(9); //Tab
		specialKeys.push(46); //Delete
		specialKeys.push(36); //Home
		specialKeys.push(35); //End
		specialKeys.push(37); //Left
		specialKeys.push(39); //Right
	var keyCode = e.keyCode == 0 ? e.charCode : e.keyCode;
	var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
	if (regex.test(str)  || (specialKeys.indexOf(e.keyCode) != -1 && e.charCode != e.keyCode)) {
		return true;
	}

	e.preventDefault();
	return false;
});

$(document).on('keyup', '.monthdatefield', function (e) { 
	var isValid = isValidDate2($(this).val());
	 if($(this).val()!=""){
	 if (isValid) {
		//alert('Valid date');
		 $("#datetext_"+$(this).attr("rel")).css("display","none");
		 $("#"+$(this).attr("id")+"_linkText").text("Edit");
		  $("#"+$(this).attr("id")+"_dateClear").text("Clear Date");
	  } else {
	   // alert('Invalid date');
		  $("#datetext_"+$(this).attr("rel")).css("display","inline");
	  }
	}
	else
	{
		$("#"+$(this).attr("id")+"_linkText").text("Set");
		$("#"+$(this).attr("id")+"_dateClear").text("");
	}  
});


$(document).on('click', 'a.showHide,span.showHide', function (e) {
    var $headingDiv = $(this).closest('.dataGroupHeader');
    e.stopPropagation();
    if (!$headingDiv.hasClass('loading')) {
        $headingDiv.addClass('loading');
        var $link = $('a.showHide', $headingDiv);
		var $link_text = $('span.showHide', $headingDiv); //<!---SQM-669--->	
        var $popupdiv = $('a.div.editbutton', $headingDiv);
        var relValue = $link.attr('rel');
		    //var associationidForVolunteerLogin = $('#associationid').val();//Commented & Used Below For CPORT-130
        if ($link.hasClass('hideIt')) {
            $link.siblings('.editbutton').slideToggle('slow');
            $('.' + relValue).slideToggle('slow', function () {
                $headingDiv.removeClass('loading');
            });
            $link.toggleClass('hideIt showIt');
			$link_text.removeClass('gtclass'); //<!---SQM-669--->
        } 
		else 
		{	
			/*CPORT-98/CPORT-149:Start*/
			var panelValue = $(this).next("span").text(); 
            if(panelValue === ""){ 
                panelValue = $(this).text();
            }   
			if(panelValue.trim() === "Communications History (Outbound)"){
				communicationPortalEmailSMSEnableDisable(panelValue.trim(),relValue);	/*CPORT-130:Stops*/
			}
			/*CPORT-98:Stops*/
			$link.siblings('.editbutton').slideToggle('slow');
			if(panelValue.trim() != "Communications History (Outbound)"){
				$('.' + relValue).slideToggle('slow', function () {
					$headingDiv.removeClass('loading');
				});
				$link.toggleClass('hideIt showIt');
			}
			if ($link_text.hasClass('gtpanel')) {$link_text.addClass('gtclass')} //<!---SQM-669--->
        }
		/*CPORT-149:Stops*/
    }
});

$(document).on('click', '.editbutton', function (e) {
   var panelid = $(this).attr('data-association-panel-id');
   var panelname = $(this).attr('data-association-panel-name');
   var subpanelid = $(this).attr('data-association-subpanel-id');
   var openedPanels = [];
	$('a.showHide').each(function(){
	 
		if($(this).hasClass('hideIt'))
		{	
			 
			panelId = $(this).attr('rel1');
			openedPanels.push(panelId);
		}
	});
	/*bg-46-Start */
	var closedPanels = [];
	$('a.showHide').each(function(){
	 
		if($(this).hasClass('showIt'))
		{	
			 
			panelId = $(this).attr('rel1');
			closedPanels.push(panelId);
		}
	});
	/*bg-46-End */
   $dialog.EditPanel.dialog(dialogSettings(panelname, 'EditPanel', 765, 765, 500, 'auto'));
   $dialog.EditPanel.dialog('open')
   .html($loadingImageTable)
   	/*bg-46-Start */
   .loadDialogContent(root + "association.editidentifierPanel&panelid="+panelid+"&associationitemid="+associationitemid+"&associationid="+associationid+"&subpanelid="+subpanelid+"&openedPanels="+openedPanels+"&closedPanels="+closedPanels);
	$(".EditPanel").addClass('_popup-center_');//MCR-184
});

/* BG-591 start Pooja */ 
$(document).on('click', '.editLink', function (e) {
	
	var userId = $(this).attr('user-id');
	var connectionDate = $(this).attr('date-value');
	var disconnectionDate = $(this).attr('date-value2');
	var connectionTrackId = $(this).attr('conn-trackerId');
	var disconnectionTrackId = $(this).attr('disconn-trackerId');
	var isPreviousAssign = $(this).attr('isPreviousAssign');
	 var panelid = 0;
	
	var subpanelid = 0;
	var openedPanels = [];
	$('a.showHide').each(function(){
	 
		if($(this).hasClass('hideIt'))
		{	
			 
			panelId = $(this).attr('rel1');
			openedPanels.push(panelId);
		}
	});

	var closedPanels = [];
	$('a.showHide').each(function(){
	 
		if($(this).hasClass('showIt'))
		{	
			 
			panelId = $(this).attr('rel1');
			closedPanels.push(panelId);
		}
	});
	
	var data = {
		userIdfk: userId,
		associationitemid: associationitemid,
		associationid: associationid,
		connectionDate: connectionDate,
		disconnectionDate: disconnectionDate,
		connectionTrackId: connectionTrackId,
		disconnectionTrackId: disconnectionTrackId,
		isPreviousAssign: isPreviousAssign,
		subpanelid: subpanelid,
		openedPanels: openedPanels,
		closedPanels: closedPanels,
		panelid:panelid
	} 
	$dialog.EditPanel.dialog(dialogSettings("Edit Assignment Date" , 'EditPanel', 765, 500, 500, 'auto'));
	$dialog.EditPanel.dialog('open')
	.loadDialogContent(root + "association.volunteerAssignToInfo", data);
	$(".EditPanel").addClass('_popup-center_'); 
		
});
/* BG-591 end Pooja */


$(document).on('click', '.archiveIdentifierLink', function (e) {
	 
	var data = [];
	var datalabel = $(this).attr('data-label');
	var checkidentifier = 0;
	data.push({
					"name": "associationitemid",
					"value": associationitemid
	});	
	data.push({
			"name": "associationid",
			"value": associationid
	}); 
	

	$.ajax({
			type: "POST",
			url: "index.cfm?event=association.CheckDeleteIdentifierExist",
			data: data,
			beforeSend: function() {
            showLoadingOverlay();
        },
        success: function(identifier) 
		{
			result = JSON.parse(identifier);
			if(result.associationItemId > 0)
			{
				if(datalabel.indexOf("Archive") != -1){
				/* Start: BG-1 */
				$.ajax({
						type: "POST",
						url: "index.cfm?event=association.checkIdentifierVolunteerAssignment",
						data: data,
						beforeSend: function() 
						{
							//showLoadingOverlay();
						},
						success: function(result)
						{
							result = JSON.parse(result);
							if (result.volunteercount > 0) {
					
								$dialog.archiveIdentifierConfirm = $('<div></div>').dialog(dialogSettings('Archive', 'ArchiveIdentifier', 500, 500, 800, 'auto'));					
								$dialog.archiveIdentifierConfirm.dialog('open')
								.html($loadingImageTable)
								.loadDialogContent(root + "association.archiveidentifierconfirmation&associationitemid="+associationitemid+"&associationid="+associationid);
							} else {
							$.ajax({
								type: "POST",
								url: "index.cfm?event=association.archiveIdentifier",
								data: data,
								beforeSend: function() {
									showLoadingOverlay();
								},
								success: function(fields) {		
									$('#associationDetailsPanel').html(fields);	
									$(".mail-icn").css('display', 'none');//CP-38
								}, 
								complete:function(fields){	
									hideLoadingOverlay();			
								},
								error: function(data) {
									status = false;
								}
							});
							}
						}, 
						complete:function(data){	
							//hideLoadingOverlay();			
						},
						error: function(data) {
							status = false;
						}		  
							/**/
					}); 
					/* End: BG-1 */
				} else {	
	
	$.ajax({
        type: "POST",
        url: "index.cfm?event=association.restoreIdentifier",
        data: data,
		beforeSend: function() {
            showLoadingOverlay();
        },
        success: function(fields) {		
			//window.location.assign(serveraddress+"association.editassociation?associationid="+associationid);
			 $('#ArchiveDeleteRestore').html(fields);						
			 $(".mail-icn").css('display', 'inline-block');//CP-38
        }, 
		complete:function(fields){	
			hideLoadingOverlay();
			/*$("#selectAssociation").val(option);*/
		 },
        error: function(data) {
            status = false;
        }
    }); 
		
					}
			}
			else
			{
				alert("The Identifier has been deleted");
				$("#CheckDeleteIdentifierForm").submit();
			}

		}, 
		complete:function(data){	
			hideLoadingOverlay();
		 },
        error: function(data) {
            status = false;
        }
    }); 
	
});



$(document).on('click', '.deleteIdentifierLink', function (e) {
	var r = confirm('Are you sure you want to permanently delete this identifier?');
	if (r == true){
	$('#DeleteIdentifierForm').submit(); 
	}
	else{
		return false;
	}
});

function setOpenPanels() {
	var openedPanels = [];
	$('a.showHide').each(function(){
	 
		if($(this).hasClass('hideIt'))
		{	
			 
			panelId = $(this).attr('rel1');
			openedPanels.push(panelId);
		}
	});
	document.getElementById("openedPanels").value = openedPanels;
}
function changeMobileNumber(field,mobfname)
{
	var fval = (field.value).replace(/-/g, "");
	var id = field.name.split("_");
	$("#checkedRecieveText_"+id[1]).prop('checked', false);
	if((fval).length == 10 && isNaN(fval)==false)
	{
		
		showLoadingOverlay();
		 $.ajax({
			type: "post",
			data: {phoneNumber:fval},
			url: "index.cfm?event=user.vaildateMobileNumberBySlooce",			
			success: function(data) { 
				data = JSON.parse(data);
				hideLoadingOverlay();				
				if(data == true)
				{
					$('#receivetexts_'+id[1]).prop('disabled', false);
					$("#checkedRecieveText_"+id[1]).prop('disabled', false);
				}
				else
				{
					var eMsg = data.replace("FieldName", mobfname);
					alert(eMsg);
				}
			}
		  });
	
		if($('#receivetexts_'+id[1]).val() == 1)
		{
			$("#checkedRecieveDiv_"+id[1]).show();
		}
		else 
		{
			$("#checkedRecieveDiv_"+id[1]).hide();
		}
	}
	else
	{
		$("#receivetexts_"+id[1]).prop('disabled', true);
		$("#checkedRecieveText_"+id[1]).prop('disabled', true);
		$("#checkedRecieveDiv_"+id[1]).hide();
	}
}
function CounterAndSelectionAttribute(field,max)
{
var firstCharacter = field.value.substring(0, 1);
var id = field.name.split("_");
var fval = (field.value).replace(/-/g, "");
//this is for the counter to show
		
if (field.value.length > max)
{
	field.value = field.value.substring(0, max);
} 
else 
{ 	
	nowCount = max - field.value.length;
	
	document.getElementById(field.name+"_cnt").childNodes[0].nodeValue = nowCount;
}
	
}

function closeIdentifierWindow() {
	$dialog['EditPanel'].dialog('close').empty();
}

function showLoadingOverlay() {
    $('#ajaxFilterLoading .bg').height('100%');
    $('#ajaxFilterLoading').fadeIn(300);
    $("#ajaxFilterLoading").attr("tabindex", -1).focus();
}

function hideLoadingOverlay() {
    $('#ajaxFilterLoading .bg').height('100%');
    $('#ajaxFilterLoading').fadeOut(300);
}

function findLongestWord(str) {
		if(str!=undefined){
			var words = str.split(' ');
			var maxLength = 0;
			for (var i = 0; i < words.length; i++) {
				if (words[i].length > maxLength) {
				maxLength = words[i].length;
				}
			}

			return maxLength;
		 }
		return 0;
	}
	
/* Start: BG-1 */
$(document).on('click', '.maintainAllAssign', function (e) {    
	//var currentIdnId = jQuery(this).attr('data-itemid');
	var $maintainLink = jQuery('.maintainAssign');
	var $undoLink = jQuery('.undoAssign');
	if ($maintainLink.length){
		$maintainLink.trigger('click');
		jQuery(".volunteerAllAssignment").html('<a class="maintainAllAssign">Maintain None</a>');
	}else{
		$undoLink.trigger('click');
		jQuery(".volunteerAllAssignment").html('<a class="maintainAllAssign">Maintain All</a>');
	}
});
$(document).on('change', '.receivetextsClass', function (e) {
	var name = $(this).attr('name');
	var id = name.split('_');
	if(this.value == 1)
	{
		$("#checkedRecieveDiv_"+id[1]).show();
		
	}
	else if(this.value == 0)
	{
		$("#checkedRecieveDiv_"+id[1]).hide();
		$("#checkedRecieveText_"+id[1]).prop('checked', false);
	}
});
$(document).on('click', '.maintainAssign', function (e) {
	var currentVolunAssignId = $(this).attr('data-userid');
	var currentVolunteerMaintained = "";
	var undoLink = "<a class='undoAssign undoAssign_" + currentVolunAssignId + "' data-userid='" + currentVolunAssignId + "'>Undo</a>"; 
	$(".volunteerAssignment_" + currentVolunAssignId).html("<b>Will Maintain</b> (" + undoLink + ")");
	$(".volunteerAssignment_" + currentVolunAssignId).css('color','#007700');
	if($(".maintainvolunteerassign").val() == '') {
		$(".maintainvolunteerassign").val(currentVolunAssignId);
	} else {
		currentVolunteerMaintained = $(".maintainvolunteerassign").val() + "," + currentVolunAssignId;
		$(".maintainvolunteerassign").val(currentVolunteerMaintained);
	}
});

$(document).on('click', '.undoAssign', function (e) {
	var currentVolunAssignId = $(this).attr('data-userid');
	var currentVolunteerMaintained = $(".maintainvolunteerassign").val().split(",");	
	var maintainLink = "<a class='maintainAssign maintainAssign_" + currentVolunAssignId + "' data-userid='" + currentVolunAssignId + "'>Maintain this Assignment</a>"; 
	$(".volunteerAssignment_" + currentVolunAssignId).html(maintainLink);	
	currentVolunteerMaintained.splice(currentVolunteerMaintained.indexOf(currentVolunAssignId), 1);		
	$(".maintainvolunteerassign").val(currentVolunteerMaintained);
});

/* End: BG-1 */


/* Goal Tracking */
$(document).on('click', '.showhideprogress', function (e) {
	//var currentVolunAssignId = $(this).attr('data-userid');
	e.stopPropagation();
	$(this).next('div.seeprogresspanel').slideToggle('slow');
	if ($(this).hasClass('hideit')) {
		$(this).html('Hide');
	}else {
		$(this).html('See Progress');
	}
	$(this).toggleClass('hideit showit');
});
var $this;
$(document).on('click', '.showhidehistory', function (e) {
	//var currentVolunAssignId = $(this).attr('data-userid');
	$this = $(this);
	e.stopPropagation();
	$(this).parent().next('div.seeprogresspaneltext').slideToggle('slow');
	$(this).toggleClass('hideit showit');
});

function viewIndividualResult(surveydate, userid, surveyid){
	$('form#Survey input#beginsurvey').val(surveydate);
	$('form#Survey input#endsurvey').val(surveydate);
	$('#volunteer').val(userid);
	$('#allavailableSurveyIds').val(surveyid);
	document.Survey.action = 'index.cfm?event=survey.viewindividualresult&requesttimeout=100000';
	document.Survey.submit();
}
/* Goal Tracking */

/* Goal Tracking V2 */
// create time period filter modal
$(document).on('click', 'a.time-period-modal', function(e) {

	var panelquestionid = $(this).attr('data-association-question-id');
	var thisassociationid = $(this).attr('data-association-id');
	var panelitemid = $(this).attr('data-association-item-id');

	var isfiltered = false;
	var begindate = false;
	var enddate = false;
	if (typeof $(this).attr('data-isfiltered') != 'undefined') {
		isfiltered = $(this).attr('data-isfiltered');
	}

	begindate = $('#associationfilterbegindate_'+panelquestionid).val();
	enddate = $('#associationfilterenddate_'+panelquestionid).val();
	begindate = begindate.replace(/;/g, "a");
	begindate = begindate.replace(/:/g, "b");
	begindate = begindate.replace(/ /g, "c");
	begindate = begindate.replace(/-/g, "d");
	enddate = enddate.replace(/;/g, "a");
	enddate = enddate.replace(/:/g, "b");
	enddate = enddate.replace(/ /g, "c");
	enddate = enddate.replace(/-/g, "d");
    

	var panelname = "managegoaltrackingperiod";
	var openedPanels = [];
	$('a.showHide').each(function() {

		if ($(this).hasClass('hideIt')) {
			panelId = $(this).attr('rel1');
			openedPanels.push(panelId);
		}
	});

	var closedPanels = [];
	$('a.showHide').each(function() {
		if ($(this).hasClass('showIt')) {
			panelId = $(this).attr('rel1');
			closedPanels.push(panelId);
		}
	});

	//$('#associationfilterlink_'+panelquestionid).html('Modify or Remove Time Period Filter');
	$dialog.EditPanel.dialog(dialogSettings("", 'EditPanel', 400, '360', 400, 'auto'));
	$dialog.EditPanel.dialog('open')
		.html($loadingImageTable)
		/*bg-46-Start */
		.loadDialogContent(root + "association.managegoaltrackingperiod&associationid=" + thisassociationid + "&associationitemid=" + panelitemid + "&question=" + panelquestionid + "&isfiltered=" + isfiltered + "&begindate="+encodeURIComponent(begindate)+ "&enddate="+encodeURIComponent(enddate));
	$(".EditPanel").addClass('_popup-center_');

});

//end  date selection in modal

$(document).on('change', '#begintimeperiod', function(e) {
	var optionTemp = $("#surveydate option").clone(true);
	var question = $('#hiddenquestionid').val();

	var selected = $("#begintimeperiod option:selected").attr('rel');
	$("#endtimeperiod").empty();
	for (i = 0; i <= selected; i++) {
		$("#endtimeperiod").append(optionTemp[i]);
	}

	if (document.getElementById('savefilterdate_' + question).checked) {
		document.getElementById('savefilterdate_' + question).checked = false;
	}

	return false;
});

$(document).on('change', '#endtimeperiod', function(e) {
	var question = $('#hiddenquestionid').val();

	if (document.getElementById('savefilterdate_' + question).checked) {
		document.getElementById('savefilterdate_' + question).checked = false;
	}

	return false;
});
//apply filter using modal


function removefilter(removedata) {

	var panelquestionid = $('#removegoaltrackingfilter').attr('data-association-question-id');
	var panelprogramid = $('#removegoaltrackingfilter').attr('data-association-program-id');
	var panelitemid = $('#removegoaltrackingfilter').attr('data-association-item-id');
	var begindate = 0;
	var enddate = 0;

	if (removedata) {
		var removefilterdata = 1;
	}

	$.ajax({
		type: "POST",
		url: "index.cfm?event=association.goaltracking_association&programid=" + panelprogramid + "&associationitemid=" + panelitemid + "&question=" + panelquestionid + "&removefilter=" + removefilterdata,

		beforeSend: function() {
			showLoadingOverlay();

		},
		success: function(fields) {
			/*$dialog.EditPanel.dialog('open')
                           .html($loadingImageTable)
   	
                          .loadDialogContent(root + "association.managegoaltrackingperiod&programid="+panelprogramid+"&associationitemid="+panelitemid+"&question="+panelquestionid);
	                       $(".EditPanel").addClass('_popup-center_');*/
			$('.modal-label-' + panelquestionid).hide();
			$('#associationfilterlink_' + panelquestionid).html('Create Time Period Filter');
			$('#associationfilterlink_' + panelquestionid).removeAttr('data-isfiltered');
			$("#associationfilterbegindate_"+panelquestionid).val('');
			$("#associationfilterenddate_"+panelquestionid).val('');
		},
		complete: function(fields) {
			hideLoadingOverlay();
		},
		error: function(data) {
			status = false;
		}
	});

	$.ajax({
		type: "POST",
		url: "index.cfm?event=association.goaltracking_association&programid=" + panelprogramid + "&associationitemid=" + panelitemid + "&question=" + panelquestionid + "&beginsurvey=" + begindate + "&endsurvey=" + enddate,

		beforeSend: function() {
			showLoadingOverlay();

		},
		success: function(fields) {
			$('#filterassociationdata_' + panelquestionid).html(fields);


			closeIdentifierWindow()
		},
		complete: function(fields) {
			hideLoadingOverlay();
		},
		error: function(data) {
			status = false;
		}
	});

}

function applyselectdate(panelquestionid, panelitemid, updatefilter) {

	var valuechecked = '';
	var updatechecked = '';
	if (updatefilter) {
		if (document.getElementById('savefilterdate_' + panelquestionid).checked) {
			updatechecked = 1;

		}

	}
	var begindate = $("#begintimeperiod").val();
	var enddate = $("#endtimeperiod").val();

	$('label.modal-label-' + panelquestionid +' span.begin-label').html( $("#begintimeperiod option:selected").attr('data-begin-label') );
	$('label.modal-label-' + panelquestionid +' span.end-label').html( $("#endtimeperiod option:selected").attr('data-end-label') );
   
  $("#demo").val("begindate");
	if (document.getElementById('savefilterdate_' + panelquestionid).checked) {
		valuechecked = 1;
	}

	var data = {
		"question": panelquestionid,
		"beginsurvey": begindate,
		"endsurvey": enddate,
		"valuechecked": valuechecked,
		"associationitemid": panelitemid,
		"updatechecked": updatechecked
	};

	$.ajax({
		type: "POST",
		//url: "index.cfm?event=association.goaltracking_association&question="+panelquestionid+"&beginsurvey="+begindate+"&endsurvey="+enddate+"&valuechecked="+valuechecked+"&associationitemid="+panelitemid+"&updatechecked="+updatechecked,
		url: "index.cfm?event=association.goaltracking_association",
		data: data,
		beforeSend: function() {
			showLoadingOverlay();

		},
		success: function(fields) {
			$('.modal-label-' + panelquestionid).show();
			$('#associationfilterlink_' + panelquestionid).html('Modify'); //Modify or Remove Time Period Filter
			$('#filterassociationdata_' + panelquestionid).html(fields);
			$('#associationfilterlink_' + panelquestionid).attr('data-isfiltered', 'true');
			 $("#associationfilterbegindate_"+panelquestionid).val(begindate);
			 $("#associationfilterenddate_"+panelquestionid).val(enddate);
             
			closeIdentifierWindow()
		},
		complete: function(fields) {
			hideLoadingOverlay();
		},
		error: function(data) {
			status = false;
		}
	});

}

/*CPORT-130/CPORT-149:Start*/
function communicationPortalEmailSMSEnableDisable(paneltype,relValue){
	var associationidForVolunteerLogin = $('#associationid').val(); 
	$.ajax({
		type: "post",
		url: "index.cfm?event=content.getAmericaLearnsEmailSMSMasterDetails&source=editidentifier&userid=0&associationitemid="+associationitemid+"&associationidForVolunteerLogin="+associationidForVolunteerLogin, 	
		beforeSend: function() {
			$('.ajaxFilterLoadingForCP').css('display','block');
			$('#loadingForCP').show(); 
		},			
		success: function(data) { 
			if(data != ""){						
				$("#CommunicationsPortalEmails").html(data);									
			}
		},
		complete:function() {
			if(paneltype === "Communications History (Outbound)"){
				$('.' + relValue).slideDown('slow', function () {
					$('div.dataGroupHeader.panel_head.loading').removeClass('loading');
				});
			}
			$('a[rel='+relValue+'].showHide.pull-left.showIt').toggleClass('hideIt showIt');
			$('.ajaxFilterLoadingForCP').css('display','none');
			$('#loadingForCP').hide(); 
		},
		error: function(data) { 
			alert("Oops... a server error occurred.");
		}
	});
}
/*CPORT-130/CPORT-149:Stop*/


/*Dhreeti : BG-577 start */

$(document).on('click','ul[name="Sitesassignedtofield"] li',function()
{
		var value = $(this).attr("data-value");
		var classattr = $(this).attr("class");
		var selector = '#' + $(this).closest("ul").attr("id");
        var Attr_id_temp = selector.split("_");
        var Attr_id =Attr_id_temp[1];
		var AllOptions = $(selector);       
		var that = this;               
		var id = $(this).closest("ul").attr("id");       
	
		var countSite=0;
		$(selector+ ' li').each(function(){ 
			if( $(this).attr('data-value') > 0 ){
				countSite=countSite+1;
			}
		});
		if(classattr == "sitelist" || classattr == "fixedOption"){

			if(id == 'Sitesassignedtofield_'+Attr_id && countSite>0)
			$('.noAssignment_'+Attr_id).hide();
		    else
			$(that).closest('tr').prev('tr').eq(0).find('.noAssignment_'+Attr_id).hide();  
	
		if(value == 0){
			selectAllOptions(AllOptions,Attr_id);
		} else if(value > 0){
			selectOption(value, that, selector, Attr_id);
		}
		disabledDropdown();
		that.selectedIndex = 0;
		
		var count=0;				
		$('#blueBox_site .checkboxparent .tick').each(function (i) {
			count=count+1;				
		});			
		$('#siteCount').val(count);

		}
			
});

$(document).on('click','.checkboxMock', function(){
	if($(this).hasClass('disabled')){
		return false;
	}
		$(this).toggleClass('tick untick');
		if($(this).next().attr("name") == "Sites") {
			$(this).next().attr("name","") ;
		} else if ($(this).next().attr("name") == "") {
			$(this).next().attr("name","Sites") ;
		} 
		var id = this.id;
        var Attr_id_temp =id.split("_");
        var Attr_id = Attr_id_temp[2];
		var checkBox = document.getElementById( 'input' + id);
		var scopeID = checkBox.getAttribute('data-scopeid');
		var oldText = $( '#scopeSelectToggle_site_'+Attr_id).text();
		checkBox.checked = $(this).hasClass('tick');
		if( $('input[type=checkbox][data-scopeid=' + scopeID + ']:checked').length == $('input[type=checkbox][data-scopeid=' + scopeID + ']').length ){
			var newText = oldText.replace("Select", "Remove");
			$( '#scopeSelectToggle_site_'+Attr_id ).removeClass('select').addClass('remove').text(newText);
		} else {
			newText = oldText.replace("Remove", "Select");
			$( '#scopeSelectToggle_site_'+Attr_id ).removeClass('remove').addClass('select').text(newText);
		}
		$('#restoreThis' + id).toggle();
	
		var tCount=0;
		var count=0;
		$('#blueBox_site_'+Attr_id+' .checkboxparent').each(function (i) {
			tCount=tCount+1;			
		});			
		$('#blueBox_site_'+Attr_id+' .checkboxparent .untick').each(function (i) {
			count=count+1;				
		});		
		tCount= tCount-count;		
		$('#siteCount').val(tCount);
});

$(document).on('click','.restoreThis', function(){
		$(this).closest('.toleft').prev().find('.checkboxMock').trigger('click');
});

$(document).on('click','a.selectOrRemoveLinkk', function(){
        var id = this.id;
        var Attr_id_temp =id.split("_");
        var Attr_id = Attr_id_temp[2];
		var $link = $(this);
		var link = this;
		link.style.display = 'none';
		try{
			var $blueBox = $link.siblings('.blueBoxScroll');
			var isSelect = $link.hasClass('select');
			var classOnWhichActionNeeded = '.checkboxMock.' + (isSelect ? 'untick' : 'tick');
			var startTime = new Date().getTime();
			var checkBoxes = $blueBox.find(classOnWhichActionNeeded).get();
			for( i = 0; i < checkBoxes.length; i++){
				that = checkBoxes[i];
				classes = that.className;
				if(!classes.includes("disabled")){
				hasTick = /(?:^|\s)tick(?!\S)/.test(classes);
				regex = new RegExp('\\b' + ( hasTick ? 'tick' : 'untick' ) + '\\b', 'i');
				replaceWith = hasTick ? 'untick' : 'tick';
				that.className = classes.replace( regex, replaceWith )
				id = that.id;
				checkBox = document.getElementById( 'input' + id);
				checkBox.checked = !hasTick;
				document.getElementById( 'restoreThis' + id ).style.display = hasTick ? 'inline' : 'none';

				if(that.nextElementSibling.getAttribute("name") == "Sites") {
					that.nextElementSibling.setAttribute("name", ""); 
				} else if (that.nextElementSibling.getAttribute("name") == "") {
					that.nextElementSibling.setAttribute("name", "Sites");
				}  
			}
			}
			var checkBox = checkBoxes[0];
			var oldText = $( '#scopeSelectToggle_site_'+ Attr_id ).text();
			var newText = ''; 
			if( $('input[type=checkbox][data-scopeid=site_'+Attr_id+']:checked').length == $('input[type=checkbox][data-scopeid=site_'+Attr_id+']').length ){
				newText = oldText.replace("Select", "Remove");
				$( '#scopeSelectToggle_site_'+Attr_id).removeClass('select').addClass('remove').text(newText);
			} else {
				newText = oldText.replace("Remove", "Select");
				$( '#scopeSelectToggle_site_'+Attr_id).removeClass('remove').addClass('select').text(newText);
			}
		} catch(err) {
			link.style.display = 'inline';
			throw 'Error';
		}
		link.style.display = 'inline';
			
		var count=0;				
		$('#blueBox_site_'+Attr_id+' .checkboxparent .tick').each(function (i) {
			count=count+1;				
		});			
		$('#siteCount').val(count);
		
});

function selectOption(value, option, selectId, Attr_id){
    var specific_bluebox= "#blueBox_site_"+Attr_id;     
	var scopeID = $(selectId).data('scopeid'); 
	if(scopeID !== undefined ){
		var scopeName = 'scope_' + scopeID;
	} else {
		var scopeName = 'Sites';
		//scopeID = 'site';
	}

	checkMarkId = (scopeID !== undefined) ? ( 'Assoc_' + scopeID + '_' + value ) : ( 'Site_' + value );
	inputId = 'input' + checkMarkId + '_'+ Attr_id;
	restoreId = 'restoreThis' + checkMarkId +'_'+ Attr_id;
	sitename = $(option).attr("site-name");
	var rowStr = '<div class="selectedScope">' + 
			'<div class="toleft checkboxparent">' + 
				'<a href="javascript:void(0);" class="checkboxMock tick hii" id="' + checkMarkId + '_' + Attr_id + '">X</a>' + 
				'<input class="scopes" type="checkbox" value="' + sitename +'~' + value +'~'+ Attr_id +'" data-scopeid="site_'+ Attr_id +'" name="' + scopeName + '" id="' + inputId + '" checked="checked"/>' + 
			'</div><div class="toleft" style="width:300px;word-break:break-word;">' + $('<div>').text($(option).text()).html() + ' ' +
				'<a href="javascript:void(0)" class="restoreThis" id="' + restoreId + '" style="display:none;">Restore</a>' + 
			'</div><div class="clear"></div></div>';
	$('#scopeSelectToggle_site_'+Attr_id).show();
	if($(option).closest('ul').hasClass('singleScope'))
		$("#blueBox_site_"+Attr_id).append(rowStr);
	else
		$(option).closest('tr').prev('tr').eq(0).find("#blueBox_site_"+Attr_id).append(rowStr);
	$("#blueBox_site_"+Attr_id).scrollTop($("#blueBox_site_"+Attr_id)[0].scrollHeight);    
	$(option).remove();
	
	blueboxcount(specific_bluebox,Attr_id);
}

function selectAllOptions(select,Attr_id){  
    
	var options = select.find("li");
	var optionslen = select.find('li').length; 
	var specific_bluebox= "#blueBox_site_"+Attr_id;

	var blueBoxScroll;
	if( /(?:^|\s)singleScope(?!\S)/.test( select.attr("class") ) )
		blueBoxScroll = $("#blueBox_site_"+Attr_id)[0];
	else
		blueBoxScroll = $(select).closest('tr').prev('tr').find("#blueBox_site_"+Attr_id)[0];

	var rowStr = '';
    var activeoptions = "";

	for (i = 1; i < optionslen; i++) {
		if (!((options[i].className) == "sitelist  inactive")) { 
				    
					thisOption = options[i];
					value = $(thisOption).attr("class");
					value = $(thisOption).attr("data-value");
					sitename = $(thisOption).attr("site-name");
					checkMarkId ='Site_' + value+ '_'+Attr_id;
					inputId = 'input' + checkMarkId;
					restoreId = 'restoreThis' + checkMarkId;
					rowStr += '<div class="selectedScope">' +
						'<div class="toleft checkboxparent">' +
						'<a href="javascript:void(0);" class="checkboxMock tick" id="' + checkMarkId + '">X</a>' +
						'<input class="scopes" type="checkbox" value="' + sitename +'~' + value +'~'+ Attr_id +'" data-scopeid="site_'+ Attr_id +'" name="Sites" id="' + inputId + '" checked="checked"/>' +
						'</div><div class="toleft" style="width:300px;word-break:break-word;">' + thisOption.innerHTML + ' ' +
						'<a href="javascript:void(0)" class="restoreThis" id="' + restoreId + '" style="display:none;">Restore</a>' +
						'</div><div class="clear"></div></div>';
                    
                    $(thisOption).remove();	
		}

	} 
   
	blueBoxScroll.innerHTML = blueBoxScroll.innerHTML + rowStr;    
	$('#blueBox_site_'+Attr_id).scrollTop($('#blueBox_site_'+Attr_id)[0].scrollHeight);   
	$('#scopeSelectToggle_site_'+Attr_id).show();
	
	blueboxcount(specific_bluebox,Attr_id); 
}

function blueboxcount(specific_bluebox, Attr_id){
	  
	var divcount = $(specific_bluebox+' .selectedScope').length;		
	if(divcount < 2 ){
		$('#scopeSelectToggle_site_'+Attr_id).css("display","none");
	}else{			
		$('#scopeSelectToggle_site_'+Attr_id).css("display","block");
	}
}

function disabledDropdown(){
          
		$(".picklist li").hover(function(){
			$(this).css("background-color", "white");
		}, function(){
			$(this).css("background-color", "");
		});
		
		var assignmentType = $('input[name="AssignmentType"]:checked').val();		
		var fixedOption = 0;		
		var active = 0;
		var inactive = 0;

		$('select[id="AllSites"] option').each(function(index,value) {						
				if($(this).attr("class") == 'inactive hidden'){
					inactive++;
				}else if($(this).attr("class") == 'inactive'){
					inactive++;
				}else if($(this).attr("class") == 'active'){
					active++;					
				}else if($(this).attr("class") == 'fixedOption'){
					fixedOption++;
				}
		});	

		if(assignmentType == 1){				
			if(fixedOption == 2 && active == 0){
				$("#AllSites").attr("disabled", true);
			}else if(fixedOption == 1 && active == 0){
				$("#AllSites").attr("disabled", true);
			}else{
				$("#AllSites").attr("disabled", false);
			}
			

		}else if(assignmentType == 2){
			if(fixedOption == 2 && active == 0 && inactive == 0){
				$("#AllSites").attr("disabled", true);
			}else if(fixedOption == 1 && active == 0 && inactive == 0){
				$("#AllSites").attr("disabled", true);
			}else{
				$("#AllSites").attr("disabled", false);
			}
		
		} 	
		
		var AllTimeAssignmentType = $('input[name="AllTimeAssignmentType"]:checked').val();		
		if(AllTimeAssignmentType == 1){				
			$('.customviewsection').css("display","none");				
		}else if(AllTimeAssignmentType == 2){
			$('.customviewsection').css("display","block");		
		}	
		
}

/* Dhreeti :BG-577 end */
