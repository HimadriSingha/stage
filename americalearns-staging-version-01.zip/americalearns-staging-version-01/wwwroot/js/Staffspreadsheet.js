var globalQuid, $dialog = {};
var $loadingImageTable = '<table width="100%"><tr><td align="center"><img src="../../images/icons/animated_loading.gif"></td></tr></table>';
var $restoreLink = $('<a href="javascript:void(0)" style="display:none;" class="restoreThis">Restore</a>');
function dialogSettings(title, dialogClass, maxWidth, width, maxHeight, height ){
    return {
        modal:true, 
        title: title, 
        resizable:false, 
        maxWidth: ( maxWidth === undefined ) ? 500 : maxWidth,
        maxHeight: maxHeight,
        width: ( width === undefined ) ? 350 : width,
        height: height,
        autoOpen: false,
        position:['center',50],
        dialogClass:dialogClass,
		close: function(event, ui) {
			jQuery(this).empty();
		}
    }
}

$(document).ready(function(){	
	if ($('body').find('#ajaxFilterLoading').attr('id') != 'ajaxFilterLoading') {
        var html = '<div id="ajaxFilterLoading" style="display:none"><img id="loading" src="../../images/icons/animated_loading.gif"><div>';
        html += '<div></div></div><div class="bg"></div></div>'
        $('body').append(html);
    }

    var height = $('body').outerHeight();
    var width = $('body').outerWidth();
    $('#ajaxFilterLoading').css({
        'width': '100%',
        'height': '100%',
        'position': 'fixed',
        'z-index': '10000000',
        'top': '0',
        'left': '0'
    });

    $('#ajaxFilterLoading .bg').css({
        'background': '#000000',
        'opacity': '0.15',
        'width': '100%',
        'height': '100%',
        'position': 'absolute',
        'top': '0'
    });

    $('#ajaxFilterLoading > div:first').css({
        'width': '100%',
        'text-align': 'center',
        'position': 'absolute',
        'left': '0',
        'top': '48%',
        'font-size': '16px',
        'z-index': '10',
        'color': '#ffffff'
    });
	//$dialog.deletesavedtemplate = $('<div></div>').dialog(dialogSettings('', 'deletesavedtemplate', 550, 550, 500, 460)); /* MV-893 */
	//$("#jWindow").dialog({ autoOpen: false, modal: true, height: 590, width: 1005 });
	$(".check_required").click(function(){		
		$(this).prop("checked","true");
	});
	/*MS-216*/
	$('input:checkbox').each(function(){
		if($(this).is(":checked")) {
			$(this).closest('.columngroup').addClass("check_bgcolor");
			$(this).closest('.association_fields').addClass("check_bgcolor");
		}
    });
    	/*MS-216*/
	alertNoData();			
	if($('.temp_radio').length == 0 )
	{
			 $(".template_selection").html('<span class="pull-left template_msg">Your Saved Templates (none available)</span>');
	} 
	$(document).on('change','input[type=radio][name=view_selection]',function() {		
		this.value = htmlEncode(this.value);//Pen_test_issue_Deva
		$('.templateidtemp').hide();													 
		$('.templateid_'+this.value).show();
		$('.btnClass').attr('disabled',false);
	});
	$('a.showHide, .contentHead').on("click", function(e){
        var $headingDiv = $(this).closest('.dataGroupHeader');
        var isTimesheet = $headingDiv.hasClass('timesheet');
        var templateID = $('#thisUserTemplateAssigned').val() || 0;
        e.stopPropagation();
        if( ! $headingDiv.hasClass('loading') ){
            $headingDiv.addClass('loading');
            var $link = $('a.showHide' ,$headingDiv);
            var relValue = $link.attr('rel');
            if($link.hasClass('hideIt')){
		if(! $link.siblings('#dialogPanelFieldEdit').hasClass('delete_anchor'))	
			$link.siblings('.editbutton').slideToggle('slow');
                if( isTimesheet && templateID != '' && templateID != 0 ){
                    $link.siblings('.linkTemplateDashboard').slideToggle('slow');
                }
                $('#'+relValue).slideToggle('slow', function(){
                    $headingDiv.removeClass('loading');
                });
                $link.toggleClass('hideIt showIt');
                $('#hide'+relValue).val(1);
            } else {
			
		if(!$link.siblings('#dialogPanelFieldEdit').hasClass('delete_anchor'))		
			$link.siblings('.editbutton').slideToggle('slow');
                
                if(isTimesheet && templateID != '' && templateID != 0){
                    $link.siblings('.linkTemplateDashboard').slideToggle('slow');
                }
                $('#'+relValue).slideToggle('slow', function(){
                    $headingDiv.removeClass('loading');
                });
                $link.toggleClass('hideIt showIt');
                $('#hide'+relValue).val(0);		
            }
            $('#'+relValue).focus();		
        }
        syncHeight();
        return false;
    });
	$(document).on('click','#rad_saved_views',function() {	
	//$('#rad_saved_views').click(function(){		
		if ($('.template_div').css('display') == 'none') {
			$('.template_div').slideDown(1000);
		}
		else
		{
			$('.template_div').slideUp(1000);
		}
	});
	
	$(".DisplayFields").click(function(){
		var temp_id= $(".temp_radio:checked").val();
		$("#savedtemplatename").val(encodeURI(temp_id));
		var formcusttoken = $("#formcusttoken").val();   
		$.ajax({
			type:"post",
			url:"/index.cfm?event=user.stafftemplateselectedvalues",
			data:{temp_id:temp_id,formcusttoken:formcusttoken},
			datatype:"json",
			beforeSend: function(){
			 //$("#ajaxFilterLoading").show();
			// $("div[id^='userAssign']#").slideUp(500);
			// $('a[rel^="userAssign"]').addClass("showIt");
			},
			/*complete: function(){
			 $("#ajaxFilterLoading").hide();
			},*/
			success: function(Survey)
			{ 
				$(':checkbox').prop("checked", false);
				//$("input[id^='checkpanel_']#").closest('.columngroup').removeClass("check_bgcolor"); 
				//$("input[id^='checkpanel_']#").closest('.association_fields').removeClass("check_bgcolor");
				$.each($.parseJSON(Survey), function(key,value){
					$.each(value, function(i,obj){
						$('#checkpanel_'+obj.staffFieldId+'.userAssignPanel_'+obj.staffPanelId+'_Select_Child').prop("checked", true);
						
						$('#checkOption_'+obj.selectOptionField).prop("checked", true);
						$('#checkOption_'+obj.selectOption).prop("checked", true);
						
						$("#userAssign"+obj.staffPanelId).slideDown(1000);
						$('a[rel="userAssign'+obj.staffPanelId+'"]').removeClass("showIt");
						$('a[rel="userAssign'+obj.staffPanelId+'"]').addClass("hideIt");
						$("#checkpanel_"+obj.staffFieldId).closest('.columngroup').addClass("check_bgcolor"); 
						$("#checkpanel_"+obj.staffFieldId).closest('.association_fields').addClass("check_bgcolor"); 
					});
				});
			}

		});		
	});
	$(".DownloadSelectedTemplate").click(function(){
		var temp_id= $(".temp_radio:checked").val();
		var formcusttoken=$("#formcusttoken").val();
		$.ajax({
			type:"post",
			url:"/index.cfm?event=user.downloadstaffselectedtemplate",
			data:{temp_id:temp_id,formcusttoken:formcusttoken},
			datatype:"json",
			beforeSend: function(){
			 $("#ajaxFilterLoading").show();
			},
			complete: function(){
			 $("#ajaxFilterLoading").hide();
			},
			success: function(Survey)
			{ 		
				$.each($.parseJSON(Survey), function(key,value)
				{
					/* remove class green */
					//$("input[id^='checkpanel_']#").closest('.columngroup').removeClass("check_bgcolor"); 
					//$("input[id^='checkpanel_']#").closest('.association_fields').removeClass("check_bgcolor");						
					$('.check_required').prop("checked", true);
					$('.check_required').closest('.columngroup').addClass("check_bgcolor");
					$('.check_required').closest('.association_fields').addClass("check_bgcolor");						
					window.location.href = "index.cfm?event=user.downloadstaffselectedtemplatepage&Templatename="+value;				
				});
			}		
		});
	}); // eof DownloadSelectedTemplate click
	
    var showChar = 15;
	$('input:file').change(function(){
		var filename = $('input[type=file]').val().replace(/C:\\fakepath\\/i, '');
		var filename= filename.split('.');
		if(filename[0].length > showChar) {
			var c = filename[0].substr(0, showChar);
			var h = filename[0].substr(showChar-1, filename[0].length - showChar);
			$(".filelabel").text(c+"[...]."+filename[1]);
			}
		else
		{
			$(".filelabel").text(filename[0]+"."+filename[1]);
		}
		if ($(this).val()) {
			$('.uploadbtn').css("display","inline");
		} 
	});  
		
	$("a[id^='userAssignPanelSelect']").click(function(){		
		var childid= $(this).attr('class')+"_Child";
		console.log(childid)
		var subchildid= $(this).attr('class')+"_SubChild";
		console.log(subchildid)
		var thisclss=$(this).attr('class');
		console.log(thisclss)
		if($(this).html() == 'Select All')
		{
			$('.'+thisclss).html("Select None");
			$('.'+childid).prop("checked", true);
			$('.'+subchildid).prop("checked", true);
			var name=thisclss.replace('_Select','');			
			$("a[class^='"+name+"']").html("Select None");			
			$('.'+childid).closest('.columngroup').addClass("check_bgcolor");			
			$('.'+subchildid).closest('.columngroup').addClass("check_bgcolor"); 			
		}
		else
		{
		
			var rel=$(this).attr('rel');
			var sitePanelName= siteAlias+ ' Assignment';		
			if(IsSite_Enable == 1 && IsCohort_Enable==0 && sitePanelName == rel){
				$('.'+thisclss).html("Select None");
			}else{
			$('.'+thisclss).html("Select All");
			}
			$('.'+childid).prop("checked", false);			
			$('.'+childid).closest('.columngroup').removeClass("check_bgcolor");	
			var name=thisclss.replace('_Select','');
			$("a[name^='"+name+"']").html("Select All");	
			$('.'+subchildid).prop("checked", false);
			$('.'+subchildid).closest('.columngroup').removeClass("check_bgcolor"); 			
			$('.check_required').prop("checked", true);	/*MS-216*/
			$('.check_required').closest('.columngroup').addClass("check_bgcolor");			
		}	
		var total= $('input[name =childpanelitem]').length;
		var checked = $('input[name =childpanelitem]:checked').length;
		if(checked == total){
			$("#staffAssign_Panel_Select").html("Select None");
		}
		if(total > checked){
			$("#staffAssign_Panel_Select").html("Select All Fields");
		}	
	});	
	$("#staffAssign_Panel_Select").click(function(){
		var total= $('input[name =childpanelitem]').length; 
		var checked = $('input[name =childpanelitem]:checked').length; 
        if($(this).html() == 'Select All Fields')
        {
			$(this).html("Select None");
			$("a[id^='userAssignPanelSelect_']*").html("Select None");
			$("a[id^='userAssignSubPanelSelect_']*").html("Select None");				
			$("div[id^='userAssign']").find(':checkbox').each(function(){
				$(':checkbox').prop("checked", true);
			});		    
			$("input[id^='checkpanel_']*").closest('.columngroup').addClass("check_bgcolor");		        
        }
        else
        {
			$(this).html("Select All Fields");
			$("a[id^='userAssignPanelSelect_']*").html("Select All");
			$("a[id^='userAssignSubPanelSelect_']*").html("Select All");					
			$("input[id^='checkpanel_']*").closest('.columngroup').removeClass("check_bgcolor"); 				
			$("div[id^='userAssign']").find(':checkbox').each(function(){
				$(':checkbox').prop("checked", false);
				$('.check_required').prop("checked", true);
				$('.check_required').closest('.columngroup').addClass("check_bgcolor");				
			});				
        }
    });
	$("a[id^='userAssignSubPanelSelect_']").click(function(){													
		var subchildid= $(this).attr('name')+"_Child";	
		console.log(subchildid)		
		var middleClass = $(this).attr('class');
		var dataPanelID= $("input[id^='checkpanel_']*").attr('data-pid');
		var datasubPanelID= $("input[id^='checkpanel_']*").attr('data-sp-id');
		var lastClass = $(this).attr('sub-pid')+"_SubChild";
		console.log(lastClass)	
		var panelClass = subchildid.replace("_Child","");		
		var id = $("input[id^='checkpanel_']*").val();		
		if($(this).html() == 'Select All' )
		{
			$(this).html("Select None");
			$('.'+subchildid).prop("checked", true); 			
			$('.'+subchildid).closest('.columngroup').addClass("check_bgcolor"); 				
		}
		else
		{
			$(this).html("Select All");
			$('.'+subchildid).prop("checked", false);		
			$('.'+subchildid).closest('.columngroup').removeClass("check_bgcolor");			
		}
		
		var checkbxlenght= $("."+middleClass+'_Select_Child'+':checked').length;
		var totalCheckbxlenght = $("."+middleClass+'_Select_Child').length	
		
		if(checkbxlenght == totalCheckbxlenght){
				$('.'+middleClass+'_Select').html("Select None");
		}
		if(totalCheckbxlenght>checkbxlenght){
				$('.'+middleClass+'_Select').html("Select All");
		}		
		var total= $('input[name =childpanelitem]').length;
		var checked = $('input[name =childpanelitem]:checked').length;
		if(checked == total){
			$("#staffAssign_Panel_Select").html("Select None");
		}
		if(total > checked){
			$("#staffAssign_Panel_Select").html("Select All Field");
		}		
	});
	$('input[type=checkbox][name="childpanelitem"]').change(function () {		
		this.value = htmlEncode(((this.value).replace('<','_')).replace('>','_'));
		var val = this.value;		 
		var datapid = $(this).attr('data-pid');
		var dataspid = $(this).attr('data-sp-id');
		var userPandelId = parseInt(datapid.replace(/[^0-9.]/g, ""))
		
		var checkClassIsValid = $(".userAssignPanel_"+userPandelId+"_Select").attr('class');
		
		var childSelectedCheckBox = []; 
		var childUnselectedCheckBox = [];
		var subChildSelectedCheckBox = []; 
		var subChildUnselectedCheckBox = [];
		
		if(checkClassIsValid == undefined){
		 	console.log("Check for sub child");
		 	var childid = $(".userAssignPanel_"+userPandelId+"_Select_Child").attr('class').replace("Select","");
			var subPanelLabelClass = dataspid.replace(childid,"").replace("_SubChild","").replace(userPandelId+"_","");
			$("input[data-sp-id="+dataspid+"]").each(function() { 
			    if ($(this).is(":checked")) {
				   subChildSelectedCheckBox.push($(this));
			    }
			    if ($(this).not(":checked")) {
				   subChildUnselectedCheckBox.push($(this)); 
			    }
			});
			if(subChildSelectedCheckBox.length  == subChildUnselectedCheckBox.length){
				$("#"+subPanelLabelClass).text("Select None");
			}
			if(subChildUnselectedCheckBox.length > subChildSelectedCheckBox.length){
				$("#"+subPanelLabelClass).text("Select All");
			}
		} else {
		 	console.log("Check for child and sub child");
			var childid = $(".userAssignPanel_"+userPandelId+"_Select").attr('class').replace("Select","");
			var subPanelId = dataspid.replace(childid,"").replace("_SubChild","");
			var subPanelLabelClass = subPanelId.replace(userPandelId+"_","");
			var panelLabel = subPanelLabelClass.replace("Sub","");
			var childpanel = subPanelLabelClass.replace("userAssignSubPanelSelect_","");
			var panelLabelId = panelLabel.replace(childpanel,"")+userPandelId;	
			if($(this).is(":checked")) {
				$(this).closest('.columngroup').addClass("check_bgcolor");
				$(this).closest('.association_fields').addClass("check_bgcolor");
			} else {
				$(this).closest('.columngroup').removeClass("check_bgcolor");
				$(this).closest('.association_fields').removeClass("check_bgcolor");
			}
		    $("input[data-pid="+datapid+"]").each(function() {
			    if ($(this).is(":checked")) {
				   childSelectedCheckBox.push($(this));
			    }
			    if ($(this).not(":checked")) {
				   childUnselectedCheckBox.push($(this));   
			    }
			}); 
			if(childSelectedCheckBox.length  == childUnselectedCheckBox.length){
				$("#"+panelLabelId).text("Select None");
			}
			if(childUnselectedCheckBox.length  > childSelectedCheckBox.length){
				$("#"+panelLabelId).text("Select All");
			}			
			$("input[data-sp-id="+dataspid+"]").each(function() {
			   if ($(this).is(":checked")) {
				   subChildSelectedCheckBox.push($(this));
			   }
			    if ($(this).not(":checked")) {
				   subChildUnselectedCheckBox.push($(this));				   
			   }
			});
			if(subChildSelectedCheckBox.length  == subChildUnselectedCheckBox.length){
				$("#"+subPanelLabelClass).text("Select None");
			}
			if(subChildUnselectedCheckBox.length  > subChildSelectedCheckBox.length){
				$("#"+subPanelLabelClass).text("Select All");
			}			
		}		
		var total= $('input[name =childpanelitem]').length;
		var checked = $('input[name =childpanelitem]:checked').length;
		if(checked == total){
			$("#staffAssign_Panel_Select").html("Select None");
		}
		if(total > checked){
			$("#staffAssign_Panel_Select").html("Select All Fields");
		}	 		
	});
	var allowSubmit = true;
	$('.performImport').click(function() {
		if (allowSubmit){	
			allowSubmit = false;
			var token=$('#perImpToken').val();
			window.location ="/index.cfm?event=user.staffCrmPerformImport";			
		}											
	});
	$("#dialogImport").dialog({ autoOpen: false, modal: true,title: "", height: 140, width: 500});
	$("#mappingDialog").dialog({ autoOpen: false, modal: true,title: "", height: 500, width: 500 });
	 $("#errorPopup").dialog({ autoOpen: false, modal: true,title: "", height: 500, width: 500 });
	 /*Ms-216*/
	 //Following code hide/show the option that is already selected or changed.
	//Get Previous Selected Option
	var previous;	
	$('.showHideOption').click(function(){
		previous = $("#"+this.id+' option:selected').val();
	});

	//Hide Option from Other select that is selected in current Select.
	$('.showHideOption').change(function(){
		if($(this).hasClass('ta_field') || $(this).hasClass('tt_field')){
			talabel = $(".ta_label").html();
			newtalabel = talabel.indexOf('*') == 0 ? talabel.substring(1) : talabel;
			$(".ta_label").html(newtalabel);
			$(".ta_label").removeClass('req_itm')
			$(".ta_span").removeClass('req_map');
			$(".ta_span").hide();

			ttlabel = $(".tt_label").html();
			newttlabel = ttlabel.indexOf('*') == 0 ? ttlabel.substring(1) : ttlabel;
			$(".tt_label").html(newttlabel);
			$(".tt_label").removeClass('req_itm')
			$(".tt_span").removeClass('req_map');
			$(".tt_span").hide();
		}

		if($(this).hasClass('ta_field') && $(this).val() > 0){
			if(j11(".tt_field").val() == 0){
				tlabel = "*"+$(".tt_label").html();
				$(".tt_label").html(tlabel);
				$(".tt_label").addClass('req_itm')
				$(".tt_span").addClass('req_map');
				$(".tt_span").show();
			}
		}else if($(this).hasClass('ta_field') && $(this).val() == 0){
			if(j11(".tt_field").val() > 0){
				tlabel = "*"+$(".ta_label").html();
				$(".ta_label").html(tlabel);
				$(".ta_label").addClass('req_itm')
				$(".ta_span").addClass('req_map');
				$(".ta_span").show();
			}
		}

		if($(this).hasClass('tt_field') && $(this).val() > 0){
			if(j11(".ta_field").val() == 0){
				tlabel = "*"+$(".ta_label").html();
				$(".ta_label").html(tlabel);
				$(".ta_label").addClass('req_itm')
				$(".ta_span").addClass('req_map');
				$(".ta_span").show();
			}
		}else if($(this).hasClass('tt_field') && $(this).val() == 0){
			if(j11(".ta_field").val() > 0){
				tlabel = "*"+$(".tt_label").html();
				$(".tt_label").html(tlabel);
				$(".tt_label").addClass('req_itm')
				$(".tt_span").addClass('req_map');
				$(".tt_span").show();
			}
		}
		
		$(".showHideOption option[value="+$("#"+this.id).val()+"]").hide();
		$("#"+this.id+" option[value="+$("#"+this.id).val()+"]").show();
		if(previous != 0)
		{			
			$(".showHideOption option[value="+previous+"]").show();
		}
		$(".showHideOption option[value=0]").show();
	});

	$('.showHideOption').each(function(k,v){
		if(v.value!=0){			
			$(".showHideOption option[value="+$("#"+v.id).val()+"]").hide();
			$("#"+v.id+" option[value="+$("#"+v.id).val()+"]").show();
		} 
	});
	 /*Ms-216*/
}); // eof doc
function validateForm(e){
	e.preventDefault();
	var formdata= $("#downloadtemplate").serialize();
	formdata= JSON.stringify(formdata);
	formdata = formdata.replace('"', '');
	formdata = formdata.replace('"', '');
	if($('#userinputfilename').val()!=""){		
	   if(check($('#userinputfilename').val()) == false){	
			$.ajax({
				type:"post",
				data:formdata,
				url:"/index.cfm?event=user.downloadStafftemplate",
				datatype:"json",
				beforeSend: function(){
				 $("#ajaxFilterLoading").show();
				},
				complete: function(){
				 $("#ajaxFilterLoading").hide();
				},
				success: function(data)
				{
					var resultresponce = $.parseJSON(data);
					
					if(resultresponce.key==2)
					{
						$(".usermessage").html(resultresponce.usermessage);
					}
					else if(resultresponce.var_filenameis !="")
					{
						$(".usermessage").html(resultresponce.usermessage);
						setTimeout(function(){
						  $(".updatediv").html(); $(".usermessage_2").html("");
						  //MS-384
						  if($('#userinputfilename').val().trim()!=''){
							$(".template_selection").html('<span class="pull-left"><a id="rad_saved_views">Your Saved Templates</a></span>');
							showsavedTemplate();
						  }
						  //MS-384
						 //window.location.href = "index.cfm?event=user.importStaff";
						// $('.template_div').slideDown(1000);
						},2000);
						window.location.href = "index.cfm?event=user.downloadstaffselectedtemplatepage&Templatename="+encodeURIComponent(resultresponce.var_filenameis);
						
					}
				} // eof success
			});
		}else{
			alert('Please provide a template name that only uses letters, numbers and spaces.');
		}	 
	}else{			
		$.ajax({
			type:"post",
			data:formdata,
			url:"/index.cfm?event=user.downloadStafftemplate",
			datatype:"json",
			beforeSend: function(){
			 $("#ajaxFilterLoading").show();
			},
			complete: function(){
			 $("#ajaxFilterLoading").hide();
			},
			success: function(data)
			{
				var resultresponce=''
				try {
					resultresponce = $.parseJSON(data);
					if(resultresponce.var_filenameis !="")
					{ $(".usermessage_2").html("");
						$(".usermessage").html(resultresponce.usermessage);
						/*setTimeout(function(){
						  $(".updatediv").html();
						  showsavedTemplate();
						},3000);*/
						window.location.href = "index.cfm?event=user.downloadstaffselectedtemplatepage&Templatename="+encodeURIComponent(resultresponce.var_filenameis);
					
					}
				}
				catch(err) {
				  console.log(err.message);
				}
				
				/*if(resultresponce.key==2)
				{
					$(".usermessage").html(resultresponce.usermessage);
				}
				else*/ 
				
			} // eof success
		});
	}		
} // eof validateForm 
function showsavedTemplate()
{
	$.ajax({
		type:"post",
		data:{temp_id:"ajax",status:"ajax"},
		url:"/index.cfm?event=user.getsavedtemplate",
		datatype:"json",
		success: function(Survey)
		{ 
		  $("#insidebox_customize_main").empty();
		  $("a[id^='userAssignPanelSelect']*").html("Select All");
		  $("a[id^='userAssignSubPanelSelect_']*").html("Select All");		
			$.each($.parseJSON(Survey), function(key,value){
				$.each(value, function(i,obj){	
				var param = htmlEncode(obj.Template_ID)+",&quot;"+htmlEncode(obj.Template_Name) +"&quot;";
				var idVal = htmlEncode(obj.Template_Name)+"_"+htmlEncode(obj.Template_ID);
				$("#insidebox_customize_main").append("<div class='overflow-303'><div class='radio pull-left width-136 show_sectn'><label class='padding-left-10 font-normal'><span class='pull-left'><input type='radio' id='"+htmlEncode(idVal)+"' name='view_selection' value='"
						+htmlEncode(obj.Template_ID)+
						"' class='enrollvol temp_radio'></span> <span class='pull-left tmsht-widt-130' style='margin-top:1.5px;'>" +htmlEncode(obj.Template_Name)+" </span></label></div><div class='radio pull-left'><span class='margin-left-5 templateidtemp templateid_"+obj.Template_ID+"' style='display:none;'><a onclick='createNewDeleteWindow("
						+param+
						");' href='javascript:void(0)' >Delete</a></span> <span class='margin-left-5 templateidtemp templateid_"+htmlEncode(obj.Template_ID)+"' style='display:none;'> <a onclick='createNewPanelWindow("
						+param+
						");' href='javascript:void(0)' id='renameTemplate'>Rename</a> </span></div></div></div>");
				});
			});
			
			$('input[type=radio][name=view_selection]').change(function() {
				$('.templateidtemp').hide();													 
				$('.templateid_'+this.value).show()
				$('.btnClass').attr('disabled',false);
			});
			$('.btnClass').attr('disabled',true);
		}					
	});
	$('.template_div').slideDown(1000);
	$('#userinputfilename').val('');
	$('#userinputfilename_cnt').html("80");
} // eof showsavetemplate

function deleteTemplateFunction(){
	var templateID=$("#templateID").val();
	var templateName=$("#templateName").val();	
	var deletetemplateltoken=$("#deletetemplateltoken").val();
	//$("#dialog").dialog('open');
	//alert();
	$.ajax({
		type: "POST",
		url: "/index.cfm?event=user.staffRenameDeleteTemplate",
		data: {templateID:templateID,templateName:templateName,actionstatus:'deletename',deletetemplateltoken:deletetemplateltoken},		
		dataType: "json",
		success: function (res) {
			//console.log(res)
			//console.log(res.data[0].usermessage_2)
			//var resultresponce = $.parseJSON(res);
			//console.log(resultresponce.data)
			closeFunction('dialogImport');
			refreshTemplateFunction(templateID);
			$(".usermessage_2").text(res.data[0].usermessage_2) ;
			//$("#dialog").dialog("open");
			//$("#dialog").html(r);
			
		}
	});		
}
function refreshTemplateFunction(templateID){	
	//$("#dialog").dialog('open');
	//alert();
	$.ajax({
		type: "POST",
		url: "/index.cfm?event=user.staffRefreshTemplate",
		data: {temp_id:templateID,status:'ajax'},
		datatype:"json",		
		success: function (res) {
			var resultresponce = $.parseJSON(res);
		//	console.log(resultresponce.data.length)
			if(resultresponce.data.length==0){
				$(".template_selection").html('<span class="pull-left template_msg">Your Saved Templates (none available)</span>');
			}
			var $str_viewSection = '';
			$.each(resultresponce.data, function(key,value){				
				console.log(resultresponce.data[key].Template_ID )
				console.log(resultresponce.data[key].Template_Name )
				$str_viewSection = $str_viewSection + '<div class="overflow-303"><div class="radio pull-left width-136 show_sectn">';
				$str_viewSection = $str_viewSection + '<label class="padding-left-10 font-normal"><span class="pull-left">';
				$str_viewSection = $str_viewSection + '<input type="radio" id="'+resultresponce.data[key].Template_Name+'_'+resultresponce.data[key].Template_ID+'"  name="view_selection" value="'+resultresponce.data[key].Template_ID+'" class="enrollvol temp_radio">	</span>'; 
				$str_viewSection = $str_viewSection + '<span class="pull-left tmsht-widt-130" style="margin-top:2px;">'+resultresponce.data[key].Template_Name+'</span>';
				$str_viewSection = $str_viewSection + '</label></div>';
				$str_viewSection = $str_viewSection + '<div class="radio pull-left"><span class="margin-left-5 templateidtemp templateid_'+resultresponce.data[key].Template_ID+'" style="display:none;"><a class="OpenDialog" onclick="createNewDeleteWindow('+"'"+resultresponce.data[key].Template_ID+"'"+','+"'"+resultresponce.data[key].Template_Name+"'"+')" href="javascript:void(0)" >Delete</a></span> ';
				$str_viewSection = $str_viewSection + '<span class="margin-left-5 templateidtemp templateid_'+resultresponce.data[key].Template_ID+'" style="display:none;"> <a onclick="createNewPanelWindow('+"'"+resultresponce.data[key].Template_ID+"'"+','+"'"+resultresponce.data[key].Template_Name+"'"+')" href="javascript:void(0)" id="renameTemplate">Rename</a> </span> ';
				$str_viewSection = $str_viewSection + '</div></div>';	
				//console.log($str_viewSection);
				//console.log('==================')
			});
			$("#insidebox_customize_main").html($str_viewSection);
			//console.log($('.template_div').css('display'));
			//console.log($('.template_div').attr('style'));
			if ($('.template_div').css('display') == 'none') {
				$('.template_div').slideDown(1000);
			}
			else
			{
				$('.template_div').slideUp(1000);
			}
					
		}
	});		
}
function  closeFunction(id){
	$( "#"+id ).dialog( "close" );
}
function createNewDeleteWindow(templateID,templatename){		
	$.ajax({
		type: "POST",
		url: "/index.cfm?event=user.deletestafftemplate",
		data: {Template_ID:templateID,TemplateName:templatename},
		beforeSend: function() {
			showLoadingOverlay();
		},		
		success: function (r) {			
			$("#dialogImport").dialog("open");
			//$( "#dialogImport" ).dialog( "option", "height", 140 );
			$("#dialogImport").html(r);
			$('#dialogImport').css({"height":"140px","z-index":"11"});
			hideLoadingOverlay();
		}
	});	
 }
function createNewPanelWindow(templateID,templatename){ 
	$.ajax({
		type: "POST",
		url: "/index.cfm?event=user.renameStafftemplate",
		data: {Template_ID:templateID,TemplateName:templatename},
		beforeSend: function() {
			showLoadingOverlay();
		},		
		success: function (r) {			
			$("#dialogImport").dialog("open");
			$( "#dialogImport" ).dialog( "option", "height", 200 );
			$("#dialogImport").html(r);
			//$('#dialogImport').css({"min-height":"123px" ,"height":"0px"});
			$('#dialogImport').css({"z-index":"11"});
			hideLoadingOverlay();
			executeafterload();
		}
	});  
 }
 function executeafterload(){	
   $("#td_paddg_1").find('input:text').each(function(){ 
			CountLeft(this,80);
  });	
}
 function validateForm2(rename_button) {	
	if($('#templateName').val().trim() == ''){
		alert('Please provide a Template Name.');
		rename_button.disabled = false;
   		return false;
	} else if(check($('#templateName').val().trim()) == false) {
		if($('#templateName').val().trim() != $('#currtemplateName').val().trim()) {
			//$("#savetemplatename").submit();
			var templatename=$('#templateName').val().trim();
			var actionstatus=$('#uactionstatus').val().trim();
			var templateID=$('#templateID').val().trim();
			var renametoken=$('#renametoken').val().trim();
			$.ajax({
				type: "POST",
				url: "/index.cfm?event=user.renameStaffDeleteTemplate",
				data: {templateID:templateID,templateName:templatename,actionstatus:actionstatus,renametoken:renametoken},	
				dataType: "json",				
				success: function (res) {						
					closeFunction('dialogImport');
					refreshTemplateFunction(templateID);					
					$(".usermessage_2").html(res.data[0].usermessage_2) ;					
				}
			});
		} else {
			closeFunction('dialogImport');
		}
	} else {
        alert('Please provide a template name that only uses letters, numbers and spaces.');
		rename_button.disabled = false;
		return false;
	}
}	
function check(string){
	var specialChars = "<>@!#$%^&*()_+[]{}?:;|'\"\\,./~`-=";
    for(i = 0; i < specialChars.length;i++){
        if(string.indexOf(specialChars[i]) > -1){
            return true
        }
    }
    return false;
}

function syncHeight(){
    $(".column_left").each(function(i, e) {
        if($(e).next().find(".columngroup").height() != null && $(e).next().find(".columngroup").height() != 0  && $(e).find(".columngroup").height() != $(e).next().find(".columngroup").height()) {
            if($(e).height() > $$(e).next().height()){
                $(e).next().find(".columngroup").height($(e).find(".columngroup").height());
            } else if($(e).height() < $(e).next().height()) {
                $(e).find(".columngroup").height($(e).next().find(".columngroup").height()); 
            }
        }
    });
}
function validateStaffFileType() {
	var filename = $('input[type=file]').val().replace(/C:\\fakepath\\/i, '');
	var filename= filename.trim().split('.');	
	if(filename[1] == 'xlsx' || filename[1] == 'xls') {		
		$('#importStaffForm').submit();
	} else {
		alert('Please provide valid excel template');
	}
}
function validateStaffFieldMapping() {
    var errorFlag = false;
    var errorList = "Please check all the required fields are mapped.";
	var tlabel="";
	var newtlabel="";
	var errorTSFlag = false;		
	if($(".ta_field").length > 0 && $(".tt_field").length > 0){
	
		if($(".ta_field").val() > 0 && $(".tt_field").val() == 0){	
			tlabel = $(".tt_label").html();
			if(tlabel.indexOf('*') != 0){
				tlabel = "*"+$(".tt_label").html();
			}		
			$(".tt_label").html(tlabel);
			$(".tt_label").addClass('req_itm');
			$(".tt_span").addClass('req_map');
			$(".tt_span").show();
			errorTSFlag = true;
		}
		else{
			tlabel = $(".tt_label").html();
			newtlabel = tlabel.indexOf('*') == 0 ? tlabel.substring(1) : tlabel;
			$(".tt_label").html(newtlabel);
			$(".tt_label").removeClass('req_itm');
			$(".tt_span").removeClass('req_map');
			$(".tt_span").hide();
		}
		if($(".tt_field").val() > 0 && $(".ta_field").val() == 0){
			tlabel = $(".ta_label").html();
			if(tlabel.indexOf('*') != 0){
				tlabel = "*"+$(".ta_label").html();
			}
			$(".ta_label").html(tlabel);
			$(".ta_label").addClass('req_itm');
			$(".ta_span").addClass('req_map');
			$(".ta_span").show();
			errorTSFlag = true;
		}
		else{
			tlabel = $(".ta_label").html();
			newtlabel = tlabel.indexOf('*') == 0 ? tlabel.substring(1) : tlabel;
			$(".ta_label").html(newtlabel);
			$(".ta_label").removeClass('req_itm');
			$(".ta_span").removeClass('req_map');
			$(".ta_hide").show();
		}
	}

	if(!errorTSFlag){
		$.each($(".req_field"), function(i, v) {
			if(v.value==0)
			{
				errorFlag=true;
				return false;
			}
		});
		if(!errorFlag)
		{
			createNewFieldWindow();
		}
		else
		{
			alert(errorList);
		}
	}
	else{
		alert(errorList);
	}
}
function createNewFieldWindow(){
	
	$.ajax({
		type: "POST",
		url: "/index.cfm?event=user.showstafffieldspreviewwindow",
		//data: {previewtoken:previewtoken},		
		success: function (r) {			
			$("#mappingDialog").dialog("open");
			$("#mappingDialog").html(r);
			$('.ui-widget-overlay').css('position','relative');
			$('#mappingDialog').css({"z-index":"11"});
			
		}
	});		
}
function fieldmappingpreview(rootPath) {
    var data = $('#testexcel').serialize();
    data = JSON.stringify(data);

    //remove Leading and trailing " from string
    data = data.replace('"', '');
    data = data.replace('"', '');

    $.ajax({
        url: rootPath,
        type: "POST",
        data: data,
        datatype: "json",
        beforeSend: function() {
            $("#ajaxFilterLoading").show();
            $("#AddActionContainer").hide();
        },
        complete: function(data) {
            var jsonObject = $.parseJSON(data.responseText);
            $("#ajaxFilterLoading").hide();
            $("#AddActionContainer").show();
            
            if(jsonObject.ColumnsNotMapped.length>0)
            {
                 $(".excelMappingTitle").show();
                 $("#ExcelColumnsNotMapped").show();
            }          
            var excelColumnsNotMapped = [];
            $.each(jsonObject.ColumnsNotMapped, function(key, value) {
                excelColumnsNotMapped.push(value);                
            });
            excelColumnsNotMapped.sort();
            $("#ExcelColumnsNotMapped").append("<ul></ul>");
            for(var x=0; x < excelColumnsNotMapped.length;x++)
            {
                $("#ExcelColumnsNotMapped > ul").append("<li><label>" + htmlEncode(excelColumnsNotMapped[x]) + "</label></li>");
            }           
            var currentPanelAndSubPanel = "";
            var newPanelAndSubPanel = "";
            var count = 0;
            var listOfPanels = [];
            var listOfSubPanels = [];

            if(jsonObject.FieldsNotMappedJSON.DATA.length>0)
            {
                 $(".fieldsMappingTitle").show();
            }
            $.each(jsonObject.FieldsNotMappedJSON.DATA, function(key, value) {
                var isExist = false;
                for (var i = 0; i < listOfPanels.length; i++) {
                    if (listOfPanels[i] == value[3]) {
                        isExist = true;
                        break;
                    }
                }
                if (!isExist) {
                    listOfPanels[count] = value[3];
                    count++;
                }
            });
            listOfPanels.sort();
            count = 0;
            for (var i = 0; i < listOfPanels.length; i++) {
                $.each(jsonObject.FieldsNotMappedJSON.DATA, function(key, value) {
                    var isExist=false;
                    for (var j = 0; j < listOfSubPanels.length; j++) {
                        if (listOfSubPanels[j] == value[4]) {
                            isExist = true;
                            break;
                        }
                    }
                    if (listOfPanels[i] == value[3] && !isExist) {
                        listOfSubPanels[count] = value[4];
                        count++;
                    }
                });
                listOfSubPanels.sort(); 
                
                for (var j = 0; j < listOfSubPanels.length; j++) {
                    var displayStrong = true;
                    var fieldsNotMapped = []
                    var panelHeading ="";
                    $.each(jsonObject.FieldsNotMappedJSON.DATA, function(key, value) {
                        if (listOfPanels[i] == value[3] && listOfSubPanels[j] == value[4]) {
                            if (displayStrong) {
                                if (value[1] != "Default") {                                     
                                    panelHeading = value[1];                                                                 
                                    $("#FieldsNotMappedJSON").append("<p class='strong'>" + value[0] + ": " + panelHeading + "</p>");                                    
                                } else {                                    
                                    $("#FieldsNotMappedJSON").append("<p class='strong'>" + value[0] + "</p>");
                                }
                                displayStrong = false;
                            }
                            fieldsNotMapped.push(value[2]);                            
                        }
                    });
                    fieldsNotMapped.sort();
                    $("#FieldsNotMappedJSON").append("<ul class='ul" + i+"_" + j +"'></ul>");
                    for(var x=0; x<fieldsNotMapped.length;x++)
                    {                        
                        $(".ul"+i +"_" + j).append("<li><label>" + htmlEncode(fieldsNotMapped[x]) + "</label></li>");
                    }
                    
                    $("#FieldsNotMappedJSON").append("<br/>")
                }

                listOfSubPanels = [];
                count = 0;
            }            
        }
    });
}
function htmlEncode(value) {
    return $('<div/>').text(value).html();
}
function CountLeft(field, max) {			
	if(typeof field.value != 'undefined') {
		tempvalue = field.value.replace(/\r\n/g,"\n");
		if(typeof tempvalue != 'undefined') {
			if (tempvalue.length > max) {
				field.value = tempvalue.substring(0, max);
				nowCount = max - field.value.length;
				document.getElementById(field.name+"_cnt").childNodes[0].nodeValue = nowCount;
			} else { 	
				nowCount = max - tempvalue.length;
				document.getElementById(field.name+"_cnt").childNodes[0].nodeValue = nowCount;
			}	
			field.style.height='';
			if(parseInt(field.style.minHeight)<field.scrollHeight)
			{
				field.style.height=field.scrollHeight+'px';
			}
		}
	} else {
		var ele = document.getElementById(field);
		var target_ele = document.getElementById(field+"_cnt");
				
		if( ele != null && target_ele!=null) {
			tempvalue = ele.value.replace(/\r\n/g,"\n");			
			if(typeof tempvalue != 'undefined') {
				if (tempvalue.length > max) {
					ele.value = tempvalue.substring(0, max);
					nowCount = max - ele.value.length;
					target_ele.childNodes[0].nodeValue = nowCount;
				} else { 	
					nowCount = max - tempvalue.length;
					target_ele.childNodes[0].nodeValue = nowCount;
				}	ele.style.height='';
				if(parseInt(ele.style.minHeight)<ele.scrollHeight)
				{
					ele.style.height=ele.scrollHeight+'px';
				}
			}
		}				
	}			
}
function showResetPasswordPopup(){
	$("#PasswordReminder").dialog({
		modal: true, 
		title: "Send Password Setup E-mail", 
		resizable: false,
		height: 300,
		dialogClass: 'sendPasswordSetupEmail'
	});
	$("#sendEmailLink").prop('disabled', true);	
	$("#closePasswordReminderPopup").prop('disabled', false);	
	$('#sendEmailMsg').hide();		
	$('#closePasswordReminderWindow').hide();	
	$('#emailCheckBox').attr("checked",false);	
}
function closePasswordReminderPopup()
{
	$('#PasswordReminder').dialog('close');
	$('#emailCheckBox').prop('checked', false);
}
function showHideSendEmailLink(){
	if($('#emailCheckBox').is(":checked")){
		$("#sendEmailLink").prop('disabled', false);
	}
	else{
		$("#sendEmailLink").prop('disabled', true);
		$("#closePasswordReminderPopup").prop('disabled', false);
		$('#sendEmailMsg').hide();		
		$('#closePasswordReminderWindow').hide();
	}
}
var sendemailflag = 1;
function sendEmail(){
	if($("#emailCheckBox").is(":checked"))
	{	
		$("#sendEmailLink").prop('disabled', true);
		var insertedUserList = $('#insertedUserList').val();		
		//alert(insertedUserList);	 
		$.ajax({
			type:"post",
			url:"index.cfm?event=user.staffPasswordReminder",	
			data:{
					"insertedUserList":insertedUserList,
					"sendemailflag":sendemailflag,
				 },
			dataType: "json",		
			success: function(data) 
			{ 
				var parsed_data = data;
				if(parsed_data == 'success'){
					$('#sendEmailMsg').show();
					sendemailflag++;
				}
			},
			error: function(data) 
			{  
				$("#sendEmailLink").prop('disabled', false);
				alert("Server Error!");
			}
		});
		$("#closePasswordReminderPopup").prop('disabled', true);			
		$('#closePasswordReminderWindow').show();
	}
	else{
		alert("Please select the checkbox!");
		$("#emailCheckBox").focus();
	}
}
function validateFileType() {
	var filename = $('input[type=file]').val().replace(/C:\\fakepath\\/i, '');
	var filename= filename.trim().split('.');	
	if(filename[1] == 'xlsx' || filename[1] == 'xls') {		
		$('#importVolForm').submit();
	} else {
		alert('Please provide valid excel template');
	}
}
function alertNoData() {	
	if (rsn == -1){
		alert('Please upload a file with atleast one record');					
	}	
	else if (rsn == -2){
		alert('The file contains multiple worksheets. Please upload a file that has only one worksheet.');							
	}	
	else if (rsn == -3){
		alert('The file you uploaded may be unsafe or corrupted. Please upload a new version of the file.');					
	}		
	else if (rsn == -4){
		alert('The file contains blank headers in Row 1 or hidden columns. Please upload a file with headers for all columns and with all columns unhidden.');					
	}
	
}
var allowSubmit = true;
function submitFormForImport()
{
	if (allowSubmit){
		document.getElementById("insertupdatefromimportedexcel").submit();
	}
	allowSubmit = false;
}

function submitForm()
{
	document.getElementById("testexcel").submit();
}

 
function closeErrorPopup(){
  ColdFusion.Window.destroy("errorPopup");        
 }
function returnWindow(){
  var cfwindowTitle = "";
  //ColdFusion.Window.create("returnWindow",cfwindowTitle,"index.cfm?event=user.cancelwindow",{modal:true,width:500,height:205,center:true,draggable:true});
  //ColdFusion.Window.onHide("returnWindow", closeCRWindow); 
  $.ajax({
		type: "POST",
		url: "/index.cfm?event=user.cancelStaffWindow",
		//data: {previewtoken:previewtoken},		
		success: function (r) {	
			console.log(r)
			$("#errorPopup").dialog("open");
			$("#errorPopup").html(r);
			//$('.ui-widget-overlay').css('position','relative');
			
		}
	});	
  
 }	
 
  function closeCRWindow(){
  ColdFusion.Window.destroy("returnWindow");        
 }

function showErrorPopup(){
  var cfwindowTitle = "";
 // ColdFusion.Window.create("errorPopup",cfwindowTitle,"index.cfm?event=user.errorpopup",{modal:true,width:500,height:205,center:true,draggable:true});
 // ColdFusion.Window.onHide("errorPopup", closeErrorPopup); 
  $.ajax({
		type: "POST",
		url: "/index.cfm?event=user.errorStaffPopup",
		//data: {previewtoken:previewtoken},		
		success: function (r) {	
			console.log(r)
			$("#errorPopup").dialog("open");
			$("#errorPopup").html(r);
			//$('.ui-widget-overlay').css('position','relative');
			
		}
	});	
 }	
 function showLoadingOverlay() {
    $('#ajaxFilterLoading .bg').height('100%');
    $('#ajaxFilterLoading').fadeIn(300);
    $("#ajaxFilterLoading").attr("tabindex",-1).focus();
}

function hideLoadingOverlay() {
    $('#ajaxFilterLoading .bg').height('100%');
    $('#ajaxFilterLoading').fadeOut(300);
}

