//this is the function to show the breAk by tutor area
function BreakByTutor(scopeName,loadingImgId,TutorDataDivId,clickLinkId,questionID,beginSurvey,endSurvey,notSelectedIds,siteidList,programList,showingstatus,showtutorstudentall)
{
	var BreakByTutor = "BreakByTutor_"+questionID;
	

		var BreakByTutorId = document.getElementById(BreakByTutor);
		
		
		if (BreakByTutorId.classList.contains('breakOutOtherThanAttribute')===true){
		BreakByTutorId.classList.remove("breakOutOtherThanAttribute");
	if(document.getElementById(TutorDataDivId).style.display == 'none' || showingstatus == 'firsttimemain' || showingstatus == 'z-a' || showingstatus == 'a-z' || showingstatus == 'asc' || showingstatus == 'desc')
		{
			
			document.getElementById(loadingImgId).style.display = 'block';
	
				// this is for sitewide
				if (scopeName == "site")
				{
				
					if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain')
					{
						document.getElementById(loadingImgId).style.display = 'none';
						//processAndCloseBreakBoxTime(TutorDataDivId,loadingImgId);
						
					}
					else
					{
			
						new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbytutorsitewide&questionid="+questionID+"&beginsurvey="+beginSurvey+"&endsurvey="+endSurvey+"&notselectedids="+notSelectedIds+"&siteidlist="+siteidList+"&programlist="+programList+"&showingstatus="+showingstatus+"&showtutorstudentall="+showtutorstudentall),{ 
			
							onSuccess: function(returnHtml) { 
							
							document.getElementById(loadingImgId).style.display = 'none';
							document.getElementById(clickLinkId).style.display = 'block';
							var studentdiv = "StudentDataDiv" + questionID;
							var tutorOnly = "TutorOnly" + questionID;
							var attributeDiv = "AttributeDataDiv" + questionID;
							var attributeSelectionDiv = "AttributeSelectionDiv" + questionID;
							Element.update(TutorDataDivId, returnHtml.responseText); 
							//Effect.toggle(TutorDataDivId, 'slide');
							if (jQuery('#' + attributeDiv).css('display') != 'none' && typeof (jQuery('#' + attributeDiv).css('display')) !== 'undefined') {
								jQuery('#' + attributeDiv).hide();
								jQuery('#' + attributeSelectionDiv).hide();
								if (showingstatus == 'firsttimemain') {
									document.getElementById(TutorDataDivId).style.display = 'block';
								}
							} else {
								jQuery('#' + attributeSelectionDiv).hide();
								if (showingstatus == 'firsttimemain')
									Effect.BlindDown(TutorDataDivId);
							}
							/*if (showingstatus == 'firsttimemain')
							Effect.BlindDown(TutorDataDivId);*/
					
							}, 
							onFailure: function(){ 
							alert('Oops...mistake on server');
							} 
						});
					}
				
				
				}
				
				//this section is for program wide data display
				else if (scopeName == "program")
				{
					if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain')
					{
						document.getElementById(loadingImgId).style.display = 'none';
						//processAndCloseBreakBoxTime(TutorDataDivId,loadingImgId);
						
					}
					else
					{
			
						new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbytutorprogramwidetimeseries&questionid="+questionID+"&beginsurvey="+beginSurvey+"&endsurvey="+endSurvey+"&notselectedids="+notSelectedIds+"&programlist="+programList+"&showingstatus="+showingstatus+"&showtutorstudentall="+showtutorstudentall),{ 
			
							onSuccess: function(returnHtml) { 
								document.getElementById(loadingImgId).style.display = 'none';
								document.getElementById(clickLinkId).style.display = 'block';
								var studentdiv = "StudentDataDiv" + questionID;
								var tutorOnly = "TutorOnly" + questionID;
								var attributeDiv = "AttributeDataDiv" + questionID;
								var attributeSelectionDiv = "AttributeSelectionDiv" + questionID;
								Element.update(TutorDataDivId, returnHtml.responseText); 
								//Effect.toggle(TutorDataDivId, 'slide');
								if (jQuery('#' + attributeDiv).css('display') != 'none' && typeof (jQuery('#' + attributeDiv).css('display')) !== 'undefined') {
									jQuery('#' + attributeDiv).hide();
									jQuery('#' + attributeSelectionDiv).hide();
									if (showingstatus == 'firsttimemain') {
										document.getElementById(TutorDataDivId).style.display = 'block';
									}
								} else {
									jQuery('#' + attributeSelectionDiv).hide();
									if (showingstatus == 'firsttimemain')
										Effect.BlindDown(TutorDataDivId);
								}								
								/*if (showingstatus == 'firsttimemain')
								Effect.BlindDown(TutorDataDivId);*/
								
							}, 
							onFailure: function(){ 
								alert('Oops...mistake on server');
							} 
						});
					}
					
				}
				
			}
		
		else
		{
			
			processAndCloseBreakBoxTime(TutorDataDivId,loadingImgId);
			
		}
		}
}

function BreakByTutorInner(scopeName,loadingImgId,TutorDataDivId,clickLinkId,questionID,beginSurvey,endSurvey,notSelectedIds,siteidList,programList,showingstatus,showtutorstudentall)
{
	
	if(document.getElementById(TutorDataDivId).style.display == 'none' || showingstatus == 'firsttimemain' || showingstatus == 'z-a' || showingstatus == 'a-z' || showingstatus == 'asc' || showingstatus == 'desc')
		{
			
			document.getElementById(loadingImgId).style.display = 'block';
	
				// this is for sitewide
				if (scopeName == "site")
				{
				
					if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain')
					{
						document.getElementById(clickLinkId).style.display = 'block';
						document.getElementById(loadingImgId).style.display = 'none';
						//processAndCloseBreakBoxTime(TutorDataDivId,loadingImgId);
						
						
					}
					else
					{
			
						new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbytutorsitewide&questionid="+questionID+"&beginsurvey="+beginSurvey+"&endsurvey="+endSurvey+"&notselectedids="+notSelectedIds+"&siteidlist="+siteidList+"&programlist="+programList+"&showingstatus="+showingstatus+"&showtutorstudentall="+showtutorstudentall),{ 
			
							onSuccess: function(returnHtml) { 
							
							document.getElementById(loadingImgId).style.display = 'none';
							document.getElementById(clickLinkId).style.display = 'block';
							var studentdiv = "StudentDataDiv" + questionID;
							var tutorOnly = "TutorOnly" + questionID;
							var attributeDiv = "AttributeDataDiv" + questionID;
							var attributeSelectionDiv = "AttributeSelectionDiv" + questionID;
							Element.update(TutorDataDivId, returnHtml.responseText); 
							//Effect.toggle(TutorDataDivId, 'slide');
							if (jQuery('#' + attributeDiv).css('display') != 'none' && typeof (jQuery('#' + attributeDiv).css('display')) !== 'undefined') {
								jQuery('#' + attributeDiv).hide();
								jQuery('#' + attributeSelectionDiv).hide();
								if (showingstatus == 'firsttimemain') {
									document.getElementById(TutorDataDivId).style.display = 'block';
								}
							} else {
								jQuery('#' + attributeSelectionDiv).hide();
								if (showingstatus == 'firsttimemain')
									Effect.BlindDown(TutorDataDivId);
							}
							/*if (showingstatus == 'firsttimemain')
							Effect.BlindDown(TutorDataDivId);*/
					
							}, 
							onFailure: function(){ 
							alert('Oops...mistake on server');
							} 
						});
					}
				
				
				}
				
				//this section is for program wide data display
				else if (scopeName == "program")
				{
					if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain')
					{
						document.getElementById(clickLinkId).style.display = 'block';
						document.getElementById(loadingImgId).style.display = 'none';
						//processAndCloseBreakBoxTime(TutorDataDivId,loadingImgId);
						
						
					}
					else
					{
			
						new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbytutorprogramwidetimeseries&questionid="+questionID+"&beginsurvey="+beginSurvey+"&endsurvey="+endSurvey+"&notselectedids="+notSelectedIds+"&programlist="+programList+"&showingstatus="+showingstatus+"&showtutorstudentall="+showtutorstudentall),{ 
			
							onSuccess: function(returnHtml) { 
								document.getElementById(loadingImgId).style.display = 'none';
								document.getElementById(clickLinkId).style.display = 'block';
								var studentdiv = "StudentDataDiv" + questionID;
								var tutorOnly = "TutorOnly" + questionID;
								var attributeDiv = "AttributeDataDiv" + questionID;
								var attributeSelectionDiv = "AttributeSelectionDiv" + questionID;
								Element.update(TutorDataDivId, returnHtml.responseText); 
								//Effect.toggle(TutorDataDivId, 'slide');
								if (jQuery('#' + attributeDiv).css('display') != 'none' && typeof (jQuery('#' + attributeDiv).css('display')) !== 'undefined') {
									jQuery('#' + attributeDiv).hide();
									jQuery('#' + attributeSelectionDiv).hide();
									if (showingstatus == 'firsttimemain') {
										document.getElementById(TutorDataDivId).style.display = 'block';
									}
								} else {
									jQuery('#' + attributeSelectionDiv).hide();
									if (showingstatus == 'firsttimemain')
										Effect.BlindDown(TutorDataDivId);
								}								
								/*if (showingstatus == 'firsttimemain')
								Effect.BlindDown(TutorDataDivId);*/
								
							}, 
							onFailure: function(){ 
								alert('Oops...mistake on server');
							} 
						});
					}
					
				}
				
			}
		
		else
		{
			
			processAndCloseBreakBoxTime(TutorDataDivId,loadingImgId);
			
		}
		
}

function BreakByTutor_volunteers(scopeName,loadingImgId,TutorDataDivId,clickLinkId,questionID,beginSurvey,endSurvey,notSelectedIds,siteidList,programList,showingstatus,showtutorstudentall,volunteeruserid)
{
	if(document.getElementById(TutorDataDivId).style.display == 'none' || showingstatus == 'firsttimemain' || showingstatus == 'z-a' || showingstatus == 'a-z' || showingstatus == 'asc' || showingstatus == 'desc')
	{	
		document.getElementById(loadingImgId).style.display = 'block';
		if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain')
		{
			document.getElementById(loadingImgId).style.display = 'none';
			
		}
		else
		{
	
			new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbytutorprogramwidetimeseries&questionid="+questionID+"&beginsurvey="+beginSurvey+"&endsurvey="+endSurvey+"&notselectedids="+notSelectedIds+"&programlist="+programList+"&showingstatus="+showingstatus+"&showtutorstudentall="+showtutorstudentall+"&volunteeruserid="+volunteeruserid),{ 
	
				onSuccess: function(returnHtml) { 
					document.getElementById(loadingImgId).style.display = 'none';
					document.getElementById(clickLinkId).style.display = 'block';
					var studentdiv = "StudentDataDiv" + questionID;
					var tutorOnly = "TutorOnly" + questionID;
					var attributeDiv = "AttributeDataDiv" + questionID;
					var attributeSelectionDiv = "AttributeSelectionDiv" + questionID;
					Element.update(TutorDataDivId, returnHtml.responseText); 
					//Effect.toggle(TutorDataDivId, 'slide');
					if (jQuery('#' + attributeDiv).css('display') != 'none' && typeof (jQuery('#' + attributeDiv).css('display')) !== 'undefined') {
						jQuery('#' + attributeDiv).hide();
						jQuery('#' + attributeSelectionDiv).hide();
						if (showingstatus == 'firsttimemain' || showingstatus == 'a-z') {
							document.getElementById(TutorDataDivId).style.display = 'block';
						}
					} else {
						jQuery('#' + attributeSelectionDiv).hide();
						if (showingstatus == 'firsttimemain')
							Effect.BlindDown(TutorDataDivId);
						else if(showingstatus == 'a-z'){
							if(jQuery('#' + TutorDataDivId).css('display') != 'none')
								document.getElementById(TutorDataDivId).style.display = 'block';
							else
								Effect.BlindDown(TutorDataDivId);
						}
					}								
					/*if (showingstatus == 'firsttimemain')
					Effect.BlindDown(TutorDataDivId);*/
					
				}, 
				onFailure: function(){ 
					alert('Oops...mistake on server');
				} 
			});
		}			
	}	
	else
	{
		
		processAndCloseBreakBoxTime(TutorDataDivId,loadingImgId);
		
	}
}



function processAndCloseBreakBoxTime(TutorDataDivId,loadingImgId)
{

	document.getElementById(loadingImgId).style.display = 'block';

	Effect.Fade(TutorDataDivId);
	//Effect.toggle(TutorDataDivId, 'slide');
	Effect.BlindUp(TutorDataDivId);
	document.getElementById(loadingImgId).style.display = 'none';
	var questionID = parseInt(TutorDataDivId.match(/[0-9]+/)[0], 10);
	var BreakByTutor = "BreakByTutor_"+questionID;
	var BreakByTutorAssociationWideTimeSeries = "BreakByTutorAssociationWideTimeSeries_"+questionID;
    var BreakByTutorId = document.getElementById(BreakByTutor);
	var BreakByTutorAssociationWideTimeSeriesId = document.getElementById(BreakByTutorAssociationWideTimeSeries);
	if(BreakByTutorId !== null)
	BreakByTutorId.classList.add("breakOutOtherThanAttribute");
	 if(BreakByTutorAssociationWideTimeSeriesId  !== null)
         BreakByTutorAssociationWideTimeSeriesId .classList.add("breakOutOtherThanAttribute");
	

	
}