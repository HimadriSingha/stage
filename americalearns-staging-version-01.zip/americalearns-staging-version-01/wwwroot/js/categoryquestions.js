
/*
	   Name		 	:	This page is used for displaying the Question and Answer based on the Question Type. 
	   Description	 	:	This page is used for displaying the Question and Answer based on the Question Type. 
	   				 Made a copy of the existing page.


       History
---------------------------------------------------------------------------------------------------
Sl.No.		Date		Description
----------------------------------------------------------------------------------------------------
1		
-----------------------------------------------------------------------------------------------------
 * 
 * */
 
 /*
  * function for getting all the questions under a category - Ajax request and Slide
  * */
function showCategoryQuestions(element1,CategoryType,CategoryName,UserType,CategoryLink,LoadingDiv)
	{
		
		//alert("/index.cfm?event=survey.getcategoryquestions&element1=" +element1 + "&CategoryType=" + CategoryType + "&CategoryName=" +CategoryName);
			if(document.getElementById(element1).style.display == 'none')
			{
				//ColdFusion.Window.create("test","test","",{modal:true,width:455,height:550,center:true,draggable:true})
				document.getElementById(CategoryLink).style.display = 'none';
				document.getElementById(LoadingDiv).style.display = 'block';
				new Ajax.Request("/index.cfm?event="+UserType+".getcategoryquestions&element1=" +element1 + "&CategoryType=" + CategoryType + "&CategoryName=" +escape(CategoryName) + "&UserType=" +UserType, { 
	
					onSuccess: function(t) { 
					
					document.getElementById(LoadingDiv).style.display = 'none';
					document.getElementById(CategoryLink).style.display = 'block';
					//$("processing-indicator").hide();
					Element.update(element1, t.responseText); 
					//Effect.Shake(element1);
					Effect.toggle(element1, 'slide');
					
					}, 
					onFailure: function(){ 
					alert('Oops...mistake on server');
					} 
				});
			}
			else
			{
				processAndCloseCategoryQuestions(element1);
			}
	}

/*
  * function for processing and closing the filled Category questions Div
  * 
  * */
  
function processAndCloseCategoryQuestions(element1)
{
	
	Effect.Fade(element1);
	Effect.toggle(element1, 'slide');
}

function slideDiv(element1,element2,clickedqid,otherqid,element1position,element2position,formid,direction)
{
	//alert(element1position);
	//alert(element2position);
	new Ajax.Request("/index.cfm?event=survey.updatequestionorder&formid="+formid+"&InitialQuestionOrder="+element1position+"&NewQuestionOrder="+element2position+"", { 
	
	
					onSuccess: function(t) { 
					
					
					}, 
					onFailure: function(){ 
					alert('Oops...mistake on server');
					} 
	            });
	
	if(direction == 1)
	{
		
		//Effect.Shake(element2);
		

		/*new Effect.Move(element1, {
  						x: 200, y: 0, mode: 'relative',
  						transition: Effect.Transitions.sinoidal
					});
		
		new Effect.Move(element2, {
  						x: 200, y: 0, mode: 'relative',
  						transition: Effect.Transitions.sinoidal
					});
					
		new Effect.Move(element1, {
  						x: 200, y: 0, mode: 'relative',
  						transition: Effect.Transitions.reverse
					});
		
		new Effect.Move(element2, {
  						x: 200, y: 0, mode: 'relative',
  						transition: Effect.Transitions.reverse
					});			
		*/			
	
	}
	else if(direction == 0)
	{
		
		//Effect.Shake(element2);
		
	
		/*new Effect.Move(element1, {
  						x: 200, y: 0, mode: 'relative',
  						transition: Effect.Transitions.sinoidal
					});
		
		new Effect.Move(element2, {
  						x: 200, y: 0, mode: 'relative',
  						transition: Effect.Transitions.sinoidal
					});
					
		new Effect.Move(element1, {
  						x: 200, y: 0, mode: 'relative',
  						transition: Effect.Transitions.reverse
					});
		
		new Effect.Move(element2, {
  						x: 200, y: 0, mode: 'relative',
  						transition: Effect.Transitions.reverse
					});	
		*/			
	
	}
	
}