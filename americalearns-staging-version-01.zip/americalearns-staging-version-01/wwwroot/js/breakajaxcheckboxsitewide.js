//this is the function to show the breAk by tutor area
function BreakByTutorCheckBox(scopeName, loadingImgId, TutorDataDivId, clickLinkId, questionID, beginSurvey, endSurvey, notSelectedIds, siteidList, programList, showingstatus, showtutorstudentall, showingstatusother, showtutorstudentallother) {
	var BreakByTutorCheckBox = "BreakByTutorCheckBox_"+questionID;

		var BreakByTutorCheckBoxId = document.getElementById(BreakByTutorCheckBox);
		
		if (BreakByTutorCheckBoxId.classList.contains('breakOutOtherThanAttribute')===true){
		BreakByTutorCheckBoxId.classList.remove("breakOutOtherThanAttribute");
	if (document.getElementById(TutorDataDivId).style.display == 'none' || showingstatus == 'firsttimemain' || showingstatus == 'z-a' || showingstatus == 'a-z' || showingstatus == 'asc' || showingstatus == 'desc' || showingstatusother == 'firsttimemain' || showingstatusother == 'z-a' || showingstatusother == 'a-z' || showingstatusother == 'asc' || showingstatusother == 'desc') {
		document.getElementById(loadingImgId).style.display = 'block';
		// this is for sitewide
		if (scopeName == "site") {
			if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain' && showingstatusother == 'firsttimemain') {
				//processAndCloseBreakBoxCheckBox(TutorDataDivId,loadingImgId);
				document.getElementById(loadingImgId).style.display = 'none';
			} else {
				new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbytutorcheckboxsitewide&questionid=" + questionID + "&beginsurvey=" + beginSurvey + "&endsurvey=" + endSurvey + "&notselectedids=" + notSelectedIds + "&siteidlist=" + siteidList + "&programlist=" + programList + "&showingstatus=" + showingstatus + "&showtutorstudentall=" + showtutorstudentall + "&showingstatusother=" + showingstatusother + "&showtutorstudentallother=" + showtutorstudentallother), {
					onSuccess: function(returnHtml) {
						document.getElementById(loadingImgId).style.display = 'none';
						document.getElementById(clickLinkId).style.display = 'block';
						var studentdiv = "StudentDataDiv" + questionID;
						var tutorOnly = "TutorOnly" + questionID;
						var attributeDiv = "AttributeDataDiv" + questionID;
						var attributeSelectionDiv = "AttributeSelectionDiv" + questionID;
						Element.update(TutorDataDivId, returnHtml.responseText);
						//Effect.toggle(TutorDataDivId, 'slide');
						if (jQuery('#' + attributeDiv).css('display') != 'none' && typeof(jQuery('#' + attributeDiv).css('display')) !== 'undefined') {
							jQuery('#' + attributeDiv).hide();
							jQuery('#' + attributeSelectionDiv).hide();
							if (showingstatus == 'firsttimemain' && showingstatusother == 'firsttimemain') {
								document.getElementById(TutorDataDivId).style.display = 'block';
							}
						} else {
							jQuery('#' + attributeSelectionDiv).hide();
							if (showingstatus == 'firsttimemain' && showingstatusother == 'firsttimemain')
								Effect.BlindDown(TutorDataDivId);
						}
					},
					onFailure: function() {
						alert('Oops...mistake on server');
					}
				});

			}
		} else if (scopeName == "program") {
			if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain' && showingstatusother == 'firsttimemain') {
				//processAndCloseBreakBoxCheckBox(TutorDataDivId,loadingImgId);
				document.getElementById(loadingImgId).style.display = 'none';
			} else {
				new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbytutorprogramwidecheckbox&questionid=" + questionID + "&beginsurvey=" + beginSurvey + "&endsurvey=" + endSurvey + "&notselectedids=" + notSelectedIds + "&siteidlist=" + siteidList + "&programlist=" + programList + "&showingstatus=" + showingstatus + "&showtutorstudentall=" + showtutorstudentall + "&showingstatusother=" + showingstatusother + "&showtutorstudentallother=" + showtutorstudentallother), {
					onSuccess: function(returnHtml) {
						document.getElementById(loadingImgId).style.display = 'none';
						document.getElementById(clickLinkId).style.display = 'block';
						var studentdiv = "StudentDataDiv" + questionID;
						var tutorOnly = "TutorOnly" + questionID;
						var attributeDiv = "AttributeDataDiv" + questionID;
						var attributeSelectionDiv = "AttributeSelectionDiv" + questionID;
						Element.update(TutorDataDivId, returnHtml.responseText);
						//Effect.toggle(TutorDataDivId, 'slide');
						if (jQuery('#' + attributeDiv).css('display') != 'none' && typeof(jQuery('#' + attributeDiv).css('display')) !== 'undefined') {
							jQuery('#' + attributeDiv).hide();
							jQuery('#' + attributeSelectionDiv).hide();
							if (showingstatus == 'firsttimemain' && showingstatusother == 'firsttimemain') {
								document.getElementById(TutorDataDivId).style.display = 'block';
							}
						} else {
							jQuery('#' + attributeSelectionDiv).hide();
							if (showingstatus == 'firsttimemain' && showingstatusother == 'firsttimemain')
								Effect.BlindDown(TutorDataDivId);
						}
					},
					onFailure: function() {
						alert('Oops...mistake on server');
					}
				});
			}
		}
	} else {
		document.getElementById(loadingImgId).style.display = 'block';
		processAndCloseBreakBoxCheckBox(TutorDataDivId, loadingImgId);
		document.getElementById(loadingImgId).style.display = 'none';
	}
		}
}

function BreakByTutorCheckBoxInner(scopeName, loadingImgId, TutorDataDivId, clickLinkId, questionID, beginSurvey, endSurvey, notSelectedIds, siteidList, programList, showingstatus, showtutorstudentall, showingstatusother, showtutorstudentallother) {

	if (document.getElementById(TutorDataDivId).style.display == 'none' || showingstatus == 'firsttimemain' || showingstatus == 'z-a' || showingstatus == 'a-z' || showingstatus == 'asc' || showingstatus == 'desc' || showingstatusother == 'firsttimemain' || showingstatusother == 'z-a' || showingstatusother == 'a-z' || showingstatusother == 'asc' || showingstatusother == 'desc') {
		document.getElementById(loadingImgId).style.display = 'block';
		
		// this is for sitewide
		if (scopeName == "site") {
			if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain' && showingstatusother == 'firsttimemain') {
				document.getElementById(clickLinkId).style.display = 'block';
				//processAndCloseBreakBoxCheckBox(TutorDataDivId,loadingImgId);
				document.getElementById(loadingImgId).style.display = 'none';
				
			} else {
				new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbytutorcheckboxsitewide&questionid=" + questionID + "&beginsurvey=" + beginSurvey + "&endsurvey=" + endSurvey + "&notselectedids=" + notSelectedIds + "&siteidlist=" + siteidList + "&programlist=" + programList + "&showingstatus=" + showingstatus + "&showtutorstudentall=" + showtutorstudentall + "&showingstatusother=" + showingstatusother + "&showtutorstudentallother=" + showtutorstudentallother), {
					onSuccess: function(returnHtml) {
						document.getElementById(loadingImgId).style.display = 'none';
						document.getElementById(clickLinkId).style.display = 'block';
						var studentdiv = "StudentDataDiv" + questionID;
						var tutorOnly = "TutorOnly" + questionID;
						var attributeDiv = "AttributeDataDiv" + questionID;
						var attributeSelectionDiv = "AttributeSelectionDiv" + questionID;
						Element.update(TutorDataDivId, returnHtml.responseText);
						
						//Effect.toggle(TutorDataDivId, 'slide');
						if (jQuery('#' + attributeDiv).css('display') != 'none' && typeof(jQuery('#' + attributeDiv).css('display')) !== 'undefined') {
							jQuery('#' + attributeDiv).hide();
							jQuery('#' + attributeSelectionDiv).hide();
							if (showingstatus == 'firsttimemain' && showingstatusother == 'firsttimemain') {
								document.getElementById(TutorDataDivId).style.display = 'block';
							}
						} else {
							jQuery('#' + attributeSelectionDiv).hide();
							if (showingstatus == 'firsttimemain' && showingstatusother == 'firsttimemain')
								Effect.BlindDown(TutorDataDivId);
						}
					},
					onFailure: function() {
						alert('Oops...mistake on server');
					}
				});

			}
		} else if (scopeName == "program") {
			if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain' && showingstatusother == 'firsttimemain') {
				document.getElementById(clickLinkId).style.display = 'block';
				//processAndCloseBreakBoxCheckBox(TutorDataDivId,loadingImgId);
				document.getElementById(loadingImgId).style.display = 'none';
				
			} else {
				new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbytutorprogramwidecheckbox&questionid=" + questionID + "&beginsurvey=" + beginSurvey + "&endsurvey=" + endSurvey + "&notselectedids=" + notSelectedIds + "&siteidlist=" + siteidList + "&programlist=" + programList + "&showingstatus=" + showingstatus + "&showtutorstudentall=" + showtutorstudentall + "&showingstatusother=" + showingstatusother + "&showtutorstudentallother=" + showtutorstudentallother), {
					onSuccess: function(returnHtml) {
						document.getElementById(loadingImgId).style.display = 'none';
						document.getElementById(clickLinkId).style.display = 'block';
						var studentdiv = "StudentDataDiv" + questionID;
						var tutorOnly = "TutorOnly" + questionID;
						var attributeDiv = "AttributeDataDiv" + questionID;
						var attributeSelectionDiv = "AttributeSelectionDiv" + questionID;
						Element.update(TutorDataDivId, returnHtml.responseText);
						//Effect.toggle(TutorDataDivId, 'slide');
						if (jQuery('#' + attributeDiv).css('display') != 'none' && typeof(jQuery('#' + attributeDiv).css('display')) !== 'undefined') {
							jQuery('#' + attributeDiv).hide();
							jQuery('#' + attributeSelectionDiv).hide();
							if (showingstatus == 'firsttimemain' && showingstatusother == 'firsttimemain') {
								document.getElementById(TutorDataDivId).style.display = 'block';
							}
						} else {
							jQuery('#' + attributeSelectionDiv).hide();
							if (showingstatus == 'firsttimemain' && showingstatusother == 'firsttimemain')
								Effect.BlindDown(TutorDataDivId);
						}
					},
					onFailure: function() {
						alert('Oops...mistake on server');
					}
				});
			}
		}
	} else {
		document.getElementById(loadingImgId).style.display = 'block';
		processAndCloseBreakBoxCheckBox(TutorDataDivId, loadingImgId);
		document.getElementById(loadingImgId).style.display = 'none';
	}
		
}
// For SDataView-53
function BreakByTutorCheckBox_volunteers(scopeName, loadingImgId, TutorDataDivId, clickLinkId, questionID, beginSurvey, endSurvey, notSelectedIds, siteidList, programList, showingstatus, showtutorstudentall, showingstatusother, showtutorstudentallother,volunteeruserid) {
	if (document.getElementById(TutorDataDivId).style.display == 'none' || showingstatus == 'firsttimemain' || showingstatus == 'z-a' || showingstatus == 'a-z' || showingstatus == 'asc' || showingstatus == 'desc' || showingstatusother == 'firsttimemain' || showingstatusother == 'z-a' || showingstatusother == 'a-z' || showingstatusother == 'asc' || showingstatusother == 'desc') {
		document.getElementById(loadingImgId).style.display = 'block';		
		if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain' && showingstatusother == 'firsttimemain') {
			document.getElementById(loadingImgId).style.display = 'none';
		} else {
			new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbytutorprogramwidecheckbox&questionid=" + questionID + "&beginsurvey=" + beginSurvey + "&endsurvey=" + endSurvey + "&notselectedids=" + notSelectedIds + "&siteidlist=" + siteidList + "&programlist=" + programList + "&showingstatus=" + showingstatus + "&showtutorstudentall=" + showtutorstudentall + "&showingstatusother=" + showingstatusother + "&showtutorstudentallother=" + showtutorstudentallother + "&volunteeruserid=" + volunteeruserid), {
				onSuccess: function(returnHtml) {
					document.getElementById(loadingImgId).style.display = 'none';
					document.getElementById(clickLinkId).style.display = 'block';
					var studentdiv = "StudentDataDiv" + questionID;
					var tutorOnly = "TutorOnly" + questionID;
					var attributeDiv = "AttributeDataDiv" + questionID;
					var attributeSelectionDiv = "AttributeSelectionDiv" + questionID;
					Element.update(TutorDataDivId, returnHtml.responseText);
					//Effect.toggle(TutorDataDivId, 'slide');
					if (jQuery('#' + attributeDiv).css('display') != 'none' && typeof(jQuery('#' + attributeDiv).css('display')) !== 'undefined') {
						jQuery('#' + attributeDiv).hide();
						jQuery('#' + attributeSelectionDiv).hide();
						if ((showingstatus == 'firsttimemain' && showingstatusother == 'firsttimemain')||(showingstatus == 'a-z' && showingstatusother == 'a-z')) {
							document.getElementById(TutorDataDivId).style.display = 'block';
						}
					} else {
						jQuery('#' + attributeSelectionDiv).hide();
						if (showingstatus == 'firsttimemain' && showingstatusother == 'firsttimemain')
							Effect.BlindDown(TutorDataDivId);
						else if(showingstatus == 'a-z' && showingstatusother == 'a-z'){
							if(jQuery('#' + TutorDataDivId).css('display') != 'none')
								document.getElementById(TutorDataDivId).style.display = 'block';
							else
								Effect.BlindDown(TutorDataDivId);
						}
					}
				},
				onFailure: function() {
					alert('Oops...mistake on server');
				}
			});
		}
	} else {
		document.getElementById(loadingImgId).style.display = 'block';
		processAndCloseBreakBoxCheckBox(TutorDataDivId, loadingImgId);
		document.getElementById(loadingImgId).style.display = 'none';
	}
}

function processAndCloseBreakBoxCheckBox(TutorDataDivId) {
	Effect.Fade(TutorDataDivId);
	//Effect.toggle(TutorDataDivId, 'slide');
	Effect.BlindUp(TutorDataDivId);
	
	var question1ID = parseInt(TutorDataDivId.match(/[0-9]+/)[0], 10);
	
	var BreakByTutorCheckBox = "BreakByTutorCheckBox_"+question1ID;
	
    var BreakByTutorCheckBoxId = document.getElementById(BreakByTutorCheckBox);
	BreakByTutorCheckBoxId.classList.add("breakOutOtherThanAttribute");
	
}