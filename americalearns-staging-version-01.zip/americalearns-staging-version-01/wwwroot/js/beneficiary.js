var $j23 = jQuery.noConflict();
var all_iden_arrList = [];
var $dialog = {};
var hWindow = 500;
var $loadingImageTable = '<table width="100%"><tr><td align="center"><img src="../../images/icons/animated_loading.gif"></td></tr></table>';
//DS:MV-1389
var globalQuid, $jdialog = {};
var $jloadingImageTable = '<table width="100%"><tr><td align="center"><img src="../../images/icons/animated_loading.gif"></td></tr></table>';
//DS:MV-1389 End
$j23(document).ready(function() {

    /*------ BG-125 : Start -------*/
    $j23('form#AssociationItemSettings :input').live('change input', function() {
        $j23(this).addClass('changedInput');
    });
    /*------ BG-125 : End -------*/

    /* ----- MCR-66 Start ------*/
    if($j23(".hrWidth").width() > 515){
        $j23(".tdWidth").attr("width",0);
    }
    if($j23(".tdWidth").width() > 505){
        $j23(".hrWidth").attr("width",519);
    }
    else
    {
        $j23(".hrWidth").width($j23(".adminlist").width()+7);
    }
    /* ----- MCR-66 End ------*/  
    
     $j23.ajax({
         url: "index.cfm?event=association.setValuesonSessionForBeneficiary",
         type: "post",
         data: {
             flagVal :0
         },
         async: false
     });
     


    if ($j23('body').find('#ajaxFilterLoading').attr('id') != 'ajaxFilterLoading') {
        var html = '<div id="ajaxFilterLoading" style="display:none"><img id="loading" src="../../images/icons/animated_loading.gif"><div>';
        html += '<div></div></div><div class="bg"></div></div>'
        $j23('body').append(html);
    }

    var height = $j23('body').outerHeight();
    var width = $j23('body').outerWidth();
    $j23('#ajaxFilterLoading').css({
        'width': '100%',
        'height': '100%',
        'position': 'fixed',
        'z-index': '10000000',
        'top': '0',
        'left': '0'
    });

    $j23('#ajaxFilterLoading .bg').css({
        'background': '#000000',
        'opacity': '0.15',
        'width': '100%',
        'height': '100%',
        'position': 'absolute',
        'top': '0'
    });

    $j23('#ajaxFilterLoading>div:first').css({
        'width': '100%',
        'text-align': 'center',
        'position': 'absolute',
        'left': '0',
        'top': '48%',
        'font-size': '16px',
        'z-index': '10',
        'color': '#ffffff'
    });
    /*end loading image*/

    
    $j23(function(){
        var hWindow = 500;
        
        $j23("#jWindow").dialog({
            modal:true, 
            title: 'Remove this Benificiary.', 
            resizable:false, 
            width:765, 
            autoOpen: false,
            height:hWindow, 
            position:['center',50],
            //dialogClass : 'addUpdateIdentifier',
            close: function( event, ui ){
                ResetActions();
            }
        });
        //ASSNS-81
        
        
     $j23("#jWindowIdentifierSetting").dialog({
            modal:true, 
            title: 'Identifier Settings', 
            resizable:false, 
            width:540, 
            autoOpen: false,
            height:hWindow, 
            position:['center',50],
			close: function( event, ui ){
                ResetActions();
            }
        }); 
        //ASSNS-81
    
    });

    $dialog.archiveIdentifierConfirm = $j23('<div></div>').dialog(dialogSettings('Archive', 'archiveIdentifierConfirm', 500, 500, hWindow, "auto"));

    $j23('.maintainAllAssign').live('click', function() {
        var currentIdnId = $j23(this).attr('data-itemid');
        var $maintainLink = $j23('.maintainAssign_'+currentIdnId);
        var $undoLink = $j23('.undoAssign_'+currentIdnId);
        if ($maintainLink.length){
            $maintainLink.trigger('click');
            $j23(".idnAssignment_" + currentIdnId).html('<a class="maintainAllAssign" data-itemid="'+ currentIdnId + '">Maintain None</a>');
        }else{
            $undoLink.trigger('click');
            $j23(".idnAssignment_" + currentIdnId).html('<a class="maintainAllAssign" data-itemid="'+ currentIdnId + '">Maintain All</a>');
        }
    });

    $j23('.maintainAssign').live('click', function() {
        var currentIdnAssignId = $j23(this).attr('data-userid');
        var currentIdnId = $j23(this).attr('data-itemid');
        var currentIdnMaintained = "";
        var undoLink = "<a class='undoAssign undoAssign_" + currentIdnId +" undoAssign_" + currentIdnAssignId + "' data-userid='" + currentIdnAssignId + "' data-itemid='" + currentIdnId + "'>Undo</a>";
        $j23(".idnAssignment_" + currentIdnAssignId).html("<b>Will Maintain</b> (" + undoLink + ")");
        if($j23(".maintainIdnVolassign").val() == '') {
            $j23(".maintainIdnVolassign").val(currentIdnAssignId);
        } else {
            currentIdnMaintained = $j23(".maintainIdnVolassign").val() + "," + currentIdnAssignId;
            $j23(".maintainIdnVolassign").val(currentIdnMaintained);
        }
    });

    $j23('.undoAssign').live('click', function() {        
        var currentIdnAssignId = $j23(this).attr('data-userid');
        var currentIdnId = $j23(this).attr('data-itemid');
        var currentIdnMaintained = $j23(".maintainIdnVolassign").val().split(",");	
        var maintainLink = "<a class='maintainAssign maintainAssign_"+ currentIdnId + " maintainAssign_" + currentIdnAssignId + "' data-userid='" + currentIdnAssignId + "' data-itemid='" + currentIdnId +  "'>Maintain this Assignment</a>"; 
        $j23(".idnAssignment_" + currentIdnAssignId).html(maintainLink);
        currentIdnMaintained.splice(currentIdnMaintained.indexOf(currentIdnAssignId), 1);		
        $j23(".maintainIdnVolassign").val(currentIdnMaintained);
    });

    $j23('input.closeDialog').live('click', function() {   
        var dialog = $j23(this).attr('data-dialog');
        //console.log("dialog: "+dialog);
        if((dialog != undefined && dialog.length > 0) && dialog != 'AddNewIdentifier'){
            $dialog[dialog].dialog('close').empty();
        }
        $j23(".identstatusdropdown").prop("disabled", false);
        $j23("#sel_action option[value='0']").prop('selected', true);
    });

    if($j23("#str_search").length && $j23("#str_search").val().length > 0) {  
        $j23(".search_inactive").css("display", "none");
            $j23(".search_active").css("display", "block");
      }

      $j23(".ui-dialog-titlebar-close").click(function(){ 
            selectActionReset();
            //$j23("#identifiersettingsenroll").prop('checked', false);  
        });
    
    
    $j23('input[name="savedview"]').live('click',function(e){
        $j23(".savedviewbtn").prop('disabled', false);
        $j23(".deleteviewbtn").prop('disabled', false);
    });

    // BG-324 Project 2
    $j23('#savedviewradio').live('click', function() {
        if ($j23('.savedviewdiv').css('display') == 'none') {

            var saved_views = $j23('#insidebox_saved_views');
            var $saved_view_string = '';
            var _this = $j23(this);
            var associationId = $j23('input[name="associationid"]').val();

            $j23.ajax({
                type: "post",
                url: "index.cfm?event=association.getSavedviews_ajax",
                data: { associationid: associationId },
                dataType: "json",
                beforeSend: function() {
                    showLoadingOverlay();
                },
                success: function(data) {
                    //data= JSON.parse(data);

                    if (data.TotalSavedViews > 0 && data.TotalSavedViews != 0) {
                        $j23('#insidebox_saved_views').html('');
                        $j23.each(data.savedviews, function(key, saved_view) {
                            let isDefaultRel = 0;
                            let check = "";
                            let defaultView = '<div class="isDefaultView" id="isDefaultView_' + saved_view.id + '" style="display:none;padding-right:5px">(Current Default View)</div>';
                            if (saved_view.IsDefaultView == "1") {
                                defaultView = '<div class="isDefaultView" id="isDefaultView_' + saved_view.id + '" style="display:inline-block;padding-right:5px">(Current Default View)</div>';
                                isDefaultRel = 1;
                                check = "Checked";
                            }
                            //Bg-268 

                            $saved_view_string = $saved_view_string + '<div class="radio show_sectn setradiopanel"><label class="setradiopanllabel savedview_' + saved_view.id + '" style="padding-right:5px"><input rel="' + isDefaultRel + '" type="radio" name="savedview" id="savedview_' + saved_view.id + '" value="' + saved_view.id + '" ' + check + ' />' + saved_view.viewname + '</label>'+defaultView+'<div class="defaultViewManage" id="defaultViewManage_' + saved_view.id +
                                '" style="display: none;"><a style="cursor:pointer" class="btn_makeDefault" id="btn_makeDefault_' +
                                saved_view.id +
                                '">Make Default</a> ' +
                                '<a class="btn_rename" rel='+isDefaultRel+' id="btn_rename_' + saved_view.id + '" style="cursor:pointer">Rename</a> ' +
                                '<a style="cursor:pointer" class="btn_delete" id="btn_delete_' + saved_view.id + '">Delete</a>' +
                                '</div></div></div>';
                        });

                        $saved_view_string = $saved_view_string + '<div class="clear"></div><div class="buttonBlock margin-top-10 margin-bottom-10"><input type="button" name="savedviewbtn" id="savedviewbtn" class="savedviewbtn" value="View"/></div>';
                        $j23('#insidebox_saved_views').html($saved_view_string);

                    } else {
                        $saved_view_string = $saved_view_string + '<div>' + data.savedviews + '</div>';
                    }

                    $j23('.savedviewdiv').slideDown(1000);
                    $j23('.addnewidentradiodiv').slideUp(1000);
                    $j23('.attributeoptiondiv').slideUp(1000);
                    var chkcount = $j23('input[name="savedview"]:checked').length;        
                    if(chkcount == 0)
                    {
                        $j23(".savedviewbtn").prop('disabled', true);
                        $j23(".deleteviewbtn").prop('disabled', true);
                    }
                    else if(chkcount > 0)
                    {
                        $j23(".savedviewbtn").prop('disabled', false);
                        $j23(".deleteviewbtn").prop('disabled', false);
                    }
                                       
                    hideLoadingOverlay();
                    //MV-1368 :: 1402
  					var selectedViews=$j23("#hidselectedsavedviewreload").val();
  					if(selectedViews==0 || selectedViews > 0){
                    $j23("#savedview_"+selectedViews).prop('checked', true);
                    }
				    //MV-1368 :: 1402
                },
                complete: function() {                	
                    
                },
                error: function(data) {
                    alert("error");
                    hideLoadingOverlay();
                }
            });            
            
        } else {
            $j23(this).removeAttr('checked');
            $j23('.savedviewdiv').slideUp(1000);
        }
    });


    $j23('input[name=savedview]').live('click', function() {
        let value = $j23(this).val();        
        let isDefaultRel = $j23(this).attr('rel');

        $j23('.defaultViewManage').hide();
        if (value > 0) {           
            // If saved view
            //$j23('#btn_delete').show();
            $j23('#defaultViewManage_' + value).css('display', 'inline-block');
            if (isDefaultRel == 1) {              
                $j23('#btn_makeDefault_' + value).hide();
            } else {               
                $j23('#btn_makeDefault_' + value).show();
            }
            $j23('#btn_rename_' + value).show();
            $j23('#btn_delete_' + value).show();
        } else {
                if (isDefaultRel == 1) {              
                $j23('#defaultViewManage_' + value).hide();
            } else {               
                $j23('#defaultViewManage_' + value).css('display', 'inline-block');
                $j23('#btn_makeDefault_0').show();
            }
            $j23('#btn_rename_0').hide();
            $j23('#btn_delete_0').hide();
        }
    });

    $dialog.renameSavedViewDialog = $j23('<div></div>').dialog(dialogSettings('Rename Saved View', 'renameSavedViewDialog', 550, 550, 550, 281));

    $j23(".btn_rename").live('click', function() {
        var saved_view_name = '';
        var selectedView = $j23('#insidebox_saved_views .radio input:radio:checked');
        var root = $j23('input[name="rootURL"]').val();
        var rel= $j23(this).attr('rel');
        saved_view_name = selectedView.parent().text();
        value = selectedView.val();
        $dialog.renameSavedViewDialog.dialog('open')
            .html($loadingImageTable)
            .load(root + 'association.renameAsociationSavedViewWindow&savedViewId=' + value+'&rel='+rel);
    });

    $j23("#saverename").live('click', function() {
        let values = {
            "savedViewId": $j23("#savedViewId").val(),
            "savedViewText": $j23("#savedViewText").val(),
            "associationId": $j23('input[name="associationid"]').val(),
            "getRel": $j23("#savedViewId").attr('rel')    
        }      //Saved and Default view validation
            var mtchFnd = matchRegEx(values.savedViewText, "^[a-z A-Z0-9]+$");
            if (mtchFnd == null) {
                alert("Enter valid data into 'Rename Saved View' text field");
                hideLoadingOverlay();
                return false;
            }else{
                $j23.ajax({
                    type: "post",
                    url: "index.cfm?event=association.renameAssociationSavedView",
                    data: values,
                    dataType: "json",
                    success: function(resp) {
                        
                        if(resp.data.status == "ok"){
                            var content = '<tbody><tr class=""><td class="iconupdated"></td><td>' + resp.data.msg + '</td></tr></tbody>';
                            $j23('table.usermessage').html(content).slideDown('slow');            
                            $j23(".savedview_" + values.savedViewId).html("<input rel='"+values.getRel+"' checked type='radio' name='savedview' id='savedview_"+values.savedViewId+"' value='"+values.savedViewId+"'></input>"+values.savedViewText);                       
                            hideLoadingOverlay();        
                            $dialog["renameSavedViewDialog"].dialog('close').empty();
                        }else{
                            alert(resp.data.msg);
                           
                        }
                       
                    },
                    error: function(resp) {
                        alert('Oops...mistake on server');
                        hideLoadingOverlay();    
                        $dialog["renameSavedViewDialog"].dialog('close').empty();
                    }
                });
            }
    });

    $j23(".btn_delete").live('click', function() {
        // $j23("#deleteviewbtn").trigger("click");
        if ($j23("input:radio[name='savedview']").is(':checked')) {

            if ($j23('#search_clear_icon_new').is(':visible')) {
                $j23('#search_clear_icon_new').hide();
                $j23('#search_icon_new').show();
                $j23('#str_search').val('');
            }
            var savedviewid = $j23("input:radio[name='savedview']:checked").val();
            var enteredname = $j23(".savedview_" + savedviewid).text();
            var associationId = $j23('input[name="associationid"]').val();
            var selectedview = $j23("input:radio[name='savedview']:checked");
            var path = 'index.cfm?event=association.deleteSavedViewBeneficiary&associationid=' + associationId;
            //var redirect_path = 'index.cfm?event=association.editassociation&associationid=#associationid#&statusAttrVal=1'; //For BG-34

            if (confirm('Are you sure you want to delete the saved view, "' + enteredname + '" ?')) /* <!--- ASSNS 545 Final Changes ---> */ {
                $j23(this).prop("disabled", true);
                $j23(".savedviewbtn").prop('disabled', true);
                showLoadingOverlay(); //@
                $j23.ajax({
                    url: path,
                    type: "POST",
                    data: { savedviewid: savedviewid },
                    success: function(response) {
                        response = $j23.parseJSON(response);
                        selectedview.parent().parent().remove();
                        hideLoadingOverlay();
                        var content = '<tbody><tr class=""><td class="iconupdated"></td><td>' + response + '</td></tr></tbody>';
                        $j23('table.usermessage').html(content);
                        $j23(".newAssocItemDiv").html('');
                    },
                    error: function() {
                        $j23("#jWindow").dialog('close');
                        alert('Oops...mistake on server');
                        hideLoadingOverlay();
                        return false;
                    }
                });
            }
        } else {
            alert("Please select any one view ");
        }
    });

    $j23(".btn_makeDefault").live('click', function() {
        var saved_view_name = '';
        var selectedView = $j23('#insidebox_saved_views .radio input:radio:checked');
        saved_view_name = selectedView.parent().text().trim();
        value = selectedView.val();

        var values = {
            "viewid": value
        }

        $j23('.view_success_message').slideUp(1000)
            //if (confirm('Are you sure you want to make default the saved view, "' + saved_view_name + '" ?')) {
        showLoadingOverlay();
        $j23.ajax({
            type: "post",
            url: "index.cfm?event=association.makeAssociationDefault",
            data: values,
            dataType: "json",
            success: function(resp) {
                //selectedView.parent().parent().remove();
                $j23('.isDefaultView').hide();
                $j23('input[name=savedview]').attr('rel', 0);
                $j23('.btn_rename').each(function(){		
                    var relVal=$j23(this).attr('rel');  
                    if(relVal==1){
                        $j23(this).attr("rel",0);
                    }
                });
                if (values.viewid == 0) {
                    $j23("#savedview_0").attr("rel", 1);
                } else {
                    $j23("#savedview_" + values.viewid).attr("rel", 1);
                    $j23("#savedview_" + values.viewid).attr("checked", true);
                    $j23("#btn_rename_" + values.viewid).attr("rel", 1);
                }
                $j23('#isDefaultView_' + values.viewid).css("display", "inline-block");
                $j23('#btn_makeDefault_' + values.viewid).hide();
                var content = '<tbody><tr class=""><td class="iconupdated"></td><td>' + resp.data.msg + '</td></tr></tbody>';
                $j23('table.usermessage').slideDown(1000);
                $j23('table.usermessage').html(content);
                // $j23('#view_success_msg').html(resp.data.msg);
                // $j23('.view_success_message').removeClass('hide').slideDown(1000);
                hideLoadingOverlay();
                //$('#AllEnrolledView').attr('checked','checked');
                //$('#btn_delete').hide();
            },
            error: function(resp) {

            }
        });
        //}
    });

    // BG-324 Project 2 End

    $j23('#addnewradio').live('click', function() {
        if ($j23('.addnewidentradiodiv').css('display') == 'none') {            
            $j23('.addnewidentradiodiv').slideDown(1000);
            $j23('.savedviewdiv').slideUp(1000);
            $j23('.attributeoptiondiv').slideUp(1000);
            $j23('input[name="savedview"]').prop('checked',false);
        } else {
            $j23(this).removeAttr('checked');
            $j23('.addnewidentradiodiv').slideUp(1000);
        }
    });

    $j23('#attributeoption').live('click', function() {        
        if ($j23('.attributeoptiondiv').css('display') == 'none') {

            /*-----Start: preparing customized view options ------*/
            var associationId= $j23('input[name="associationid"]').val();
            var path = "index.cfm?event=association.beneficiaryCustomizedViewOptions";
            $j23.ajax({
                url: path,
                type: "Post",
                data: {
                    associationid: associationId
                },                
               // async: false,
               beforeSend: function() {
                    showLoadingOverlay();
                },                    
                success:function(data){                    
                   // console.log(data);
                   $j23('.savedviewdiv').slideUp(1000);
                   $j23('input[name="savedview"]').prop('checked',false);
                   $j23('.addnewidentradiodiv').slideUp(1000);                   
                    $j23('#insidebox_customize_main').html(data);
                    $j23('.attributeoptiondiv').slideDown(1000);
                   // hideLoadingOverlay(); 

                    $j23("#optBreakOutContainer").hide();
                    $j23(".breakOutRadioOptions").hide();
                    hideLoadingOverlay();
                },
                complete:function(data){
                                   
                },
                error:function(){ 
                    alert('Oops...mistake on server');
                    hideLoadingOverlay();
                    return false;
                }
            });
            
            /*-----End: preparing customized view options ------*/


        } else {
            $j23(this).removeAttr('checked');
            $j23('.attributeoptiondiv').slideUp(1000);
        }
    });

    $j23('#saveenteredname input[type="text"]').live({
        keyup : function(){
            //console.log($j23(this).attr('id'));
            CountLeft(document.getElementById($j23(this).attr('id')),$j23(this).attr('rel'));
        },
        keydown : function(){
            //console.log($j23(this).attr('id') );
            CountLeft(document.getElementById($j23(this).attr('id')),$j23(this).attr('rel'));
        }
    });

    // load identifiers list on page load    
    var associationId= $j23('input[name="associationid"]').val();
    var statusAttrValInitial = $j23('input[name="statusAttrVal"]').val();    
    var frmData = [];
    // frmData.push(
    //     /* {
    //     		"name": "statusAttrVal",
    //     		"value": 1
    //         }, */ // commented on 02-11-2019
    //     {
    //         "name": "statusAttrVal",
    //         "value": statusAttrValInitial
    //     }, {
    //         "name": "associationid",
    //         "value": associationId
    //     });
    //$j23('body').data('formdata', frmData);  // Commented for MV-1697
    if ($j23.trim($j23('#intstartrowhid').val()).length == 0) {
        var mydataa = { statusAttrVal: statusAttrValInitial, associationid: associationId };
        //$j23('.loader2').css('display','block');
        // var mydata = "";
        showLoadingOverlay();
        // BG-324 Project 2
        $j23.ajax({
            type: "post",
            url: "index.cfm?event=association.getSavedviews_ajax",
            data: { associationid: associationId },
            success: function(data) {
                data = JSON.parse(data);

                if (data.TotalSavedViews > 0 && data.TotalSavedViews != 0) {
                    // loadIdentifiersList(mydataa, "firstLoad");
                    $j23.each(data.savedviews, function(key, saved_view) {
                        let mydata = { savedview: saved_view.id, associationid: associationId };

                        if (saved_view.IsDefaultView == "1") {
                            //DS::MV-1697
                            frmData.push(
                                 {
                                        "name": "savedview",
                                        "value": saved_view.id
                                    }, 
                                {
                                    "name": "statusAttrVal",
                                    "value": statusAttrValInitial
                                },
                                {
                                    "name": "associationid",
                                    "value": associationId
                                });
                            $j23('body').data('formdata', frmData);
                            loadIdentifiersList(mydata, "firstLoad");
                        }
                    });
                } else {
                    frmData.push(
                       {
                           "name": "statusAttrVal",
                           "value": statusAttrValInitial
                       }, 
                       {
                           "name": "associationid",
                           "value": associationId
                       });
                   $j23('body').data('formdata', frmData);
                   //MV-1697
                    loadIdentifiersList(mydataa, "firstLoad");
                }
            }
        });
        // BG-324 Project 2 End

        // loadIdentifiersList(mydataa, "firstLoad");
    }

    //update association title    
    $j23("#idnListSection #association_title_update").live('click',function(e){

        $j23("#association_title_update").addClass("linkdisabled");
        //showLoadingOverlay(); //@    
        var associationId= $j23('input[name="associationid"]').val();    
        var isValid = true;
        //var namepattern = /^[a-z\d\_(),\*-_.~&\"\s']+$/i; // CPORT-66
        //var namepattern = /^[a-z\d\_(),\*-_.&\s']+$/i;    // CPORT-66
        var newItem = $j23(".association_title").val();
        e.preventDefault();        
        /*if(newItem.length == 0)
        {
            alert('Please enter a name for this Group.'); //MCR-60
            isValid = false;
            $j23("#association_title_update").removeClass("linkdisabled");
            //return false;
            //hideLoadingOverlay();
        }
        else if(!newItem.match(namepattern))
        {
           // alert('Please enter a valid name for this identifier.\n\nThe following characters are allowed: letters, numbers, spaces, parentheses, double-quotes, commas, hyphens, underscores, ampersands, and periods.'); //CPORT-66
            alert('Please enter a valid name for this Group.\n\nThe following characters are allowed: letters, numbers, spaces, parentheses, commas, hyphens, underscores, ampersands, and periods.'); 
            isValid = false;
            $j23("#association_title_update").removeClass("linkdisabled");
            //hideLoadingOverlay();
        }*/     
        // CPORT-66: Start
        if (newItem.replace(/^\s+|\s+$/g,"")=="")
	{
		alert("Please enter the Group Name.")//MCR-60
		isValid = false;
    		$j23("#association_title_update").removeClass("linkdisabled");
	}
	else if (newItem.search(/~/i) > -1)
	{
		alert("Please avoid '~' in the Association Name.");
		isValid = false;
    		$j23("#association_title_update").removeClass("linkdisabled"); 
	}
	else if (newItem.search(/`/i) > -1)
	{
		alert("Please avoid '`' in the Association Name.");
		isValid = false;
    		$j23("#association_title_update").removeClass("linkdisabled");
	}	        
        else if(newItem.indexOf('"') > -1)
        {
            alert("Please avoid double qoutes '\"' in the Association Name.");
            isValid = false;
            $j23("#association_title_update").removeClass("linkdisabled");
        } // CPORT-66: End
        else if(isValid == true)
        {                   
            var path = 'index.cfm?event=association.updateassoctiontitleBeneficiary&associationid='+associationId;
        
            $j23.ajax({
                url: path,
                type: "Post",
                data: {
                    updatedname: newItem
                },
                datatype:"json",
                //async: false,
                beforeSend: function() {
                    showLoadingOverlay();
                },
                success:function(data){
                    data= JSON.parse(data);
                    alert(data);
                    $j23("#assignedassociation").val(newItem);                    
                    $j23("#association_title_update").removeClass("linkdisabled");
                    hideLoadingOverlay();
                },
                complete:function(){
                    //hideLoadingOverlay();
                },
                error:function(){ 
                    hideLoadingOverlay();
                    alert('Oops...mistake on server');
                    $j23("#association_title_update").removeClass("linkdisabled");
                    return false;
                }
            });
        }
    });    

    // Alphabetical filter
    $j23('.alphabet li a').live('click', function() {
        showLoadingOverlay();
        //$j23('.loader2').css('display','block');
        _this = $j23(this);
        _this.parent().addClass('active');
        _this.parent().siblings('li').removeClass('active');
        var alphabeticFilter = _this.attr('id');
        $j23('#alphabeticFilter').val(alphabeticFilter);
        //var searchfilter = $j23('#str_search').val();
        $j23("#str_search").val("");
        var associationId= $j23('input[name="associationid"]').val();
        var int_start_row = 1;
        var sortColumn = $j23('#sortColumn').val();
        var sortType = $j23('#sortType').val();
        $j23('#newstartrowhid').val(int_start_row);
        
        var postData = $j23('body').data('formdata');
        
        var bit_push = 1;
        var bit_push_assnid = 1;
        $j23(postData).each(function(i){
            if(postData[i]['name'] == "alphabeticFilter") {
                postData[i]['value'] = alphabeticFilter;
                bit_push = 0;
            } else if (postData[i]['name'] == "searchfilter") {
                //postData[i]['value'] = searchfilter;
                postData[i]['value'] = '';
            } else if (postData[i]['name'] == "sort_column") {
                postData[i]['value'] = sortColumn;
            } else if (postData[i]['name'] == "sort_type") {
                postData[i]['value'] = sortType;
            }else if (postData[i]['name'] == "int_start_row") {
                postData[i]['value'] = int_start_row;
            }else if (postData[i]['name'] == "associationid") {
                postData[i]['value'] = associationId;
                bit_push_assnid = 0;
            }
        });
        if(bit_push == 1) {
             postData.push({
                "name": "alphabeticFilter",
                "value": alphabeticFilter
            });
        }
        if(bit_push_assnid == 1){
            postData.push({
                "name": "associationid",
                "value": associationId
            });
        }        
        //BG-697
        /* $j23('input[name=identifierid_list]').each(function(){		
            $j23(this).removeAttr('checked');  
        });	
        $j23('#selectedIdentifiers').val(''); */
        /* $j23("#sel_action option[value='-1']").prop('selected', true);	 */
        
        setSelectedIdentifiers();
        loadIdentifiersList(postData,"",'updatedView'); //BG-697
        $j23('#alphabeticFilter').val(alphabeticFilter);
        if($j23('#str_search').val().trim().length == 0){
            $j23('#search_icon_new').show();
            $j23('#search_clear_icon_new').hide();
        }       
             
    });    

    // Previous link pagination
    $j23('#report_list_previous').live('click', function(e) {
        $j23("html, body").animate({ scrollTop: 300 }, "slow");//MV-835
        showLoadingOverlay();
        //$j23('.loader2').css('display','block');
        e.preventDefault();
    
        var alphabeticFilter = $j23('#alphabeticFilter').val();
        var searchfilter = $j23('#str_search').val();
        var int_start_row = $j23('#int_prev_start_row').val();
        $j23('#newstartrowhid').val(int_start_row);
        var sortColumn = $j23('#sortColumn').val();
        var sortType = $j23('#sortType').val();
        var associationId= $j23('input[name="associationid"]').val();
        var postData = $j23('body').data('formdata');
        var bit_push = 1;
        var bit_push_assnid = 1;
        $j23(postData).each(function(i){
            if(postData[i]['name'] == "alphabeticFilter") {
                postData[i]['value'] = alphabeticFilter;
                
            } else if (postData[i]['name'] == "searchfilter") {
                postData[i]['value'] = searchfilter;
            } else if (postData[i]['name'] == "sort_column") {
                postData[i]['value'] = sortColumn;
            } else if (postData[i]['name'] == "sort_type") {
                postData[i]['value'] = sortType;
            }else if (postData[i]['name'] == "int_start_row") {
                postData[i]['value'] = int_start_row;
                bit_push = 0;
            }else if (postData[i]['name'] == "associationid") { 
                postData[i]['value'] = associationId;
                bit_push_assnid = 0;
            }
        });
        if(bit_push == 1) {
             postData.push({
                "name": "int_start_row",
                "value": int_start_row
            });
        }
        if(bit_push_assnid == 1){
            postData.push({
                "name": "associationid",
                "value": associationId
            });
        } 
        
        loadIdentifiersList(postData,"","updatedView"); //BG-697
                
    });
    
    
    // Next link pagination
    $j23('#report_list_next').live('click', function(e) {
        $j23("html, body").animate({ scrollTop: 300 }, "slow");//MV-835
        showLoadingOverlay();
        //$j23('.loader2').css('display','block');
        e.preventDefault();
        var alphabeticFilter = $j23('#alphabeticFilter').val();
        var searchfilter = $j23('#str_search').val();
        var int_start_row = $j23('#int_next_start_row').val();
        $j23('#newstartrowhid').val(int_start_row);
        var sortColumn = $j23('#sortColumn').val();
        var sortType = $j23('#sortType').val();
        var associationId= $j23('input[name="associationid"]').val();
        var postData = $j23('body').data('formdata');
        var bit_push = 1;
        var bit_push_assnid = 1;
        $j23(postData).each(function(i){
            if(postData[i]['name'] == "alphabeticFilter") {
                postData[i]['value'] = alphabeticFilter;
                
            } else if (postData[i]['name'] == "searchfilter") {
                postData[i]['value'] = searchfilter;
            } else if (postData[i]['name'] == "sort_column") {
                postData[i]['value'] = sortColumn;
            } else if (postData[i]['name'] == "sort_type") {
                postData[i]['value'] = sortType;
            }else if (postData[i]['name'] == "int_start_row") {
                postData[i]['value'] = int_start_row;
                bit_push = 0;
            }else if (postData[i]['name'] == "associationid") { 
                postData[i]['value'] = associationId;
                bit_push_assnid = 0;
            }
        });
        if(bit_push == 1) {
             postData.push({
                "name": "int_start_row",
                "value": int_start_row
            });
        }
        if(bit_push_assnid == 1){
            postData.push({
                "name": "associationid",
                "value": associationId
            });
        } 
       
        loadIdentifiersList(postData,"","updatedView"); //BG-697               
    });
    
    /* Sorting begin */
    $j23('.headers .columnForSort, .notHeader .columnForSort').live('click', function(e) {
        var noSortAllowed = $j23('input[name="breakOutRadio"]:checked').val();/* --- BG-165 --- */
        var noSortAllowedSavedView = $j23('input[name="noSortBrkOut"]').val();/* --- BG-165 --- */        
        if(noSortAllowed != 1 && noSortAllowed != 2 && noSortAllowedSavedView == 0){/* --- BG-165 --- */
        showLoadingOverlay();
       // $j23('.loader2').css('display','block');
        e.preventDefault();
        var sortColumn = $j23(this).attr('data-column');
        var sortType = $j23(this).attr('data-sort');
        $j23('#sortColumn').val(sortColumn);
        $j23('#sortType').val(sortType);
        var alphabeticFilter = $j23('#alphabeticFilter').val();
        var searchfilter = $j23('#str_search').val();
        var int_start_row = 1;
        $j23('#newstartrowhid').val(int_start_row);
        var associationId= $j23('input[name="associationid"]').val();
        var postData = $j23('body').data('formdata');
        var bit_push = 1;
        var bit_push_assnid = 1;
        $j23(postData).each(function(i){
            if(postData[i]['name'] == "alphabeticFilter") {
                postData[i]['value'] = alphabeticFilter;
            } else if (postData[i]['name'] == "searchfilter") {
                postData[i]['value'] = searchfilter;
            } else if (postData[i]['name'] == "sort_column") {
                postData[i]['value'] = sortColumn;
                bit_push = 0;
            } else if (postData[i]['name'] == "sort_type") {
                postData[i]['value'] = sortType;
                bit_push = 0;
            }else if (postData[i]['name'] == "int_start_row") {
                postData[i]['value'] = int_start_row;
            }else if (postData[i]['name'] == "associationid") { 
                postData[i]['value'] = associationId;
                bit_push_assnid = 0;
            }
        });
        if(bit_push == 1) {
            postData.push({
                "name": "sort_column",
                "value": sortColumn
            });
            postData.push({
                "name": "sort_type",
                "value": sortType
            });
        }
        if(bit_push_assnid == 1){
            postData.push({
                "name": "associationid",
                "value": associationId
            });
        } 
        
        loadIdentifiersList(postData,"");
        if (sortType === 'desc') {
            $j23(this).attr('data-sort', 'asc');
        } else {
            $j23(this).attr('data-sort', 'desc');
        }        
    }/* --- BG-165 --- */
    }); /* Sorting end */
    
    
    $j23('form#frm_identifier_list').bind("keyup", function(e) {
        if($j23('#str_search').val().trim().length){            
            $j23('#search_icon_new').hide();
            $j23('#search_clear_icon_new').show();            
        }
        else{
            if($j23('#search_clear_icon_new').is(':visible')){                  
                $j23('#search_clear_icon_new').click();
            }
            $j23('#search_clear_icon_new').hide();
            $j23('#search_icon_new').show();
        }
        var code = e.keyCode || e.which; 
        if (code  == 13) {               
            e.preventDefault();
            return false;
        }
        if(code  == 8 && $j23('#str_search').val().trim().length == 0) {   //Added on 04-12-2019
            $j23('.ui-autocomplete.ui-menu.ui-widget.ui-widget-content.ui-corner-all').hide();
            $j23('#str_search').blur();
            //$j23('#str_search').focus();		  
        }
        
        if($j23('#str_search').val().trim().length == 0){           
            $j23('#All').click();
        }
    });

    
    $j23('#savedviewbtn').live('click', function() {
        
        //$j23(".loader1").css("display","block");	
        showLoadingOverlay();
        $j23("#savedviewbtn").attr('disabled',true);
        $j23("#deleteviewbtn").attr('disabled',true);
        if($j23('#search_clear_icon_new').is(':visible')){                  
            $j23('#search_clear_icon_new').hide();
            $j23('#search_icon_new').show();
        }
        var savedviewid_btn=$j23("input:radio[name='savedview']:checked").val();              //MV-1368::1402         
        var _this = $j23("#form_savedviews");
       // $('#selectedview').val('savedviews');//ADMINFUNCT-34
        var postData = _this.serializeArray();
       // $('#sortColumn').val('');
       // $('#sortType').val('');
        $j23('#alphabeticFilter').val('');
        $j23('#str_search').val('');
        $j23('body').data('formdata',postData);
        loadIdentifiersList(postData,"");        
        
        $j23('table.usermessage').html('');
        $j23(".newAssocItemDiv").html('');  	
        $j23("#savedviewbtn").attr('disabled',false);
        $j23("#deleteviewbtn").attr('disabled',false);
        $j23('#hidselectedsavedviewreload').val(savedviewid_btn);		//MV-1368 :: 1402
    });
    
    $j23('#search_clear_icon_new').live('click', function(e) {        
        $j23("#search_clear_icon_new").hide();
		$j23(".search_inactive").show();
	    $j23("#str_search").val("");	 
        showLoadingOverlay();
        //$j23('.loader2').css('display','block');
        e.preventDefault();
        var alphabeticFilter = $j23('#alphabeticFilter').val();   //Commented on 04-12-2019  //UnComment for MV-1697
        //var alphabeticFilter = $j23('#alpha_all #all').text();  //Added on 04-12-2019
        var searchfilter = $j23('#str_search').val();
        var int_start_row = $j23('#int_next_start_row').val();
        var sortColumn = $j23('#sortColumn').val();
        var sortType = $j23('#sortType').val();
        var associationId= $j23('input[name="associationid"]').val();
        var postData = $j23('body').data('formdata');
        var bit_push = 1;
        var bit_push_assnid = 1;
        $j23(postData).each(function(i){
            if(postData[i]['name'] == "alphabeticFilter") {
                postData[i]['value'] = alphabeticFilter;
            } else if (postData[i]['name'] == "searchfilter") {
                bit_push = 0;
                postData[i]['value'] = searchfilter;
            } else if (postData[i]['name'] == "sort_column") {
                postData[i]['value'] = sortColumn;
            } else if (postData[i]['name'] == "sort_type") {
                postData[i]['value'] = sortType;
            }else if (postData[i]['name'] == "int_start_row") {
                postData[i]['value'] = 1;
            }else if (postData[i]['name'] == "associationid") { 
                postData[i]['value'] = associationId;
                bit_push_assnid = 0;
            }
        });
        if(bit_push == 1) {
             postData.push({
                "name": "searchfilter",
                "value": searchfilter
            });
        }
        if(bit_push_assnid == 1){
            postData.push({
                "name": "associationid",
                "value": associationId
            });
        } 
        
        $j23('input[name=identifierid_list]').each(function(){		
                $j23(this).removeAttr('checked');       
        });	
        $j23('#selectedIdentifiers').val('');
        
        loadIdentifiersList(postData,"");         
        $j23('.alphabet li').removeClass('active');
        $j23('#alpha_all').addClass('active');
        var selectedAlphabet = $j23('#alpha_all #all').text();
        $j23('#alphabeticFilter').val(selectedAlphabet);      
       
    });
    
    
    $j23('#search_icon_new').live('click',function(e){
        
        showLoadingOverlay();
        //$j23('.loader2').css('display','block');
        e.preventDefault();
        //$j23('#str_search').val('');
        $j23('.alphabet li').removeClass('active');
       // $j23('#alpha_all').addClass('active');
        var selectedAlphabet = $j23('#alpha_all #all').val();
        $j23('#alphabeticFilter').val(selectedAlphabet);

        var alphabeticFilter = $j23('#alphabeticFilter').val();
        var searchfilter = $j23('#str_search').val();
        var int_start_row = $j23('#int_next_start_row').val();
        var sortColumn = $j23('#sortColumn').val();
        var sortType = $j23('#sortType').val();
        var associationId= $j23('input[name="associationid"]').val();
        var postData = $j23('body').data('formdata');
        var bit_push = 1;
        var bit_push_assnid = 1;
        $j23(postData).each(function(i){
            if(postData[i]['name'] == "alphabeticFilter") {
                postData[i]['value'] = alphabeticFilter;
            } else if (postData[i]['name'] == "searchfilter") {
                bit_push = 0;
                postData[i]['value'] = '';
            } else if (postData[i]['name'] == "sort_column") {
                postData[i]['value'] = sortColumn;
            } else if (postData[i]['name'] == "sort_type") {
                postData[i]['value'] = sortType;
            }else if (postData[i]['name'] == "int_start_row") {
                postData[i]['value'] = 1;
            }else if (postData[i]['name'] == "associationid") { 
                postData[i]['value'] = associationId;
                bit_push_assnid = 0;
            }
        });
        if(bit_push == 1) {
             postData.push({
                "name": "searchfilter",
                "value": ""
            });
        }
        if(bit_push_assnid == 1){
            postData.push({
                "name": "associationid",
                "value": associationId
            });
        } 
       
        $j23('input[name=identifierid_list]').each(function(){		
            $j23(this).removeAttr('checked');       
        });	
        $j23('#selectedIdentifiers').val('');        
        
        loadIdentifiersList(postData,"");
        
        
    });
    

    /* ---------------Search Suggestion Start ---------------------------------------------*/

    $j23(function() {
        var available_names = all_iden_arrList;
        $j23( "#str_search" ).autocomplete({
            source: available_names,
		change: function(event, ui){			 
		},
		select: function (event, ui) {            
            event.preventDefault();
			var text = ui.item.value; 
			$j23("#str_search").val(text);			
            if($j23('.ui-autocomplete.ui-menu.ui-widget.ui-widget-content.ui-corner-all').is(":visible")){
				$j23('.ui-autocomplete.ui-menu.ui-widget.ui-widget-content.ui-corner-all').hide();
		    }
                showLoadingOverlay();
                //$j23('.loader2').css('display','block');
                event.preventDefault();                
                var alphabeticFilter = $j23('#alphabeticFilter').val();
                var searchfilter = $j23('#str_search').val();
                var int_start_row = $j23('#int_next_start_row').val();
                var sortColumn = $j23('#sortColumn').val();
                var sortType = $j23('#sortType').val();
                var associationId= $j23('input[name="associationid"]').val();
                var postData = $j23('body').data('formdata');
                var bit_push = 1;
                var bit_push_assnid = 1;
                $j23(postData).each(function(i){
                    if(postData[i]['name'] == "alphabeticFilter") {
                        //postData[i]['value'] = alphabeticFilter;
                        postData[i]['value'] = '';
                    } else if (postData[i]['name'] == "searchfilter") {
                        bit_push = 0;
                        postData[i]['value'] = searchfilter;
                    } else if (postData[i]['name'] == "sort_column") {
                        postData[i]['value'] = sortColumn;
                    } else if (postData[i]['name'] == "sort_type") {
                        postData[i]['value'] = sortType;
                    }else if (postData[i]['name'] == "int_start_row") {
                        postData[i]['value'] = 0;
                    }else if (postData[i]['name'] == "associationid") { 
                        postData[i]['value'] = associationId;
                        bit_push_assnid = 0;
                    }
                });
                if(bit_push == 1) {
                    postData.push({
                        "name": "searchfilter",
                        "value": searchfilter
                    });
                }
                if(bit_push_assnid == 1){
                    postData.push({
                        "name": "associationid",
                        "value": associationId
                    });
                } 
                loadIdentifiersList(postData,"");
                
                $j23('.alphabet li').removeClass('active');
                        
		},
		/* focus: function(event, ui){
			$j23("#str_search").val(ui.item.value);
		}, */
        appendTo: '#search_box',
        //selectFirst: true,
		minLength: 0
        }).keyup(function (e) {
            
            if(e.which === 13 && $j23('#str_search').val().trim().length > 0 ) {               
                showLoadingOverlay();
                //$j23('.loader2').css('display','block');
                e.preventDefault(); 
                if($j23('.ui-autocomplete.ui-menu.ui-widget.ui-widget-content.ui-corner-all').is(":visible")){                    
                    $j23('.ui-autocomplete.ui-menu.ui-widget.ui-widget-content.ui-corner-all').hide();                   
                }               
                var alphabeticFilter = $j23('#alphabeticFilter').val();
                var searchfilter = $j23('#str_search').val();
                var int_start_row = $j23('#int_next_start_row').val();
                var sortColumn = $j23('#sortColumn').val();
                var sortType = $j23('#sortType').val();
                var associationId= $j23('input[name="associationid"]').val();
                var postData = $j23('body').data('formdata');
                var bit_push = 1;
                var bit_push_assnid = 1;
                $j23(postData).each(function(i){
                    if(postData[i]['name'] == "alphabeticFilter") {
                        //postData[i]['value'] = alphabeticFilter;
                        postData[i]['value'] = '';
                    } else if (postData[i]['name'] == "searchfilter") {
                        bit_push = 0;
                        postData[i]['value'] = searchfilter;
                    } else if (postData[i]['name'] == "sort_column") {
                        postData[i]['value'] = sortColumn;
                    } else if (postData[i]['name'] == "sort_type") {
                        postData[i]['value'] = sortType;
                    }else if (postData[i]['name'] == "int_start_row") {
                        postData[i]['value'] = 0;
                    }else if (postData[i]['name'] == "associationid") { 
                        postData[i]['value'] = associationId;
                        bit_push_assnid = 0;
                    }
                });
                if(bit_push == 1) {
                    postData.push({
                        "name": "searchfilter",
                        "value": searchfilter
                    });
                }
                if(bit_push_assnid == 1){
                    postData.push({
                        "name": "associationid",
                        "value": associationId
                    });
                }             
                
                loadIdentifiersList(postData,"");
                
                $j23('#str_search').blur();
                $j23('.alphabet li').removeClass('active');
            }  
            else if(e.which  == 13 && $j23('#str_search').val().trim().length == 0 ) {
                e.preventDefault();
                //$j23('.alphabet li').removeClass('active');   //commented on 04-12-2019
            }
            else if (e.which  == 8 && $j23('#str_search').val().trim().length == 0) {           // Added on 04-12-2019 
                if($j23('.ui-autocomplete.ui-menu.ui-widget.ui-widget-content.ui-corner-all').is(":visible")){                    
                     $j23('.ui-autocomplete.ui-menu.ui-widget.ui-widget-content.ui-corner-all').hide();                   
                }                
            }
        });
        // on  enter key press  
        /* $j23( "#str_search" ).keyup(function(e) {        //commented on 04-12-2019
            
        }); */
      });
    /* ------------------------ Search Suggestion End -------------------------------------*/

    /* -----------------Start : Add Association------------------------- */

    $j23("#Topic #addAssociation").live('click',function(e){
           	
        var addAssociationBtn=$j23(this);
        $j23('#addAssociation').attr('disabled',true);
        //showLoadingOverlay();
        //$j23(".loader2").css("display","block");
       
        if($j23(this).attr('id') == 'addAssociation')
        {   
            var returnvariable = validateItem(addAssociationBtn);            
            if (!returnvariable)
            {
                e.preventDefault();                
                return false;
            }           
        } 
            
    });     
    /* -----------------End : Add Association --------------------------*/

    $j23('input[name="enrolledVolunteers"]').live('change',function(){
        changeEnrolledVisible();
        renderOddEvenRows();
        var defaultDivHeight = $j23.trim($j23('#hdn_DivHeightCal').val());
        var tableHeight = $j23('#div_selectedTutorsTable').height();	
        var divHeight = $j23('#div_selectedTutors').height();			
        if(divHeight < defaultDivHeight ){
            $j23('#a_showHideLink').trigger('click');
        }
    });

    $j23('#a_showHideLink').live('click',function(){
        if($j23('tr.tutorsList.selected').length > 0){
            if($j23('#a_showHideLink').hasClass('show')){
                $j23('#a_showHideLink').removeClass('show').addClass('hide');
                $j23('tr.tutorsList').each(function(){
                    if(!$j23(this).hasClass('selected'))
                        $j23(this).addClass('hidden');
                });
            }else{
                $j23('#a_showHideLink').removeClass('hide').addClass('show');
                changeEnrolledVisible();
            }
            changeLinkText();
            adjustHeightVolunteerList();
            renderOddEvenRows();
        }
    });
    
    
    $j23('a.sortorder').live('click',function(){
        var $op = $j23('#updownlist option:selected');
        var $opreverse = $op.toArray().reverse();
        var $opnotsel = $j23('#updownlist option:not(:selected)');

        //--- ASSNS-78 ---//		
        var $op2 = $j23('#updownlist2 option:selected');
        var $opreverse2 = $op2.toArray().reverse();
        var $opnotsel2 = $j23('#updownlist2 option:not(:selected)');	
        $this = $j23(this);
        if($op.length){			        	        		    
            if($this.hasClass( "firstlast" )){	        	   
                ($this.attr('rel') == 'First') ? $opnotsel.first().before($op) : $opnotsel.last().after($op);  		          		            		
            }else{
                if ($this.attr('rel') == 'Up'){
                    $op.each(function(){
                        if($j23.trim($j23(this).prev().val()).length != 0){
                            if(!($j23(this).prev().is(':selected')))
                                $j23(this).prev().before($j23(this)) ;
                        }
                    });
                }else{
                    $j23($opreverse).each(function () {
                        if($j23.trim($j23(this).next().val()).length != 0){
                            if(!($j23(this).next().is(':selected')))
                                $j23(this).next().after($j23(this)) ;
                        }
                    });
                }
            }
        }
        //--- ASSNS-78 ---//
        if($op2.length){			        	        		    
            if($this.hasClass( "firstlast" )){	  	   
                ($this.attr('rel') == 'First') ? $opnotsel2.first().before($op2) : $opnotsel2.last().after($op2);  		          		            		
            }else{
                if ($this.attr('rel') == 'Up'){
                    $op2.each(function(){
                        if($j23.trim($j23(this).prev().val()).length != 0){
                            if(!($j23(this).prev().is(':selected')))
                                $j23(this).prev().before($j23(this)) ;
                        }
                    });
                }else{
                    $j23($opreverse2).each(function () {
                        if($j23.trim($j23(this).next().val()).length != 0){
                            if(!($j23(this).next().is(':selected')))
                                $j23(this).next().after($j23(this)) ;
                        }
                    });
                }
            }
        }
    });


    $j23('a.defaultinstructions').live("click",function(){
        attrid =  $j23(this).attr('id') ;
        defaultinstruction = $j23('#hiddendefaultinstruction').val();
        (attrid == 'defaultinstvolunteer') ? $j23('#instructionforvolunteer').val(defaultinstruction) : $j23('#instructionforstaff').val(defaultinstruction);	    		  
    });

    $j23('#uplink2').live("click",function(){
        cntr = $j23("#updownlist2 option").length;			
        if(cntr <5)
        {
           var x=document.getElementById("nonvisibleattr");
           var newattrvisible = $j23('#nonvisibleattr option:selected').length;				
           var totalattr = cntr + newattrvisible;				
           if (totalattr > 5) {
               alert("Visible Fields can have up to 5 fields.");					
           } else {
             var check=1;	
             getMultipleSelectedValue(x,check);
           }
        }
        else
        {
           $j23('#uplink2').attr("disabled",true);
           $j23(".visibleattrlimit").css("display","block");			  	 
        }
   });

   $j23('#downlink2').live("click",function(){
        var x=document.getElementById("updownlist2");
        var check=2;	
        getMultipleSelectedValue(x,check);
        cntr = $j23("#updownlist2 option").length;
        if(cntr < 5) {
        $j23('#uplink2').attr("disabled",false);
        $j23(".visibleattrlimit").css("display","none");
        }
    });

    $j23('.callFun').live('mouseover',function(){
        var cName = $j23(this).attr("class").split(" ")[1];
        $j23("tr."+cName).css('background-color', '#fffff3');
    });
    
    $j23('.callFun').live('mouseout',function(){
        var cName = $j23(this).attr("class").split(" ")[1];
        $j23("tr."+cName).css('background-color', 'transparent');
    });

    $j23('#sortattr').live("click",function(){				
        if($j23('#sortattr').is(":checked")){
          var seloptions = $j23('select#updownlist2 option');
            var arr = seloptions.map(function(_, o) {
                   return {
                      t: $j23(o).text(),
                      v: $j23(o).val()
                   };
                }).get();
            //console.log(arr);
            arr.sort(function(o1, o2) {
               return o1.t > o2.t ? 1 : o1.t < o2.t ? -1 : 0;
            });
            seloptions.each(function(i, o) {
               //console.log(i);
               o.value = arr[i].v;
               $j23(o).text(arr[i].t);
            });
        }
    });


    // Select all/None checkboxes
    $j23(".allidentcheckbox ,.identcheckbox").live("click",function(){
        showLoadingOverlay();
        var checkbxlen=0;
        var checkedItemsCountBasedOnId="";//MV-2058
        if($j23(this).hasClass("allidentcheckbox") && $j23(this).val()==0)
        {
            /* var identcheckbox = $j23('[id^=identcheckbox_]:visible').not(":disabled"); */
            var identcheckbox = $j23('.identcheckbox:visible').not(":disabled");
            identcheckbox.prop("checked",true);
            $j23(".adminlist").find('input[name="attr_val_chkbox"]:visible').prop("checked",true);//Staging Bugfix 544
            var checkbxlen=identcheckbox.length;
            //var checkedItemsCountBasedOnId=identcheckbox.length;
            /* Start :: MV-2058 */
            checkedItemsCountBasedOnId = countBasesdOnitemId();
            $j23(this).prop("checked",true).val(1);
            $j23("#selectact").text("Select Action... ("+checkedItemsCountBasedOnId+")");            
            $j23("#delete").text("Delete Selected ("+checkedItemsCountBasedOnId+")");
            $j23("#archive").text("Archive Selected ("+checkedItemsCountBasedOnId+")");
            $j23("#restore").text("Restore Selected ("+checkedItemsCountBasedOnId+")");
            /* End :: MV-2058 */
            
        }
        else if($j23(this).hasClass('identcheckbox'))
        {
        
            
            checkbxlen=$j23('.identcheckbox:visible:checked').length;
            /* Start :: MV-2058 */
            makeThisCheckedBasedOnID($j23(this));
            checkedItemsCountBasedOnId = countBasesdOnitemId();
            $j23("#selectact").text("Select Action... ("+checkedItemsCountBasedOnId+")");            
            $j23("#delete").text("Delete Selected ("+checkedItemsCountBasedOnId+")"); 
            $j23("#archive").text("Archive Selected ("+checkedItemsCountBasedOnId+")");
            $j23("#restore").text("Restore Selected ("+checkedItemsCountBasedOnId+")");
            $j23(".identcheckbox:visible").each(function () {
                var parentRowName= $j23(this).closest("tr").attr('name');
                if (typeof parentRowName !== "undefined") {
                parentRowName=parentRowName.replaceAll("'", "\\'");//MV-2187
                }
                var totalCheckboxes = $j23("tr[name='" + parentRowName + "']").find(".identcheckbox").length;
                var checkedCheckboxes = $j23("tr[name='" + parentRowName + "']").find(".identcheckbox:checked").length;
                if(checkedCheckboxes == totalCheckboxes){
                    $j23("input[class='"+parentRowName+"']").prop("checked",true);
                }else if(totalCheckboxes > checkedCheckboxes){
                    $j23("input[class='"+parentRowName+"']").prop("checked",false);
                }
            });
            /* End :: MV-2058 */
        }
        else
        {
            $j23('.identcheckbox').prop("checked",false);
            $j23(".adminlist").find('input[name="attr_val_chkbox"]').prop("checked",false);//Staging Bugfix 544
            $j23(".allidentcheckbox").prop("checked",false).val(0);
            $j23("#selectact").text("Select Action... (0)");
            $j23("#delete").text("Delete Selected (0)");
            $j23("#archive").text("Archive Selected (0)");
            $j23("#restore").text("Restore Selected (0)");
        }
        checkAssignmentDetails();
        hideLoadingOverlay();
        //BG-697
        checkAllCheckboxesOnIdentCB();
        cloneCheckBoxes(this);
        updateSelectActionCnt();
    });//eof allidentcheckbox

    /* Start :: MV-2058 */

    function isInArray(value, array) {
        return array.indexOf(value) > -1;
    }

    function countBasesdOnitemId(){
        var uniqueItemIds = [];

        $j23('.identcheckbox:visible:checked').each(function () {
            var item_Id = $j23(this).val();
            if (!isInArray(item_Id, uniqueItemIds)) {
            //if (!uniqueUserIds.includes(item_Id)) {
                uniqueItemIds.push(item_Id);
            }
        });
        var itemId_listCount = uniqueItemIds.length;
        //console.log("itemId_listCount",itemId_listCount);
        return itemId_listCount;
    }

    function makeThisCheckedBasedOnID(event){
        var getItemID= event.attr('id');
        if (event.is(':checked')) {
            $j23('input[id=' + getItemID+ ']').prop('checked', true);
        } else {
            $j23('input[id=' + getItemID+ ']' ).prop('checked',false);
        }

    }

    /* End :: MV-2058 */
    
    /* -------- Start : select delete/archive/restore action from dropdown --------- */
    $j23(".identstatusdropdown").live("change",function()
    {
        var chckbx="";
        var identifierSingularName = $j23('#identifier_singular_name').val();
        var identifierPluralName = $j23('#identifier_plural_alias').val();        
        var value = $j23(this).children(":selected").attr("id");//to get content of "value" attrid  
        
        // CPORT-54, Start, 12-05-2019        
        if(identifierSingularName == ''){
            identifierSingularName = "Identifier";
        }
        // CPORT-54, End, 12-05-2019

        if(value != 'selectact')
        {
            if(value == "delete")
            {
                    $j23('.showRemove:checked').each(function (i, el) {
                                chckbx= chckbx + "- "+$j23(".identcheckbox_"+el.value).text()+"\n";
                    });
                    var identifierCount = $j23('.showRemove:checked').length;                    
                    
                //Start : Code Added by dikendra 15june2018 for Delete(0) selected alert
                if(identifierCount == 0){
                    alert("Please select at least one "+identifierSingularName+" for this action."); // CPORT-54, 12-05-2019   
                    $j23('#sel_action').prop('selectedIndex',0);
                }
                else
                {
                    if(chckbx.length != 0)
                    {
                        if(identifierCount == 1){
                            var chkBoxStatusSingularName = confirm("Please confirm that you want to permanently delete the following "+ identifierSingularName +".\n\n You will not be able to undo your work.\n\n"+ chckbx);
                            if(chkBoxStatusSingularName != true)
                            {
                                $j23('#sel_action').prop('selectedIndex',0);//Code Added by dikendra 15june2018 reset select action dropwown
                            }
                            else{
                                getIdentStatuscount(value);
                            }
                        }else{
                            var chkBoxStatusPluralName = confirm("Please confirm that you want to permanently delete the following "+ identifierPluralName +". \n\n You will not be able to undo your work.\n\n"+ chckbx);
                            if(chkBoxStatusPluralName != true)
                            { 
                                $j23('#sel_action').prop('selectedIndex',0);//Code Added by dikendra 15june2018 reset select action dropwown
                            }
                            else{
                                getIdentStatuscount(value);
                            }
                        }
                    }
                }//Ends :Code Added by dikendra 15june2018			
            }
            else
            {
                getIdentStatuscount(value);
            }
        }
    });
    /* -------- End: select delete/archive/restore action from dropdown --------- */

   // optional Breakout
   $j23("input[name=breakOutRadio]").live("click",function(){		
       $j23(".breakOutRadioOptions").hide();
        if($j23(this).val() == "0"){
           $j23("input[name=breakOutRadio]").removeClass("breakoutshowhide");
           $j23(".breakOutRadioOptions").hide();
        }
        else if($j23(this).val() == "1"){
            
            if($j23(this).hasClass("breakoutshowhide"))
            {
               $j23(".breakOutRadioOptions").hide();
               $j23("input[name=breakOutRadio]").removeClass("breakoutshowhide");
            }
            else
            {
               $j23("input[name=breakOutRadio]").removeClass("breakoutshowhide");
               $j23(this).addClass("breakoutshowhide");
               $j23(".breakOutRadioOptions").hide();
               $j23("#breakOutRadioOptions-1").show();
            }
        }
        else if($j23(this).val() == "2"){
            if($j23(this).hasClass("breakoutshowhide"))
            {
               $j23(".breakOutRadioOptions").hide();
               $j23("input[name=breakOutRadio]").removeClass("breakoutshowhide");
            }
            else
            {	
               $j23("input[name=breakOutRadio]").removeClass("breakoutshowhide");
               $j23(this).addClass("breakoutshowhide");
               $j23(".breakOutRadioOptions").hide();
               $j23("#breakOutRadioOptions-2").show();
            }
        }
    });

   $j23(".chkbx_TargetedTutors").live('click',function(){

		var tgtClass =$j23(".chkbx_TargetedTutors").attr("class").split(" ")[1];
		var checked =$j23('.'+tgtClass+':checked:visible').length;		
		if(checked > 0){
			$j23("#a_showHideLinkNew").css({"pointer-events":"","cursor":"default","color":"blue"});
		}

	});

    $j23('#a_showHideLinkNew').live('click',function(){
        if($j23('tr.tutorsList.selected').length > 0){
            if($j23('#a_showHideLinkNew').hasClass('show')){
                $j23('#a_showHideLinkNew').removeClass('show').addClass('hide');
                $j23('tr.tutorsList').each(function(){
                    if(!$j23(this).hasClass('selected'))
                        $j23(this).addClass('hidden');
                });
            }else{
                $j23('#a_showHideLinkNew').removeClass('hide').addClass('show');
                changeEnrolledVisibleNew();
            }
            changeLinkTextNew();
            adjustHeightVolunteerListNew();
            renderOddEvenRowsNew();
        }
    });

    $j23('input[name="enrolledVolunteersNew"]').live('change',function(){
        changeEnrolledVisibleNew();
        renderOddEvenRowsNew();        
        var defaultDivHeight = $j23.trim($j23('#hdn_DivHeightCal').val());       
        var tableHeight = $j23('#div_selectedTutorsTable').height();	
        var divHeight = $j23('#div_selectedTutors').height();			
        adjustHeightVolunteerListNew();
        if(divHeight < defaultDivHeight ){
            $j23('#a_showHideLinkNew').trigger('click');
        }
    });

    $j23("#selectvolunteerid").live('click',function(){
		if($j23(this).hasClass("Select_All")){           
			$j23(this).removeClass("Select_All");
			$j23(this).addClass("Select_None");
			$j23(this).text("Select None");

			var tgtClass = $j23(".chkbx_TargetedTutors").attr("class").split(" ")[1];
			var classValue = $j23("input[name=enrolledVolunteersNew]:checked").attr("value");			
			
			if(tgtClass == "opt_1" && classValue == 1)
			{
				$j23(".opt_1").each(function(){
					if($j23(this).prop('disabled') == false && $j23(this).is(':visible'))
					{
						$j23(this).prop("checked",true);
						$j23(this).closest('tr').addClass("selected");
					}
					else
					{
						$j23(this).prop("checked",false);
						$j23(this).closest('tr').removeClass("selected");
					}
				});
			}
			else if(tgtClass == "opt_0" && classValue == 0)
			{
				$j23(".opt_0").each(function(){
					if($j23(this).prop('disabled') == false && $j23(this).is(':visible'))
					{
						$j23(this).prop("checked",true);
						$j23(this).closest('tr').addClass("selected");
					}
					else
					{
						$j23(this).prop("checked",false);
						$j23(this).closest('tr').removeClass("selected");
					}
				});
			}
				
		}
		else if($j23(this).hasClass("Select_None")){			
			$j23(this).removeClass("Select_None");
			$j23(this).addClass("Select_All");
			$j23(this).text("Select All");

			$j23(".chkbx_TargetedTutors:visible").prop("checked",false);
			$j23('.tutorsList:visible').removeClass("selected");
			if($j23('input.chkbx_TargetedTutors:visible:checked').length == 0 && $j23('#a_showHideLinkNew').hasClass('hide')){
				changeEnrolledVisibleNew();
				changeLinkTextNew();
				adjustHeightVolunteerListNew();
				renderOddEvenRowsNew();
				$j23('#a_showHideLinkNew').removeClass('hide').addClass('show');
			}
		}		
    });
    
	
	$j23("input[name=enrolledVolunteersNew]").live('click',function(){        
		var class_to_add_onchange = $j23("input[name=enrolledVolunteersNew]:checked").attr("value");
		if(class_to_add_onchange == 0){            
			$j23(".chkbx_TargetedTutors").removeClass("opt_1");
			$j23(".chkbx_TargetedTutors").addClass("opt_"+class_to_add_onchange);

			var checked = 0;

			$j23(".opt_0").each(function(){				
				if (!$j23(this).is(':checked')){
					checked++;
				}
			});
			
			if(checked == 0){
				$j23("#selectvolunteerid").removeClass("Select_All");
				$j23("#selectvolunteerid").addClass("Select_None");
				$j23("#selectvolunteerid").text("Select None");
			}
			else{
				$j23("#selectvolunteerid").removeClass("Select_None");
				$j23("#selectvolunteerid").addClass("Select_All");
				$j23("#selectvolunteerid").text("Select All");
			}

			$j23(".opt_0").each(function()
			{
				if(!$j23(this).attr("checked"))
				{
					$j23(this).closest('tr').removeClass("selected");
					
				} 
				if(!$j23(this).attr("checked") && $j23(this).closest('tr').hasClass("selected"))
				{
					//$j23(this).attr("checked","true"); //commented for Select All Sub Manager BugFix
				}
			});
		}
		if(class_to_add_onchange == 1){            
			$j23(".chkbx_TargetedTutors").removeClass("opt_0");
			$j23(".chkbx_TargetedTutors").addClass("opt_"+class_to_add_onchange);
		} 
		
    });
    
    $j23("input[class*='opt']").live('click',function(){
        targeted_class = $j23(this).attr('class').split(" ")[1];
        var checked = $j23('.'+targeted_class+':not(:checked):visible').length;
        
        if(checked == 0)
        {
            $j23("#selectvolunteerid").removeClass("Select_All");
            $j23("#selectvolunteerid").addClass("Select_None");
            $j23("#selectvolunteerid").text("Select None");
            
        }
        else
        {
            $j23("#selectvolunteerid").removeClass("Select_None");
            $j23("#selectvolunteerid").addClass("Select_All");
            $j23("#selectvolunteerid").text("Select All");
        }
            
    });
    
    $j23("input[name='assigncheckbox_0']").live('click',function(){
        
        var parentid=$j23(this).attr('id');
        
        $j23("."+parentid+":input[name='assignsubcheckbox']").each(function(){
            var divids = $j23(this).attr("value");
            if($j23("#assignsubcheckbox_"+divids).prop("checked") == true){
                
                $j23(".assignsubcheckbox_"+divids+"_div").slideUp();
            }
        });
    });

    $j23(".changeArrow").live('click',function(){
		var arrowid = $j23(this).attr('id');
		var arrowidmatch = arrowid.substring(0,arrowid.lastIndexOf("_"));
		arrowidmatch = arrowidmatch + "_div";
		
		var statusflag = $j23('#'+arrowid).hasClass('showarrow');
		
		if(statusflag == true)
		{
			var divid = arrowid.substring(0,arrowid.lastIndexOf("_"));
			$j23('#'+divid).attr("checked","checked");
			$j23('.columns').each(function() {
				var divname=$j23(this).attr("id");
				if($j23("."+divname+"_div").hasClass(arrowidmatch)){
					$j23("."+divname+"_div").slideDown(200);//Staging Bugfix 545
				}
				
			})

			$j23('#'+arrowid).removeClass('showarrow');
 			$j23('#'+arrowid).addClass('hidearrow');
		}
		else
		{	
			var chkboxchkcount=0;
			var divid = arrowid.substring(0,arrowid.lastIndexOf("_"));
			
			$j23('.columns').each(function() {
				var divname=$j23(this).attr("id");
				if($j23("."+divname+"_div").hasClass(arrowidmatch)){
					$j23("."+divname+"_div").slideUp(200);//Staging Bugfix 545
				}
			})

			$j23('#'+arrowid).addClass('showarrow');
 			$j23('#'+arrowid).removeClass('hidearrow');
			
			var fatchid=divid.split("_")[1];
			if($j23(".attrCheckBox_"+fatchid+":checked").length || $j23(".assigncheckbox_"+fatchid+":checked").length)
			{
				$j23('#'+divid).prop("checked",true);
			}
			else
			{
				$j23('#'+divid).prop("checked",false);
			}
		}
 		
    });
    
    $j23('a.selectAll').live('click',function(e){
        $j23('#updateTableView input[name="viewattributes"] , .viewattributes , .subcolumns').each(function() {
            $j23(this).prop('checked', true);	
        });
        
        $j23('.changeArrow').removeClass("showarrow");
        $j23('.changeArrow').addClass("hidearrow");
        $j23('.columns').each(function() {            
            var divname=$j23(this).attr("id");
            $j23("."+divname+"_div").slideDown();	
        });
        	
         $j23(".assignmentattrcontainer").slideDown();
        
        $j23("input[name='assignsubcheckbox']").each(function(){
            var divname=$j23(this).attr("id");
            $j23("."+divname+"_div").slideDown();	
        });

        toggleSelect();
        //e.preventDefault();
        //return false;
    });

    $j23('a.selectNone').live('click',function(e){
    
        $j23('#updateTableView input[name="viewattributes"], .viewattributes , .subcolumns').each(function() {
            $j23(this).prop('checked', false);
        });
        $j23('#updateTableView input[name="show_status"]').each(function() {
            $j23(this).prop('checked', false);
                                
        });
        
        $j23('.changeArrow').removeClass("hidearrow");
        $j23('.changeArrow').addClass("showarrow");
        $j23('.columns').each(function() {
            
            var divname=$j23(this).attr("id");
             $j23("."+divname+"_div").slideUp();	
        })
         $j23(".assignmentattrcontainer").slideUp();
    
         $j23('input[name=countAttr]').val('0');        
        
        $j23(".filterOptionsContainer").hide();
        
        toggleSelect();
        e.preventDefault();
        return false;
    });
    
    $j23('#updateTableView input[name="viewattributes"] ,.viewattributes').live('change',function(){
        toggleSelect();
    });

    $j23(".columns ,.checkpanel,.subcheck").live('change',function(){
        var divid1=$j23(this).attr("id"); 
        divid1=divid1.split("_");
    
        if(divid1.length <= 3)
        {
        divid2=divid1[0]+"_"+divid1[1];
        
        }
        
        if($j23("."+divid2+"_div").css('visibility') === 'hidden' && $j23(this).hasClass("subcolumns") )
                {
        
                    $j23("."+divid2+"_div").slideDown();
                    $j23("#"+divid2).addClass("show_"+divid1[1]+"_div");
                    $j23("#"+divid2).removeClass("subcolumns");
                    $j23("#"+divid2+"_arrow").removeClass("showarrow");
                    $j23("#"+divid2+"_arrow").addClass("hidearrow");
                }
        else if($j23("#"+divid2+"_arrow").hasClass("showarrow") )
        {
        
                            if($j23("."+divid2+"_div").is(":visible"))
                                {
                                        //	console.log("visible");
                                            
                                            $j23("."+divid2+"_div").slideUp();
                                            $j23("#"+divid2+"_arrow").addClass("showarrow");
                                            $j23("#"+divid2+"_arrow").removeClass("hidearrow");
                                            $j23("."+divid2+"_div").find('input:checkbox').prop("checked",false);
                                }
                            else
                            {
                                            //console.log($j23("."+divid2+"_div").is(":visible"));
                                            $j23("."+divid2+"_div").slideDown();
                            
                                            if($j23("#"+divid2).prop("checked")== true)
                                            {
                                                        $j23("."+divid2+"_div input:checkbox").each(function(){
                                                                                //$j23(this).prop("checked",true);// commented for ASSNS-286 SC
                                                                                //$j23("."+$j23(this).attr("id")+"_div").slideDown();
                                                    });
                                            }
                            
                                            $j23("#"+divid2+"_arrow").addClass("hidearrow");
                                            $j23("#"+divid2+"_arrow").removeClass("showarrow");
                            }
        
                                            $j23("#"+divid2).addClass("show_"+divid1[1]+"_div");
                                            $j23("#"+divid2).removeClass("subcolumns");
        }	
        else if($j23("#"+divid2).prop("checked")== true)
                {
            
                        
                        $j23("."+divid2+"_div").slideDown(200);//Staging Bugfix 545
                        
                        
                            $j23("."+divid2+"_div input:checkbox").each(function()
                            {
                                            //$j23(this).prop("checked",true);// commented for ASSNS-286 SC
                                            //$j23("."+$j23(this).attr("id")+"_div").slideDown();
                                });
                                
                        $j23("#"+divid2+"_arrow").addClass("hidearrow");
                        $j23("#"+divid2+"_arrow").removeClass("showarrow");
                        $j23("#"+divid2).addClass("show_"+divid1[1]+"_div");
                        $j23("#"+divid2).removeClass("subcolumns");
                    
                }	
        else
        {
                    
                $j23("."+divid2+"_div").slideUp(200);//Staging Bugfix 545
                $j23("#"+divid2+"_arrow").removeClass("hidearrow");
                $j23("#"+divid2+"_arrow").addClass("showarrow")
                $j23("#"+divid2).addClass("subcolumns");
                $j23("#"+divid2).removeClass("show_"+divid1[1]+"_div");
                
                $j23("."+divid2+"_div").find('input:checkbox').prop("checked",false);
                                
        }
    
    });

    // breakoutoption-2 Field Value
    $j23('#selectAttrValue').live('change',function(){
        var selectedOptVal = $j23(this).find(":selected").text();
        if(selectedOptVal == "None Selected"){
            $j23("#attr_val_container").hide(); 
        }
        else
        {
            $j23("#attr_val_container").show(); 
        }        
    });

   $j23('#selectAttrValue').live('change',function(){
		ajaxCallForView(this);
    });
    
    //Staging Bugfix 545 Start
	$j23('#optBreakOut').live('click', function() {
		$j23("#chkoptBreakOut").val("clicked");
		
		
		if($j23('#selectAttrValue option').length == 1)
		{
			$j23("#breakOutRadioOptions-1").hide("slow");
			$j23("input[name=breakOutRadio][value=1]").attr("disabled",true);
			$j23("#attrValufilter").css("display","block");
		}
		$j23(".breakOutRadioOptions").hide("slow");
		//$j23("#optBreakOutContainer").toggle("slow");//commented for staging issue bugfix 545
	});
    //Staging Bugfix 545 End
    
    // customized view
    $j23('#updateView').live('click', function() {
        var associationid = $j23('.associationid').val();
        $j23('#sortColumn').val('');
        $j23('#sortType').val('');
		//$j23('#alphabeticFilter').val('');
        $j23('#str_search').val('');
        if($j23('#search_clear_icon_new').is(':visible')){                  
            $j23('#search_clear_icon_new').hide();
            $j23('#search_icon_new').show();
        }
        /* --- BG-165: Start --- */
        var noSortAllowed1 = $j23('input[name="breakOutRadio"]:checked').val();
        if(noSortAllowed1 != 1 && noSortAllowed1 != 2){
            $j23('input[name="noSortBrkOut"]').val(0);
        }
        /* --- BG-165: End --- */

        showLoadingOverlay();		

        if ($j23('.activechecked').is(':checked') || $j23('.archivechecked').is(':checked')) {
            //showLoadingOverlay();
            //$j23(".loader2").css("display","block"); 
            $j23("#updateView").attr("disabled",true);           
            $j23('table.usermessage').html('');            
            var _this = $j23("#updateTableView");
            var saveenteredname = $j23("#saveenteredname").val();
            var searchfilter = $j23('#str_search').val();
            var int_start_row = 1;
            var alphabeticFilter = $j23('#alphabeticFilter').val();
            var sortColumn = $j23('#sortColumn').val();
            var sortType = $j23('#sortType').val();
            var postData = _this.serializeArray();
            //validation
			var frmData = _this.serializeArray();
			$j23('body').data('formdata',frmData);
			
            postData.push({
                "name": "associationid",
                "value": associationid
            });
            postData.push({
                "name": "alphabeticFilter",
                "value": alphabeticFilter
            });
            postData.push({
                "name": "searchfilter",
                "value": searchfilter
            });
            postData.push({
                "name": "int_start_row",
                "value": int_start_row
            });
            postData.push({
                "name": "sort_column",
                "value": sortColumn
            });
            postData.push({
                "name": "sort_type",
                "value": sortType
            });
			
            var status = false;
            if (saveenteredname && saveenteredname.trim().length) {
                //validate for similar name
                var mtchFnd = matchRegEx(saveenteredname, "^[a-z A-Z0-9]+$");
                if (mtchFnd == null) {
                    alert("Enter valid data into 'Save View AS' text field");
                    hideLoadingOverlay();
                    return false;                   
                }else{
                 
                    $j23.ajax({
                        url: "index.cfm?event=association.beneficiarySaveAView",
                        type: "post",
                        data: postData,
                        dataType: "json",
                        //async: false,
                        success: function(resp) {
                                                   
                            if (resp.data.status == "ok") {                          
                                
                                var content = '<tbody><tr class="stop"><td class="icon"></td><td>'+resp.data.msg+'</td></tr></tbody>';
                                $j23('table.usermessage').html(content);
                                
                                loadIdentifiersList(postData,'','loadUpdatedView');                         
                                $j23(".newAssocItemDiv").html('');	                               
    
                            } else {                            
                                
                                // var content = '<tbody><tr class="stop"><td class="icon"></td><td>'+resp.data.msg+'</td></tr></tbody>';
                                // $j23('table.usermessage').html(content);
                                alert(resp.data.msg);
                                hideLoadingOverlay();
                                //$j23(".loader2").css("display","none");
                                $j23(".newAssocItemDiv").html('');	                            
                                return false;
                            }
                        },
                        error: function() {
                            //if fails
                            alert('Oops...mistake on server');
                            hideLoadingOverlay();
                            return false;      
                        }
                    });
                    
                    $j23("#updateView").attr("disabled",false);  
                }                         
            } else {                
                loadIdentifiersList(postData,'','loadUpdatedView');											
                $j23(".newAssocItemDiv").html('');
                $j23("#updateView").attr("disabled",false);           
            }
        } else {
            alert('Please select one of the checkboxes in the "Show" section at the top of this table.');
            hideLoadingOverlay();
            return false;
        }
    });

    function matchRegEx(string, regexPattern) {
        return string.match(regexPattern);
    }
    // Delete saved view
   /*$j23("#deleteviewbtn").live('click', function() {
        if($j23("input:radio[name='savedview']").is(':checked'))
        {
            
            if($j23('#search_clear_icon_new').is(':visible')){                  
                $j23('#search_clear_icon_new').hide();
                $j23('#search_icon_new').show();
                $j23('#str_search').val('');
            }
            var savedviewid=$j23("input:radio[name='savedview']:checked").val();
            var enteredname =$j23(".savedview_"+savedviewid).text();  
            var associationId= $j23('input[name="associationid"]').val();
            var selectedview =  $j23("input:radio[name='savedview']:checked"); 
            var path = 'index.cfm?event=association.deleteSavedViewBeneficiary&associationid='+associationId;
            //var redirect_path = 'index.cfm?event=association.editassociation&associationid=#associationid#&statusAttrVal=1'; //For BG-34
          
            if(confirm('Are you sure you want to delete the saved view, "'+enteredname+'" ?'))
            {
                $j23(this).prop("disabled",true);
                $j23(".savedviewbtn").prop('disabled', true); 
                showLoadingOverlay(); //@
                $j23.ajax({
                        url: path,
                        type: "POST",
                        data:{savedviewid:savedviewid},
                        success:function(response){
                            response=$j23.parseJSON(response);                            
                            selectedview.parent().parent().remove();
                            hideLoadingOverlay();
                            var content = '<tbody><tr class=""><td class="iconupdated"></td><td>'+response+'</td></tr></tbody>';
                            $j23('table.usermessage').html(content);
                            $j23(".newAssocItemDiv").html('');
                        }
                        ,
                        error:function(){
                            $j23("#jWindow").dialog('close');
                            alert('Oops...mistake on server');
                            hideLoadingOverlay();
                            return false;
                        }
                });
            }
        }
        else
        {
         alert("Please select any one view ");
        }
    });*/

    //Staging Bugfix 544 Start
	var chkboxcounter = 0;
	$j23(".adminlist").find("input[name='attr_val_chkbox']").live('click', function(){
		if($j23(this).prop("checked"))
		{	
			var tgt_name = $j23(this).attr("class");
			$j23(".adminlist").find("tr[name='"+tgt_name+"'] input").prop("checked",true);
			//chkboxcounter = $j23('.identcheckbox:checked').length;
            var chkboxcounter = countBasesdOnitemId(); //MV-2058
            checkAllCheckboxesOnIdentCB();//BG-697
		}
		if(!$j23(this).prop("checked"))
		{	
			var tgt_name = $j23(this).attr("class");
			$j23(".adminlist").find("tr[name='"+tgt_name+"'] input").prop("checked",false);
            $j23("input." + tgt_name.split(' ').join('.')).prop("checked", false);//BG-697
			//chkboxcounter = $j23('.identcheckbox:checked').length;
            var chkboxcounter = countBasesdOnitemId(); //MV-2058
            uncheckAllCheckboxesOnIdentCB(".adminlist tr[name='" + tgt_name + "']");//BG-697
		}
        // Start :: MV-2058
        $j23("#selectact").text("Select Action... ("+chkboxcounter+")");
        $j23("#delete").text("Delete Selected ("+chkboxcounter+")"); 
        $j23("#archive").text("Archive Selected ("+chkboxcounter+")");
        $j23("#restore").text("Restore Selected ("+chkboxcounter+")");
        // End :: MV-2058
		checkAssignmentDetails();
        updateSelectActionCnt();
        syncAllParentCheckboxes();//BG-697
	});	
    //Staging Bugfix 544 End
    
    $j23(".adminlist").find("tr input").live('click', function(){
		var tgt_trobj = $j23(this).closest("tr");
		var tgt_name = $j23(tgt_trobj).attr("name");
		var tgt_inobj = $j23(".adminlist").find("tr[name='"+tgt_name+"'] input");
		var chk_len=0;
		var total=0;
		$j23(tgt_inobj).each(function(){
			if($j23(this).prop("checked"))
			{
				chk_len++;
			}
			total++;
		}); 
	
		if(chk_len == total)
		{
			$j23(".adminlist").find("input[class='"+tgt_name+"']").prop("checked",true);
		}
		if(chk_len == 0)
		{
			$j23(".adminlist").find("input[class='"+tgt_name+"']").prop("checked",false);
        }
    });

    checkIfDeleteAllShouldBeEnabled();

    /* ------------------BG-70, Start: page loading issue - 07-01-2020 --------------------------- */
    $j23('form#Topic, form#form_savedviews, form#updateTableView').bind("keyup keypress", function(e) {        
        var code = e.keyCode || e.which; 
        if (code  == 13) {               
            e.preventDefault();
            return false;
        }
    });

    $j23('form#enrollsettings_form').live("keyup keypress", function(e) {        
        var code = e.keyCode || e.which; 
        if (code  == 13) {               
            e.preventDefault();
            return false;
        }
    });

    /* ------------------BG-70, End: page loading issue - 07-01-2020 --------------------------- */

    /* ------------------------ ASSNS-168 , Start ------------------------------------ */
		//--- to show checkbox ---/
			$j23("input[name=identifierenrolltype]").live('change',function(){
				if ($j23(this).val()==3){
				    $j23(".allowenroll").show();
				}else{
                    $j23(".allowenroll").hide();
                    document.getElementById("allowenroll").checked = false;
                    $j23("input[name=allowenroll]").val(0);
				}
			});
        
            //--- to change checkbox value ----// 
            $j23("input[name=allowenroll]").live('change',function(){
                if ($j23(this).prop("checked")){
                    $j23("input[name=allowenroll]").val(1);
                }else{
                    $j23("input[name=allowenroll]").val(0);
                }
            });
	
    /* -------------------- ASSNS-168 , End ------------------------------------------ */
    
    /* -------------------- ASSNS-527 :not(.donotcharCount) --------------------------- */

    $j23('#AssociationItemSettings input[type="text"]:not(.donotcharCount)[name!="itemvalue"],#AssociationItemSettings textarea[name!="itemvalue"]').live({
        keyup : function(){
            console.log($j23(this).attr('id'));
            CountLeft(document.getElementById($j23(this).attr('id')),$j23(this).attr('rel'));
        },
        keydown : function(){
            console.log($j23(this).attr('id') );
            CountLeft(document.getElementById($j23(this).attr('id')),$j23(this).attr('rel'));
        },
        blur : function()
        {
            CountLeft(document.getElementById($j23(this).attr('id')),$j23(this).attr('rel'));
        }
    });

    $jdialog.identifier_EnrollmentDialog = $j23('<div></div>').dialog(dialogSettings(''+identi_als+' Enrollment Settings', 'EnrollmentSettings', 540, 524, 395, 395)); //MV-1389
});
//DS::MV-1389::Start
$j23('#identifierFieldEdit').live('click', function(e) {
    //console.log(root);
    //alert("dd");
    var root = $j23('input[name="rootURL"]').val();
    $jdialog.identifier_EnrollmentDialog.dialog('open').html($jloadingImageTable).load(root + 'association.identifierenrollment_window&associationid='+associationid).dialog({ position: {my: "center bottom", at: "center center", of: window}});
});
//MV-1389::End
function changeEnrolledVisible(){
    if($j23('input[name="enrolledVolunteers"]:checked').val() == 0){
        $j23('tr.tutorsList.hidden').each(function(){
            $j23(this).removeClass('hidden');
        });
    }else{
        $j23('tr.tutorsList.notenrolled').each(function(){
            $j23(this).removeClass('hidden').addClass('hidden');
           // $j23(this).find('input[type="checkbox"]').prop('checked','');
        });
        $j23('tr.tutorsList.enrolled').each(function(){
            $j23(this).removeClass('hidden');
        });
    }
}

function renderOddEvenRows(){
    var counter = 1;
    $j23('tr.tutorsList').each(function(){
        if(! $j23(this).hasClass('hidden')){
            if(( counter % 2 ) == 1 )
                $j23(this).removeClass('oddrow evenrow').addClass('oddrow');
            else
                $j23(this).removeClass('oddrow evenrow').addClass('evenrow');
            counter++;
        }
    });
}

function adjustHeightVolunteerList(){
    var defaultDivHeight = $j23.trim($j23('#hdn_DivHeightCal').val());
    var tableHeight = $j23('#div_selectedTutorsTable').height();	
    var divHeight = $j23('#div_selectedTutors').height();
    if( tableHeight <= divHeight ){
        $j23('#div_selectedTutors').height(tableHeight + 'px')
    }else{
        $j23('#div_selectedTutors').height(defaultDivHeight + 'px')
    }
}

function changeLinkText(){
    var newText = $j23('#a_showHideLink').attr('rel');
    var newRel = $j23('#a_showHideLink').text();
    $j23('#a_showHideLink').attr('rel',newRel).text(newText);
    /* ASSNS-657 */
    var ua = window.navigator.userAgent;
    if (ua.indexOf('MSIE ') > 0 || ua.indexOf('Trident/') > 0) {
        $j23('#a_showHideLink').show();
    }/* ASSNS-657::END */
}

function changeRowClass(obj){ 
    if($j23(obj).prop('checked')){
        $j23(obj).parent().parent().addClass('selected');
    }else{
        $j23(obj).parent().parent().removeClass('selected');
    }

    if($j23('input.chkbx_TargetedTutors:visible:checked').length == 0 && $j23('#a_showHideLink').hasClass('hide')){
        changeEnrolledVisible();
        changeLinkText();
        adjustHeightVolunteerList();
        renderOddEvenRows();
        $j23('#a_showHideLink').removeClass('hide').addClass('show');
    }
}

function isEmail(email) {    
    //var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return emailregex.test(email); /* MS-400 */
}

/* BG-564 */
function validateEncryptedTextField (val){

	var specialChars = "~`^";
	  for(i = 0; i < specialChars.length;i++){
		  if(val.indexOf(specialChars[i]) > -1){
			  return true
		  }
	  }
	  return false;
  };
/* BG-564 */
function isValidMobileNumber(field,mobile) {
    /*
    mobilelength = mobile.length;
    if(mobilelength != 12){
        return false;
    }
    return true;
	*/
	
	var fval = jQuery(field).val().replace(/-/g, "");
	var id = jQuery(field).attr('id').split("_");
	
	if((fval).length == 10 && isNaN(fval)==false){			
		showLoadingOverlay();
		jQuery.ajax({
			type: "post",
			data: {phoneNumber:fval},
			url: "index.cfm?event=user.vaildateMobileNumberBySlooce",			
			success: function(data) { 
				data = JSON.parse(data);
				hideLoadingOverlay();				
				if(data == true){
					jQuery('#receivetexts_'+id[1]).prop('disabled', false);
					jQuery("#checkedRecieveText_"+id[1]).prop('disabled', false);
					return true;
				}else{
					return false;
				}
			}
		});
		
		if(jQuery('#receivetexts_'+id[1]).val() == 1){
			jQuery("#checkedRecieveDiv_"+id[1]).show();
		}else {
			jQuery("#checkedRecieveDiv_"+id[1]).hide();
		}
	}else{
		jQuery("#receivetexts_"+id[1]).prop('disabled', true);
		jQuery("#checkedRecieveText_"+id[1]).prop('disabled', true);
		jQuery("#checkedRecieveDiv_"+id[1]).hide();
		return false;
	}
}

function isNumberKey(evt)
{
    const key = event.keyCode;
    return ((key >= 48 && key <= 57) || (key >= 96 && key <= 105 || (event.shiftKey === true || key === 35 || key === 36) || (key === 8 || key === 9 || key === 13 || key === 46) || (key > 36 && key < 41) || 
        ((event.ctrlKey === true || event.metaKey === true) &&(key === 65 || key === 67 || key === 86 || key === 88 || key === 90))) 
    );
}
const isModifierKey = function(event){
    const key = event.keyCode;
    return (event.shiftKey === true || key === 35 || key === 36) || // Allow Shift, Home, End
        (key === 8 || key === 9 || key === 13 || key === 46) || // Allow Backspace, Tab, Enter, Delete
        (key > 36 && key < 41) || // Allow left, up, right, down
        (
            // Allow Ctrl/Command + A,C,V,X,Z
            (event.ctrlKey === true || event.metaKey === true) &&
            (key === 65 || key === 67 || key === 86 || key === 88 || key === 90)
        )
}

function FormatPhoneNumBG(obj, e, mobfname)
{	
        var event=e;//BG-703
        if(isModifierKey(event)) {return;}
        var cursorStart = e.target.selectionStart;
        var cursorEnd = e.target.selectionEnd;
        var charCode = (e.which) ? e.which : event.keyCode       
            if (charCode !=8 && charCode !=46 && charCode !=37 && charCode !=39 ){
        input = obj.value;
        input = input.replace(/-/g,'');       
        var size = input.length;
        if(size == 4 || size == 7){ cursorEnd++; cursorStart++; }
        if(size == 0 || size < 4){
                input = input;
        }else if(size < 7){
                input = input.substring(0,3)+'-'+input.substring(3,6);                
        }else{
                input = input.substring(0,3)+'-'+input.substring(3,6)+'-'+input.substring(6,10);
        }
        obj.value = input;  
        e.target.setSelectionRange(cursorStart, cursorEnd);
        } 
        input = obj.value;
        input = input.replace(/-/g,''); 
        var pattern = /^\d+$/;
        if(!input.match(pattern)){obj.value='';}else{checkMobileNumber(obj,mobfname);}
}

function checkMobileNumber(field,mobfname)
	{
		var fval = (field.value).replace(/-/g, "");
		var id = field.name.split("_");
		jQuery("#checkedRecieveText_"+id[1]).prop('checked', false);
		if((fval).length == 10 && isNaN(fval)==false)
		{
			
			showLoadingOverlay();
			 jQuery.ajax({
				type: "post",
				data: {phoneNumber:fval},
				url: "index.cfm?event=user.vaildateMobileNumberBySlooce",			
				success: function(data) { 
					data = JSON.parse(data);
					hideLoadingOverlay();				
					if(data == true)
					{
						jQuery('#receivetexts_'+id[1]).prop('disabled', false);
						jQuery("#checkedRecieveText_"+id[1]).prop('disabled', false);
					}
					else
					{
						var eMsg = data.replace("FieldName", mobfname);
						alert(eMsg);
					}
				}
			  });
		
			if(jQuery('#receivetexts_'+id[1]).val() == 1)
			{
				jQuery("#checkedRecieveDiv_"+id[1]).show();
			}
			else 
			{
				jQuery("#checkedRecieveDiv_"+id[1]).hide();
			}
		}
		else
		{
			jQuery("#receivetexts_"+id[1]).prop('disabled', true);
			jQuery("#checkedRecieveText_"+id[1]).prop('disabled', true);
			jQuery("#checkedRecieveDiv_"+id[1]).hide();
		}
	}

function isValidDate2(input) {
    var regexes = [
      /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/,
      /^(\d{1,2})\-(\d{1,2})\-(\d{4})$/
    ];

    for (var i = 0; i < regexes.length; i++)
    {
        var r = regexes[i];
        if(!r.test(input)) {
            continue;
        }
        var a = input.match(r), d = new Date(a[3],a[1] - 1,a[2]);
        if(d.getFullYear() != a[3] || d.getMonth() + 1 != a[1] || d.getDate() != a[2]) {
            continue;
        }
        // All checks passed:
        return true;
    }

    return false;
}

function closeWindow()
{
    $j23("#jWindow").dialog('close');
    $j23("#jWindowIdentifierSetting").dialog('close');      
    $j23("#identifiersettingsenroll").prop('checked', false);
}
function closeWindow1()//MV-1389
    {
        $jdialog.identifier_EnrollmentDialog.dialog('close');
	}
function ResetActions()
{
    if($j23('#addAssociation').prop('disabled') == true){
        $j23('#addAssociation').prop('disabled',false);
    }

    var resetActionDropdown = $j23('#sel_action').val();
    if(resetActionDropdown != 0)
    {
        selectActionReset();
    }
}

function validateItem(addAssociationBtn)
{
    var isValid = true;	
    var namepattern = /^[a-z\d\_(),\*-_.'&\s]+$/i;//SURVEYCOMP-169 : ~ Removed
    var pattern2 =  /^\d+$/;
    var newItem = $j23.trim($j23('#newAssocItem').val());
    newItem = newItem.replaceAll(/\s+/g, ' ');//MV-2043
    // CPORT-54, Start, 12-05-2019
    var identifierSingularAlias = $j23('#identifier_singular_name').val();
    if(identifierSingularAlias == ''){
       identifierSingularAlias = "Identifier";
    }
    // CPORT-54, End, 12-05-2019

    if(newItem=='')
    {        
        alert('Please enter a name for this '+ identifierSingularAlias + '.');  // CPORT-54, 12-05-2019
        $j23('#addAssociation').attr('disabled',false);
        hideLoadingOverlay();
        //$j23(".loader2").css("display","none");
        isValid = false;
        return false;
    }
    else if(!newItem.match(namepattern))
    {        
        alert('Please enter a valid name for this '+identifierSingularAlias+'.\n\nThe following characters are allowed: letters, numbers, spaces, parentheses, commas, hyphens, underscores, ampersands, apostrophe and periods.');     // CPORT-54, 12-05-2019
        $j23('#addAssociation').attr('disabled',false);
        hideLoadingOverlay();
        //$j23(".loader2").css("display","none");
        isValid = false;
        return false;
    }
    else
    {
        
        var assnId = $j23('input[name="associationid"]').val();
        var path = "index.cfm?event=association.checkduplicateidentifierforlistingpage";        
        
        $j23.ajax({
            url: path,
            type: "POST",
            data: {
                newItem: newItem,
                associationid: assnId, 
            },
            datatype:"json",
            //async: false,
            beforeSend: function() {                
                showLoadingOverlay();
                //$j23(".loader2").css("display","none");
            },
            success:function(response){
                    obj = $j23.parseJSON(response);                
                    if(obj.ITEMAVAILABLE == 1){
                        isValid = false;                    
                        alert('An '+identifierSingularAlias+' with the same name already exists in this Association. Please enter a unique name or close this window and edit the existing '+identifierSingularAlias+'.');      // CPORT-54, 12-05-2019
                        hideLoadingOverlay();
                        //$j23(".loader2").css("display","none");
                        $j23('#addAssociation').attr('disabled',false);
                        return false;
                    }
					else if(obj.IDENTIFIERPENDINGAPPROVAL == 1){
						
						isValid = false;
							//	alert('An'+identifierSingularAlias+' of this name is currently awaiting review on the Screen Submissions page.  Please review that submission.');      // 
							/*START : BG-246*/
							if(obj.ENROLLSTATUS == 0){
								 alert('An '+identifierSingularAlias+' of this name is currently awaiting review on the Screen Submissions page. Please review that submission.');      // 
							}else if(obj.ENROLLSTATUS == 1){
								 if(obj.ENROLLPERMISSION == 2){
									 alert(obj.VOLUNTEERALIAS +' '+ obj.FIRSTNAME +' '+ obj.LASTNAME + ' has already started to enroll this '+ (obj.IDENTIFIERALIAS).toLowerCase() +', but has not yet clicked the Submit For Review button. Please ask '+ obj.FIRSTNAME +' to either click Submit For Review or Cancel.');  
								 }else{
									 alert(obj.VOLUNTEERALIAS +' '+ obj.FIRSTNAME +' '+ obj.LASTNAME + ' has already started to enroll this '+ (obj.IDENTIFIERALIAS).toLowerCase() +', but has not yet clicked the Enroll button. Please ask '+ obj.FIRSTNAME +' to either click Enroll or Cancel.');
								 }
							}
							/*STOP :BG-246*/
							hideLoadingOverlay();
                        $j23('#addAssociation').attr('disabled',false);
                        return false;
						}
                    else {
						
                        //hideLoadingOverlay();
                        //$j23(".loader2").css("display","none");
                        openAttributePresentPopupWindow(addAssociationBtn);
                        return true;
                    }
                                   
            },
            error:function(){ 
                alert('Oops...mistake on server');
                hideLoadingOverlay();
                return false;                
            }
        }); 
    }
    
    //return isValid;
}


function openAttributePresentPopupWindow(addAssociationBtn)
{ 
        //e.preventDefault();
        var path = "index.cfm?event=association.checkIfAttributeRequireBeneficiary";
        var associationid =$j23('input[name="associationid"]').val();
        $j23.ajax({
                url: path,
                type: "POST",
                datatype:"json",
                data : {associationid:associationid},
                async : false,
                beforeSend: function() {                    
                    //showLoadingOverlay();
                },
                success:function(data){
                    
                    if(data==1)
                    {        
                        if(typeof openIdentifierSettingPopupWindow != 'undefined')
                        {                            
                            //hideLoadingOverlay();
                            openIdentifierSettingPopupWindow(addAssociationBtn);                            
                        }                        
                    }
                    else
                    {                        
                        addNewIdentifier();
                    }
                },
                error:function(xhr, status, error){
                    $j23("#jWindow").dialog('close');
                    alert('Oops...mistake on server');
                    hideLoadingOverlay();
                    return false;
                }
        });
}

function addNewIdentifier()
{
    var associationid =$j23('input[name="associationid"]').val();
    var newItem = $j23.trim($j23('#newAssocItem').val());
    newItem = newItem.replaceAll(/\s+/g, ' ');//MV-2043
    var newUsrMsg = '';
    
    var alphabeticFilter = $j23('#alphabeticFilter').val();
    var searchfilter = $j23('#str_search').val();
    var int_start_row = $j23('#int_next_start_row').val();
    var sortColumn = $j23('#sortColumn').val();
    var sortType = $j23('#sortType').val();
    var bit_push_assnid = 1;/* --- CF18-77 --- */

    var postData = $j23('body').data('formdata');    
    $j23(postData).each(function(i){
        if(postData[i]['name'] == "alphabeticFilter") {
            postData[i]['value'] = alphabeticFilter;
        } else if (postData[i]['name'] == "searchfilter") {            
            postData[i]['value'] = searchfilter;
        } else if (postData[i]['name'] == "sort_column") {
            postData[i]['value'] = sortColumn;
        } else if (postData[i]['name'] == "sort_type") {
            postData[i]['value'] = sortType;
        }else if (postData[i]['name'] == "int_start_row") {
            postData[i]['value'] = 1;
        }
            /* --- CF18-77 : Start --- */
        else if (postData[i]['name'] == "associationid") { 
            postData[i]['value'] = associationid; 
            bit_push_assnid = 0; 
        } 
           /* --- CF18-77 : End --- */
    });

    /* --- CF18-77 : Start --- */
    if(bit_push_assnid == 1){
        postData.push({
            "name": "associationid",
            "value": associationid
        });
    }
    /* --- CF18-77 : End --- */

    $j23.ajax({
        type: "POST",
        url: "index.cfm?event=association.addNewIdentifier",       
        data: {
            newItem: newItem,
            associationid: associationid, 
        },
        dataType: "json",
        //async: false,
        beforeSend: function() {
            //showLoadingOverlay();
        },
        success: function(data) {           
            $j23('#newAssocItem').val('');                       
            $j23('#addAssociation').attr('disabled',false);
            
            var classAdded = 'stop';
            var newInsertedIdentifierID = data.id;
                                  
            var UserMsg = data.status;  // added on 12-06-2019
            var path = 'index.cfm?event=association.setValuesonSessionForBeneficiary';
            $j23.ajax({
                url: path,
                type: "post",
                data: {
                    classAdded : classAdded,
                    newMsg : UserMsg,
                    insertedId : newInsertedIdentifierID,
                    insertedItem : newItem,
                    flagVal :1
                },
                async: false,
                success:function(){
                    newUsrMsg = data.msg;
                    setUserMessageFields(classAdded,UserMsg,newInsertedIdentifierID,newItem);
                } 

            });
            setUserMessage();
            loadIdentifiersList(postData,"");
        },
        complete: function() {          
                             
        },
        error: function(err) {
           // status = false;
            alert("error: "+err);
            hideLoadingOverlay();
        }
    });
}
//BG-697
function loadIdentifiersList(data,loadFlag,updatedView)
{
    var status = false;
    var _current_time_cache = new Date().getTime();
       
   /*tf = true ;
    if (all_iden_arrList.length == 0 ){
        tf = false;
    } */
    
    $j23.ajax({
        type: "POST",
        url: "index.cfm?event=association.identifierlistingsection&currenttimestamp="+_current_time_cache,       
        data: data,
        dataType: "json",
        //async: tf,
        beforeSend: function() {
            //showLoadingOverlay();
        },
        success: function(identifiers) {
                        
            var pageData = identifiers.paginationData;            
            prepareHeaderViewSection(identifiers.alphabeticfilterdata.data); 
			//BG-697
            prepareviewSection(identifiers.data, identifiers.headers, identifiers.paginationData, identifiers.archieveSiteList,updatedView); // BG-577
            
            if (pageData.alphabeticfilter) {                
                $j23('.alphabet li a#' + pageData.alphabeticfilter).parent().addClass('active');
            } else {                
                $j23('#alpha_all').addClass('active');
            }
            
            status = true;
            //setIdentifiersList(identifiers.data);            
            setIdentifiersList(pageData.identifierNames);
            hideLoadingOverlay(); 
            $j23('#str_search').autocomplete("option", { source: all_iden_arrList});                      
        },
        complete: function() {
			//BG-697
            if(updatedView == 'loadUpdatedView'){
            var currentPage_id_list = Array.from(document.querySelectorAll('.identcheckbox:not(#selectedIdentifiersCheckbox .identcheckbox)')).map(checkbox => checkbox.id);
            
            $j23('#selectedIdentifiersCheckbox td').each(function() {
                var checkboxInTd = $j23(this).find('input[type="checkbox"]');
                var checkboxId = checkboxInTd.attr('id');
            
                if (!currentPage_id_list.includes(checkboxId)) {
                    $j23(this).remove();
                }
            });
        }                           
        syncCheckboxes();
        updateSelectActionCnt();  
		$j23(".hrWidth").width($j23(".adminlist").width()+49); // BG-update UI Fix
        checkIfDeleteAllShouldBeEnabled();  // added 21/10/2019
        syncAllParentCheckboxes();//BG-697
        },
        error: function() {
            status = false;
            alert("error");
            hideLoadingOverlay();
        }
    });
    return status;
}
//BG-697
function syncCheckboxes() {
    // Get all the IDs of checkboxes in the selectedIdentifiersCheckbox
    var selectedIds = [];
    $j23('#selectedIdentifiersCheckbox').find('.check_identifierid_list:checked').each(function() {
      selectedIds.push($j23(this).attr('id'));
    });
    // Check all corresponding checkboxes in the main content
    $j23.each(selectedIds, function(index, id) {
      $j23('input[type="checkbox"][id="'+id+'"]').attr('checked', true).trigger('change');
    });
  }
//BG-697
function prepareviewSection(data, headers, pageData, archievesitelist,updatedView='noUpdate') { // BG-577
    var curr_associationid = $j23('input[name="associationid"]').val();
    var reportSection = $j23('#idnListSection');
    var paginationSection = $j23('.viewSectionPagination');
    
    var assocTitle = $j23('input[name="associationTitle"]').val();
    var identifier_plural_alias = $j23('input[name="identifier_plural_alias"]').val();
    reportSection.html('');

    var $str_viewSectionHeader = '<table cellspacing="0" class="adminlist ajax_assoc3_result_tbl verticalTop listtbl" id="idnListingSectionTable"><tbody><tr style="background:#3366CC;">';
    var $str_viewSection = '';
    var $str_pageSection = '';
    
    

    if (pageData.prev_link === "") {
        $str_pageSection = $str_pageSection + '<div class="right-align">';
		// Should be visible when Identifiers >50 		
		$str_pageSection = $str_pageSection + '&lt; Previous Page';		
    } else {
        $str_pageSection = $str_pageSection + '<div class="right-align"><a id="report_list_previous" title="Previous Page" href="' + pageData.prev_link + '">&lt; Previous Page</a>';
    }

    if (pageData.next_link === "") {
		// Should be visible when Volun >50		
		$str_pageSection = $str_pageSection + ' | Next Page &gt;';		
        $str_pageSection = $str_pageSection + '</div>';
    } else {
        $str_pageSection = $str_pageSection + ' | <a id="report_list_next" title="Next Page" href="' + pageData.next_link + '">Next Page &gt;</a></div>';
    }
    
    $str_pageSection = $str_pageSection + '<input type="hidden" name="int_prev_start_row" id="int_prev_start_row" value="' + pageData.int_prev_start_row + '"><input type="hidden" name="int_next_start_row" id="int_next_start_row" value="' + pageData.int_next_start_row + '"><input type="hidden" name="sortColumn" id="sortColumn" value="' + pageData.sortColumn + '"><input type="hidden" name="sortType" id="sortType" value="' + pageData.sortType + '">'
    paginationSection.html($str_pageSection);

    /*-----Start: dynamic dropdown code 18/10/2019------*/
    var disable_sel_action = false;
    var disable_allidentcheckbox = false;
    var disable_actionLinks = false;
    var isdisabled = '';
    var deleteidentcount = pageData.deleteidentcount;
    var restoreidentcount = pageData.restoreidentcount;
    var archiveidentcount = pageData.archiveidentcount;

    /* Start : Fix D/A/R count, added on 12-08-2019 */
    var archiveidentifierslist = pageData.archiveidentifierslist;
    var deleteidentifierslist = pageData.deleteidentifierslist;
    var restoreidentifierslist = pageData.restoreidentifierslist;
    $j23("#archiveidentifierslist").val(archiveidentifierslist);
    $j23("#deleteidentifierslist").val(deleteidentifierslist);
    $j23("#restoreidentifierslist").val(restoreidentifierslist);
    /* Start : Fix D/A/R count, added on 12-08-2019 */

    //console.log(deleteidentcount+","+restoreidentcount+","+archiveidentcount);    
    //var type3Permission = $j23('input[name="type3Permission"]').val();
    var type3Permission = pageData.type3Permission;
    var isTimesheetAssociation = $j23('input[name="isTimesheetAssociation"]').val();
    var isViewArchiveAllIdentifier = $j23('#ViewArchiveAllIdentifier').val();

    if(type3Permission == "ViewOnly" || type3Permission == "ViewAndCreateAssociation" || type3Permission == "ViewAndDeleteAssociation" || type3Permission == "ViewOrModifyAssociation"){
        disable_sel_action = true;
        disable_allidentcheckbox = true;
        disable_actionLinks = true;
    }

    if(disable_sel_action == true){ isdisabled = 'disabled="disabled"'}
    
    var myActionDropdown = '';
//BG-697
    if(updatedView!='updatedView' || updatedView!=='loadUpdatedView'){
        $j23('#sel_action').empty();

        // Start : Added on 12-02-2019 for diabled dropdown based on permissions
        if(disable_sel_action == true){
            $j23('#sel_action').prop("disabled", true);
        }else{
            $j23('#sel_action').prop("disabled", false);
        }
        // End : Added on 12-02-2019 for diabled dropdown based on permissions
        
        myActionDropdown = myActionDropdown + '<option value="0" id="selectact">Select Action... (0)</option>';
        if(deleteidentcount > 0){
            myActionDropdown = myActionDropdown + '<option value="1" id="delete"  >Delete Selected (0)</option>';
            if(isViewArchiveAllIdentifier == 1) {
                myActionDropdown = myActionDropdown + '<option value="2" id="deleteall"  >Delete All ('+deleteidentcount+')</option>';
            }
        }

        if(archiveidentcount > 0){
            if(deleteidentcount > 0){
                myActionDropdown = myActionDropdown + '<optgroup class="deleteSeparator" label="------">------</optgroup>';  
            }
            myActionDropdown = myActionDropdown + '<option value="3" id="archive" >Archive Selected (0)</option>';
            if(isViewArchiveAllIdentifier == 1) {
                myActionDropdown = myActionDropdown + '<option value="4" id="archiveall">Archive All ('+archiveidentcount+')</option>';
            }
        }
        
        if(restoreidentcount > 0){
            myActionDropdown = myActionDropdown + '<optgroup label="------">------</optgroup>';
            myActionDropdown = myActionDropdown + '<option value="5" id="restore" >Restore Selected (0)</option>';
            myActionDropdown = myActionDropdown + '<option value="6" id="restoreall">Restore All Archived ('+restoreidentcount+')</option>';
        }
                

        $j23('#sel_action').append(myActionDropdown); 
    }
    /*-----End: dynamic dropdown code 18/10/2019------*/


    /* if (headers.length === 1) {
        $str_viewSectionHeader = $str_viewSectionHeader + '<th class="headers" style="width:180px;"><div style="float:left; width:245px;"><input type="text" name="association_title"  class="association_title" id="association_title" value="'+assocTitle+'" size="40" maxlength="100" style="width:184px;" /> <a name="association_title_update" id="association_title_update" style="color:#FFFFFF !important">Update</a></div></th><th class="headers">Edit</th>';
    } else { */

        $str_viewSectionHeader = $str_viewSectionHeader + '<th class="assnsUpdate" style="width:180px;"><div style="float:left; width:245px;">';
        
        // Start : Added on 12-02-2019 for diabled dropdown based on permissions
        if( type3Permission == "ViewOnly" || type3Permission == "ViewAndDeleteAssociation" || type3Permission == "ViewOrModifyIdentifier" || type3Permission == "ViewOrDeleteAssociationModifyIdentifier"){
            $str_viewSectionHeader = $str_viewSectionHeader + '<input type="text" name="association_title"  class="association_title" id="association_title" value="'+assocTitle+'" size="40" maxlength="100" style="width:184px;" disabled="disabled" />';
        }else{
            $str_viewSectionHeader = $str_viewSectionHeader + '<input type="text" name="association_title"  class="association_title" id="association_title" value="'+assocTitle+'" size="40" maxlength="100" style="width:184px;" />';
            
            if(isTimesheetAssociation == 0){
                $str_viewSectionHeader = $str_viewSectionHeader + ' <a name="association_title_update" id="association_title_update" style="color:#FFFFFF !important">Update</a>';
            }
        }
        // End : Added on 12-02-2019 for diabled dropdown based on permissions

        $str_viewSectionHeader = $str_viewSectionHeader + '</div></th>';
        
            
        
        $j23.each(headers, function(index, header) {
            if (header.name != 'identifier_id' && header.name != 'identifier_name') {

                if(header.name == 'assignedassociation'){
                    $str_viewSectionHeader = $str_viewSectionHeader + '<th class="me" style="min-width:150px;text-align:left">' + header.displayName + '</th>';
                }else{
                
                    if(header.name == 'status'){
                        var headerclassname = 'headers status_auto_width status_width';
                    }else{
                        var headerclassname = 'headers dynamicselectedcolumn'; 
                    }

                    //$str_viewSectionHeader = $str_viewSectionHeader + '<th  id="" class="'+headerclassname+'"><a id="' + header.sort + '" title="Sort by '+ header.displayName +'" href="javascript:void(0);" data-column="' + header.sort + '"';
		    $str_viewSectionHeader = $str_viewSectionHeader + '<th  id="" class="'+headerclassname+'"><a title="Sort by '+ header.displayName +'" href="javascript:void(0);" data-column="' + header.sort + '"';
                    if (pageData.sortType) {
                        if (pageData.sortType == "desc") {
                            sortType = "asc";
                            sortClass = "sortUp";
                        } else {
                            sortType = "desc";
                            sortClass = "sortDown";
                        }
                    } else {
                        sortType = "asc";
                        sortClass = "noSort";
                    }
                    if (pageData.sortColumn === header.sort) {
                        $str_viewSectionHeader = $str_viewSectionHeader + 'data-sort="' + sortType + '" class="columnForSort ' + sortClass + '">';
                    } else {
                        $str_viewSectionHeader = $str_viewSectionHeader + 'data-sort="asc" class="columnForSort">';
                    }
                    // MV-1015 : START --->short name
                    if((header.displayName).length > 13 ){
                        $str_viewSectionHeader = $str_viewSectionHeader + (header.displayName).substring(0,13) + '...' + '</a></th>'; 
                    }
                    else{
                    $str_viewSectionHeader = $str_viewSectionHeader + header.displayName + '</a></th>';
                    }
                    // MV-1015 : END
                }
            }
        });
        if(disable_actionLinks == false){ 
        $str_viewSectionHeader = $str_viewSectionHeader + '<th class="status_width">Edit</th></tr>';
        } // Bg-577
    /* } */
    
    // Start : Added on 12-02-2019 for diabled dropdown based on permissions
    if(disable_allidentcheckbox == true){
        $str_viewSection = $str_viewSection + '<tr><td class="notHeader"><span><input type="checkbox" name="allidentcheckbox" id="allidentcheckbox" class="allidentcheckbox" value="0" style="margin-right:5px; display:none" disabled="disabled" /></span>'; //bg-577
    }else{
        $str_viewSection = $str_viewSection + '<tr><td class="notHeader"><span><input type="checkbox" name="allidentcheckbox" id="allidentcheckbox" class="allidentcheckbox" value="0" style="margin-right:5px;" /></span>';
    }
    // End : Added on 12-02-2019 for diabled dropdown based on permissions
    
    $str_viewSection = $str_viewSection + '<a id="identifier_name" rel="" href="javascript:void(0)" data-column="identifier_name" ';
    //BG-577 start
    if(disable_allidentcheckbox == true){
        $str_viewSection = $str_viewSection + 'style="margin-left: 34px;"';
    }
    //BG-577 end
    if (pageData.sortType) {
        if (pageData.sortType == "desc") {
            sortType = "asc";
            sortClass = "sortUp";
        } else {
            sortType = "desc";
            sortClass = "sortDown";
        }
    } else {
        sortType = "desc";
        sortClass = "sortDown"; 
    }
    
    if (pageData.sortColumn === "identifier_name") {
        
        $str_viewSection = $str_viewSection + 'data-sort="' + sortType + '" class="sorting ' + sortClass + ' filterlabel columnForSort">';
    } else {        
        
        if(pageData.sortColumn.toString().trim().length > 0)
        {
            sortClass = "noSort";
        }
        $str_viewSection = $str_viewSection + 'data-sort="' + sortType + '" class="sorting ' + sortClass + ' filterlabel columnForSort">';
    }
    
    
    if(headers.length == 3){        
        $str_viewSection = $str_viewSection +  identifier_plural_alias + '</a></td><td></td><td></td></tr>';
    }else if(headers.length > 3){        
        $str_viewSection = $str_viewSection +  identifier_plural_alias + '</a></td>';
        for(var k=2;k<=headers.length;k++){            
            $str_viewSection = $str_viewSection +  '<td></td>';
        }
        $str_viewSection = $str_viewSection +  '</tr>';
    }
    

    
     var isBreakOut = 0;
    var breakOutFactor = "";
    var breakOutName = "";


    //preparing identifier listing table rows
    //if (headers.length < 3) {
    
    if (typeof data[0] === 'undefined' || (data[0].identifier_id == "0" && data[0].status == "nodatafound")) {
        
    }else{        
        
        for(var i=0; i < data.length; i++)
        {    
            if(data[i].status == 0){
                var idnStatus = 'Archived';
                var tdclassForActiveArchived = 'greybackground';
            }else{
                var idnStatus = 'Active';
                var tdclassForActiveArchived = '';
            }

            if (typeof data[i]["breakoutname"] !== "undefined" && data[i]["breakoutname"] != null && data[i]["breakoutname"] != "" /* && data[i]["breakoutfactor"].length > 0 */) {
               
                isBreakOut = 1;
                if(pageData.optionflag == "1")
                {
                    breakOutFactor = data[i]["breakoutname"];
                    breakOutName = data[i]["breakoutname"];
                    breakOutFactor = breakOutFactor.replace(/~([^~]*)$/, '$1').replaceAll("$DQUOTE$", '"').replaceAll("$SQUOTE$", "'").replaceAll("$squote$", "'");/* --- BG-165 --- */ // MV-1381 added By KC 
                    breakOutName = breakOutName.replace(/~([^~]*)$/, '$1').replaceAll("$DQUOTE$", '"').replaceAll("$SQUOTE$", "'").replaceAll("$squote$", "'");/* --- BG-165 --- */ // MV-1381 added By KC 
                }else{
                    breakOutFactor = data[i]["breakoutfactor"];       //DS:: BG-467
                    breakOutName = data[i]["breakoutname"];
                    console.log(breakOutFactor);
                    //breakOutFactor = breakOutFactor.replace(/~([^~]*)$/, '$1').replaceAll("$DQUOTE$", '"').replaceAll("$SQUOTE$", "'").replaceAll("$squote$", "'");/* --- BG-165 --- */ // MV-1381 added By KC  //DS:: BG-467
                    breakOutName = breakOutName.replace(/~([^~]*)$/, '$1').replaceAll("$DQUOTE$", '"').replaceAll("$SQUOTE$", "'").replaceAll("$squote$", "'");/* --- BG-165 --- */ // MV-1381 added By KC 
                }
                
                $j23('input[name="noSortBrkOut"]').val(1);/* --- BG-165 --- */
                //breakOutName = data[i]["breakoutname"];
                $str_viewSection = $str_viewSection + '<tr>';
                $str_viewSection = $str_viewSection + '<td class="notHeader breakouthead" colspan='+headers.length+'>';
                //BG-577 start
                if( type3Permission == "ViewOnly" || type3Permission == "ViewAndCreateAssociation" || type3Permission == "ViewAndDeleteAssociation" || type3Permission == "ViewOrModifyAssociation"){
                $str_viewSection = $str_viewSection + '<span class="pull-left"><input type="checkbox" style ="display:none;" name="attr_val_chkbox" id="" class="'+breakOutFactor+'"></span>';
                
                $str_viewSection = $str_viewSection + '<label class="pull-left" style ="margin-left:34px">'+breakOutName;
                }
                else{
                $str_viewSection = $str_viewSection + '<span class="pull-left"><input type="checkbox" name="attr_val_chkbox" id="" class="'+breakOutFactor+'"></span>';
                
                $str_viewSection = $str_viewSection + '<label class="pull-left">'+breakOutName;
                }
                //BG-577 end

                $str_viewSection = $str_viewSection + '<span id="filterid_'+breakOutFactor+'" style="color:red; float:none;margin-top:1px; display:none;" class="msglabeltext">(Inactive Option)</span>';
                $str_viewSection = $str_viewSection + '</label></td>';
                
                
            }
            else{
                $str_viewSection = $str_viewSection + '<tr class="cl_ajax_result" ';

                if(typeof data[i]["findbreakoutrelatedrow"] !== "undefined" && data[i]["findbreakoutrelatedrow"] != null && data[i]["findbreakoutrelatedrow"] != ""){
                    /* --- BG-165 : Start --- */
                    if(pageData.optionflag == "1")
                    {
                        var findbreakoutrelatedrow = data[i]["findbreakoutrelatedrow"];                      
                        findbreakoutrelatedrow = findbreakoutrelatedrow.replace(/~([^~]*)$/, '$1').replaceAll("$DQUOTE$", '"').replaceAll("$squote$", "'").replaceAll("$SQUOTE$", "'");
                    }else{
                        var findbreakoutrelatedrow = data[i]["findbreakoutrelatedrow"];
                    }
                    /* --- BG-165: End --- */
                    $str_viewSection = $str_viewSection + 'name = "'+ findbreakoutrelatedrow + '" ';
                }

                $str_viewSection = $str_viewSection + '>';
            }


            if (typeof data[i]["breakoutname"] !== "undefined" && data[i]["breakoutname"] != null && data[i]["breakoutname"] != "") {

            } 
            else{            
           
            for(var j=0; j < headers.length; j++)
            {    
                if(headers[j].name == 'identifier_name'){

                    $str_viewSection = $str_viewSection + `<td id="${data[i].identifier_id}" class="${tdclassForActiveArchived}"><span class="pull-left"><input ${data[i].displaycheckbox} name="identifierid_list" id="${data[i].identifier_id}" style="display:${data[i].displaycheckbox == "disabled='true'" ? 'none' : 'block'}" value="${data[i].identifier_id}" type="checkbox" class="check_identifierid_list identcheckbox ${data[i].statusclass}"></span><label class="pull-left" style="width:185px; display:block; word-break:normal;margin-left:${data[i].displaycheckbox == "disabled='true'" ? '34px' : '0px'}"><a style="word-break: break-word;" class="identifiers identcheckbox_${data[i].identifier_id}" href="index.cfm?event=dashboard.view_missioncontrol&amp;associationid=${curr_associationid}&amp;associationitemid=${data[i].identifier_id}" target="_blank">${htmlEncode(data[i][headers[j].name])}</a></label></td>`;     //MV-1368::MV-1834 ::bg-577
                }
                else if(headers[j].name == 'status'){
                    $str_viewSection = $str_viewSection + '<td style="center" class="status_auto_width '+tdclassForActiveArchived+'">'+idnStatus+'</td>';
                }
                else if(headers[j].name == 'identifier_id'){                    
                }
                else{                    
                        
                    var selectedColArr = data[i][headers[j].name] + "";                   
                    if(selectedColArr != '' && selectedColArr.indexOf('~') > -1)
                    {    
                       //BG-577 start
                        var selectedcolarr_array = selectedColArr.split("~")  
                        var archievesitelist_array = archievesitelist != "" ? archievesitelist.split("~") : null ;                 
                        if(archievesitelist_array != null){
                            var selectedcolarr_array = selectedcolarr_array.map(function(item) {
                                return archievesitelist_array.includes(item) ? item +" (Archived)" : item;
                            });
                        } 
                        var selectedColArr = selectedcolarr_array.toString()  
                        //BG-577 end                                          
                        selectedColArr = selectedColArr.replace(/,/g,'<br>').replaceAll("$dquote$", '"').replaceAll("$squote$", "'").replaceAll("$SQUOTE$", "'");     //MV-1381 Added By KC     MV-1368::MV-1834 //BG-577      
                    }
                    //BG-577
                    var selectedcolarr_array = selectedColArr.split("~") 
                    var archievesitelist_array = archievesitelist != "" ? archievesitelist.split("~") : null ;                       
                    if(archievesitelist_array != null){
                        var selectedcolarr_array = selectedcolarr_array.map(function(item) {
                            return archievesitelist_array.includes(item) ? item +" (Archived)" : item;
                        });
                    }   
                    var selectedColArr = selectedcolarr_array.toString()
                    //BG-577 end 
                    selectedColArr=selectedColArr.replaceAll("$dquote$", '"').replaceAll("$squote$", "'").replaceAll("$SQUOTE$", "'");  //MV-1381 Added By KC  MV-1368::MV-1834  
                    $str_viewSection = $str_viewSection + '<td style="white-space:pre-wrap;" class=" '+tdclassForActiveArchived+'">'+selectedColArr+'</td>';
                    
                }     
                       
                
            }            
            // Start : Added on 12-02-2019 for diabled dropdown based on permissions
            if(disable_actionLinks == true){
                $str_viewSection = $str_viewSection + '<td align="center" class="'+tdclassForActiveArchived+'"><a class="actionLinks no_link " disabled="disabled" style="display:none;'+ data[i].displayeditlink +'" href="javascript:editAssociationItemWindow('+curr_associationid+','+data[i].identifier_id+',\'2\');">Edit</a></td>'; //bg-577
            }else{
                $str_viewSection = $str_viewSection + '<td align="center" class="'+tdclassForActiveArchived+'"><a class="actionLinks " style="'+ data[i].displayeditlink +'" href="javascript:editAssociationItemWindow('+curr_associationid+','+data[i].identifier_id+',\'2\');">Edit</a></td>';
            }
            // End : Added on 12-02-2019 for diabled dropdown based on permissions
        }
            $str_viewSection = $str_viewSection + '</tr>';
            
        }
    }    
    

    $str_viewSection = $str_viewSectionHeader + $str_viewSection + '</tbody></table>';

    reportSection.html($str_viewSection);

}

function prepareHeaderViewSection(data) {
    var albhabetSection = $j23('#viewHeaderAlbhabetSection');
    var actionSection = $j23('#viewHeaderActionSection');
    var $str_albhabetSection = '';
    var $str_actionSection = '';

    $str_albhabetSection = $str_albhabetSection + '<div class="center-align"><ul class="alphabet">';

    $j23.each(data, function(index, albhabet) {
        if (albhabet.status == 'active') {
            if (albhabet.id == 'other') {
                $str_albhabetSection = $str_albhabetSection + '<li style="width:35px" ><a id="' + albhabet.id + '" href="javascript:void(0);">' + albhabet.displayName + '</a></li>';
            } else if (albhabet.id == 'all') {
                $str_albhabetSection = $str_albhabetSection + '<li style="width:18px" id="alpha_all"><a id="' + albhabet.id + '" href="javascript:void(0);">' + albhabet.displayName + '</a></li>';
            } else {
                $str_albhabetSection = $str_albhabetSection + '<li><a id="' + albhabet.id + '" href="javascript:void(0);">' + albhabet.displayName + '</a></li>';
            }
        } else {
            if (albhabet.id == 'other') {
                $str_albhabetSection = $str_albhabetSection + '<li style="width:35px">' + albhabet.displayName + '</li>';
            } else if (albhabet.id == 'all') {
                $str_albhabetSection = $str_albhabetSection + '<li style="width:18px" id="alpha_all">' + albhabet.displayName + '</li>';
            } else {
                $str_albhabetSection = $str_albhabetSection + '<li>' + albhabet.displayName + '</li>';
            }
        }
    });

    $str_albhabetSection = $str_albhabetSection + '</ul></div>';
    albhabetSection.html($str_albhabetSection);
    return true;
}


function setSelectedIdentifiers() {
    var identifierid_list = $j23('[name="identifierid_list"]:checked');
    var selected_user_count = identifierid_list.length;
    var selected = [];
    identifierid_list.each(function() {
        if (!isInArray($j23(this).attr('id'), selected)) {
            selected.push($j23(this).attr('id'));
        }
    });
	
	if($j23('#selectedIdentifiers').val().split(',').length > 0){
		var arr_selected = $j23('#selectedIdentifiers').val().split(',');
		$j23(arr_selected).each(function(e,i){
			if (!isInArray(i.toString(), selected)) {
				if(i != "") {
					selected.push(i);
				}
			}
		});
	} 
	
	$j23('#selectedIdentifiers').val( selected.toString());	
    return selected;
}


function autoCompleteInit(){
    
    var suggested_idn_arr = getReletedIdentifier();
    var postData = [];

	$j23("#str_search").autocomplete({
		source: suggested_idn_arr,
		change: function(event, ui){			 
		},
		select: function (event, ui) {
			event.preventDefault();
			var text = ui.item.value; 
			$j23("#str_search").val(text);
			
            $j23('#search_icon_new').trigger('click');
		},
		/* focus: function(event, ui){
			$j23("#str_search").val(ui.item.value);
		}, */
        appendTo: '#search_box',
        //selectFirst: true,
		minLength: 0
	});
}


function getReletedIdentifier(){
    var identifiers_arr = [];
    var postData = [];
    postData = $j23('body').data('formdata');
    var bit_push = 1;
    $j23(postData).each(function(i){
        if(postData[i]['name'] == "str_search") {
            bit_push = 0;
            postData[i]['value'] = $j23('#str_search').val();
        }
    });
    if(bit_push == 1){
        postData.push({
            "name": "str_search",
            "value": $j23('#str_search').val()
        });
    }
    
    $j23.ajax({
        url: "index.cfm?event=association.getRelatedIdentifierNames",
        dataType: "json",
        type:"get",
        data:postData, /*{"str_search":$j23('#str_search').val()}*/
        async: false,
        beforeSend: function( xhr ) {
            $j23('#suggestionLoader').show();
        }
    }).success(function( data ) {
       
       identifiers_arr.push(data.data);
        $j23('#suggestionLoader').hide();
    });
    return identifiers_arr;
}

function isInArray(value, array) {
    return array.indexOf(value) > -1;
}

function setIdentifiersList(idnList){
    
    if(idnList.length > 0)
    {
        var myIdnList = idnList.split(',');
        all_iden_arrList = [];
            
        for(var i=0; i < myIdnList.length; i++)
        {
            all_iden_arrList.push(myIdnList[i]);
        }
    }
  
}

/* -----------------Start : open identifier setting popup if attribute required-------------------------- */
function openIdentifierSettingPopupWindow(addAssociationObj)
{ 
    if($j23.trim(addAssociationObj.val()) == 'Add')
    {  
        var associationid = $j23('input[name="associationid"]').val();
        var rootURL = $j23('input[name="rootURL"]').val();
        var associationitemid = '';
        var itemValue = $j23.trim($j23('input[name="newAssocItem"]').val());
        itemValue=itemValue.replaceAll(/\s+/g, ' ').trim();//MV-2043
        var identifierSingularName = $j23('#identifier_singular_name').val();
        /* var arr ={};
        <cfoutput query="requiredAssociationAttributes">								
            var attrId = #requiredAssociationAttributes.attributeid#;													
            var attrstatus = '.attrContainer_' + attrId;				
            if($j23(attrstatus).css('display') == 'block') {
                vals = $j23('##updateTableView input[name="attribute_#requiredAssociationAttributes.attributeid#"]:checked').map(function() {
                    return this.value;
                }).get().join(',');	
                arr["attribute_#requiredAssociationAttributes.attributeid#"] = vals;																
            }	
                    
        </cfoutput>	 */				
        //var path = "index.cfm?event=association.associationitemsettings&associationitemid="+ associationitemid + "&associationid=" + associationid +"&create=1&itemValue=" + itemValue + '&' + $j23('#exportTableView').serialize() + "&timeid=" + generateTimeID();
        // Yeou : Creating POST Data : START
        var path = "index.cfm?event=association.associationitemsettingsBeneficiary";
        var data = {};
        /* var formData = $j23('#exportTableView').serializeArray(); */
        data["associationitemid"] = associationitemid;
        data["associationid"] = associationid;
        data["create"] = 1;
        data["itemValue"] = itemValue;
        
        /* $j23.each(formData, function() {
            if (data[this.name] !== undefined) {
                if (!data[this.name].push) {
                    data[this.name] = [data[this.name]];
                }
                data[this.name].push(this.value || '');
            } else {
                data[this.name] = this.value || '';
            }
        });	 */		
       
        data["timeid"] = generateTimeID();        
        // Yeou : Creating POST Data : END
        
        document.getElementById('ui-dialog-title-jWindow').innerHTML = "Add a New "+identifierSingularName;        
        
        $j23("#jWindow").dialog('open');
        $j23("#jWindow").addClass('popHight');// MV-1867(S)
        $j23.ajax({
            url: path,
            type: "POST",
            data : data,
            async: false,
            success:function(data){
                if (data.indexOf(rootURL+'user.processlogin') > 0) {
                    window.location.href = rootURL+'user.login&oldlocation=' + escape( window.location.href.substr(window.location.href.indexOf('event=')));
                }
                //document.getElementById('jWindow').innerHTML = '';                            
                document.getElementById('jWindow').innerHTML = data;
                $j23(".popup_heading").text("Add a New "+identifierSingularName);
                //For setting the date picker on the ajax load page.
                $j23( ".openDateTimePicker" ).datepicker({
                        changeMonth: true,
                        changeYear: true,
                        yearRange: '1900:2100',
                        dateFormat: "m/d/yy",
                        onSelect: function() {
                        var id= $j23(this).attr("id").split("_");
                            $j23("#openDateTimePicker_"+id[1]).text('Edit');
                            $j23("#clearDateTimePicker_"+id[1]).show();
                            $j23(".datetext_"+id[1]).css("display","none");
                        }
                    });

                      /* Dhreeti: BG-577 start */
                      $j23(".picklist li").hover(function(){
                        $j23(this).css("background-color", "white");
                      }, function(){
                        $j23(this).css("background-color", "");
                      });

                       var siteFieldattrIDList = $j23('#siteFieldattrIDList').val();
                       var siteFieldattrIDArray = siteFieldattrIDList.split(',');

                       for (let index = 0; index < siteFieldattrIDArray.length; index++) {
                        var divcount = $j23('#blueBox_site_'+siteFieldattrIDArray[index]+' .selectedScope').length;		
	                   if(divcount < 2 ){
                            $j23('#scopeSelectToggle_site_'+siteFieldattrIDArray[index]).css("display","none");
	                   }else{			
                            $j23('#scopeSelectToggle_site_'+siteFieldattrIDArray[index]).css("display","block");
	                    }
    
                       }

                       /* Dhreeti: BG-577 end */
            
                    $j23(".openDateTimePicker").click(function (e) {
                        var id= $j23(this).attr("id").split("_"); 
                        $j23("input#attribute_"+id[1]).datepicker("show");
                        e.preventDefault();
                    });
            
                    $j23(".clearDateTimePicker").click(function (e) {
                        var id= $j23(this).attr("id").split("_");
                        $j23("input#attribute_"+id[1]).val('');
                        $j23("#openDateTimePicker_"+id[1]).html('Set');
                        $j23(this).hide();
                        $j23(".datetext_"+id[1]).css("display","none");
                        e.preventDefault();
                    });

                    //BG-110 Start
                    $j23( ".openDateTimePickerAnother" ).datepicker({
                        changeMonth: true,
                        changeYear: true,
                        yearRange: '1900:2100',
                        dateFormat: "m/d/yy",
                        maxDate: 0,
                        onSelect: function() {
                        var id= $j23(this).attr("id").split("_");
                            $j23("#openDateTimePicker_"+id[1]).text('Edit');
                            $j23("#clearDateTimePicker_"+id[1]).show();
                            $j23(".datetext_"+id[1]).css("display","none");
                            $j23("#attribute_"+id[1]).css("display","inline");
                        }
                    });

                    $j23(".openDateTimePickerAnother").click(function (e) {
                        var id= $j23(this).attr("id").split("_"); 
                        $j23("input#attribute_"+id[1]).datepicker("show");
                        e.preventDefault();
                    });
                        
                    $j23(".clearDateTimePickerAnother").click(function (e) {
                        var id= $j23(this).attr("id").split("_");
                        $j23("input#attribute_"+id[1]).val('');
                        $j23("input#attribute_"+id[1]).hide();
                        $j23("#openDateTimePicker_"+id[1]).html('Select Birthdate');
                        $j23(this).hide();
                        $j23(".datetext_"+id[1]).css("display","none");
                        e.preventDefault();
                    });

                    //BG-110 End
            
                    $j23(".dateAttribute").keyup(function(e){
                        var isValid = isValidDate2($j23(this).val());
                        var id= $j23(this).attr("id").split("_");
                        if($j23(this).val()!=""){
                            if (isValid) {
                            $j23(".datetext_"+id[1]).css("display","none");
                            $j23("#openDateTimePicker_"+id[1]).text('Edit');
                            $j23("#clearDateTimePicker_"+id[1]).show();
                            } else {
                            $j23(".datetext_"+id[1]).css("display","inline");
                            }
                        }
                    });
            $j23('.phoneNumberField').keypress(function (e) {
                    var regex = new RegExp("^[0-9A-Za-z+\b ]+$");
                    var key = e.charCode;
                    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
                    if (regex.test(str) || e.which==0)
                    {
                        return true;
                    }
        
                    e.preventDefault();
                    return false;
                });
                $j23.each($j23(".attributeHeading"), function(i,v){
                    var len = findLongestWord($j23(v).attr("data-attr-name"));

                    if(len>=15){
                        $j23(v).css("word-break","break-all");
                        $j23(v).css("overflow-wrap","break-word");
                    }
                });	
                    $j23(".panel_alignment").click(function(){
                        var rel = $j23(this).attr("id");
                        panelslider(rel);
                    });
                hideLoadingOverlay();    
            },
            error:function(xhr, status, error){
                $j23("#jWindow").dialog('close');
                alert('Oops...mistake on server');
                hideLoadingOverlay();
                return false;
            }
        });
        
    }else
    {
        hideLoadingOverlay();
    }
}
/* ----------------End : open identifier setting popup if attribute required----------------------- */

/* ----------------Start : edit identifier setting popup ------------------------------------------ */
function editAssociationItemWindow(associationid,associationitemid,flagvalue){// BG-56
    showLoadingOverlay();
    var rootURL = $j23('input[name="rootURL"]').val();
    var identifierSingularName = $j23('#identifier_singular_name').val();
    var path = "index.cfm?event=association.associationitemsettingsBeneficiary&associationitemid=" + associationitemid + '&associationid=' + associationid + '&' + '&flagvalue=' + flagvalue + /* '&' + $j23('#exportTableView').serialize() + */ "&create=0&timeid=" + generateTimeID();// BG-56
        
    document.getElementById('jWindow').innerHTML="";
    document.getElementById('ui-dialog-title-jWindow').innerHTML = "";
    $j23("#jWindow").dialog('open'); 
    $j23("#jWindow").addClass('popHight'); // MV-1867(S)
    
    $j23.ajax({
        url: path,
        type: "GET",
        success:function(data){
    if (data.indexOf(rootURL+'user.processlogin') > 0) {
        window.location.href = rootURL+'user.login&oldlocation=' + escape( window.location.href.substr(window.location.href.indexOf('event=')));
    }
     document.getElementById('ui-dialog-title-jWindow').innerHTML = identifierSingularName+" Settings";
     
    document.getElementById('jWindow').innerHTML = data;				
    //For setting the date picker on the ajax load page.


     /* Dhreeti: BG-577 start */
      $j23(".picklist li").hover(function(){
        $j23(this).css("background-color", "white");
      }, function(){
        $j23(this).css("background-color", "");
      });

      var siteFieldattrIDList = $j23('#siteFieldattrIDList').val();
      var siteFieldattrIDArray = siteFieldattrIDList.split(',');

      for (let index = 0; index < siteFieldattrIDArray.length; index++) {
        var divcount = $j23('#blueBox_site_'+siteFieldattrIDArray[index]+' .selectedScope').length;		
	    if(divcount < 2 ){
            $j23('#scopeSelectToggle_site_'+siteFieldattrIDArray[index]).css("display","none");
	    }else{			
            $j23('#scopeSelectToggle_site_'+siteFieldattrIDArray[index]).css("display","block");
	    }
    
      }
      /* Dhreeti: BG-577 end */
      
    $j23(".popup_heading").text(identifierSingularName+" Settings");
    $j23( ".openDateTimePicker" ).datepicker({
        changeMonth: true,
        changeYear: true,
        yearRange: '1900:2100',
        dateFormat: "m/d/yy",
        onSelect: function() {
        var id= $j23(this).attr("id").split("_");
            $j23("#openDateTimePicker_"+id[1]).text('Edit');
            $j23("#clearDateTimePicker_"+id[1]).show();
            $j23(".datetext_"+id[1]).css("display","none");
        }
    });

    $j23(".openDateTimePicker").click(function (e) {
        var id= $j23(this).attr("id").split("_"); 
        $j23("input#attribute_"+id[1]).datepicker("show");
        e.preventDefault();
    });
        
    $j23(".clearDateTimePicker").click(function (e) {
        var id= $j23(this).attr("id").split("_");
        $j23("input#attribute_"+id[1]).val('');
        $j23("#openDateTimePicker_"+id[1]).html('Set');
        $j23(this).hide();
        $j23(".datetext_"+id[1]).css("display","none");
        e.preventDefault();
    });

    //BG-110 Start
    $j23( ".openDateTimePickerAnother" ).datepicker({
        changeMonth: true,
        changeYear: true,
        yearRange: '1900:2100',
        dateFormat: "m/d/yy",
        maxDate: 0,
        onSelect: function() {
        var id= $j23(this).attr("id").split("_");
            $j23("#openDateTimePicker_"+id[1]).text('Edit');
            $j23("#clearDateTimePicker_"+id[1]).show();
            $j23(".datetext_"+id[1]).css("display","none");
            $j23("#attribute_"+id[1]).css("display","inline");
        }
    });

    $j23(".openDateTimePickerAnother").click(function (e) {
        var id= $j23(this).attr("id").split("_"); 
        $j23("input#attribute_"+id[1]).datepicker("show");
        e.preventDefault();
    });
        
    $j23(".clearDateTimePickerAnother").click(function (e) {
        var id= $j23(this).attr("id").split("_");
        $j23("input#attribute_"+id[1]).val('');
        $j23("input#attribute_"+id[1]).hide();
        $j23("#openDateTimePicker_"+id[1]).html('Select Birthdate');
        $j23(this).hide();
        $j23(".datetext_"+id[1]).css("display","none");
        e.preventDefault();
    });

    //BG-110 End
        
    $j23(".dateAttribute").keyup(function(e){
        var isValid = isValidDate2($j23(this).val());
        var id= $j23(this).attr("id").split("_");
        if($j23(this).val()!=""){
            if (isValid) {
            $j23(".datetext_"+id[1]).css("display","none");
            $j23("#openDateTimePicker_"+id[1]).text('Edit');
            $j23("#clearDateTimePicker_"+id[1]).show();
            } else {
            $j23(".datetext_"+id[1]).css("display","inline");
            }
        }
    });
    $j23('.phoneNumberField').keypress(function (e) {
        var regex = new RegExp("^[0-9A-Za-z+\b ]+$");
        var key = e.charCode;
        var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
        if (regex.test(str) || e.which==0)
        {
            return true;
        }

        e.preventDefault();
        return false;
    });						   
    $j23.each($j23(".attributeHeading"), function(i,v){
        var len = findLongestWord($j23(v).attr("data-attr-name"));
        if(len>=15){
            $j23(v).css("word-break","break-all");
            $j23(v).css("overflow-wrap","break-word");
        }
    });
    
    $j23(".panel_alignment").click(function(){
           var rel = $j23(this).attr("id");
           panelslider(rel);
       });
    
    
    
        },
        complete:function(){
            hideLoadingOverlay();
        },
        error:function(){
            $j23("#jWindow").dialog('close');
            alert('Oops...mistake on server');
            hideLoadingOverlay();
            return false;
        }
    });
}
/* ----------------End : edit identifier setting popup -------------------------------------------- */

/* Start :: BG-682 */
function ValidatePastedValueInPhoneNumber(e){
    var regex = new RegExp("^[0-9A-Za-z+\b ]+$");
    var input = e.target;
    var previous_val=input.value;

    setTimeout(() => {
        if (!regex.test(input.value)) {
            if(previous_val.length > 0){
                input.value = previous_val;
            }else{
                input.value = '';
            }
        }
        e.preventDefault();
        CountLeft(input,20);
        return false;
    }, 0);
}
function ValidatePastedValueInMobileNumber(obj, e, mobfname){
    var regex = new RegExp("^[0-9\-]+$");
    var input = e.target;
    var previous_val=input.value;

    setTimeout(() => {
        if (!regex.test(input.value)) {
            if(previous_val.length > 0){
                input.value = previous_val;
            }else{
                input.value = '';
            }
        }else{
            FormatPhoneNumBG(obj, e, mobfname);
        }
        e.preventDefault();
        CountLeft(input,12);
        return false;
    }, 0);
}
/* End :: BG-682 and BG-703 */

function generateTimeID(){
    var dt = new Date();
    var tm = dt.getTime();
    return tm;
}

function findLongestWord(str) {
    if(str!=undefined){
        var words = str.split(' ');
        var maxLength = 0;
        for (var i = 0; i < words.length; i++) {
            if (words[i].length > maxLength) {
            maxLength = words[i].length;
            }
        }

        return maxLength;
    }
    return 0;
}

function panelslider(rel)
{			
    if($j23(rel).attr("class") != undefined)
    {
        var rel = $j23(rel).prop('rel');
    }
    
    if($j23("."+rel).attr("data-index")==0)
    {
            
            $j23("."+rel).attr("data-index","1");
            $j23("."+rel).addClass("hideIt");
            $j23("."+rel).removeClass("showIt");
            $j23("."+rel+"_div").slideDown();
    }
    else
    {
            $j23("."+rel).attr("data-index","0");	
            $j23("."+rel).addClass("showIt");
            $j23("."+rel).removeClass("hideIt");	
            $j23("."+rel+"_div").slideUp();
    }				
}
/*MV-1580*/
function checkValidation(action,flagvalue){
    var CheckeduserIds=$j23('#AssociationItemSettings input:checkbox[name="chkbx_TargetedTutors"]:checked').map(function() {
        return $j23(this).val();
     }).get().join(','); 
    var assoID =$j23(".associationid").val().trim();
    var pgmid =$j23("#programid").val();
    var assignedUserIDList =$j23("#assignedUserIDList").val().trim();
    var flgVal=false;
    if(assignedUserIDList != '' && action=="Update"){
        $j23.ajax({
            url: "index.cfm?event=association.checkType3Validation",
            type: "POST",               
            data: {
                CheckeduserIds: CheckeduserIds, 
                assoID: assoID, 
                pgmid: pgmid, 
                assignedUserIDList : assignedUserIDList
            },     
            dataType : "json",
            success:function(data){
                if(data.DisconnectedList == 1){
                    alert("Please go to this "+identi_als+"'s profile page to make this change as removing the identifier here will violate a requirement that all "+volPlural+" must be assigned to at least one identifier at all times.");			
                    $j23('#AllpanelButton').prop('disabled',false);
                    return false;
                }else{
                    return processForm(action,flagvalue);
                }                
            },
            error:function(){
                return false;
            }
        });
    }else{
        return processForm(action,flagvalue);
    }
    return false;
}
/*MV-1580*/
function processForm(action,flagvalue){// BG-56
    var formObj = $j23("form#AssociationItemSettings");	
    var formData = new FormData($j23("form#AssociationItemSettings")[0]);    
    
    // CPORT-54, Start, 12-05-2019
    var identifierSingularAlias = $j23('#identifier_singular_name').val();
    if(identifierSingularAlias == ''){
       identifierSingularAlias = "Identifier";
    }
    // CPORT-54, End, 12-05-2019    

    /* <!--- ASSNS-527 Start (from associationItemSettings.cfm) ---> */			
    var attrIdList = $j23('#fileFieldattrIDList').val();	//get all file type field attribute id list 			
    var fileOperationArr = {};
    var tfcount = 0;						
    if(attrIdList != ''){
        //validateFileSubmit(attrIdList,formData,fileOperationArr);
        var str_array = attrIdList.split(',');					
        var UserType = $j23('#UserType').val();			
        var namecheck = 'true';			
        for(var k = 0; k < str_array.length; k++){	
            var checkrequired = $j23('#checkrequired'+str_array[k]).val();
            var attrname = $j23('#attrname'+str_array[k]).val();

            oldfiles = $j23(document).find("#UploadFiles"+str_array[k]).find("input[type=file]:not([fileidufn=0])");
            files = $j23(document).find("#UploadFiles"+str_array[k]).find("input[type=file]");

            //loop k for attribute list
            oldUserfileName = $j23(document).find("#UploadFiles"+str_array[k]).find("input[type=text]:not([fileidufn=0])");
            UserfileName = $j23(document).find("#UploadFiles"+str_array[k]).find("input[type=text]");
            var j = 1;
                                
            // check mandatory files upload or not :- Start
            var mandatoryFiles = '';
            var fileslen = files.length;
            var oldfileslen = oldfiles.length;
            var countexactfiles = 0;						
                
            if(UserType == 'submanager'  || UserType == 'manager'){
                mandatoryFiles = $j23('#staffmandatory'+str_array[k]).val();					
            }else if(UserType == 'volunteer'){
                mandatoryFiles = $j23('#aliasmandatory'+str_array[k]).val();					
            }						
            for(var i=0; i<fileslen; i++){					
                if(files[i].value != ''){
                    countexactfiles = countexactfiles + 1;
                }
            }		
                        
            if(UserType == 'submanager' || UserType == 'manager' || UserType == 'volunteer'){
                countexactfiles = countexactfiles + oldfileslen;
                var dynamicval = mandatoryFiles - countexactfiles;											
                if(mandatoryFiles > countexactfiles){
                    alert('Please upload ' +dynamicval+ ' mandatory files to the field, "'+attrname+'".');
                    $j23('#AllpanelButton').prop('disabled',false);
                    return false;
                        
                }
            }
            // check mandatory files upload or not :- End

            var len = files.length;
            var uploadedFiles = 0 ;	
            var filefields = [];	
            var userFileNames = [];													
            //loop i for length of files
            for(var i=0; i<len; i++)
            {	//loop j for file naming 
                if(files[i].value != '' || $j23(UserfileName[i]).attr('fileidufn') != 0)							
                {								
                    $j23(files[i]).attr('name',"file"+str_array[k]+"_"+(j)).attr('id',"file"+str_array[k]+"_"+(j));
                    $j23(UserfileName[i]).attr('name',"userFileLabel"+str_array[k]+"_"+(j)).attr('id',"userFileLabel"+str_array[k]+"_"+(j));	
                    filefields.push($j23(files[i]).attr('name'));	
                    userFileNames.push($j23(UserfileName[i]).val());									
                    if($j23(UserfileName[i]).attr('fileidufn') != 0 && files[i].value != '' )														
                    fileOperationArr['fileActn'+str_array[k]+'_'+j] = 'insert_'+$j23(files[i]).attr('fileidufn');
                    else if($j23(UserfileName[i]).attr('fileidufn') == 0 && files[i].value != '' )	
                    fileOperationArr['fileActn'+str_array[k]+'_'+j]  = 'insert_'+$j23(files[i]).attr('fileidufn');									
                    else if($j23(UserfileName[i]).attr('fileidufn') != 0 && files[i].value == '' )	
                    fileOperationArr['fileActn'+str_array[k]+'_'+j] = 'update_'+$j23(files[i]).attr('fileidufn');
                    j++;					
                }						
            }						
            formData.filefields = filefields.join(",");
            formData.userFileNames = userFileNames.join("<$>");

            for(var i=0; i < j-1; i++)
            {	
                if($j23(UserfileName[i]).val().trim().length == 0)
                {	
                    namecheck = 'false';
                        
                }else if($j23(UserfileName[i]).val().trim().length > 0){
                    if(checkNameForFileChar($j23(UserfileName[i]).val())){
                        namecheck = 'false';								
                    }
                        
                    if($j23(UserfileName[i]).val().trim().length > 249){
                        namecheck = 'false';								 								
                    }
                }							
            }											
                
            $j23('#fileCount'+str_array[k]).val(j-1);	
            tfcount = parseInt(tfcount) + parseInt($j23('#fileCount'+str_array[k]).val());									
        }	
        
        if(namecheck == 'false'){	
            namecheckOnSubmit(str_array);
            $j23('#AllpanelButton').prop('disabled',false);
            return false;					
        }
        $j23('#tfcount').val('');	
        $j23('#tfcount').val(tfcount);
    }								
    /* <!--- ASSNS-527 End ---> */

    var fieldNames  = new Array();			
    var namepattern = /^[a-z\d\_()',\*-_.&\s]+$/i;//SURVEYCOMP-169 : ~ Removed
    var pattern2 =  /^\d+$/;
    var newItem = $j23.trim($j23("form#AssociationItemSettings #itemvalue").val());
    newItem =newItem.replaceAll(/\s+/g, ' ').trim();//MV-2043
    var old_itemvalue= $j23("form#AssociationItemSettings #old_itemvalue").val();
    /* <!--- cp-14 lookup ---> */
    var mobiletypeattributes = '';
    var mobiletypeattributevalue = {};
    /* <!--- cp-14 lookup ---> */
    
    var chkbx_TargetedTutors=$j23('#AssociationItemSettings input:checkbox[name="chkbx_TargetedTutors"]:checked');

    var chkbx_TargetedTutorsList = [];
    for(var i = 0; i<chkbx_TargetedTutors.length; i++ )
    { 
        chkbx_TargetedTutorsList.push($j23(chkbx_TargetedTutors[i]).val());
        
    }
    $j23('#checkedVolunteers').val(chkbx_TargetedTutorsList);


    
    var phonepattern = /^[0-9A-Za-z+ ]+$/;
    var finalValue = "";
    var digits = ""; 
    var trailingValues = "";
    

    if(newItem=='')
    {
        alert('Please enter a name for this '+identifierSingularAlias+'.');     //CPORT-54, 12-05-2019
        $j23('#AllpanelButton').prop('disabled',false);
        return false;
        
    }               
    else if(!newItem.match(namepattern))
    {
        alert("Please enter a valid name for this "+identifierSingularAlias+". Only alphanumeric characters, spaces, paranthesis, commas, apostrophe, -, _, &, or periods are allowed.");    //CPORT-54, 12-05-2019
        $j23('#AllpanelButton').prop('disabled',false);
        return false;
        
    }               
    /*else{
        flag = 0;
        $j23('a.identifiers').each(function(){
            //if($j23('#create').val()==1 && $j23(this).html()==newItem)    // commented on 12-11-2019
            if($j23(this).html()==newItem && newItem != old_itemvalue)
            {
                alert('An '+identifierSingularAlias+' with the same name already exists in this Association.  Please enter a unique name or close this window and edit the existing '+identifierSingularAlias+'.');     //CPORT-54, 12-05-2019
                flag =1;
                $j23('#AllpanelButton').prop('disabled',false);
                return false;                
            }
        });
        if(flag) {$j23('#AllpanelButton').prop('disabled',false); return false;}
    }*/
	
		
    formObj.find('input.required,input.changedInput,textarea.required,select.required,input.emailField,input.numberTextField, input.encrypedField,textarea.freetextarea').each(function(){ //SM-193       
        fieldName = $j23(this).attr('name');
        var found = $j23.inArray(fieldName, fieldNames);
        if (found >= 0) {
        } else {
            // Element was not found, add it.
            fieldNames.push(fieldName);
        }
    });
    var message = '';		
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;	
        //var phoneformat  = /\(?([0-9]{3})\)?([ .-]?)([0-9]{3})\2([0-9]{4})/;
				
    $j23.each(fieldNames, function(index, value){
    
        var fieldObj = formObj.find(':input' + '[name="' + value + '"]');
        var fieldType = fieldObj.attr('type');
        var fieldIsRequired = fieldObj.hasClass('required');
        var fieldIsFreeText = fieldObj.hasClass('freeTextField');                
        var heading = fieldObj.parents('.attributeFields').find('.attributeHeading');
        var attrname =heading.attr('data-attr-name');
        
        var strvalue = value;
        var attrid = $j23.trim((strvalue.substring(strvalue.indexOf("_") + 1)));				
        if(fieldType == 'checkbox'){
            checked = formObj.find(':input' + '[name="' + value + '"]:checked').length;
            if(checked == 0 && fieldIsRequired){
                message = message + '\n*' + attrname + ' is a required field. Please complete it.';//BG-577
            }
        }
        else
        {
           var fieldValue = $j23.trim(fieldObj.val()); 
            
            if(fieldValue.length == 0 && fieldIsRequired){
                message = message + '\n*' + attrname + ' is a required field. Please complete it.';//BG-577
            }/*else if(fieldValue.length != 0 && fieldIsFreeText && !fieldValue.match(namepattern)) {
                message = message + '\nInvalid value for attribute ' + attrname + ', Only alphanumeric characters, spaces, -, _, &, or Periods are allowed.';                   
            }*/else if(fieldValue.length != 0 && fieldObj.hasClass('numberTextField') && isNaN(fieldValue)){
                message = message + '\n' + attrname + ' should be a number.';
            }else if(fieldValue.length != 0 && fieldObj.hasClass('mobileNumberField') && isValidMobileNumber(fieldObj,fieldValue)) {
				message = message + '\n' + attrname + ' : Phone number "'+fieldValue+'" is not a valid mobile number.  Please enter another number or delete the number.';
            } 	
            
            else if(fieldValue.length != 0 && fieldObj.hasClass('phoneNumberField') /* <!---&& (! fieldValue.match(phoneformat) )---> */ ){
                //message = message + '\n' + attrname + ' should be a valid phone number.';
                /* <!--- New phone no validation ---> */
                                
                var attrValue = fieldValue.trim();
                var attrValueLength = fieldValue.toString().length;
                var firstAlphabet = fieldValue.match(/[A-Za-z ]/);
                var indexOfFirstAlphabet = fieldValue.indexOf(firstAlphabet);
                var indexOfPlus = fieldValue.indexOf("+");
                finalValue = "";
                if(attrValueLength <= 18){
                    if(indexOfFirstAlphabet != -1){
                        if(indexOfPlus == 0){
                            digits = attrValue.toString().substring(1,indexOfFirstAlphabet);
                            digits = digits.replace(/[\+\-]/g, '');
                            trailingValues = attrValue.toString().substring(indexOfFirstAlphabet,attrValue.toString().length);
                            finalValue += "+";
                        }else if(indexOfPlus > 0){
                            digits = attrValue.toString().substring(0,indexOfFirstAlphabet);
                            digits = digits.replace(/[\+\-]/g, '');
                            trailingValues = attrValue.toString().substring(indexOfFirstAlphabet,attrValue.toString().length);
                        }else{
                            digits = attrValue.toString().substring(0,indexOfFirstAlphabet);
                            trailingValues = attrValue.toString().substring(indexOfFirstAlphabet,attrValue.toString().length);
                        }
                    }else{
                        if(indexOfPlus == 0){
                            digits = attrValue.toString().substring(1,attrValue.toString().length);
                            digits = digits.replace(/[\+\-]/g, '');
                            finalValue += "+";
                        }else if(indexOfPlus > 0){
                            digits = attrValue.toString().substring(0,attrValue.toString().length);
                            digits = digits.replace(/[\+\-]/g, '');
                        }else{
                            digits = attrValue.toString().substring(0,attrValue.toString().length);
                        }
                    }
                    
                    var digitsValueLength = digits.toString().length;

                    if(digitsValueLength == 10){
                        if(!$j23.isNaN(digits)){
                            var first3Digit = digits.toString().substring(0,3);
                            var second3Digit = digits.toString().substring(3,6);
                            var last4Digit = digits.toString().substring(6,10);
                            finalValue += first3Digit + "-" + second3Digit + "-" +last4Digit + trailingValues;
                            fieldObj.val(finalValue);
                        } 
                    } else if (digitsValueLength == 7){
                        if(!$j23.isNaN(digits)){
                            var first3Digit = digits.toString().substring(0,3);
                            var last4Digit = digits.toString().substring(3,7);
                            finalValue += first3Digit + "-" + last4Digit + trailingValues;
                            fieldObj.val(finalValue);
                        }
                    }
                }
                /* <!--- New phone no validation ---> */						
            }else if(fieldValue.length != 0 && fieldObj.hasClass('dateAttribute') && !isValidDate2(fieldValue)){
                    message = message + '\n' + attrname + ' is not proper format.';                      
            } else if(fieldValue.length != 0 && fieldObj.hasClass('emailField') && (! isEmail(fieldValue) )){
                message = message + '\n' + emailvalidationmessage;//Added by MN
            } 
	    /* BG-564 */
            else if(fieldValue.length != 0 && fieldObj.hasClass("encryptedField") && validateEncryptedTextField(fieldValue)){
                message = message + "Please enter "+ attrname +" without these special characters (~,`,^).";
            }
	    /* BG-564 */
            /* Start :: SM-193 */ 
            else if(fieldValue.length != 0 && ( fieldObj.hasClass("freeTextField") || fieldObj.hasClass("freetextarea") ) && validateFreeTextAndLongTextField(fieldValue)){
                message = message + '\n' + "Please enter "+ attrname +" without these special character (~).";
            }
            /* End :: SM-193 */
            /* CP-14: Start */
            else if(fieldValue.length != 0 && fieldObj.hasClass('mobileNumberField')){
                actualmobilevalue = fieldObj.attr('rel1');			
                if (actualmobilevalue != fieldValue){
                    if(mobiletypeattributes.length != 0){
                        mobiletypeattributes = mobiletypeattributes + '~' + attrid + '`' + attrname;
                    }
                    else{
                        mobiletypeattributes = attrid + '`' + attrname;
                    }
                    mobiletypeattributevalue['mobilenumber_'+attrid] = fieldValue;
                }						
            } 
            /* CP-14: End */
        }
        /*if(fieldType = 'hidden'){
            value = $j23.trim(fieldObj.val());
            
        }*/
    });
	//if($j23("#checkedRecieveText_"+attributeid[1]).is(":checked"))
		
	formObj.find(':input[name^="receivetexts_"]').each(function() {
		fieldName = $j23(this).attr('name');
		var e = document.getElementById(fieldName);
		var RecieveTextsVal = $j23('#'+fieldName).val();
		var attributeid = fieldName.split("_");
		if(document.getElementById("checkedRecieveText_"+attributeid[1]).checked == false && RecieveTextsVal == 1 && $j23(this).is(':disabled')==false)
		{
			message = message + '\n' + 'Please either select the box verifying that you\'ve received written authorization to send text messages to this '+identifierSingularAlias+', or change the drop-down value to No.';//MV-1244	
		}
	});
        /* BG-577 start */
		var SiteFields = new Array();
		formObj.find('div[class^="blueBoxScroll"]').each(function(){
			blueboxid = $j23(this).attr('id');
			SiteFields.push(blueboxid);
		});
	
		$j23.each(SiteFields, function(index, value){
			var SitefieldObj = formObj.find('div[id^="'+value+'"]');
			var fieldIsRequired = SitefieldObj.hasClass('required');
			var heading = SitefieldObj.parents('.attributeFields').find('.attributeHeading');
			var attrname = heading.attr('data-attr-name');
			var SitefieldObj_hassites = SitefieldObj.find('div[class^="selectedScope"]').length;
            
			if ( SitefieldObj_hassites == 0 && fieldIsRequired ) {
				message = message + '\n*' + attrname + ' is a required field. Please complete it.';//BG-577
            }
			else if(SitefieldObj_hassites > 0){
				var SitefieldObj_hassites_tick = SitefieldObj.find('a.tick').length;
				if ( SitefieldObj_hassites_tick == 0 && fieldIsRequired ) {
				     message = message + '\n*' + attrname + ' is a required field. Please complete it.';//BG-577
                }

			}

		});
        /* BG-577 end */

    if($j23.trim(message).length == 0){
        var associationitemid = $j23('input[name=associationitemid]').val();
        var path = "index.cfm?event=association.saveassociationitemforbeneficiary";
        var newUsrMsg = '';
        /* <!--- ASSNS-527 Start --->
        <!--- cp-14 lookup ---> */
        $j23('#mobiletypeattributes').val(mobiletypeattributes);
        /* <!--- cp-14 lookup ---> */
        var formData = new FormData($j23("#AssociationItemSettings")[0]);
        $j23.each(fileOperationArr, function(key, value){					
            formData.append(key, value);
        });
        /* <!--- ASSNS-527 End --->
        <!--- cp-14 lookup --->	 */
        //$j23(".loader2").css("display","block");			
        showLoadingOverlay();
        $j23.each(mobiletypeattributevalue, function(key, value){					
            formData.append(key, value);					
        });
        
        var alphabeticFilter = $j23('#alphabeticFilter').val();
        var searchfilter = $j23('#str_search').val();
        var int_start_row = $j23('#int_next_start_row').val();
        var sortColumn = $j23('#sortColumn').val();
        var sortType = $j23('#sortType').val();
        var associationId= $j23('input[name="associationid"]').val();                  
        var bit_push_assnid = 1;
        
        var postData = $j23('body').data('formdata');    
        $j23(postData).each(function(i){
            if(postData[i]['name'] == "alphabeticFilter") {
                postData[i]['value'] = alphabeticFilter;
            } else if (postData[i]['name'] == "searchfilter") {            
                postData[i]['value'] = searchfilter;
            } else if (postData[i]['name'] == "sort_column") {
                postData[i]['value'] = sortColumn;
            } else if (postData[i]['name'] == "sort_type") {
                postData[i]['value'] = sortType;
            }else if (postData[i]['name'] == "int_start_row") {
                postData[i]['value'] = 1;
            }else if (postData[i]['name'] == "associationid") { 
                postData[i]['value'] = associationId;
                bit_push_assnid = 0;
            }
        });

        if(bit_push_assnid == 1){
            postData.push({
                "name": "associationid",
                "value": associationId
            });
        }

        /* <!--- cp-14 lookup ---> */
        $j23.ajax({
            url: path,
            type: "POST",
            //datatype:"json",
            //data: formObj.serialize(),
            data: formData, /* <!--- ASSNS-527 ---> */
			beforeSend: function() {
				showLoadingOverlay();
			},
            contentType: false,       
            cache: false,             
            processData:false,
            //async: false,	
            success:function(data){            
            data = $j23.parseJSON(data);            
                var classAdded = '';
                /* <!--- ASSNS-527 Start ---> */
                if(data.msg == 'fail'){							
                    if(attrIdList != ''){				
                        var str_array = attrIdList.split(',');																
                        for(var k = 0; k < str_array.length; k++) {																		
                            var fileCount = $j23('#fileCount'+str_array[k]).val();
                            for(var i=1; i<=fileCount; i++){   
                                var splitThis = data.files[str_array[k]+'_'+i];
                                if(typeof(splitThis) != 'undefined'){
                                    var splitThis_array = splitThis.split(';');										
                                    if(splitThis_array[2] == 'no'){
                                        $j23('#'+splitThis_array[0]).css('border','1px solid red');
                                        $j23('#'+splitThis_array[1]).val('');
                                        $j23('#'+splitThis_array[1]).next().text('Attach File Here');												
                                    }else{
                                        $j23('#'+splitThis_array[0]).attr('fileidufn',splitThis_array[3]);
                                        $j23('#file'+str_array[k]+'_'+(i)).attr('fileidufn',splitThis_array[3]);
                                    }
                                    $j23('#'+splitThis_array[0]).attr('name',"filename"+str_array[k]+"_"+(i)).attr('id',"filename"+str_array[k]+"_"+(i));
                                }
                            }		
                        }
                        alert("File Upload Failed, Please review your files and submit again.");
                        $j23('#AllpanelButton').prop('disabled',false);
                        hideLoadingOverlay();
                        return false;	
                    }								
                }
                /* <!--- ASSNS-527 End --->
                <!--- CP-14: Start ---> */
                else if(data.msg == 'lookupfail'){
                    mobattrval = mobiletypeattributes.split("~");
                    var lookupmsg = '';
					var mobilevalidatemsg = '';
                    for(var j = 0; j < mobattrval.length; j++)
                    {						
                        mobattridval = mobattrval[j].split('`');
                        mobattrid = mobattridval[0];
                        if(data.messageStruct[mobattrid] != undefined){							
                           mobilevalidatemsg = data.messageStruct[mobattrid].replace(/dquote/g, '"');
							lookupmsg = lookupmsg + '\n' + mobilevalidatemsg;
                        }
                    }
                    alert(lookupmsg);
                    //$j23(".loader2").css("display","none");
                    hideLoadingOverlay();
                    $j23('#AllpanelButton').prop('disabled',false);
                    return false;
                }
                /* <!--- CP-14: End ---> */
				else if(data.msg == 'duplicateidentifier'){
					var duplicateidentifiermsg = '';
					duplicateidentifiermsg = data.messageStruct['duplicatemessage'];
					alert(duplicateidentifiermsg);
                    //$j23(".loader2").css("display","none");
                    hideLoadingOverlay();
                    $j23('#AllpanelButton').prop('disabled',false);
                    return false;
				}
                else if(data.msg == 'Updated'){                 // CPORT-54, 12-05-2019
               
                    //if(flagvalue == 1){       // commented on 03-12-2019 for showing usermsg on identifier update                
                        var updatedAssoItemValue = $j23('#itemvalue').val().trim();
                        $j23('#insertedId').val(associationitemid);
                        $j23("#insertedItem").val(updatedAssoItemValue);                        
                        var path = 'index.cfm?event=association.setValuesonSessionForBeneficiary';                        
                        $j23.ajax({
                            url: path,
                            type: "post",
                            data: {
                                classAdded : 'go',
                               // newMsg : 'Identifier Updated',    // CPORT-54, 12-05-2019
                                newMsg : data.msg,                  // CPORT-54, 12-05-2019
                                insertedId : $j23('#insertedId').val().trim(), // from session
                                insertedItem : $j23('#itemvalue').val().trim(),
                                flagVal :1
                                //flagVal :flagvalue
                            },
                            async: false,
                            success:function(){
                                
                                //newUsrMsg1 = 'Identifier Updated';    // CPORT-54, 12-05-2019
                                newUsrMsg1 = data.msg;                  // CPORT-54, 12-05-2019                        
                                setUserMessageFields(classAdded,newUsrMsg1,associationitemid,updatedAssoItemValue);
                                setUserMessage();
                            } 
                        }); 
                    //}	            // commented on 03-12-2019 for showing usermsg on identifier update 
                    // BG-56 End
                    closeWindow();	
                    var y = all_iden_arrList;
                    y = $j23.grep(y, function(value) {
                        return value != old_itemvalue;
                    });
                    
                    all_iden_arrList = y;
                    all_iden_arrList.push($j23('#itemvalue').val().trim())
                    $j23('#str_search').autocomplete("option", { source: all_iden_arrList});
                    classAdded = 'go';
                }
                else if(data.msg == 'The association item already exists.'){
                    closeWindow(); 
                    hideLoadingOverlay(); 							
                }
                else{
                    classAdded = 'stop';
                    if(data.msg == 'Added'){                    // CPORT-54, 12-05-2019
                    //if(data.msg == 'New Identifier Added'){   // CPORT-54, 12-05-2019
                        // BG-56 Start 
                        var path = 'index.cfm?event=association.setValuesonSessionForBeneficiary';
                        $j23.ajax({
                            url: path,
                            type: "post",
                            data: {
                                classAdded : classAdded,
                                //newMsg : 'New Identifier Added',      // CPORT-54, 12-05-2019
                                newMsg : data.msg,                      // CPORT-54, 12-05-2019
                                insertedId : data.newInsertedId,
                                insertedItem : data.newInserteditem,
                                flagVal :1
                            },
                            async: false,
                            success:function(){
                                //newUsrMsg = 'New Identifier Added';       // CPORT-54, 12-05-2019
                                newUsrMsg = data.msg;                       // CPORT-54, 12-05-2019
                                setUserMessageFields(classAdded,newUsrMsg,data.newInsertedId,data.newInserteditem);
                                setUserMessage();
                            } 

                        }); 
                        // BG-56 End
                        closeWindow();	
                        all_iden_arrList.push($j23('#itemvalue').val().trim());
                        $j23('#str_search').autocomplete("option", { source: all_iden_arrList});
                        //$j23(".newAssocItemDiv").html("<a href='javascript:editAssociationItemWindow(<cfoutput>#associationid#</cfoutput>,"+data.newInsertedId+")'>View "+data.newInserteditem+" Settings</a>");
                    }
                }
                               
                if(classAdded == 'go'){
                    $j23("td#"+associationitemid+"").find('a:first').text(newItem);
                    
                }
                if($j23('#newAssocItem').val().trim().length){
                    $j23('#newAssocItem').val('');
                }
                if($j23('.adminlist tr').length == 2){
                    //location.reload();<!--- ASSNS-527 --->
                }
                else{                    
                    console.log(data);                                                                
                }
                /* closeWindow(); <!--- ASSNS-527 ---> */
                checkIfDeleteAllShouldBeEnabled();						
                checkForDelete();
            },
            complete:function(data){
                data = data.responseText;                
                data = $j23.parseJSON(data);             
                
                if(data.msg == 'lookupfail' || data.msg == 'fail'){
                    //$j23(".loader2").css("display","none");
                    hideLoadingOverlay();                    
                }
                else{                                                         

                    loadIdentifiersList(postData,"");                    
                    $j23('#AllpanelButton').prop('disabled',false);
                    				
                }	
            }
            ,
            error:function(){ 
                alert('Oops...mistake on server');
                $j23('#AllpanelButton').prop('disabled',false);
                hideLoadingOverlay();
                return false;						
            }
        }, 'json'); /* <!--- ASSNS-527 ---> */
    }			
    else{
        alert(message);
        $j23('#AllpanelButton').prop('disabled',false);
    }
}

function ResetUserMessage()
{
    $j23('table.usermessage').html('');   
}

function setUserMessageFields(classAdded,newUsrMsg,newInsertedId,newInserteditem)
{
    $j23("#classAdded").val(classAdded);    
    $j23("#newMsg").val(newUsrMsg);
    $j23("#insertedId").val(newInsertedId);
    $j23("#insertedItem").val(newInserteditem);
}

function setUserMessage()
{    
    ResetUserMessage();
    var classAdded = $j23("#classAdded").val();
     var newMsg = $j23("#newMsg").val();     
     var insertedId = $j23("#insertedId").val();     
     var insertedItem = $j23("#insertedItem").val();
     var associationId = $j23('input[name="associationid"]').val();
     // CPORT-54, Start, 12-05-2019
     var identifierSingularAlias = $j23('#identifier_singular_name').val();
     if(identifierSingularAlias == ''){
        identifierSingularAlias = "Identifier";
     }
     // CPORT-54, End, 12-05-2019
     
     //if($j23("#newMsg").val() == "New Identifier Added" || $j23("#newMsg").val() == "Identifier Updated")
     if($j23("#newMsg").val() == "Added" || $j23("#newMsg").val() == "Updated") // CPORT-54, 12-05-2019
     {	
         
        // CPORT-54, Start, 12-05-2019
         if($j23("#newMsg").val() == "Added"){
            newMsg = "New "+identifierSingularAlias+" Added";
            $j23(".newAssocItemDiv").html("<a href='javascript:editAssociationItemWindow("+associationId+","+insertedId+",1)'>View "+insertedItem+" Settings</a>");
         }else if($j23("#newMsg").val() == "Updated"){
            newMsg = identifierSingularAlias + " Updated";
            $j23(".newAssocItemDiv").html('');
         }
         // CPORT-54, End, 12-05-2019

         //$j23(".newAssocItemDiv").html("<a href='javascript:editAssociationItemWindow("+associationId+","+insertedId+",1)'>View "+insertedItem+" Settings</a>");
         var content = '<tbody><tr class="'+classAdded+'"><td class="iconupdated"></td><td>'+newMsg+'</td></tr></tbody>';
         $j23('table.usermessage').html(content);
     }
     
}

function identifiersettingsenrollWindow(associationid){
    var rootURL = $j23('input[name="rootURL"]').val();
    var path = "index.cfm?event=association.identifierenrollsettingsForBeneficiary&associationid=" + associationid + "&create=0&timeid=" + generateTimeID();
       //cntr=0;
    document.getElementById('ui-dialog-title-jWindow').innerHTML = "Identifier Settings";
    //document.getElementById('jWindowIdentifierSetting').innerHTML = '<table width="100%"><tr><td align="center"><img src="../../images/icons/animated_loading.gif"></td></tr></table>';
    $j23("#jWindowIdentifierSetting").dialog({ dialogClass: 'identifier_settings_class'}); //MCR-206
    $j23("#jWindowIdentifierSetting").dialog('open'); 
    $j23.ajax({
        url: path,
        type: "GET",
        success:function(data){
                if (data.indexOf('index.cfm?event=user.processlogin') > 0) {
                    window.location.href = rootURL+'user.login&oldlocation=' + escape( window.location.href.substr(window.location.href.indexOf('event=')));
                }
                document.getElementById('jWindowIdentifierSetting').innerHTML = data;
                cntr = $j23("#updownlist2 option").length;							
                if(cntr >= 5) {
                    $j23('#uplink2').attr("disabled",true);
                    $j23(".visibleattrlimit").css("display","block");
                }
                            toggleGroup5();
						// BG-249	 
					if($j23("#allowConnect2:checked").val() == 2)
					{
						
                        $j23("#divforRadiobutton_inner_2").css('display', "block");
                        $j23("#divforRadiobutton_inner_3").css('display', "none");
											
					}
					if($j23("#allowConnect3:checked").val() == 3)
					{
						
                        $j23("#divforRadiobutton_inner_3").css('display', "block");
                        $j23("#divforRadiobutton_inner_2").css('display', "none");
				
					}
                    //BG-577 start
                    if($j23(".allowWithApproval_limit:checked")){
                        var value=$j23(".allowWithApproval_limit:checked").val();
                        $j23("#openDateTimePicker_connectallowwithdate_"+value).removeClass('linkdisabed');
                        $j23("#openDateTimePicker_connectallowwithdate_"+value).addClass('openDateTimePickerSettings');
                    }
                    if($j23(".allowWithOutApproval_limit:checked")){
                        var value=$j23(".allowWithOutApproval_limit:checked").val();
                        $j23("#openDateTimePicker_connectallowwithoutdate_"+value).removeClass('linkdisabed');
                        $j23("#openDateTimePicker_connectallowwithoutdate_"+value).addClass('openDateTimePickerSettings')  
                    }
                    //BG-577 end
							
					$j23( ".openDateTimePickerSettings" ).datepicker({
						changeMonth: true,
						changeYear: true,
						yearRange: '1900:2100',
						dateFormat: "m/d/yy",
						maxDate: 0,
						onSelect: function() {
						var id= $j23(this).attr("id");
						var datevalue = document.getElementById(id).value;
                        $j23("#"+id).attr("value",datevalue);//bg-577
				
						document.getElementById("openDateTimePicker_"+id).innerHTML=datevalue;
							 
						}
					});
					$j23(".openDateTimePickerSettings").click(function (e) {
						var id= $j23(this).attr("id").split("_"); 
						console.log(id);
						$j23("input#"+id[1]+"_"+id[2]).datepicker("show");//bg-577
						e.preventDefault();
					});	
                    //bg-577
					$j23('input:radio[name="allowConnect"]').change(function (e) {
						if($j23(".allowConnect:checked").val() == 2 ){


						$j23("#divforRadiobutton_inner_3").css('display', "none");
                        $j23("#checkboxAndTextSection_without_1").css('display', "none");
                        $j23("#checkboxAndTextSection_without_2").css('display', "none");
                        $j23("#divforRadiobutton_inner_2").css('display', "block");
                        $j23("#checkboxAndTextSection_1").css('display', "block");

						
						$j23("#allowWithApproval1").attr('checked', true);					
						$j23(".allowWithOutApproval_limit").attr('checked', false);						
						$j23(".allowWithOutApproval").attr('checked', false);
						
						
						document.getElementById("openDateTimePicker_connectallowwithoutdate_1").innerHTML="Select Date";
						document.getElementById("openDateTimePicker_connectallowwithoutdate_2").innerHTML="Select Date";
						document.getElementById("connectallowwithoutdate_1").value='';
						document.getElementById("connectallowwithoutdate_2").value='';
                        $j23("#allowWithApproval_1").removeAttr('checked');
                        $j23("#allowWithApproval_2").removeAttr('checked');
						$j23("#openDateTimePicker_connectallowwithoutdate_1").removeClass('openDateTimePickerSettings');
						$j23("#openDateTimePicker_connectallowwithoutdate_2").removeClass('openDateTimePickerSettings');
						$j23("#openDateTimePicker_connectallowwithoutdate_1").addClass('linkdisabed');
						$j23("#openDateTimePicker_connectallowwithoutdate_2").addClass('linkdisabed');
												}
						else if ($j23(".allowConnect:checked").val() == 3)
						{
                           
                        $j23("#divforRadiobutton_inner_2").css('display', "none");
                        $j23("#checkboxAndTextSection_1").css('display', "none");
                        $j23("#checkboxAndTextSection_2").css('display', "none");
                        $j23("#divforRadiobutton_inner_3").css('display', "block");
                        $j23("#checkboxAndTextSection_without_1").css('display', "block");

						
						$j23("#allowWithOutApproval1").attr('checked', true);						
						$j23(".allowWithApproval_limit").attr('checked', false);					
						$j23(".allowWithApproval").attr('checked', false);
						
						
						document.getElementById("openDateTimePicker_connectallowwithdate_1").innerHTML="Select Date";
						document.getElementById("openDateTimePicker_connectallowwithdate_2").innerHTML="Select Date";
						document.getElementById("connectallowwithdate_1").value='';
						document.getElementById("connectallowwithdate_2").value='';
                        $j23("#allowWithOutApproval_1").removeAttr('checked');
                        $j23("#allowWithOutApproval_2").removeAttr('checked');
						$j23("#openDateTimePicker_connectallowwithdate_1").removeClass('openDateTimePickerSettings');
						$j23("#openDateTimePicker_connectallowwithdate_2").removeClass('openDateTimePickerSettings');
						$j23("#openDateTimePicker_connectallowwithdate_1").addClass('linkdisabed');
						$j23("#openDateTimePicker_connectallowwithdate_2").addClass('linkdisabed');
												}
						else
						{
                            $j23(".divforRadiobutton_inner").css('display', "none");
                            $j23("a.openDateTimePickerSettings").html('Select Date');
							$j23('input.openDateTimePickerSettings').attr('value','');
							$j23("a.openDateTimePickerSettings").addClass('linkdisabed');
                            $j23("a.openDateTimePickerSettings").removeClass('openDateTimePickerSettings');
                            $j23("#checkboxAndTextSection_1").css('display', "none");
                            $j23("#checkboxAndTextSection_2").css('display', "none");
                            $j23("#checkboxAndTextSection_without_1").css('display', "none");
                            $j23("#checkboxAndTextSection_without_2").css('display', "none");
                           
							$j23(".allowWithApproval").attr('checked', false);
							$j23(".allowWithOutApproval").attr('checked', false);

							$j23(".allowWithApproval_limit").attr('checked', false);
							$j23(".allowWithOutApproval_limit").attr('checked', false);
													}
						e.preventDefault();
					});
                    //bg-577
					

                    $j23('input:radio[name="allowWithApproval"]').change(function (e) {
                        var value = $j23(this).val();
                        if(value == 1){
                            $j23("#checkboxAndTextSection_1").css('display', "block");
                            $j23("#checkboxAndTextSection_2").css('display', "none");            
                            
                            document.getElementById("openDateTimePicker_connectallowwithdate_2").innerHTML="Select Date";
                            $j23("#connectallowwithdate_2").attr("value","");
                            $j23("#allowWithApproval_2").removeAttr('checked');
							$j23("#openDateTimePicker_connectallowwithdate_2").removeClass('openDateTimePickerSettings');
							$j23("#openDateTimePicker_connectallowwithdate_2").addClass('linkdisabed');

                        }else if(value == 2){
                            $j23("#checkboxAndTextSection_2").css('display', "block");
                            $j23("#checkboxAndTextSection_1").css('display', "none"); 

                            document.getElementById("openDateTimePicker_connectallowwithdate_1").innerHTML="Select Date";
                            $j23("#connectallowwithdate_1").attr("value","");
                            $j23("#allowWithApproval_1").removeAttr('checked');
							$j23("#openDateTimePicker_connectallowwithdate_1").removeClass('openDateTimePickerSettings');
							$j23("#openDateTimePicker_connectallowwithdate_1").addClass('linkdisabed');
                        }		
					});
                    $j23('input:radio[name="allowWithOutApproval"]').change(function (e) {
                        
                        var value = $j23(this).val();
                        if(value == 1){
                            $j23("#checkboxAndTextSection_without_1").css('display', "block");
                            $j23("#checkboxAndTextSection_without_2").css('display', "none");  
                         
                            document.getElementById("openDateTimePicker_connectallowwithoutdate_2").innerHTML="Select Date";
                            $j23("#connectallowwithoutdate_2").attr("value","");
							$j23("#allowWithOutApproval_2").removeAttr('checked');
							$j23("#openDateTimePicker_connectallowwithoutdate_2").removeClass('openDateTimePickerSettings');
							$j23("#openDateTimePicker_connectallowwithoutdate_2").addClass('linkdisabed');

                        }else if(value == 2){
                            $j23("#checkboxAndTextSection_without_2").css('display', "block");
                            $j23("#checkboxAndTextSection_without_1").css('display', "none");  
               
                            document.getElementById("openDateTimePicker_connectallowwithoutdate_1").innerHTML="Select Date";
                            $j23("#connectallowwithoutdate_1").attr("value","");
							$j23("#allowWithOutApproval_1").removeAttr('checked');
							$j23("#openDateTimePicker_connectallowwithoutdate_1").removeClass('openDateTimePickerSettings');
							$j23("#openDateTimePicker_connectallowwithoutdate_1").addClass('linkdisabed');
                        }	
                       
					});		

                    $j23('input:checkbox[name="allowWithApproval_limit"]').change(function (e) {

						var Limit_checkbox_value = $j23(this).val();
                        var dateselector =  $j23("#openDateTimePicker_connectallowwithdate_"+Limit_checkbox_value);
                        var dateselector_2 =  $j23("#connectallowwithdate_"+Limit_checkbox_value);
                        var isdisabled = dateselector.hasClass('linkdisabed');
                        if(isdisabled){
                            dateselector.removeClass('linkdisabed');
							dateselector.addClass('openDateTimePickerSettings');
                           
                        }
                        else{
                           dateselector.removeClass('openDateTimePickerSettings');
                            dateselector.html("Select Date");
                            dateselector_2.attr("Value","");
							dateselector.addClass('linkdisabed');
                        }
					});	
                    $j23('input:checkbox[name="allowWithOutApproval_limit"]').change(function (e) {

						var Limit_checkbox_value = $j23(this).val();
                        var dateselector =  $j23("#openDateTimePicker_connectallowwithoutdate_"+Limit_checkbox_value);
                        var dateselector_2 =  $j23("#connectallowwithoutdate_"+Limit_checkbox_value);
                        var isdisabled = dateselector.hasClass('linkdisabed');
                        if(isdisabled){
                            dateselector.removeClass('linkdisabed');
							dateselector.addClass('openDateTimePickerSettings');
                           
                        }
                        else{
                           dateselector.removeClass('openDateTimePickerSettings');
                            dateselector.html("Select Date");
                            dateselector_2.attr("Value","");
							dateselector.addClass('linkdisabed');
                        }
					});	
					//BG-249
					
        },
       error: function(xhr, textStatus, errorThrown) {
               if (xhr.readyState < 4) {
                   xhr.abort();
               }
               else {
                   alert('Error!');
               }
        }
    });
}

function toggleGroup5(){
    if($j23(".allowConnect:checked").val() != 1 || $j23(".allowDisConnect:checked").val() != 1){
        $j23(".group5").show();
    }else{
        $j23(".group5").hide();
    }
}

function submitenrollsettings(){ 
    //$j23(".loader2").css("display","block");
    showLoadingOverlay();
    $j23("#submitenrollsettingbtn").addClass("linkdisabled");
    var selectlist = $j23('#updownlist option').map(function(){return $j23(this).val();}).get().join(',');
    var selectlist2 = $j23('#updownlist2 option').map(function(){return $j23(this).val();}).get().join(',');
    //console.log(selectlist);
    $j23('#attributeidorder').val(selectlist);
    var identifierEnrolltype = $j23('#enrollsettings_form input[type=radio][name=identifierenrolltype]:checked').val();
    var instructionForStaff =$j23('#instructionforstaff').val();
    var instructionForVolunteer =$j23('#instructionforvolunteer').val();
    var hiddendeFaultInstruction =$j23('#hiddendefaultinstruction').val();
    var attributeIdOrder = selectlist;
    var associationId = $j23('input[name="associationid"]').val();
    var path = "index.cfm?event=association.identifierenrollsettingsactionForBeneficiary";
    var dashboardAccessVol = $j23('input[name="dashboardAccessVol"]:checked').val();
    //--- ASSNS-78 ---//
    $j23('#visibleattributeidorder').val(selectlist2);
    var IdentifiresSingularName=$j23('#singularId').val(); 
    var IdentifiresPluralName = $j23('#pluralId').val();
    var ConnectExistingIdentifires = $j23('input[type=radio][name=allowConnect]:checked').val();
    var DisconnectExistingIdentifires= $j23('input[type=radio][name=allowDisConnect]:checked').val();
	// BG-249
	var allowWithApproval = $j23('input[type=radio][name=allowWithApproval]:checked').val();
	var allowWithOutApproval = $j23('input[type=radio][name=allowWithOutApproval]:checked').val();
	var connectallowwithdate=$j23('#connectallowwithdate_'+allowWithApproval).val(); //BG-577
	var connectallowwithoutdate=$j23('#connectallowwithoutdate_'+allowWithOutApproval).val(); //BG-577
	// BG-249
	var AllowAddIdentifierFromVolunteerProfile= $j23('input[type=radio][name=AllowAddIdentifierFromVolunteerProfile]:checked').val(); 
    var aliaspattern = /^[a-z\d\_(),\*-_.~&\s']+$/i;
    var isValid = true;
	var checkallowdate='';
	var checkallowdate1='';
    var accessCPMSGFromIdentifiers = $j23('input[name="accessCPMSGFromIdentifiers"]:checked').val();//CPORT-116
	if($j23("#allowWithApproval_"+allowWithApproval).is(":checked") ){//BG-577
		checkallowdate=$j23('#connectallowwithdate_'+allowWithApproval).val();
		if(checkallowdate.length == 0)
		{
			alert('Please select date for "Limit display of identifiers created on or after"');//BG-577
			$j23("#submitenrollsettingbtn").removeClass("linkdisabled");
        		hideLoadingOverlay();
			return false;
		}
	}
	if($j23("#allowWithOutApproval_"+allowWithOutApproval).is(":checked")){//BG-577
		checkallowdate1=$j23('#connectallowwithoutdate_'+allowWithOutApproval).val();
		if(checkallowdate1.length == 0)
		{
			alert('Please select date for "Limit display of identifiers created on or after"');//BG-577
			$j23("#submitenrollsettingbtn").removeClass("linkdisabled");
        		hideLoadingOverlay();
			return false;

		}
	}

    if($j23("#sortattr").is(":checked"))
    {
    selectlist2 = JSON.parse("[" + selectlist2 + "]");
    }
    var visibleattributeidorder = selectlist2.toString();
    //console.log(selectlist2,identifierEnrolltype, instructionForStaff, instructionForVolunteer, hiddendeFaultInstruction, attributeIdOrder, associationId, dashboardAccessVol,IdentifiresSingularName,IdentifiresPluralName,ConnectExistingIdentifires,DisconnectExistingIdentifires,visibleattributeidorder);
    //--- ASSNS-168 ---//
    var Allowenroll= $j23("input[name=allowenroll]").val();

    var alphabeticFilter = $j23('#alphabeticFilter').val();
    var searchfilter = $j23('#str_search').val();
    var int_start_row = $j23('#int_next_start_row').val();
    var sortColumn = $j23('#sortColumn').val();
    var sortType = $j23('#sortType').val();  
    var bit_push_assnid = 1;                
    
    var postData = $j23('body').data('formdata');    
    $j23(postData).each(function(i){
        if(postData[i]['name'] == "alphabeticFilter") {
            postData[i]['value'] = alphabeticFilter;
        } else if (postData[i]['name'] == "searchfilter") {            
            postData[i]['value'] = searchfilter;
        } else if (postData[i]['name'] == "sort_column") {
            postData[i]['value'] = sortColumn;
        } else if (postData[i]['name'] == "sort_type") {
            postData[i]['value'] = sortType;
        }else if (postData[i]['name'] == "int_start_row") {
            postData[i]['value'] = 1;
        }else if (postData[i]['name'] == "associationid") {
            postData[i]['value'] = associationId;
            bit_push_assnid = 0;
        }
    });

    if(bit_push_assnid == 1){
        postData.push({
            "name": "associationid",
            "value": associationId
        });
    } 

    if(!IdentifiresSingularName.match(aliaspattern))
    {       
        alert('Please enter a valid Singular Name.\n\nThe following characters are allowed: letters, numbers, spaces, parentheses, commas, hyphens, underscores, ampersands, and periods.'); 
        isValid = false;
        //$j23(".loader2").css("display","none");
        $j23("#submitenrollsettingbtn").removeClass("linkdisabled");
        hideLoadingOverlay();
    }
    else if(!IdentifiresPluralName.match(aliaspattern))
    {
        alert('Please enter a valid Plural name.\n\nThe following characters are allowed: letters, numbers, spaces, parentheses, commas, hyphens, underscores, ampersands, and periods.'); 
        isValid = false;
        //$j23(".loader2").css("display","none");
        $j23("#submitenrollsettingbtn").removeClass("linkdisabled");
        hideLoadingOverlay();
    }
    else if(isValid == true)
    {
    $j23.ajax({
        url: path,
        type: "POST",
        data: {
            identifierenrolltype: identifierEnrolltype,
            instructionforstaff: instructionForStaff,
            instructionforvolunteer: instructionForVolunteer,
            hiddendefaultinstruction: hiddendeFaultInstruction,
            attributeidorder: attributeIdOrder,
            associationid: associationId,
            dashboardaccessvol: dashboardAccessVol,
            //--- ASSNS-78 ---//
            IdentifiresSingularName:IdentifiresSingularName,
            IdentifiresPluralName:IdentifiresPluralName,
            ConnectExistingIdentifires:ConnectExistingIdentifires,
            DisconnectExistingIdentifires:DisconnectExistingIdentifires,
            visibleattributeidorder:visibleattributeidorder,
            //--- ASSNS-168 ---//
            Allowenroll:Allowenroll,
			// BG-249
			connectallowwithdate:connectallowwithdate,
			connectallowwithoutdate:connectallowwithoutdate,
			allowWithApproval:allowWithApproval,
			allowWithOutApproval:allowWithOutApproval,
			// BG-249
			AllowAddIdentifierFromVolunteerProfile:AllowAddIdentifierFromVolunteerProfile
            ,accessCPMSGFromIdentifiers: accessCPMSGFromIdentifiers,//CPORT-116
        },
        datatype:"json",
        async: false,        
        success:function(data){
            data= JSON.parse(data);
            if(data.flag == 1)
            {
                //alert(data.userMsg);
                //$j23(".loader2").css("display","none");
                $j23("#jWindowIdentifierSetting").dialog('close');				
                $j23('.instructionformatcontainer').html($j23('#instructionforstaff').val());
                $j23('.identSingName').text(IdentifiresSingularName);
                $j23('.identPluName').text(IdentifiresPluralName);
                $j23('#identifier_singular_name').val(IdentifiresSingularName);
                $j23('#identifier_plural_alias').val(IdentifiresPluralName);
                $j23('#frm_identifier_list #str_search').attr('title','Filter by '+IdentifiresSingularName);
                $j23('#frm_identifier_list #str_search').attr('placeholder','Filter by '+IdentifiresSingularName);
            }else{
                alert(data.userMsg);
                //$j23(".loader2").css("display","none");
                hideLoadingOverlay();
                $j23("#submitenrollsettingbtn").removeClass("linkdisabled");
            }
           
        },
        complete:function(data){
            console.log(data.responseText);
            data = JSON.parse(data.responseText);
            if(data.flag == 1)
            {                
                loadIdentifiersList(postData,"");
               
                var content = '<tbody><tr class="identifier_setting_updated"><td class="iconupdated"></td><td>'+data.userMsg+'</td></tr></tbody>';
                $j23('table.usermessage').html(content);
                $j23(".newAssocItemDiv").html('');
                
            }
        },
        error:function(){
            $j23("#jWindowIdentifierSetting").dialog('close');
            alert('Oops...mistake on server');
            $j23("#submitenrollsettingbtn").removeClass("linkdisabled");
            hideLoadingOverlay();
            return false;
        }
    });    
    } //end of isValid condition
}

var cntr=0;	
function getMultipleSelectedValue(x,check)
{
 cntr = $j23("#updownlist2 option").length;	
      for (var i = 0; i < x.options.length; i++) {
         if(x.options[i].selected ==true){
              var id = x.options[i].value;
			  if(check==1)
			  {
				  var accattr=x.options[i].text;
				  $j23(x.options[i]).css("display","none");
				  $j23(x.options[i]).removeAttr('selected');
				  $j23("#updownlist2").append('<option value='+id+'>'+accattr+'</option>');
				  cntr ++;
				  if (cntr >= 5) {
					$j23('#uplink2').attr("disabled",true);
					$j23(".visibleattrlimit").css("display","block");
				  }
			  }
			  if(check==2)
			  {
			  	$j23(x.options[i]).remove();
		  		$j23(".nonvisibleattr option[value="+id+"]").css("display","block");
			  }
          }
      }
   
}

function popUp(URL){
    day = new Date();
    //id = day.getTime();
    id = day.getDate();				
    eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=775,height=375,left = 265,top = 175');");
}

function checkForDelete(){
    
    var assnId = $j23('input[name="associationid"]').val();
    var path = "index.cfm?event=association.checkForDeleteBeneficiary";
    $j23.ajax({
        url: path,
        type: "GET",
        data: {
            associationid: assnId
        },
        async: false,
        success:function(response){
            			
            if(! parseInt(response.trim())){					
                $j23('#deleteAssociation').show();	
            }
            else{
                $j23('#deleteAssociation').hide();
            }
        },
        error: function(xhr, status, error) 
        {
        var err = eval("(" + xhr.responseText + ")");
        //console.log(err.Message);
        alert('Oops...mistake on server');
        hideLoadingOverlay();
        return false;
        }
        //Bugfix 545 Staging Issue
        
    });
}

function checkIfDeleteAllShouldBeEnabled(){
    var url = "index.cfm?event=association.checkAssignmentDetailsByIdForBeneficiary";
    var data= {};
    //var dataArr = [];
    var associationid = $j23('.associationid').val();
    
    data.associationid = associationid;
    data.requesttype="deleteall";
    
    
    $j23.post(url,data, function(data){
       
        if(data){
            $j23("#deleteall").prop("disabled",true);
            $j23("#deleteall").css("display","none");
        }else{
            $j23("#deleteall").prop("disabled",false);
            $j23("#deleteall").css("display","");
        }
    },"json");

    $j23('#sel_action option:eq(0)').prop('selected', true);
    /* $j23(".identcheckbox").prop('checked',false); */ //BG-697

}

function checkAssignmentDetails(){
    var url = "index.cfm?event=association.checkAssignmentDetailsByIdForBeneficiary";
    var data= {};
    var dataArr = [];
    var associationid = $j23('.associationid').val();
    dataArr = $j23.map($j23(".identcheckbox:checked"),function(v, i){
        return v.value;
    });
    
    data.associationitemidList = dataArr.toString();
    data.associationid = associationid;
    data.requesttype="delete";

    
    $j23.post(url,data, function(data){
        if(data){ 
            $j23("#delete").prop("disabled",true);            
            
        }else{
            $j23("#delete").prop("disabled",false);
            
        }
    },"json");

    var checkClasses = $j23.map($j23(".identcheckbox:checked"),function(v, i){
        
        return $j23(v).prop("class");
    });

    var allClasses = checkClasses.join();
    if(allClasses.search("showArchive")> 0 && allClasses.search("showRestore") > 0){
        $j23("#archive").prop("disabled",true);
        $j23("#restore").prop("disabled",true);
        
    }else if(allClasses.search("showArchive")> 0){
        $j23("#restore").prop("disabled",true);        
        $j23("#archive").prop("disabled",false);        
    }else if(allClasses.search("showRestore") > 0){
        $j23("#archive").prop("disabled",true);        
        $j23("#restore").prop("disabled",false);        
    }else{
        $j23("#archive").prop("disabled",false);
        $j23("#restore").prop("disabled",false);        
    }
}

function getIdentStatuscount(requstedkey){
    var identarray=[];
    var identnamesarray=[];
	var action= "";
    var associationId= $j23('input[name="associationid"]').val();
    var identifierPluralName = $j23('#identifier_plural_alias').val();
    var root = $j23('input[name="rootURL"]').val();

    // CPORT-54, Start, 12-05-2019
    var identifierSingularAlias = $j23('#identifier_singular_name').val();
    if(identifierSingularAlias == ''){
       identifierSingularAlias = "Identifier";
    }
    // CPORT-54, End, 12-05-2019

	switch(requstedkey)
	{
		case 'delete' :
		        action = requstedkey;			
				$j23('.showRemove:checked').each(function (i, el) {
                         identarray.push(el.value);
                         identnamesarray.push($j23(".identcheckbox_"+el.value).text());
					 });
				if(identarray.length != 0 && action != "" && action != "archiveall")
				{
                    $j23(".identstatusdropdown").prop("disabled", true);
                    //console.log(identnamesarray);
				    changeAssociationItem(associationId,identarray,action,identnamesarray);
				}
				else
				{
					alert("Please select at least one "+identifierSingularAlias+" for this action.");    // CPORT-54, 12-05-2019
					$j23('#sel_action').prop('selectedIndex',0);//Code Added by dikendra 15june2018 reset select action dropwown
				}
			    break;
		case 'deleteall' : 
					/* ASSNS-544 */
		 			document.getElementById('jWindow').innerHTML="";
					document.getElementById('ui-dialog-title-jWindow').innerHTML = "";
					$j23("#jWindow").css({'padding':'20px','font-size':'13px'}); 
					$j23("#jWindow").dialog('open'); 
					//$j23(".ui-dialog").css({"width": "400px", "height": "200px","left": "35%","top": "30%",}); 
					$j23(".ui-dialog").css({"width": "410px", "height": "150px","left": "35%","top": "30%"});
					$j23('.ui-dialog').position({my: 'center',at: 'center',of: window,collision: 'fit'});		
					
                    $j23.ajax({
					url: "index.cfm?event=association.archivealldeleteallconfirmforBeneficiary&type=deleteall&pluralname="+identifierPluralName.toLowerCase(),
					type: "GET",
					success:function(data){
						document.getElementById('jWindow').innerHTML = data;
					},
					complete:function()
					{
							$j23("#confirmdelete").click(function(){
								action = requstedkey;								
								/* var values = $j23('.showRemove').map(function () {
								identarray.push($j23(this).val());								
                                }).get(); */
                                $j23("#confirmdelete").addClass("linkdisabled");
                                /* Start : A/D/R bug fix, added on 08-12-2019 */
                                identarray.push($j23("#deleteidentifierslist").val());
                                /* End : A/D/R bug fix, added on 08-12-2019 */																	
                                $j23(".identstatusdropdown").prop("disabled", true);                                
									changeAssociationItem(associationId,identarray,action);
								$j23("#jWindow").dialog('close'); 
							});

							$j23(".confirmcancle").click(function(){
								$j23("#jWindow").dialog('close'); 
							});
					},
					error:function(){
						ColdFusion.Window.destroy("reminderWindow"); 
                        alert('Oops...mistake on server');
                        hideLoadingOverlay();
						return false;
					}
				}); /* ASSNS-544 */   
			    break;
		case 'archive' :
		        action = requstedkey;
				$j23('.showArchive:checked').each(function (i, el) {
                     identarray.push(el.value);
                     identnamesarray.push($j23(".identcheckbox_"+el.value).text());
				 });
				 if(identarray!="" && action!="" && action!="archiveall")
				{
					$j23(".identstatusdropdown").prop("disabled", true);
					
					/* <!--- Start: BG-1 ---> */
					var data = [];
					data.push({
						"name": "associationitemid",
						"value": identarray //json.stringify(identarray)
					});
					data.push({
						"name": "associationid",
						"value": associationId
					});
					$j23.fn.loadDialogContent = function (url) {
						this.load(url, {}, function (response, status, xhr) {
							loadStatusHandler(status);
						});
					}
					$j23.ajax({
						type: "POST",
						url: "index.cfm?event=association.checkIdentifierVolunteerAssignmentBeneficiary",//&associationitemid=" + identarray
						data: data,
						beforeSend: function() {
							//$j23(".loader1").fadeOut("slow");
							//showLoadingOverlay();
						},
						success: function(result) {							
							result = JSON.parse(result);				
							if (result.volunteercount > 0) {					
								$dialog.archiveIdentifierConfirm.dialog('open')
							.html($loadingImageTable)
							.loadDialogContent(root + "association.archiveidentifierconfirmationlistBeneficiary&associationitemid="+identarray+"&associationid="+associationId);
							} else {
								changeAssociationItem(associationId,identarray,action);
							}
						}, 
						complete:function(data){                
							//hideLoadingOverlay();			
						},
						error: function(data) {
                            status = false;
                            alert("error");
                            hideLoadingOverlay();
						}		  
						/**/
					}); 
					//changeAssociationItem(associationId,identarray,action)					
					/* End: BG-1 */
				}
				else
				{
				alert("Please select at least one "+identifierSingularAlias+" for this action.");    // CPORT-54, 12-05-2019
				$j23('#sel_action').prop('selectedIndex',0);//Code Added by dikendra 15june2018 reset select action dropwown
				}
				break;
		case 'archiveall' :
					/* ASSNS-544 */
					document.getElementById('jWindow').innerHTML="";
					document.getElementById('ui-dialog-title-jWindow').innerHTML = "";
					$j23("#jWindow").css({'padding':'20px','font-size':'13px'}); 
					$j23("#jWindow").dialog('open'); 
					//$j23(".ui-dialog").css({"width": "400px", "height": "200px","left": "35%","top": "30%",});  
					$j23(".ui-dialog").css({"width": "410px", "height": "150px","left": "35%","top": "30%"});
					$j23('.ui-dialog').position({my: 'center',at: 'center',of: window,collision: 'fit'});
					$j23.ajax({
					url: "index.cfm?event=association.archivealldeleteallconfirmforBeneficiary&type=archiveall&pluralname="+identifierPluralName.toLowerCase(),
					type: "GET",
					success:function(data){
						document.getElementById('jWindow').innerHTML = data;
					},
					complete:function()
					{
							$j23("#confirmarchive").click(function(){
								action = requstedkey;								
								/* var values = $j23('.showArchive').map(function () {
								identarray.push($j23(this).val()) ;								
                                }).get(); */
                                $j23("#confirmarchive").addClass("linkdisabled");
                                /* Start : A/D/R bug fix, added on 08-12-2019 */
                                identarray.push($j23("#archiveidentifierslist").val());
                                /* End : A/D/R bug fix, added on 08-12-2019 */															
								$j23(".identstatusdropdown").prop("disabled", true);
								changeAssociationItem(associationId,identarray,action);
								$j23("#jWindow").dialog('close'); 
							});	
							$j23(".confirmcancle").live("click",function(){
								$j23("#jWindow").dialog('close'); 
							});
					},
					error:function(){
						ColdFusion.Window.destroy("reminderWindow"); 
                        alert('Oops...mistake on server');
                        hideLoadingOverlay();
						return false;
					}
				});/* ASSNS-544 */
				break;    
		case 'restore' :
		        action = requstedkey;
				$j23('.showRestore:checked').each(function (i, el) {
                     identarray.push(el.value);
                     identnamesarray.push($j23(".identcheckbox_"+el.value).text());
				 });
				 if(identarray!="" && action!="" && action!="archiveall")
				{
					$j23(".identstatusdropdown").prop("disabled", true);
					changeAssociationItem(associationId,identarray,action);
				}
				else
				{
				alert("Please select at least one "+identifierSingularAlias+" for this action.");    // CPORT-54, 12-05-2019
				$j23('#sel_action').prop('selectedIndex',0);//Code Added by dikendra 15june2018 reset select action dropwown
				} 
			    break;
		case 'restoreall' :
		 		action = requstedkey;
				/* var values = $j23('.showRestore').map(function () {
				  identarray.push($j23(this).val()) ;
                }).get(); */
                /* Start : A/D/R bug fix, added on 08-12-2019 */
                identarray.push($j23("#restoreidentifierslist").val());
                /* End : A/D/R bug fix, added on 08-12-2019 */
				if(identarray!="")
				{
					$j23(".identstatusdropdown").prop("disabled", true);
					changeAssociationItem(associationId,identarray,action);
				}
				else
				{
				alert("Please select at least one "+identifierSingularAlias+" for this action.");    // CPORT-54, 12-05-2019
				$j23('#sel_action').prop('selectedIndex',0);//Code Added by dikendra 15june2018 reset select action dropwown
				} 
			    break;
		
	}
			
	
}

function changeAssociationItem(associationid,associationitemid,action,name){
    
    var alphabeticFilter = $j23('#alphabeticFilter').val();
    var searchfilter = $j23('#str_search').val();
    var int_start_row = $j23('#int_next_start_row').val();
    var sortColumn = $j23('#sortColumn').val();
    var sortType = $j23('#sortType').val();
    var bit_push_assnid = 1;
    var postData = $j23('body').data('formdata');    
    $j23(postData).each(function(i){
        if(postData[i]['name'] == "alphabeticFilter") {
            postData[i]['value'] = alphabeticFilter;
        } else if (postData[i]['name'] == "searchfilter") {            
            postData[i]['value'] = searchfilter;
        } else if (postData[i]['name'] == "sort_column") {
            postData[i]['value'] = sortColumn;
        } else if (postData[i]['name'] == "sort_type") {
            postData[i]['value'] = sortType;
        }else if (postData[i]['name'] == "int_start_row") {
            postData[i]['value'] = 1;
        }else if (postData[i]['name'] == "associationid") {
            postData[i]['value'] = associationid;
            bit_push_assnid = 0;
        }    
    });

    if(bit_push_assnid == 1){
            postData.push({
                "name": "associationid",
                "value": associationid
            });
        } 
    
    //path = "index.cfm?event=association.actionOnBeneficiaryItems&associationid=" + associationid + "&action=" + action + "&associationitemid=" + associationitemid /* + '&' +$j23('#exportTableView').serialize() */;
    path = "index.cfm?event=association.actionOnBeneficiaryItems&associationid=" + associationid + "&action=" + action;  //BG-70
    confirmVal = true;
    var pdata = [];
    /* <!--- Start: BG-1 ---> */
    if (action === 'archive'){
        //pdata = [];
        var volunteerAssignMaintained =$j23(".maintainIdnVolassign").val();
        pdata.push({
            "name": "volunteerAssignMaintained",
            "value": volunteerAssignMaintained
        });
       $j23('#closeDialog').trigger('click');
    }			 
    /* <!--- End: BG-1 ---> */
    /* ----- BG-70 Start ----- */
    pdata.push({
        "name": "associationitemid",
        "value": associationitemid
    });
    /* ----- BG-70 End ----- */
    
    if(confirmVal)
    {
       $j23.ajax({
            url: path,
            type: "POST",
            data: pdata,/* <!--- BG-1 ---> */
            //async: false,
            beforeSend: function() {
                showLoadingOverlay();
            },
            success:function(data){                
                data = JSON.parse(data);
                //console.log(data);
                
                var classAdded = 'stop';
                if(data.res == "delete" || data.res == "deleteAll" || data.res == "archive" || data.res == "archiveall" || data.res == "restore" || data.res == "restoreall")
                {
                    alert(data.msg.trim().replace(/<br>/g,'\n'));
                    $j23('#sel_action').prop('selectedIndex',0);
                    
                    ResetUserMessage();    
                    $j23("#newMsg").val(data.msg.trim());
                    var content = '<tbody><tr class="'+classAdded+'"><td class="iconupdated"></td><td>'+data.msg.trim()+'</td></tr></tbody>';
                    $j23('table.usermessage').html(content);
                    $j23(".identstatusdropdown").prop("disabled", false);
                    $j23(".newAssocItemDiv").html('');  

                    /* if(data.res == "delete"){
                        var y = all_iden_arrList;                        
                        y = y.filter( ( el ) => !name.includes( el ) );
                        all_iden_arrList = y;
                        $j23('#str_search').autocomplete("option", { source: all_iden_arrList});
                    } */

                    loadIdentifiersList(postData,"");
                    
                }               
               
            },
            error:function(){ 
                alert('Oops...mistake on server');
                hideLoadingOverlay();
                return false;
            }
        });
        
    }
}

function selectActionReset() {
	$j23(".identstatusdropdown").prop("disabled", false);
	$j23("#sel_action option[value='0']").prop('selected', true);
 }

 function loadStatusHandler(status) {
    if (status == "error") {
        var msg = "Sorry but there was an error.";
        // handledAlert(msg);
    }
}

function dialogSettings(title, dialogClass, maxWidth, width, maxHeight, height) {
    return {
        modal: true,
        title: title,
        resizable: false,
        maxWidth: ( maxWidth === undefined ) ? 500 : maxWidth,
        maxHeight: ( maxHeight === undefined ) ? 500 : maxHeight,
        width: ( width === undefined ) ? 350 : width,
        height: ( height === undefined ) ? 350 : height,
        autoOpen: false,
        position:['center',50],
        dialogClass:dialogClass
    }
}

function showHideDivs(divid)
{	
	display = $j23('#'+divid).css("display");
	if(display == "block")
	{
		$j23(document).find('#'+divid).slideUp(200);
	}
	else
	{
		$j23(document).find('#'+divid).slideDown(200);
	}
}

function changeEnrolledVisibleNew(){
    if($j23('input[name="enrolledVolunteersNew"]:checked').val() == 0){
        $j23('tr.tutorsList.hidden').each(function(){
            $j23(this).removeClass('hidden');
        });
    }else{
        $j23('tr.tutorsList.notenrolled').each(function(){
            $j23(this).removeClass('hidden').addClass('hidden');
          //  $j23(this).find('input[type="checkbox"]').prop('checked','');
        });
        $j23('tr.tutorsList.enrolled').each(function(){
            $j23(this).removeClass('hidden');
        });
    }
    
}	
function renderOddEvenRowsNew(){
    var counter = 1;
    $j23('tr.tutorsList').each(function(){
        if(! $j23(this).hasClass('hidden')){
            if(( counter % 2 ) == 1 )
                $j23(this).removeClass('oddrow evenrow').addClass('oddrow');
            else
                $j23(this).removeClass('oddrow evenrow').addClass('evenrow');
            counter++;
        }
    });
}
function adjustHeightVolunteerListNew(){
    var defaultDivHeight = $j23.trim($j23('#hdn_DivHeightCal').val());
    var tableHeight = $j23('#div_selectedTutorsTable').height();	
    var divHeight = $j23('#div_selectedTutors').height();
    if( tableHeight < divHeight ){
        $j23('#div_selectedTutors').height(tableHeight + 'px')
    }else{
        $j23('#div_selectedTutors').height(defaultDivHeight + 'px')
    }
}
function changeLinkTextNew(){
    var newText = $j23('#a_showHideLinkNew').attr('rel');
    var newRel = $j23('#a_showHideLinkNew').text();
    $j23('#a_showHideLinkNew').attr('rel',newRel).text(newText);
    
}
function changeRowClassNew(obj){ 
    if($j23(obj).prop('checked'))
        $j23(obj).parent().parent().addClass('selected');
    else
        $j23(obj).parent().parent().removeClass('selected');
    if($j23('input.chkbx_TargetedTutors:visible:checked').length == 0 && $j23('#a_showHideLinkNew').hasClass('hide')){
        changeEnrolledVisibleNew();
        changeLinkTextNew();
        adjustHeightVolunteerListNew();
        renderOddEvenRowsNew();
        $j23('#a_showHideLinkNew').removeClass('hide').addClass('show');
    }
}
function displayselectedvolNew() {	
    if($j23('tr.tutorsList.selected').length > 0){
        if($j23('#a_showHideLinkNew').hasClass('show')){
        
            $j23('#a_showHideLinkNew').addClass('hide').removeClass('show');
            $j23('tr.tutorsList').each(function(){
                if(!$j23(this).hasClass('selected'))
                    $j23(this).addClass('hidden');
            });
        }else{
            $j23('#a_showHideLinkNew').removeClass('hide').addClass('show');
            changeEnrolledVisibleNew();
        }
        changeLinkTextNew();
        adjustHeightVolunteerListNew();
        renderOddEvenRowsNew();
    }
}

function toggleSelect(){
    //console.log($j23('.viewattributes').length > $j23('.viewattributes:checked').length);    
    if(($j23('#updateTableView input[name="viewattributes"]').length > $j23('#updateTableView input[name="viewattributes"]:checked').length) || ($j23('.viewattributes').length > $j23('.viewattributes:checked').length)){
        $j23('a.selectNone').text('Select All');
        $j23('a.selectNone').removeClass('selectNone selectAll').addClass('selectAll');
    }else{
        $j23('a.selectAll').text('Select None');
        $j23('a.selectAll').removeClass('selectNone selectAll').addClass('selectNone');
    }
}     

function changeAttr(panelId,subPanelId)
{	
    if($j23(".attrSubChekBox_"+subPanelId).prop("checked") == true)
    {	
        $j23("#assignsubcheckbox_"+subPanelId).prop("checked",true);
    }
    else
    {
        
    }       
}

/* BG-34 (Added for ASSNS-545 View fix) Start */
function ajaxCallForView(obj) {
    var identifier_plural_alias = $j23("#identifier_plural_alias").attr("value");
    var attridVal= $j23(obj).val();
    var assnId = $j23('input[name="associationid"]').val();
    var userroletype = $j23("#userroletype").attr("value");
    var allowedsections = $j23("#allowedsections").attr("value");
    var currentuserid = $j23("#currentuserid").attr("value");
    var programid = $j23("#programid").attr("value");

       
    showLoadingOverlay();//BG-52
    
    if(attridVal != ''){
        //var targetURL = "index.cfm?event=association.getAttributeValBasedAssociations_BreakOutAjax" BG-110
        var targetURL = "index.cfm?event=association.getAttributeValBasedAssns_BreakOut_Benefeciary";
    }
    return $j23.ajax({
        type: "post",
        cache:false,			
        dataType: "json",
        data: {
            attrid:attridVal,
            associationid: assnId,
            userroletype: userroletype,
            allowedsections: allowedsections,
            currentuserid: currentuserid,
            programid: programid,
            },
        url: targetURL,			
        error: function(data) {
            alert("error"); 
            return false; 
            },
        success: function(data) 
        { 
            //console.log(data);	
            if(attridVal != ''){
                $j23('.filteredAssociationList').html('');
                var counter = 1;
                var dataHTML="";
                if(data.length > 0)
                {
                    dataHTML = dataHTML + '<div class="padding-top-5"><a id="selectattrid" class="Select_All">Select All</a></div>';
                }
                else
                {
                    dataHTML = dataHTML + '<span id="spanWithMsg" style="display:block; color:red; width:338px;">This Field does not yet have any options or connected '+identifier_plural_alias+'.<span>';
                }
                dataHTML = dataHTML + '<table width="100%" style="padding:0px 0px 5px;">';
                
                var deciderflag = false;
                $j23.each(data, function(index, attribute) {
                    if(typeof attribute.filterArray !== "undefined")
                    {
                        deciderflag = true;
                    }
                });
                
                if(deciderflag == true)
                {	
                    var filterArrayObj = data[1]["filterArray"];
                    //console.log(filterArrayObj.DATA);
                    var array_Length = filterArrayObj.DATA.length;
                    for(i=0;i<array_Length;i++)
                    {
                        //console.log(filterArrayObj.DATA[i]);	
                        var originaldata = filterArrayObj.DATA[i][3];
                        var displaydata = originaldata;
                        //polyfill for IE Version 11
                        Number.isInteger = Number.isInteger || function(value) {
                            return typeof value === "number" && 
                                isFinite(value) && 
                                Math.floor(value) === value;
                        };

                        if(!Number.isInteger(filterArrayObj.DATA[i][3]))
                        {
                            displaydata = displaydata.replaceAll("$squote$", "'"); // MV-1381 Added By KC
                            displaydata = displaydata.replaceAll("$dquote$", '"'); // MV-1381 Added By KC
                        }

                        if(parseDate(displaydata,"opt1")){
                            displaydata = new Date(displaydata);
                            displaydata = displaydata.getMonth()+1 + "/" + displaydata.getDate() + "/" + displaydata.getFullYear();
                            originaldata = displaydata;
                        }
                    
                        var attribute_id = filterArrayObj.DATA[i][1];
                        var isenable = filterArrayObj.DATA[i][7];
                        var ishidden = filterArrayObj.DATA[i][8]; /* Production Fix InActive Option ASSNS-545 */
                        //console.log("ishidden : "+ishidden+" ,isenable : "+isenable);
                        var csstext = "display:inline-block;";
                        var disabledValue = "";
                        var valforclass = "class_0";
                        var display_message = '';
                        if(ishidden != null)//Qualitative Single & Multi Select
                        {
                            if(isenable == 0 && ishidden == 0){
                            display_message = '(No Connected '+identifier_plural_alias+')';
                            disabledValue = "disabled";
                            }
                            else if(ishidden == 1 && isenable == 1){
                                display_message = '(Inactive Option)';
                                disabledValue = "";
                                var filterid_label = document.getElementById("filterid_"+originaldata.replace(/\s/g, '_'));
                                $j23(filterid_label).css("display","inline-block");
                            }
                            else if(isenable == 0 && ishidden == 1){
                                display_message = '(Inactive and No Connected '+identifier_plural_alias+')';
                                disabledValue = "disabled";
                            }
                            
                            if((isenable == 1 && ishidden == 0) || (ishidden == 0 && isenable == 1) || (isenable == 1 && ishidden == 0))
                            {
                                csstext = "display:none;";
                                valforclass = "class_1";
                                display_message = "";
                            } 
                        }
                        else //Quantitative Single & Multi Select
                        {	
                            display_message = '(No Connected '+identifier_plural_alias+')';
                            disabledValue = "disabled";
                            if(isenable == 1){
                                csstext = "display:none;";
                                valforclass = "class_1";
                                display_message = "";
                                disabledValue = "";
                            }
                        }
                        
                        dataHTML = dataHTML + '<tr><td colspan="2" style="padding-top:3px; padding-bottom:3px"><div style="position:relative;padding-left: 13px;">';
                        dataHTML = dataHTML + '<div class="select_attr_checkBox" style="position: absolute;left: 0;top:0;float: none;"><span style="overflow: initial;"><input type="checkbox" id="'+attribute_id+'_'+originaldata+'" name="breakOutAttrchkBox" class="breakOutAttrchkBox '+valforclass+'" value="'+originaldata+'"'+disabledValue+'></span></div>';
                        dataHTML = dataHTML + '<div><lable class="optattrcenter">'+displaydata+' <span style="color:red;float:none;margin-left:0;margin-top:0;overflow: initial;'+csstext+'" class="msglabel" value="'+originaldata+'">'+display_message+'</span></lable>';/* <!--- JN:545---><!--- Production Fix-1 545 ---> */
                        dataHTML = dataHTML + '</div></div></td></tr>';	 
                        
                        counter = counter + 1;						
                    }
                        
                }
                else if(deciderflag == false)
                {	
                    $j23.each(data, function(index, attribute) 
                    {	
                        var displaydata = attribute.attrVal;
                        if(typeof displaydata !== 'undefined')
                        {
                            /* Phone Number 20 Digit Fix ASSNS-545 */
                            if(displaydata.charAt(0) == "~")
                            {
                                displaydata = displaydata.substring(1,displaydata.length);
                            }
                            
                            //polyfill for IE Version 11
                            Number.isInteger = Number.isInteger || function(value) {
                                return typeof value === "number" && 
                                    isFinite(value) && 
                                    Math.floor(value) === value;
                            };

                            if(!Number.isInteger(displaydata))
                            {	
                                //displaydata = displaydata.replace("$squote$", "'");
                                //displaydata = displaydata.replace("$dquote$", '"');
                                    
                                if(isValidDateString(displaydata)){
                                    displaydata = new Date(displaydata);
                                    displaydata = displaydata.getMonth()+1 + "/" + displaydata.getDate() + "/" + displaydata.getFullYear();
                                    //console.log(displaydata);										
                                }
                            }
                            //BG-577 start
                            var isArchive = attribute.isArchive;
                            var displaydata_label = displaydata;
                            if(typeof isArchive != "undefined"){
                                if(isArchive == true){
                                     displaydata_label = displaydata + ' (Archived)';
                                }
                            }
                            //BG-577 end
                            
                            
                            //console.log(attribute);		
                            dataHTML = dataHTML + '<tr><td colspan="2" style="padding-top:3px; padding-bottom:3px">';
                            dataHTML = dataHTML + '<div class="select_attr_checkBox"><span><input type="checkbox" id="'+attribute.attrid+'_'+displaydata+'" name="breakOutAttrchkBox" class="breakOutAttrchkBox" value="'+displaydata+'"></span></div>';
                            dataHTML = dataHTML + '<lable style="float:left;margin-left: 10px; margin-top:0px;width: 270px;">'+displaydata_label+'</lable><label style="color:red" class="msglabel" value="'+displaydata+'"></label>'; // BG-577 Class Name Changes
                            dataHTML = dataHTML + '</td></tr>';	
                            /* 
                            $j23.each(attribute.assolist, function(index, association) {
                                dataHTML = dataHTML + '<tr><td valign="top" width="20"><label value="'+association.assoId+'">"'+association.assoId+'"</label></td></tr>';
                            }); 
                            */
                            counter = counter + 1;		
                        }					
                    });
                }
                
                dataHTML = dataHTML + '</table><div class="clear">&nbsp;</div>';
                $j23('.filteredAssociationList').html(dataHTML);
            }
            else
            {
                var dataHTML = '<table width="100%">';					
                $j23('.filteredAssociationList').html(dataHTML);
            }
            
            $j23("#selectattrid").click(function(){
                if($j23(this).hasClass("Select_All")){
                    $j23(".breakOutAttrchkBox").prop("checked",true);
                    $j23(this).removeClass("Select_All");
                    $j23(this).addClass("Select_None");
                    $j23(this).text("Select None");
                    //$j23(this).addClass("selected");
                }
                else if($j23(this).hasClass("Select_None")){
                    $j23(".breakOutAttrchkBox").prop("checked",false);
                    $j23(this).removeClass("Select_None");
                    $j23(this).addClass("Select_All");
                    $j23(this).text("Select All");
                    //$j23(this).removeClass("selected");
                }
                
                $j23(".breakOutAttrchkBox").each(function(){
                    if($j23(this).is(':disabled') == true)
                    {
                        $j23(this).prop("checked",false);
                        var attrval = $j23(this).attr("value");
                    }
                });	
            });

            $j23(".breakOutAttrchkBox").click(function(){
                var checked = $j23('.breakOutAttrchkBox:not(:checked)').length; 
                if(checked == 0)
                {
                    $j23("#selectattrid").removeClass("Select_All");
                    $j23("#selectattrid").addClass("Select_None");
                    $j23("#selectattrid").text("Select None");
                }
                else
                {
                    $j23("#selectattrid").removeClass("Select_None");
                    $j23("#selectattrid").addClass("Select_All");
                    $j23("#selectattrid").text("Select All");
                }
            });
        
            $j23("#selectAttrValue").attr("name","selectAttrValue");

            var selectedid = $j23('#selectAttrValue :selected').attr("value");
            var jbreakOutOption = $j23("#breakOutOption").val();
            var jselectedAttribute = $j23("#selectedAttribute").val();
            var jselectedAttributeValues = $j23("#selectedAttributeValues").val();				
            var jarray = jselectedAttributeValues.split(",");				
            if(jarray != "" && jbreakOutOption == 1)
            {	
                if(jarray.length == 1 && jselectedAttribute == selectedid)
                {	
                    var strvalue=jarray[0];
                    var match_id = $j23('input[type="checkbox"][value="'+strvalue+'"][name="breakOutAttrchkBox"]').attr("id");
                    if(typeof match_id !== 'undefined')
                    {
                        if(jselectedAttribute == match_id.split("_")[0])
                        {	
                            $j23('input[value="'+strvalue+'"][type="checkbox"]:enabled').prop("checked",true);				
                        }
                    }
                }
                else if(jarray.length > 1 && jselectedAttribute == selectedid )
                {	
                    for(i=0;i<jarray.length;i++)
                    {		
                        var strvalue=jarray[i];					
                        var match_id = $j23('input[type="checkbox"][value="'+strvalue+'"][name="breakOutAttrchkBox"]').attr("id");
                        if(typeof match_id === 'undefined'){
                                match_id = $j23('input[value="'+strvalue.toLowerCase()+'"][type="checkbox"]').attr("id");
                        }
                        
                        if(typeof match_id !== 'undefined')	
                        { 
                            if(jselectedAttribute == match_id.split("_")[0])
                            {	
                                $j23('input[value="'+strvalue+'"][type="checkbox"]:enabled').prop("checked",true);
                            }
                        }	
                    }

                }
            }
        },
        complete:function(data)
        {
            hideLoadingOverlay();//BG-52
        }
    });		
}

function parseDate(str,opt) 
{	
    //alert("parseDate : " +Number.isInteger(str) +"str : "+str+", opt : "+opt);
    //polyfill for IE Version 11
    Number.isInteger = Number.isInteger || function(value) {
        return typeof value === "number" && 
            isFinite(value) && 
            Math.floor(value) === value;
    };
    if((!Number.isInteger(str)) && (typeof str !== "undefined")){
        var t = str.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
        if(t != null){
            return true;
        }
        else{
            return null;
        }
    }
}

function isValidDateString(d) 
{
    var reg = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
    var t = d.match(reg);
    if(t != null)
        return true;
    else
        return false;			
}

function displayVolunFilterRemove() {

    var count = parseInt($j23('#updateTableView input[name=countAttr]').val());				
    //$j23('.volContainer').slideToggle("slow");		
    $j23(".volunAttrVal").prop('checked', true);
    
    $j23('a.volunFilterSelect').css("display", "inline");
    $j23('a.volunFilterRemove').css("display", "none");
    if(count > 0) {	
        count = count - 1;
        $j23('#updateTableView input[name=countAttr]').val(count);
        changeFilterCount();
    }
}

function changeFilterCount(){
    var count = parseInt($j23('#updateTableView input[name=countAttr]').val());						
    if(count > 0) {
        $j23(".filterOptionsContainer").show();
    }
    else {
        $j23(".filterOptionsContainer").hide();
        $j23('#updateTableView input[name=countAttr]').val('0');
    }
}

function showLoadingOverlay() {
    $j23('#ajaxFilterLoading .bg').height('100%');
    $j23('#ajaxFilterLoading').fadeIn(300);
    $j23("#ajaxFilterLoading").attr("tabindex",-1).focus();
    /* console.log("inside showLoadingOverlay()"); */
}

function hideLoadingOverlay() {
    $j23('#ajaxFilterLoading .bg').height('100%');
    $j23('#ajaxFilterLoading').fadeOut(300);
    $j23(".loader1").fadeOut("slow");
    //$j23(".loader2").css("display","none");
    /* console.log("hide hideLoadingOverlay()"); */
}
//DS::MV-1389

$j23('.require_fieldscls1').live('click', function()
{
	if($j23(this).attr('id') == 'idn_required'){
		$j23('#opt_idn_required').prop('checked', false);
	}
	else if($j23(this).attr('id') == 'opt_idn_required'){
		$j23('#idn_required').prop('checked', false);
	}
});



/*Dhreeti : BG-577 start */
$j23('ul[name="Sitesassignedtofield"] li').live('click', function()
{
		var value = $j23(this).attr("data-value");
		var classattr = $j23(this).attr("class");
		var selector = '#' + $j23(this).closest("ul").attr("id");
        var Attr_id_temp = selector.split("_");
        var Attr_id =Attr_id_temp[1];
		var AllOptions = $j23(selector);       
		var that = this;               
		var id = $j23(this).closest("ul").attr("id");       
	
		var countSite=0;
		$j23(selector+ ' li').each(function(){ 
			if( $j23(this).attr('data-value') > 0 ){
				countSite=countSite+1;
			}
		});
		if(classattr == "sitelist" || classattr == "fixedOption"){

			if(id == 'Sitesassignedtofield_'+Attr_id && countSite>0)
			$j23('.noAssignment_'+Attr_id).hide();
		    else
			$j23(that).closest('tr').prev('tr').eq(0).find('.noAssignment_'+Attr_id).hide();  
	
		if(value == 0){
			selectAllOptions(AllOptions,Attr_id);
		} else if(value > 0){
			selectOption(value, that, selector, Attr_id);
		}
		disabledDropdown();
		that.selectedIndex = 0;
		
		var count=0;				
		$j23('#blueBox_site .checkboxparent .tick').each(function (i) {
			count=count+1;				
		});			
		$j23('#siteCount').val(count);

		}
			
});

$j23('.checkboxMock').live('click', function(){
    if($j23(this).hasClass('disabled')){
		return false;
	}
		$j23(this).toggleClass('tick untick');
        if($j23(this).next().attr("name") == "Sites") {
			$j23(this).next().attr("name","") ;
		} else if ($j23(this).next().attr("name") == "") {
			$j23(this).next().attr("name","Sites") ;
		} 
		var id = this.id;
        var Attr_id_temp =id.split("_");
        var Attr_id = Attr_id_temp[2];
		var checkBox = document.getElementById( 'input' + id);
		var scopeID = checkBox.getAttribute('data-scopeid');
		var oldText = $j23( '#scopeSelectToggle_site_'+Attr_id).text();
		checkBox.checked = $j23(this).hasClass('tick');
		if( $j23('input[type=checkbox][data-scopeid=' + scopeID + ']:checked').length == $j23('input[type=checkbox][data-scopeid=' + scopeID + ']').length ){
			var newText = oldText.replace("Select", "Remove");
			$j23( '#scopeSelectToggle_site_'+Attr_id ).removeClass('select').addClass('remove').text(newText);
		} else {
			newText = oldText.replace("Remove", "Select");
			$j23( '#scopeSelectToggle_site_'+Attr_id ).removeClass('remove').addClass('select').text(newText);
		}
		$j23('#restoreThis' + id).toggle();
	
		var tCount=0;
		var count=0;
		$j23('#blueBox_site_'+Attr_id+' .checkboxparent').each(function (i) {
			tCount=tCount+1;			
		});			
		$j23('#blueBox_site_'+Attr_id+' .checkboxparent .untick').each(function (i) {
			count=count+1;				
		});		
		tCount= tCount-count;		
		$j23('#siteCount').val(tCount);
});

$j23('.restoreThis').live('click', function(){
		$j23(this).closest('.toleft').prev().find('.checkboxMock').trigger('click');
});

$j23('a.selectOrRemoveLinkk').live('click', function(){
        var id = this.id;
        var Attr_id_temp =id.split("_");
        var Attr_id = Attr_id_temp[2];
		var $link = $j23(this);
		var link = this;
		link.style.display = 'none';
		try{
			var $blueBox = $link.siblings('.blueBoxScroll');
			var isSelect = $link.hasClass('select');
			var classOnWhichActionNeeded = '.checkboxMock.' + (isSelect ? 'untick' : 'tick');
			var startTime = new Date().getTime();
			var checkBoxes = $blueBox.find(classOnWhichActionNeeded).get();
			for( i = 0; i < checkBoxes.length; i++){
				that = checkBoxes[i];
				classes = that.className;
                if(!classes.includes("disabled")){
				hasTick = /(?:^|\s)tick(?!\S)/.test(classes);
				regex = new RegExp('\\b' + ( hasTick ? 'tick' : 'untick' ) + '\\b', 'i');
				replaceWith = hasTick ? 'untick' : 'tick';
				that.className = classes.replace( regex, replaceWith )
				id = that.id;
				checkBox = document.getElementById( 'input' + id);
				checkBox.checked = !hasTick;
				document.getElementById( 'restoreThis' + id ).style.display = hasTick ? 'inline' : 'none';

				if(that.nextElementSibling.getAttribute("name") == "Sites") {
					that.nextElementSibling.setAttribute("name", ""); 
				} else if (that.nextElementSibling.getAttribute("name") == "") {
					that.nextElementSibling.setAttribute("name", "Sites");
				}  
            }
			}
			var checkBox = checkBoxes[0];
			var oldText = $j23( '#scopeSelectToggle_site_'+ Attr_id ).text();
			var newText = ''; 
			if( $j23('input[type=checkbox][data-scopeid=site_'+Attr_id+']:checked').length == $j23('input[type=checkbox][data-scopeid=site_'+Attr_id+']').length ){
				newText = oldText.replace("Select", "Remove");
				$j23( '#scopeSelectToggle_site_'+Attr_id).removeClass('select').addClass('remove').text(newText);
			} else {
				newText = oldText.replace("Remove", "Select");
				$j23( '#scopeSelectToggle_site_'+Attr_id).removeClass('remove').addClass('select').text(newText);
			}
		} catch(err) {
			link.style.display = 'inline';
			throw 'Error';
		}
		link.style.display = 'inline';
			
		var count=0;				
		$j23('#blueBox_site_'+Attr_id+' .checkboxparent .tick').each(function (i) {
			count=count+1;				
		});			
		$j23('#siteCount').val(count);
		
});

function selectOption(value, option, selectId, Attr_id){
    var specific_bluebox= "#blueBox_site_"+Attr_id;     
	var scopeID = $j23(selectId).data('scopeid'); 

	checkMarkId = (scopeID !== undefined) ? ( 'Assoc_' + scopeID + '_' + value ) : ( 'Site_' + value );
	inputId = 'input' + checkMarkId + '_'+ Attr_id;
	restoreId = 'restoreThis' + checkMarkId +'_'+ Attr_id;
    sitename = $j23(option).attr("site-name");
	var rowStr = '<div class="selectedScope">' + 
			'<div class="toleft checkboxparent">' + 
				'<a href="javascript:void(0);" class="checkboxMock tick" id="' + checkMarkId + '_' + Attr_id + '">X</a>' + 
				'<input class="scopes" type="checkbox" value="' + sitename +'~' + value +'~'+ Attr_id +'" data-scopeid="site_'+ Attr_id +'" name="Sites" id="' + inputId + '" checked="checked"/>' + 
			'</div><div class="toleft" style="width:300px;">' + $j23('<div>').text($j23(option).text()).html() + ' ' +
				'<a href="javascript:void(0)" class="restoreThis" id="' + restoreId + '" style="display:none;">Restore</a>' + 
			'</div><div class="clear"></div></div>';
	$j23('#scopeSelectToggle_site_'+Attr_id).show();
	if($j23(option).closest('ul').hasClass('singleScope'))
		$j23("#blueBox_site_"+Attr_id).append(rowStr);
	else
		$j23(option).closest('tr').prev('tr').eq(0).find("#blueBox_site_"+Attr_id).append(rowStr);
	$j23("#blueBox_site_"+Attr_id).scrollTop($j23("#blueBox_site_"+Attr_id)[0].scrollHeight);    
	$j23(option).remove();
	
	$j23('#ads'+value).remove();
	$j23('#as'+value).remove();
	//alert($('#ad22919').attr('id'));
	blueboxcount(specific_bluebox,Attr_id);
}

function selectAllOptions(select,Attr_id){  
    
	var options = select.find("li");
	var optionslen = select.find('li').length; 
    var specific_bluebox= "#blueBox_site_"+Attr_id; 

	var blueBoxScroll;
	if( /(?:^|\s)singleScope(?!\S)/.test( select.attr("class") ) )
		blueBoxScroll = $j23("#blueBox_site_"+Attr_id)[0];
	else
		blueBoxScroll = $j23(select).closest('tr').prev('tr').find("#blueBox_site_"+Attr_id)[0];

	var rowStr = '';
    var activeoptions = "";

	for (i = 1; i < optionslen; i++) {
		if (!((options[i].className) == "sitelist  inactive")) { 
				    
					thisOption = options[i];
					value = $j23(thisOption).attr("class");
					value = $j23(thisOption).attr("data-value");
                    sitename = $j23(thisOption).attr("site-name");
					checkMarkId ='Site_' + value+ '_'+Attr_id;
					inputId = 'input' + checkMarkId;
					restoreId = 'restoreThis' + checkMarkId;
					rowStr += '<div class="selectedScope">' +
						'<div class="toleft checkboxparent">' +
						'<a href="javascript:void(0);" class="checkboxMock tick" id="' + checkMarkId + '">X</a>' +
						'<input class="scopes" type="checkbox" value="' + sitename +'~' + value +'~'+ Attr_id +'" data-scopeid="site_'+ Attr_id +'" name="Sites" id="' + inputId + '" checked="checked"/>' +
						'</div><div class="toleft" style="width:300px;">' + thisOption.innerHTML + ' ' +
						'<a href="javascript:void(0)" class="restoreThis" id="' + restoreId + '" style="display:none;">Restore</a>' +
						'</div><div class="clear"></div></div>';
                    
                    $j23(thisOption).remove();	
		}

	} 
   
	blueBoxScroll.innerHTML = blueBoxScroll.innerHTML + rowStr;    
	$j23('#blueBox_site_'+Attr_id).scrollTop($j23('#blueBox_site_'+Attr_id)[0].scrollHeight);   
	$j23('#scopeSelectToggle_site_'+Attr_id).show();
	
	blueboxcount(specific_bluebox,Attr_id);
}

function blueboxcount(specific_bluebox, Attr_id){
	  
	var divcount = $j23(specific_bluebox+' .selectedScope').length;		
	if(divcount < 2 ){
		$j23('#scopeSelectToggle_site_'+Attr_id).css("display","none");
	}else{			
		$j23('#scopeSelectToggle_site_'+Attr_id).css("display","block");
	}
}

function disabledDropdown(){
          
		$j23(".picklist li").hover(function(){
			$j23(this).css("background-color", "white");
		}, function(){
			$j23(this).css("background-color", "");
		});
		
		var assignmentType = $j23('input[name="AssignmentType"]:checked').val();		
		var fixedOption = 0;		
		var active = 0;
		var inactive = 0;

		$j23('select[id="AllSites"] option').each(function(index,value) {						
				if($j23(this).attr("class") == 'inactive hidden'){
					inactive++;
				}else if($j23(this).attr("class") == 'inactive'){
					inactive++;
				}else if($j23(this).attr("class") == 'active'){
					active++;					
				}else if($j23(this).attr("class") == 'fixedOption'){
					fixedOption++;
				}
		});	

		if(assignmentType == 1){				
			if(fixedOption == 2 && active == 0){
				$j23("#AllSites").attr("disabled", true);
			}else if(fixedOption == 1 && active == 0){
				$j23("#AllSites").attr("disabled", true);
			}else{
				$j23("#AllSites").attr("disabled", false);
			}
			

		}else if(assignmentType == 2){
			if(fixedOption == 2 && active == 0 && inactive == 0){
				$j23("#AllSites").attr("disabled", true);
			}else if(fixedOption == 1 && active == 0 && inactive == 0){
				$j23("#AllSites").attr("disabled", true);
			}else{
				$j23("#AllSites").attr("disabled", false);
			}
		
		} 	
		
		var AllTimeAssignmentType = $j23('input[name="AllTimeAssignmentType"]:checked').val();		
		if(AllTimeAssignmentType == 1){				
			$j23('.customviewsection').css("display","none");				
		}else if(AllTimeAssignmentType == 2){
			$j23('.customviewsection').css("display","block");		
		}	
		
}
/* BG-577 start */
function htmlEncode(value){
    //create a in-memory div, set it's inner text(which jQuery automatically encodes)
    //then grab the encoded contents back out.  The div never exists on the page.
    return $j23('<div/>').text(value).html();
  }
/* BG-577 end */

/* Dhreeti :BG-577 end */


/* Start :: SM-193 */
function validateFreeTextAndLongTextField(val){
    var specialChars = "~";
        for(i = 0; i < specialChars.length;i++){
          if(val.indexOf(specialChars[i]) > -1){
              return true
          }
        }
      return false;
};
/* End :: SM-193 */
//BG-697
function countBasesdOnitemId(){
    var uniqueItemIds = [];

    $j23('.identcheckbox:visible:checked').each(function () {
        var item_Id = $j23(this).val();
        if (!isInArray(item_Id, uniqueItemIds)) {
        //if (!uniqueUserIds.includes(item_Id)) {
            uniqueItemIds.push(item_Id);
        }
    });
    var itemId_listCount = uniqueItemIds.length;
    //console.log("itemId_listCount",itemId_listCount);
    return itemId_listCount;
}

function updateSelectActionCnt(){
    var checkedItemsCountBasedOnId = '';
    checkedItemsCountBasedOnId = $j23('#selectedIdentifiersCheckbox input.check_identifierid_list:checked').length;
    $j23(this).prop("checked",true).val(1);
    $j23("#selectact").text("Select Action... ("+checkedItemsCountBasedOnId+")");            
    $j23("#delete").text("Delete Selected ("+checkedItemsCountBasedOnId+")");
    $j23("#archive").text("Archive Selected ("+checkedItemsCountBasedOnId+")");
    $j23("#restore").text("Restore Selected ("+checkedItemsCountBasedOnId+")");
}

function cloneCheckBoxes(this_el) {
    var checkbox = $j23(this_el);
    var checkboxId = checkbox.attr('id');

    if (checkbox.is(':checked')) {
        var alreadyCloned = $j23('#selectedIdentifiersCheckbox').find('input.check_identifierid_list[id="' + checkboxId + '"]').length > 0;

        if (!alreadyCloned) {
            // Find the td that contains this checkbox
            var td = checkbox.closest('td');

            // Clone the td
            var tdClone = td.clone(true);

            // Keep clone's checkbox in sync with original
            tdClone.find('.check_identifierid_list').bind('change', function() {
                $j23('#' + checkboxId + '.check_identifierid_list').attr('checked', $j23(this).is(':checked')).trigger('change');
            });

            // Append the cloned td to the target div
            $j23('#selectedIdentifiersCheckbox').append(tdClone);
        }
    } else {
        // If unchecked, find and remove the td containing this checkbox from the target div
        $j23('#selectedIdentifiersCheckbox').find('td input[id="' + checkboxId + '"]').closest('td').remove();
    }
}


function checkAllCheckboxesOnIdentCB(){
    // Find all checked checkboxes
    var checkedIds = [];
    // Collect IDs of all checked checkboxes (even if duplicated)
    $j23('.check_identifierid_list:checked').each(function() {
        checkedIds.push($j23(this).attr('id'));
    });

    // Now re-check ALL checkboxes that match those IDs (even duplicates)
    checkedIds.forEach(function(id) {
        $j23('input.check_identifierid_list[id="' + id + '"]').each(function() {
            $j23(this).prop('checked', true);

            // b. Also CLONE this checkbox into #selectedIdentifiersCheckbox
            cloneCheckBoxes(this);
        });
    });

}

function uncheckAllCheckboxesOnIdentCB(trSelector) {
    var uncheckedIds = [];

    // Collect IDs of all checkboxes inside the specified <tr>
    $j23(trSelector).find('.check_identifierid_list').each(function() {
        uncheckedIds.push($j23(this).attr('id'));
    });

    // Now uncheck ALL checkboxes on page that have those IDs
    uncheckedIds.forEach(function(id) {
        $j23('input.check_identifierid_list[id="' + id + '"]').prop('checked', false);
    });
}
function syncAllParentCheckboxes() {
    $j23("input[name='attr_val_chkbox']").each(function() {
        var parentCheckbox = $j23(this);
        var parentId = parentCheckbox.attr("class");  // example: 104999

        // Find ALL children rows with name=parentId
        parentId=parentId.replaceAll("'", "\\'");//BG-697
        var $children = $j23("tr[name='" + parentId + "'] input.check_identifierid_list")
            // EXCLUDE any children that are inside #selectedIdentifiersCheckbox
            .filter(function() {
                return $j23(this).closest("#selectedIdentifiersCheckbox").length === 0;
            });

        if ($children.length === 0) {
            // No valid children outside selectedIdentifiersCheckbox → uncheck parent
            parentCheckbox.prop("checked", false);
            return;
        }

        // Count checked child checkboxes
        var checkedCount = $children.filter(":checked").length;

        // Check/uncheck parent
        parentCheckbox.prop("checked", checkedCount === $children.length);
    });
}


//BG-697