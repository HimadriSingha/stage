//this is the function to show the breAk by tutor area
function BreakByStudentSiteWideCheckBox(scopeName, loadingImgId, TutorDataDivId, clickLinkId, questionID, beginSurvey, endSurvey, notSelectedIds, siteidList, programList, showingstatus, showtutorstudentall, whichanswertable, operationname) {
var BreakByStudentSiteWideCheckBox = "BreakByStudentSiteWideCheckBox_"+questionID;
var BreakByResponseCheckBox = "BreakByResponseCheckBox_"+questionID;
var BreakByTutorNonNumericCheckBox = "BreakByTutorNonNumericCheckBox_"+questionID;
var BreakByStudentSiteWideCheckBoxId = document.getElementById(BreakByStudentSiteWideCheckBox);	
var BreakByResponseCheckBoxId = document.getElementById(BreakByResponseCheckBox);
var BreakByTutorNonNumericCheckBoxId = document.getElementById(BreakByTutorNonNumericCheckBox);
if (BreakByStudentSiteWideCheckBoxId.classList.contains('breakOutOtherThanAttribute')===true){
	    if(BreakByStudentSiteWideCheckBoxId !== null)
		BreakByStudentSiteWideCheckBoxId.classList.remove("breakOutOtherThanAttribute");
	    if(BreakByResponseCheckBoxId !== null)
		BreakByResponseCheckBoxId.classList.add("breakOutOtherThanAttribute");
        if(BreakByTutorNonNumericCheckBoxId !== null)	
       BreakByTutorNonNumericCheckBoxId.classList.add("breakOutOtherThanAttribute");
	if (document.getElementById(TutorDataDivId).style.display == 'none' || showingstatus == 'firsttimemain' || showingstatus == 'z-a' || showingstatus == 'a-z' || showingstatus == 'asc' || showingstatus == 'desc') {

		document.getElementById(loadingImgId).style.display = 'block';

		// this is for sitewide
		if (scopeName == "site") {


			if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain') {


				document.getElementById(loadingImgId).style.display = 'none';
			} else {

				new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbystudentsitewidecheckbox&questionid=" + questionID + "&beginsurvey=" + beginSurvey + "&endsurvey=" + endSurvey + "&notselectedids=" + notSelectedIds + "&siteidlist=" + siteidList + "&programlist=" + programList + "&showingstatus=" + showingstatus + "&showtutorstudentall=" + showtutorstudentall + "&whichanswertable=" + whichanswertable + "&operationname=" + operationname), {

					onSuccess: function (returnHtml) {

						document.getElementById(loadingImgId).style.display = 'none';
						document.getElementById(clickLinkId).style.display = 'block';
						Element.update(TutorDataDivId, returnHtml.responseText);
						//Effect.toggle(TutorDataDivId, 'slide');
						var tutdiv = "TutorDataDiv" + questionID;
						var tutorOnlydiv = "TutorOnly" + questionID;
						var attributeDiv = "AttributeDataDiv" + questionID;
						var attributeSelectionDiv = "AttributeSelectionDiv" + questionID;
						jQuery('#' + attributeDiv).hide();
						jQuery('#' + attributeSelectionDiv).hide();
						if (document.getElementById(tutorOnlydiv).style.display != 'none') {
							document.getElementById(tutorOnlydiv).style.display = 'none';
							document.getElementById(TutorDataDivId).style.display = 'block';
						} else {
							if (document.getElementById(tutdiv).style.display != 'none') {
								document.getElementById(tutdiv).style.display = 'none';
								if (showingstatus == 'firsttimemain') {
									document.getElementById(TutorDataDivId).style.display = 'block';
								}
							} else {
								if (showingstatus == 'firsttimemain')
									Effect.BlindDown(TutorDataDivId);
							}
						}

					},
					onFailure: function () {
						alert('Oops...mistake on server');
					}
				});
			}

		} else if (scopeName == "program") {


			if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain') {

				//processAndCloseBreakBoxSelectRadio(TutorDataDivId,loadingImgId);
				document.getElementById(loadingImgId).style.display = 'none';
			} else {
				new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbystudentprogramwidecheckbox&questionid=" + questionID + "&beginsurvey=" + beginSurvey + "&endsurvey=" + endSurvey + "&notselectedids=" + notSelectedIds + "&programlist=" + programList + "&showingstatus=" + showingstatus + "&showtutorstudentall=" + showtutorstudentall + "&whichanswertable=" + whichanswertable + "&operationname=" + operationname), {

					onSuccess: function (returnHtml) {

						document.getElementById(loadingImgId).style.display = 'none';
						document.getElementById(clickLinkId).style.display = 'block';
						Element.update(TutorDataDivId, returnHtml.responseText);
						//Effect.toggle(TutorDataDivId, 'slide');
						var tutdiv = "TutorDataDiv" + questionID;
						var tutorOnlydiv = "TutorOnly" + questionID;
						var attributeDiv = "AttributeDataDiv" + questionID;
						var attributeSelectionDiv = "AttributeSelectionDiv" + questionID;
						jQuery('#' + attributeDiv).hide();
						jQuery('#' + attributeSelectionDiv).hide();
						if (document.getElementById(tutorOnlydiv).style.display != 'none') {
							document.getElementById(tutorOnlydiv).style.display = 'none';
							document.getElementById(TutorDataDivId).style.display = 'block';
						} else {
							if (document.getElementById(tutdiv).style.display != 'none') {
								document.getElementById(tutdiv).style.display = 'none';
								if (showingstatus == 'firsttimemain') {
									document.getElementById(TutorDataDivId).style.display = 'block';
								}
							} else {
								if (showingstatus == 'firsttimemain')
									Effect.BlindDown(TutorDataDivId);
							}
						}

					},
					onFailure: function () {
						alert('Oops...mistake on server');
					}
				});
			}


		}

	} else {
		document.getElementById(loadingImgId).style.display = 'block';
		processAndCloseBreakBoxSelectRadio(TutorDataDivId, loadingImgId);
		document.getElementById(loadingImgId).style.display = 'none';
	}
}
}

function BreakByStudentSiteWideCheckBox_volunteers(scopeName, loadingImgId, TutorDataDivId, clickLinkId, questionID, beginSurvey, endSurvey, notSelectedIds, siteidList, programList, showingstatus, showtutorstudentall, whichanswertable, operationname, volunteeruserid) {

	if (document.getElementById(TutorDataDivId).style.display == 'none' || showingstatus == 'firsttimemain' || showingstatus == 'z-a' || showingstatus == 'a-z' || showingstatus == 'asc' || showingstatus == 'desc') {

		document.getElementById(loadingImgId).style.display = 'block';
		if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain') {

			//processAndCloseBreakBoxSelectRadio(TutorDataDivId,loadingImgId);
			document.getElementById(loadingImgId).style.display = 'none';
		} else {
			new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbystudentprogramwidecheckbox&questionid=" + questionID + "&beginsurvey=" + beginSurvey + "&endsurvey=" + endSurvey + "&notselectedids=" + notSelectedIds + "&programlist=" + programList + "&showingstatus=" + showingstatus + "&showtutorstudentall=" + showtutorstudentall + "&whichanswertable=" + whichanswertable + "&operationname=" + operationname + "&volunteeruserid=" + volunteeruserid), {

				onSuccess: function (returnHtml) {

					document.getElementById(loadingImgId).style.display = 'none';
					document.getElementById(clickLinkId).style.display = 'block';
					Element.update(TutorDataDivId, returnHtml.responseText);
					//Effect.toggle(TutorDataDivId, 'slide');
					var tutdiv = "TutorDataDiv" + questionID;
					var tutorOnlydiv = "TutorOnly" + questionID;
					var attributeDiv = "AttributeDataDiv" + questionID;
					var attributeSelectionDiv = "AttributeSelectionDiv" + questionID;
					jQuery('#' + attributeDiv).hide();
					jQuery('#' + attributeSelectionDiv).hide();
					if (document.getElementById(tutorOnlydiv).style.display != 'none') {
						document.getElementById(tutorOnlydiv).style.display = 'none';
						document.getElementById(TutorDataDivId).style.display = 'block';
					} else {
						if (document.getElementById(tutdiv).style.display != 'none') {
							document.getElementById(tutdiv).style.display = 'none';
							if (showingstatus == 'firsttimemain') {
								document.getElementById(TutorDataDivId).style.display = 'block';
							}
						} else {
							if (showingstatus == 'firsttimemain')
								Effect.BlindDown(TutorDataDivId);
						}
					}

				},
				onFailure: function () {
					alert('Oops...mistake on server');
				}
			});
		}

	} else {
		document.getElementById(loadingImgId).style.display = 'block';
		processAndCloseBreakBoxSelectRadio(TutorDataDivId, loadingImgId);
		document.getElementById(loadingImgId).style.display = 'none';
	}
}



function processAndCloseBreakBoxResponseSelectRadio(TutorDataDivId) {
	Effect.Fade(TutorDataDivId);
	//Effect.toggle(TutorDataDivId, 'slide');
	Effect.BlindUp(TutorDataDivId);
	var question1ID = parseInt(TutorDataDivId.match(/[0-9]+/)[0], 10);
	var question4ID = parseInt(TutorDataDivId.match(/[0-9]+/)[0], 10);
	var question2ID = parseInt(TutorDataDivId.match(/[0-9]+/)[0], 10);
	var question3ID = parseInt(TutorDataDivId.match(/[0-9]+/)[0], 10);
	var questionID = parseInt(TutorDataDivId.match(/[0-9]+/)[0], 10);
	var BreakByTutorNonNumericCheckBox = "BreakByTutorNonNumericCheckBox_"+question1ID;
	var BreakByTutorNonNumeric = "BreakByTutorNonNumeric_"+questionID;
	var BreakByResponseSelectRadio = "BreakByResponseSelectRadio_"+question2ID;
	var BreakByStudentSiteWideCheckBox = "BreakByStudentSiteWideCheckBox_"+question3ID;
	var BreakByResponseCheckBox = "BreakByResponseCheckBox_"+question4ID;
	var BreakByTutorAssociationWideNonNumericCheckBox = "BreakByTutorAssociationWideNonNumericCheckBox_"+questionID;
	var BreakByStudentSiteWideSelectRadio = "BreakByStudentSiteWideSelectRadio_"+questionID;
	var BreakByTutorAssociationWideSelectRadio = "BreakByTutorAssociationWideSelectRadio_"+questionID;
    var BreakByResponseAssociationWideCheckBox = "BreakByResponseAssociationWideCheckBox_"+questionID;
	var BreakByStudentAssociationWideCheckBox = "BreakByStudentAssociationWideCheckBox_"+questionID;	
	var BreakByTutorAssociationWideNumberText = "BreakByTutorAssociationWideNumberText_"+questionID;
	var BreakByTutorAssociationWideTimeSeries = "BreakByTutorAssociationWideTimeSeries_"+questionID;
	var BreakByStudentAssociationWideSelectRadio = "BreakByStudentAssociationWideSelectRadio_"+questionID;
	var BreakByResponseAssociationWideSelectRadio = "BreakByResponseAssociationWideSelectRadio_"+questionID;
	var BreakByTutorAssociationWideNonNumericSelectRadio = "BreakByTutorAssociationWideNonNumericSelectRadio_"+questionID;
	var BreakByTutorAssociationWideNonNumericCheckBox = "BreakByTutorAssociationWideNonNumericCheckBox_"+questionID;
    var BreakByResponseSelectRadioId = document.getElementById(BreakByResponseSelectRadio);
	var BreakByStudentSiteWideCheckBoxId = document.getElementById(BreakByStudentSiteWideCheckBox);	
	var BreakByTutorNonNumericCheckBoxId = document.getElementById(BreakByTutorNonNumericCheckBox);
	var BreakByTutorNonNumericId = document.getElementById(BreakByTutorNonNumeric);
    var BreakByResponseCheckBoxId = document.getElementById(BreakByResponseCheckBox);
	var BreakByStudentSiteWideSelectRadioId = document.getElementById(BreakByStudentSiteWideSelectRadio);
	var BreakByTutorAssociationWideNonNumericCheckBoxId = document.getElementById(BreakByTutorAssociationWideNonNumericCheckBox);
	var BreakByTutorAssociationWideSelectRadioId = document.getElementById(BreakByTutorAssociationWideSelectRadio);
	var BreakByTutorAssociationWideNonNumericCheckBoxId = document.getElementById(BreakByTutorAssociationWideNonNumericCheckBox);
    var BreakByResponseAssociationWideCheckBoxId = document.getElementById(BreakByResponseAssociationWideCheckBox);
		var BreakByTutorAssociationWideNumberTextId = document.getElementById(BreakByTutorAssociationWideNumberText);
		var BreakByStudentAssociationWideCheckBoxId = document.getElementById(BreakByStudentAssociationWideCheckBox);
		var BreakByTutorAssociationWideTimeSeriesId = document.getElementById(BreakByTutorAssociationWideTimeSeries);
		var BreakByResponseAssociationWideSelectRadioId = document.getElementById(BreakByResponseAssociationWideSelectRadio);
		var BreakByTutorAssociationWideNonNumericSelectRadioId = document.getElementById(BreakByTutorAssociationWideNonNumericSelectRadio);
		var BreakByStudentAssociationWideSelectRadioId = document.getElementById(BreakByStudentAssociationWideSelectRadio);
	if(BreakByTutorNonNumericCheckBoxId !== null)
	BreakByTutorNonNumericCheckBoxId.classList.add("breakOutOtherThanAttribute");
	if(BreakByTutorNonNumericId !== null)
	BreakByTutorNonNumericId.classList.add("breakOutOtherThanAttribute");
    if(BreakByResponseSelectRadioId !== null)
	BreakByResponseSelectRadioId.classList.add("breakOutOtherThanAttribute");
    if(BreakByStudentSiteWideCheckBoxId !== null)
	BreakByStudentSiteWideCheckBoxId.classList.add("breakOutOtherThanAttribute");
    if(BreakByResponseCheckBoxId !== null)
	BreakByResponseCheckBoxId.classList.add("breakOutOtherThanAttribute");
    if(BreakByStudentSiteWideSelectRadioId !== null)
	BreakByStudentSiteWideSelectRadioId.classList.add("breakOutOtherThanAttribute");
    if( BreakByTutorAssociationWideNonNumericCheckBoxId  !== null)
    BreakByTutorAssociationWideNonNumericCheckBoxId.classList.add("breakOutOtherThanAttribute");
    if(BreakByTutorAssociationWideNumberTextId !== null)
         BreakByTutorAssociationWideNumberTextId.classList.add("breakOutOtherThanAttribute");
	    if(BreakByTutorAssociationWideSelectRadioId !== null)
         BreakByTutorAssociationWideSelectRadioId.classList.add("breakOutOtherThanAttribute");
	    if(BreakByResponseAssociationWideCheckBoxId !== null)
         BreakByResponseAssociationWideCheckBoxId.classList.add("breakOutOtherThanAttribute");
	     if(BreakByStudentAssociationWideCheckBoxId  !== null)
         BreakByStudentAssociationWideCheckBoxId .classList.add("breakOutOtherThanAttribute");
	    if(BreakByTutorAssociationWideTimeSeriesId  !== null)
         BreakByTutorAssociationWideTimeSeriesId .classList.add("breakOutOtherThanAttribute");
	    if( BreakByTutorAssociationWideNonNumericSelectRadioId  !== null)
          BreakByTutorAssociationWideNonNumericSelectRadioId .classList.add("breakOutOtherThanAttribute");
	    if( BreakByResponseAssociationWideSelectRadioId  !== null)
          BreakByResponseAssociationWideSelectRadioId .classList.add("breakOutOtherThanAttribute");
	    if( BreakByStudentAssociationWideSelectRadioId  !== null)
          BreakByStudentAssociationWideSelectRadioId .classList.add("breakOutOtherThanAttribute");

}


function BreakByStudentSiteWideCheckBoxInner(scopeName, loadingImgId, TutorDataDivId, clickLinkId, questionID, beginSurvey, endSurvey, notSelectedIds, siteidList, programList, showingstatus, showtutorstudentall, whichanswertable, operationname, associationid) {
	if (document.getElementById(TutorDataDivId).style.display == 'none' || showingstatus == 'firsttimemain' || showingstatus == 'z-a' || showingstatus == 'a-z' || showingstatus == 'asc' || showingstatus == 'desc') {

		document.getElementById(loadingImgId).style.display = 'block';

		// this is for sitewide
		if (scopeName == "site") {



			if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain') {


				document.getElementById(loadingImgId).style.display = 'none';
			} else {

				new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbystudentsitewidecheckboxinner&questionid=" + questionID + "&beginsurvey=" + beginSurvey + "&endsurvey=" + endSurvey + "&notselectedids=" + notSelectedIds + "&siteidlist=" + siteidList + "&programlist=" + programList + "&showingstatus=" + showingstatus + "&showtutorstudentall=" + showtutorstudentall + "&whichanswertable=" + whichanswertable + "&operationname=" + operationname + "&associationid=" + associationid), {

					onSuccess: function (returnHtml) {

						document.getElementById(loadingImgId).style.display = 'none';

						var answerdiv = "divid_" + associationid + "_" + questionID;

						Element.update(answerdiv, returnHtml.responseText);
						//Effect.toggle(TutorDataDivId, 'slide');

						if (document.getElementById(tutdiv).style.display != 'none') {
							document.getElementById(tutdiv).style.display = 'none';
							if (showingstatus == 'firsttimemain') {
								document.getElementById(TutorDataDivId).style.display = 'block';
							}
						} else {
							if (showingstatus == 'firsttimemain')
								Effect.BlindDown(TutorDataDivId);
						}


					},
					onFailure: function () {
						alert('Oops...mistake on server');
					}
				});
			}

		} else if (scopeName == "program") {


			if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain') {

				//processAndCloseBreakBoxSelectRadio(TutorDataDivId,loadingImgId);
				document.getElementById(loadingImgId).style.display = 'none';
			} else {
				new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbystudentprogramwidecheckboxinner&questionid=" + questionID + "&beginsurvey=" + beginSurvey + "&endsurvey=" + endSurvey + "&notselectedids=" + notSelectedIds + "&programlist=" + programList + "&showingstatus=" + showingstatus + "&showtutorstudentall=" + showtutorstudentall + "&whichanswertable=" + whichanswertable + "&operationname=" + operationname + "&associationid=" + associationid), {

					onSuccess: function (returnHtml) {

						document.getElementById(loadingImgId).style.display = 'none';
						document.getElementById(clickLinkId).style.display = 'block';
						var answerdiv = "divid_" + associationid + "_" + questionID;
						Element.update(answerdiv, returnHtml.responseText);
						//Effect.toggle(TutorDataDivId, 'slide');

						if (document.getElementById(tutdiv).style.display != 'none') {
							document.getElementById(tutdiv).style.display = 'none';
							if (showingstatus == 'firsttimemain') {
								document.getElementById(TutorDataDivId).style.display = 'block';
							}
						} else {
							if (showingstatus == 'firsttimemain')
								Effect.BlindDown(TutorDataDivId);
						}


					},
					onFailure: function () {
						alert('Oops...mistake on server');
					}
				});
			}


		}

	} else {
		document.getElementById(loadingImgId).style.display = 'block';
		processAndCloseBreakBoxSelectRadio(TutorDataDivId, loadingImgId);
		document.getElementById(loadingImgId).style.display = 'none';
	}
}
function BreakByStudentSiteWideCheckBoxInner_volunteers(scopeName, loadingImgId, TutorDataDivId, clickLinkId, questionID, beginSurvey, endSurvey, notSelectedIds, siteidList, programList, showingstatus, showtutorstudentall, whichanswertable, operationname, associationid, volunteeruserid) {
	if (document.getElementById(TutorDataDivId).style.display == 'none' || showingstatus == 'firsttimemain' || showingstatus == 'z-a' || showingstatus == 'a-z' || showingstatus == 'asc' || showingstatus == 'desc') {

		document.getElementById(loadingImgId).style.display = 'block';
		if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain') {

			//processAndCloseBreakBoxSelectRadio(TutorDataDivId,loadingImgId);
			document.getElementById(loadingImgId).style.display = 'none';
		} else {
			new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbystudentprogramwidecheckboxinner&questionid=" + questionID + "&beginsurvey=" + beginSurvey + "&endsurvey=" + endSurvey + "&notselectedids=" + notSelectedIds + "&programlist=" + programList + "&showingstatus=" + showingstatus + "&showtutorstudentall=" + showtutorstudentall + "&whichanswertable=" + whichanswertable + "&operationname=" + operationname + "&associationid=" + associationid+ "&volunteeruserid=" + volunteeruserid), {

				onSuccess: function (returnHtml) {

					document.getElementById(loadingImgId).style.display = 'none';
					document.getElementById(clickLinkId).style.display = 'block';
					var answerdiv = "divid_" + associationid + "_" + questionID;
					Element.update(answerdiv, returnHtml.responseText);
					//Effect.toggle(TutorDataDivId, 'slide');

					if (document.getElementById(tutdiv).style.display != 'none') {
						document.getElementById(tutdiv).style.display = 'none';
						if (showingstatus == 'firsttimemain') {
							document.getElementById(TutorDataDivId).style.display = 'block';
						}
					} else {
						if (showingstatus == 'firsttimemain')
							Effect.BlindDown(TutorDataDivId);
					}


				},
				onFailure: function () {
					alert('Oops...mistake on server');
				}
			});
		}

	} else {
		document.getElementById(loadingImgId).style.display = 'block';
		processAndCloseBreakBoxSelectRadio(TutorDataDivId, loadingImgId);
		document.getElementById(loadingImgId).style.display = 'none';
	}
}