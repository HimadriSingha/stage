vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|25 Aug 2009 11:37:17 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{FA49048B-DB84-49AD-B2FF-101580A2B6C2}
vti_cacheddtm:TX|08 Sep 2008 11:18:00 -0000
vti_filesize:IR|10185
vti_backlinkinfo:VX|
