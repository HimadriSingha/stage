vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Apr 2011 15:02:13 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{7BD4F0F8-18A1-4DA0-B19D-BDF748531658}
vti_cacheddtm:TX|31 Jan 2008 20:44:47 -0000
vti_filesize:IR|1297
vti_backlinkinfo:VX|
