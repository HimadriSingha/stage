vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Feb 2008 11:31:02 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{B96DF757-EEF7-47D4-BFE5-DC741F2944D0}
vti_cacheddtm:TX|19 Feb 2008 11:31:02 -0000
vti_filesize:IR|1865
vti_backlinkinfo:VX|
