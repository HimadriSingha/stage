vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|16 Nov 2010 07:22:09 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{51FFE5C9-CDCD-4CF2-BCF3-E9A972EAAE03}
vti_cacheddtm:TX|16 Nov 2010 07:22:09 -0000
vti_filesize:IR|3723
vti_backlinkinfo:VX|
