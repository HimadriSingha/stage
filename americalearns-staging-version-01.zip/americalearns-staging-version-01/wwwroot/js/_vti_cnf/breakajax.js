vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Apr 2011 15:02:13 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{DF0335D5-486F-40DB-B0F7-674984FA69EC}
vti_cacheddtm:TX|03 Jun 2009 11:38:04 -0000
vti_filesize:IR|3344
vti_backlinkinfo:VX|
