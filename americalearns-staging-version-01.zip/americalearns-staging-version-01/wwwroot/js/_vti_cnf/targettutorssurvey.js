vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|16 Nov 2010 07:22:09 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{75EBF0D4-141B-4C35-9BF1-0829549DBF94}
vti_cacheddtm:TX|16 Nov 2010 07:22:09 -0000
vti_filesize:IR|19678
vti_backlinkinfo:VX|
