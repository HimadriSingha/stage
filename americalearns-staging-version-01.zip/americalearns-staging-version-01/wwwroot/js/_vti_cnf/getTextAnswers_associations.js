vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Apr 2011 15:02:13 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{C3BA1D03-5542-4D69-AC7B-43A6390AD77E}
vti_cacheddtm:TX|06 Feb 2008 23:05:50 -0000
vti_filesize:IR|1384
vti_backlinkinfo:VX|
