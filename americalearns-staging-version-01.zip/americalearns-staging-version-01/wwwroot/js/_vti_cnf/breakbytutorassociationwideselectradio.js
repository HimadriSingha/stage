vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Apr 2011 15:02:13 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{AD2291E6-5526-4532-9967-26717B2E9942}
vti_cacheddtm:TX|18 Jun 2009 12:25:40 -0000
vti_filesize:IR|2232
vti_backlinkinfo:VX|
