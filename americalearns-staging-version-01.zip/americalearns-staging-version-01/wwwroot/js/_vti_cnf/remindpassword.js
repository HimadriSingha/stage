vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|08 Mar 2010 08:31:30 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{5F58752D-D661-46CA-9AAE-920E79C5BDC2}
vti_cacheddtm:TX|08 Mar 2010 08:31:30 -0000
vti_filesize:IR|1600
vti_backlinkinfo:VX|
