vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|15 Sep 2010 12:05:05 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{EA869D6E-F345-4C74-81B2-C7DAEB8A029D}
vti_cacheddtm:TX|15 Sep 2010 12:05:05 -0000
vti_filesize:IR|17167
vti_backlinkinfo:VX|
