vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|05 Feb 2008 17:59:41 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{7C5DE63E-50B1-41AE-9867-21587707C920}
vti_cacheddtm:TX|05 Feb 2008 17:59:41 -0000
vti_filesize:IR|18119
vti_backlinkinfo:VX|
