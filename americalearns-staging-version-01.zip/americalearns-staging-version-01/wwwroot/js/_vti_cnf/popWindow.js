vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Feb 2008 14:11:41 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{67E05A48-C5A1-4AC7-8FE4-6E824E6641C4}
vti_cacheddtm:TX|12 Feb 2008 14:11:41 -0000
vti_filesize:IR|398
vti_backlinkinfo:VX|
