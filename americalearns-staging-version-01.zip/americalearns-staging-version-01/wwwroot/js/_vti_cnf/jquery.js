vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Sep 2010 09:53:45 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{51BED141-7A97-4175-A230-76421DF7DAA8}
vti_cacheddtm:TX|01 Sep 2010 09:53:45 -0000
vti_filesize:IR|170095
vti_backlinkinfo:VX|
