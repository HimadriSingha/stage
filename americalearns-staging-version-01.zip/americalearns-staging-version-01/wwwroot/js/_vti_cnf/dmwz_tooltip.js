vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|18 Jul 2008 09:34:33 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{1B7DF5AF-7A19-40A1-B058-6F0673FCF8F1}
vti_cacheddtm:TX|18 Jul 2008 09:34:33 -0000
vti_filesize:IR|35238
vti_backlinkinfo:VX|
