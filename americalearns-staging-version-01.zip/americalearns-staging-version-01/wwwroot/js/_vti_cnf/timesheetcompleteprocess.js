vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|08 Jul 2011 13:54:18 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{9D6E8218-8A2F-4CD1-8C6F-C8F63147E23D}
vti_cacheddtm:TX|16 Jun 2011 17:30:17 -0000
vti_filesize:IR|33337
vti_backlinkinfo:VX|
