vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Apr 2011 15:02:13 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{ACFCD8DA-5DE1-44F8-8236-5C104EB22818}
vti_cacheddtm:TX|28 Jul 2009 06:45:13 -0000
vti_filesize:IR|6462
vti_backlinkinfo:VX|
