vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|15 Jun 2011 14:17:13 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{93871A4D-9D6F-4EE3-8C06-456576D348D0}
vti_cacheddtm:TX|15 Feb 2008 15:05:01 -0000
vti_filesize:IR|1038
vti_backlinkinfo:VX|
