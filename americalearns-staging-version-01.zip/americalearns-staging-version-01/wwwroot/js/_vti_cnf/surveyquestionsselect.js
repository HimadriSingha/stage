vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Apr 2011 15:02:13 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{760A2780-5CF3-4902-BA38-49674AE7E0D3}
vti_cacheddtm:TX|11 Nov 2009 04:28:07 -0000
vti_filesize:IR|58707
vti_backlinkinfo:VX|
