vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Apr 2011 15:02:13 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{F3656697-EF42-4A5F-9AB1-EBEBE0577AC8}
vti_cacheddtm:TX|28 Jul 2009 06:45:13 -0000
vti_filesize:IR|6498
vti_backlinkinfo:VX|
