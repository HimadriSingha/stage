vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|08 Mar 2008 16:02:00 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{3F01EE26-9D80-4635-952B-4D63FE54750B}
vti_cacheddtm:TX|08 Mar 2008 16:02:00 -0000
vti_filesize:IR|561
vti_backlinkinfo:VX|
