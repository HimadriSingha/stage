vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|08 Mar 2010 08:31:30 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{0CD29861-D37C-47D3-B3EF-C665F14F9FE8}
vti_cacheddtm:TX|08 Mar 2010 08:31:30 -0000
vti_filesize:IR|3408
vti_backlinkinfo:VX|
