vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|08 Sep 2008 11:18:00 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{22331739-AC37-4773-9B16-72B7375D3D82}
vti_cacheddtm:TX|08 Sep 2008 11:18:00 -0000
vti_filesize:IR|4003
vti_backlinkinfo:VX|
