vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Apr 2011 15:02:13 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{DAEFD7C4-4BC8-4AEC-B6D0-1D978FAA3FEA}
vti_cacheddtm:TX|13 Apr 2011 15:02:13 -0000
vti_filesize:IR|2744
vti_backlinkinfo:VX|
