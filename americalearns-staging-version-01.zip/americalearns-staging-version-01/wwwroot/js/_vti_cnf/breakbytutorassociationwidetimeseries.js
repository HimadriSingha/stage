vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Apr 2011 15:02:13 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{8B572001-22F1-4710-80CB-4833FA5F8789}
vti_cacheddtm:TX|18 Jun 2009 12:25:40 -0000
vti_filesize:IR|2230
vti_backlinkinfo:VX|
