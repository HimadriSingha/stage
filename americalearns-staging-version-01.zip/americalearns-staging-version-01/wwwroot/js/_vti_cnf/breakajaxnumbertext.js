vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Apr 2011 15:02:13 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{E8E36AB7-DFBC-4880-8F36-47309D512B45}
vti_cacheddtm:TX|03 Jun 2009 11:38:04 -0000
vti_filesize:IR|3360
vti_backlinkinfo:VX|
