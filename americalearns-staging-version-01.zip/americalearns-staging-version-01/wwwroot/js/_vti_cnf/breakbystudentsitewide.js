vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Apr 2011 15:02:13 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{0EA5E9EA-E7C9-4405-8171-0F5412350FED}
vti_cacheddtm:TX|25 Aug 2009 06:51:47 -0000
vti_filesize:IR|8047
vti_backlinkinfo:VX|
