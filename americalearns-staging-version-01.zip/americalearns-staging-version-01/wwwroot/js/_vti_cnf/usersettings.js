vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|08 Mar 2010 08:31:30 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{FF114700-CBE3-4470-BF4D-48920E2A1FA7}
vti_cacheddtm:TX|08 Mar 2010 08:31:30 -0000
vti_filesize:IR|1451
vti_backlinkinfo:VX|
