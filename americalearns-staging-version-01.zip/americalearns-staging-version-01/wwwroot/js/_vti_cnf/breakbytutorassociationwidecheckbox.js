vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Apr 2011 15:02:13 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{287BB944-4A2C-4EB1-B4CF-7FAFF8F87048}
vti_cacheddtm:TX|18 Jun 2009 12:25:40 -0000
vti_filesize:IR|2547
vti_backlinkinfo:VX|
