vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|14 Jun 2011 19:40:00 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{9B6C2C58-5015-4F47-8BD2-7F4BA5A11521}
vti_cacheddtm:TX|14 Jun 2011 19:40:00 -0000
vti_filesize:IR|39189
vti_backlinkinfo:VX|
