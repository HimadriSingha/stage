vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Apr 2011 15:02:13 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{2ED67153-535D-4014-BC59-FA99D1DD6BB4}
vti_cacheddtm:TX|28 Aug 2009 08:41:58 -0000
vti_filesize:IR|4580
vti_backlinkinfo:VX|
