vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Feb 2008 19:24:57 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{711E1424-9FE8-4AF7-84D5-7BD5CB6DD32A}
vti_cacheddtm:TX|19 Feb 2008 19:24:57 -0000
vti_filesize:IR|1076
vti_backlinkinfo:VX|
