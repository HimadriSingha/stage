var componentChangedArr = [];
var componentChangedStruct = {};
var inputChangedSection = '';

function addCommaSep(number) {
    return String(number).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function removeCommaSep(number){
    return String(number).replace(/,/g, "");
}

function percentChange() {
    var totalExceededVal = 0;
    if($j("#budgetVarianceRule").val() == 'EntireBudget'){
        var modifiedBudgetTotal = removeCommaSep($j("#"+$j("#finalCompId").val()+"_total").val());
        if(modifiedBudgetTotal != '' && modifiedBudgetTotal != 'undefined'){
            modifiedBudgetTotal = parseFloat(modifiedBudgetTotal);
        }else{
            modifiedBudgetTotal = parseFloat(removeCommaSep($j("#"+$j("#finalCompId").val()+"_totalprev").val()));
        }

        totalExceededVal = modifiedBudgetTotal - parseFloat(removeCommaSep($j("#approvedExpensesToDate").val()));
        if(totalExceededVal < 0){
            totalExceededVal = Math.abs(totalExceededVal);
        }else{
            totalExceededVal = 0;
        }
    }else if($j("#budgetVarianceRule").val() == 'CncsOnly'){
        $j(".input-cncs").each(function(){
            var thisVal = $j("#"+$j(this).attr("data-componentId")+"_cncs").val();
            if(thisVal == undefined || thisVal == 'undefined'){
                thisVal = $j("#"+$j(this).attr("data-componentId")+"_cncsprev").val();
            }
            if($j(this).attr('data-isCalculated') == '0' && (thisVal != '' || parseFloat(removeCommaSep($j("."+$j(this).attr("data-componentId")+"_cncs_balance span").html())) < 0) && $j(this).attr('id') != 'budgetIncreasecncs'){
                var newBalance =  0;
                if(thisVal == ''){
                    newBalance = parseFloat(removeCommaSep($j("."+$j(this).attr("data-componentId")+"_cncs_balance span").html()));
                }else{
                    newBalance = parseFloat(removeCommaSep(thisVal)) - Math.abs(parseFloat(removeCommaSep($j("."+$j(this).attr("data-componentId")+"_cncs_expense span").html())));
                }
    
                if(newBalance < 0){
                    totalExceededVal = totalExceededVal + Math.abs(newBalance.toFixed(2));
                }
            }
        });
    }

    $j("#totalExceedVal").val(totalExceededVal);
    var approvedVal = parseFloat(removeCommaSep($j("#total_approvedVal").val()));
    var percentChange = parseFloat(((totalExceededVal / approvedVal) * 100).toFixed(2));
    $j("#percentChange").val(percentChange);
    $j("#percentChangePopup").val(1);
}

function checkIfReconcileNeeded(){
    var finalComponentId = $j("#finalCompId").val();
    var finalTotalPrev = removeCommaSep($j("#"+finalComponentId+"_totalprev").val());
    var finalTotal = removeCommaSep($j("#"+finalComponentId+"_total").val());

    if(finalTotal != '' && finalTotalPrev != finalTotal){
        var finalCncsPrev = removeCommaSep($j("#"+finalComponentId+"_cncsprev").val());
        var finalCncs = removeCommaSep($j("#"+finalComponentId+"_cncs").val());
        if(finalCncsPrev != finalCncs){
            $j(".input-grantee").attr('readonly', true);
            $j(".input-cncs").attr('readonly', false);
            //$j(".input-grantee_Section3").attr('readonly', false);
            $j(".input-cncs").each(function(){ 
                if($j(this).hasClass('input-readonly')){
                    $j(this).attr('readonly', true);
                }else{
                    $j(this).attr('readonly', false);
                }
            });
            $j("#editedField").val('cncs');
            $j(".reconcile-grantee").html('Locked Until AmeriCorps Share is Balanced');
            $j(".reconcile-grantee-secIII").css("display","none");
            $j(".or-text-grantee").css("display","none");
        }else{
            var finalGranteePrev = removeCommaSep($j("#"+finalComponentId+"_granteeprev").val());
            var finalGrantee = removeCommaSep($j("#"+finalComponentId+"_grantee").val());
            if(finalGranteePrev != finalGrantee){
                $j(".input-cncs").attr('readonly', true);
                $j(".input-grantee").attr('readonly', false);
                //$j(".input-cncs_Section3").attr('readonly', false);
                $j(".input-grantee").each(function(){ 
                    if($j(this).hasClass('input-readonly')){
                        $j(this).attr('readonly', true);
                    }else{
                        $j(this).attr('readonly', false);
                    }
                });
                $j("#editedField").val('grantee');
                $j(".reconcile-cncs").html('Locked Until Grantee Share is Balanced');
                $j(".reconcile-cncs-secIII").css("display","none");
                $j(".or-text-cncs").css("display","none");
            }
        }
    }else{
        $j(".trsimple_total_Adjust_"+finalComponentId).hide();
        $j("#"+finalComponentId+"_cncs_adjust").val('');
        $j("#"+finalComponentId+"_grantee_adjust").val('');
    }
}

function updateSec3ToDefaultChangesNote(){
    var corfa_icrChanged = $j("#corfa_icrChanged").val();
    var comfa_cfaChanged = $j("#comfa_cfaChanged").val();
    var mxGranteeShareChanged = $j("#mxGranteeShareChanged").val();
    var fundingStructureName = $j("#FundingStructureName").val();
    var corfa = $j('#corfa').val();
    var icr = $j('#icr').val();
    var changesAvailable = false;
    var useSection3 = true;
    if(FundingStructureBudgetType == 'Fixed'){
        if($j("#useSectionIII").val() == 0){
            useSection3 = false;
        }
    }
    $j(".sec3ChangesInnerDiv .corfa_icr_span").addClass('display-none');
    $j(".sec3ChangesInnerDiv .comfa_cfa_span").addClass('display-none');

    if(useSection3 && (corfa != undefined || icr != undefined)){
        if(fundingStructureName == 'NonIndirect'){
            var sec3Heading = 'Corporation Fixed Percentage';
            var sec3corfa = 'Corporation Fixed Amount';     
        }else if(fundingStructureName == 'Indirect'){
            var sec3Heading = 'Federally Approved Indirect Cost Rate';
            var sec3corfa = 'Indirect Cost Rate';   
        }  

        if(corfa_icrChanged == 1){
            changesAvailable = true;
            $j(".sec3ChangesInnerDiv .corfa_icr_span .corfa_icr_heading").html('- '+sec3Heading+': ');
            $j(".sec3ChangesInnerDiv .corfa_icr_span .corfa_icr_lineitem").html(sec3corfa+' (AmeriCorps Share)');
            $j(".sec3ChangesInnerDiv .corfa_icr_span").removeClass('display-none');
        }else{
            $j(".sec3ChangesInnerDiv .corfa_icr_span").addClass('display-none');
        }

        if(comfa_cfaChanged == 1){
            changesAvailable = true;
            $j(".sec3ChangesInnerDiv .comfa_cfa_span .comfa_cfa_heading").html('- '+sec3Heading+': ');
            $j(".sec3ChangesInnerDiv .comfa_cfa_span").removeClass('display-none');
        }else{
            $j(".sec3ChangesInnerDiv .comfa_cfa_span").addClass('display-none');
        }

        if(mxGranteeShareChanged == 1){
            changesAvailable = true;
            $j(".sec3ChangesInnerDiv .mxGranteeShare_span .mxGranteeShare_heading").html('- '+sec3Heading+': ');
            $j(".sec3ChangesInnerDiv .mxGranteeShare_span .mxGranteeShare_lineitem").html(sec3corfa+' (Grantee Share)');
            $j(".sec3ChangesInnerDiv .mxGranteeShare_span").removeClass('display-none');
        }else{
            $j(".sec3ChangesInnerDiv .mxGranteeShare_span").addClass('display-none');
        }

        if(changesAvailable){
            $j(".sec3Changes").removeClass('display-none');
        }else{
            $j(".sec3Changes").addClass('display-none');
        }
    }
}

function showLinkToSetDefault(){
    $j("#updateSec3ToDefault").hide();
    $j("#updateSec3ToDefaultSpan").hide();
    $j(".sec3ChangesInnerDiv .corfa_icr_span").addClass('display-none');
    $j(".sec3ChangesInnerDiv .comfa_cfa_span").addClass('display-none');
    $j("#corfa_icrChanged").val(0);
    $j("#mxGranteeShareChanged").val(0);
    $j("#comfa_cfaChanged").val(0);
    var corfa = $j('#corfa').val();
    var comfa = $j('#comfa').val();
    var icr = $j('#icr').val();
    var cfa = $j('#cfa').val();
    var noCalCulationForGranteeShare = $j("#noCalCulationForGranteeShare").val();
    var fundingStructureName = $j("#FundingStructureName").val();
    var changesAvailable = false;

    var useSection3 = true;
    if(FundingStructureBudgetType == 'Fixed'){
        if($j("#useSectionIII").val() == 0){
            useSection3 = false;
        }
    }

    if(useSection3 && (corfa != undefined || icr != undefined)){
        if(fundingStructureName == 'NonIndirect'){
            var sec3Heading = 'Corporation Fixed Percentage';
            var corfaCncs = removeCommaSep($j("#"+corfa+"_cncs").val());
            var corfaCncsDefault = parseFloat(removeCommaSep($j("#"+corfa+"_cncs_default").val()));
            if(corfaCncs != ''){
                corfaCncs = parseFloat(corfaCncs);
            }else{
                //corfaCncs = parseFloat($j("#"+corfa+"_cncsprev").val());
            }

            var comfaCncs = removeCommaSep($j("#"+comfa+"_cncs").val());
            var comfaCncsDefault = parseFloat(removeCommaSep($j("#"+comfa+"_cncs_default").val()));
            if(comfaCncs != ''){
                comfaCncs = parseFloat(comfaCncs);
            }else{
                //comfaCncs = parseFloat($j("#"+comfa+"_cncsprev").val());
            }

            if(noCalCulationForGranteeShare == 0){
                var corfaGrantee = removeCommaSep($j("#"+corfa+"_grantee").val());
                var corfaGranteeDefault = parseFloat(removeCommaSep($j("#"+corfa+"_grantee_default").val()));
                if(corfaGrantee != ''){
                    corfaGrantee = parseFloat(corfaGrantee);
                }else{
                    //corfaGrantee = parseFloat($j("#"+corfa+"_granteeprev").val());
                }

                if((corfaGrantee.toString()).length != 0 && (corfaGranteeDefault != 0)){
                    if(corfaGrantee != corfaGranteeDefault){
                        $j("#updateSec3ToDefault").css("display","inline-block");
                        $j("#updateSec3ToDefaultSpan").css("display","inline-block");
                        $j("#mxGranteeShareChanged").val(1);
                        changesAvailable = true;
                        $j(".sec3ChangesInnerDiv .mxGranteeShare_span .mxGranteeShare_heading").html('- '+sec3Heading+': ');
                        $j(".sec3ChangesInnerDiv .mxGranteeShare_span .mxGranteeShare_lineitem").html('Corporation Fixed Amount (Grantee Share)');
                        $j(".sec3ChangesInnerDiv .mxGranteeShare_span").removeClass('display-none');
                        $j("#corfa_icrChangedId").val(corfa);
                    }else{
                        $j("#mxGranteeShareChanged").val(0);
                        changesAvailable = false;
                        $j(".sec3ChangesInnerDiv .mxGranteeShare_span").addClass('display-none');
                    }
                }
            }

            if((corfaCncs.toString()).length != 0 && (corfaCncsDefault != 0)){
                if(corfaCncs != corfaCncsDefault){
                    $j("#updateSec3ToDefault").css("display","inline-block");
                    $j("#updateSec3ToDefaultSpan").css("display","inline-block");
                    $j("#corfa_icrChanged").val(1);
                    $j(".sec3ChangesInnerDiv .corfa_icr_span .corfa_icr_heading").html('- '+sec3Heading+': ');
                    $j(".sec3ChangesInnerDiv .corfa_icr_span .corfa_icr_lineitem").html('Corporation Fixed Amount (AmeriCorps Share)');
                    $j(".sec3ChangesInnerDiv .corfa_icr_span").removeClass('display-none');
                    changesAvailable = true;
                    $j("#corfa_icrChangedId").val(corfa);
                }else{
                    $j("#corfa_icrChanged").val(0);
                    $j(".sec3ChangesInnerDiv .corfa_icr_span").addClass('display-none');
                    if(!changesAvailable){
                        changesAvailable = false;
                    }
                }
            }

            if((comfaCncs.toString()).length != 0 && (comfaCncsDefault != 0)){
                if(comfaCncs != comfaCncsDefault){
                    $j("#updateSec3ToDefault").css("display","inline-block");
                    $j("#updateSec3ToDefaultSpan").css("display","inline-block");
                    $j("#comfa_cfaChanged").val(1);
                    $j(".sec3ChangesInnerDiv .comfa_cfa_span .comfa_cfa_heading").html('- '+sec3Heading+': ');
                    $j(".sec3ChangesInnerDiv .comfa_cfa_span").removeClass('display-none');
                    changesAvailable = true;
                    $j("#comfa_cfaChangedId").val(comfa);
                }else{
                    $j("#comfa_cfaChanged").val(0);
                    $j(".sec3ChangesInnerDiv .comfa_cfa_span").addClass('display-none');
                    if(!changesAvailable){
                        changesAvailable = false;
                    }
                }
            }

            if(changesAvailable){
                $j(".sec3Changes").removeClass('display-none');
            }else{
                $j(".sec3Changes").addClass('display-none');
            }
        }else if(fundingStructureName == 'Indirect'){
            var sec3Heading = 'Federally Approved Indirect Cost Rate';
            var icrCncs = removeCommaSep($j("#"+icr+"_cncs").val());
            var icrCncsDefault = parseFloat(removeCommaSep($j("#"+icr+"_cncs_default").val()));
            if(icrCncs != ''){
                icrCncs = parseFloat(icrCncs);
            }else{
                //icrCncs = parseFloat($j("#"+icr+"_cncsprev").val());
            }

            var cfaCncs = removeCommaSep($j("#"+cfa+"_cncs").val());
            var cfaCncsDefault = parseFloat(removeCommaSep($j("#"+cfa+"_cncs_default").val()));
            if(cfaCncs != ''){
                cfaCncs = parseFloat(cfaCncs);
            }else{
                //cfaCncs = parseFloat($j("#"+cfa+"_cncsprev").val());
            }

            if(noCalCulationForGranteeShare == 0){
                var icrGrantee = removeCommaSep($j("#"+icr+"_grantee").val());
                var icrGranteeDefault = parseFloat(removeCommaSep($j("#"+icr+"_grantee_default").val()));
                if(icrGrantee != ''){
                    icrGrantee = parseFloat(icrGrantee);
                }else{
                    //icrGrantee = parseFloat($j("#"+icr+"_granteeprev").val());
                }
                
                if((icrGrantee.toString()).length != 0 && icrGranteeDefault != 0){
                    if(icrGrantee != icrGranteeDefault){
                        $j("#updateSec3ToDefault").css("display","inline-block");
                        $j("#updateSec3ToDefaultSpan").css("display","inline-block");
                        $j("#mxGranteeShareChanged").val(1);
                        changesAvailable = true;
                        $j(".sec3ChangesInnerDiv .mxGranteeShare_span .mxGranteeShare_heading").html('- '+sec3Heading+': ');
                        $j(".sec3ChangesInnerDiv .mxGranteeShare_span .mxGranteeShare_lineitem").html('Indirect Cost Rate (Grantee Share)');
                        $j(".sec3ChangesInnerDiv .mxGranteeShare_span").removeClass('display-none');
                        $j("#corfa_icrChangedId").val(icr);
                    }else{
                        $j("#mxGranteeShareChanged").val(0);
                        changesAvailable = false;
                        $j(".sec3ChangesInnerDiv .mxGranteeShare_span").addClass('display-none');
                    }
                }
            }

            if((icrCncs.toString()).length != 0 && icrCncsDefault != 0){
                if(icrCncs != icrCncsDefault){
                    $j("#updateSec3ToDefault").css("display","inline-block");
                    $j("#updateSec3ToDefaultSpan").css("display","inline-block");
                    $j("#corfa_icrChanged").val(1);
                    $j(".sec3ChangesInnerDiv .corfa_icr_span .corfa_icr_heading").html('- '+sec3Heading+': ');
                    $j(".sec3ChangesInnerDiv .corfa_icr_span .corfa_icr_lineitem").html('Indirect Cost Rate (AmeriCorps Share)');
                    $j(".sec3ChangesInnerDiv .corfa_icr_span").removeClass('display-none');
                    $j("#corfa_icrChangedId").val(icr);
                    changesAvailable = true;
                }else{
                    $j("#corfa_icrChanged").val(0);
                    $j(".sec3ChangesInnerDiv .corfa_icr_span").addClass('display-none');
                    if(!changesAvailable){
                        changesAvailable = false;
                    }
                }
            } 

            if((cfaCncs.toString()).length != 0 && cfaCncsDefault != 0){
                if(cfaCncs != cfaCncsDefault){
                    $j("#updateSec3ToDefault").css("display","inline-block");
                    $j("#updateSec3ToDefaultSpan").css("display","inline-block");
                    $j("#comfa_cfaChanged").val(1);
                    $j(".sec3ChangesInnerDiv .comfa_cfa_span .comfa_cfa_heading").html('- '+sec3Heading+': ');
                    $j(".sec3ChangesInnerDiv .comfa_cfa_span").removeClass('display-none');
                    $j("#comfa_cfaChangedId").val(cfa);
                    changesAvailable = true;
                }else{
                    $j("#comfa_cfaChanged").val(0);
                    $j(".sec3ChangesInnerDiv .comfa_cfa_span").addClass('display-none');
                    if(!changesAvailable){
                        changesAvailable = false;
                    }
                }
            }

            if(changesAvailable){
                $j(".sec3Changes").removeClass('display-none');
            }else{
                $j(".sec3Changes").addClass('display-none');
            }
        }
    }
 }  


$j(document).ready(function(){
    $j('.section3AutoCalField').on('change', function() {
        showLinkToSetDefault();
    });

    $j("#updateSec3ToDefault").click(function(){
        var fundingStructureName = $j("#FundingStructureName").val();
        var varconfirm = confirm("Click OK to confirm that you want to remove the edits you made and restore the default calculations.");
        if(varconfirm){
            autoCalc(fundingStructureName,'cncs',9899901);
            $j("#editedField").val('cncs');
            calculateFinal('cncs')
            $j("#editedField").val('grantee');
            calculateFinal('grantee')
            //autoCalc(fundingStructureName,'grantee',989);
            $j("#updateSec3ToDefault").css("display","none");
            $j("#updateSec3ToDefaultSpan").css("display","none");
            $j("#corfa_icrChanged").val(0);
            $j("#comfa_cfaChanged").val(0);
            $j("#mxGranteeShareChanged").val(0);
            $j(".sec3Changes").addClass('display-none');
        }
    });

    $j(".input-budget-increase").change(function(){
        var BudgetInccontributedFor = $j(this).attr('data-contributedFor');
        var inputBudgetIncValue = removeCommaSep($j(this).val());
        $j("#editedSection").val(''); // edited should be blank to get correct edited section info

        if(inputBudgetIncValue == '' || isNaN(inputBudgetIncValue)){
            if(inputBudgetIncValue == ''){
                $j(this).val('');
            }else{
                $j(this).val('0.00');
            }
            inputBudgetIncValue = 0;
        }else{
            $j(this).val(addCommaSep(inputBudgetIncValue));
        }

        var cncsSec1Available = 0;
        var granteeSec1Available = 0;
        var granteeinkindSec1Available = 0;
        var cncsSec2Available = 0;
        var granteeSec2Available = 0;
        var granteeinkindSec2Available = 0;
        var sec1SubId = $j("#sec1Sub").val();
        var sec2SubId = $j("#sec2Sub").val();
        if(sec1SubId != undefined){
            cncsSec1Available = parseFloat(removeCommaSep($j("#"+sec1SubId+"_cncsprev").val()));
            granteeSec1Available = parseFloat(removeCommaSep($j("#"+sec1SubId+"_granteeprev").val()));
            granteeinkindSec1Available = parseFloat(removeCommaSep($j("#"+sec1SubId+"_granteeinkindprev").val()));
        }

        if(sec2SubId != undefined){
            cncsSec2Available = parseFloat(removeCommaSep($j("#"+sec2SubId+"_cncsprev").val()));
            granteeSec2Available = parseFloat(removeCommaSep($j("#"+sec2SubId+"_granteeprev").val()));
            granteeinkindSec2Available = parseFloat(removeCommaSep($j("#"+sec2SubId+"_granteeinkindprev").val()));
        }

        var cncsTotalAvailable = cncsSec1Available + cncsSec2Available;
        var granteeTotalAvailable = granteeSec1Available + granteeSec2Available;
        var granteeinkindTotalAvailable = granteeinkindSec1Available + granteeinkindSec2Available;
        var checkReturn = true;

        if(BudgetInccontributedFor == 'cncs' && (cncsTotalAvailable + parseFloat(inputBudgetIncValue)) < 0){
            checkReturn = false;
        }else if(BudgetInccontributedFor == 'grantee' && (granteeTotalAvailable + parseFloat(inputBudgetIncValue)) < 0){
            checkReturn = false;
        }else if(BudgetInccontributedFor == 'granteeinkind' && (granteeinkindTotalAvailable + parseFloat(inputBudgetIncValue)) < 0){     
            checkReturn = false;
        }
        
        if(checkReturn){
            if(BudgetInccontributedFor == 'cncs'){
                $j(".input-grantee").attr('readonly', true);
                $j(".input-cncs").attr('readonly', false);
                //$j(".input-grantee_Section3").attr('readonly', false);
                $j(".input-cncs").each(function(){ 
                    if($j(this).hasClass('input-readonly')){
                        $j(this).attr('readonly', true);
                    }else{
                        $j(this).attr('readonly', false);
                    }
                });
                $j("#editedField").val('cncs');
                $j(".reconcile-grantee").html('Locked Until AmeriCorps Share is Balanced');
                $j(".reconcile-grantee-secIII").css("display","none");
                $j(".or-text-grantee").css("display","none");
            }else if(BudgetInccontributedFor == 'grantee' || BudgetInccontributedFor == 'granteeinkind'){
                $j(".input-cncs").attr('readonly', true);
                $j(".input-grantee").attr('readonly', false);
                //$j(".input-cncs_Section3").attr('readonly', false);
                $j(".input-grantee").each(function(){ 
                    if($j(this).hasClass('input-readonly')){
                        $j(this).attr('readonly', true);
                    }else{
                        $j(this).attr('readonly', false);
                    }
                });
                $j("#editedField").val('grantee');
                $j(".reconcile-cncs").html('Locked Until Grantee Share is Balanced');
                $j(".reconcile-cncs-secIII").css("display","none");
                $j(".or-text-cncs").css("display","none");
            }
            
            addBudgetIncrese(BudgetInccontributedFor,inputBudgetIncValue);
        }else{
            alert('When reducing the budget, the amount entered cannot exceed the current total money available to modify in Sections I and II for each column.\n Total available money to reduce from Section I and II is \n Americorps : '+cncsTotalAvailable+'\n Grantee Cash : '+granteeTotalAvailable+'\n Grantee InKind : '+granteeinkindTotalAvailable);
            $j(this).val('');
            return false;
        }
    });

    $j(".close-modal-popup").click(function(){
        var compId = $j(".amount-already-spent").attr("data-inputfocus");
        $j("#container").css("visibility","hidden");
        $j("#container").css("display","none");
        $j("body").removeClass('overflow-hidden');
        $j("#budgetDetailUpdate").removeClass("pointer-allowed");
        $j(".amount-already-spent").html(0);
        $j(".amount-already-spent").attr("data-inputfocus","0");
        $j("#"+compId).focus();
    });

    var ctrlDown = false, ctrlKey = 17, cmdKey = 91, vKey = 86, cKey = 67;
    $j(".input-number").keydown(function(e) {
        if (e.keyCode == ctrlKey || e.keyCode == cmdKey) ctrlDown = true;
    }).keyup(function(e) {
        if (e.keyCode == ctrlKey || e.keyCode == cmdKey) ctrlDown = false;
    });
    
    $j(".input-number").on('keydown keyup', function(evt) {
        var self = $(this);
        var inputId = self.attr('id');
        var cursorPos = evt.target.selectionStart;
        var cursorEnd = evt.target.selectionEnd;
        var currentVal = self.val();
        var currentValCommaCount = 0;
        if (currentVal.indexOf(',') > -1) { 
            currentValCommaCount = (currentVal.match(/,/g)).length;
        }

        self.val(addCommaSep(removeCommaSep(self.val())));
        if (evt.which != 46 && evt.which != 110 && evt.which != 190 && evt.which != 8 && evt.which != 17 && evt.which != 37 && evt.which != 39 && evt.which != 9
            && (evt.which < 48 || evt.which > 57)) {   
            if(evt.which < 96 || evt.which > 105){
                if (!ctrlDown || (evt.which != cKey && evt.which != vKey)){
                    self.val(self.val().replace(/[^0-9\.]/g, ''));
                    evt.preventDefault();
                }
            }
            
        }

        var newVal = self.val();
        var newValCommaCount = 0;
        if (newVal.indexOf(',') > -1) { 
            newValCommaCount = (newVal.match(/,/g)).length;
        }        
        var inputHtmlEl = document.getElementById(inputId);
        var selectedVal = inputHtmlEl.value.substring(inputHtmlEl.selectionStart,inputHtmlEl.selectionEnd);
        evt.target.setSelectionRange(cursorPos, cursorEnd);

        if(selectedVal == ''){
            if (evt.which != 46 && evt.which != 110 && evt.which != 190 /*&& evt.which != 8*/ && evt.which != 17 && evt.which != 37 && evt.which != 39 && evt.which != 9) {   
                //if(evt.which < 96 || evt.which > 105){
                    if (!ctrlDown || (evt.which != cKey && evt.which != vKey)){
                        if ((inputHtmlEl.setSelectionRange && evt.which != 8) || (evt.which == 8 && cursorPos > 0)) {
                            if (evt.which != 110 && evt.which != 190) {
                                if(currentValCommaCount < newValCommaCount){
                                    cursorPos = cursorPos + 1;
                                }else if(currentValCommaCount > newValCommaCount){
                                    cursorPos = cursorPos - 1;
                                }
                            }

                            inputHtmlEl.focus();
                            inputHtmlEl.setSelectionRange(self.val().length, cursorPos);
                        }
                    }
                //}
            }
        }
    });
    
    $j(".input-budget-increase").keydown(function(e) {
        if (e.keyCode == ctrlKey || e.keyCode == cmdKey) ctrlDown = true;
    }).keyup(function(e) {
        if (e.keyCode == ctrlKey || e.keyCode == cmdKey) ctrlDown = false;
    });
    
    $j(".input-budget-increase").on('keydown keyup', function(evt) {
        var self = $(this);
        var inputId = self.attr('id');
        var cursorPos = evt.target.selectionStart;
        var currentVal = self.val();
        var currentValCommaCount = 0;
        if (currentVal.indexOf(',') > -1) { 
            currentValCommaCount = (currentVal.match(/,/g)).length;
        }

        self.val(addCommaSep(removeCommaSep(self.val())));
        if (evt.which != 173 && evt.which != 189 && evt.which != 46 && evt.which != 110 && evt.which != 190 && evt.which != 8 && evt.which != 17 && evt.which != 37 && evt.which != 39 && evt.which != 9
            && (evt.which < 48 || evt.which > 57)) {   
            if(evt.which < 96 || evt.which > 105){
                if (!ctrlDown || (evt.which != cKey && evt.which != vKey)){
                    self.val(addCommaSep(removeCommaSep(self.val()).replace(/[^0-9\.]/g, '')));
                    evt.preventDefault();
                }
            }
            
        }
        
        var newVal = self.val();
        var newValCommaCount = 0;
        if (newVal.indexOf(',') > -1) { 
            newValCommaCount = (newVal.match(/,/g)).length;
        }        
        var inputHtmlEl = document.getElementById(inputId);
        var selectedVal = inputHtmlEl.value.substring(inputHtmlEl.selectionStart,inputHtmlEl.selectionEnd);

        if(selectedVal == ''){
            if (evt.which != 46 && evt.which != 110 && evt.which != 190 /*&& evt.which != 8*/ && evt.which != 17 && evt.which != 37 && evt.which != 39 && evt.which != 9) {   
                if(evt.which < 96 || evt.which > 105){
                    if (!ctrlDown || (evt.which != cKey && evt.which != vKey)){
                        if ((inputHtmlEl.setSelectionRange && evt.which != 8) || (evt.which == 8 && cursorPos > 0)) {
                            if(currentValCommaCount < newValCommaCount){
                                cursorPos = cursorPos + 1;
                            }else if(currentValCommaCount > newValCommaCount){
                                cursorPos = cursorPos - 1;
                            }

                            inputHtmlEl.focus();
                            inputHtmlEl.setSelectionRange(self.val().length, cursorPos);
                        }
                    }
                }
            }
        }
    });

    $j('.enableAutoCalc').click(function() {
        $j(".update-box").css("visibility","hidden");
        $j(".update-box").css("display","none");
        $j("body").removeClass('overflow-hidden');
        $j("#budgetDetailUpdate").removeClass("pointer-allowed");
        $j('#sec3AutoAdjust').val(1);
        $j('#' + ($j("#firstModifiedInputId").val())).trigger('change');
        $j("#firstModifiedInputId").val("");
        $j('#btnSec3AutoAdjust').prop('checked', true);
        $j('.sec3Toggle').css("display","flex");
        $j(".sec3Toggle").removeClass("mb-10-neg");
        var reconcileWindowHeight = $j(".budget-bottom-info-container").height();
        if(reconcileWindowHeight > 60){
            $j(".budgetMod-button-div").css("padding-bottom","168px");
        }else{
            $j(".budgetMod-button-div").css("padding-bottom","135px");
        }
    });
        
    $j('.disableAutoCalc').click(function() {
        $j(".update-box").css("visibility","hidden");
        $j(".update-box").css("display","none");
        $j("body").removeClass('overflow-hidden');
        $j("#budgetDetailUpdate").removeClass("pointer-allowed");
        $j('#sec3AutoAdjust').val(0);
        $j('#' + ($j("#firstModifiedInputId").val())).trigger('change');
        $j("#firstModifiedInputId").val("");
        $j('#btnSec3AutoAdjust').prop('checked', false);
        $j('.sec3Toggle').css("display","flex");
        $j(".sec3Toggle").removeClass("mb-10-neg");
        var reconcileWindowHeight = $j(".budget-bottom-info-container").height();
        if(reconcileWindowHeight > 60){
            $j(".budgetMod-button-div").css("padding-bottom","168px");
        }else{
            $j(".budgetMod-button-div").css("padding-bottom","135px");
        }
    });

    $j("#btnSec3AutoAdjust").change(function() {
        if ($j(this).is(":checked")) {
            $j("#sec3AutoAdjust").val(1);
            $j(".input-grantee").each(function(){
                if($j(this).val() != 'undefined' && $j(this).val() != undefined && $j(this).val() != '' && !$j(this).hasClass('input-budget-increase')){
                    inputTriggerGrantee = $j(this).attr('id');
                    return false;
                }
            });
            if(inputTriggerGrantee != ''){
                $j('#'+inputTriggerGrantee).trigger('change');
            }
            $j(".input-cncs").each(function(){
                if($j(this).val() != 'undefined' && $j(this).val() != undefined && $j(this).val() != '' && !$j(this).hasClass('input-budget-increase')){
                    inputTriggerCncs = $j(this).attr('id');
                    return false;
                }
            });
            if(inputTriggerCncs != ''){
                $j('#'+inputTriggerCncs).trigger('change');
            }
            
        } else {
            $j("#sec3AutoAdjust").val(0);
            section3adjust();
        }
    });

    function section3adjust(){
        var corfa = $j('#corfa').val();
        var comfa = $j('#comfa').val();
        var icr = $j('#icr').val();
        var cfa = $j('#cfa').val();
        var fundingStructureName = $j("#FundingStructureName").val();
        var useSection3 = true;
        if(FundingStructureBudgetType == 'Fixed'){
            if($j("#useSectionIII").val() == 0){
                useSection3 = false;
            }
        }

        if(useSection3 && (corfa != undefined || icr != undefined)){
            if(fundingStructureName == 'NonIndirect'){
                $j("#"+corfa+"_cncs").val($j("#"+corfa+"_cncsprev").val());
                $j('#'+corfa+"_cncs").trigger('change');
                $j("#"+corfa+"_grantee").val($j("#"+corfa+"_granteeprev").val());
                $j('#'+corfa+"_grantee").trigger('change');
                $j("#"+comfa+"_cncs").val($j("#"+comfa+"_cncsprev").val());
                $j('#'+comfa+"_cncs").trigger('change');
                $j("#"+comfa+"_grantee").val($j("#"+comfa+"_granteeprev").val());
                $j('#'+comfa+"_grantee").trigger('change');       
            }else if(fundingStructureName == 'Indirect'){
                $j("#"+icr+"_cncs").val($j("#"+icr+"_cncsprev").val());
                $j('#'+icr+"_cncs").trigger('change');
                $j("#"+icr+"_grantee").val($j("#"+icr+"_granteeprev").val());
                $j('#'+icr+"_grantee").trigger('change');
                $j("#"+cfa+"_cncs").val($j("#"+cfa+"_cncsprev").val());
                $j('#'+cfa+"_cncs").trigger('change');
                $j("#"+cfa+"_grantee").val($j("#"+cfa+"_granteeprev").val());
                $j('#'+cfa+"_grantee").trigger('change');
            }

            // code start: to recheck reconciliation
            var firtCompId = $j("#firstCompId").val();
            var firtCompIdCncsVal = $j("#"+firtCompId+"_cncs").val();
            if(firtCompIdCncsVal == ""){
                firtCompIdCncsVal = $j("#"+firtCompId+"_cncsprev").val();
            }
            $j("#"+firtCompId+"_cncs").val(firtCompIdCncsVal);
            $j("#"+firtCompId+"_cncs").trigger("change");
            // code end: to recheck reconciliation
        }
    }

    $j('.input-number').change(function(){
        var amountAlreadySpentJsFailed = false;
        var compId = $j(this).attr('data-componentId');
        var contributedFor = $j(this).attr('data-contributedFor');
        var inputValue = $j(this).val();
        var fundingStructureName = $j("#FundingStructureName").val();
        var editedSection =  $j(this).attr('data-section');
        var finalCompId = $j('#finalCompId').val();

        var corfa = $j('#corfa').val();
        var icr = $j('#icr').val();
        var useSection3 = true;
        var FundingStructureBudgetType = $j("#FundingStructureBudgetType").val();
        if(FundingStructureBudgetType == 'Fixed'){
            if($j("#useSectionIII").val() == 0){
                useSection3 = false;
            }
        }

        if(inputValue == ''){
            var value = 0;
            var expenses = removeCommaSep($j("#"+compId+"_"+contributedFor+"expense").val());
            if(expenses != ''){
                expenses = parseFloat(expenses);
            }else{
                expenses = 0;
            }
            if(value < expenses){
                inputValue = parseFloat(removeCommaSep($j("#"+compId+"_"+contributedFor+"prev").val()));
                value =  Math.abs(parseFloat(inputValue));
                $j(this).val(addCommaSep(inputValue.toFixed(2)));
            }else{
                $j(this).val(addCommaSep(value.toFixed(2)));
                alert("A 0 was just inserted into the cell you just left because it was blank. Please check to make sure that's what you need.");
            }
        }else{
            var value = Math.abs(parseFloat(removeCommaSep(inputValue)));
            var expenses = removeCommaSep($j("#"+compId+"_"+contributedFor+"expense").val());
            if(expenses != ''){
                expenses = parseFloat(expenses);
            }else{
                expenses = 0;
            }
            var modificationCanBeLessThanExpense_Not =  $j("#modificationCanBeLessThanExpense_Not").val();            

            if(value < expenses && modificationCanBeLessThanExpense_Not == '1'){
                inputValue = parseFloat(removeCommaSep($j("#"+compId+"_"+contributedFor+"prev").val()));
                value =  Math.abs(parseFloat(inputValue));
                $j(this).val(addCommaSep(inputValue));             
                $j(".amount-already-spent").html(addCommaSep(expenses));
                amountAlreadySpentJsFailed = true;
                $j("#container").css("visibility","visible");
                $j("#container").css("display","block");
                $j("body").addClass('overflow-hidden');
                $j("#budgetDetailUpdate").addClass("pointer-allowed");
                $j(".amount-already-spent").attr("data-inputfocus",compId+'_'+contributedFor);
                //return false;
            }else{
                inputValue = removeCommaSep(inputValue);
                $j(this).val(addCommaSep(parseFloat(inputValue).toFixed(2)));
            }
        }

        var autoAdjustConfirmed = true;
        if(amountAlreadySpentJsFailed == false){
            if($j('#sec3AutoAdjust').val() == "-1" && $j(this).attr('data-section') != "section3" && $j("#useSectionIII").val() != 0){
                $j(".update-box").css("visibility","visible");
                $j(".update-box").css("display","block");
                $j("body").addClass('overflow-hidden');
                $j("#budgetDetailUpdate").removeClass("pointer-allowed");
                $j("#firstModifiedInputId").val($j(this).attr('id'));
                return false;
            }else if($j('#sec3AutoAdjust').val() == "1" || $j('#sec3AutoAdjust').val() == "2") {
                autoAdjustConfirmed = true;
            }else if($j('#sec3AutoAdjust').val() == "0"){
                autoAdjustConfirmed = false;
            }
        }

        inputChangedSection = $j('#'+compId+"_"+contributedFor).attr('data-section');
        var isChildInput = $j("#"+compId+"_"+contributedFor).attr("data-inputtype");
        if(!(inputChangedSection in componentChangedStruct)){
            componentChangedStruct[inputChangedSection] = [];
        }
        var tempArr = componentChangedStruct[inputChangedSection];
        if(isChildInput != undefined && isChildInput == 'child'){
            var changedCompId = $j("#"+compId+"_"+contributedFor).attr("data-parentCompId");
            tempArr = $j.grep(tempArr, function(value) {
                return value != changedCompId;
            });
            tempArr.push(parseFloat(changedCompId));
            componentChangedStruct[inputChangedSection] = tempArr;
        }else{
            var changedCompId = $j("#"+compId+"_"+contributedFor).attr("data-componentId");
            tempArr = $j.grep(tempArr, function(value) {
                return value != changedCompId;
            });
            tempArr.push(parseFloat(changedCompId));
            componentChangedStruct[inputChangedSection] = tempArr;
        }
        
        if((inputChangedSection in componentChangedStruct)){
            if(componentChangedStruct[inputChangedSection].length){
                var changedTo = '';
                var sectionArr = componentChangedStruct[inputChangedSection];
                sectionArr = sectionArr.sort();
                sectionArr = sectionArr.sort(function(a, b){return a - b});	
                if(sectionArr.length){
                    for(var i=0; i<sectionArr.length; i++){
                        if(changedTo != ''){
                            changedTo = changedTo + ', ' + $j("#componentText_"+sectionArr[i]).val();
                        }else{
                            changedTo = '<span style="width:20%;">Changes made to:</span> <span style="width:88%;">'+$j("#componentText_"+sectionArr[i]).val();
                        }
                    }
                }
                $j("#changesmadeto"+inputChangedSection).html(changedTo + '</span>');
            }
        }else{
            $j("#changesmadeto"+inputChangedSection).html('');
        }
        
        var prevValue = parseFloat(removeCommaSep($j("#"+compId+"_"+contributedFor+"prev").val()));
        var calculateFor = $j(this).attr('data-calcFor');

        if(contributedFor == 'cncs'){
            $j(".input-grantee").attr('readonly', true);
            $j(".input-cncs").attr('readonly', false);    
            //$j(".input-grantee_Section3").attr('readonly', false);
            $j(".input-cncs").each(function(){ 
                if($j(this).hasClass('input-readonly')){
                    $j(this).attr('readonly', true);
                }else{
                    $j(this).attr('readonly', false);
                }
            });
            $j("#editedField").val('cncs');
            $j("#editedSection").val(editedSection);
            $j(".reconcile-grantee").html('Locked Until AmeriCorps Share is Balanced');            
            $j(".reconcile-grantee-secIII").css("display","none");
            $j(".or-text-grantee").css("display","none");
            var garnteeValue =  removeCommaSep($j('#'+compId+'_grantee').val());
            var garnteeInKindValue =  removeCommaSep($j('#'+compId+'_granteeinkind').val());
        
            if(garnteeValue == '' && inputValue == '' && garnteeInKindValue == ''){
                var totalValue = '';
            }else{
                if(garnteeValue != ''){
                    var totalValue = value+parseFloat(garnteeValue);
                    if(garnteeInKindValue != ''){
                        totalValue = totalValue + parseFloat(garnteeInKindValue);
                    }
                }else if (garnteeInKindValue != ''){
                    var totalValue = value+parseFloat(garnteeInKindValue);
                }else{
                    if(inputValue == ''){
                        var totalValue = '';
                    }else{
                        var garnteePrevValue =  removeCommaSep($j('#'+compId+'_granteeprev').val());
                        var garnteeinkindPrevValue =  removeCommaSep($j('#'+compId+'_granteeinkindprev').val());

                        if(garnteePrevValue != ''){
                            $j("#"+compId+"_grantee").val(addCommaSep(garnteePrevValue));
                            $j("."+compId+"_grantee_change_value").html('$0.00');
                            $j("."+compId+"_grantee_change_percent").html('(0.00%)');
                            var totalValue = parseFloat(inputValue)+parseFloat(garnteePrevValue);

                            if(garnteeinkindPrevValue != ''){
                                $j("#"+compId+"_granteeinkind").val(addCommaSep(garnteeinkindPrevValue));
                                $j("."+compId+"_granteeinkind_change_value").html('$0.00');
                                $j("."+compId+"_granteeinkind_change_percent").html('(0.00%)');
                                totalValue = totalValue+parseFloat(garnteeinkindPrevValue);
                            }
                        }else if(garnteeinkindPrevValue != ''){
                            $j("#"+compId+"_granteeinkind").val(addCommaSep(garnteeinkindPrevValue));
                            $j("."+compId+"_granteeinkind_change_value").html('$0.00');
                            $j("."+compId+"_granteeinkind_change_percent").html('(0.00%)');
                            var totalValue = parseFloat(inputValue)+parseFloat(garnteeinkindPrevValue);
                        }else{
                            var totalValue = '';
                        }
                    }
                }
            }
            //change in percent
            var prevTotalValue = parseFloat(removeCommaSep($j("#"+compId+"_totalprev").val()));
            var totalNewValue = removeCommaSep($j("#"+compId+"_totalnew").val());
            if(totalNewValue != ''){
                totalNewValue = parseFloat(totalNewValue);
            }
            var totalChangePercent = $j("#totalChangePercent").val();
            var totalLineChange = parseInt($j("#totalLineChange").val());
            
            calculateChangePercent(compId, totalChangePercent, totalValue, prevTotalValue, totalNewValue, totalLineChange, contributedFor, value, prevValue)
            
            //$j('#'+compId+'_total').val(totalValue);
            calculateSubTotal(calculateFor);

            if($j('#'+calculateFor).attr('data-isCalculated')  == 1){
                var Parentformula = $j('#'+calculateFor).attr('data-parentFormula');
                var ParentformulaSign = $j('#'+calculateFor).attr('data-parenrFormulaSign');
                var parentCalFor = $j('#'+calculateFor).attr('data-parentFormulaCalFor');
                var section = $j('#'+calculateFor).attr('data-section');
                if(Parentformula != undefined && Parentformula != ''){
                    calculateParent(Parentformula, ParentformulaSign, parentCalFor);
                }
            }

            if(autoAdjustConfirmed && useSection3 && (corfa != undefined || icr != undefined)){
                autoCalc(fundingStructureName,contributedFor,compId, totalValue, prevTotalValue, totalNewValue, value, prevValue);
            // autoCalc(fundingStructureName,'grantee',compId, totalValue, prevTotalValue, totalNewValue, value, prevValue);
            }

            calculatePercent(section,contributedFor);
            claculateCombinedSection(section,contributedFor);
        }else if(contributedFor == 'grantee'){
            $j(".input-cncs").attr('readonly', true);
            $j(".input-grantee").attr('readonly', false);
            //$j(".input-cncs_Section3").attr('readonly', false);
            $j(".input-grantee").each(function(){ 
                if($j(this).hasClass('input-readonly')){
                    $j(this).attr('readonly', true);
                }else{
                    $j(this).attr('readonly', false);
                }
            });
            $j("#editedField").val('grantee');
            $j("#editedSection").val(editedSection);
            $j(".reconcile-cncs").html('Locked Until Grantee Share is Balanced');
            $j(".reconcile-cncs-secIII").css("display","none");
            $j(".or-text-cncs").css("display","none");
            var cncsValue =  removeCommaSep($j('#'+compId+'_cncs').val());
            var garnteeInKindValue =  removeCommaSep($j('#'+compId+'_granteeinkind').val());
            if(cncsValue == '' && inputValue == '' && garnteeInKindValue == ''){
                var totalValue = '';
            }else{
                if(cncsValue != ''){
                    var totalValue = value+parseFloat(cncsValue);
                    if(garnteeInKindValue != ''){
                        totalValue = totalValue + parseFloat(garnteeInKindValue);
                    }
                }else if (garnteeInKindValue != ''){
                    var totalValue = value+parseFloat(garnteeInKindValue);
                }else{
                    if(inputValue == ''){
                        var totalValue = '';
                    }else{
                        var cncsPrevValue =  removeCommaSep($j('#'+compId+'_cncsprev').val());
                        var garnteeinkindPrevValue =  removeCommaSep($j('#'+compId+'_granteeinkindprev').val());
                        if(cncsPrevValue != ''){
                            $j("#"+compId+"_cncs").val(addCommaSep(cncsPrevValue));
                            $j("."+compId+"_cncs_change_value").html('$0.00');
                            $j("."+compId+"_cncs_change_percent").html('(0.00%)');
                            var totalValue = parseFloat(inputValue)+parseFloat(cncsPrevValue);

                            if(garnteeinkindPrevValue != ''){
                                $j("#"+compId+"_granteeinkind").val(addCommaSep(garnteeinkindPrevValue));
                                $j("."+compId+"_granteeinkind_change_value").html('$0.00');
                                $j("."+compId+"_granteeinkind_change_percent").html('(0.00%)');
                                totalValue = totalValue+parseFloat(garnteeinkindPrevValue);
                            }
                        }else if(garnteeinkindPrevValue != ''){
                            $j("#"+compId+"_granteeinkind").val(addCommaSep(garnteeinkindPrevValue));
                            $j("."+compId+"_granteeinkind_change_value").html('$0.00');
                            $j("."+compId+"_granteeinkind_change_percent").html('(0.00%)');
                            var totalValue = parseFloat(inputValue)+parseFloat(garnteeinkindPrevValue);
                        }else{
                            var totalValue = '';
                        }
                    }
                }
            }

            var prevTotalValue = parseFloat(removeCommaSep($j("#"+compId+"_totalprev").val()));
            var totalNewValue = removeCommaSep($j("#"+compId+"_totalnew").val());
            if(totalNewValue != ''){
                totalNewValue = parseFloat(totalNewValue);
            }
            var totalChangePercent = $j("#totalChangePercent").val();
            var totalLineChange = parseInt($j("#totalLineChange").val());

            calculateChangePercent(compId, totalChangePercent, totalValue, prevTotalValue, totalNewValue, totalLineChange, contributedFor, value, prevValue)

            //$j('#'+compId+'_total').val(totalValue);
            calculateSubTotal(calculateFor);
            if($j('#'+calculateFor).attr('data-isCalculated')  == 1){
                var Parentformula = $j('#'+calculateFor).attr('data-parentFormula');
                var ParentformulaSign = $j('#'+calculateFor).attr('data-parenrFormulaSign');
                var parentCalFor = $j('#'+calculateFor).attr('data-parentFormulaCalFor');
                var section = $j('#'+calculateFor).attr('data-section');
                if(Parentformula != undefined && Parentformula != ''){
                    calculateParent(Parentformula, ParentformulaSign, parentCalFor);
                }
            }
            
            if(autoAdjustConfirmed && useSection3 && (corfa != undefined || icr != undefined)){
                autoCalc(fundingStructureName,contributedFor,compId, totalValue, prevTotalValue, totalNewValue, value, prevValue);
            }
            calculatePercent(section,contributedFor);
            claculateCombinedSection(section,contributedFor);
        }else if(contributedFor == 'granteeinkind'){
            $j(".input-cncs").attr('readonly', true);
            $j(".input-grantee").attr('readonly', false);
            //$j(".input-cncs_Section3").attr('readonly', false);
            $j(".input-grantee").each(function(){ 
                if($j(this).hasClass('input-readonly')){
                    $j(this).attr('readonly', true);
                }else{
                    $j(this).attr('readonly', false);
                }
            });
            $j("#editedField").val('grantee');
            $j("#editedSection").val(editedSection);
            $j(".reconcile-cncs").html('Locked Until Grantee Share is Balanced');
            $j(".reconcile-cncs-secIII").css("display","none");
            $j(".or-text-cncs").css("display","none");
            var cncsValue =  removeCommaSep($j('#'+compId+'_cncs').val());
            var garnteeValue =  removeCommaSep($j('#'+compId+'_grantee').val());
            if(cncsValue == '' && inputValue == '' && garnteeValue == ''){
                var totalValue = '';
            }else{
                if(cncsValue != ''){
                    var totalValue = value+parseFloat(cncsValue);
                    if(garnteeValue != ''){
                        totalValue = totalValue + parseFloat(garnteeValue);
                    }
                }else if (garnteeValue != ''){
                    var totalValue = value+parseFloat(garnteeValue);
                }else{
                    if(inputValue == ''){
                        var totalValue = '';
                    }else{
                        var cncsPrevValue =  removeCommaSep($j('#'+compId+'_cncsprev').val());
                        var garnteePrevValue =  removeCommaSep($j('#'+compId+'_granteeprev').val());
                        if(cncsPrevValue != ''){
                            $j("#"+compId+"_cncs").val(addCommaSep(cncsPrevValue));
                            $j("."+compId+"_cncs_change_value").html('$0.00');
                            $j("."+compId+"_cncs_change_percent").html('(0.00%)');
                            var totalValue = parseFloat(inputValue)+parseFloat(cncsPrevValue);

                            if(garnteePrevValue != ''){
                                $j("#"+compId+"_grantee").val(addCommaSep(garnteePrevValue));
                                $j("."+compId+"_grantee_change_value").html('$0.00');
                                $j("."+compId+"_grantee_change_percent").html('(0.00%)');
                                totalValue = totalValue+parseFloat(garnteePrevValue);
                            }
                        }else if(garnteePrevValue != ''){
                            $j("#"+compId+"_grantee").val(addCommaSep(garnteePrevValue));
                            $j("."+compId+"_grantee_change_value").html('$0.00');
                            $j("."+compId+"_grantee_change_percent").html('(0.00%)');
                            var totalValue = parseFloat(inputValue)+parseFloat(garnteePrevValue);
                        }else{
                            var totalValue = '';
                        }
                    }
                }
            }

            var prevTotalValue = parseFloat(removeCommaSep($j("#"+compId+"_totalprev").val()));
            var totalNewValue = removeCommaSep($j("#"+compId+"_totalnew").val());
            if(totalNewValue != ''){
                totalNewValue = parseFloat(totalNewValue);
            }
            var totalChangePercent = $j("#totalChangePercent").val();
            var totalLineChange = parseInt($j("#totalLineChange").val());

            calculateChangePercent(compId, totalChangePercent, totalValue, prevTotalValue, totalNewValue, totalLineChange, contributedFor, value, prevValue)

            //$j('#'+compId+'_total').val(totalValue);
            calculateSubTotal(calculateFor);
            if($j('#'+calculateFor).attr('data-isCalculated')  == 1){
                var Parentformula = $j('#'+calculateFor).attr('data-parentFormula');
                var ParentformulaSign = $j('#'+calculateFor).attr('data-parenrFormulaSign');
                var parentCalFor = $j('#'+calculateFor).attr('data-parentFormulaCalFor');
                var section = $j('#'+calculateFor).attr('data-section');
                if(Parentformula != undefined && Parentformula != ''){
                    calculateParent(Parentformula, ParentformulaSign, parentCalFor);
                }
            }
            if(autoAdjustConfirmed && useSection3 && (corfa != undefined || icr != undefined)){
                autoCalc(fundingStructureName,contributedFor,compId);  
            }
            calculatePercent(section,contributedFor);
            claculateCombinedSection(section,contributedFor);
        }
    });
});

function autoCalc(fundingStructureName, contributedFor, compId, totalValue, prevTotalValue, totalNewValue, value, prevValue){
    var sec1Sub = $j('#sec1Sub').val();
    var sec2Sub = $j('#sec2Sub').val();
    var sec3Sub = $j('#sec3Sub').val();
    var sec3Percent = $j('#sec3Percent').val();
    var SectionITotal = removeCommaSep($j('#'+sec1Sub+'_'+contributedFor).val());
    var SectionIITotal = removeCommaSep($j('#'+sec2Sub+'_'+contributedFor).val());
    if(SectionIITotal == undefined || SectionIITotal == 'undefined' || SectionIITotal == NaN || SectionIITotal == 'NaN' || isNaN(SectionIITotal)){
        SectionIITotal = 0.00;
    }
    var SectionITotal_Total = removeCommaSep($j('#'+sec1Sub+'_total').val());
    var SectionIITotal_Total = removeCommaSep($j('#'+sec2Sub+'_total').val());
    if(SectionIITotal_Total == undefined || SectionIITotal_Total == 'undefined' || SectionIITotal_Total == NaN || SectionIITotal_Total == 'NaN' || isNaN(SectionIITotal_Total)){
        SectionIITotal_Total = 0.00;
    }

    //calculateChangePercent(compId, totalChangePercent, totalValue, prevTotalValue, totalNewValue, totalLineChange, contributedFor, value, prevValue)

    if(SectionITotal != '' && SectionITotal != undefined && SectionITotal != 'undefined'){
        SectionITotal = parseFloat(SectionITotal);
    }else{
        SectionITotal = removeCommaSep($j("#"+sec1Sub+"_"+contributedFor+"prev").val());
        if(SectionITotal != '' && SectionITotal != undefined && SectionITotal != 'undefined'){
            SectionITotal = parseFloat(SectionITotal);
        }else{
            SectionITotal = 0;
        }
    }

    if(SectionIITotal != ''){
        SectionIITotal = parseFloat(SectionIITotal);
    }else{
        SectionIITotal = parseFloat(removeCommaSep($j("#"+sec2Sub+"_"+contributedFor+"prev").val()));
    }
    if(SectionIITotal == undefined || SectionIITotal == 'undefined' || SectionIITotal == NaN || SectionIITotal == 'NaN' || isNaN(SectionIITotal)){
        SectionIITotal = 0.00;
    }

    if(SectionITotal_Total != ''){
        SectionITotal_Total = parseFloat(SectionITotal_Total);
    }else{
        SectionITotal_Total = parseFloat(removeCommaSep($j("#"+sec1Sub+"_totalprev").val()));
    }

    if(SectionIITotal_Total != ''){
        SectionIITotal_Total = parseFloat(SectionIITotal_Total);
    }else{
        SectionIITotal_Total = parseFloat(removeCommaSep($j("#"+sec2Sub+"_totalprev").val()));
    }
    if(SectionIITotal_Total == undefined || SectionIITotal_Total == 'undefined' || SectionIITotal_Total == NaN || SectionIITotal_Total == 'NaN' || isNaN(SectionIITotal_Total)){
        SectionIITotal_Total = 0.00;
    }

    var FundingStructureBudgetType = $j("#FundingStructureBudgetType").val();
    var indirectCostRatePercentCalc = parseFloat($j("#indirectCostRatePercentCalc").val()); //0.8
    var programFixedPercentCalc = parseFloat($j("#programFixedPercentCalc").val()); //0.8
    var noCalCulationForGranteeShare = $j("#noCalCulationForGranteeShare").val();
    var commissionFixedPercentCalc = parseFloat($j("#commissionFixedPercentCalc").val()); //0.2
    var maxAmountAmericorpShare = parseFloat($j("#maxAmountAmericorpShare").val()); //0.0526
    var maxAmountRequestAsGranteeShare = parseFloat($j("#maxAmountRequestAsGranteeShare").val()); //0.1
    var subtractCorfaWithSec3Acfs = parseFloat($j("#subtractCorfaWithSec3Acfs").val());
    var corfa_icrZeroInclude = parseFloat($j("#corfa_icrZeroInclude").val()); // It is for indirectCostRatePercentCalc, programFixedPercentCalc
    var comfa_cfaZeroInclude = parseFloat($j("#comfa_cfaZeroInclude").val()); // It is for commissionFixedPercentCalc
    var mxGranteeShareZeroInclude = parseFloat($j("#mxGranteeShareZeroInclude").val()); // It is for maxAmountRequestAsGranteeShare
    var calcPercent = false;

    var percentValue = 0;

    var useSection3 = true;
    if(FundingStructureBudgetType == 'Fixed'){
        if($j("#useSectionIII").val() == 0){
            useSection3 = false;
        }
    }

    var corfa = $j('#corfa').val();
    var comfa = $j('#comfa').val();
    var icr = $j('#icr').val();
    var cfa = $j('#cfa').val();
    
    if(useSection3){
        if(fundingStructureName == 'NonIndirect'){
            if(corfa != compId && comfa != compId){
                var sec3Acfs = $j("#sec3Acfs").val();
                
                var calccorfa = 0;
                var calccomfa = 0;

                if(contributedFor == 'cncs'){
                    if(maxAmountAmericorpShare != 0){
                        //calccorfa = (((SectionITotal+SectionIITotal)*0.0526)*0.8).toFixed(2);
                        //calccomfa = (((SectionITotal+SectionIITotal)*0.0526)*0.2).toFixed(2);
                        if(programFixedPercentCalc != 0 || corfa_icrZeroInclude == 1){
                            calccorfa = (((SectionITotal+SectionIITotal)*maxAmountAmericorpShare)*programFixedPercentCalc).toFixed(2);
                        }else{
                            calccorfa = ((SectionITotal+SectionIITotal)*maxAmountAmericorpShare).toFixed(2);
                        }

                        if(commissionFixedPercentCalc != 0 || comfa_cfaZeroInclude == 1){
                            calccomfa = (((SectionITotal+SectionIITotal)*maxAmountAmericorpShare)*commissionFixedPercentCalc).toFixed(2);
                        }else{
                            calccomfa = ((SectionITotal+SectionIITotal)*maxAmountAmericorpShare).toFixed(2);
                        }
                    }else{
                        if(programFixedPercentCalc != 0 || corfa_icrZeroInclude == 1){
                            calccorfa = ((SectionITotal+SectionIITotal)*programFixedPercentCalc).toFixed(2);
                        }else{
                            calccorfa = (0).toFixed(2);
                        }

                        if(commissionFixedPercentCalc != 0 || comfa_cfaZeroInclude == 1){
                            calccomfa = ((SectionITotal+SectionIITotal)*commissionFixedPercentCalc).toFixed(2);
                        }else{
                            calccomfa = (0).toFixed(2);
                        }
                    }
                    
                    //to check if expenses are greater than budget value.
                    var expensesCorfa = removeCommaSep($j("#"+corfa+"_cncsexpense").val());
                    if(expensesCorfa != ''){
                        expensesCorfa = parseFloat(expensesCorfa);
                    }else{
                        expensesCorfa = 0;
                    }
                    if(calccorfa < expensesCorfa){
                        calccorfa = expensesCorfa;
                    }
                    var expensesComfa = removeCommaSep($j("#"+comfa+"_cncsexpense").val());
                    if(expensesComfa != ''){
                        expensesComfa = parseFloat(expensesComfa);
                    }else{
                        expensesComfa = 0;
                    }
                    if(calccomfa < expensesComfa){
                        calccomfa = expensesComfa;
                    }

                    var sectionIIIsubtotal = parseFloat(calccorfa) + parseFloat(calccomfa);
                    var corfaCncs = calccorfa;
                    var comfaCncs = calccomfa;
                    var corfaGrantee = removeCommaSep($j('#'+corfa+'_grantee').val());
                    if(corfaGrantee != ''){ 
                        corfaGrantee = parseFloat(corfaGrantee);
                    }else{
                        corfaGrantee = parseFloat(removeCommaSep($j('#'+corfa+'_granteeprev').val()));
                        if(compId != 0){
                            $j("#"+corfa+"_grantee").val(addCommaSep(corfaGrantee.toFixed(2)));
                        }
                        //$j("#"+corfa+"_grantee_default").val(corfaGrantee.toFixed(2));
                    }
                    var comfaGrantee = removeCommaSep($j('#'+comfa+'_grantee').val());
                    if(comfaGrantee != ''){ 
                        comfaGrantee = parseFloat(comfaGrantee);
                    }else{
                        comfaGrantee = parseFloat(removeCommaSep($j('#'+comfa+'_granteeprev').val()));
                        if(compId != 0){
                            $j("#"+comfa+"_grantee").val(addCommaSep(comfaGrantee.toFixed(2)));
                        }
                        //$j("#"+comfa+"_grantee_default").val(comfaGrantee.toFixed(2));
                    }
                    var corfaGranteeInkind = removeCommaSep($j('#'+corfa+'_granteeinkind').val());
                    if(corfaGranteeInkind != ''){ 
                        corfaGranteeInkind = parseFloat(corfaGranteeInkind);
                    }else{
                        corfaGranteeInkind = parseFloat(removeCommaSep($j('#'+corfa+'_granteeinkindprev').val()));
                        /*if(compId != 0){
                            $j("#"+corfa+"_granteeinkind").val(corfaGranteeInkind.toFixed(2));
                        }
                        $j("#"+corfa+"_granteeinkind_default").val(corfaGranteeInkind.toFixed(2));*/
                    }
                    var comfaGranteeInkind = removeCommaSep($j('#'+comfa+'_granteeinkind').val());
                    if(comfaGranteeInkind != ''){ 
                        comfaGranteeInkind = parseFloat(comfaGranteeInkind);
                    }else{
                        comfaGranteeInkind = parseFloat(removeCommaSep($j('#'+comfa+'_granteeinkindprev').val()));
                        /*$j("#"+comfa+"_granteeinkind").val(comfaGranteeInkind.toFixed(2));*/
                    }

                    // change in cncs also impacts gramtee so that is why if changes contributed by cncs grantee calculation should also occur.
                    var calcorfagrantee = 0;
                    var calcomfagrantee = 0;
                    if(noCalCulationForGranteeShare == 0){
                        //var cncsSubtotaSection3 = sectionIIIsubtotal;//parseFloat($j("#"+sec3Sub+"_cncs").val());
                        if(maxAmountRequestAsGranteeShare != 0 || mxGranteeShareZeroInclude == 1){
                            if(subtractCorfaWithSec3Acfs == 1){
                                var cncsSubtotaSection3 = sectionIIIsubtotal;//parseFloat($j("#"+sec3Sub+"_cncs").val());
                            }else{
                                var cncsSubtotaSection3 = 0;
                            }
                            //calccorfa = ((SectionITotal+SectionIITotal)*0.1).toFixed(2);
                            calcorfagrantee = (((SectionITotal_Total+SectionIITotal_Total)*maxAmountRequestAsGranteeShare)-cncsSubtotaSection3).toFixed(2);
                            corfaGrantee = calcorfagrantee
                        }else{
                            calcorfagrantee = (0).toFixed(2);
                        }

                        calcomfagrantee = removeCommaSep($j('#'+comfa+'_grantee').val());
                        if(calcomfagrantee != ''){
                            calcomfagrantee = parseFloat(calcomfagrantee);
                        }else{
                            calcomfagrantee = parseFloat(removeCommaSep($j('#'+comfa+'_granteeprev').val()));
                        }
                    }else{
                        calcomfagrantee = removeCommaSep($j('#'+comfa+'_grantee').val());
                        if(calcomfagrantee != ''){
                            calcomfagrantee = parseFloat(calcomfagrantee);
                        }else{
                            calcomfagrantee = parseFloat(removeCommaSep($j('#'+comfa+'_granteeprev').val()));
                        }
                    }
                    
                    //to check if expenses are greater than budget value.
                    var expensesCorfa = removeCommaSep($j("#"+corfa+"_granteeexpense").val());
                    if(expensesCorfa != ''){
                        expensesCorfa = parseFloat(expensesCorfa);
                    }else{
                        expensesCorfa = 0;
                    }
                    if(calcorfagrantee < expensesCorfa){
                        calcorfagrantee = expensesCorfa;
                        corfaGrantee = expensesCorfa;
                    }

                    $j('#'+corfa+'_grantee_default').val(addCommaSep(calcorfagrantee));
                    if(compId != 0){
                        $j('#'+corfa+'_grantee').val(addCommaSep(calcorfagrantee));
                        var sectionIIIsubtotalGrantee = parseFloat(calcorfagrantee) + parseFloat(calcomfagrantee);
                        $j('#'+sec3Acfs+'_grantee').val(addCommaSep(sectionIIIsubtotalGrantee.toFixed(2)));
                        $j('#'+sec3Sub+'_grantee').val(addCommaSep(sectionIIIsubtotalGrantee.toFixed(2)));
                    }

                }else if(contributedFor == 'grantee'){
                    if(noCalCulationForGranteeShare == 0){
                        if(maxAmountRequestAsGranteeShare != 0 || mxGranteeShareZeroInclude == 1){
                            //calccorfa = ((SectionITotal+SectionIITotal)*0.1).toFixed(2);
                            if(subtractCorfaWithSec3Acfs == 1){
                                var cncsSubtotaSection3 = removeCommaSep($j("#"+sec3Sub+"_cncs").val());
                                if(cncsSubtotaSection3 != ''){
                                    cncsSubtotaSection3 = parseFloat(cncsSubtotaSection3);
                                }else{
                                    cncsSubtotaSection3 = parseFloat(removeCommaSep($j("#"+sec3Sub+"_cncsprev").val()));
                                }
                            }else{
                                var cncsSubtotaSection3 = 0;
                            }
                            calccorfa = (((SectionITotal_Total+SectionIITotal_Total)*maxAmountRequestAsGranteeShare)-cncsSubtotaSection3).toFixed(2);
                        }else{
                            calccorfa = (0).toFixed(2);
                        }
                    }else{
                        calccorfa = parseFloat(removeCommaSep($j('#'+corfa+'_'+contributedFor).val()));
                    }

                    //to check if expenses are greater than budget value.
                    var expensesCorfa = removeCommaSep($j("#"+corfa+"_granteeexpense").val());
                    if(expensesCorfa != ''){
                        expensesCorfa = parseFloat(expensesCorfa);
                    }else{
                        expensesCorfa = 0;
                    }
                    if(calccorfa < expensesCorfa){
                        calccorfa = expensesCorfa;
                    }
                    
                    calccomfa = removeCommaSep($j('#'+comfa+'_'+contributedFor).val());
                    if(calccomfa != ''){
                        calccomfa = parseFloat(calccomfa);
                    }else{
                        calccomfa = parseFloat(removeCommaSep($j('#'+comfa+'_'+contributedFor+'prev').val()));
                        if(compId != 0){
                            $j('#'+comfa+'_'+contributedFor).val(addCommaSep(calccomfa));
                        }
                        //$j('#'+comfa+'_'+contributedFor+'_default').val(calccomfa);
                    }

                    var sectionIIIsubtotal = parseFloat(calccorfa) + parseFloat(calccomfa);
                    var corfaCncs = removeCommaSep($j('#'+corfa+'_cncs').val());
                    if(corfaCncs != ''){ 
                        corfaCncs = parseFloat(corfaCncs);
                    }else{
                        corfaCncs = parseFloat(removeCommaSep($j('#'+corfa+'_cncsprev').val()));
                        if(compId != 0){
                            $j("#"+corfa+"_cncs").val(addCommaSep(corfaCncs.toFixed(2)));
                        }
                        $j('#'+corfa+'_cncs_default').val(addCommaSep(corfaCncs));
                    }
                    
                    var comfaCncs = removeCommaSep($j('#'+comfa+'_cncs').val());
                    if(comfaCncs != ''){ 
                        comfaCncs = parseFloat(comfaCncs);
                    }else{
                        comfaCncs = parseFloat(removeCommaSep($j('#'+comfa+'_cncsprev').val()));
                        if(compId != 0){
                            $j("#"+comfa+"_cncs").val(addCommaSep(comfaCncs.toFixed(2)));
                        }
                        $j('#'+comfa+'_cncs_default').val(addCommaSep(comfaCncs));
                    }
                    
                    var corfaGrantee = calccorfa;
                    var comfaGrantee = calccomfa;
                    var corfaGranteeInkind = removeCommaSep($j('#'+corfa+'_granteeinkind').val());
                    if(corfaGranteeInkind != ''){ 
                        corfaGranteeInkind = parseFloat(corfaGranteeInkind);
                    }else{
                        corfaGranteeInkind = parseFloat(removeCommaSep($j('#'+corfa+'_granteeinkindprev').val()));
                        /*if(compId != 0){
                            $j("#"+corfa+"_granteeinkind").val(corfaGranteeInkind.toFixed(2));
                        }*/
                    }
                    var comfaGranteeInkind = removeCommaSep($j('#'+comfa+'_granteeinkind').val());
                    if(comfaGranteeInkind != ''){ 
                        comfaGranteeInkind = parseFloat(comfaGranteeInkind);
                    }else{
                        comfaGranteeInkind = parseFloat(removeCommaSep($j('#'+comfa+'_granteeinkindprev').val()));
                        //$j("#"+comfa+"_granteeinkind").val(comfaGranteeInkind.toFixed(2));
                    }
                }else if(contributedFor == 'granteeinkind'){
                    var calccorfa = 0;
                    var calccomfa = 0;
                    var corfaCncs = removeCommaSep($j('#'+corfa+'_cncs').val());
                    if(corfaCncs != ''){ 
                        corfaCncs = parseFloat(corfaCncs);
                    }else{
                        corfaCncs = parseFloat(removeCommaSep($j('#'+corfa+'_cncsprev').val()));
                        if(compId != 0){
                            $j("#"+corfa+"_cncs").val(addCommaSep(corfaCncs.toFixed(2)));
                        }
                        $j('#'+corfa+'_cncs_default').val(addCommaSep(corfaCncs));
                    }
                    
                    var comfaCncs = removeCommaSep($j('#'+comfa+'_cncs').val());
                    if(comfaCncs != ''){ 
                        comfaCncs = parseFloat(comfaCncs);
                    }else{
                        comfaCncs = parseFloat(removeCommaSep($j('#'+comfa+'_cncsprev').val()));
                        if(compId != 0){
                            $j("#"+comfa+"_cncs").val(addCommaSep(comfaCncs.toFixed(2)));
                        }
                        $j('#'+comfa+'_cncs_default').val(addCommaSep(comfaCncs));
                    }
                    var corfaGrantee = removeCommaSep($j('#'+corfa+'_grantee').val());
                    if(corfaGrantee != ''){ 
                        corfaGrantee = parseFloat(corfaGrantee);
                    }else{
                        corfaGrantee = parseFloat(removeCommaSep($j('#'+corfa+'_granteeprev').val()));
                        if(compId != 0){
                            $j("#"+corfa+"_grantee").val(addCommaSep(corfaGrantee.toFixed(2)));
                        }
                    }
                    var comfaGrantee = removeCommaSep($j('#'+comfa+'_grantee').val());
                    if(comfaGrantee != ''){ 
                        comfaGrantee = parseFloat(comfaGrantee);
                    }else{
                        comfaGrantee = parseFloat(removeCommaSep($j('#'+comfa+'_granteeprev').val()));
                        if(compId != 0){
                            $j("#"+comfa+"_grantee").val(addCommaSep(comfaGrantee.toFixed(2)));
                        }
                    }
                    var corfaGranteeInkind = 0;
                    var comfaGranteeInkind = 0;

                    // change in cncs also impacts gramtee so that is why if changes contributed by cncs grantee calculation should also occur.
                    var calcorfagrantee = 0;
                    var calcomfagrantee = 0;
                    if(noCalCulationForGranteeShare == 0){
                        //var cncsSubtotaSection3 = sectionIIIsubtotal;//parseFloat($j("#"+sec3Sub+"_cncs").val());
                        if(maxAmountRequestAsGranteeShare != 0 || mxGranteeShareZeroInclude == 1){
                            if(subtractCorfaWithSec3Acfs == 1){
                                var cncsSubtotaSection3 = removeCommaSep($j("#"+sec3Sub+"_cncs").val());
                                if(cncsSubtotaSection3 != ''){
                                    cncsSubtotaSection3 = parseFloat(cncsSubtotaSection3);
                                }else{
                                    cncsSubtotaSection3 = parseFloat(removeCommaSep($j("#"+sec3Sub+"_cncsprev").val()));
                                }
                            }else{
                                var cncsSubtotaSection3 = 0;
                            }
                            //calccorfa = ((SectionITotal+SectionIITotal)*0.1).toFixed(2);
                            calcorfagrantee = (((SectionITotal_Total+SectionIITotal_Total)*maxAmountRequestAsGranteeShare)-cncsSubtotaSection3).toFixed(2);
                            corfaGrantee = calcorfagrantee
                        }else{
                            calcorfagrantee = (0).toFixed(2);
                        }

                        calcomfagrantee = removeCommaSep($j('#'+comfa+'_grantee').val());
                        if(calcomfagrantee != ''){
                            calcomfagrantee = parseFloat(calcomfagrantee);
                        }else{
                            calcomfagrantee = parseFloat(removeCommaSep($j('#'+comfa+'_granteeprev').val()));
                        }
                    }else{
                        calcomfagrantee = removeCommaSep($j('#'+comfa+'_grantee').val());
                        if(calcomfagrantee != ''){
                            calcomfagrantee = parseFloat(calcomfagrantee);
                        }else{
                            calcomfagrantee = parseFloat(removeCommaSep($j('#'+comfa+'_granteeprev').val()));
                        }
                    }
                    
                    //to check if expenses are greater than budget value.
                    var expensesCorfa = removeCommaSep($j("#"+corfa+"_granteeexpense").val());
                    if(expensesCorfa != ''){
                        expensesCorfa = parseFloat(expensesCorfa);
                    }else{
                        expensesCorfa = 0;
                    }
                    if(calcorfagrantee < expensesCorfa){
                        calcorfagrantee = expensesCorfa;
                        corfaGrantee = expensesCorfa;
                    }

                    $j('#'+corfa+'_grantee_default').val(addCommaSep(calcorfagrantee));
                    if(compId != 0){
                        $j('#'+corfa+'_grantee').val(addCommaSep(calcorfagrantee));
                        var sectionIIIsubtotalGrantee = parseFloat(calcorfagrantee) + parseFloat(calcomfagrantee);
                        $j('#'+sec3Acfs+'_grantee').val(addCommaSep(sectionIIIsubtotalGrantee.toFixed(2)));
                        $j('#'+sec3Sub+'_grantee').val(addCommaSep(sectionIIIsubtotalGrantee.toFixed(2)));
                    }

                    var sectionIIIsubtotal = parseFloat(calccorfa) + parseFloat(calccomfa);
                }
                
                $j('#'+corfa+'_'+contributedFor+'_default').val(addCommaSep(calccorfa));
                if(compId != 0){
                    $j('#'+corfa+'_'+contributedFor).val(addCommaSep(calccorfa));          
                    var totalcorfa = parseFloat(corfaGrantee)+parseFloat(corfaCncs)+parseFloat(corfaGranteeInkind);               
                    $j('#'+corfa+'_total').val(addCommaSep(totalcorfa.toFixed(2)));            
                    var totalprevcorfa = parseFloat(removeCommaSep($j("#"+corfa+"_totalprev").val()));
                    var totalNewValuecorfa = removeCommaSep($j("#"+corfa+"_totalnew").val());
                    if(totalNewValuecorfa != ''){
                        totalNewValuecorfa = parseFloat(totalNewValuecorfa);
                    }
                    var calccorfaprevavlue = parseFloat(removeCommaSep($j('#'+corfa+'_'+contributedFor+'prev').val()));
                    var totalChangePercent = $j("#totalChangePercent").val();
                    var totalLineChange = parseInt($j("#totalLineChange").val());
                    if(contributedFor == 'granteeinkind'){
                        var calcorfagranteeprevValue = parseFloat(removeCommaSep($j('#'+corfa+'_granteeprev').val()));
                        calculateChangePercent(corfa, totalChangePercent, totalcorfa, totalprevcorfa, totalNewValuecorfa, totalLineChange, 'grantee', calcorfagrantee, calcorfagranteeprevValue)
                    }else{
                        calculateChangePercent(corfa, totalChangePercent, totalcorfa, totalprevcorfa, totalNewValuecorfa, totalLineChange, contributedFor, calccorfa, calccorfaprevavlue)
                    }   
                }
                
                $j('#'+comfa+'_'+contributedFor+'_default').val(addCommaSep(calccomfa));
                if(compId != 0){
                    $j('#'+comfa+'_'+contributedFor).val(addCommaSep(calccomfa));
                    var totalcomfa = parseFloat(comfaGrantee)+parseFloat(comfaCncs)+parseFloat(comfaGranteeInkind);
                    $j('#'+comfa+'_total').val(addCommaSep(totalcomfa.toFixed(2)));
                    var totalprevcomfa = parseFloat(removeCommaSep($j("#"+comfa+"_totalprev").val()));
                    var totalNewValuecomfa = removeCommaSep($j("#"+comfa+"_totalnew").val());
                    if(totalNewValuecomfa != ''){
                        totalNewValuecomfa = parseFloat(totalNewValuecomfa);
                    }
                    var calccomfaprevavlue = parseFloat(removeCommaSep($j('#'+comfa+'_'+contributedFor+'prev').val()));
                    var totalChangePercent = $j("#totalChangePercent").val();
                    var totalLineChange = parseInt($j("#totalLineChange").val());
                    if(contributedFor == 'granteeinkind'){
                        var calcomfagranteeprevValue = parseFloat(removeCommaSep($j('#'+comfa+'_granteeprev').val()));
                        calculateChangePercent(comfa, totalChangePercent, totalcomfa, totalprevcomfa, totalNewValuecomfa, totalLineChange, 'grantee', calcomfagrantee, calcomfagranteeprevValue)
                    }else{
                        calculateChangePercent(comfa, totalChangePercent, totalcomfa, totalprevcomfa, totalNewValuecomfa, totalLineChange, contributedFor, calccomfa, calccomfaprevavlue)
                    }
                }

                if(compId != 0){
                    $j('#'+sec3Acfs+'_'+contributedFor).val(addCommaSep(sectionIIIsubtotal.toFixed(2)));
                    $j('#'+sec3Sub+'_'+contributedFor).val(addCommaSep(sectionIIIsubtotal.toFixed(2)));
                }

                var totalsec3Acfs = 0;
                var sec3SubTotal = 0;
                if($j('#'+sec3Acfs+'_grantee').val() != ''){
                    var sec3AcfsGrantee = parseFloat(removeCommaSep($j('#'+sec3Acfs+'_grantee').val()));
                }else{       
                    var sec3AcfsGrantee = parseFloat(removeCommaSep($j('#'+sec3Acfs+'_granteeprev').val()));
                    if(compId != 0){
                        $j('#'+sec3Acfs+'_grantee').val(addCommaSep(sec3AcfsGrantee.toFixed(2)));
                    }
                }
                if($j('#'+sec3Acfs+'_cncs').val() != ''){
                    var sec3AcfsCncs = parseFloat(removeCommaSep($j('#'+sec3Acfs+'_cncs').val()));
                }else{       
                    var sec3AcfsCncs = parseFloat(removeCommaSep($j('#'+sec3Acfs+'_cncsprev').val()));
                    if(compId != 0){
                        $j('#'+sec3Acfs+'_cncs').val(addCommaSep(sec3AcfsCncs.toFixed(2)));
                    }
                }
                var sec3AcfsGranteeinkind = 0;
                if($j('#'+sec3Acfs+'_granteeinkind').val() != undefined){
                    if($j('#'+sec3Acfs+'_granteeinkind').val() != ''){
                        sec3AcfsGranteeinkind = parseFloat(removeCommaSep($j('#'+sec3Acfs+'_granteeinkind').val()));
                    }else{       
                        sec3AcfsGranteeinkind = parseFloat(removeCommaSep($j('#'+sec3Acfs+'_granteeinkindprev').val()));
                        
                        //$j('#'+sec3Acfs+'_granteeinkind').val(sec3AcfsGranteeinkind.toFixed(2));
                    }
                }

                var sec3SubGranteePrev = removeCommaSep($j('#'+sec3Sub+'_granteeprev').val());
                if($j('#'+sec3Sub+'_grantee').val() != ''){
                    var sec3SubGrantee = parseFloat(removeCommaSep($j('#'+sec3Sub+'_grantee').val()));
                }else{       
                    var sec3SubGrantee = parseFloat(removeCommaSep($j('#'+sec3Sub+'_granteeprev').val()));
                    $j('#'+sec3Sub+'_grantee').val(addCommaSep(sec3SubGrantee.toFixed(2)));
                }
                var sec3SubCncsPrev = removeCommaSep($j('#'+sec3Sub+'_cncsprev').val());
                if($j('#'+sec3Sub+'_cncs').val() != ''){
                    var sec3SubCncs = parseFloat(removeCommaSep($j('#'+sec3Sub+'_cncs').val()));
                }else{       
                    var sec3SubCncs = parseFloat(removeCommaSep($j('#'+sec3Sub+'_cncsprev').val()));
                    $j('#'+sec3Sub+'_cncs').val(addCommaSep(sec3SubCncs.toFixed(2)));
                }
                var sec3SubGranteeinkindPrev = removeCommaSep($j('#'+sec3Sub+'_granteeinkindprev').val());
                if($j('#'+sec3Sub+'_granteeinkind').val() != ''){
                    var sec3SubGranteeinkind = parseFloat(removeCommaSep($j('#'+sec3Sub+'_granteeinkind').val()));
                }else{       
                    var sec3SubGranteeinkind = parseFloat(removeCommaSep($j('#'+sec3Sub+'_granteeinkindprev').val()));
                    $j('#'+sec3Sub+'_granteeinkind').val(addCommaSep(sec3SubGranteeinkind.toFixed(2)));
                }

                if(contributedFor == 'cncs'){
                    totalsec3Acfs = sec3AcfsGrantee+parseFloat(sectionIIIsubtotal)+sec3AcfsGranteeinkind;
                    sec3SubTotal = parseFloat(sectionIIIsubtotal+sec3SubGrantee+sec3SubGranteeinkind);
                    $j("#"+sec3Sub+'_grantee').val(addCommaSep(sec3SubGrantee.toFixed(2)));
                    $j("#"+sec3Sub+'_granteeinkind').val(addCommaSep(sec3SubGranteeinkind.toFixed(2)));
                }else if(contributedFor == 'grantee'){
                    totalsec3Acfs = sec3AcfsCncs+parseFloat(sectionIIIsubtotal)+sec3AcfsGranteeinkind;
                    sec3SubTotal = parseFloat(sectionIIIsubtotal+sec3SubCncs+sec3SubGranteeinkind);
                    $j("#"+sec3Sub+'_cncs').val(addCommaSep(sec3SubCncs.toFixed(2)));
                    $j("#"+sec3Sub+'_granteeinkind').val(addCommaSep(sec3SubGranteeinkind.toFixed(2)));
                }else if(contributedFor == 'granteeinkind'){
                    totalsec3Acfs = sec3AcfsGrantee+parseFloat(sectionIIIsubtotal)+sec3AcfsCncs;
                    sec3SubTotal = parseFloat(sectionIIIsubtotal+sec3SubGrantee+sec3SubCncs);
                    $j("#"+sec3Sub+'_cncs').val(addCommaSep(sec3SubCncs.toFixed(2)));
                    $j("#"+sec3Sub+'_grantee').val(addCommaSep(sec3SubGrantee.toFixed(2)));
                }
                
                if(compId != 0){
                    $j('#'+sec3Acfs+'_total').val(addCommaSep(totalsec3Acfs.toFixed(2)));
                    $j('#'+sec3Sub+'_total').val(addCommaSep(sec3SubTotal.toFixed(2)));
                
                
                var cncsChangeValue = 0;
                var granteeChangeValue = 0;
                var granteeinkindChangeValue = 0;
                var totalChangeValue = 0;

                sec3SubCncsPrev = parseFloat(sec3SubCncsPrev);
                if(sec3SubCncs > 0){
                    cncsChangeValue =  sec3SubCncs - sec3SubCncsPrev;
                }
                if(sec3SubCncsPrev > 0){
                    var cncsChangePercent = (cncsChangeValue/sec3SubCncsPrev)*100;
                }else{
                    var cncsChangePercent = cncsChangeValue;
                }
                if(cncsChangeValue > 0){
                    $j("#changevaluesummarycncs_"+sec3Sub).html('+$'+addCommaSep(cncsChangeValue.toFixed(2)));
                    if(cncsChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarycncs_"+sec3Sub).html('('+cncsChangePercent.toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarycncs_"+sec3Sub).html('(+'+cncsChangePercent.toFixed(2)+'%)');
                    }          
                }else if(cncsChangeValue == 0){
                    $j("#changevaluesummarycncs_"+sec3Sub).html('');
                    $j("#changepercentsummarycncs_"+sec3Sub).html('');
                }else{
                    $j("#changevaluesummarycncs_"+sec3Sub).html('-$'+addCommaSep(Math.abs(cncsChangeValue).toFixed(2)));
                    if(cncsChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarycncs_"+sec3Sub).html('('+Math.abs(cncsChangePercent).toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarycncs_"+sec3Sub).html('(-'+Math.abs(cncsChangePercent).toFixed(2)+'%)');
                    }  
                }
                sec3SubGranteePrev = parseFloat(sec3SubGranteePrev);
                if(sec3SubGrantee > 0){
                    granteeChangeValue = sec3SubGrantee - sec3SubGranteePrev;
                }
                if(sec3SubGranteePrev > 0){
                    var granteeChangePercent = (granteeChangeValue/sec3SubGranteePrev)*100;
                }else{
                    var granteeChangePercent = granteeChangeValue;
                }
                if(granteeChangeValue > 0){
                    $j("#changevaluesummarygrantee_"+sec3Sub).html('+$'+addCommaSep(granteeChangeValue.toFixed(2)));
                    if(granteeChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarygrantee_"+sec3Sub).html('('+granteeChangePercent.toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarygrantee_"+sec3Sub).html('(+'+granteeChangePercent.toFixed(2)+'%)');
                    }  
                }else if(granteeChangeValue == 0){
                    $j("#changevaluesummarygrantee_"+sec3Sub).html('');
                    $j("#changepercentsummarygrantee_"+sec3Sub).html('');
                }else{
                    $j("#changevaluesummarygrantee_"+sec3Sub).html('-$'+addCommaSep(Math.abs(granteeChangeValue).toFixed(2)));
                    if(granteeChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarygrantee_"+sec3Sub).html('('+Math.abs(granteeChangePercent).toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarygrantee_"+sec3Sub).html('(-'+Math.abs(granteeChangePercent).toFixed(2)+'%)');
                    }  
                }
                sec3SubGranteeinkindPrev = parseFloat(sec3SubGranteeinkindPrev);
                if(sec3SubGranteeinkind > 0){
                    granteeinkindChangeValue =  sec3SubGranteeinkind - sec3SubGranteeinkindPrev;
                }
                if(sec3SubGranteeinkindPrev > 0){
                    var granteeinkindChangePercent = (granteeinkindChangeValue/sec3SubGranteeinkindPrev)*100;
                }else{
                    var granteeinkindChangePercent = granteeinkindChangeValue;
                }
                if(granteeinkindChangeValue > 0){
                    $j("#changevaluesummarygranteeinkind_"+sec3Sub).html('+$'+addCommaSep(granteeinkindChangeValue.toFixed(2)));
                    if(granteeinkindChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarygranteeinkind_"+sec3Sub).html('('+granteeinkindChangePercent.toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarygranteeinkind_"+sec3Sub).html('(+'+granteeinkindChangePercent.toFixed(2)+'%)');
                    } 
                }else if(granteeinkindChangeValue == 0){
                    $j("#changevaluesummarygranteeinkind_"+sec3Sub).html('');
                    $j("#changepercentsummarygranteeinkind_"+sec3Sub).html('');
                }else{
                    $j("#changevaluesummarygranteeinkind_"+sec3Sub).html('-$'+addCommaSep(Math.abs(granteeinkindChangeValue).toFixed(2)));
                    if(granteeinkindChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarygranteeinkind_"+sec3Sub).html('('+Math.abs(granteeinkindChangePercent).toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarygranteeinkind_"+sec3Sub).html('(-'+Math.abs(granteeinkindChangePercent).toFixed(2)+'%)');
                    }
                }

                sec3totalprev_value = parseFloat(removeCommaSep($j('#'+sec3Sub+'_totalprev').val()));
                if(sec3SubTotal > 0){
                    totalChangeValue =  sec3SubTotal - sec3totalprev_value;
                }
                if(sec3totalprev_value > 0){
                    var totalChangePercent = (totalChangeValue/sec3totalprev_value)*100;
                }else{
                    var totalChangePercent = totalChangeValue;
                }
                if(totalChangeValue > 0){
                    $j("#changevaluesummarytotal_"+sec3Sub).html('+$'+addCommaSep(totalChangeValue.toFixed(2)));
                    if(totalChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarytotal_"+sec3Sub).html('('+totalChangePercent.toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarytotal_"+sec3Sub).html('(+'+totalChangePercent.toFixed(2)+'%)');
                    }
                }else if(totalChangeValue == 0){
                    $j("#changevaluesummarytotal_"+sec3Sub).html('');
                    $j("#changepercentsummarytotal_"+sec3Sub).html('');
                }else{
                    $j("#changevaluesummarytotal_"+sec3Sub).html('-$'+addCommaSep(Math.abs(totalChangeValue).toFixed(2)));
                    if(totalChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarytotal_"+sec3Sub).html('('+Math.abs(totalChangePercent).toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarytotal_"+sec3Sub).html('(-'+Math.abs(totalChangePercent).toFixed(2)+'%)');
                    }
                }

                if(sec3SubTotal > 0){
                    percentValue = (sectionIIIsubtotal/sec3SubTotal)*100;
                }else{
                    percentValue= 0;
                }
                var displayCompCount = $j('#'+sec3Sub+'_cncs').attr("data-displaycount");
                
                if(sec3SubTotal.toFixed(2) == removeCommaSep($j('#'+sec3Sub+'_totalprev').val())){
                    //$j('#'+sec3Sub+'_total').val('');
                    //$j(".trsimple_total_"+sec3Sub).hide();
                    $j(".trsimple_total_"+sec3Sub+" input").css("color","black");
                    $j("#trsimple-total"+displayCompCount+"_input").val(0);
                    $j("#"+sec3Sub+"_changespan").show();
                    $j(".changevaluesummary_"+sec3Sub).html('-');
                }else{
                    //$j('#'+sec3Sub+'_total').val(totalofSubTotal.toFixed(2));
                    /*if($j("#"+sec3Sub+"_cncs").attr('data-section') == 'section3'){
                        //if(!$j(".hideshowwrapper_dsiplayCount_3 .dataGroupHeader .showHide").hasClass('showIt')){
                            $j(".trsimple_total_"+sec3Sub).show();
                        //}
                    }else{
                        $j(".trsimple_total_"+sec3Sub).show();
                    } */  
                    $j(".trsimple_total_"+sec3Sub).show();
                    $j(".trsimple_total_"+sec3Sub+" input").css("color","#C70404");
                    $j("#trsimple-total"+displayCompCount+"_input").val(1);
                    $j("#"+sec3Sub+"_changespan").show();
                }

                calcPercent = true;
            }
            }

        }else if(fundingStructureName == 'Indirect'){
            var sec3faic = $j('#sec3faic').val();
            var calcicr = 0;
            var calccfa = 0;

            if(icr != compId && cfa != compId){
                if(contributedFor == 'cncs'){
                    if(maxAmountAmericorpShare != 0){
                        //calccorfa = (((SectionITotal+SectionIITotal)*0.0526)*0.8).toFixed(2);
                        //calccomfa = (((SectionITotal+SectionIITotal)*0.0526)*0.2).toFixed(2);
                        if(indirectCostRatePercentCalc != 0 || corfa_icrZeroInclude == 1){
                            calcicr = (((SectionITotal+SectionIITotal)*maxAmountAmericorpShare)*indirectCostRatePercentCalc).toFixed(2);
                        }else{
                            calcicr = ((SectionITotal+SectionIITotal)*maxAmountAmericorpShare).toFixed(2);
                        }

                        if(commissionFixedPercentCalc != 0 || comfa_cfaZeroInclude == 1){
                            calccfa = (((SectionITotal+SectionIITotal)*maxAmountAmericorpShare)*commissionFixedPercentCalc).toFixed(2);
                        }else{
                            calccfa = ((SectionITotal+SectionIITotal)*maxAmountAmericorpShare).toFixed(2);
                        }
                    }else{
                        if(indirectCostRatePercentCalc != 0 || corfa_icrZeroInclude == 1){
                            calcicr = ((SectionITotal+SectionIITotal)*indirectCostRatePercentCalc).toFixed(2);
                        }else{
                            calcicr = (SectionITotal+SectionIITotal).toFixed(2);
                        }

                        if(commissionFixedPercentCalc != 0 || comfa_cfaZeroInclude == 1){
                            calccfa = ((SectionITotal+SectionIITotal)*commissionFixedPercentCalc).toFixed(2);
                        }else{
                            calccfa = (SectionITotal+SectionIITotal).toFixed(2);
                        }
                    }

                    //to check if expenses are greater than budget value.
                    var expensesIcr = removeCommaSep($j("#"+icr+"_cncsexpense").val());
                    if(expensesIcr != ''){
                        expensesIcr = parseFloat(expensesIcr);
                    }else{
                        expensesIcr = 0;
                    }
                    if(calcicr < expensesIcr){
                        calcicr = expensesIcr;
                    }
                    var expensesCfa = removeCommaSep($j("#"+cfa+"_cncsexpense").val());
                    if(expensesCfa != ''){
                        expensesCfa = parseFloat(expensesCfa);
                    }else{
                        expensesCfa = 0;
                    }
                    if(calccfa < expensesCfa){
                        calccfa = expensesCfa;
                    }

                    var sectionIIIsubtotal = parseFloat(calcicr) + parseFloat(calccfa);

                    var icrcncs = calcicr;
                    var cfacncs = calccfa;
                    var icrGrantee = removeCommaSep($j('#'+icr+'_grantee').val());
                    if(icrGrantee != ''){ 
                        icrGrantee = parseFloat(icrGrantee);
                    }else{
                        icrGrantee = parseFloat(removeCommaSep($j('#'+icr+'_granteeprev').val()));
                        if(compId != 0){
                            $j("#"+icr+"_grantee").val(addCommaSep(icrGrantee.toFixed(2)));
                        }
                    }
                    var cfaGrantee = removeCommaSep($j('#'+cfa+'_grantee').val());
                    if(cfaGrantee != ''){ 
                        cfaGrantee = parseFloat(cfaGrantee);
                    }else{
                        cfaGrantee = parseFloat(removeCommaSep($j('#'+cfa+'_granteeprev').val()));
                        if(compId != 0){
                            $j("#"+cfa+"_grantee").val(addCommaSep(cfaGrantee.toFixed(2)));
                        }
                    }
                    var icrGranteeInkind = removeCommaSep($j('#'+icr+'_granteeinkind').val());
                    if(icrGranteeInkind != ''){ 
                        icrGranteeInkind = parseFloat(icrGranteeInkind);
                    }else{
                        icrGranteeInkind = parseFloat(removeCommaSep($j('#'+icr+'_granteeinkindprev').val()));
                        if(compId != 0){
                            $j("#"+icr+"_granteeinkind").val(addCommaSep(icrGranteeInkind.toFixed(2)));
                        }
                    }
                    var cfaGranteeInkind = removeCommaSep($j('#'+cfa+'_granteeinkind').val());
                    if(cfaGranteeInkind != ''){ 
                        cfaGranteeInkind = parseFloat(cfaGranteeInkind);
                    }else{
                        cfaGranteeInkind = parseFloat(removeCommaSep($j('#'+cfa+'_granteeinkindprev').val()));
                        if(compId != 0){
                            $j("#"+cfa+"_granteeinkind").val(addCommaSep(cfaGranteeInkind.toFixed(2)));
                        }
                    }

                    // change in cncs also impacts gramtee so that is why if changes contributed by cncs grantee calculation should also occur.
                    var calcicrgrantee = 0;
                    var calccfagrantee = 0;
                    if(noCalCulationForGranteeShare == 0){
                        var cncsSubtotaSection3 = sectionIIIsubtotal;//parseFloat($j("#"+sec3Sub+"_cncs").val());
                        if(maxAmountRequestAsGranteeShare != 0 || mxGranteeShareZeroInclude == 1){
                            //calccorfa = ((SectionITotal+SectionIITotal)*0.1).toFixed(2);
                            calcicrgrantee = (((SectionITotal_Total+SectionIITotal_Total)*maxAmountRequestAsGranteeShare)-cncsSubtotaSection3).toFixed(2);
                            icrGrantee = calcicrgrantee
                        }else{
                            calcicrgrantee = (0).toFixed(2);
                        }

                        calccfagrantee = removeCommaSep($j('#'+cfa+'_grantee').val());
                        if(calccfagrantee != ''){
                            calccfagrantee = parseFloat(calccfagrantee);
                        }else{
                            calccfagrantee = parseFloat(removeCommaSep($j('#'+cfa+'_granteeprev').val()));
                        }
                    }else{
                        calccfagrantee = removeCommaSep($j('#'+cfa+'_grantee').val());
                        if(calccfagrantee != ''){
                            calccfagrantee = parseFloat(calccfagrantee);
                        }else{
                            calccfagrantee = parseFloat(removeCommaSep($j('#'+cfa+'_granteeprev').val()));
                        }
                    }

                    //to check if expenses are greater than budget value.
                    var expensesIcr = removeCommaSep($j("#"+icr+"_granteeexpense").val());
                    if(expensesIcr != ''){
                        expensesIcr = parseFloat(expensesIcr);
                    }else{
                        expensesIcr = 0;
                    }
                    if(calcicrgrantee < expensesIcr){
                        calcicrgrantee = expensesIcr;
                        icrGrantee = expensesIcr;
                    }

                    $j('#'+icr+'_grantee_default').val(addCommaSep(calcicrgrantee));
                    if(compId != 0){
                        $j('#'+icr+'_grantee').val(addCommaSep(calcicrgrantee));
                        var sectionIIIsubtotalGrantee = parseFloat(calcicrgrantee) + parseFloat(calccfagrantee);
                        $j('#'+sec3faic+'_grantee').val(addCommaSep(sectionIIIsubtotalGrantee.toFixed(2)));
                        $j('#'+sec3Sub+'_grantee').val(addCommaSep(sectionIIIsubtotalGrantee.toFixed(2)));
                    }
                }else if(contributedFor == 'grantee'){
                    if(noCalCulationForGranteeShare == 0){
                        var cncsSubtotaSection3 = removeCommaSep($j("#"+sec3Sub+"_cncs").val());
                        if(cncsSubtotaSection3 != ''){
                            cncsSubtotaSection3 = parseFloat(cncsSubtotaSection3);
                        }else{
                            cncsSubtotaSection3 = parseFloat(removeCommaSep($j("#"+sec3Sub+"_cncsprev").val()))
                        }
                        if(maxAmountRequestAsGranteeShare != 0 || mxGranteeShareZeroInclude == 1){
                            //calccorfa = ((SectionITotal+SectionIITotal)*0.1).toFixed(2);
                            calcicr = (((SectionITotal_Total+SectionIITotal_Total)*maxAmountRequestAsGranteeShare)-cncsSubtotaSection3).toFixed(2);
                        }else{
                            calcicr = (SectionITotal_Total+SectionIITotal_Total).toFixed(2);
                        }
                    }else{
                        calcicr = removeCommaSep($j('#'+icr+'_'+contributedFor).val());
                        if(calcicr != ''){
                            calcicr = parseFloat(calcicr);
                        }else{
                            calcicr = parseFloat(removeCommaSep($j('#'+icr+'_'+contributedFor+'prev').val()));
                            if(compId != 0){
                                $j('#'+icr+'_'+contributedFor).val(addCommaSep(calcicr.toFixed(2)));
                            }
                        }
                    }

                    //to check if expenses are greater than budget value.
                    var expensesIcr = removeCommaSep($j("#"+icr+"_granteeexpense").val());
                    if(expensesIcr != ''){
                        expensesIcr = parseFloat(expensesIcr);
                    }else{
                        expensesIcr = 0;
                    }
                    if(calcicr < expensesIcr){
                        calcicr = expensesIcr;
                    }

                    calccfa = removeCommaSep($j('#'+cfa+'_'+contributedFor).val());
                    if(calccfa != ''){
                        calccfa = parseFloat(calccfa);
                    }else{
                        calccfa = parseFloat(removeCommaSep($j('#'+cfa+'_'+contributedFor+'prev').val()));
                        if(compId != 0){
                            $j("#"+cfa+"_"+contributedFor).val(addCommaSep(calccfa.toFixed(2)));
                        }
                    }

                    var sectionIIIsubtotal = parseFloat(calcicr) + parseFloat(calccfa);

                    var icrcncs = removeCommaSep($j('#'+icr+'_cncs').val());
                    if(icrcncs != ''){ 
                        icrcncs = parseFloat(icrcncs);
                    }else{
                        icrcncs = parseFloat(removeCommaSep($j('#'+icr+'_cncsprev').val()));
                        if(compId != 0){
                            $j('#'+icr+'_cncs').val(addCommaSep(icrcncs));
                        }
                        $j('#'+icr+'_cncs_default').val(addCommaSep(icrcncs));
                    }
                    
                    var cfacncs = removeCommaSep($j('#'+cfa+'_cncs').val());
                    if(cfacncs != ''){ 
                        cfacncs = parseFloat(cfacncs);
                    }else{
                        cfacncs = parseFloat(removeCommaSep($j('#'+cfa+'_cncsprev').val()));
                        if(compId != 0){
                            $j('#'+cfa+'_cncs').val(addCommaSep(cfacncs));
                        }
                        $j('#'+cfa+'_cncs_default').val(addCommaSep(cfacncs));
                    }
                    
                    var icrGrantee = calcicr;
                    var cfaGrantee = calccfa;
                    var icrGranteeInkind = removeCommaSep($j('#'+icr+'_granteeinkind').val());
                    if(icrGranteeInkind != ''){ 
                        icrGranteeInkind = parseFloat(icrGranteeInkind);
                    }else{
                        icrGranteeInkind = parseFloat(removeCommaSep($j('#'+icr+'_granteeinkindprev').val()));
                        if(compId != 0){
                            $j('#'+icr+'_granteeinkind').val(addCommaSep(icrGranteeInkind));
                        }
                    }
                    var cfaGranteeInkind = removeCommaSep($j('#'+cfa+'_granteeinkind').val());
                    if(cfaGranteeInkind != ''){ 
                        cfaGranteeInkind = parseFloat(cfaGranteeInkind);
                    }else{
                        cfaGranteeInkind = parseFloat(removeCommaSep($j('#'+cfa+'_granteeinkindprev').val()));
                        if(compId != 0){
                            $j('#'+cfa+'_granteeinkind').val(addCommaSep(cfaGranteeInkind));
                        }
                    }
                }else if(contributedFor == 'granteeinkind'){
                    var icrcncs = removeCommaSep($j('#'+icr+'_cncs').val());
                    if(icrcncs != ''){ 
                        icrcncs = parseFloat(icrcncs);
                    }else{
                        icrcncs = removeCommaSep($j('#'+icr+'_cncsprev').val());
                        if(compId != 0){
                            $j('#'+icr+'_cncs').val(addCommaSep(icrcncs));
                        }
                        $j('#'+icr+'_cncs_default').val(addCommaSep(icrcncs));
                    }
                    var cfacncs = removeCommaSep($j('#'+cfa+'_cncs').val());
                    if(cfacncs != ''){ 
                        cfacncs = parseFloat(cfacncs);
                    }else{
                        cfacncs = parseFloat(removeCommaSep($j('#'+cfa+'_cncsprev').val()));
                        if(compId != 0){
                            $j('#'+cfa+'_cncs').val(addCommaSep(cfacncs));
                        }
                        $j('#'+cfa+'_cncs_default').val(addCommaSep(cfacncs));
                    }
                    var icrGrantee = removeCommaSep($j('#'+icr+'_grantee').val());
                    if(icrGrantee != ''){ 
                        icrGrantee = parseFloat(icrGrantee);
                    }else{
                        icrGrantee = parseFloat(removeCommaSep($j('#'+icr+'_granteeprev').val()));
                        if(compId != 0){
                            $j('#'+icr+'_grantee').val(addCommaSep(icrGrantee));
                        }
                    }
                    var cfaGrantee = removeCommaSep($j('#'+cfa+'_grantee').val());
                    if(cfaGrantee != ''){ 
                        cfaGrantee = parseFloat(cfaGrantee);
                    }else{
                        cfaGrantee = parseFloat(removeCommaSep($j('#'+cfa+'_granteeprev').val()));
                        if(compId != 0){
                            $j('#'+cfa+'_grantee').val(addCommaSep(cfaGrantee));
                        }
                    }

                    var icrGranteeInkind = 0;
                    var cfaGranteeInkind = 0;

                    // change in cncs also impacts gramtee so that is why if changes contributed by cncs grantee calculation should also occur.
                    var calcicrgrantee = 0;
                    var calccfagrantee = 0;
                    if(noCalCulationForGranteeShare == 0){
                        var cncsSubtotaSection3 = removeCommaSep($j("#"+sec3Sub+"_cncs").val());
                        if(cncsSubtotaSection3 != ''){
                            cncsSubtotaSection3 = parseFloat(cncsSubtotaSection3);
                        }else{
                            cncsSubtotaSection3 = parseFloat(removeCommaSep($j("#"+sec3Sub+"_cncsprev").val()))
                        }
                        if(maxAmountRequestAsGranteeShare != 0 || mxGranteeShareZeroInclude == 1){
                            //calccorfa = ((SectionITotal+SectionIITotal)*0.1).toFixed(2);
                            calcicrgrantee = (((SectionITotal_Total+SectionIITotal_Total)*maxAmountRequestAsGranteeShare)-cncsSubtotaSection3);
                            icrGrantee = calcicrgrantee
                        }else{
                            calcicrgrantee = (0).toFixed(2);
                        }

                        calccfagrantee = removeCommaSep($j('#'+cfa+'_grantee').val());
                        if(calccfagrantee != ''){
                            calccfagrantee = parseFloat(calccfagrantee);
                        }else{
                            calccfagrantee = parseFloat(removeCommaSep($j('#'+cfa+'_granteeprev').val()));
                        }
                    }else{
                        calccfagrantee = removeCommaSep($j('#'+cfa+'_grantee').val());
                        if(calccfagrantee != ''){
                            calccfagrantee = parseFloat(calccfagrantee);
                        }else{
                            calccfagrantee = parseFloat(removeCommaSep($j('#'+cfa+'_granteeprev').val()));
                        }
                    }

                    //to check if expenses are greater than budget value.
                    var expensesIcr = removeCommaSep($j("#"+icr+"_granteeexpense").val());
                    if(expensesIcr != ''){
                        expensesIcr = parseFloat(expensesIcr);
                    }else{
                        expensesIcr = 0;
                    }
                    if(calcicrgrantee < expensesIcr){
                        calcicrgrantee = expensesIcr;
                        icrGrantee = expensesIcr;
                    }

                    $j('#'+icr+'_grantee_default').val(addCommaSep(calcicrgrantee.toFixed(2)));
                    if(compId != 0){
                        $j('#'+icr+'_grantee').val(addCommaSep(calcicrgrantee.toFixed(2)));
                        var sectionIIIsubtotalGrantee = parseFloat(calcicrgrantee) + parseFloat(calccfagrantee);
                        $j('#'+sec3faic+'_grantee').val(addCommaSep(sectionIIIsubtotalGrantee.toFixed(2)));
                        $j('#'+sec3Sub+'_grantee').val(addCommaSep(sectionIIIsubtotalGrantee.toFixed(2)));
                    }

                    var sectionIIIsubtotal = parseFloat(calcicr) + parseFloat(calccfa);
                }
                
                $j('#'+icr+'_'+contributedFor+'_default').val(addCommaSep(calcicr));
                if(compId != 0){
                    $j('#'+icr+'_'+contributedFor).val(addCommaSep(calcicr));
                    var totalicr = parseFloat(icrcncs)+parseFloat(icrGrantee)+parseFloat(icrGranteeInkind);
                    $j('#'+icr+'_total').val(addCommaSep(totalicr.toFixed(2)));
                    var totalprevicr = parseFloat(removeCommaSep($j("#"+icr+"_totalprev").val()));
                    var totalNewValueicr = removeCommaSep($j("#"+icr+"_totalnew").val());
                    if(totalNewValueicr != ''){
                        totalNewValueicr = parseFloat(totalNewValueicr);
                    }
                    var calcicrprevavlue = parseFloat(removeCommaSep($j('#'+icr+'_'+contributedFor+'prev').val()));
                    var totalChangePercent = $j("#totalChangePercent").val();
                    var totalLineChange = parseInt($j("#totalLineChange").val());
                    if(contributedFor == 'granteeinkind'){
                        var calicrgranteeprevValue = parseFloat(removeCommaSep($j('#'+icr+'_granteeprev').val()));
                        calculateChangePercent(icr, totalChangePercent, totalicr, totalprevicr, totalNewValueicr, totalLineChange, 'grantee', calcicrgrantee, calicrgranteeprevValue)
                    }else{
                        calculateChangePercent(icr, totalChangePercent, totalicr, totalprevicr, totalNewValueicr, totalLineChange, contributedFor, calcicr, calcicrprevavlue)
                    }
                }

                $j('#'+cfa+'_'+contributedFor+'_default').val(addCommaSep(calccfa));
                if(compId != 0){
                    $j('#'+cfa+'_'+contributedFor).val(addCommaSep(calccfa));   
                    var totalcfa = parseFloat(cfaGrantee)+parseFloat(cfacncs)+parseFloat(cfaGranteeInkind);
                    $j('#'+cfa+'_total').val(addCommaSep(totalcfa.toFixed(2)));    
                    var totalprevcfa = parseFloat(removeCommaSep($j("#"+cfa+"_totalprev").val()));
                    var totalNewValuecfa = removeCommaSep($j("#"+cfa+"_totalnew").val());
                    if(totalNewValuecfa != ''){
                        totalNewValuecfa = parseFloat(totalNewValuecfa);
                    }
                    var calccfaprevavlue = parseFloat(removeCommaSep($j('#'+cfa+'_'+contributedFor+'prev').val()));
                    var totalChangePercent = $j("#totalChangePercent").val();
                    var totalLineChange = parseInt($j("#totalLineChange").val());
                    if(contributedFor == 'granteeinkind'){
                        var calcfagranteeprevValue = parseFloat(removeCommaSep($j('#'+cfa+'_granteeprev').val()));
                        calculateChangePercent(cfa, totalChangePercent, totalcfa, totalprevcfa, totalNewValuecfa, totalLineChange, 'grantee', calccfagrantee, calcfagranteeprevValue)
                    }else{
                        calculateChangePercent(cfa, totalChangePercent, totalcfa, totalprevcfa, totalNewValuecfa, totalLineChange, contributedFor, calccfa, calccfaprevavlue)
                    }
                   $j('#'+sec3faic+'_'+contributedFor).val(addCommaSep(sectionIIIsubtotal.toFixed(2)));
                   $j('#'+sec3Sub+'_'+contributedFor).val(addCommaSep(sectionIIIsubtotal.toFixed(2)));
                }
                
                var totalsec3faic = 0;
                var sec3SubTotal = 0;
                
                if($j('#'+sec3faic+'_grantee').val() != ''){
                    var sec3faicGrantee = parseFloat(removeCommaSep($j('#'+sec3faic+'_grantee').val()));
                }else{       
                    var sec3faicGrantee = parseFloat(removeCommaSep($j('#'+sec3faic+'_granteeprev').val()));
                    if(compId != 0){
                        $j('#'+sec3faic+'_grantee').val(addCommaSep(sec3faicGrantee.toFixed(2)));
                    }
                }
                if(removeCommaSep($j('#'+sec3faic+'_cncs').val()) != ''){
                    var sec3faicCncs = parseFloat(removeCommaSep($j('#'+sec3faic+'_cncs').val()));
                }else{       
                    var sec3faicCncs = parseFloat(removeCommaSep($j('#'+sec3faic+'_cncsprev').val()));
                    if(compId != 0){
                        $j('#'+sec3faic+'_cncs').val(addCommaSep(sec3faicCncs.toFixed(2)));
                    }
                }

                var sec3faicGranteeinkind = 0;
                if($j('#'+sec3faic+'_granteeinkind').val() != undefined){
                    if(removeCommaSep($j('#'+sec3faic+'_granteeinkind').val()) != ''){
                        sec3faicGranteeinkind = parseFloat(removeCommaSep($j('#'+sec3faic+'_granteeinkind').val()));
                    }else{       
                        sec3faicGranteeinkind = parseFloat(removeCommaSep($j('#'+sec3faic+'_granteeinkindprev').val()));
                    }
                    if(compId != 0){
                        $j('#'+sec3faic+'_granteeinkind').val(addCommaSep(sec3faicGranteeinkind.toFixed(2)));
                    }
                }

                var sec3SubGranteePrev = removeCommaSep($j('#'+sec3Sub+'_granteeprev').val());
                if(removeCommaSep($j('#'+sec3Sub+'_grantee').val()) != ''){
                    var sec3SubGrantee = parseFloat(removeCommaSep($j('#'+sec3Sub+'_grantee').val()));
                }else{       
                    var sec3SubGrantee = parseFloat(removeCommaSep($j('#'+sec3Sub+'_granteeprev').val()));
                    $j('#'+sec3Sub+'_grantee').val(addCommaSep(sec3SubGrantee.toFixed(2)));
                }
                var sec3SubCncsPrev = removeCommaSep($j('#'+sec3Sub+'_cncsprev').val());
                if(removeCommaSep($j('#'+sec3Sub+'_cncs').val()) != ''){
                    var sec3SubCncs = parseFloat(removeCommaSep($j('#'+sec3Sub+'_cncs').val()));
                }else{       
                    var sec3SubCncs = parseFloat(removeCommaSep($j('#'+sec3Sub+'_cncsprev').val()));
                    $j('#'+sec3Sub+'_cncs').val(addCommaSep(sec3SubCncs.toFixed(2)));
                }
                var sec3SubGranteeinkindPrev = removeCommaSep($j('#'+sec3Sub+'_granteeinkindprev').val());
                if(removeCommaSep($j('#'+sec3Sub+'_granteeinkind').val()) != ''){
                    var sec3SubGranteeinkind = parseFloat(removeCommaSep($j('#'+sec3Sub+'_granteeinkind').val()));
                }else{       
                    var sec3SubGranteeinkind = parseFloat(removeCommaSep($j('#'+sec3Sub+'_granteeinkindprev').val()));
                    $j('#'+sec3Sub+'_granteeinkind').val(addCommaSep(sec3SubGranteeinkind.toFixed(2)));
                }

                if(contributedFor == 'cncs'){
                    totalsec3faic = sec3faicGrantee+parseFloat(sectionIIIsubtotal)+sec3faicGranteeinkind;
                    sec3SubTotal = parseFloat(sectionIIIsubtotal+sec3SubGrantee+sec3SubGranteeinkind);
                    $j("#"+sec3Sub+'_grantee').val(addCommaSep(sec3SubGrantee.toFixed(2)));
                    $j("#"+sec3Sub+'_granteeinkind').val(addCommaSep(sec3SubGranteeinkind.toFixed(2)));
                }else if(contributedFor == 'grantee'){
                    totalsec3faic = sec3faicCncs+parseFloat(sectionIIIsubtotal)+sec3faicGranteeinkind;
                    sec3SubTotal = parseFloat(sectionIIIsubtotal+sec3SubCncs+sec3SubGranteeinkind);
                    $j("#"+sec3Sub+'_cncs').val(addCommaSep(sec3SubCncs.toFixed(2)));
                    $j("#"+sec3Sub+'_granteeinkind').val(addCommaSep(sec3SubGranteeinkind.toFixed(2)));
                }else if(contributedFor == 'granteeinkind'){
                    totalsec3faic = sec3faicGrantee+parseFloat(sectionIIIsubtotal)+sec3faicCncs;
                    sec3SubTotal = parseFloat(sectionIIIsubtotal+sec3SubGrantee+sec3SubCncs);
                    $j("#"+sec3Sub+'_cncs').val(addCommaSep(sec3SubCncs.toFixed(2)));
                    $j("#"+sec3Sub+'_grantee').val(addCommaSep(sec3SubGrantee.toFixed(2)));
                }

                if(compId != 0){
                    $j('#'+sec3faic+'_total').val(addCommaSep(totalsec3faic.toFixed(2)));
                    $j('#'+sec3Sub+'_total').val(addCommaSep(sec3SubTotal.toFixed(2)));
                

                var cncsChangeValue = 0;
                var granteeChangeValue = 0;
                var granteeinkindChangeValue = 0;
                var totalChangeValue = 0;

                sec3SubCncsPrev = parseFloat(sec3SubCncsPrev);
                if(sec3SubCncs > 0){
                    cncsChangeValue =  sec3SubCncs - sec3SubCncsPrev;
                }
                if(sec3SubCncsPrev > 0){
                    var cncsChangePercent = (cncsChangeValue/sec3SubCncsPrev)*100;
                }else{
                    var cncsChangePercent = cncsChangeValue;
                }
                if(cncsChangeValue > 0){
                    $j("#changevaluesummarycncs_"+sec3Sub).html('+$'+addCommaSep(cncsChangeValue.toFixed(2)));
                    if(cncsChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarycncs_"+sec3Sub).html('('+cncsChangePercent.toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarycncs_"+sec3Sub).html('(+'+cncsChangePercent.toFixed(2)+'%)');
                    }                
                }else if(cncsChangeValue == 0){
                    $j("#changevaluesummarycncs_"+sec3Sub).html('');
                    $j("#changepercentsummarycncs_"+sec3Sub).html('');
                }else{
                    $j("#changevaluesummarycncs_"+sec3Sub).html('-$'+addCommaSep(Math.abs(cncsChangeValue).toFixed(2)));
                    if(cncsChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarycncs_"+sec3Sub).html('('+Math.abs(cncsChangePercent).toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarycncs_"+sec3Sub).html('(-'+Math.abs(cncsChangePercent).toFixed(2)+'%)');
                    }
                }
                sec3SubGranteePrev = parseFloat(sec3SubGranteePrev);
                if(sec3SubGrantee > 0){
                    granteeChangeValue = sec3SubGrantee - sec3SubGranteePrev;
                }
                if(sec3SubGranteePrev > 0){
                    var granteeChangePercent = (granteeChangeValue/sec3SubGranteePrev)*100;
                }else{
                    var granteeChangePercent = granteeChangeValue;
                }
                if(granteeChangeValue > 0){
                    $j("#changevaluesummarygrantee_"+sec3Sub).html('+$'+addCommaSep(granteeChangeValue.toFixed(2)));
                    if(granteeChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarygrantee_"+sec3Sub).html('('+granteeChangePercent.toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarygrantee_"+sec3Sub).html('(+'+granteeChangePercent.toFixed(2)+'%)');
                    }
                }else if(granteeChangeValue == 0){
                    $j("#changevaluesummarygrantee_"+sec3Sub).html('');
                    $j("#changepercentsummarygrantee_"+sec3Sub).html('');
                }else{
                    $j("#changevaluesummarygrantee_"+sec3Sub).html('-$'+addCommaSep(Math.abs(granteeChangeValue).toFixed(2)));
                    if(granteeChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarygrantee_"+sec3Sub).html('('+Math.abs(granteeChangePercent).toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarygrantee_"+sec3Sub).html('(-'+Math.abs(granteeChangePercent).toFixed(2)+'%)');
                    }
                }
                sec3SubGranteeinkindPrev = parseFloat(sec3SubGranteeinkindPrev);
                if(sec3SubGranteeinkind > 0){
                    granteeinkindChangeValue =  sec3SubGranteeinkind - sec3SubGranteeinkindPrev;
                }
                if(sec3SubGranteeinkindPrev > 0){
                    var granteeinkindChangePercent = (granteeinkindChangeValue/sec3SubGranteeinkindPrev)*100;
                }else{
                    var granteeinkindChangePercent = granteeinkindChangeValue;
                }
                if(granteeinkindChangeValue > 0){
                    $j("#changevaluesummarygranteeinkind_"+sec3Sub).html('+$'+addCommaSep(granteeinkindChangeValue.toFixed(2)));
                    if(granteeinkindChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarygranteeinkind_"+sec3Sub).html('('+granteeinkindChangePercent.toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarygranteeinkind_"+sec3Sub).html('(+'+granteeinkindChangePercent.toFixed(2)+'%)');
                    }
                }else if(granteeinkindChangeValue == 0){
                    $j("#changevaluesummarygranteeinkind_"+sec3Sub).html('');
                    $j("#changepercentsummarygranteeinkind_"+sec3Sub).html('');
                }else{
                    $j("#changevaluesummarygranteeinkind_"+sec3Sub).html('-$'+addCommaSep(Math.abs(granteeinkindChangeValue).toFixed(2)));
                    if(granteeinkindChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarygranteeinkind_"+sec3Sub).html('('+Math.abs(granteeinkindChangePercent).toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarygranteeinkind_"+sec3Sub).html('(-'+Math.abs(granteeinkindChangePercent).toFixed(2)+'%)');
                    }
                }

                sec3totalprev_value = parseFloat(removeCommaSep($j('#'+sec3Sub+'_totalprev').val()));
                if(sec3SubTotal > 0){
                    totalChangeValue =  sec3SubTotal - sec3totalprev_value;
                }
                if(sec3totalprev_value > 0){
                    var totalChangePercent = (totalChangeValue/sec3totalprev_value)*100;
                }else{
                    var totalChangePercent = totalChangeValue;
                }
                if(totalChangeValue > 0){
                    $j("#changevaluesummarytotal_"+sec3Sub).html('+$'+addCommaSep(totalChangeValue.toFixed(2)));
                    if(totalChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarytotal_"+sec3Sub).html('('+totalChangePercent.toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarytotal_"+sec3Sub).html('(+'+totalChangePercent.toFixed(2)+'%)');
                    }         
                }else if(totalChangeValue == 0){
                    $j("#changevaluesummarytotal_"+sec3Sub).html('');
                    $j("#changepercentsummarytotal_"+sec3Sub).html('');
                }else{
                    $j("#changevaluesummarytotal_"+sec3Sub).html('-$'+addCommaSep(Math.abs(totalChangeValue).toFixed(2)));
                    if(totalChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarytotal_"+sec3Sub).html('('+Math.abs(totalChangePercent).toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarytotal_"+sec3Sub).html('(-'+Math.abs(totalChangePercent).toFixed(2)+'%)');
                    }              
                }

                if(sec3SubTotal > 0){
                    percentValue = (sectionIIIsubtotal/sec3SubTotal)*100;
                }else{
                    percentValue = 0;
                }

                var displayCompCount = $j('#'+sec3Sub+'_cncs').attr("data-displaycount");
                if(sec3SubTotal == removeCommaSep($j('#'+sec3Sub+'_totalprev').val())){
                    //$j('#'+sec3Sub+'_total').val('');
                    //$j(".trsimple_total_"+sec3Sub).hide();
                    $j(".trsimple_total_"+sec3Sub+" input").css("color","black");
                    $j("#trsimple-total"+displayCompCount+"_input").val(0);
                    $j(".changevaluesummary_"+sec3Sub).html('-');
                    $j("#"+sec3Sub+"_changespan").show();
                }else{
                    //$j('#'+sec3Sub+'_total').val(totalofSubTotal.toFixed(2));
                    /*if($j("#"+sec3Sub+"_cncs").attr('data-section') == 'section3'){
                        //if(!$j(".hideshowwrapper_dsiplayCount_3 .dataGroupHeader .showHide").hasClass('showIt')){
                            $j(".trsimple_total_"+sec3Sub).show();
                        //}
                    }else{
                        $j(".trsimple_total_"+sec3Sub).show();
                    }*/
                    $j(".trsimple_total_"+sec3Sub).show();
                    $j(".trsimple_total_"+sec3Sub+" input").css("color","#C70404");
                    $j("#trsimple-total"+displayCompCount+"_input").val(1);
                    $j("#"+sec3Sub+"_changespan").show();
                }

                calcPercent = true;
            }
            }
        }  
        
        if(calcPercent){
            var displayCompCount = $j('#'+sec3Sub+'_cncs').attr("data-displaycount");
            var checkTotalChangeExists = $j("#trsimple-total"+displayCompCount+"_input").val();

            if(contributedFor == 'cncs'){
                var remainingPercent = Math.abs(100-percentValue);
                if(remainingPercent > 0){
                    var prevCompId = sec3Percent - 1;

                    var prevCompIdGrantee = removeCommaSep($j("#"+prevCompId+"_grantee").val());
                    if(prevCompIdGrantee != ''){
                        prevCompIdGrantee = parseFloat(prevCompIdGrantee);
                    }else{
                        prevCompIdGrantee = parseFloat(removeCommaSep($j("#"+prevCompId+"_granteeprev").val()));
                    }
                    var prevCompIdGranteeInKind = removeCommaSep($j("#"+prevCompId+"_granteeinkind").val());
                    if(prevCompIdGranteeInKind != ''){
                        prevCompIdGranteeInKind = parseFloat(prevCompIdGranteeInKind);
                    }else{
                        prevCompIdGranteeInKind = parseFloat(removeCommaSep($j("#"+prevCompId+"_granteeinkindprev").val()));
                    }

                    var totalValueRemaimingComps = prevCompIdGrantee + prevCompIdGranteeInKind;
                    if(totalValueRemaimingComps > 0){
                        var granteePercent = parseFloat((prevCompIdGrantee/totalValueRemaimingComps)*remainingPercent);
                    }else{
                        var granteePercent = 0;
                    }

                    //granteePercent = Math.round(granteePercent);

                    if(granteePercent == 0 && percentValue == 0){
                        var granteeInkindPercent =  0;
                    }else{
                        var granteeInkindPercent = Math.abs(remainingPercent-granteePercent);
                    }
                }else{
                    var granteePercent = 0;
                    var granteeInkindPercent = 0;
                }

                $j('#'+sec3Percent+'_cncs').val(percentValue.toFixed(2));
                $j('#'+sec3Percent+'_grantee').val(granteePercent.toFixed(2));
                $j("#"+sec3Percent+'_granteeinkind').val(granteeInkindPercent.toFixed(2));

                if(parseFloat($j('#'+sec3Percent+'_cncsprev').val()) == (percentValue).toFixed(2) && checkTotalChangeExists == 0){
                    //$j('#'+grantee).val('');
                    //$j('#'+cncs).val('');
                    //$j('#'+granteeinkind).val('');
                    //$j(".trsimple_percent_"+sectionPercentCompId).hide();
                    $j(".trsimple_percent_"+sec3Percent+" input").css("color","black");
                    $j("#trsimple-percent"+displayCompCount+"_input").val(0);
                }else{
                    /*if($j("#"+sec3Percent+"_cncs").attr('data-section') == 'section3'){
                        if(!$j(".hideshowwrapper_dsiplayCount_3 .dataGroupHeader .showHide").hasClass('showIt')){
                            $j(".trsimple_percent_"+sec3Percent).show();
                        }
                    }else{
                        $j(".trsimple_percent_"+sec3Percent).show();
                    }*/
                    $j(".trsimple_percent_"+sec3Percent).show();
                    $j(".trsimple_percent_"+sec3Percent).css("color","#C70404");
                    $j("#trsimple-percent"+displayCompCount+"_input").val(1);
                }
            }else if(contributedFor == 'grantee'){
                
                var remainingPercent = Math.abs(100-percentValue);
                if(remainingPercent > 0){
                    var prevCompId = sec3Percent - 1;
                    var prevCompIdCncs = removeCommaSep($j("#"+prevCompId+"_cncs").val());
                    if(prevCompIdCncs != ''){
                        prevCompIdCncs = parseFloat(prevCompIdCncs);
                    }else{
                        prevCompIdCncs = parseFloat(removeCommaSep($j("#"+prevCompId+"_cncsprev").val()));
                    }

                    var prevCompIdGranteeInKind = removeCommaSep($j("#"+prevCompId+"_granteeinkind").val());
                    if(prevCompIdGranteeInKind != ''){
                        prevCompIdGranteeInKind = parseFloat(prevCompIdGranteeInKind);
                    }else{
                        prevCompIdGranteeInKind = parseFloat(removeCommaSep($j("#"+prevCompId+"_granteeinkindprev").val()));
                    }
                    var totalValueRemaimingComps = prevCompIdCncs + prevCompIdGranteeInKind;
                    if(totalValueRemaimingComps > 0){
                        var cncsPercent = parseFloat((prevCompIdCncs/totalValueRemaimingComps)*remainingPercent);
                    }else{
                        var cncsPercent = 0;
                    }
                    //cncsPercent = Math.round(cncsPercent);
                    if(cncsPercent == 0 && percentValue == 0){
                        var granteeInkindPercent =  0;
                    }else{
                        var granteeInkindPercent = Math.abs(remainingPercent-cncsPercent);
                    }
                }else{
                    var cncsPercent = 0;
                    var granteeInkindPercent = 0;
                }
                $j('#'+sec3Percent+'_cncs').val(cncsPercent.toFixed(2));
                $j('#'+sec3Percent+'_grantee').val(percentValue.toFixed(2));
                $j("#"+sec3Percent+'_granteeinkind').val(granteeInkindPercent.toFixed(2));
                if(parseFloat($j('#'+sec3Percent+'_granteeprev').val()) == (percentValue).toFixed(2) && checkTotalChangeExists == 0){
                    //$j('#'+grantee).val('');
                    //$j('#'+cncs).val('');
                    //$j('#'+granteeinkind).val('');
                    //$j(".trsimple_percent_"+sectionPercentCompId).hide();
                    $j(".trsimple_percent_"+sec3Percent+" input").css("color","black");
                    $j("#trsimple-percent"+displayCompCount+"_input").val(0);
                }else{
                    /*if($j("#"+sec3Percent+"_cncs").attr('data-section') == 'section3'){
                        if(!$j(".hideshowwrapper_dsiplayCount_3 .dataGroupHeader .showHide").hasClass('showIt')){
                            $j(".trsimple_percent_"+sec3Percent).show();
                        }
                    }else{
                        $j(".trsimple_percent_"+sec3Percent).show();
                    }*/
                    $j(".trsimple_percent_"+sec3Percent).show();
                    $j(".trsimple_percent_"+sec3Percent+" input").css("color","#C70404");
                    $j("#trsimple-percent"+displayCompCount+"_input").val(1);
                }
            }else if(contributedFor == 'granteeinkind'){
                
                var remainingPercent = Math.abs(100-percentValue);
                if(remainingPercent > 0){
                    var prevCompId = sec3Percent - 1;
                    var prevCompIdCncs = removeCommaSep($j("#"+prevCompId+"_cncs").val());
                    if(prevCompIdCncs != ''){
                        prevCompIdCncs = parseFloat(prevCompIdCncs);
                    }else{
                        prevCompIdCncs = parseFloat(removeCommaSep($j("#"+prevCompId+"_cncs").val()));
                    }

                    var prevCompIdGrantee = removeCommaSep($j("#"+prevCompId+"_grantee").val());
                    if(prevCompIdGrantee != ''){
                        prevCompIdGrantee = parseFloat(prevCompIdGrantee);
                    }else{
                        prevCompIdGrantee = parseFloat(removeCommaSep($j("#"+prevCompId+"_granteeprev").val()));
                    }
                    var totalValueRemaimingComps = prevCompIdCncs + prevCompIdGrantee;                    
                    if(totalValueRemaimingComps > 0){
                        var cncsPercent = parseFloat((prevCompIdCncs/totalValueRemaimingComps)*remainingPercent);
                    }else{
                        var cncsPercent = 0;
                    }

                    //cncsPercent = Math.round(cncsPercent);
                    if(cncsPercent == 0 && percentValue == 0){
                        var granteePercent =  0;
                    }else{
                        var granteePercent = Math.abs(remainingPercent-cncsPercent);
                    }
                }else{
                    var cncsPercent = 0;
                    var granteePercent = 0;
                }
                $j('#'+sec3Percent+'_cncs').val(cncsPercent.toFixed(2));
                $j('#'+sec3Percent+'_grantee').val(granteePercent.toFixed(2));
                $j("#"+sec3Percent+'_granteeinkind').val(percentValue.toFixed(2));
                if(parseFloat($j('#'+sec3Percent+'_granteeinkindprev').val()) == (percentValue).toFixed(2) && checkTotalChangeExists == 0){
                    //$j('#'+grantee).val('');
                    //$j('#'+cncs).val('');
                    //$j('#'+granteeinkind).val('');
                    //$j(".trsimple_percent_"+sectionPercentCompId).hide();
                    $j(".trsimple_percent_"+sec3Percent+" input").css("color","black");
                    $j("#trsimple-percent"+displayCompCount+"_input").val(0);
                }else{
                    /*if($j("#"+sec3Percent+"_cncs").attr('data-section') == 'section3'){
                        if(!$j(".hideshowwrapper_dsiplayCount_3 .dataGroupHeader .showHide").hasClass('showIt')){
                            $j(".trsimple_percent_"+sec3Percent).show();
                        }
                    }else{
                        $j(".trsimple_percent_"+sec3Percent).show();
                    }*/
                    $j(".trsimple_percent_"+sec3Percent).show();
                    $j(".trsimple_percent_"+sec3Percent+" input").css("color","#C70404");
                    $j("#trsimple-percent"+displayCompCount+"_input").val(1);
                }
            }
        }
    }

    if(compId != 0 && compId != 9899901){
        showLinkToSetDefault();
    }
}


function calculateSubTotal(calculateFor){
    var componentId = $j('#'+calculateFor).attr('data-componentId');
    var formula = $j('#'+calculateFor).attr('data-formula');
    var formulaSign = $j('#'+calculateFor).attr('data-formulaSign');
    var displayCompCount = $j('#'+calculateFor).attr("data-displayCount");

    var formularArr = formula.split(',')
    var formulaSignArr = formulaSign.split(',')

    var Subtotal = 0;
    var totalofSubTotal = 0;

    for(var i=0; i<formularArr.length; i++){
        var elementvalue = removeCommaSep($j('#'+formularArr[i]).val());
        if(elementvalue === ''){
            elementvalue = removeCommaSep($j('#'+formularArr[i]+'prev').val());
        }
        if(elementvalue == undefined || elementvalue == 'undefined'){
            elementvalue = 0;
        }
        if(formulaSignArr[i] == '/'){
            Subtotal = Subtotal/parseFloat(elementvalue);
        }else if(formulaSignArr[i] == '*'){
            Subtotal = Subtotal*parseFloat(elementvalue);
        }else if(formulaSignArr[i] == '+'){
            Subtotal = Subtotal+parseFloat(elementvalue);
        }else if(formulaSignArr[i] == '-'){
            Subtotal = Subtotal-parseFloat(elementvalue);
        }         
    }
 
    /*if($j('#'+calculateFor+'prev').val() == Subtotal){
        $j('#'+calculateFor).val('');
    }else{*/
        $j('#'+calculateFor).val(addCommaSep(Subtotal.toFixed(2)));
    //}
        
    var cncs_value = removeCommaSep($j('#'+componentId+'_cncs').val());
    var cncsprev_value = removeCommaSep($j('#'+componentId+'_cncsprev').val());
    if(cncs_value != ''){
        cncs_value = parseFloat(cncs_value);
    }else{
        cncs_value = parseFloat(cncsprev_value);
    }

    var grantee_value = removeCommaSep($j('#'+componentId+'_grantee').val());
    var granteeprev_value = removeCommaSep($j('#'+componentId+'_granteeprev').val());
    if(grantee_value != ''){
        grantee_value = parseFloat(grantee_value);
    }else{
        grantee_value = parseFloat(granteeprev_value);
    }

    var granteeinkind_value = removeCommaSep($j('#'+componentId+'_granteeinkind').val());
    var granteeinkindprev_value = removeCommaSep($j('#'+componentId+'_granteeinkindprev').val());
    if(granteeinkind_value != ''){
        granteeinkind_value = parseFloat(granteeinkind_value);
    }else{
        granteeinkind_value = parseFloat(granteeinkindprev_value);
    }

    var cncsCompElement = componentId+'_cncs';
    var granteeCompElement = componentId+'_grantee';
    var granteeInkindCompElement = componentId+'_granteeinkind';
    
    if(calculateFor == cncsCompElement){
        $j("#"+componentId+'_grantee').val(addCommaSep(grantee_value.toFixed(2)));
        $j("#"+componentId+'_granteeinkind').val(addCommaSep(granteeinkind_value.toFixed(2)));
    }else if(calculateFor == granteeCompElement){
        $j("#"+componentId+'_cncs').val(addCommaSep(cncs_value.toFixed(2)));
        $j("#"+componentId+'_granteeinkind').val(addCommaSep(granteeinkind_value.toFixed(2)));
    }else if(calculateFor == granteeInkindCompElement){
        $j("#"+componentId+'_cncs').val(addCommaSep(cncs_value.toFixed(2)));
        $j("#"+componentId+'_grantee').val(addCommaSep(grantee_value.toFixed(2)));
    }   

    totalofSubTotal = totalofSubTotal + cncs_value + grantee_value + granteeinkind_value;
    
    if(totalofSubTotal == removeCommaSep($j('#'+componentId+'_totalprev').val())){
        $j('#'+componentId+'_total').val(addCommaSep(totalofSubTotal.toFixed(2)));
        //$j(".trsimple_total_"+componentId).hide();
        $j(".trsimple_total_"+componentId+" input").css("color","black");
        $j("#trsimple-total"+displayCompCount+"_input").val(0);
        $j("#"+componentId+"_changespan").show();
        $j(".changevaluesummary_"+componentId).html('-');
        var calChangeValue = false;
    }else{
        $j('#'+componentId+'_total').val(addCommaSep(totalofSubTotal.toFixed(2)));
        $j(".trsimple_total_"+componentId).show();
        $j(".trsimple_total_"+componentId+" input").css("color","#C70404");
        $j("#trsimple-total"+displayCompCount+"_input").val(1);
        $j("#"+componentId+"_changespan").show();
        var calChangeValue = true;
    }

    if(calChangeValue){
        var cncsChangeValue = 0;
        var granteeChangeValue = 0;
        var granteeinkindChangeValue = 0;
        var totalChangeValue = 0;

        cncsprev_value = parseFloat(cncsprev_value);
        if(cncs_value > 0){
            cncsChangeValue =  cncs_value - cncsprev_value;
        }
        if(cncsprev_value > 0){
            var cncsChangePercent = (cncsChangeValue/cncsprev_value)*100;
        }else{
            var cncsChangePercent = cncsChangeValue;
        }
        if(cncsChangeValue > 0){
            $j("#changevaluesummarycncs_"+componentId).html('+$'+addCommaSep(cncsChangeValue.toFixed(2)));
            if(cncsChangePercent.toFixed(2) == 0){
                $j("#changepercentsummarycncs_"+componentId).html('('+cncsChangePercent.toFixed(2)+'%)');
            }else{
                $j("#changepercentsummarycncs_"+componentId).html('(+'+cncsChangePercent.toFixed(2)+'%)');
            } 
        }else if(cncsChangeValue == 0){
            $j("#changevaluesummarycncs_"+componentId).html('');
            $j("#changepercentsummarycncs_"+componentId).html('');
        }else{
            $j("#changevaluesummarycncs_"+componentId).html('-$'+addCommaSep(Math.abs(cncsChangeValue).toFixed(2)));
            if(cncsChangePercent.toFixed(2) == 0){
                $j("#changepercentsummarycncs_"+componentId).html('('+Math.abs(cncsChangePercent).toFixed(2)+'%)');
            }else{
                $j("#changepercentsummarycncs_"+componentId).html('(-'+Math.abs(cncsChangePercent).toFixed(2)+'%)');
            }  
        }
        granteeprev_value = parseFloat(granteeprev_value);
        if(grantee_value > 0){
            granteeChangeValue = grantee_value - granteeprev_value;
        }
        if(granteeprev_value > 0){
            var granteeChangePercent = (granteeChangeValue/granteeprev_value)*100;
        }else{
            var granteeChangePercent = granteeChangeValue;
        }
        if(granteeChangeValue > 0){
            $j("#changevaluesummarygrantee_"+componentId).html('+$'+addCommaSep(granteeChangeValue.toFixed(2)));
            if(granteeChangePercent.toFixed(2) == 0){
                $j("#changepercentsummarygrantee_"+componentId).html('('+granteeChangePercent.toFixed(2)+'%)');
            }else{
                $j("#changepercentsummarygrantee_"+componentId).html('(+'+granteeChangePercent.toFixed(2)+'%)');
            }           
        }else if(granteeChangeValue == 0){
            $j("#changevaluesummarygrantee_"+componentId).html('');
            $j("#changepercentsummarygrantee_"+componentId).html('');
        }else{
            $j("#changevaluesummarygrantee_"+componentId).html('-$'+addCommaSep(Math.abs(granteeChangeValue).toFixed(2)));
            if(granteeChangePercent.toFixed(2) == 0){
                $j("#changepercentsummarygrantee_"+componentId).html('('+Math.abs(granteeChangePercent).toFixed(2)+'%)');
            }else{
                $j("#changepercentsummarygrantee_"+componentId).html('(-'+Math.abs(granteeChangePercent).toFixed(2)+'%)');
            }
        }
        granteeinkindprev_value = parseFloat(granteeinkindprev_value);
        if(granteeinkind_value > 0){
            granteeinkindChangeValue =  granteeinkind_value - granteeinkindprev_value;
        }
        if(granteeinkindprev_value > 0){
            var granteeinkindChangePercent = (granteeinkindChangeValue/granteeinkindprev_value)*100;
        }else{
            var granteeinkindChangePercent = granteeinkindChangeValue;
        }
        if(granteeinkindChangeValue > 0){
            $j("#changevaluesummarygranteeinkind_"+componentId).html('+$'+addCommaSep(granteeinkindChangeValue.toFixed(2)));
            if(granteeinkindChangePercent.toFixed(2) == 0){
                $j("#changepercentsummarygranteeinkind_"+componentId).html('('+granteeinkindChangePercent.toFixed(2)+'%)');
            }else{
                $j("#changepercentsummarygranteeinkind_"+componentId).html('(+'+granteeinkindChangePercent.toFixed(2)+'%)');
            }
        }else if(granteeinkindChangeValue == 0){
            $j("#changevaluesummarygranteeinkind_"+componentId).html('');
            $j("#changepercentsummarygranteeinkind_"+componentId).html('');
        }else{
            $j("#changevaluesummarygranteeinkind_"+componentId).html('-$'+addCommaSep(Math.abs(granteeinkindChangeValue).toFixed(2)));
            if(granteeinkindChangePercent.toFixed(2) == 0){
                $j("#changepercentsummarygranteeinkind_"+componentId).html('('+Math.abs(granteeinkindChangePercent).toFixed(2)+'%)');
            }else{
                $j("#changepercentsummarygranteeinkind_"+componentId).html('(-'+Math.abs(granteeinkindChangePercent).toFixed(2)+'%)');
            }
        }

        totalprev_value = parseFloat(removeCommaSep($j('#'+componentId+'_totalprev').val()));
        if(totalofSubTotal > 0){
            totalChangeValue =  totalofSubTotal - totalprev_value;
        }
        if(totalprev_value > 0){
            var totalChangePercent = (totalChangeValue/totalprev_value)*100;
        }else{
            var totalChangePercent = totalChangeValue;
        }
        if(totalChangeValue > 0){
            $j("#changevaluesummarytotal_"+componentId).html('+$'+addCommaSep(totalChangeValue.toFixed(2)));
            if(totalChangePercent.toFixed(2) == 0){
                $j("#changepercentsummarytotal_"+componentId).html('('+totalChangePercent.toFixed(2)+'%)');
            }else{
                $j("#changepercentsummarytotal_"+componentId).html('(+'+totalChangePercent.toFixed(2)+'%)');
            }
        }else if(totalChangeValue == 0){
            $j("#changevaluesummarytotal_"+componentId).html('');
            $j("#changepercentsummarytotal_"+componentId).html('');
        }else{
            $j("#changevaluesummarytotal_"+componentId).html('-$'+addCommaSep(Math.abs(totalChangeValue).toFixed(2)));
            if(totalChangePercent.toFixed(2) == 0){
                $j("#changepercentsummarytotal_"+componentId).html('('+Math.abs(totalChangePercent).toFixed(2)+'%)');
            }else{
                $j("#changepercentsummarytotal_"+componentId).html('(-'+Math.abs(totalChangePercent).toFixed(2)+'%)');
            }
        }
    }
}

function calculateParent(formula, formulaSign, calFor){
    var compId = $j('#'+calFor).attr('data-componentId');
    var formularArr = formula.split(',')
    var formulaSignArr = formulaSign.split(',')
    var displayCompCount = $j('#'+compId+'_cncs').attr("data-displayCount");

    var parentTotal = 0;
    var totalofParentTotal = 0;

    for(var i=0; i<formularArr.length; i++){
        var elementvalue = removeCommaSep($j('#'+formularArr[i]).val());
        if(elementvalue == undefined || elementvalue == 'undefined'){
            elementvalue = 0;
        }else if(elementvalue === ''){
            elementvalue = removeCommaSep($j('#'+formularArr[i]+'prev').val());
        }
        if(formulaSignArr[i] == '/'){
            parentTotal = parentTotal/parseFloat(elementvalue);
        }else if(formulaSignArr[i] == '*'){
            parentTotal = parentTotal*parseFloat(elementvalue);
        }else if(formulaSignArr[i] == '+'){
            parentTotal = parentTotal+parseFloat(elementvalue);
        }else if(formulaSignArr[i] == '-'){
            parentTotal = parentTotal-parseFloat(elementvalue);
        }         
    }

    /*if($j('#'+calFor+'prev').val() == parentTotal){
        $j('#'+calFor).val('');
    }else{*/
        $j('#'+calFor).val(addCommaSep(parentTotal.toFixed(2)));
    //}
    
    var cncs_value = removeCommaSep($j('#'+compId+'_cncs').val());
    var cncsprev_value = removeCommaSep($j('#'+compId+'_cncsprev').val());
    if(cncs_value != ''){
        cncs_value = parseFloat(cncs_value);
    }else{
        cncs_value = parseFloat(cncsprev_value);
    }
    var grantee_value = removeCommaSep($j('#'+compId+'_grantee').val());
    var granteeprev_value = removeCommaSep($j('#'+compId+'_granteeprev').val());
    if(grantee_value != ''){
        grantee_value = parseFloat(grantee_value);
    }else{
        grantee_value = parseFloat(granteeprev_value);
    }

    var granteeinkind_value = removeCommaSep($j('#'+compId+'_granteeinkind').val());
    var granteeinkindprev_value = removeCommaSep($j('#'+compId+'_granteeinkindprev').val());
    if(granteeinkind_value != ''){
        granteeinkind_value = parseFloat(granteeinkind_value);
    }else{
        granteeinkind_value = parseFloat(granteeinkindprev_value);
    }

    var cncsCompElement = compId+'_cncs';
    var granteeCompElement = compId+'_grantee';
    var granteeInkindCompElement = compId+'_granteeinkind';
    
    if(calFor == cncsCompElement){
        $j("#"+compId+'_grantee').val(addCommaSep(grantee_value.toFixed(2)));
        $j("#"+compId+'_granteeinkind').val(addCommaSep(granteeinkind_value.toFixed(2)));
    }else if(calFor == granteeCompElement){
        $j("#"+compId+'_cncs').val(addCommaSep(cncs_value.toFixed(2)));
        $j("#"+compId+'_granteeinkind').val(addCommaSep(granteeinkind_value.toFixed(2)));
    }else if(calFor == granteeInkindCompElement){
        $j("#"+compId+'_cncs').val(addCommaSep(cncs_value.toFixed(2)));
        $j("#"+compId+'_grantee').val(addCommaSep(grantee_value.toFixed(2)));
    }   

    totalofParentTotal = totalofParentTotal + cncs_value + grantee_value + granteeinkind_value;

    if(totalofParentTotal == removeCommaSep($j('#'+compId+'_totalprev').val())){
        $j('#'+compId+'_total').val(addCommaSep(totalofParentTotal.toFixed(2)));
        //$j(".trsimple_total_"+compId).hide();
        $j(".trsimple_total_"+compId+" input").css("color","black");
        $j("#trsimple-total"+displayCompCount+"_input").val(0);
        $j("#"+compId+"_changespan").show();
        $j(".changevaluesummary_"+compId).html('-');
        var calChangeValue = false;
    }else{
        $j('#'+compId+'_total').val(addCommaSep(totalofParentTotal.toFixed(2)));
        $j(".trsimple_total_"+compId).show();
        $j(".trsimple_total_"+compId+" input").css("color","#C70404");
        $j("#trsimple-total"+displayCompCount+"_input").val(1);
        $j("#"+compId+"_changespan").show();
        var calChangeValue = true;
    }

    if(calChangeValue){
        var cncsChangeValue = 0;
        var granteeChangeValue = 0;
        var granteeinkindChangeValue = 0;
        var totalChangeValue = 0;

        cncsprev_value = parseFloat(cncsprev_value);
        if(cncs_value > 0){
            cncsChangeValue =  cncs_value - cncsprev_value;
        }
        if(cncsprev_value > 0){
            var cncsChangePercent = (cncsChangeValue/cncsprev_value)*100;
        }else{
            var cncsChangePercent = cncsChangeValue;
        }
        if(cncsChangeValue > 0){
            $j("#changevaluesummarycncs_"+compId).html('+$'+addCommaSep(cncsChangeValue.toFixed(2)));
            if(cncsChangePercent.toFixed(2) == 0){
                $j("#changepercentsummarycncs_"+compId).html('('+cncsChangePercent.toFixed(2)+'%)');
            }else{
                $j("#changepercentsummarycncs_"+compId).html('(+'+cncsChangePercent.toFixed(2)+'%)');
            }  
        }else if(cncsChangeValue == 0){
            $j("#changevaluesummarycncs_"+compId).html('');
            $j("#changepercentsummarycncs_"+compId).html('');
        }else{
            $j("#changevaluesummarycncs_"+compId).html('-$'+addCommaSep(Math.abs(cncsChangeValue).toFixed(2)));
            if(cncsChangePercent.toFixed(2) == 0){
                $j("#changepercentsummarycncs_"+compId).html('('+Math.abs(cncsChangePercent).toFixed(2)+'%)');
            }else{
                $j("#changepercentsummarycncs_"+compId).html('(-'+Math.abs(cncsChangePercent).toFixed(2)+'%)');
            } 
        }
        granteeprev_value = parseFloat(granteeprev_value);
        if(grantee_value > 0){
            granteeChangeValue = grantee_value - granteeprev_value;
        }
        if(granteeprev_value > 0){
            var granteeChangePercent = (granteeChangeValue/granteeprev_value)*100;
        }else{
            var granteeChangePercent = granteeChangeValue;
        }
        if(granteeChangeValue > 0){
            $j("#changevaluesummarygrantee_"+compId).html('+$'+addCommaSep(granteeChangeValue.toFixed(2)));
            if(granteeChangePercent.toFixed(2) == 0){
                $j("#changepercentsummarygrantee_"+compId).html('('+granteeChangePercent.toFixed(2)+'%)');
            }else{
                $j("#changepercentsummarygrantee_"+compId).html('(+'+granteeChangePercent.toFixed(2)+'%)');
            } 
        }else if(granteeChangeValue == 0){
            $j("#changevaluesummarygrantee_"+compId).html('');
            $j("#changepercentsummarygrantee_"+compId).html('');
        }else{
            $j("#changevaluesummarygrantee_"+compId).html('-$'+addCommaSep(Math.abs(granteeChangeValue).toFixed(2)));
            if(granteeChangePercent.toFixed(2) == 0){
                $j("#changepercentsummarygrantee_"+compId).html('('+Math.abs(granteeChangePercent).toFixed(2)+'%)');
            }else{
                $j("#changepercentsummarygrantee_"+compId).html('(-'+Math.abs(granteeChangePercent).toFixed(2)+'%)');
            }
        }
        granteeinkindprev_value = parseFloat(granteeinkindprev_value);
        if(granteeinkind_value > 0){
            granteeinkindChangeValue =  granteeinkind_value - granteeinkindprev_value;
        }
        if(granteeinkindprev_value > 0){
            var granteeinkindChangePercent = (granteeinkindChangeValue/granteeinkindprev_value)*100;
        }else{
            var granteeinkindChangePercent = granteeinkindChangeValue;
        }
        if(granteeinkindChangeValue > 0){
            $j("#changevaluesummarygranteeinkind_"+compId).html('+$'+addCommaSep(granteeinkindChangeValue.toFixed(2)));
            if(granteeinkindChangePercent.toFixed(2) == 0){
                $j("#changepercentsummarygranteeinkind_"+compId).html('('+granteeinkindChangePercent.toFixed(2)+'%)');
            }else{
                $j("#changepercentsummarygranteeinkind_"+compId).html('(+'+granteeinkindChangePercent.toFixed(2)+'%)');
            }
        }else if(granteeinkindChangeValue == 0){
            $j("#changevaluesummarygranteeinkind_"+compId).html('');
            $j("#changepercentsummarygranteeinkind_"+compId).html('');
        }else{
            $j("#changevaluesummarygranteeinkind_"+compId).html('-$'+addCommaSep(Math.abs(granteeinkindChangeValue).toFixed(2)));
            if(granteeinkindChangePercent.toFixed(2) == 0){
                $j("#changepercentsummarygranteeinkind_"+compId).html('('+Math.abs(granteeinkindChangePercent).toFixed(2)+'%)');
            }else{
                $j("#changepercentsummarygranteeinkind_"+compId).html('(-'+Math.abs(granteeinkindChangePercent).toFixed(2)+'%)');
            }
        }

        totalprev_value = parseFloat(removeCommaSep($j('#'+compId+'_totalprev').val()));
        if(totalofParentTotal > 0){
            totalChangeValue =  totalofParentTotal - totalprev_value;
        }
        if(totalprev_value > 0){
            var totalChangePercent = (totalChangeValue/totalprev_value)*100;
        }else{
            var totalChangePercent = totalChangeValue;
        }
        if(totalChangeValue > 0){
            $j("#changevaluesummarytotal_"+compId).html('+$'+addCommaSep(totalChangeValue.toFixed(2)));
            if(totalChangePercent.toFixed(2) == 0){
                $j("#changepercentsummarytotal_"+compId).html('('+totalChangePercent.toFixed(2)+'%)');
            }else{
                $j("#changepercentsummarytotal_"+compId).html('(+'+totalChangePercent.toFixed(2)+'%)');
            }
        }else if(totalChangeValue == 0){
            $j("#changevaluesummarytotal_"+compId).html('');
            $j("#changepercentsummarytotal_"+compId).html('');
        }else{
            $j("#changevaluesummarytotal_"+compId).html('-$'+addCommaSep(Math.abs(totalChangeValue).toFixed(2)));
            if(totalChangePercent.toFixed(2) == 0){
                $j("#changepercentsummarytotal_"+compId).html('('+Math.abs(totalChangePercent).toFixed(2)+'%)');
            }else{
                $j("#changepercentsummarytotal_"+compId).html('(-'+Math.abs(totalChangePercent).toFixed(2)+'%)');
            }      
        }
    }
}

function claculateCombinedSection(section, contributedFor){
    var sectionCombinedCompId = $j("#"+section+'_combinedSection').val();
    var calculateFor = $j('#'+sectionCombinedCompId+'_'+contributedFor).attr('data-combinedcalcFor');
    var formula = $j('#'+sectionCombinedCompId+'_'+contributedFor).attr('data-combinedformula');
    var formulaSign = $j('#'+sectionCombinedCompId+'_'+contributedFor).attr('data-combinedformulaSign');
    var displayCompCount = $j("#"+calculateFor+'_'+contributedFor).attr('data-displaycount');

    if(formula != undefined && formula != ''){
        var formularArr = formula.split(',')
        var formulaSignArr = formulaSign.split(',')
        var sectionCombined = 0;
        var sectionCombinedTotal = 0;

        for(var i=0; i<formularArr.length; i++){
            var elementvalue = removeCommaSep($j('#'+formularArr[i]).val());
            if(elementvalue === ''){
                elementvalue = removeCommaSep($j('#'+formularArr[i]+'prev').val());
            }
            if(formulaSignArr[i] == '/'){
                sectionCombined = sectionCombined/parseFloat(elementvalue);
            }else if(formulaSignArr[i] == '*'){
                sectionCombined = sectionCombined*parseFloat(elementvalue);
            }else if(formulaSignArr[i] == '+'){
                sectionCombined = sectionCombined+parseFloat(elementvalue);
            }else if(formulaSignArr[i] == '-'){
                sectionCombined = sectionCombined-parseFloat(elementvalue);
            }       
        }
        
        $j('#'+calculateFor+'_'+contributedFor).val(addCommaSep(sectionCombined.toFixed(2)));

        var cncs_value = removeCommaSep($j('#'+calculateFor+'_cncs').val());
        var cncsprev_value = removeCommaSep($j('#'+calculateFor+'_cncsprev').val());
        if(cncs_value != ''){
            cncs_value = parseFloat(cncs_value);
        }else{
            if(cncsprev_value != ''){
                cncs_value = parseFloat(cncsprev_value);
            }else{
                cncs_value = 0;
            }
        }

        var grantee_value = removeCommaSep($j('#'+calculateFor+'_grantee').val());
        var granteeprev_value = removeCommaSep($j('#'+calculateFor+'_granteeprev').val());
        if(grantee_value != ''){
            grantee_value = parseFloat(grantee_value);
        }else{
            if(granteeprev_value != ''){
                grantee_value = parseFloat(granteeprev_value);
            }else{
                grantee_value = 0;
            }
        }

        var granteeinkind_value = removeCommaSep($j('#'+calculateFor+'_granteeinkind').val());
        var granteeinkindprev_value = removeCommaSep($j('#'+calculateFor+'_granteeinkindprev').val());
        if(granteeinkind_value != ''){
            granteeinkind_value = parseFloat(granteeinkind_value);
        }else{
            granteeinkind_value = parseFloat(granteeinkindprev_value);
        }
        
        if(contributedFor == 'cncs'){
            $j("#"+calculateFor+'_grantee').val(addCommaSep(grantee_value.toFixed(2)));
            $j("#"+calculateFor+'_granteeinkind').val(addCommaSep(granteeinkind_value.toFixed(2)));
        }else if(contributedFor == 'grantee'){
            $j("#"+calculateFor+'_cncs').val(addCommaSep(cncs_value.toFixed(2)));
            $j("#"+calculateFor+'_granteeinkind').val(addCommaSep(granteeinkind_value.toFixed(2)));
        }else if(contributedFor == 'granteeinkind'){
            $j("#"+calculateFor+'_cncs').val(addCommaSep(cncs_value.toFixed(2)));
            $j("#"+calculateFor+'_grantee').val(addCommaSep(grantee_value.toFixed(2)));
        } 

        sectionCombinedTotal = sectionCombinedTotal+ cncs_value +grantee_value+granteeinkind_value;
        //var existingTotalValue =  parseFloat($('#'+calculateFor+'_total').val());
   
        if(sectionCombinedTotal == removeCommaSep($j('#'+calculateFor+'_totalprev').val())){
            $j('#'+calculateFor+'_total').val(addCommaSep(sectionCombinedTotal.toFixed(2)));
            //$j(".trsimple_total_"+calculateFor).hide();
            $j(".trsimple_total_"+calculateFor+" input").css("color","black");
            $j("#trsimple-total"+displayCompCount+"_input").val(0);
            $j("#"+calculateFor+"_changespan").show();
            $j(".changevaluesummary_"+calculateFor).html('-');
            var calChangeValue = false;
        }else{
            $j('#'+calculateFor+'_total').val(addCommaSep(sectionCombinedTotal.toFixed(2)));
            $j(".trsimple_total_"+calculateFor).show();
            $j(".trsimple_total_"+calculateFor+" input").css("color","#C70404");
            $j("#trsimple-total"+displayCompCount+"_input").val(1);
            $j("#"+calculateFor+"_changespan").show();
            var calChangeValue = true;
        }

        calculateCombinedPercent(calculateFor,contributedFor);
 
        if(calChangeValue){
            var cncsChangeValue = 0;
            var granteeChangeValue = 0;
            var granteeinkindChangeValue = 0;
            var totalChangeValue = 0;

            cncsprev_value = parseFloat(cncsprev_value);
            if(cncs_value > 0){
                cncsChangeValue =  cncs_value - cncsprev_value;
            }
            if(cncsprev_value > 0){
                var cncsChangePercent = (cncsChangeValue/cncsprev_value)*100;
            }else{
                var cncsChangePercent = cncsChangeValue;
            }
            if(cncsChangeValue > 0){
                $j("#changevaluesummarycncs_"+calculateFor).html('+$'+addCommaSep(cncsChangeValue.toFixed(2)));
                if(cncsChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarycncs_"+calculateFor).html('('+cncsChangePercent.toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarycncs_"+calculateFor).html('(+'+cncsChangePercent.toFixed(2)+'%)');
                }  
            }else if(cncsChangeValue == 0){
                $j("#changevaluesummarycncs_"+calculateFor).html('');
                $j("#changepercentsummarycncs_"+calculateFor).html('');
            }else{
                $j("#changevaluesummarycncs_"+calculateFor).html('-$'+addCommaSep(Math.abs(cncsChangeValue).toFixed(2)));
                if(cncsChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarycncs_"+calculateFor).html('('+Math.abs(cncsChangePercent).toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarycncs_"+calculateFor).html('(-'+Math.abs(cncsChangePercent).toFixed(2)+'%)');
                } 
            }
            granteeprev_value = parseFloat(granteeprev_value);
            if(grantee_value > 0){
                granteeChangeValue = grantee_value - granteeprev_value;
            }
            if(granteeprev_value > 0){
                var granteeChangePercent = (granteeChangeValue/granteeprev_value)*100;
            }else{
                var granteeChangePercent = granteeChangeValue;
            }
            if(granteeChangeValue > 0){
                $j("#changevaluesummarygrantee_"+calculateFor).html('+$'+addCommaSep(granteeChangeValue.toFixed(2)));
                if(granteeChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarygrantee_"+calculateFor).html('('+granteeChangePercent.toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarygrantee_"+calculateFor).html('(+'+granteeChangePercent.toFixed(2)+'%)');
                } 
            }else if(granteeChangeValue == 0){
                $j("#changevaluesummarygrantee_"+calculateFor).html('');
                $j("#changepercentsummarygrantee_"+calculateFor).html('');
            }else{
                $j("#changevaluesummarygrantee_"+calculateFor).html('-$'+addCommaSep(Math.abs(granteeChangeValue).toFixed(2)));
                if(granteeChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarygrantee_"+calculateFor).html('('+Math.abs(granteeChangePercent).toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarygrantee_"+calculateFor).html('(-'+Math.abs(granteeChangePercent).toFixed(2)+'%)');
                } 
            }
            granteeinkindprev_value = parseFloat(granteeinkindprev_value);
            if(granteeinkind_value > 0){
                granteeinkindChangeValue =  granteeinkind_value - granteeinkindprev_value;
            }
            if(granteeinkindprev_value > 0){
                var granteeinkindChangePercent = (granteeinkindChangeValue/granteeinkindprev_value)*100;
            }else{
                var granteeinkindChangePercent = granteeinkindChangeValue;
            }
            if(granteeinkindChangeValue > 0){
                $j("#changevaluesummarygranteeinkind_"+calculateFor).html('+$'+addCommaSep(granteeinkindChangeValue.toFixed(2)));
                if(granteeinkindChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarygranteeinkind_"+calculateFor).html('('+granteeinkindChangePercent.toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarygranteeinkind_"+calculateFor).html('(+'+granteeinkindChangePercent.toFixed(2)+'%)');
                } 
            }else if(granteeinkindChangeValue == 0){
                $j("#changevaluesummarygranteeinkind_"+calculateFor).html('');
                $j("#changepercentsummarygranteeinkind_"+calculateFor).html('');
            }else{
                $j("#changevaluesummarygranteeinkind_"+calculateFor).html('-$'+addCommaSep(Math.abs(granteeinkindChangeValue).toFixed(2)));
                if(granteeinkindChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarygranteeinkind_"+calculateFor).html('('+Math.abs(granteeinkindChangePercent).toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarygranteeinkind_"+calculateFor).html('(-'+Math.abs(granteeinkindChangePercent).toFixed(2)+'%)');
                } 
            }

            totalprev_value = parseFloat(removeCommaSep($j('#'+calculateFor+'_totalprev').val()));
            if(sectionCombinedTotal > 0){
                totalChangeValue =  sectionCombinedTotal - totalprev_value;
            }
            if(totalprev_value > 0){
                var totalChangePercent = (totalChangeValue/totalprev_value)*100;
            }else{
                var totalChangePercent = totalChangeValue;
            }
            if(totalChangeValue > 0){
                $j("#changevaluesummarytotal_"+calculateFor).html('+$'+addCommaSep(totalChangeValue.toFixed(2)));
                if(totalChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarytotal_"+calculateFor).html('('+totalChangePercent.toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarytotal_"+calculateFor).html('(+'+totalChangePercent.toFixed(2)+'%)');
                } 
            }else if(totalChangeValue == 0){
                $j("#changevaluesummarytotal_"+calculateFor).html('');
                $j("#changepercentsummarytotal_"+calculateFor).html('');
            }else{
                $j("#changevaluesummarytotal_"+calculateFor).html('-$'+addCommaSep(Math.abs(totalChangeValue).toFixed(2)));
                if(totalChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarytotal_"+calculateFor).html('('+Math.abs(totalChangePercent).toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarytotal_"+calculateFor).html('(-'+Math.abs(totalChangePercent).toFixed(2)+'%)');
                } 
            }
        }
        calculateFinal(contributedFor);
        if(contributedFor == 'cncs'){
            calculateFinal('grantee');
        }
    }else{
        calculateFinal(contributedFor);
        if(contributedFor == 'cncs'){
            calculateFinal('grantee');
        }
    }
}

function calculateCombinedPercent(calculateForCompId,contributedFor){
    var targetCompId =  $j('#'+calculateForCompId+'_'+contributedFor).attr('data-combinedpercentTarget');
    var cncs = targetCompId+'_cncs';
    var grantee = targetCompId+'_grantee';
    var granteeinkind = targetCompId+'_granteeinkind';
    var calculateFor = $j("#"+targetCompId+'_'+contributedFor).attr('data-calcFor');
    var formula = $j('#'+targetCompId+'_'+contributedFor).attr('data-formula');
    var formulaSign = $j('#'+targetCompId+'_'+contributedFor).attr('data-formulaSign');
    var displayCompCount = $j("#"+targetCompId+'_'+contributedFor).attr('data-displaycount');

    var formularArr = formula.split(',')
    var formulaSignArr = formulaSign.split(',')

    var combinedpercent = 0;

    for(var i=0; i<formularArr.length; i++){
        var elementvalue = removeCommaSep($j('#'+formularArr[i]).val());
        if(elementvalue === ''){
            elementvalue = removeCommaSep($j('#'+formularArr[i]+'prev').val());
        }
        if(formulaSignArr[i] == '/'){
            combinedpercent = combinedpercent/parseFloat(elementvalue);
        }else if(formulaSignArr[i] == '*'){
            combinedpercent = combinedpercent*parseFloat(elementvalue);
        }else if(formulaSignArr[i] == '+'){
            combinedpercent = combinedpercent+parseFloat(elementvalue);
        }else if(formulaSignArr[i] == '-'){
            combinedpercent = combinedpercent-parseFloat(elementvalue);
        }       
    }

    var checkTotalChangeExists = $j("#trsimple-total"+displayCompCount+"_input").val();

    if(calculateFor == cncs){    
        //var granteePercent = Math.abs(100-combinedpercent);
        var remainingPercent = Math.abs(100-combinedpercent);
        if(remainingPercent > 0){
            var prevCompId = targetCompId - 1;
            var prevCompIdGrantee = removeCommaSep($j("#"+prevCompId+"_grantee").val());
            if(prevCompIdGrantee != ''){
                prevCompIdGrantee = parseFloat(prevCompIdGrantee);
            }else{
                prevCompIdGrantee = parseFloat(removeCommaSep($j("#"+prevCompId+"_granteeprev").val()));
            }
            var prevCompIdGranteeInKind = removeCommaSep($j("#"+prevCompId+"_granteeinkind").val());
            if(prevCompIdGranteeInKind != ''){
                prevCompIdGranteeInKind = parseFloat(prevCompIdGranteeInKind);
            }else{
                prevCompIdGranteeInKind = parseFloat(removeCommaSep($j("#"+prevCompId+"_granteeinkindprev").val()));
            }
            var totalValueRemaimingComps = prevCompIdGrantee + prevCompIdGranteeInKind;
            var granteePercent = parseFloat((prevCompIdGrantee/totalValueRemaimingComps)*remainingPercent);
            //granteePercent = Math.round(granteePercent);
            var granteeInkindPercent = Math.abs(remainingPercent-granteePercent);
        }else{
            var granteePercent = 0;
            var granteeInkindPercent = 0;
        }
        $j('#'+cncs).val(combinedpercent.toFixed(2));
        $j('#'+grantee).val(granteePercent.toFixed(2));
        $j("#"+granteeinkind).val(granteeInkindPercent.toFixed(2));
        if(parseFloat($j('#'+cncs+'prev').val()) == (combinedpercent).toFixed(2) && checkTotalChangeExists == 0){
            /*$j('#'+grantee).val('');
            $j('#'+cncs).val('');
            $j('#'+granteeinkind).val('');
            $j(".trsimple_percent_"+targetCompId).hide();*/
            $j(".trsimple_percent_"+targetCompId+" input").css("color","black");
            $j("#trsimple-percent"+displayCompCount+"_input").val(0);
        }else{
            $j(".trsimple_percent_"+targetCompId).show();
            $j(".trsimple_percent_"+targetCompId+" input").css("color","#C70404");
            $j("#trsimple-percent"+displayCompCount+"_input").val(1);
        }
    }else if(calculateFor == grantee){
        var remainingPercent = Math.abs(100-combinedpercent);
        if(remainingPercent > 0){
            var prevCompId = targetCompId - 1;
            var prevCompIdCncs = removeCommaSep($j("#"+prevCompId+"_cncs").val());
            if(prevCompIdCncs != ''){
                prevCompIdCncs = parseFloat(prevCompIdCncs);
            }else{
                prevCompIdCncs = parseFloat(removeCommaSep($j("#"+prevCompId+"_cncsprev").val()));
            }
            var prevCompIdGranteeInKind = removeCommaSep($j("#"+prevCompId+"_granteeinkind").val());
            if(prevCompIdGranteeInKind != ''){
                prevCompIdGranteeInKind = parseFloat(prevCompIdGranteeInKind);
            }else{
                prevCompIdGranteeInKind = parseFloat(removeCommaSep($j("#"+prevCompId+"_granteeinkindprev").val()));
            }
            var totalValueRemaimingComps = prevCompIdCncs + prevCompIdGranteeInKind;
            var cncsPercent = parseFloat((prevCompIdCncs/totalValueRemaimingComps)*remainingPercent);
            //cncsPercent = Math.round(cncsPercent);
            var granteeInkindPercent = Math.abs(remainingPercent-cncsPercent);
        }else{
            var cncsPercent = 0;
            var granteeInkindPercent = 0;
        }
        $j('#'+grantee).val(combinedpercent.toFixed(2));
        $j('#'+cncs).val(cncsPercent.toFixed(2));
        $j("#"+granteeinkind).val(granteeInkindPercent.toFixed(2));
        if(parseFloat($j('#'+grantee+'prev').val()) == (combinedpercent).toFixed(2) && checkTotalChangeExists == 0){
            /*$j('#'+grantee).val('');
            $j('#'+cncs).val('');
            $j('#'+granteeinkind).val('');
            $j(".trsimple_percent_"+targetCompId).hide();*/
            $j(".trsimple_percent_"+targetCompId+" input").css("color","black");
            $j("#trsimple-percent"+displayCompCount+"_input").val(0);
        }else{
            $j(".trsimple_percent_"+targetCompId).show();
            $j(".trsimple_percent_"+targetCompId+" input").css("color","#C70404");
            $j("#trsimple-percent"+displayCompCount+"_input").val(1);
        }
    }else if(calculateFor == granteeinkind){    
        var remainingPercent = Math.abs(100-combinedpercent);
        if(remainingPercent > 0){
            var prevCompId = targetCompId - 1;
            var prevCompIdCncs = removeCommaSep($j("#"+prevCompId+"_cncs").val());
            if(prevCompIdCncs != ''){
                prevCompIdCncs = parseFloat(prevCompIdCncs);
            }else{
                prevCompIdCncs = parseFloat(removeCommaSep($j("#"+prevCompId+"_cncsprev").val()));
            }
            var prevCompIdGrantee = removeCommaSep($j("#"+prevCompId+"_grantee").val());
            if(prevCompIdGrantee != ''){
                prevCompIdGrantee = parseFloat(prevCompIdGrantee);
            }else{
                prevCompIdGrantee = parseFloat(removeCommaSep($j("#"+prevCompId+"_granteeprev").val()));
            }
            var totalValueRemaimingComps = prevCompIdCncs + prevCompIdGrantee;
            var cncsPercent = parseFloat((prevCompIdCncs/totalValueRemaimingComps)*remainingPercent);
            //cncsPercent = Math.round(cncsPercent);
            var granteePercent = Math.abs(remainingPercent-cncsPercent);
        }else{
            var cncsPercent = 0;
            var granteePercent = 0;
        }
        $j("#"+granteeinkind).val(combinedpercent.toFixed(2));
        $j('#'+grantee).val(granteePercent.toFixed(2));
        $j('#'+cncs).val(cncsPercent.toFixed(2));
        if(parseFloat($j('#'+granteeinkind+'prev').val()) == (combinedpercent).toFixed(2) && checkTotalChangeExists == 0){
            /*$j('#'+grantee).val('');
            $j('#'+cncs).val('');
            $j('#'+granteeinkind).val('');
            $j(".trsimple_percent_"+targetCompId).hide();*/
            $j(".trsimple_percent_"+targetCompId+" input").css("color","black");
            $j("#trsimple-percent"+displayCompCount+"_input").val(0);
        }else{
            $j(".trsimple_percent_"+targetCompId).show();
            $j(".trsimple_percent_"+targetCompId+" input").css("color","#C70404");
            $j("#trsimple-percent"+displayCompCount+"_input").val(1);
        }
    }

}

function calculateFinal(contributedFor){
    var finalCompId = $j('#finalCompId').val();
    var section = $j('#'+finalCompId+'_'+contributedFor).attr('data-section');
    //var calculateFor = $('#'+finalCompId+'_'+contributedFor).attr('data-calcFor');
    var formula = $j('#'+finalCompId+'_'+contributedFor).attr('data-formula');
    var formulaSign = $j('#'+finalCompId+'_'+contributedFor).attr('data-formulaSign');
    var displayCompCount = $j("#"+finalCompId+'_'+contributedFor).attr('data-displaycount');
    var formularArr = formula.split(',')
    var formulaSignArr = formulaSign.split(',')

    var final = 0;
    var finalTotal = 0;

    for(var i=0; i<formularArr.length; i++){
        var elementvalue = removeCommaSep($j('#'+formularArr[i]).val());
        if(elementvalue == ''){
            elementvalue = removeCommaSep($j('#'+formularArr[i]+'prev').val());
        }
        if(formulaSignArr[i] == '/'){
            if(elementvalue != ''){
                final = final/parseFloat(elementvalue);
            }else{
                final = final;
            }
        }else if(formulaSignArr[i] == '*'){
            if(elementvalue != ''){
                final = final*parseFloat(elementvalue);
            }else{
                final = final;
            }
        }else if(formulaSignArr[i] == '+'){
            if(elementvalue != ''){
                final = final+parseFloat(elementvalue);
            }else{
                final = final;
            }
        }else if(formulaSignArr[i] == '-'){
            if(elementvalue != ''){
                final = final-parseFloat(elementvalue);
            }else{
                final = final;
            }
        }       
    }

    final = parseFloat(final.toFixed(2));
    if(contributedFor == 'granteeinkind'){
        var prevFinalForContributed = parseFloat(removeCommaSep($j('#'+finalCompId+'_granteeprev').val()));
        var differenceExists = final - (prevFinalForContributed);
        differenceExists = parseFloat(differenceExists.toFixed(2));
        if(Math.abs(differenceExists) < 0.03){
            if(differenceExists < 0){
                final = parseFloat((final) + (Math.abs(differenceExists)));
            }else{
                final = parseFloat((final) - (differenceExists));
            }
        }
        final = final.toFixed(2);

        $j('#'+finalCompId+'_grantee').val(addCommaSep(final));
    }else{
        var prevFinalForContributed = parseFloat(removeCommaSep($j('#'+finalCompId+'_'+contributedFor+'prev').val()));
        var differenceExists = final - (prevFinalForContributed);
        differenceExists = parseFloat(differenceExists.toFixed(2));
        if(Math.abs(differenceExists) < 0.03){
            if(differenceExists < 0){
                final = parseFloat(final + (Math.abs(differenceExists)));
            }else{
                final = parseFloat(final - (differenceExists));
            }
        }
        final = final.toFixed(2)
        
        $j('#'+finalCompId+'_'+contributedFor).val(addCommaSep(final));
    }

    var cncs_value = removeCommaSep($j('#'+finalCompId+'_cncs').val());
    var cncsprev_value = removeCommaSep($j('#'+finalCompId+'_cncsprev').val());
    if(cncs_value != ''){
        cncs_value = parseFloat(cncs_value);
    }else{
        if(cncsprev_value != ''){
            cncs_value = parseFloat(cncsprev_value);
        }else{
            cncs_value = 0;
        }
    }

    var grantee_value = removeCommaSep($j('#'+finalCompId+'_grantee').val());
    var granteeprev_value = removeCommaSep($j('#'+finalCompId+'_granteeprev').val());
    if(grantee_value != ''){
        grantee_value = parseFloat(grantee_value);
    }else{
        if(granteeprev_value != ''){
            grantee_value = parseFloat(granteeprev_value);
        }else{
            grantee_value = 0;
        }
    }

    var granteeinkind_value = 0;
    /*var granteeinkind_value = $j('#'+finalCompId+'_granteeinkind').val();
    var granteeinkindprev_value = $j('#'+finalCompId+'_granteeinkindprev').val();
    if(granteeinkind_value != ''){
        granteeinkind_value = parseFloat(granteeinkind_value);
    }else{
        granteeinkind_value = parseFloat(granteeinkindprev_value);
    }*/
    
    if(contributedFor == 'cncs'){
        $j("#"+finalCompId+'_grantee').val(addCommaSep(grantee_value.toFixed(2)));
        $j("#"+finalCompId+'_granteeinkind').val(addCommaSep(granteeinkind_value.toFixed(2)));
    }else if(contributedFor == 'grantee'){
        $j("#"+finalCompId+'_cncs').val(addCommaSep(cncs_value.toFixed(2)));
        $j("#"+finalCompId+'_granteeinkind').val(addCommaSep(granteeinkind_value.toFixed(2)));
    }else if(contributedFor == 'granteeinkind'){
        $j("#"+finalCompId+'_cncs').val(addCommaSep(cncs_value.toFixed(2)));
        $j("#"+finalCompId+'_grantee').val(addCommaSep(grantee_value.toFixed(2)));
    } 
    finalTotal = finalTotal+cncs_value+grantee_value+granteeinkind_value;
    //var existingTotalValue =  parseFloat($('#'+calculateFor+'_total').val());
    $j('#'+finalCompId+'_total').val(addCommaSep(finalTotal.toFixed(2)));

    calculateTotalPERMSY(contributedFor);

    if($j("#editedField").val() == 'cncs' && (cncs_value).toFixed(2) == removeCommaSep($j('#'+finalCompId+'_cncsprev').val())){
        $j(".input-grantee").attr('readonly', false);
        //$j(".input-grantee_Section3").attr('readonly', false);
        $j(".input-grantee").each(function(){ 
            if($j(this).hasClass('input-readonly')){
                $j(this).attr('readonly', true);
            }else{
                $j(this).attr('readonly', false);
            }
        });
        $j("#editedField").val('');
        $j(".reconcile-cncs").html('Locked Until Grantee Share is Balanced');
        $j(".reconcile-cncs-secIII").css("display","none");
        $j(".or-text-cncs").css("display","none");
        $j("#"+finalCompId+"_cncs_adjust").val('');
        
        if((grantee_value).toFixed(2) != $j('#'+finalCompId+'_granteeprev').val() || (granteeinkind_value).toFixed(2) != $j('#'+finalCompId+'_granteeinkindprev').val()){ 
            //This block of piece is used to have editedField set to grantee if cncs is reconciled
            //$j(".input-cncs").attr('readonly', true);
            //$j("#editedField").val('grantee');
            $j(".input-grantee").attr('readonly', false);
            $j(".input-cncs").attr('readonly', true);
            //$j(".input-grantee_Section3").attr('readonly', false);
            $j(".input-grantee").each(function(){ 
                if($j(this).hasClass('input-readonly')){
                    $j(this).attr('readonly', true);
                }else{
                    $j(this).attr('readonly', false);
                }
            });
            $j("#editedField").val('grantee');
            contributedFor = 'grantee';
        }
    }else if($j("#editedField").val() == 'grantee' && (grantee_value).toFixed(2) == removeCommaSep($j('#'+finalCompId+'_granteeprev').val()) && (granteeinkind_value).toFixed(2) == removeCommaSep($j('#'+finalCompId+'_granteeinkindprev').val())){
        $j(".input-cncs").attr('readonly', false);
        $j(".reconcile-cncs").html('-'); // cncs editable show should not show locked.
        //$j(".input-cncs_Section3").attr('readonly', false);
        $j(".input-cncs").each(function(){ 
            if($j(this).hasClass('input-readonly')){
                $j(this).attr('readonly', true);
            }else{
                $j(this).attr('readonly', false);
            }
        });
        $j("#editedField").val('');
        $j(".reconcile-grantee").html('Locked Until AmeriCorps Share is Balanced');
        $j(".reconcile-grantee-secIII").css("display","none");
        $j(".or-text-grantee").css("display","none");
        $j("#"+finalCompId+"_grantee_adjust").val('');
        if((cncs_value).toFixed(2) != removeCommaSep($j('#'+finalCompId+'_cncsprev').val())){
            $j(".input-grantee").attr('readonly', true);
            $j(".input-cncs").attr('readonly', false);
            //$j(".input-grantee_Section3").attr('readonly', false);
            $j(".input-cncs").each(function(){ 
                if($j(this).hasClass('input-readonly')){
                    $j(this).attr('readonly', true);
                }else{
                    $j(this).attr('readonly', false);
                }
            });
            $j("#editedField").val('cncs');
            contributedFor = 'cncs';
        }
    }else{ 
        if($j("#editedField").val() == 'cncs' && (cncs_value).toFixed(2) != removeCommaSep($j('#'+finalCompId+'_cncsprev').val())){
            /* Lock the grantee : Start */
            $j(".input-grantee").attr('readonly', true);
            $j(".reconcile-grantee").html('Locked Until AmeriCorps Share is Balanced');
            $j(".reconcile-grantee-secIII").css("display","none");
            $j(".or-text-grantee").css("display","none");
            /* Lock the grantee : End */

            /* UnLock the cncs : Start */
            $j(".input-cncs").attr('readonly', false);
            $j(".input-cncs").each(function(){ 
                if($j(this).hasClass('input-readonly')){
                    $j(this).attr('readonly', true);
                }else{
                    $j(this).attr('readonly', false);
                }
            });  
            /* UnLock the cncs : End */
        }else if($j("#editedField").val() == 'grantee' && ( (grantee_value).toFixed(2) != removeCommaSep($j('#'+finalCompId+'_granteeprev').val()) || (granteeinkind_value).toFixed(2) != removeCommaSep($j('#'+finalCompId+'_granteeinkindprev').val()) )){
            /* Lock the cncs : Start */
            $j(".input-cncs").attr('readonly', true);
            $j(".reconcile-cncs").html('Locked Until Grantee Share is Balanced');
            $j(".reconcile-cncs-secIII").css("display","none");
            $j(".or-text-cncs").css("display","none");
            /* Lock the cncs : End */

            /* UnLock the grantee : Start */
            $j(".input-grantee").attr('readonly', false);
            $j(".input-grantee").each(function(){ 
                if($j(this).hasClass('input-readonly')){
                    $j(this).attr('readonly', true);
                }else{
                    $j(this).attr('readonly', false);
                }
            }); 
            /* UnLock the grantee : End */
        }
    }

    if((finalTotal).toFixed(2) == removeCommaSep($j('#'+finalCompId+'_totalprev').val())){
        //$j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
        //$j(".trsimple_total_"+finalCompId).hide();
        $j(".trsimple_total_"+finalCompId+" input").css("color","black");
        $j("#trsimple-total"+displayCompCount+"_input").val(0);
        $j("#"+finalCompId+"_changespan").empty();
        $j("#"+finalCompId+"_changespan").append('TOTAL AS MODIFIED');
        $j("#"+finalCompId+"_changespan").show();
    
        if((grantee_value).toFixed(2) == removeCommaSep($j('#'+finalCompId+'_granteeprev').val()) && (granteeinkind_value).toFixed(2) == removeCommaSep($j('#'+finalCompId+'_granteeinkindprev').val())
            && (cncs_value).toFixed(2) == removeCommaSep($j('#'+finalCompId+'_cncsprev').val())){
            $j(".submit-button").attr("type", "submit");
            $j(".submit-button").removeClass("disabled");
            $j(".resubmit-button").attr("type", "submit");
            $j(".resubmit-button").removeClass("disabled");
            $j(".changevaluesummary_"+finalCompId).html('-');
            $j(".trsimple_total_Adjust_"+finalCompId).hide();
        }
        var calChangeValue = false;
    }else{
       // $j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
        $j(".trsimple_total_"+finalCompId).show();
        $j(".trsimple_total_"+finalCompId+" input").css("color","#C70404");
        $j("#trsimple-total"+displayCompCount+"_input").val(1);
        $j("#"+finalCompId+"_changespan").empty();
        //$j("#"+finalCompId+"_changespan").append('TOTAL AS MODIFIED <p style="color:red;font-style:italic;text-transform: none;font-size: 11px;">Difference to Reconcile</p>');
        $j("#"+finalCompId+"_changespan").append('TOTAL AS MODIFIED');
        $j("#"+finalCompId+"_changespan").show();
        $j(".submit-button").attr("type", "button");
        $j(".submit-button").addClass("disabled");
        $j(".resubmit-button").attr("type", "button");
        $j(".resubmit-button").addClass("disabled");
        $j(".trsimple_total_Adjust_"+finalCompId).show();
        var calChangeValue = true;
    }

    if(calChangeValue){
        var cncsChangeValue = 0;
        var granteeChangeValue = 0;
        var granteeinkindChangeValue = 0;
        var totalChangeValue = 0;

        cncsprev_value = parseFloat(cncsprev_value);
        if(cncs_value > 0){
            cncsChangeValue =  cncs_value - cncsprev_value;
        }
        if(cncsprev_value > 0){
            var cncsChangePercent = (cncsChangeValue/cncsprev_value)*100;
        }else{
            var cncsChangePercent = cncsChangeValue;
        }
        /*if(cncsChangeValue > 0){
            $j("#changevaluesummarycncs_"+finalCompId).html('+$'+cncsChangeValue.toFixed(2));
            $j("#changepercentsummarycncs_"+finalCompId).html('(+'+cncsChangePercent.toFixed(2)+'%)');
        }else if(cncsChangeValue == 0){
            $j("#changevaluesummarycncs_"+finalCompId).html('');
            $j("#changepercentsummarycncs_"+finalCompId).html('');
        }else{
            $j("#changevaluesummarycncs_"+finalCompId).html('-$'+Math.abs(cncsChangeValue.toFixed(2)));
            $j("#changepercentsummarycncs_"+finalCompId).html('(-'+Math.abs(cncsChangePercent.toFixed(2))+'%)');
        } FR-212*/
        granteeprev_value = parseFloat(granteeprev_value);
        if(grantee_value > 0){
            granteeChangeValue = grantee_value - granteeprev_value;
        }
        if(granteeprev_value > 0){
            var granteeChangePercent = (granteeChangeValue/granteeprev_value)*100;
        }else{
            var granteeChangePercent = granteeChangeValue;
        }
        /*if(granteeChangeValue > 0){
            $j("#changevaluesummarygrantee_"+finalCompId).html('+$'+granteeChangeValue.toFixed(2));
            $j("#changepercentsummarygrantee_"+finalCompId).html('(+'+granteeChangePercent.toFixed(2)+'%)');
        }else if(granteeChangeValue == 0){
            $j("#changevaluesummarygrantee_"+finalCompId).html('');
            $j("#changepercentsummarygrantee_"+finalCompId).html('');
        }else{
            $j("#changevaluesummarygrantee_"+finalCompId).html('-$'+Math.abs(granteeChangeValue.toFixed(2)));
            $j("#changepercentsummarygrantee_"+finalCompId).html('(-'+Math.abs(granteeChangePercent.toFixed(2))+'%)');
        } FR-212*/
        /*granteeinkindprev_value = parseFloat(granteeinkindprev_value);
        if(granteeinkind_value > 0){
            granteeinkindChangeValue =  granteeinkind_value - granteeinkindprev_value;
        }
        if(granteeinkindprev_value > 0){
            var granteeinkindChangePercent = (granteeinkindChangeValue/granteeinkindprev_value)*100;
        }else{
            var granteeinkindChangePercent = granteeinkindChangeValue;
        }
        if(granteeinkindChangeValue > 0){
            $j("#changevaluesummarygranteeinkind_"+finalCompId).html('+$'+granteeinkindChangeValue.toFixed(2));
            $j("#changepercentsummarygranteeinkind_"+finalCompId).html('(+'+granteeinkindChangePercent.toFixed(2)+'%)');
        }else if(granteeinkindChangeValue == 0){
            $j("#changevaluesummarygranteeinkind_"+finalCompId).html('');
            $j("#changepercentsummarygranteeinkind_"+finalCompId).html('');
        }else{
            $j("#changevaluesummarygranteeinkind_"+finalCompId).html('-$'+Math.abs(granteeinkindChangeValue.toFixed(2)));
            $j("#changepercentsummarygranteeinkind_"+finalCompId).html('(-'+Math.abs(granteeinkindChangePercent.toFixed(2))+'%)');
        }*/

        totalprev_value = parseFloat(removeCommaSep($j('#'+finalCompId+'_totalprev').val()));
        if(finalTotal > 0){
            totalChangeValue =  finalTotal - totalprev_value;
        }
        if(totalprev_value > 0){
            var totalChangePercent = (totalChangeValue/totalprev_value)*100;
        }else{
            var totalChangePercent = totalChangeValue;
        }
        /*if(totalChangeValue > 0){
            $j("#changevaluesummarytotal_"+finalCompId).html('+$'+totalChangeValue.toFixed(2));
            $j("#changepercentsummarytotal_"+finalCompId).html('(+'+totalChangePercent.toFixed(2)+'%)');
        }else if(totalChangeValue == 0){
            $j("#changevaluesummarytotal_"+finalCompId).html('');
            $j("#changepercentsummarytotal_"+finalCompId).html('');
        }else{
            $j("#changevaluesummarytotal_"+finalCompId).html('-$'+Math.abs(totalChangeValue.toFixed(2)));
            $j("#changepercentsummarytotal_"+finalCompId).html('(-'+Math.abs(totalChangePercent.toFixed(2))+'%)');
        } FR-212*/
    }
    calculatePercent(section, contributedFor);

    calculateSection1and3Percent();
    //if($j("#editedSection").val() != 'section3'){
        if(contributedFor == 'granteeinkind'){
            calculateExactAmountToReconcile('grantee')
        }else{
            calculateExactAmountToReconcile(contributedFor)
        }
    //}else{
     //   reconcileNeededSection3Change()
    //}
    percentChange();
    reasonToReconcile();
}

function calculateTotalPERMSY(contributedFor){
    var totalpermsycompId = $j('#totalpermsy').val(); //60
    var finaltotalcompId = $j('#finalTotal').val(); //58
    var displayCompCount = $j("#"+totalpermsycompId+'_cncs').attr('data-displaycount')
    if(contributedFor == 'granteeinkind'){
        contributedFor = 'grantee';
    }
    var formula = $j('#'+totalpermsycompId+'_'+contributedFor).attr('data-formula');
    var formulaSign = $j('#'+totalpermsycompId+'_'+contributedFor).attr('data-formulaSign');
    if(formula != '' && formula != undefined && formula != 'undefined'){
        var formularArr = formula.split(',')
        var formulaSignArr = formulaSign.split(',')

        var finalmsyperbudget = 0;
        var finalTotalmsyperbudget = 0;

        for(var i=0; i<formularArr.length; i++){
            var elmval = removeCommaSep($j('#'+formularArr[i]).val());
            if( elmval == "" ){
                elmval = removeCommaSep($j('#'+finaltotalcompId+'_cncsprev').val());
            }
            if(formulaSignArr[i] == '/'){
                if(elmval != '' && elmval != 0){ 
                    finalmsyperbudget = finalmsyperbudget/parseFloat(elmval);
                }else{
                    finalmsyperbudget = 0;
                }
            }else if(formulaSignArr[i] == '*'){
                finalmsyperbudget = finalmsyperbudget*parseFloat(elmval);
            }else if(formulaSignArr[i] == '+'){
                finalmsyperbudget = finalmsyperbudget+parseFloat(elmval);
            }else if(formulaSignArr[i] == '-'){
                finalmsyperbudget = finalmsyperbudget-parseFloat(elmval);
            }       
        }

        $j('#'+totalpermsycompId+'_'+contributedFor).val(addCommaSep(finalmsyperbudget.toFixed(2)));

        var cncs_value = removeCommaSep($j('#'+totalpermsycompId+'_cncs').val());
        if(cncs_value != ''){
            cncs_value = parseFloat(cncs_value);
        }else{
            var cncsprev_value = removeCommaSep($j('#'+totalpermsycompId+'_cncsprev').val());
            if(cncsprev_value != ''){
                cncs_value = parseFloat(cncsprev_value);
            }else{
                cncs_value = 0;
            }
        }

        var grantee_value = removeCommaSep($j('#'+totalpermsycompId+'_grantee').val());
        if(grantee_value != ''){
            grantee_value = parseFloat(grantee_value);
        }else{
            var granteeprev_value = removeCommaSep($j('#'+totalpermsycompId+'_granteeprev').val());
            if(granteeprev_value != ''){
                grantee_value = parseFloat(granteeprev_value);
            }else{
                grantee_value = 0;
            }
        }

        var granteeinkind_value = removeCommaSep($j('#'+totalpermsycompId+'_granteeinkind').val());
        if(granteeinkind_value != ''){
            granteeinkind_value = parseFloat(granteeinkind_value);
        }else{
            var granteeinkindprev_value = removeCommaSep($j('#'+totalpermsycompId+'_granteeinkindprev').val());
            granteeinkind_value = parseFloat(granteeinkindprev_value);
        }
        
        if(contributedFor == 'cncs'){
            $j("#"+totalpermsycompId+'_grantee').val(addCommaSep(grantee_value.toFixed(2)));
            $j("#"+totalpermsycompId+'_granteeinkind').val(addCommaSep(granteeinkind_value.toFixed(2)));
        }else if(contributedFor == 'grantee'){
            $j("#"+totalpermsycompId+'_cncs').val(addCommaSep(cncs_value.toFixed(2)));
            $j("#"+totalpermsycompId+'_granteeinkind').val(addCommaSep(granteeinkind_value.toFixed(2)));
        }else if(contributedFor == 'granteeinkind'){
            $j("#"+totalpermsycompId+'_cncs').val(addCommaSep(cncs_value.toFixed(2)));
            $j("#"+totalpermsycompId+'_grantee').val(addCommaSep(grantee_value.toFixed(2)));
        } 

        finalTotalmsyperbudget = finalTotalmsyperbudget+parseFloat(removeCommaSep($j('#'+totalpermsycompId+'_cncs').val()))+parseFloat(removeCommaSep($j('#'+totalpermsycompId+'_grantee').val()))+parseFloat(removeCommaSep($j('#'+totalpermsycompId+'_granteeinkind').val()));
        //var existingTotalValue =  parseFloat($('#'+calculateFor+'_total').val());
        
        $j('#'+totalpermsycompId+'_total').val(addCommaSep(finalTotalmsyperbudget.toFixed(2)));

        if(finalTotalmsyperbudget.toFixed(2) == removeCommaSep($j('#'+totalpermsycompId+'_totalprev').val())){
            //$j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
            //$j(".trsimple_total_"+finalCompId).hide();
            $j(".trsimple_total_"+totalpermsycompId+" input").css("color","black");
            $j("#trsimple-total"+displayCompCount+"_input").val(0);
            $j("#"+totalpermsycompId+"_changespan").html('AS MODIFIED');
            $j("#"+totalpermsycompId+"_changespan").show();
            $j(".changevaluesummary_"+totalpermsycompId).hide();
        }else{
        // $j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
            $j(".trsimple_total_"+totalpermsycompId).show();
            $j(".trsimple_total_"+totalpermsycompId+" input").css("color","#C70404");
            $j("#trsimple-total"+displayCompCount+"_input").val(1);
            $j("#"+totalpermsycompId+"_changespan").html('AS MODIFIED');
            $j("#"+totalpermsycompId+"_changespan").show();
            $j(".changevaluesummary_"+totalpermsycompId).hide();
        }
    }
}

function calculateTotalPERMSYPrev(contributedFor){
    var totalpermsycompId = $j('#totalpermsy').val();
    var displayCompCount = $j("#"+totalpermsycompId+'_cncs').attr('data-displaycount')
    var formula = $j('#'+totalpermsycompId+'_'+contributedFor).attr('data-formula');
    var formulaSign = $j('#'+totalpermsycompId+'_'+contributedFor).attr('data-formulaSign');
    if(formula != '' && formula != undefined && formula != 'undefined'){
        var formularArr = formula.split(',')
        var formulaSignArr = formulaSign.split(',')

        var finalmsyperbudget = 0;
        var finalTotalmsyperbudget = 0;

        for(var i=0; i<formularArr.length; i++){
            if(formularArr[i] != 'awardedmsy'){
                var elmval = removeCommaSep($j('#'+formularArr[i]+'prev').val());
            }else{
                var elmval = $j('#'+formularArr[i]).val();
            }
            if(formulaSignArr[i] == '/'){
                if(elmval != '' && elmval != 0){ 
                    finalmsyperbudget = finalmsyperbudget/parseFloat(elmval);
                }else{
                    finalmsyperbudget = 0;
                }
            }else if(formulaSignArr[i] == '*'){
                finalmsyperbudget = finalmsyperbudget*parseFloat(elmval);
            }else if(formulaSignArr[i] == '+'){
                finalmsyperbudget = finalmsyperbudget+parseFloat(elmval);
            }else if(formulaSignArr[i] == '-'){
                finalmsyperbudget = finalmsyperbudget-parseFloat(elmval);
            }       
        }

        $j('#'+totalpermsycompId+'_'+contributedFor+'prev').val(addCommaSep(finalmsyperbudget.toFixed(2)));

        var cncsprev_value = removeCommaSep($j('#'+totalpermsycompId+'_cncsprev').val());
        if(cncsprev_value != ''){
            cncs_value = parseFloat(cncsprev_value);
        }else{
            cncs_value = 0;
        }

        var granteeprev_value = removeCommaSep($j('#'+totalpermsycompId+'_granteeprev').val());
        if(granteeprev_value != ''){
            grantee_value = parseFloat(granteeprev_value);
        }else{
            grantee_value = 0;
        }

        var granteeinkindprev_value = removeCommaSep($j('#'+totalpermsycompId+'_granteeinkindprev').val());
        granteeinkind_value = parseFloat(granteeinkindprev_value);
        
        if(contributedFor == 'cncs'){
            $j("#"+totalpermsycompId+'_granteeprev').val(addCommaSep(grantee_value.toFixed(2)));
            $j("#"+totalpermsycompId+'_granteeinkindprev').val(addCommaSep(granteeinkind_value.toFixed(2)));
        }else if(contributedFor == 'grantee'){
            $j("#"+totalpermsycompId+'_cncsprev').val(addCommaSep(cncs_value.toFixed(2)));
            $j("#"+totalpermsycompId+'_granteeinkindprev').val(addCommaSep(granteeinkind_value.toFixed(2)));
        }else if(contributedFor == 'granteeinkind'){
            $j("#"+totalpermsycompId+'_cncsprev').val(addCommaSep(cncs_value.toFixed(2)));
            $j("#"+totalpermsycompId+'_granteeprev').val(addCommaSep(grantee_value.toFixed(2)));
        } 

        finalTotalmsyperbudget = finalTotalmsyperbudget+parseFloat(removeCommaSep($j('#'+totalpermsycompId+'_cncsprev').val()))+parseFloat(removeCommaSep($j('#'+totalpermsycompId+'_granteeprev').val()))+parseFloat(removeCommaSep($j('#'+totalpermsycompId+'_granteeinkindprev').val()));
        //var existingTotalValue =  parseFloat($('#'+calculateFor+'_total').val());
        $j('#'+totalpermsycompId+'_totalprev').val(addCommaSep(finalTotalmsyperbudget.toFixed(2)));

        if((finalTotalmsyperbudget).toFixed(2) == removeCommaSep($j('#'+totalpermsycompId+'_total').val())){
            //$j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
            //$j(".trsimple_total_"+finalCompId).hide();
            $j(".trsimple_total_"+totalpermsycompId+" input").css("color","black");
            $j("#trsimple-total"+displayCompCount+"_input").val(0);
        }else{
        // $j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
            $j(".trsimple_total_"+totalpermsycompId).show();
            $j(".trsimple_total_"+totalpermsycompId+" input").css("color","#C70404");
            $j("#trsimple-total"+displayCompCount+"_input").val(1);
        }
    }
}

/*function calculateSection1and3Percent(){
    var section1And3CompId = $j('#section1and3Percent').val();
    var contributeColumnArr = ['cncs','grantee','granteeinkind'];
    var displayCompCount = $j('#'+section1And3CompId+'_cncs').attr('data-displaycount');
    for(var j=0; j<contributeColumnArr.length; j++){
        var formula = $j('#'+section1And3CompId+'_'+contributeColumnArr[j]).attr('data-formula');
        var formulaSign = $j('#'+section1And3CompId+'_'+contributeColumnArr[j]).attr('data-formulaSign');
        if(formula != '' && formula != undefined && formula != 'undefined'){
            var formularArr = formula.split(',')
            var formulaSignArr = formulaSign.split(',')

            var section1And3Percent = 0;

            for(var i=0; i<formularArr.length; i++){
                var elmval = removeCommaSep($j('#'+formularArr[i]).val());
                if(elmval == '' && formularArr[i] != 'awardedmsy'){
                    elmval = removeCommaSep($j('#'+formularArr[i]+'prev').val());
                }

                if(formulaSignArr[i] == '/'){
                    if(elmval != '' && elmval != 0){ 
                        section1And3Percent = section1And3Percent/parseFloat(elmval);
                    }else{
                        section1And3Percent = 0;
                    }
                }else if(formulaSignArr[i] == '*'){
                    section1And3Percent = section1And3Percent*parseFloat(elmval);
                }else if(formulaSignArr[i] == '+'){
                    section1And3Percent = section1And3Percent+parseFloat(elmval);
                }else if(formulaSignArr[i] == '-'){
                    section1And3Percent = section1And3Percent-parseFloat(elmval);
                }       
            }

            $j('#'+section1And3CompId+'_'+contributeColumnArr[j]).val(section1And3Percent.toFixed(2));

            if(section1And3Percent.toFixed(2) == $j('#'+section1And3CompId+'_'+contributeColumnArr[j]+'prev').val()){
                $j(".trsimple_percent_"+section1And3CompId+" input").css("color","black");
                $j("#trsimple-percent"+displayCompCount+"_input").val(0);
            }else{
                $j(".trsimple_percent_"+section1And3CompId).show();
                $j(".trsimple_percent_"+section1And3CompId+" input").css("color","#C70404");
                $j("#trsimple-percent"+displayCompCount+"_input").val(1);
            }
        }
    }
}*/

function calculateSection1and3Percent(){
    var section1And3CompId = $j('#section1and3Percent').val();
    var contributeColumnArr = ['cncs','grantee','granteeinkind'];
    var displayCompCount = $j('#'+section1And3CompId+'_cncs').attr('data-displaycount');
    for(var j=0; j<contributeColumnArr.length; j++){
        var formula = "sec1and3Total,sec1and3Total_total,totalPercent";
        var formulaSign = "+,/,*";
        if(formula != '' && formula != undefined && formula != 'undefined'){
            var formularArr = formula.split(',')
            var formulaSignArr = formulaSign.split(',')

            //sec1and3Total
            var sec1TotalCompId = $j("#sec1Sub").val();
            var sec3TotalCompId = $j("#sec3Sub").val();
            var sec1Total = removeCommaSep($j('#'+sec1TotalCompId+'_'+contributeColumnArr[j]).val());
            var sec1Total_total = 0;
            if(sec1Total != undefined && sec1Total != '' && sec1Total != 'undefined'){
                sec1Total = parseFloat(sec1Total);
                sec1Total_total = removeCommaSep($j('#'+sec1TotalCompId+'_total').val());
                if(sec1Total_total != undefined && sec1Total_total != '' && sec1Total_total != 'undefined'){
                    sec1Total_total = parseFloat(sec1Total_total);
                }else{
                    sec1Total_total = 0;
                }
            }else{
                sec1Total = removeCommaSep($j('#'+sec1TotalCompId+'_'+contributeColumnArr[j]+'prev').val());
                if(sec1Total != undefined && sec1Total != '' && sec1Total != 'undefined'){
                    sec1Total = parseFloat(sec1Total);
                    sec1Total_total = parseFloat(removeCommaSep($j('#'+sec1TotalCompId+'_totalprev').val()));
                }else{
                    sec1Total = 0;
                }
            }

            var sec3Total = removeCommaSep($j('#'+sec3TotalCompId+'_'+contributeColumnArr[j]).val());
            var sec3Total_total = 0;
            if(sec3Total != undefined && sec3Total != '' && sec3Total != 'undefined'){
                sec3Total = parseFloat(sec3Total);
                sec3Total_total = removeCommaSep($j('#'+sec3TotalCompId+'_total').val());
                if(sec3Total_total != undefined && sec3Total_total != '' && sec3Total_total != 'undefined'){
                    sec3Total_total = parseFloat(sec3Total_total);
                }else{
                    sec3Total_total = 0;
                }
            }else{
                sec3Total = removeCommaSep($j('#'+sec3TotalCompId+'_'+contributeColumnArr[j]+'prev').val());
                if(sec3Total != undefined && sec3Total != '' && sec3Total != 'undefined'){
                    sec3Total = parseFloat(sec3Total);
                    sec3Total_total = parseFloat(removeCommaSep($j('#'+sec3TotalCompId+'_totalprev').val()));
                }else{
                    sec3Total = 0;
                }
            }

            var sec1and3Total = sec1Total + sec3Total;
            $j("#sec1and3Total").val(sec1and3Total);
            
            var sec1and3Total_total = sec1Total_total + sec3Total_total;
            $j("#sec1and3Total_total").val(sec1and3Total_total);

            var section1And3Percent = 0;

            for(var i=0; i<formularArr.length; i++){
                var elmval = removeCommaSep($j('#'+formularArr[i]).val());
                if(elmval == '' && formularArr[i] != 'awardedmsy'){
                    elmval = removeCommaSep($j('#'+formularArr[i]+'prev').val());
                }

                if(formulaSignArr[i] == '/'){
                    if(elmval != '' && elmval != 0){ 
                        section1And3Percent = section1And3Percent/parseFloat(elmval);
                    }else{
                        section1And3Percent = 0;
                    }
                }else if(formulaSignArr[i] == '*'){
                    section1And3Percent = section1And3Percent*parseFloat(elmval);
                }else if(formulaSignArr[i] == '+'){
                    section1And3Percent = section1And3Percent+parseFloat(elmval);
                }else if(formulaSignArr[i] == '-'){
                    section1And3Percent = section1And3Percent-parseFloat(elmval);
                }       
            }

            $j('#'+section1And3CompId+'_'+contributeColumnArr[j]).val(section1And3Percent.toFixed(2));

            if(section1And3Percent.toFixed(2) == $j('#'+section1And3CompId+'_'+contributeColumnArr[j]+'prev').val()){
                $j(".trsimple_percent_"+section1And3CompId+" input").css("color","black");
                $j("#trsimple-percent"+displayCompCount+"_input").val(0);
            }else{
                $j(".trsimple_percent_"+section1And3CompId).show();
                $j(".trsimple_percent_"+section1And3CompId+" input").css("color","#C70404");
                $j("#trsimple-percent"+displayCompCount+"_input").val(1);
            }
        }
    }
}

/*function calculateFinalPercent(section, contributedFor){
var sectionPercentCompId = $("#"+section+'_prcnt_comp_id').val();
var cncs = sectionPercentCompId+'_cncs';
var grantee = sectionPercentCompId+'_grantee';

var calculateFor = $("#"+sectionPercentCompId+'_'+contributedFor).attr('data-calcFor');
var formula = $('#'+sectionPercentCompId+'_'+contributedFor).attr('data-formula');
var formulaSign = $('#'+sectionPercentCompId+'_'+contributedFor).attr('data-formulaSign');
var formularArr = formula.split(',')
var formulaSignArr = formulaSign.split(',')

var percent = 0;

for(var i=0; i<formularArr.length; i++){
    if(formulaSignArr[i] == '/'){
        percent = percent/parseFloat($('#'+formularArr[i]).val());
    }else if(formulaSignArr[i] == '*'){
        percent = percent*parseFloat($('#'+formularArr[i]).val());
    }else if(formulaSignArr[i] == '+'){
        percent = percent+parseFloat($('#'+formularArr[i]).val());
    }else if(formulaSignArr[i] == '-'){
        percent = percent-parseFloat($('#'+formularArr[i]).val());
    }       
}

if(calculateFor == cncs){
    var granteePercent = Math.abs(100-percent);
    $('#'+grantee).val(granteePercent.toFixed(2));
    $('#'+cncs).val(percent.toFixed(2));
}else if(calculateFor == grantee){
    var cncsPercent = Math.abs(100-percent);
    $('#'+grantee).val(percent.toFixed(2));
    $('#'+cncs).val(cncsPercent.toFixed(2));
}
}*/

function calculatePercent(section, contributedFor){
    var sectionPercentCompId = $j("#"+section+'_prcnt_comp_id').val();
    var cncs = sectionPercentCompId+'_cncs';
    var grantee = sectionPercentCompId+'_grantee';
    var granteeinkind = sectionPercentCompId+'_granteeinkind';
    var displayCompCount = $j("#"+sectionPercentCompId+"_cncs").attr("data-displayCount");

    var calculateFor = $j("#"+sectionPercentCompId+'_'+contributedFor).attr('data-calcFor');
    var formula = $j('#'+sectionPercentCompId+'_'+contributedFor).attr('data-formula');
    var formulaSign = $j('#'+sectionPercentCompId+'_'+contributedFor).attr('data-formulaSign');
    var formularArr = formula.split(',')
    var formulaSignArr = formulaSign.split(',')
    
    var percent = 0;

    for(var i=0; i<formularArr.length; i++){
        var elementvalue = removeCommaSep($j('#'+formularArr[i]).val());
        if(elementvalue === ''){
            elementvalue = removeCommaSep($j('#'+formularArr[i]+'prev').val());
        }
        if(formulaSignArr[i] == '/'){
            if(elementvalue == 0){
                percent = 0;
            }else{
                percent = percent/parseFloat(elementvalue);
            }
        }else if(formulaSignArr[i] == '*'){
            percent = percent*parseFloat(elementvalue);
        }else if(formulaSignArr[i] == '+'){
            percent = percent+parseFloat(elementvalue);
        }else if(formulaSignArr[i] == '-'){
            percent = percent-parseFloat(elementvalue);
        }       
    }
    //percent = percent.toFixed(2);

    var prevCompId = sectionPercentCompId - 1;

    var checkTotalChangeExists = $j("#trsimple-total"+displayCompCount+"_input").val();
    
    if(calculateFor == cncs){
        var remainingPercent = Math.abs(100-percent);
        if(remainingPercent > 0){
            var prevCompIdGrantee = removeCommaSep($j("#"+prevCompId+"_grantee").val());
            if(prevCompIdGrantee != ''){
                prevCompIdGrantee = parseFloat(prevCompIdGrantee);
            }else{
                prevCompIdGrantee = parseFloat(removeCommaSep($j("#"+prevCompId+"_granteeprev").val()));
            }
            var prevCompIdGranteeInKind = removeCommaSep($j("#"+prevCompId+"_granteeinkind").val());
            if(prevCompIdGranteeInKind != ''){
                prevCompIdGranteeInKind = parseFloat(prevCompIdGranteeInKind);
            }else{
                prevCompIdGranteeInKind = parseFloat(removeCommaSep($j("#"+prevCompId+"_granteeinkindprev").val()));
            }
            var totalValueRemaimingComps = prevCompIdGrantee + prevCompIdGranteeInKind;
            if(totalValueRemaimingComps > 0){
                var granteePercent = parseFloat((prevCompIdGrantee/totalValueRemaimingComps)*remainingPercent);
                var granteeInkindPercent = Math.abs(remainingPercent-granteePercent);
            }else{
                var granteePercent = 0;
                var granteeInkindPercent = 0;
            }
            
            //granteePercent = Math.round(granteePercent);       
        }else{
            var granteePercent = 0;
            var granteeInkindPercent = 0;
        }
        $j('#'+cncs).val(percent.toFixed(2));
        $j('#'+grantee).val(granteePercent.toFixed(2));
        $j("#"+granteeinkind).val(granteeInkindPercent.toFixed(2));
        if(parseFloat($j('#'+cncs+'prev').val()) == percent.toFixed(2) && checkTotalChangeExists == 0){
            //$j('#'+grantee).val('');
            //$j('#'+cncs).val('');
            //$j('#'+granteeinkind).val('');
            //$j(".trsimple_percent_"+sectionPercentCompId).hide();
            $j(".trsimple_percent_"+sectionPercentCompId+" input").css("color","black");
            $j("#trsimple-percent"+displayCompCount+"_input").val(0);
        }else{
            $j(".trsimple_percent_"+sectionPercentCompId).show();
            $j(".trsimple_percent_"+sectionPercentCompId+" input").css("color","#C70404");
            $j("#trsimple-percent"+displayCompCount+"_input").val(1);
        }
    }else if(calculateFor == grantee){  
        var remainingPercent = Math.abs(100-percent);
        if(remainingPercent > 0){
            var prevCompIdCncs = removeCommaSep($j("#"+prevCompId+"_cncs").val());
            if(prevCompIdCncs != ''){
                prevCompIdCncs = parseFloat(prevCompIdCncs);
            }else{
                prevCompIdCncs = parseFloat(removeCommaSep($j("#"+prevCompId+"_cncsprev").val()));
            }
            var prevCompIdGranteeInKind = removeCommaSep($j("#"+prevCompId+"_granteeinkind").val());
            if(prevCompIdGranteeInKind != ''){
                prevCompIdGranteeInKind = parseFloat(prevCompIdGranteeInKind);
            }else{
                prevCompIdGranteeInKind = parseFloat(removeCommaSep($j("#"+prevCompId+"_granteeinkindprev").val()));
            }
            
            var totalValueRemaimingComps = prevCompIdCncs + prevCompIdGranteeInKind;

            if(totalValueRemaimingComps > 0){
                var cncsPercent = parseFloat((prevCompIdCncs/totalValueRemaimingComps)*remainingPercent);
                var granteeInkindPercent = Math.abs(remainingPercent-cncsPercent);
            }else{
                var cncsPercent = 0;
                var granteeInkindPercent = 0;
            }

            //cncsPercent = Math.round(cncsPercent);
        }else{
            var cncsPercent = 0;
            var granteeInkindPercent = 0;
        }
        $j('#'+grantee).val(percent.toFixed(2));
        $j('#'+cncs).val(cncsPercent.toFixed(2));
        $j("#"+granteeinkind).val(granteeInkindPercent.toFixed(2));
        if(parseFloat($j('#'+grantee+'prev').val()) == percent.toFixed(2) && checkTotalChangeExists == 0){
            /* $j('#'+grantee).val('');
            $j('#'+cncs).val('');
            $j('#'+granteeinkind).val('');
            $j(".trsimple_percent_"+sectionPercentCompId).hide();*/
            $j(".trsimple_percent_"+sectionPercentCompId+" input").css("color","black");
            $j("#trsimple-percent"+displayCompCount+"_input").val(0);
        }else{
            $j(".trsimple_percent_"+sectionPercentCompId).show();
            $j(".trsimple_percent_"+sectionPercentCompId+" input").css("color","#C70404");
            $j("#trsimple-percent"+displayCompCount+"_input").val(1);
        }
    }else if(calculateFor == granteeinkind){
        var remainingPercent = Math.abs(100-percent);
        if(remainingPercent > 0){
            var prevCompIdCncs = removeCommaSep($j("#"+prevCompId+"_cncs").val());
            if(prevCompIdCncs != ''){
                prevCompIdCncs = parseFloat(prevCompIdCncs);
            }else{
                prevCompIdCncs = parseFloat(removeCommaSep($j("#"+prevCompId+"_cncsprev").val()));
            }
            var prevCompIdGrantee = removeCommaSep($j("#"+prevCompId+"_grantee").val());
            if(prevCompIdGrantee != ''){
                prevCompIdGrantee = parseFloat(prevCompIdGrantee);
            }else{
                prevCompIdGrantee = parseFloat(removeCommaSep($j("#"+prevCompId+"_granteeprev").val()));
            }
            var totalValueRemaimingComps = prevCompIdCncs + prevCompIdGrantee;
            if(totalValueRemaimingComps > 0){
                var cncsPercent = parseFloat((prevCompIdCncs/totalValueRemaimingComps)*remainingPercent);
                var granteePercent = Math.abs(remainingPercent-cncsPercent);
            }else{
                var cncsPercent = 0;
                var granteePercent = 0;
            }
            //cncsPercent = Math.round(cncsPercent);
        }else{
            var cncsPercent = 0;
            var granteePercent = 0;
        }
        $j("#"+granteeinkind).val(percent.toFixed(2));
        $j('#'+grantee).val(granteePercent.toFixed(2));
        $j('#'+cncs).val(cncsPercent.toFixed(2));
        if(parseFloat($j('#'+granteeinkind+'prev').val()) == percent.toFixed(2) && checkTotalChangeExists == 0){
            /*$j('#'+grantee).val('');
            $j('#'+cncs).val('');
            $j('#'+granteeinkind).val('');
            $j(".trsimple_percent_"+sectionPercentCompId).hide();*/
            $j(".trsimple_percent_"+sectionPercentCompId+" input").css("color","black");
            $j("#trsimple-percent"+displayCompCount+"_input").val(0);
        }else{
            $j(".trsimple_percent_"+sectionPercentCompId).show();
            $j(".trsimple_percent_"+sectionPercentCompId+" input").css("color","#C70404");
            $j("#trsimple-percent"+displayCompCount+"_input").val(1);
        }
    }
} 


function calculateChangePercent(compId, totalChangePercent, totalValue, prevTotalValue, totalNewValue, totalLineChange, contributedFor, value, prevValue){
    var budgetThresholdValue = $j("#BudgetModificationApprovalThreshold").val();
    if(totalChangePercent == ''){
        totalChangePercent = 0;
    }else{
        totalChangePercent = parseFloat(totalChangePercent);
    }
    
    if(totalValue === ''){
        totalValue = prevTotalValue;
    }

    if(totalValue != prevTotalValue || value != prevValue){
        $j(".componenttrchange_"+compId).addClass("tr-simple");
        $j(".componenttrchange_"+compId).show();
        $j("#"+compId+"_change_text").attr('data-requiredInput','1');
        if(totalNewValue == ''){
            if(totalValue == 0 && prevTotalValue ==0){
                var TchangeValue = 0;
            }else{
                var TchangeValue = totalValue - prevTotalValue;
            }
            if(prevTotalValue > 0){
                var TchanagePercent = (TchangeValue/prevTotalValue)*100;
                if(totalValue < prevTotalValue){
                    totalChangePercent += ((prevTotalValue - totalValue)/prevTotalValue)*100;
                }else{
                    totalChangePercent += ((totalValue - prevTotalValue)/prevTotalValue)*100;
                }
            }else{
                var TchanagePercent = TchangeValue;
                totalChangePercent += totalValue;
            }
            totalLineChange = totalLineChange + 1;
            $j("#totalLineChange").val(totalLineChange);
            $j("#"+compId+"_rowdatamodification").val(1);
        }else{
            var totalNewChangePercent = 0;
            if(prevTotalValue > 0){
                if(totalNewValue < prevTotalValue){
                    totalNewChangePercent += ((prevTotalValue - totalNewValue)/prevTotalValue)*100;
                }else{
                    totalNewChangePercent += ((totalNewValue - prevTotalValue)/prevTotalValue)*100;
                }
            }else{
                totalNewChangePercent += totalNewValue;
            }
            totalChangePercent = totalChangePercent - totalNewChangePercent;
            if(totalValue == 0 && prevTotalValue == 0){
                var TchangeValue = 0;
            }else{
                var TchangeValue = totalValue - prevTotalValue;
            }
            if(prevTotalValue > 0){
                var TchanagePercent = (TchangeValue/prevTotalValue)*100;
                if(totalValue < prevTotalValue){
                    totalChangePercent += ((prevTotalValue - totalValue)/prevTotalValue)*100;
                }else{
                    totalChangePercent += ((totalValue - prevTotalValue)/prevTotalValue)*100;
                }
            }else{
                var TchanagePercent = TchangeValue;
                totalChangePercent += totalValue;
            }
        }

        if(value == 0 && prevValue ==0){
            var changeValue = 0;
        }else{
            var changeValue = value - prevValue;
        }
        
        if(prevValue > 0){
            var changeValuePercent = (changeValue/prevValue)*100;
        }else{
            var changeValuePercent = changeValue;
        }

        if(contributedFor == 'cncs'){
            if(changeValue > 0){
                $j("."+compId+"_cncs_change_value").html('+$'+addCommaSep(changeValue.toFixed(2)));
                if(changeValuePercent.toFixed(2) == 0){
                    $j("."+compId+"_cncs_change_percent").html('('+changeValuePercent.toFixed(2)+'%)');
                }else{
                    $j("."+compId+"_cncs_change_percent").html('(+'+changeValuePercent.toFixed(2)+'%)');
                }
            }else if(changeValue == 0){
                $j("."+compId+"_cncs_change_value").html('$'+addCommaSep(changeValue.toFixed(2)));
                $j("."+compId+"_cncs_change_percent").html('('+changeValuePercent.toFixed(2)+'%)');
            }else{
                $j("."+compId+"_cncs_change_value").html('-$'+addCommaSep(Math.abs(changeValue).toFixed(2)));
                if(changeValuePercent.toFixed(2) == 0){
                    $j("."+compId+"_cncs_change_percent").html('('+Math.abs(changeValuePercent).toFixed(2)+'%)');
                }else{
                    $j("."+compId+"_cncs_change_percent").html('(-'+Math.abs(changeValuePercent).toFixed(2)+'%)');
                }
            }
        }else if(contributedFor == 'grantee'){
            if(changeValue > 0){
                $j("."+compId+"_grantee_change_value").html('+$'+addCommaSep(changeValue.toFixed(2)));
                if(changeValuePercent.toFixed(2) == 0){
                    $j("."+compId+"_grantee_change_percent").html('('+changeValuePercent.toFixed(2)+'%)');
                }else{
                    $j("."+compId+"_grantee_change_percent").html('(+'+changeValuePercent.toFixed(2)+'%)');
                }
            }else if(changeValue == 0){
                $j("."+compId+"_grantee_change_value").html('$'+addCommaSep(changeValue.toFixed(2)));
                $j("."+compId+"_grantee_change_percent").html('('+changeValuePercent.toFixed(2)+'%)');
            }else{
                $j("."+compId+"_grantee_change_value").html('-$'+addCommaSep(Math.abs(changeValue).toFixed(2)));
                if(changeValuePercent.toFixed(2) == 0){
                    $j("."+compId+"_grantee_change_percent").html('('+Math.abs(changeValuePercent).toFixed(2)+'%)');
                }else{
                    $j("."+compId+"_grantee_change_percent").html('(-'+Math.abs(changeValuePercent).toFixed(2)+'%)');
                }
            }
        }else if(contributedFor == 'granteeinkind'){
            if(changeValue > 0){
                $j("."+compId+"_granteeinkind_change_value").html('+$'+addCommaSep(changeValue.toFixed(2)));
                if(changeValuePercent.toFixed(2) == 0){
                    $j("."+compId+"_granteeinkind_change_percent").html('('+changeValuePercent.toFixed(2)+'%)');
                }else{
                    $j("."+compId+"_granteeinkind_change_percent").html('(+'+changeValuePercent.toFixed(2)+'%)');
                }
            }else if(changeValue == 0){
                $j("."+compId+"_granteeinkind_change_value").html('$'+addCommaSep(changeValue.toFixed(2)));
                $j("."+compId+"_granteeinkind_change_percent").html('('+changeValuePercent.toFixed(2)+'%)');
            }else{
                $j("."+compId+"_granteeinkind_change_value").html('-$'+addCommaSep(Math.abs(changeValue).toFixed(2)));
                if(changeValuePercent.toFixed(2) == 0){
                    $j("."+compId+"_granteeinkind_change_percent").html('('+Math.abs(changeValuePercent).toFixed(2)+'%)');
                }else{
                    $j("."+compId+"_granteeinkind_change_percent").html('(-'+Math.abs(changeValuePercent).toFixed(2)+'%)');
                }
            }
        }

        if(TchangeValue > 0){
            $j("."+compId+"_total_change_value").html('+$'+addCommaSep(TchangeValue.toFixed(2)));
            if(TchanagePercent.toFixed(2) == 0){
                $j("."+compId+"_total_change_percent").html('('+TchanagePercent.toFixed(2)+'%)');
            }else{
                $j("."+compId+"_total_change_percent").html('(+'+TchanagePercent.toFixed(2)+'%)');
            }
        }else if(TchangeValue == 0){
            $j("."+compId+"_total_change_value").html('$'+addCommaSep(TchangeValue.toFixed(2)));
            $j("."+compId+"_total_change_percent").html('('+TchanagePercent.toFixed(2)+'%)');
        }else{
            $j("."+compId+"_total_change_value").html('-$'+addCommaSep(Math.abs(TchangeValue).toFixed(2)));
            if(TchanagePercent.toFixed(2) == 0){
                $j("."+compId+"_total_change_percent").html('('+Math.abs(TchanagePercent).toFixed(2)+'%)');
            }else{
                $j("."+compId+"_total_change_percent").html('(-'+Math.abs(TchanagePercent).toFixed(2)+'%)');
            }         
        }

        if(budgetThresholdValue != 'Never Require Approval'){
            /*FR-303if((Math.abs(TchanagePercent)).toFixed(2) >= parseFloat(budgetThresholdValue)){
                $j("#"+compId+"_cncs").css({"color": "#C77C04", "font-weight": "bold"});
                $j("#"+compId+"_grantee").css({"color": "#C77C04", "font-weight": "bold"});
                $j("#"+compId+"_granteeinkind").css({"color": "#C77C04", "font-weight": "bold"});
                $j("#"+compId+"_total").css({"color": "black", "font-weight": "bold"});
                $j("#"+compId+"_changeimg").show();   
            }else{*/
                $j("#"+compId+"_cncs").css({"color": "black", "font-weight": "bold"});
                $j("#"+compId+"_grantee").css({"color": "black", "font-weight": "bold"});
                $j("#"+compId+"_granteeinkind").css({"color": "black", "font-weight": "bold"});
                $j("#"+compId+"_total").css({"color": "black", "font-weight": "bold"});
                $j("#"+compId+"_changeimg").hide();  
            //}
        }
             
        $j('#'+compId+'_total').val(addCommaSep(totalValue.toFixed(2)));
        $j("#"+compId+"_totalnew").val(addCommaSep(totalValue.toFixed(2)));
        $j("#totalChangePercent").val(totalChangePercent.toFixed(2));
        
    }else{
        $j("#"+compId+"_cncs").css("color","black");
        $j("#"+compId+"_grantee").css("color","black");
        $j("#"+compId+"_granteeinkind").css("color","black");
        $j("#"+compId+"_total").css("color","black");
        $j(".componenttrchange_"+compId).removeClass("tr-simple");
        $j(".componenttrchange_"+compId).hide();
        $j("#"+compId+"_change_text").attr('data-requiredInput','0');
        var totalNewChangePercent = 0;
        if(prevTotalValue > 0){
            if(totalNewValue != ''){
                if(totalNewValue < prevTotalValue){
                    totalNewChangePercent += ((prevTotalValue - totalNewValue)/prevTotalValue)*100;
                }else if(totalNewValue > prevTotalValue){
                    totalNewChangePercent += ((totalNewValue - prevTotalValue)/prevTotalValue)*100;
                }
            }
        }else{
            totalNewChangePercent += totalNewValue;
        }
        totalChangePercent = totalChangePercent - totalNewChangePercent;  
        
        if(value == prevValue){
            if(contributedFor == 'cncs'){
                $j("."+compId+"_change_cncs").html('');
            }else if (contributedFor == 'grantee'){
                $j("."+compId+"_change_grantee").html('');
            }else if (contributedFor == 'granteeinkind'){
                $j("."+compId+"_change_granteeinkind").html('');
            }
        }

        $j("#"+compId+"_cncs").val('');
        $j("#"+compId+"_grantee").val('');
        $j("#"+compId+"_granteeinkind").val('');
        $j("#"+compId+"_total").val('');

        $j("#"+compId+"_changeimg").hide();

        $j("."+compId+"_change_total").html('');
        $j("#"+compId+"_totalnew").val('');
        $j("#totalChangePercent").val(totalChangePercent.toFixed(2));
        totalLineChange = totalLineChange-1;
        $j("#totalLineChange").val(totalLineChange);
        $j("#"+compId+"_rowdatamodification").val(0);

        var inputChangedSection = $j('#'+compId+"_"+contributedFor).attr('data-section');
        if((inputChangedSection in componentChangedStruct)){
            if(componentChangedStruct[inputChangedSection].length){
                var changedTo = '';             
                var isChildInput = $j("#"+compId+"_"+contributedFor).attr("data-inputtype");
                if(isChildInput != undefined && isChildInput == 'child'){
                    var changedComp = $j("#"+compId+"_"+contributedFor).attr("data-parentCompId");
                    changedComp = parseFloat(changedComp);
                    componentChangedStruct[inputChangedSection] = $j.grep(componentChangedStruct[inputChangedSection], function(value) {
                        return value != changedComp;
                    });
                }else{
                    componentChangedStruct[inputChangedSection] = $j.grep(componentChangedStruct[inputChangedSection], function(value) {
                        return value != compId;
                    });
                }


                /*componentChangedStruct[inputChangedSection] = $j.grep(componentChangedStruct[inputChangedSection], function(value) {
                    return value != compId;
                });*/
                var sectionArr = componentChangedStruct[inputChangedSection];
                sectionArr = sectionArr.sort();
                sectionArr = sectionArr.sort(function(a, b){return a - b});	
                if(sectionArr.length){
                    for(var i=0; i<sectionArr.length; i++){
                        if(changedTo != ''){
                            changedTo = changedTo + ', ' + $j("#componentText_"+sectionArr[i]).val();
                        }else{
                            changedTo = '<span style="width:115px;">Changes made to:</span> <span style="width:88%;">'+$j("#componentText_"+sectionArr[i]).val();
                        }
                    }
                }
                $j("#changesmadeto"+inputChangedSection).html(changedTo + '</span>');
            }else{
                $j("#changesmadeto"+inputChangedSection).html('');
            }
        }
    }

    if(totalLineChange > 0){
        var finalComp = $("#finalCompId").val();
        if(removeCommaSep($j("#"+finalComp+'_total').val()) == removeCommaSep($j("#"+finalComp+'_totalprev').val())){
            var budgetThreshold = totalChangePercent/totalLineChange;
            $j(".submit-button").attr("type", "submit");
            $j(".submit-button").removeClass("disabled");
            $j(".resubmit-button").attr("type", "submit");
            $j(".resubmit-button").removeClass("disabled");
        }else{
            var budgetThreshold = totalChangePercent/totalLineChange;
            $j(".submit-button").attr("type", "button");
            $j(".submit-button").addClass("disabled");
            $j(".resubmit-button").attr("type", "button");
            $j(".resubmit-button").addClass("disabled");
        }
    }else{
        var budgetThreshold = 0;
        $j(".submit-button").attr("type", "button");
        $j(".submit-button").addClass("disabled");
        $j(".resubmit-button").attr("type", "button");
        $j(".resubmit-button").addClass("disabled");
    }
    
    /*FR-303if(budgetThresholdValue != 'Never Require Approval'){
        if(budgetThreshold >= parseFloat(budgetThresholdValue)){
            $j(".budget-threshold").show();
            $j("#budgetThresholdExceeded").val(1);
        }else{
            $j(".budget-threshold").hide();
            $j("#budgetThresholdExceeded").val(0);
        }
    }*/
}

function addBudgetIncrese(BudgetInccontributedFor,inputBudgetIncValue){
    var sec1and2Comp = $j("#sec1and2").val();
    var finalComp = $j("#finalTotal").val();
    var displayCompCount = $j("#sec1and2").attr("data-displayCount");
    var displayCompCountFinal = $j("#finalTotal").attr("data-displayCount");

    var cncsIncreased = removeCommaSep($j("#budgetIncreasecncs").val());
    if(cncsIncreased == '' || cncsIncreased == undefined || cncsIncreased == 'undefined'){
        cncsIncreased = 0;
    }
    var granteeIncreased = removeCommaSep($j("#budgetIncreasegrantee").val());
    if(granteeIncreased == '' || granteeIncreased == undefined || granteeIncreased == 'undefined'){
        granteeIncreased = 0;
    }
    var granteeInkindIncreased = removeCommaSep($j("#budgetIncreasegranteeinkind").val());
    if(granteeInkindIncreased == '' || granteeInkindIncreased == undefined || granteeInkindIncreased == 'undefined'){
        granteeInkindIncreased = 0;
    }
    var totalIncreased = removeCommaSep($j("#budgetIncreasetotal").val());
    if(totalIncreased == '' || totalIncreased == undefined || totalIncreased == 'undefined'){
        totalIncreased = 0;
    }
    var increaseTotal = parseFloat(totalIncreased)+parseFloat(cncsIncreased)+parseFloat(granteeIncreased)+parseFloat(granteeInkindIncreased);
    if(increaseTotal > 0){
        $j("#budgetIncreaseTotal").val(addCommaSep(increaseTotal.toFixed(2)));
    }else{
        $j("#budgetIncreaseTotal").val(addCommaSep(increaseTotal.toFixed(2)));
    }
    if(removeCommaSep(inputBudgetIncValue) == ''){
        var inputBudgetIncValuePrev = parseFloat(removeCommaSep($j("#budgetIncrease"+BudgetInccontributedFor+"_prev").val()));
        if(inputBudgetIncValuePrev != 0){
            var contributedForsec1and2SubTotal = parseFloat(removeCommaSep($j("#"+sec1and2Comp+"_"+BudgetInccontributedFor+"prev").val()));
            contributedForsec1and2SubTotal = contributedForsec1and2SubTotal - parseFloat(inputBudgetIncValuePrev);
            $j("#"+sec1and2Comp+"_"+BudgetInccontributedFor+"prev").val(addCommaSep(contributedForsec1and2SubTotal.toFixed(2)));
            if(BudgetInccontributedFor == 'cncs'){
                var totalSec1And2 = contributedForsec1and2SubTotal + parseFloat(removeCommaSep($j("#"+sec1and2Comp+"_granteeprev").val())) + parseFloat(removeCommaSep($j("#"+sec1and2Comp+"_granteeinkindprev").val()))
                $j("#"+sec1and2Comp+"_totalprev").val(addCommaSep(totalSec1And2.toFixed(2)));

                if(removeCommaSep($j('#'+sec1and2Comp+'_total').val()) == (totalSec1And2).toFixed(2)){
                    //$j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                    //$j(".trsimple_total_"+finalCompId).hide();
                    $j(".trsimple_total_"+sec1and2Comp+" input").css("color","black");
                    $j("#trsimple-total"+displayCompCount+"_input").val(0);
                    $j(".changevaluesummary_"+sec1and2Comp).html('-');
                    var calChangeValue = false;
                }else{
                   // $j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                    $j(".trsimple_total_"+sec1and2Comp).show();
                    $j(".trsimple_total_"+sec1and2Comp+" input").css("color","#C70404");
                    $j("#trsimple-total"+displayCompCount+"_input").val(1);
                    var calChangeValue = true;
                } 

                //percent
                if(totalSec1And2 > 0){
                    var percentVal = (contributedForsec1and2SubTotal/totalSec1And2)*100;
                }else{
                    var percentVal = 0;
                }

                var remainingPercent = Math.abs(100-percentVal);
                if(remainingPercent > 0){
                    var percentCompId = parseFloat(sec1and2Comp)+1;
                    var prevCompIdGrantee = parseFloat(removeCommaSep($j("#"+percentCompId+"_granteeprev").val()));
                    var prevCompIdGranteeInKind = parseFloat(removeCommaSep($j("#"+percentCompId+"_granteeinkindprev").val()));
                    var totalValueRemaimingComps = prevCompIdGrantee + prevCompIdGranteeInKind;
                    var granteePercent = parseFloat((prevCompIdGrantee/totalValueRemaimingComps)*remainingPercent);
                    //granteePercent = Math.round(granteePercent);
                    var granteeInkindPercent = Math.abs(remainingPercent-granteePercent);
                }else{
                    var granteePercent = 0;
                    var granteeInkindPercent = 0;
                }
                $j("#"+percentCompId+"_cncsprev").val(percentVal.toFixed(2));
                $j("#"+percentCompId+"_granteeprev").val(granteePercent.toFixed(2));
                $j("#"+percentCompId+"_granteeinkindprev").val(granteeInkindPercent.toFixed(2));

                var checkTotalChangeExists = $j("#trsimple-total"+displayCompCount+"_input").val();
            
                if($j('#'+percentCompId+'_cncs').val() == (percentVal).toFixed(2) && checkTotalChangeExists == 0){
                    $j(".trsimple_percent_"+percentCompId+" input").css("color","black");
                    $j("#trsimple-percent"+displayCompCount+"_input").val(0);
                }else{
                    $j(".trsimple_percent_"+percentCompId+" input").css("color","#C70404");
                    $j(".trsimple_percent_"+percentCompId).show();
                    $j("#trsimple-percent"+displayCompCount+"_input").val(1);
                }
            }else if(BudgetInccontributedFor == 'grantee'){
                var totalSec1And2 = contributedForsec1and2SubTotal + parseFloat(removeCommaSep($j("#"+sec1and2Comp+"_cncsprev").val())) + parseFloat(removeCommaSep($j("#"+sec1and2Comp+"_granteeinkindprev").val()))
                $j("#"+sec1and2Comp+"_totalprev").val(addCommaSep(totalSec1And2.toFixed(2)));

                if(removeCommaSep($j('#'+sec1and2Comp+'_total').val()) == (totalSec1And2).toFixed(2)){
                    //$j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                    //$j(".trsimple_total_"+finalCompId).hide();
                    $j(".trsimple_total_"+sec1and2Comp+" input").css("color","black");
                    $j("#trsimple-total"+displayCompCount+"_input").val(0);
                    $j(".changevaluesummary_"+sec1and2Comp).html('-');
                    var calChangeValue = false;
                }else{
                   // $j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                    $j(".trsimple_total_"+sec1and2Comp).show();
                    $j(".trsimple_total_"+sec1and2Comp+" input").css("color","#C70404");
                    $j("#trsimple-total"+displayCompCount+"_input").val(1);
                    var calChangeValue = true;
                }

                //percent
                if(totalSec1And2 > 0){
                    var percentVal = (contributedForsec1and2SubTotal/totalSec1And2)*100;
                }else{
                    var percentVal = 0;
                }
                var remainingPercent = Math.abs(100-percentVal);
                if(remainingPercent > 0){
                    var percentCompId = parseFloat(sec1and2Comp)+1;
                    var prevCompIdCncs = parseFloat(removeCommaSep($j("#"+percentCompId+"_cncsprev").val()));
                    var prevCompIdGranteeInKind = parseFloat(removeCommaSep($j("#"+percentCompId+"_granteeinkindprev").val()));
                    var totalValueRemaimingComps = prevCompIdCncs + prevCompIdGranteeInKind;
                    var cncsPercent = parseFloat((prevCompIdCncs/totalValueRemaimingComps)*remainingPercent);
                    //granteePercent = Math.round(granteePercent);
                    var granteeInkindPercent = Math.abs(remainingPercent-cncsPercent);
                }else{
                    var cncsPercent = 0;
                    var granteeInkindPercent = 0;
                }

                $j("#"+percentCompId+"_cncsprev").val(cncsPercent.toFixed(2));
                $j("#"+percentCompId+"_granteeprev").val(percentVal.toFixed(2));
                $j("#"+percentCompId+"_granteeinkindprev").val(granteeInkindPercent.toFixed(2));

                var checkTotalChangeExists = $j("#trsimple-total"+displayCompCount+"_input").val();
            
                if($j('#'+percentCompId+'_grantee').val() == (percentVal).toFixed(2) && checkTotalChangeExists == 0){
                    $j(".trsimple_percent_"+percentCompId+" input").css("color","black");
                    $j("#trsimple-percent"+displayCompCount+"_input").val(0);
                }else{
                    $j(".trsimple_percent_"+percentCompId+" input").css("color","#C70404");
                    $j(".trsimple_percent_"+percentCompId).show();
                    $j("#trsimple-percent"+displayCompCount+"_input").val(1);
                }
            }else if(BudgetInccontributedFor == 'granteeinkind'){
                var totalSec1And2 = contributedForsec1and2SubTotal + parseFloat(removeCommaSep($j("#"+sec1and2Comp+"_granteeprev").val())) + parseFloat(removeCommaSep($j("#"+sec1and2Comp+"_cncsprev").val()))
                $j("#"+sec1and2Comp+"_totalprev").val(addCommaSep(totalSec1And2.toFixed(2)));

                if(removeCommaSep($j('#'+sec1and2Comp+'_total').val()) == (totalSec1And2).toFixed(2)){
                    //$j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                    //$j(".trsimple_total_"+finalCompId).hide();
                    $j(".trsimple_total_"+sec1and2Comp+" input").css("color","black");
                    $j("#trsimple-total"+displayCompCount+"_input").val(0);
                    $j(".changevaluesummary_"+sec1and2Comp).html('-');
                    var calChangeValue = false;
                }else{
                   // $j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                    $j(".trsimple_total_"+sec1and2Comp).show();
                    $j(".trsimple_total_"+sec1and2Comp+" input").css("color","#C70404");
                    $j("#trsimple-total"+displayCompCount+"_input").val(1);
                    var calChangeValue = true;
                }

                //percent
                if(totalSec1And2 > 0){
                    var percentVal = (contributedForsec1and2SubTotal/totalSec1And2)*100;
                }else{
                    var percentVal = 0;
                }
                var remainingPercent = Math.abs(100-percentVal);
                if(remainingPercent > 0){
                    var percentCompId = parseFloat(sec1and2Comp)+1;
                    var prevCompIdCncs = parseFloat(removeCommaSep($j("#"+percentCompId+"_cncsprev").val()));
                    var prevCompIdGrantee = parseFloat(removeCommaSep($j("#"+percentCompId+"_granteeprev").val()));
                    var totalValueRemaimingComps = prevCompIdCncs + prevCompIdGrantee;
                    var cncsPercent = parseFloat((prevCompIdCncs/totalValueRemaimingComps)*remainingPercent);
                    //granteePercent = Math.round(granteePercent);
                    var granteePercent = Math.abs(remainingPercent-cncsPercent);
                }else{
                    var cncsPercent = 0;
                    var granteePercent = 0;
                }

                $j("#"+percentCompId+"_cncsprev").val(cncsPercent.toFixed(2));
                $j("#"+percentCompId+"_granteeprev").val(granteePercent.toFixed(2));
                $j("#"+percentCompId+"_granteeinkindprev").val(percentVal.toFixed(2));

                var checkTotalChangeExists = $j("#trsimple-total"+displayCompCount+"_input").val();
            
                if($j('#'+percentCompId+'_granteeinkind').val() == (percentVal).toFixed(2) && checkTotalChangeExists == 0){
                    $j(".trsimple_percent_"+percentCompId+" input").css("color","black");
                    $j("#trsimple-percent"+displayCompCount+"_input").val(0);
                }else{
                    $j(".trsimple_percent_"+percentCompId+" input").css("color","#C70404");
                    $j(".trsimple_percent_"+percentCompId).show();
                    $j("#trsimple-percent"+displayCompCount+"_input").val(1);
                }
            }

            if(calChangeValue){
                var cncsChangeValue = 0;
                var granteeChangeValue = 0;
                var granteeinkindChangeValue = 0;
                var totalChangeValue = 0;
                
                var cncs_value = removeCommaSep($j('#'+sec1and2Comp+'_cncs').val());
                var cncsprev_value = removeCommaSep($j('#'+sec1and2Comp+'_cncsprev').val());
                if(cncs_value != ''){
                    cncs_value = parseFloat(cncs_value);
                }else{
                    if(cncsprev_value != ''){
                        cncs_value = parseFloat(cncsprev_value);
                    }else{
                        cncs_value = 0;
                    }
                }
                if(cncs_value > 0){
                    cncsChangeValue =  cncs_value - cncsprev_value;
                }
                if(cncsprev_value > 0){
                    var cncsChangePercent = (cncsChangeValue/cncsprev_value)*100;
                }else{
                    var cncsChangePercent = cncsChangeValue;
                }
                if(cncsChangeValue > 0){
                    $j("#changevaluesummarycncs_"+sec1and2Comp).html('+$'+addCommaSep(cncsChangeValue.toFixed(2)));
                    if(cncsChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarycncs_"+sec1and2Comp).html('('+cncsChangePercent.toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarycncs_"+sec1and2Comp).html('(+'+cncsChangePercent.toFixed(2)+'%)');
                    }
                }else if(cncsChangeValue == 0){
                    $j("#changevaluesummarycncs_"+sec1and2Comp).html('');
                    $j("#changepercentsummarycncs_"+sec1and2Comp).html('');
                }else{
                    $j("#changevaluesummarycncs_"+sec1and2Comp).html('-$'+addCommaSep(Math.abs(cncsChangeValue).toFixed(2)));
                    if(cncsChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarycncs_"+sec1and2Comp).html('('+Math.abs(cncsChangePercent).toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarycncs_"+sec1and2Comp).html('(-'+Math.abs(cncsChangePercent).toFixed(2)+'%)');
                    }
                }

                var grantee_value = removeCommaSep($j('#'+sec1and2Comp+'_grantee').val());
                var granteeprev_value = removeCommaSep($j('#'+sec1and2Comp+'_granteeprev').val());
                if(grantee_value != ''){
                    grantee_value = parseFloat(grantee_value);
                }else{
                    if(granteeprev_value != ''){
                        grantee_value = parseFloat(granteeprev_value);
                    }else{
                        grantee_value = 0;
                    }
                }
                if(grantee_value > 0){
                    granteeChangeValue = grantee_value - granteeprev_value;
                }
                if(granteeprev_value > 0){
                    var granteeChangePercent = (granteeChangeValue/granteeprev_value)*100;
                }else{
                    var granteeChangePercent = granteeChangeValue;
                }
                if(granteeChangeValue > 0){
                    $j("#changevaluesummarygrantee_"+sec1and2Comp).html('+$'+addCommaSep(granteeChangeValue.toFixed(2)));
                    if(granteeChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarygrantee_"+sec1and2Comp).html('('+granteeChangePercent.toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarygrantee_"+sec1and2Comp).html('(+'+granteeChangePercent.toFixed(2)+'%)');
                    }
                }else if(granteeChangeValue == 0){
                    $j("#changevaluesummarygrantee_"+sec1and2Comp).html('');
                    $j("#changepercentsummarygrantee_"+sec1and2Comp).html('');
                }else{
                    $j("#changevaluesummarygrantee_"+sec1and2Comp).html('-$'+addCommaSep(Math.abs(granteeChangeValue).toFixed(2)));
                    if(granteeChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarygrantee_"+sec1and2Comp).html('('+Math.abs(granteeChangePercent).toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarygrantee_"+sec1and2Comp).html('(-'+Math.abs(granteeChangePercent).toFixed(2)+'%)');
                    }         
                }

                var granteeinkind_value = removeCommaSep($j('#'+sec1and2Comp+'_granteeinkind').val());
                var granteeinkindprev_value = removeCommaSep($j('#'+sec1and2Comp+'_granteeinkindprev').val());
                if(granteeinkind_value != ''){
                    granteeinkind_value = parseFloat(granteeinkind_value);
                }else{
                    if(granteeinkindprev_value != ''){
                        granteeinkind_value = parseFloat(granteeinkindprev_value);
                    }else{
                        granteeinkind_value = 0;
                    }
                }
                if(granteeinkind_value > 0){
                    granteeinkindChangeValue =  granteeinkind_value - granteeinkindprev_value;
                }
                if(granteeinkindprev_value > 0){
                    var granteeinkindChangePercent = (granteeinkindChangeValue/granteeinkindprev_value)*100;
                }else{
                    var granteeinkindChangePercent = granteeinkindChangeValue;
                }
                if(granteeinkindChangeValue > 0){
                    $j("#changevaluesummarygranteeinkind_"+sec1and2Comp).html('+$'+addCommaSep(granteeinkindChangeValue.toFixed(2)));
                    if(granteeinkindChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarygranteeinkind_"+sec1and2Comp).html('('+granteeinkindChangePercent.toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarygranteeinkind_"+sec1and2Comp).html('(+'+granteeinkindChangePercent.toFixed(2)+'%)');
                    }  
                }else if(granteeinkindChangeValue == 0){
                    $j("#changevaluesummarygranteeinkind_"+sec1and2Comp).html('');
                    $j("#changepercentsummarygranteeinkind_"+sec1and2Comp).html('');
                }else{
                    $j("#changevaluesummarygranteeinkind_"+sec1and2Comp).html('-$'+addCommaSep(Math.abs(granteeinkindChangeValue).toFixed(2)));
                    if(granteeinkindChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarygranteeinkind_"+sec1and2Comp).html('('+Math.abs(granteeinkindChangePercent).toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarygranteeinkind_"+sec1and2Comp).html('(-'+Math.abs(granteeinkindChangePercent).toFixed(2)+'%)');
                    }             
                }

                var total_value = removeCommaSep($j('#'+sec1and2Comp+'_total').val());
                var totalprev_value = removeCommaSep($j('#'+sec1and2Comp+'_totalprev').val());
                if(total_value != ''){
                    total_value = parseFloat(total_value);
                }else{
                    if(totalprev_value != ''){
                        total_value = parseFloat(totalprev_value);
                    }else{
                        total_value = 0;
                    }
                }
                if(total_value > 0){
                    totalChangeValue =  total_value - totalprev_value;
                }
                if(totalprev_value > 0){
                    var totalChangePercent = (totalChangeValue/totalprev_value)*100;
                }else{
                    var totalChangePercent = totalChangeValue;
                }
                if(totalChangeValue > 0){
                    $j("#changevaluesummarytotal_"+sec1and2Comp).html('+$'+addCommaSep(totalChangeValue.toFixed(2)));
                    if(totalChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarytotal_"+sec1and2Comp).html('('+totalChangePercent.toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarytotal_"+sec1and2Comp).html('(+'+totalChangePercent.toFixed(2)+'%)');
                    } 
                }else if(totalChangeValue == 0){
                    $j("#changevaluesummarytotal_"+sec1and2Comp).html('');
                    $j("#changepercentsummarytotal_"+sec1and2Comp).html('');
                }else{
                    $j("#changevaluesummarytotal_"+sec1and2Comp).html('-$'+addCommaSep(Math.abs(totalChangeValue).toFixed(2)));
                    if(totalChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarytotal_"+sec1and2Comp).html('('+Math.abs(totalChangePercent).toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarytotal_"+sec1and2Comp).html('(-'+Math.abs(totalChangePercent).toFixed(2)+'%)');
                    } 
                }
            } 

    
            //total
            if(BudgetInccontributedFor == 'granteeinkind'){
                var BudgetInccontributed = 'grantee';
                var contributedForFinalTotal = parseFloat(removeCommaSep($j("#"+finalComp+"_"+BudgetInccontributed+"prev").val()));
                contributedForFinalTotal = contributedForFinalTotal - parseFloat(inputBudgetIncValuePrev);
                $j("#"+finalComp+"_"+BudgetInccontributed+"prev").val(addCommaSep(contributedForFinalTotal.toFixed(2)));
            }else{
                var BudgetInccontributed = BudgetInccontributedFor;
                var contributedForFinalTotal = parseFloat(removeCommaSep($j("#"+finalComp+"_"+BudgetInccontributedFor+"prev").val()));
                contributedForFinalTotal = contributedForFinalTotal - parseFloat(inputBudgetIncValuePrev);
                $j("#"+finalComp+"_"+BudgetInccontributedFor+"prev").val(addCommaSep(contributedForFinalTotal.toFixed(2)));
            }

            if(BudgetInccontributedFor == 'cncs'){
                var totalFinal = contributedForFinalTotal + parseFloat(removeCommaSep($j("#"+finalComp+"_granteeprev").val())) + parseFloat(removeCommaSep($j("#"+finalComp+"_granteeinkindprev").val()))
                $j("#"+finalComp+"_totalprev").val(addCommaSep(totalFinal.toFixed(2)));

                var cncsTotal = removeCommaSep($j('#'+finalComp+'_cncs').val());
                if($j("#editedField").val() == 'cncs' && cncsTotal ==  removeCommaSep($j('#'+finalComp+'_cncsprev').val())){
                    $j(".input-grantee").attr('readonly', false);
                    //$j(".input-grantee_Section3").attr('readonly', false);
                    $j(".input-grantee").each(function(){ 
                        if($j(this).hasClass('input-readonly')){
                            $j(this).attr('readonly', true);
                        }else{
                            $j(this).attr('readonly', false);
                        }
                    });
                    $j("#editedField").val('');
                    $j(".reconcile-cncs").html('-');
                    $j(".reconcile-cncs-secIII").css("display","none");
                    $j(".or-text-cncs").css("display","none");
                }

                if(removeCommaSep($j('#'+finalComp+'_total').val()) == (totalFinal).toFixed(2)){
                    //$j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                    //$j(".trsimple_total_"+finalCompId).hide();
                    $j(".trsimple_total_"+finalComp+" input").css("color","black");
                    $j("#trsimple-total"+displayCompCountFinal+"_input").val(0);
                    $j(".submit-button").attr("type", "submit");
                    $j(".submit-button").removeClass("disabled");
                    $j(".resubmit-button").attr("type", "submit");
                    $j(".resubmit-button").removeClass("disabled");
                    $j("#"+finalComp+"_changespan").empty();
                    $j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED');
                    $j(".changevaluesummary_"+finalComp).html('-');
                    var calChangeValue = false;
                }else{
                // $j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                    $j(".trsimple_total_"+finalComp).show();
                    $j(".trsimple_total_"+finalComp+" input").css("color","#C70404");
                    $j("#trsimple-total"+displayCompCountFinal+"_input").val(1);
                    $j(".submit-button").attr("type", "button");
                    $j(".submit-button").addClass("disabled");
                    $j(".resubmit-button").attr("type", "button");
                    $j(".resubmit-button").addClass("disabled");
                    $j("#"+finalComp+"_changespan").empty();
                    $j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED');
                    //$j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED <p style="color:red;font-style:italic;text-transform: none;font-size: 11px;">Difference to Reconcile</p>'); FR-212
                    var calChangeValue = true;
                }  

                //percent
                if(totalFinal > 0){
                    var percentVal = (contributedForFinalTotal/totalFinal)*100;
                }else{
                    var percentVal = 0;
                }

                var remainingPercent = Math.abs(100-percentVal);
                if(remainingPercent > 0){
                    var percentCompIdFinal = parseFloat(finalComp)+1;
                    var prevCompIdGrantee = parseFloat($j("#"+percentCompIdFinal+"_granteeprev").val());
                    var prevCompIdGranteeInKind = parseFloat($j("#"+percentCompIdFinal+"_granteeinkindprev").val());
                    var totalValueRemaimingComps = prevCompIdGrantee + prevCompIdGranteeInKind;
                    var granteePercent = parseFloat((prevCompIdGrantee/totalValueRemaimingComps)*remainingPercent);
                    //granteePercent = Math.round(granteePercent);
                    var granteeInkindPercent = Math.abs(remainingPercent-granteePercent);
                }else{
                    var granteePercent = 0;
                    var granteeInkindPercent = 0;
                }
                $j("#"+percentCompIdFinal+"_cncsprev").val(percentVal.toFixed(2));
                $j("#"+percentCompIdFinal+"_granteeprev").val(granteePercent.toFixed(2));
                $j("#"+percentCompIdFinal+"_granteeinkindprev").val(granteeInkindPercent.toFixed(2));

                var checkTotalChangeExists = $j("#trsimple-total"+displayCompCountFinal+"_input").val();

                if($j('#'+percentCompIdFinal+'_cncs').val() == (percentVal).toFixed(2) && checkTotalChangeExists == 0){
                    $j(".trsimple_percent_"+percentCompIdFinal+" input").css("color","black");
                    $j("#trsimple-percent"+displayCompCountFinal+"_input").val(0);
                }else{
                    $j(".trsimple_percent_"+percentCompIdFinal+" input").css("color","#C70404");
                    $j(".trsimple_percent_"+percentCompIdFinal).show();
                    $j("#trsimple-percent"+displayCompCountFinal+"_input").val(1);
                }
            }else if(BudgetInccontributedFor == 'grantee'){
                var totalFinal = contributedForFinalTotal + parseFloat(removeCommaSep($j("#"+finalComp+"_cncsprev").val())) + parseFloat(removeCommaSep($j("#"+finalComp+"_granteeinkindprev").val()))
                $j("#"+finalComp+"_totalprev").val(addCommaSep(totalFinal.toFixed(2)));

                var granteeTotal = removeCommaSep($j('#'+finalComp+'_grantee').val());
                var granteeinkindTotal = removeCommaSep($j('#'+finalComp+'_granteeinkind').val());
                if($j("#editedField").val() == 'grantee' && granteeTotal == removeCommaSep($j('#'+finalComp+'_granteeprev').val()) && granteeinkindTotal == removeCommaSep($j('#'+finalComp+'_granteeinkindprev').val())){
                    $j(".input-cncs").attr('readonly', false);
                    //$j(".input-cncs_Section3").attr('readonly', false);
                    $j(".input-cncs").each(function(){ 
                        if($j(this).hasClass('input-readonly')){
                            $j(this).attr('readonly', true);
                        }else{
                            $j(this).attr('readonly', false);
                        }
                    });
                    $j("#editedField").val('');
                    $j(".reconcile-grantee").html('-');
                    $j(".reconcile-grantee-secIII").css("display","none");
                    $j(".or-text-grantee").css("display","none");
                }

                if(removeCommaSep($j('#'+finalComp+'_total').val()) == (totalFinal).toFixed(2)){
                    //$j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                    //$j(".trsimple_total_"+finalCompId).hide();
                    $j(".trsimple_total_"+finalComp+" input").css("color","black");
                    $j("#trsimple-total"+displayCompCountFinal+"_input").val(0);
                    $j(".submit-button").attr("type", "submit");
                    $j(".submit-button").removeClass("disabled");
                    $j(".resubmit-button").attr("type", "submit");
                    $j(".resubmit-button").removeClass("disabled");
                    $j("#"+finalComp+"_changespan").empty();
                    $j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED');
                    $j(".changevaluesummary_"+finalComp).html('-');
                    var calChangeValue = false;
                }else{
                // $j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                    $j(".trsimple_total_"+finalComp).show();
                    $j(".trsimple_total_"+finalComp+" input").css("color","#C70404");
                    $j("#trsimple-total"+displayCompCountFinal+"_input").val(1);
                    $j(".submit-button").attr("type", "button");
                    $j(".submit-button").addClass("disabled");
                    $j(".resubmit-button").attr("type", "button");
                    $j(".resubmit-button").addClass("disabled");
                    $j("#"+finalComp+"_changespan").empty();
                    $j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED');
                    //$j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED <p style="color:red;font-style:italic;text-transform: none;font-size: 11px;">Difference to Reconcile</p>'); FR-212
                    var calChangeValue = true;
                }  
                

                //percent
                if(totalFinal > 0){
                    var percentVal = (contributedForFinalTotal/totalFinal)*100;
                }else{
                    var percentVal = 0;
                }
                var remainingPercent = Math.abs(100-percentVal);
                if(remainingPercent > 0){
                    var percentCompIdFinal = parseFloat(finalComp)+1;
                    var prevCompIdCncs = parseFloat($j("#"+percentCompIdFinal+"_cncsprev").val());
                    var prevCompIdGranteeInKind = parseFloat($j("#"+percentCompIdFinal+"_granteeinkindprev").val());
                    var totalValueRemaimingComps = prevCompIdCncs + prevCompIdGranteeInKind;
                    var cncsPercent = parseFloat((prevCompIdCncs/totalValueRemaimingComps)*remainingPercent);
                    //granteePercent = Math.round(granteePercent);
                    var granteeInkindPercent = Math.abs(remainingPercent-cncsPercent);
                }else{
                    var cncsPercent = 0;
                    var granteeInkindPercent = 0;
                }

                $j("#"+percentCompIdFinal+"_cncsprev").val(cncsPercent.toFixed(2));
                $j("#"+percentCompIdFinal+"_granteeprev").val(percentVal.toFixed(2));
                $j("#"+percentCompIdFinal+"_granteeinkindprev").val(granteeInkindPercent.toFixed(2));

                var checkTotalChangeExists = $j("#trsimple-total"+displayCompCountFinal+"_input").val();

                if($j('#'+percentCompIdFinal+'_grantee').val() == (percentVal).toFixed(2) && checkTotalChangeExists == 0){
                    $j(".trsimple_percent_"+percentCompIdFinal+" input").css("color","black");
                    $j("#trsimple-percent"+displayCompCountFinal+"_input").val(0);
                }else{
                    $j(".trsimple_percent_"+percentCompIdFinal+" input").css("color","#C70404");
                    $j(".trsimple_percent_"+percentCompIdFinal).show();
                    $j("#trsimple-percent"+displayCompCountFinal+"_input").val(1);
                }
            }else if(BudgetInccontributedFor == 'granteeinkind'){
                /*var totalFinal = contributedForFinalTotal + parseFloat($j("#"+finalComp+"_granteeprev").val()) + parseFloat($j("#"+finalComp+"_cncsprev").val())
                $j("#"+finalComp+"_totalprev").val(totalFinal.toFixed(2));

                if($j('#'+finalComp+'_total').val() == (totalFinal).toFixed(2)){
                    //$j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                    //$j(".trsimple_total_"+finalCompId).hide();
                    $j(".trsimple_total_"+finalComp+" input").css("color","black");
                    $j("#trsimple-total"+displayCompCountFinal+"_input").val(0);
                    $j(".submit-button").attr("type", "submit");
                    $j(".submit-button").removeClass("disabled");
                    $j(".resubmit-button").attr("type", "submit");
                    $j(".resubmit-button").removeClass("disabled");
                    $j("#"+finalComp+"_changespan").empty();
                    $j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED');
                    $j(".changevaluesummary_"+finalComp).html('-');
                    var calChangeValue = false;
                }else{
                // $j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                    $j(".trsimple_total_"+finalComp).show();
                    $j(".trsimple_total_"+finalComp+" input").css("color","red");
                    $j("#trsimple-total"+displayCompCountFinal+"_input").val(1);
                    $j(".submit-button").attr("type", "button");
                    $j(".submit-button").addClass("disabled");
                    $j(".resubmit-button").attr("type", "button");
                    $j(".resubmit-button").addClass("disabled");
                    $j("#"+finalComp+"_changespan").empty();
                    $j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED');
                    //$j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED <p style="color:red;font-style:italic;text-transform: none;font-size: 11px;">Difference to Reconcile</p>'); FR-212
                    var calChangeValue = true;
                }  
                
                //percent
                if(totalFinal > 0){
                    var percentVal = (contributedForFinalTotal/totalFinal)*100;
                }else{
                    var percentVal = 0;
                }
                var remainingPercent = Math.abs(100-percentVal);
                if(remainingPercent > 0){
                    var percentCompIdFinal = parseFloat(finalComp)+1;
                    var prevCompIdCncs = parseFloat($j("#"+percentCompIdFinal+"_cncsprev").val());
                    var prevCompIdGrantee = parseFloat($j("#"+percentCompIdFinal+"_granteeprev").val());
                    var totalValueRemaimingComps = prevCompIdCncs + prevCompIdGrantee;
                    var cncsPercent = parseFloat((prevCompIdCncs/totalValueRemaimingComps)*remainingPercent);
                    //granteePercent = Math.round(granteePercent);
                    var granteePercent = Math.abs(remainingPercent-cncsPercent);
                }else{
                    var cncsPercent = 0;
                    var granteePercent = 0;
                }

                $j("#"+percentCompIdFinal+"_cncsprev").val(cncsPercent.toFixed(2));
                $j("#"+percentCompIdFinal+"_granteeprev").val(granteePercent.toFixed(2));
                $j("#"+percentCompIdFinal+"_granteeinkindprev").val(percentVal.toFixed(2));

                var checkTotalChangeExists = $j("#trsimple-total"+displayCompCountFinal+"_input").val();

                if($j('#'+percentCompIdFinal+'_granteeinkind').val() == (percentVal).toFixed(2) && checkTotalChangeExists == 0){
                    $j(".trsimple_percent_"+percentCompIdFinal+" input").css("color","black");
                    $j("#trsimple-percent"+displayCompCountFinal+"_input").val(0);
                }else{
                    $j(".trsimple_percent_"+percentCompIdFinal+" input").css("color","red");
                    $j(".trsimple_percent_"+percentCompIdFinal).show();
                    $j("#trsimple-percent"+displayCompCountFinal+"_input").val(1);
                }*/
                var totalFinal = contributedForFinalTotal + parseFloat(removeCommaSep($j("#"+finalComp+"_cncsprev").val())) + parseFloat(removeCommaSep($j("#"+finalComp+"_granteeinkindprev").val()))
                $j("#"+finalComp+"_totalprev").val(addCommaSep(totalFinal.toFixed(2)));

                var granteeTotal = removeCommaSep($j('#'+finalComp+'_grantee').val());
                var granteeinkindTotal = removeCommaSep($j('#'+finalComp+'_granteeinkind').val());
                if($j("#editedField").val() == 'grantee' && granteeTotal == removeCommaSep($j('#'+finalComp+'_granteeprev').val()) && granteeinkindTotal == removeCommaSep($j('#'+finalComp+'_granteeinkindprev').val())){
                    $j(".input-cncs").attr('readonly', false);
                    //$j(".input-cncs_Section3").attr('readonly', false);
                    $j(".input-cncs").each(function(){ 
                        if($j(this).hasClass('input-readonly')){
                            $j(this).attr('readonly', true);
                        }else{
                            $j(this).attr('readonly', false);
                        }
                    });
                    $j("#editedField").val('');
                    $j(".reconcile-grantee").html('-');
                    $j(".reconcile-grantee-secIII").css("display","none");
                    $j(".or-text-grantee").css("display","none");
                }

                if(removeCommaSep($j('#'+finalComp+'_total').val()) == (totalFinal).toFixed(2)){
                    //$j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                    //$j(".trsimple_total_"+finalCompId).hide();
                    $j(".trsimple_total_"+finalComp+" input").css("color","black");
                    $j("#trsimple-total"+displayCompCountFinal+"_input").val(0);
                    $j(".submit-button").attr("type", "submit");
                    $j(".submit-button").removeClass("disabled");
                    $j(".resubmit-button").attr("type", "submit");
                    $j(".resubmit-button").removeClass("disabled");
                    $j("#"+finalComp+"_changespan").empty();
                    $j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED');
                    $j(".changevaluesummary_"+finalComp).html('-');
                    var calChangeValue = false;
                }else{
                // $j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                    $j(".trsimple_total_"+finalComp).show();
                    $j(".trsimple_total_"+finalComp+" input").css("color","#C70404");
                    $j("#trsimple-total"+displayCompCountFinal+"_input").val(1);
                    $j(".submit-button").attr("type", "button");
                    $j(".submit-button").addClass("disabled");
                    $j(".resubmit-button").attr("type", "button");
                    $j(".resubmit-button").addClass("disabled");
                    $j("#"+finalComp+"_changespan").empty();
                    $j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED');
                    //$j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED <p style="color:red;font-style:italic;text-transform: none;font-size: 11px;">Difference to Reconcile</p>'); FR-212
                    var calChangeValue = true;
                }  
                

                //percent
                if(totalFinal > 0){
                    var percentVal = (contributedForFinalTotal/totalFinal)*100;
                }else{
                    var percentVal = 0;
                }
                var remainingPercent = Math.abs(100-percentVal);
                if(remainingPercent > 0){
                    var percentCompIdFinal = parseFloat(finalComp)+1;
                    var prevCompIdCncs = parseFloat($j("#"+percentCompIdFinal+"_cncsprev").val());
                    var prevCompIdGranteeInKind = parseFloat($j("#"+percentCompIdFinal+"_granteeinkindprev").val());
                    var totalValueRemaimingComps = prevCompIdCncs + prevCompIdGranteeInKind;
                    var cncsPercent = parseFloat((prevCompIdCncs/totalValueRemaimingComps)*remainingPercent);
                    //granteePercent = Math.round(granteePercent);
                    var granteeInkindPercent = Math.abs(remainingPercent-cncsPercent);
                }else{
                    var cncsPercent = 0;
                    var granteeInkindPercent = 0;
                }

                $j("#"+percentCompIdFinal+"_cncsprev").val(cncsPercent.toFixed(2));
                $j("#"+percentCompIdFinal+"_granteeprev").val(percentVal.toFixed(2));
                $j("#"+percentCompIdFinal+"_granteeinkindprev").val(granteeInkindPercent.toFixed(2));

                var checkTotalChangeExists = $j("#trsimple-total"+displayCompCountFinal+"_input").val();

                if($j('#'+percentCompIdFinal+'_grantee').val() == (percentVal).toFixed(2) && checkTotalChangeExists == 0){
                    $j(".trsimple_percent_"+percentCompIdFinal+" input").css("color","black");
                    $j("#trsimple-percent"+displayCompCountFinal+"_input").val(0);
                }else{
                    $j(".trsimple_percent_"+percentCompIdFinal+" input").css("color","#C70404");
                    $j(".trsimple_percent_"+percentCompIdFinal).show();
                    $j("#trsimple-percent"+displayCompCountFinal+"_input").val(1);
                }
            }

            if(calChangeValue){
                var cncsChangeValue = 0;
                var granteeChangeValue = 0;
                var granteeinkindChangeValue = 0;
                var totalChangeValue = 0;
                
                var cncs_value = removeCommaSep($j('#'+finalComp+'_cncs').val());
                var cncsprev_value = removeCommaSep($j('#'+finalComp+'_cncsprev').val());
                if(cncs_value != ''){
                    cncs_value = parseFloat(cncs_value);
                }else{
                    if(cncsprev_value != ''){
                        cncs_value = parseFloat(cncsprev_value);
                    }else{
                        cncs_value = 0;
                    }
                }
                if(cncs_value > 0){
                    cncsChangeValue =  cncs_value - cncsprev_value;
                }
                if(cncsprev_value > 0){
                    var cncsChangePercent = (cncsChangeValue/cncsprev_value)*100;
                }else{
                    var cncsChangePercent = cncsChangeValue;
                }
                if(cncsChangeValue > 0){
                    $j("#changevaluesummarycncs_"+finalComp).html('+$'+addCommaSep(cncsChangeValue.toFixed(2)));
                    if(cncsChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarycncs_"+finalComp).html('('+cncsChangePercent.toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarycncs_"+finalComp).html('(+'+cncsChangePercent.toFixed(2)+'%)');
                    }                 
                }else if(cncsChangeValue == 0){
                    $j("#changevaluesummarycncs_"+finalComp).html('');
                    $j("#changepercentsummarycncs_"+finalComp).html('');
                }else{
                    $j("#changevaluesummarycncs_"+finalComp).html('-$'+addCommaSep(Math.abs(cncsChangeValue).toFixed(2)));
                    if(cncsChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarycncs_"+finalComp).html('('+Math.abs(cncsChangePercent).toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarycncs_"+finalComp).html('(-'+Math.abs(cncsChangePercent).toFixed(2)+'%)');
                    }  
                }

                var grantee_value = removeCommaSep($j('#'+finalComp+'_grantee').val());
                var granteeprev_value = removeCommaSep($j('#'+finalComp+'_granteeprev').val());
                if(grantee_value != ''){
                    grantee_value = parseFloat(grantee_value);
                }else{
                    if(granteeprev_value != ''){
                        grantee_value = parseFloat(granteeprev_value);
                    }else{
                        grantee_value = 0;
                    }
                }
                if(grantee_value > 0){
                    granteeChangeValue = grantee_value - granteeprev_value;
                }
                if(granteeprev_value > 0){
                    var granteeChangePercent = (granteeChangeValue/granteeprev_value)*100;
                }else{
                    var granteeChangePercent = granteeChangeValue;
                }
                if(granteeChangeValue > 0){
                    $j("#changevaluesummarygrantee_"+finalComp).html('+$'+addCommaSep(granteeChangeValue.toFixed(2)));
                    if(granteeChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarygrantee_"+finalComp).html('('+granteeChangePercent.toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarygrantee_"+finalComp).html('(+'+granteeChangePercent.toFixed(2)+'%)');
                    }  
                }else if(granteeChangeValue == 0){
                    $j("#changevaluesummarygrantee_"+finalComp).html('');
                    $j("#changepercentsummarygrantee_"+finalComp).html('');
                }else{
                    $j("#changevaluesummarygrantee_"+finalComp).html('-$'+addCommaSep(Math.abs(granteeChangeValue).toFixed(2)));
                    if(granteeChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarygrantee_"+finalComp).html('('+Math.abs(granteeChangePercent).toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarygrantee_"+finalComp).html('(-'+Math.abs(granteeChangePercent).toFixed(2)+'%)');
                    }  
                }

                var granteeinkind_value = removeCommaSep($j('#'+finalComp+'_granteeinkind').val());
                var granteeinkindprev_value = removeCommaSep($j('#'+finalComp+'_granteeinkindprev').val());
                if(granteeinkind_value != ''){
                    granteeinkind_value = parseFloat(granteeinkind_value);
                }else{
                    if(granteeinkindprev_value != ''){
                        granteeinkind_value = parseFloat(granteeinkindprev_value);
                    }else{
                        granteeinkind_value = 0;
                    }
                }
                if(granteeinkind_value > 0){
                    granteeinkindChangeValue =  granteeinkind_value - granteeinkindprev_value;
                }
                if(granteeinkindprev_value > 0){
                    var granteeinkindChangePercent = (granteeinkindChangeValue/granteeinkindprev_value)*100;
                }else{
                    var granteeinkindChangePercent = granteeinkindChangeValue;
                }
                if(granteeinkindChangeValue > 0){
                    $j("#changevaluesummarygranteeinkind_"+finalComp).html('+$'+addCommaSep(granteeinkindChangeValue.toFixed(2)));
                    if(granteeinkindChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarygranteeinkind_"+finalComp).html('('+granteeinkindChangePercent.toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarygranteeinkind_"+finalComp).html('(+'+granteeinkindChangePercent.toFixed(2)+'%)');
                    } 
                }else if(granteeinkindChangeValue == 0){
                    $j("#changevaluesummarygranteeinkind_"+finalComp).html('');
                    $j("#changepercentsummarygranteeinkind_"+finalComp).html('');
                }else{
                    $j("#changevaluesummarygranteeinkind_"+finalComp).html('-$'+addCommaSep(Math.abs(granteeinkindChangeValue).toFixed(2)));
                    if(granteeinkindChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarygranteeinkind_"+finalComp).html('('+Math.abs(granteeinkindChangePercent).toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarygranteeinkind_"+finalComp).html('(-'+Math.abs(granteeinkindChangePercent).toFixed(2)+'%)');
                    } 
                }

                var total_value = removeCommaSep($j('#'+finalComp+'_total').val());
                var totalprev_value = removeCommaSep($j('#'+finalComp+'_totalprev').val());
                if(total_value != ''){
                    total_value = parseFloat(total_value);
                }else{
                    if(totalprev_value != ''){
                        total_value = parseFloat(totalprev_value);
                    }else{
                        total_value = 0;
                    }
                }
                if(total_value > 0){
                    totalChangeValue =  total_value - totalprev_value;
                }
                if(totalprev_value > 0){
                    var totalChangePercent = (totalChangeValue/totalprev_value)*100;
                }else{
                    var totalChangePercent = totalChangeValue;
                }
                if(totalChangeValue > 0){
                    $j("#changevaluesummarytotal_"+finalComp).html('+$'+addCommaSep(totalChangeValue.toFixed(2)));
                    if(totalChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarytotal_"+finalComp).html('('+totalChangePercent.toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarytotal_"+finalComp).html('(+'+totalChangePercent.toFixed(2)+'%)');
                    } 
                }else if(totalChangeValue == 0){
                    $j("#changevaluesummarytotal_"+finalComp).html('');
                    $j("#changepercentsummarytotal_"+finalComp).html('');
                }else{
                    $j("#changevaluesummarytotal_"+finalComp).html('-$'+addCommaSep(Math.abs(totalChangeValue).toFixed(2)));
                    if(totalChangePercent.toFixed(2) == 0){
                        $j("#changepercentsummarytotal_"+finalComp).html('('+Math.abs(totalChangePercent).toFixed(2)+'%)');
                    }else{
                        $j("#changepercentsummarytotal_"+finalComp).html('(-'+Math.abs(totalChangePercent).toFixed(2)+'%)');
                    } 
                }
            } 

            calculateTotalPERMSY(BudgetInccontributed)
            calculateTotalPERMSYPrev(BudgetInccontributed)
                
            $j("#budgetIncrease"+BudgetInccontributedFor+"_prev").val(0);
        }
    }else{
        if($j("#"+sec1and2Comp+"_cncs").val() == ''){
            $j("#"+sec1and2Comp+"_cncs").val($j("#"+sec1and2Comp+"_cncsprev").val())
        }
        if($j("#"+sec1and2Comp+"_grantee").val() == ''){
            $j("#"+sec1and2Comp+"_grantee").val($j("#"+sec1and2Comp+"_granteeprev").val())
        }
        if($j("#"+sec1and2Comp+"_granteeinkind").val() == ''){
            $j("#"+sec1and2Comp+"_granteeinkind").val($j("#"+sec1and2Comp+"_granteeinkindprev").val())
        }
        if($j("#"+sec1and2Comp+"_total").val() == ''){
            $j("#"+sec1and2Comp+"_total").val($j("#"+sec1and2Comp+"_totalprev").val())
        }

        var inputBudgetIncValuePrev = parseFloat(removeCommaSep($j("#budgetIncrease"+BudgetInccontributedFor+"_prev").val()));
        var contributedForsec1and2SubTotal = parseFloat(removeCommaSep($j("#"+sec1and2Comp+"_"+BudgetInccontributedFor+"prev").val()));
        if(inputBudgetIncValuePrev > 0){
            contributedForsec1and2SubTotal = Math.abs(contributedForsec1and2SubTotal-inputBudgetIncValuePrev);
        }else if(inputBudgetIncValuePrev < 0){
            contributedForsec1and2SubTotal = Math.abs(contributedForsec1and2SubTotal-(inputBudgetIncValuePrev));
        }
        contributedForsec1and2SubTotal = contributedForsec1and2SubTotal + parseFloat(inputBudgetIncValue);
        $j("#"+sec1and2Comp+"_"+BudgetInccontributedFor+"prev").val(addCommaSep(contributedForsec1and2SubTotal.toFixed(2)));

        var percentCompId = parseFloat(sec1and2Comp)+1;

        if($j("#"+percentCompId+"_cncs").val() == ''){
            $j("#"+percentCompId+"_cncs").val($j("#"+percentCompId+"_cncsprev").val())
        }
        if($j("#"+percentCompId+"_grantee").val() == ''){
            $j("#"+percentCompId+"_grantee").val($j("#"+percentCompId+"_granteeprev").val())
        }
        if($j("#"+percentCompId+"_granteeinkind").val() == ''){
            $j("#"+percentCompId+"_granteeinkind").val($j("#"+percentCompId+"_granteeinkindprev").val())
        }

        if(BudgetInccontributedFor == 'cncs'){
            var totalSec1And2 = contributedForsec1and2SubTotal + parseFloat(removeCommaSep($j("#"+sec1and2Comp+"_granteeprev").val())) + parseFloat(removeCommaSep($j("#"+sec1and2Comp+"_granteeinkindprev").val()))
            $j("#"+sec1and2Comp+"_totalprev").val(addCommaSep(totalSec1And2.toFixed(2)));
            
            if(removeCommaSep($j('#'+sec1and2Comp+'_total').val()) == (totalSec1And2).toFixed(2)){
                //$j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                //$j(".trsimple_total_"+finalCompId).hide();
                $j(".trsimple_total_"+sec1and2Comp+" input").css("color","black");
                $j("#trsimple-total"+displayCompCount+"_input").val(0);
                $j(".changevaluesummary_"+sec1and2Comp).html('-');
                    var calChangeValue = false;
            }else{
               // $j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                $j(".trsimple_total_"+sec1and2Comp).show();
                $j(".trsimple_total_"+sec1and2Comp+" input").css("color","#C70404");
                $j("#trsimple-total"+displayCompCount+"_input").val(1);
                    var calChangeValue = true;
            }  

            //percent
            if(totalSec1And2 > 0){
                var percentVal = (contributedForsec1and2SubTotal/totalSec1And2)*100;
            }else{
                var percentVal = 0;
            }
            
            var remainingPercent = Math.abs(100-percentVal);
            if(remainingPercent > 0){
                var prevCompIdGrantee = parseFloat($j("#"+percentCompId+"_granteeprev").val());
                var prevCompIdGranteeInKind = parseFloat($j("#"+percentCompId+"_granteeinkindprev").val());
                var totalValueRemaimingComps = prevCompIdGrantee + prevCompIdGranteeInKind;
                var granteePercent = parseFloat((prevCompIdGrantee/totalValueRemaimingComps)*remainingPercent);
                //granteePercent = Math.round(granteePercent);
                var granteeInkindPercent = Math.abs(remainingPercent-granteePercent);
            }else{
                var granteePercent = 0;
                var granteeInkindPercent = 0;
            }

            $j("#"+percentCompId+"_cncsprev").val(percentVal.toFixed(2));
            $j("#"+percentCompId+"_granteeprev").val(granteePercent.toFixed(2));
            $j("#"+percentCompId+"_granteeinkindprev").val(granteeInkindPercent.toFixed(2));

            var checkTotalChangeExists = $j("#trsimple-total"+displayCompCount+"_input").val();
            
            if($j('#'+percentCompId+'_cncs').val() == (percentVal).toFixed(2) && checkTotalChangeExists == 0){
                $j(".trsimple_percent_"+percentCompId+" input").css("color","black");
                $j("#trsimple-percent"+displayCompCount+"_input").val(0);
            }else{
                $j(".trsimple_percent_"+percentCompId+" input").css("color","#C70404");
                $j(".trsimple_percent_"+percentCompId).show();
                $j("#trsimple-percent"+displayCompCount+"_input").val(1);
            }
        }else if(BudgetInccontributedFor == 'grantee'){
            var totalSec1And2 = contributedForsec1and2SubTotal + parseFloat(removeCommaSep($j("#"+sec1and2Comp+"_cncsprev").val())) + parseFloat(removeCommaSep($j("#"+sec1and2Comp+"_granteeinkindprev").val()))
            $j("#"+sec1and2Comp+"_totalprev").val(addCommaSep(totalSec1And2.toFixed(2)));
            
            if(removeCommaSep($j('#'+sec1and2Comp+'_total').val()) == (totalSec1And2).toFixed(2)){
                //$j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                //$j(".trsimple_total_"+finalCompId).hide();
                $j(".trsimple_total_"+sec1and2Comp+" input").css("color","black");
                $j("#trsimple-total"+displayCompCount+"_input").val(0);
                $j(".changevaluesummary_"+sec1and2Comp).html('-');
                    var calChangeValue = false;
            }else{
               // $j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                $j(".trsimple_total_"+sec1and2Comp).show();
                $j(".trsimple_total_"+sec1and2Comp+" input").css("color","#C70404");
                $j("#trsimple-total"+displayCompCount+"_input").val(1);
                    var calChangeValue = true;
            }

            //percent
            if(totalSec1And2 > 0){
                var percentVal = (contributedForsec1and2SubTotal/totalSec1And2)*100;
            }else{
                var percentVal = 0;
            }
            var remainingPercent = Math.abs(100-percentVal);
            if(remainingPercent > 0){
                var prevCompIdCncs = parseFloat($j("#"+percentCompId+"_cncsprev").val());
                var prevCompIdGranteeInKind = parseFloat($j("#"+percentCompId+"_granteeinkindprev").val());
                var totalValueRemaimingComps = prevCompIdCncs + prevCompIdGranteeInKind;
                var cncsPercent = parseFloat((prevCompIdCncs/totalValueRemaimingComps)*remainingPercent);
                //granteePercent = Math.round(granteePercent);
                var granteeInkindPercent = Math.abs(remainingPercent-cncsPercent);
            }else{
                var cncsPercent = 0;
                var granteeInkindPercent = 0;
            }

            $j("#"+percentCompId+"_cncsprev").val(cncsPercent.toFixed(2));
            $j("#"+percentCompId+"_granteeprev").val(percentVal.toFixed(2));
            $j("#"+percentCompId+"_granteeinkindprev").val(granteeInkindPercent.toFixed(2));

            var checkTotalChangeExists = $j("#trsimple-total"+displayCompCount+"_input").val();

            if($j('#'+percentCompId+'_grantee').val() == (percentVal).toFixed(2) && checkTotalChangeExists == 0){
                $j(".trsimple_percent_"+percentCompId+" input").css("color","black");
                $j("#trsimple-percent"+displayCompCount+"_input").val(0);
            }else{
                $j(".trsimple_percent_"+percentCompId+" input").css("color","#C70404");
                $j(".trsimple_percent_"+percentCompId).show();
                $j("#trsimple-percent"+displayCompCount+"_input").val(1);
            }
        }else if(BudgetInccontributedFor == 'granteeinkind'){
            var totalSec1And2 = contributedForsec1and2SubTotal + parseFloat(removeCommaSep($j("#"+sec1and2Comp+"_granteeprev").val())) + parseFloat(removeCommaSep($j("#"+sec1and2Comp+"_cncsprev").val()))
            $j("#"+sec1and2Comp+"_totalprev").val(addCommaSep(totalSec1And2.toFixed(2)));

            if(removeCommaSep($j('#'+sec1and2Comp+'_total').val()) == (totalSec1And2).toFixed(2)){
                //$j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                //$j(".trsimple_total_"+finalCompId).hide();
                $j(".trsimple_total_"+sec1and2Comp+" input").css("color","black");
                $j("#trsimple-total"+displayCompCount+"_input").val(0);
                $j(".changevaluesummary_"+sec1and2Comp).html('-');
                    var calChangeValue = false;
            }else{
               // $j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                $j(".trsimple_total_"+sec1and2Comp).show();
                $j(".trsimple_total_"+sec1and2Comp+" input").css("color","#C70404");
                $j("#trsimple-total"+displayCompCount+"_input").val(1);
                    var calChangeValue = true;
            }

            //percent
            if(totalSec1And2 > 0){
                var percentVal = (contributedForsec1and2SubTotal/totalSec1And2)*100;
            }else{
                var percentVal = 0;
            }
            var remainingPercent = Math.abs(100-percentVal);
            if(remainingPercent > 0){
                var prevCompIdCncs = parseFloat($j("#"+percentCompId+"_cncsprev").val());
                var prevCompIdGrantee = parseFloat($j("#"+percentCompId+"_granteeprev").val());
                var totalValueRemaimingComps = prevCompIdCncs + prevCompIdGrantee;
                var cncsPercent = parseFloat((prevCompIdCncs/totalValueRemaimingComps)*remainingPercent);
                //granteePercent = Math.round(granteePercent);
                var granteePercent = Math.abs(remainingPercent-cncsPercent);
            }else{
                var cncsPercent = 0;
                var granteePercent = 0;
            }

            $j("#"+percentCompId+"_cncsprev").val(cncsPercent.toFixed(2));
            $j("#"+percentCompId+"_granteeprev").val(granteePercent.toFixed(2));
            $j("#"+percentCompId+"_granteeinkindprev").val(percentVal.toFixed(2));

            var checkTotalChangeExists = $j("#trsimple-total"+displayCompCount+"_input").val();

            if($j('#'+percentCompId+'_granteeinkind').val() == (percentVal).toFixed(2) && checkTotalChangeExists == 0){
                $j(".trsimple_percent_"+percentCompId+" input").css("color","black");
                $j("#trsimple-percent"+displayCompCount+"_input").val(0);
            }else{
                $j(".trsimple_percent_"+percentCompId+" input").css("color","#C70404");
                $j(".trsimple_percent_"+percentCompId).show();
                $j("#trsimple-percent"+displayCompCount+"_input").val(1);
            }
        }

        if(calChangeValue){
            var cncsChangeValue = 0;
            var granteeChangeValue = 0;
            var granteeinkindChangeValue = 0;
            var totalChangeValue = 0;
            
            var cncs_value = removeCommaSep($j('#'+sec1and2Comp+'_cncs').val());
            var cncsprev_value = removeCommaSep($j('#'+sec1and2Comp+'_cncsprev').val());
            if(cncs_value != ''){
                cncs_value = parseFloat(cncs_value);
            }else{
                if(cncsprev_value != ''){
                    cncs_value = parseFloat(cncsprev_value);
                }else{
                    cncs_value = 0;
                }
            }
            if(cncs_value > 0){
                cncsChangeValue =  cncs_value - cncsprev_value;
            }
            if(cncsprev_value > 0){
                var cncsChangePercent = (cncsChangeValue/cncsprev_value)*100;
            }else{
                var cncsChangePercent = cncsChangeValue;
            }
            if(cncsChangeValue > 0){
                $j("#changevaluesummarycncs_"+sec1and2Comp).html('+$'+addCommaSep(cncsChangeValue.toFixed(2)));
                if(cncsChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarycncs_"+sec1and2Comp).html('('+cncsChangePercent.toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarycncs_"+sec1and2Comp).html('(+'+cncsChangePercent.toFixed(2)+'%)');
                } 
            }else if(cncsChangeValue == 0){
                $j("#changevaluesummarycncs_"+sec1and2Comp).html('');
                $j("#changepercentsummarycncs_"+sec1and2Comp).html('');
            }else{
                $j("#changevaluesummarycncs_"+sec1and2Comp).html('-$'+addCommaSep(Math.abs(cncsChangeValue).toFixed(2)));
                if(cncsChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarycncs_"+sec1and2Comp).html('('+Math.abs(cncsChangePercent).toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarycncs_"+sec1and2Comp).html('(-'+Math.abs(cncsChangePercent).toFixed(2)+'%)');
                } 
            }

            var grantee_value = removeCommaSep($j('#'+sec1and2Comp+'_grantee').val());
            var granteeprev_value = removeCommaSep($j('#'+sec1and2Comp+'_granteeprev').val());
            if(grantee_value != ''){
                grantee_value = parseFloat(grantee_value);
            }else{
                if(granteeprev_value != ''){
                    grantee_value = parseFloat(granteeprev_value);
                }else{
                    grantee_value = 0;
                }
            }
            if(grantee_value > 0){
                granteeChangeValue = grantee_value - granteeprev_value;
            }
            if(granteeprev_value > 0){
                var granteeChangePercent = (granteeChangeValue/granteeprev_value)*100;
            }else{
                var granteeChangePercent = granteeChangeValue;
            }
            if(granteeChangeValue > 0){
                $j("#changevaluesummarygrantee_"+sec1and2Comp).html('+$'+addCommaSep(granteeChangeValue.toFixed(2)));
                if(granteeChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarygrantee_"+sec1and2Comp).html('('+granteeChangePercent.toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarygrantee_"+sec1and2Comp).html('(+'+granteeChangePercent.toFixed(2)+'%)');
                } 
            }else if(granteeChangeValue == 0){
                $j("#changevaluesummarygrantee_"+sec1and2Comp).html('');
                $j("#changepercentsummarygrantee_"+sec1and2Comp).html('');
            }else{
                $j("#changevaluesummarygrantee_"+sec1and2Comp).html('-$'+addCommaSep(Math.abs(granteeChangeValue).toFixed(2)));
                if(granteeChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarygrantee_"+sec1and2Comp).html('('+Math.abs(granteeChangePercent).toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarygrantee_"+sec1and2Comp).html('(-'+Math.abs(granteeChangePercent).toFixed(2)+'%)');
                } 
            }

            var granteeinkind_value = removeCommaSep($j('#'+sec1and2Comp+'_granteeinkind').val());
            var granteeinkindprev_value = removeCommaSep($j('#'+sec1and2Comp+'_granteeinkindprev').val());
            if(granteeinkind_value != ''){
                granteeinkind_value = parseFloat(granteeinkind_value);
            }else{
                if(granteeinkindprev_value != ''){
                    granteeinkind_value = parseFloat(granteeinkindprev_value);
                }else{
                    granteeinkind_value = 0;
                }
            }
            //if(granteeinkind_value > 0){
                granteeinkindChangeValue =  granteeinkind_value - granteeinkindprev_value;
            //}
            if(granteeinkindprev_value > 0){
                var granteeinkindChangePercent = (granteeinkindChangeValue/granteeinkindprev_value)*100;
            }else{
                var granteeinkindChangePercent = granteeinkindChangeValue;
            }
            if(granteeinkindChangeValue > 0){
                $j("#changevaluesummarygranteeinkind_"+sec1and2Comp).html('+$'+addCommaSep(granteeinkindChangeValue.toFixed(2)));
                if(granteeinkindChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarygranteeinkind_"+sec1and2Comp).html('('+granteeinkindChangePercent.toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarygranteeinkind_"+sec1and2Comp).html('(+'+granteeinkindChangePercent.toFixed(2)+'%)');
                } 
            }else if(granteeinkindChangeValue == 0){
                $j("#changevaluesummarygranteeinkind_"+sec1and2Comp).html('');
                $j("#changepercentsummarygranteeinkind_"+sec1and2Comp).html('');
            }else{
                $j("#changevaluesummarygranteeinkind_"+sec1and2Comp).html('-$'+addCommaSep(Math.abs(granteeinkindChangeValue).toFixed(2)));
                if(granteeinkindChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarygranteeinkind_"+sec1and2Comp).html('('+Math.abs(granteeinkindChangePercent).toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarygranteeinkind_"+sec1and2Comp).html('(-'+Math.abs(granteeinkindChangePercent).toFixed(2)+'%)');
                } 
            }

            var total_value = removeCommaSep($j('#'+sec1and2Comp+'_total').val());
            var totalprev_value = removeCommaSep($j('#'+sec1and2Comp+'_totalprev').val());
            if(total_value != ''){
                total_value = parseFloat(total_value);
            }else{
                if(totalprev_value != ''){
                    total_value = parseFloat(totalprev_value);
                }else{
                    total_value = 0;
                }
            }
            if(total_value > 0){
                totalChangeValue =  total_value - totalprev_value;
            }
            if(totalprev_value > 0){
                var totalChangePercent = (totalChangeValue/totalprev_value)*100;
            }else{
                var totalChangePercent = totalChangeValue;
            }
            if(totalChangeValue > 0){
                $j("#changevaluesummarytotal_"+sec1and2Comp).html('+$'+addCommaSep(totalChangeValue.toFixed(2)));
                if(totalChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarytotal_"+sec1and2Comp).html('('+totalChangePercent.toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarytotal_"+sec1and2Comp).html('(+'+totalChangePercent.toFixed(2)+'%)');
                } 
            }else if(totalChangeValue == 0){
                $j("#changevaluesummarytotal_"+sec1and2Comp).html('');
                $j("#changepercentsummarytotal_"+sec1and2Comp).html('');
            }else{
                $j("#changevaluesummarytotal_"+sec1and2Comp).html('-$'+addCommaSep(Math.abs(totalChangeValue).toFixed(2)));
                if(totalChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarytotal_"+sec1and2Comp).html('('+Math.abs(totalChangePercent).toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarytotal_"+sec1and2Comp).html('(-'+Math.abs(totalChangePercent).toFixed(2)+'%)');
                } 
            }
        } 
        

        //total
        if($j("#"+finalComp+"_cncs").val() == ''){
            $j("#"+finalComp+"_cncs").val($j("#"+finalComp+"_cncsprev").val())
        }
        if($j("#"+finalComp+"_grantee").val() == ''){
            $j("#"+finalComp+"_grantee").val($j("#"+finalComp+"_granteeprev").val())
        }
        if($j("#"+finalComp+"_granteeinkind").val() == ''){
            $j("#"+finalComp+"_granteeinkind").val($j("#"+finalComp+"_granteeinkindprev").val())
        }
        if($j("#"+finalComp+"_total").val() == ''){
            $j("#"+finalComp+"_total").val($j("#"+finalComp+"_totalprev").val())
        }

        if(BudgetInccontributedFor == 'granteeinkind'){
            var BudgetInccontributed = 'grantee';
            var contributedForFinalTotal = parseFloat(removeCommaSep($j("#"+finalComp+"_"+BudgetInccontributed+"prev").val()));
            contributedForFinalTotal = contributedForFinalTotal + parseFloat(inputBudgetIncValue);
            if(inputBudgetIncValuePrev > 0){
                contributedForFinalTotal = Math.abs(contributedForFinalTotal-inputBudgetIncValuePrev);
            }else if(inputBudgetIncValuePrev < 0){
                contributedForFinalTotal = Math.abs(contributedForFinalTotal-(inputBudgetIncValuePrev));
            }
            $j("#"+finalComp+"_"+BudgetInccontributed+"prev").val(addCommaSep(contributedForFinalTotal.toFixed(2)));
            calculateTotalPERMSY(BudgetInccontributed)
            calculateTotalPERMSYPrev(BudgetInccontributed)
        }else{
            var contributedForFinalTotal = parseFloat(removeCommaSep($j("#"+finalComp+"_"+BudgetInccontributedFor+"prev").val()));
            contributedForFinalTotal = contributedForFinalTotal + parseFloat(inputBudgetIncValue);
            if(inputBudgetIncValuePrev > 0){
                contributedForFinalTotal = Math.abs(contributedForFinalTotal-inputBudgetIncValuePrev);
            }else if(inputBudgetIncValuePrev < 0){
                contributedForFinalTotal = Math.abs(contributedForFinalTotal-(inputBudgetIncValuePrev));
            }
            $j("#"+finalComp+"_"+BudgetInccontributedFor+"prev").val(addCommaSep(contributedForFinalTotal.toFixed(2)));
            calculateTotalPERMSY(BudgetInccontributedFor)
            calculateTotalPERMSYPrev(BudgetInccontributedFor)
        }

        //calculateSection1and3Percent(BudgetInccontributedFor)

        var percentCompIdFinal = parseFloat(finalComp)+1;

        if($j("#"+percentCompIdFinal+"_cncs").val() == ''){
            $j("#"+percentCompIdFinal+"_cncs").val($j("#"+percentCompIdFinal+"_cncsprev").val())
        }
        if($j("#"+percentCompIdFinal+"_grantee").val() == ''){
            $j("#"+percentCompIdFinal+"_grantee").val($j("#"+percentCompIdFinal+"_granteeprev").val())
        }
        if($j("#"+percentCompIdFinal+"_granteeinkind").val() == ''){
            $j("#"+percentCompIdFinal+"_granteeinkind").val($j("#"+percentCompIdFinal+"_granteeinkindprev").val())
        }

        if(BudgetInccontributedFor == 'cncs'){
            var totalFinal = contributedForFinalTotal + parseFloat(removeCommaSep($j("#"+finalComp+"_granteeprev").val())) + parseFloat(removeCommaSep($j("#"+finalComp+"_granteeinkindprev").val()))
            $j("#"+finalComp+"_totalprev").val(addCommaSep(totalFinal.toFixed(2)));

            var cncsTotal = removeCommaSep($j('#'+finalComp+'_cncs').val());
            if($j("#editedField").val() == 'cncs' && cncsTotal == removeCommaSep($j('#'+finalComp+'_cncsprev').val())){
                $j(".input-grantee").attr('readonly', false);
                //$j(".input-grantee_Section3").attr('readonly', false);
                $j(".input-grantee").each(function(){ 
                    if($j(this).hasClass('input-readonly')){
                        $j(this).attr('readonly', true);
                    }else{
                        $j(this).attr('readonly', false);
                    }
                });
                $j("#editedField").val('');
                $j(".reconcile-cncs").html('-');
                $j(".reconcile-cncs-secIII").css("display","none");
                $j(".or-text-cncs").css("display","none");
            }

            if(removeCommaSep($j('#'+finalComp+'_total').val()) == (totalFinal).toFixed(2)){
                //$j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                //$j(".trsimple_total_"+finalCompId).hide();
                $j(".trsimple_total_"+finalComp+" input").css("color","black");
                $j("#trsimple-total"+displayCompCountFinal+"_input").val(0);
                $j(".submit-button").attr("type", "submit");
                $j(".submit-button").removeClass("disabled");
                $j(".resubmit-button").attr("type", "submit");
                $j(".resubmit-button").removeClass("disabled");
                $j("#"+finalComp+"_changespan").empty();
                $j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED');
                $j(".changevaluesummary_"+finalComp).html('-');
                var calChangeValue = false;
            }else{
               // $j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                $j(".trsimple_total_"+finalComp).show();
                $j(".trsimple_total_"+finalComp+" input").css("color","#C70404");
                $j("#trsimple-total"+displayCompCountFinal+"_input").val(1);
                $j(".submit-button").attr("type", "button");
                $j(".submit-button").addClass("disabled");
                $j(".resubmit-button").attr("type", "button");
                $j(".resubmit-button").addClass("disabled");
                $j("#"+finalComp+"_changespan").empty();
                $j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED');
                //$j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED <p style="color:red;font-style:italic;text-transform: none;font-size: 11px;">Difference to Reconcile</p>'); FR-212
                var calChangeValue = true;
            }  
            
            //percent
            if(totalFinal > 0){
                var percentVal = (contributedForFinalTotal/totalFinal)*100;
            }else{
                var percentVal = 0;
            }

            var remainingPercent = Math.abs(100-percentVal);
            if(remainingPercent > 0){
                var prevCompIdGrantee = parseFloat($j("#"+percentCompIdFinal+"_granteeprev").val());
                var prevCompIdGranteeInKind = parseFloat($j("#"+percentCompIdFinal+"_granteeinkindprev").val());
                var totalValueRemaimingComps = prevCompIdGrantee + prevCompIdGranteeInKind;
                if(totalValueRemaimingComps > 0){
                    var granteePercent = parseFloat((prevCompIdGrantee/totalValueRemaimingComps)*remainingPercent);
                }else{
                    var granteePercent = 0;
                }
                //granteePercent = Math.round(granteePercent);
                var granteeInkindPercent = Math.abs(remainingPercent-granteePercent);
            }else{
                var granteePercent = 0;
                var granteeInkindPercent = 0;
            }
            
            $j("#"+percentCompIdFinal+"_cncsprev").val(percentVal.toFixed(2));
            $j("#"+percentCompIdFinal+"_granteeprev").val(granteePercent.toFixed(2));
            $j("#"+percentCompIdFinal+"_granteeinkindprev").val(granteeInkindPercent.toFixed(2));

            var checkTotalChangeExists = $j("#trsimple-total"+displayCompCountFinal+"_input").val();

            if($j('#'+percentCompIdFinal+'_cncs').val() == (percentVal).toFixed(2) && checkTotalChangeExists == 0){
                $j(".trsimple_percent_"+percentCompIdFinal+" input").css("color","black");
                $j("#trsimple-percent"+displayCompCountFinal+"_input").val(0);
            }else{
                $j(".trsimple_percent_"+percentCompIdFinal+" input").css("color","#C70404");
                $j(".trsimple_percent_"+percentCompIdFinal).show();
                $j("#trsimple-percent"+displayCompCountFinal+"_input").val(1);
            }

        }else if(BudgetInccontributedFor == 'grantee'){
            var totalFinal = contributedForFinalTotal + parseFloat(removeCommaSep($j("#"+finalComp+"_cncsprev").val())) + parseFloat(removeCommaSep($j("#"+finalComp+"_granteeinkindprev").val()))
            $j("#"+finalComp+"_totalprev").val(addCommaSep(totalFinal.toFixed(2)));

            var granteeTotal = removeCommaSep($j('#'+finalComp+'_grantee').val());
            var granteeinkindTotal = removeCommaSep($j('#'+finalComp+'_granteeinkind').val());
            if($j("#editedField").val() == 'grantee' && granteeTotal == removeCommaSep($j('#'+finalComp+'_granteeprev').val()) && granteeinkindTotal == removeCommaSep($j('#'+finalComp+'_granteeinkindprev').val())){
                $j(".input-cncs").attr('readonly', false);
                //$j(".input-cncs_Section3").attr('readonly', false);
                $j(".input-cncs").each(function(){ 
                    if($j(this).hasClass('input-readonly')){
                        $j(this).attr('readonly', true);
                    }else{
                        $j(this).attr('readonly', false);
                    }
                });
                $j("#editedField").val('');
                $j(".reconcile-grantee").html('-');
                $j(".reconcile-grantee-secIII").css("display","none");
                $j(".or-text-grantee").css("display","none");
            }

            if(removeCommaSep($j('#'+finalComp+'_total').val()) == (totalFinal).toFixed(2)){
                //$j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                //$j(".trsimple_total_"+finalCompId).hide();
                $j(".trsimple_total_"+finalComp+" input").css("color","black");
                $j("#trsimple-total"+displayCompCountFinal+"_input").val(0);
                $j(".submit-button").attr("type", "submit");
                $j(".submit-button").removeClass("disabled");
                $j(".resubmit-button").attr("type", "submit");
                $j(".resubmit-button").removeClass("disabled");
                $j("#"+finalComp+"_changespan").empty();
                $j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED');
                $j(".changevaluesummary_"+finalComp).html('-');
                var calChangeValue = false;
            }else{
               // $j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                $j(".trsimple_total_"+finalComp).show();
                $j(".trsimple_total_"+finalComp+" input").css("color","#C70404");
                $j("#trsimple-total"+displayCompCountFinal+"_input").val(1);
                $j(".submit-button").attr("type", "button");
                $j(".submit-button").addClass("disabled");
                $j(".resubmit-button").attr("type", "button");
                $j(".resubmit-button").addClass("disabled");
                $j("#"+finalComp+"_changespan").empty();
                $j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED');
                //$j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED <p style="color:red;font-style:italic;text-transform: none;font-size: 11px;">Difference to Reconcile</p>'); FR-212
                var calChangeValue = true;
            }  

            //percent
            if(totalFinal > 0){
                var percentVal = (contributedForFinalTotal/totalFinal)*100;
            }else{
                var percentVal = 0;
            }
            var remainingPercent = Math.abs(100-percentVal);
            if(remainingPercent > 0){
                var prevCompIdCncs = parseFloat($j("#"+percentCompIdFinal+"_cncsprev").val());
                var prevCompIdGranteeInKind = parseFloat($j("#"+percentCompIdFinal+"_granteeinkindprev").val());
                var totalValueRemaimingComps = prevCompIdCncs + prevCompIdGranteeInKind;
                if(totalValueRemaimingComps > 0){
                    var cncsPercent = parseFloat((prevCompIdCncs/totalValueRemaimingComps)*remainingPercent);
                }else{
                    var cncsPercent = 0;
                }
                //granteePercent = Math.round(granteePercent);
                var granteeInkindPercent = Math.abs(remainingPercent-cncsPercent);
            }else{
                var cncsPercent = 0;
                var granteeInkindPercent = 0;
            }

            $j("#"+percentCompIdFinal+"_cncsprev").val(cncsPercent.toFixed(2));
            $j("#"+percentCompIdFinal+"_granteeprev").val(percentVal.toFixed(2));
            $j("#"+percentCompIdFinal+"_granteeinkindprev").val(granteeInkindPercent.toFixed(2));

            var checkTotalChangeExists = $j("#trsimple-total"+displayCompCountFinal+"_input").val();

            if($j('#'+percentCompIdFinal+'_grantee').val() == (percentVal).toFixed(2) && checkTotalChangeExists == 0){
                $j(".trsimple_percent_"+percentCompIdFinal+" input").css("color","black");
                $j("#trsimple-percent"+displayCompCountFinal+"_input").val(0);
            }else{
                $j(".trsimple_percent_"+percentCompIdFinal+" input").css("color","#C70404");
                $j(".trsimple_percent_"+percentCompIdFinal).show();
                $j("#trsimple-percent"+displayCompCountFinal+"_input").val(1);
            }
        }else if(BudgetInccontributedFor == 'granteeinkind'){
            /*var totalFinal = contributedForFinalTotal + parseFloat($j("#"+finalComp+"_granteeprev").val()) + parseFloat($j("#"+finalComp+"_cncsprev").val())
            $j("#"+finalComp+"_totalprev").val(totalFinal.toFixed(2));

            if($j('#'+finalComp+'_total').val() == (totalFinal).toFixed(2)){
                //$j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                //$j(".trsimple_total_"+finalCompId).hide();
                $j(".trsimple_total_"+finalComp+" input").css("color","black");
                $j("#trsimple-total"+displayCompCountFinal+"_input").val(0);
                $j(".submit-button").attr("type", "submit");
                $j(".submit-button").removeClass("disabled");
                $j(".resubmit-button").attr("type", "submit");
                $j(".resubmit-button").removeClass("disabled");
                $j("#"+finalComp+"_changespan").empty();
                $j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED');
                $j(".changevaluesummary_"+finalComp).html('-');
                var calChangeValue = false;
            }else{
               // $j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                $j(".trsimple_total_"+finalComp).show();
                $j(".trsimple_total_"+finalComp+" input").css("color","red");
                $j("#trsimple-total"+displayCompCountFinal+"_input").val(1);
                $j(".submit-button").attr("type", "button");
                $j(".submit-button").addClass("disabled");
                $j(".resubmit-button").attr("type", "button");
                $j(".resubmit-button").addClass("disabled");
                $j("#"+finalComp+"_changespan").empty();
                $j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED');
                //$j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED <p style="color:red;font-style:italic;text-transform: none;font-size: 11px;">Difference to Reconcile</p>');
                var calChangeValue = true;
            }  

            //percent
            if(totalFinal > 0){
                var percentVal = (contributedForFinalTotal/totalFinal)*100;
            }else{
                var percentVal = 0;
            }
            var remainingPercent = Math.abs(100-percentVal);
            if(remainingPercent > 0){
                var prevCompIdCncs = parseFloat($j("#"+percentCompIdFinal+"_cncsprev").val());
                var prevCompIdGrantee = parseFloat($j("#"+percentCompIdFinal+"_granteeprev").val());
                var totalValueRemaimingComps = prevCompIdCncs + prevCompIdGrantee;
                var cncsPercent = parseFloat((prevCompIdCncs/totalValueRemaimingComps)*remainingPercent);
                //granteePercent = Math.round(granteePercent);
                var granteePercent = Math.abs(remainingPercent-cncsPercent);
            }else{
                var cncsPercent = 0;
                var granteePercent = 0;
            }

            $j("#"+percentCompIdFinal+"_cncsprev").val(cncsPercent.toFixed(2));
            $j("#"+percentCompIdFinal+"_granteeprev").val(granteePercent.toFixed(2));
            $j("#"+percentCompIdFinal+"_granteeinkindprev").val(percentVal.toFixed(2));

            var checkTotalChangeExists = $j("#trsimple-total"+displayCompCountFinal+"_input").val();

            if($j('#'+percentCompIdFinal+'_granteeinkind').val() == (percentVal).toFixed(2) && checkTotalChangeExists == 0){
                $j(".trsimple_percent_"+percentCompIdFinal+" input").css("color","black");
                $j("#trsimple-percent"+displayCompCountFinal+"_input").val(0);
            }else{
                $j(".trsimple_percent_"+percentCompIdFinal+" input").css("color","red");
                $j(".trsimple_percent_"+percentCompIdFinal).show();
                $j("#trsimple-percent"+displayCompCountFinal+"_input").val(1);
            }*/
            /* as total does not use granteeinkind instead any value entered in grantee in kind for budget increase will be considered as grantee cash 
            here we should use grantee code*/
            var totalFinal = contributedForFinalTotal + parseFloat(removeCommaSep($j("#"+finalComp+"_cncsprev").val())) + parseFloat(removeCommaSep($j("#"+finalComp+"_granteeinkindprev").val()))
            $j("#"+finalComp+"_totalprev").val(addCommaSep(totalFinal.toFixed(2)));

            var granteeTotal = removeCommaSep($j('#'+finalComp+'_grantee').val());
            var granteeinkindTotal = removeCommaSep($j('#'+finalComp+'_granteeinkind').val());
            if($j("#editedField").val() == 'grantee' && granteeTotal == removeCommaSep($j('#'+finalComp+'_granteeprev').val()) && granteeinkindTotal == removeCommaSep($j('#'+finalComp+'_granteeinkindprev').val())){
                $j(".input-cncs").attr('readonly', false);
                //$j(".input-cncs_Section3").attr('readonly', false);
                $j(".input-cncs").each(function(){ 
                    if($j(this).hasClass('input-readonly')){
                        $j(this).attr('readonly', true);
                    }else{
                        $j(this).attr('readonly', false);
                    }
                });
                $j("#editedField").val('');
                $j(".reconcile-grantee").html('-');
                $j(".reconcile-grantee-secIII").css("display","none");
                $j(".or-text-grantee").css("display","none");
            }

            if(removeCommaSep($j('#'+finalComp+'_total').val()) == (totalFinal).toFixed(2)){
                //$j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                //$j(".trsimple_total_"+finalCompId).hide();
                $j(".trsimple_total_"+finalComp+" input").css("color","black");
                $j("#trsimple-total"+displayCompCountFinal+"_input").val(0);
                $j(".submit-button").attr("type", "submit");
                $j(".submit-button").removeClass("disabled");
                $j(".resubmit-button").attr("type", "submit");
                $j(".resubmit-button").removeClass("disabled");
                $j("#"+finalComp+"_changespan").empty();
                $j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED');
                $j(".changevaluesummary_"+finalComp).html('-');
                var calChangeValue = false;
            }else{
               // $j('#'+finalCompId+'_total').val(finalTotal.toFixed(2));
                $j(".trsimple_total_"+finalComp).show();
                $j(".trsimple_total_"+finalComp+" input").css("color","#C70404");
                $j("#trsimple-total"+displayCompCountFinal+"_input").val(1);
                $j(".submit-button").attr("type", "button");
                $j(".submit-button").addClass("disabled");
                $j(".resubmit-button").attr("type", "button");
                $j(".resubmit-button").addClass("disabled");
                $j("#"+finalComp+"_changespan").empty();
                $j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED');
                //$j("#"+finalComp+"_changespan").append('TOTAL AS MODIFIED <p style="color:red;font-style:italic;text-transform: none;font-size: 11px;">Difference to Reconcile</p>'); FR-212
                var calChangeValue = true;
            }  

            //percent
            if(totalFinal > 0){
                var percentVal = (contributedForFinalTotal/totalFinal)*100;
            }else{
                var percentVal = 0;
            }
            var remainingPercent = Math.abs(100-percentVal);
            if(remainingPercent > 0){
                var prevCompIdCncs = parseFloat($j("#"+percentCompIdFinal+"_cncsprev").val());
                var prevCompIdGranteeInKind = parseFloat($j("#"+percentCompIdFinal+"_granteeinkindprev").val());
                var totalValueRemaimingComps = prevCompIdCncs + prevCompIdGranteeInKind;
                if(totalValueRemaimingComps > 0){
                    var cncsPercent = parseFloat((prevCompIdCncs/totalValueRemaimingComps)*remainingPercent);
                }else{
                    var cncsPercent = 0;
                }
                //granteePercent = Math.round(granteePercent);
                var granteeInkindPercent = Math.abs(remainingPercent-cncsPercent);
            }else{
                var cncsPercent = 0;
                var granteeInkindPercent = 0;
            }

            $j("#"+percentCompIdFinal+"_cncsprev").val(cncsPercent.toFixed(2));
            $j("#"+percentCompIdFinal+"_granteeprev").val(percentVal.toFixed(2));
            $j("#"+percentCompIdFinal+"_granteeinkindprev").val(granteeInkindPercent.toFixed(2));

            var checkTotalChangeExists = $j("#trsimple-total"+displayCompCountFinal+"_input").val();

            if($j('#'+percentCompIdFinal+'_grantee').val() == (percentVal).toFixed(2) && checkTotalChangeExists == 0){
                $j(".trsimple_percent_"+percentCompIdFinal+" input").css("color","black");
                $j("#trsimple-percent"+displayCompCountFinal+"_input").val(0);
            }else{
                $j(".trsimple_percent_"+percentCompIdFinal+" input").css("color","#C70404");
                $j(".trsimple_percent_"+percentCompIdFinal).show();
                $j("#trsimple-percent"+displayCompCountFinal+"_input").val(1);
            }
        }
        if(calChangeValue){
            var cncsChangeValue = 0;
            var granteeChangeValue = 0;
            var granteeinkindChangeValue = 0;
            var totalChangeValue = 0;
            
            var cncs_value = removeCommaSep($j('#'+finalComp+'_cncs').val());
            var cncsprev_value = removeCommaSep($j('#'+finalComp+'_cncsprev').val());
            if(cncs_value != ''){
                cncs_value = parseFloat(cncs_value);
            }else{
                if(cncsprev_value != ''){
                    cncs_value = parseFloat(cncsprev_value);
                }else{
                    cncs_value = 0;
                }
            }
            if(cncs_value > 0){
                cncsChangeValue =  cncs_value - cncsprev_value;
            }
            if(cncsprev_value > 0){
                var cncsChangePercent = (cncsChangeValue/cncsprev_value)*100;
            }else{
                var cncsChangePercent = cncsChangeValue;
            }

            if(cncsChangeValue > 0){
                $j("#changevaluesummarycncs_"+finalComp).html('+$'+addCommaSep(cncsChangeValue.toFixed(2)));
                if(cncsChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarycncs_"+finalComp).html('('+cncsChangePercent.toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarycncs_"+finalComp).html('(+'+cncsChangePercent.toFixed(2)+'%)');
                } 
            }else if(cncsChangeValue == 0){
                $j("#changevaluesummarycncs_"+finalComp).html('');
                $j("#changepercentsummarycncs_"+finalComp).html('');
            }else{
                $j("#changevaluesummarycncs_"+finalComp).html('-$'+addCommaSep(Math.abs(cncsChangeValue).toFixed(2)));
                if(cncsChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarycncs_"+finalComp).html('('+Math.abs(cncsChangePercent).toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarycncs_"+finalComp).html('(-'+Math.abs(cncsChangePercent).toFixed(2)+'%)');
                } 
            }

            var grantee_value = removeCommaSep($j('#'+finalComp+'_grantee').val());
            var granteeprev_value = removeCommaSep($j('#'+finalComp+'_granteeprev').val());
            if(grantee_value != ''){
                grantee_value = parseFloat(grantee_value);
            }else{
                if(granteeprev_value != ''){
                    grantee_value = parseFloat(granteeprev_value);
                }else{
                    grantee_value = 0;
                }
            }
            if(grantee_value > 0){
                granteeChangeValue = grantee_value - granteeprev_value;
            }
            if(granteeprev_value > 0){
                var granteeChangePercent = (granteeChangeValue/granteeprev_value)*100;
            }else{
                var granteeChangePercent = granteeChangeValue;
            }
            if(granteeChangeValue > 0){
                $j("#changevaluesummarygrantee_"+finalComp).html('+$'+addCommaSep(granteeChangeValue.toFixed(2)));
                if(granteeChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarygrantee_"+finalComp).html('('+granteeChangePercent.toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarygrantee_"+finalComp).html('(+'+granteeChangePercent.toFixed(2)+'%)');
                } 
            }else if(granteeChangeValue == 0){
                $j("#changevaluesummarygrantee_"+finalComp).html('');
                $j("#changepercentsummarygrantee_"+finalComp).html('');
            }else{
                $j("#changevaluesummarygrantee_"+finalComp).html('-$'+addCommaSep(Math.abs(granteeChangeValue).toFixed(2)));
                if(granteeChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarygrantee_"+finalComp).html('('+Math.abs(granteeChangePercent).toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarygrantee_"+finalComp).html('(-'+Math.abs(granteeChangePercent).toFixed(2)+'%)');
                } 
            }

            var granteeinkind_value = removeCommaSep($j('#'+finalComp+'_granteeinkind').val());
            var granteeinkindprev_value = removeCommaSep($j('#'+finalComp+'_granteeinkindprev').val());
            if(granteeinkind_value != ''){
                granteeinkind_value = parseFloat(granteeinkind_value);
            }else{
                if(granteeinkindprev_value != ''){
                    granteeinkind_value = parseFloat(granteeinkindprev_value);
                }else{
                    granteeinkind_value = 0;
                }
            }
            //if(granteeinkind_value > 0){
                granteeinkindChangeValue =  granteeinkind_value - granteeinkindprev_value;
            //}
            if(granteeinkindprev_value > 0){
                var granteeinkindChangePercent = (granteeinkindChangeValue/granteeinkindprev_value)*100;
            }else{
                var granteeinkindChangePercent = granteeinkindChangeValue;
            }
            if(granteeinkindChangeValue > 0){
                $j("#changevaluesummarygranteeinkind_"+finalComp).html('+$'+addCommaSep(granteeinkindChangeValue.toFixed(2)));
                if(granteeinkindChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarygranteeinkind_"+finalComp).html('('+granteeinkindChangePercent.toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarygranteeinkind_"+finalComp).html('(+'+granteeinkindChangePercent.toFixed(2)+'%)');
                }        
            }else if(granteeinkindChangeValue == 0){
                $j("#changevaluesummarygranteeinkind_"+finalComp).html('');
                $j("#changepercentsummarygranteeinkind_"+finalComp).html('');
            }else{
                $j("#changevaluesummarygranteeinkind_"+finalComp).html('-$'+addCommaSep(Math.abs(granteeinkindChangeValue).toFixed(2)));
                if(granteeinkindChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarygranteeinkind_"+finalComp).html('('+Math.abs(granteeinkindChangePercent).toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarygranteeinkind_"+finalComp).html('(-'+Math.abs(granteeinkindChangePercent).toFixed(2)+'%)');
                }  
            }

            var total_value = removeCommaSep($j('#'+finalComp+'_total').val());
            var totalprev_value = removeCommaSep($j('#'+finalComp+'_totalprev').val());
            if(total_value != ''){
                total_value = parseFloat(total_value);
            }else{
                if(totalprev_value != ''){
                    total_value = parseFloat(totalprev_value);
                }else{
                    total_value = 0;
                }
            }
            if(total_value > 0){
                totalChangeValue =  total_value - totalprev_value;
            }
            if(totalprev_value > 0){
                var totalChangePercent = (totalChangeValue/totalprev_value)*100;
            }else{
                var totalChangePercent = totalChangeValue;
            }
            if(totalChangeValue > 0){
                $j("#changevaluesummarytotal_"+finalComp).html('+$'+addCommaSep(totalChangeValue.toFixed(2)));
                if(totalChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarytotal_"+finalComp).html('('+totalChangePercent.toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarytotal_"+finalComp).html('(+'+totalChangePercent.toFixed(2)+'%)');
                }  
            }else if(totalChangeValue == 0){
                $j("#changevaluesummarytotal_"+finalComp).html('');
                $j("#changepercentsummarytotal_"+finalComp).html('');
            }else{
                $j("#changevaluesummarytotal_"+finalComp).html('-$'+addCommaSep(Math.abs(totalChangeValue).toFixed(2)));
                if(totalChangePercent.toFixed(2) == 0){
                    $j("#changepercentsummarytotal_"+finalComp).html('('+Math.abs(totalChangePercent).toFixed(2)+'%)');
                }else{
                    $j("#changepercentsummarytotal_"+finalComp).html('(-'+Math.abs(totalChangePercent).toFixed(2)+'%)');
                }
            }
        }

        $j("#budgetIncrease"+BudgetInccontributedFor+"_prev").val(addCommaSep(inputBudgetIncValue));
    }

    if(BudgetInccontributedFor == 'cncs' || BudgetInccontributedFor == 'grantee'){
        calculateExactAmountToReconcile(BudgetInccontributedFor)
        if(BudgetInccontributedFor == 'cncs'){ // fix for issue - When we removes the cncs value in budget inc section so the reconcile amount persists for grantee
            calculateExactAmountToReconcile('grantee')
        }
    }else{
        calculateExactAmountToReconcile('grantee')
    }
}

function calculateExactAmountToReconcile(BudgetInccontributedFor){
    var sec1SubId = $j("#sec1Sub").val();
    var sec2SubId = $j("#sec2Sub").val();
    var sec3Sub = $j("#sec3Sub").val();
    var finalCompId = $j("#finalCompId").val();
    var SectionITotal_Total = removeCommaSep($j('#'+sec1SubId+'_total').val());
    var SectionIITotal_Total = removeCommaSep($j('#'+sec2SubId+'_total').val());
    var SectionIIITotal_prev = removeCommaSep($j('#'+sec3Sub+'_totalprev').val());
    if(SectionIITotal_Total == NaN || SectionIITotal_Total == 'NaN' || isNaN(SectionIITotal_Total)){
        SectionIITotal_Total = 0.00;
    }
    var sec1SubVal = 0;
    var sec2SubVal = 0;
    var sec1and2TotalVal = 0;
    var finalCompVal = 0;
    var SectionIandIITotal_Total = 0;
    var corfa = $j('#corfa').val();
    var comfa = $j('#comfa').val();
    var icr = $j('#icr').val();
    var cfa = $j('#cfa').val();
    
    var fundingStructureName = $j("#FundingStructureName").val();
    var FundingStructureBudgetType = $j("#FundingStructureBudgetType").val();
    var indirectCostRatePercentCalc = parseFloat($j("#indirectCostRatePercentCalc").val()); //0.8
    var programFixedPercentCalc = parseFloat($j("#programFixedPercentCalc").val()); //0.8
    var noCalCulationForGranteeShare = $j("#noCalCulationForGranteeShare").val();
    var commissionFixedPercentCalc = parseFloat($j("#commissionFixedPercentCalc").val()); //0.2
    var maxAmountAmericorpShare = parseFloat($j("#maxAmountAmericorpShare").val()); //0.0526
    var maxAmountRequestAsGranteeShare = parseFloat($j("#maxAmountRequestAsGranteeShare").val()); //0.1
    var subtractCorfaWithSec3Acfs = parseFloat($j("#subtractCorfaWithSec3Acfs").val());
    var corfa_icrZeroInclude = parseFloat($j("#corfa_icrZeroInclude").val()); // It is for indirectCostRatePercentCalc, programFixedPercentCalc
    var comfa_cfaZeroInclude = parseFloat($j("#comfa_cfaZeroInclude").val()); // It is for commissionFixedPercentCalc
    var mxGranteeShareZeroInclude = parseFloat($j("#mxGranteeShareZeroInclude").val()); // It is for maxAmountRequestAsGranteeShare

    var calccorfaSimple = 0;
    var calccorfaX = 0;
    var calccomfaSimple= 0 ;
    var calccomfaX = 0;

    var useSection3 = true;
    if(FundingStructureBudgetType == 'Fixed'){
        if($j("#useSectionIII").val() == 0){
            useSection3 = false;
        }
    }
    
    var reconcileBySection3 = false;
    if(useSection3 && sec3Sub != undefined){
        if(fundingStructureName == 'NonIndirect'){
            if(BudgetInccontributedFor == 'cncs'){
                //to check if expenses are greater than budget value.
                var expensesCorfa = removeCommaSep($j("#"+corfa+"_cncsexpense").val());
                if(expensesCorfa != ''){
                    expensesCorfa = parseFloat(expensesCorfa);
                }else{
                    expensesCorfa = 0;
                }
                var calccorfa = removeCommaSep($j("#"+corfa+"_cncs").val());
                if(calccorfa != ''){
                    calccorfa = parseFloat(calccorfa);
                }else{
                    calccorfa = parseFloat(removeCommaSep($j("#"+corfa+"_cncsprev").val()));
                }
                if(calccorfa > 0 && calccorfa > expensesCorfa){
                    reconcileBySection3 = true;
                }

                var expensesComfa = removeCommaSep($j("#"+comfa+"_cncsexpense").val());
                if(expensesComfa != ''){
                    expensesComfa = parseFloat(expensesComfa);
                }else{
                    expensesComfa = 0;
                }
                var calccomfa = removeCommaSep($j("#"+comfa+"_cncs").val());
                if(calccomfa != ''){
                    calccomfa = parseFloat(calccomfa);
                }else{
                    calccomfa = parseFloat(removeCommaSep($j("#"+comfa+"_cncsprev").val()));
                }
                if(calccomfa > 0 && calccomfa > expensesComfa){
                    reconcileBySection3 = true;
                }
            }else if(BudgetInccontributedFor == 'grantee'){
                var expensesCorfa = removeCommaSep($j("#"+corfa+"_granteeexpense").val());
                if(expensesCorfa != ''){
                    expensesCorfa = parseFloat(expensesCorfa);
                }else{
                    expensesCorfa = 0;
                }
                var calccorfa = removeCommaSep($j("#"+corfa+"_grantee").val());
                if(calccorfa != ''){
                    calccorfa = parseFloat(calccorfa);
                }else{
                    calccorfa = parseFloat(removeCommaSep($j("#"+corfa+"_granteeprev").val()));
                }
                if(calccorfa > 0 && calccorfa > expensesCorfa){
                    reconcileBySection3 = true;
                }
            }
        }else if(fundingStructureName == 'Indirect'){
            if(BudgetInccontributedFor == 'cncs'){
                //to check if expenses are greater than budget value.
                var expensesIcr = removeCommaSep($j("#"+icr+"_cncsexpense").val());
                if(expensesIcr != ''){
                    expensesIcr = parseFloat(expensesIcr);
                }else{
                    expensesIcr = 0;
                }
                var calcicr = removeCommaSep($j("#"+icr+"_cncs").val());
                if(calcicr != ''){
                    calcicr = parseFloat(calcicr);
                }else{
                    calcicr = parseFloat(removeCommaSep($j("#"+icr+"_cncsprev").val()));
                }
                if(calcicr > 0 && calcicr > expensesIcr){
                    reconcileBySection3 = true;
                }

                var expensesCfa = removeCommaSep($j("#"+cfa+"_cncsexpense").val());
                if(expensesCfa != ''){
                    expensesCfa = parseFloat(expensesCfa);
                }else{
                    expensesCfa = 0;
                }
                var calccfa = removeCommaSep($j("#"+cfa+"_cncs").val());
                if(calccfa != ''){
                    calccfa = parseFloat(calccfa);
                }else{
                    calccfa = parseFloat(removeCommaSep($j("#"+cfa+"_cncsprev").val()));
                }
                if(calccfa > 0 && calccfa > expensesCfa){
                    reconcileBySection3 = true;
                }
            }else if(BudgetInccontributedFor == 'grantee'){
                var expensesIcr = removeCommaSep($j("#"+icr+"_granteeexpense").val());
                if(expensesIcr != ''){
                    expensesIcr = parseFloat(expensesIcr);
                }else{
                    expensesIcr = 0;
                }
                var calcicr = removeCommaSep($j("#"+icr+"_grantee").val());
                if(calcicr != ''){
                    calcicr = parseFloat(calcicr);
                }else{
                    calcicr = parseFloat(removeCommaSep($j("#"+icr+"_granteeprev").val()));
                }
                if(calcicr > 0 && calcicr > expensesIcr){
                    reconcileBySection3 = true;
                }
            }
        }
    }

    if(reconcileBySection3){
        var editedSectionVal = $j("#editedSection").val();
        if(editedSectionVal == 'section3' || $j('#sec3AutoAdjust').val() == 0){ //This condition is for the case when we enter value in budget increase and concludes if it needs to reconciled by section3 or not
            if(BudgetInccontributedFor == 'cncs' && removeCommaSep($j("#"+sec3Sub+"_cncsprev").val()) == removeCommaSep($j("#"+sec3Sub+"_cncs").val())){
                reconcileBySection3 = false;
            }else if(BudgetInccontributedFor == 'grantee' && removeCommaSep($j("#"+sec3Sub+"_granteeprev").val()) == removeCommaSep($j("#"+sec3Sub+"_grantee").val())){
                reconcileBySection3 = false;
            }else if(removeCommaSep($j("#"+sec3Sub+"_totalprev").val()) == removeCommaSep($j("#"+sec3Sub+"_total").val())){
                reconcileBySection3 = false;
            }
        }
    }

    if(useSection3 && sec3Sub != undefined && reconcileBySection3){
        sec1SubVal = removeCommaSep($j("#"+sec1SubId+"_"+BudgetInccontributedFor).val());
        if(sec1SubVal == ''){
            sec1SubVal = removeCommaSep($j("#"+sec1SubId+"_"+BudgetInccontributedFor+"prev").val());
        }
        sec2SubVal = removeCommaSep($j("#"+sec2SubId+"_"+BudgetInccontributedFor).val());
        if(sec2SubVal == ''){
            sec2SubVal = removeCommaSep($j("#"+sec2SubId+"_"+BudgetInccontributedFor+"prev").val());
        }
        if(sec2SubVal == undefined || sec2SubVal == 'undefined'){
            sec2SubVal = 0;
        }

        sec1and2TotalVal = parseFloat(sec1SubVal) + parseFloat(sec2SubVal);

        if(SectionITotal_Total != ''){
            SectionITotal_Total = parseFloat(SectionITotal_Total);
        }else{
            SectionITotal_Total = parseFloat(removeCommaSep($j("#"+sec1SubId+"_totalprev").val()));
        }
    
        if(SectionIITotal_Total != ''){
            SectionIITotal_Total = parseFloat(SectionIITotal_Total);
        }else{
            SectionIITotal_Total = parseFloat(removeCommaSep($j("#"+sec2SubId+"_totalprev").val()));
        }

        if(SectionIITotal_Total == NaN || SectionIITotal_Total == 'NaN' || isNaN(SectionIITotal_Total)){
            SectionIITotal_Total = 0.00;
        }

        SectionIandIITotal_Total = SectionITotal_Total + SectionIITotal_Total;
        var finalValToAdjust = 0;
        if(fundingStructureName == 'NonIndirect'){
            if(BudgetInccontributedFor == 'cncs'){

                finalCompVal = removeCommaSep($j("#"+finalCompId+"_"+BudgetInccontributedFor+"prev").val());
                if(finalCompVal == ''){
                    finalCompVal = removeCommaSep($j("#"+finalCompId+"_"+BudgetInccontributedFor).val());
                }
                finalCompVal = parseFloat(finalCompVal);

                if(maxAmountAmericorpShare != 0){
                    //calccorfa = (((SectionITotal+SectionIITotal)*0.0526)*0.8).toFixed(2);
                    //calccomfa = (((SectionITotal+SectionIITotal)*0.0526)*0.2).toFixed(2);
                    if(programFixedPercentCalc != 0 || corfa_icrZeroInclude == 1){
                        calccorfaSimple = (sec1and2TotalVal*maxAmountAmericorpShare*programFixedPercentCalc);
                        calccorfaX = (maxAmountAmericorpShare*programFixedPercentCalc);
                    }else{
                        calccorfaSimple = (sec1and2TotalVal*maxAmountAmericorpShare);
                        calccorfaX = (maxAmountAmericorpShare);
                    }

                    if(commissionFixedPercentCalc != 0 || comfa_cfaZeroInclude == 1){
                        calccomfaSimple = (sec1and2TotalVal*maxAmountAmericorpShare*commissionFixedPercentCalc);
                        calccomfaX = (maxAmountAmericorpShare*commissionFixedPercentCalc);
                    }else{
                        calccomfaSimple = (sec1and2TotalVal*maxAmountAmericorpShare);
                        calccomfaX = (maxAmountAmericorpShare);
                    }
                }else{
                    if(programFixedPercentCalc != 0 || corfa_icrZeroInclude == 1){
                        calccorfaSimple = (sec1and2TotalVal*programFixedPercentCalc);
                    }else{
                        calccorfaX = (0).toFixed(2);
                    }

                    if(commissionFixedPercentCalc != 0 || comfa_cfaZeroInclude == 1){
                        calccomfaSimple = (sec1and2TotalVal*commissionFixedPercentCalc);
                    }else{
                        calccomfaX = (0).toFixed(2);
                    }
                }

                var simpleFinal = parseFloat(calccomfaSimple) + parseFloat(calccorfaSimple) + sec1and2TotalVal;
                var xFinal = parseFloat(calccorfaX) + parseFloat(calccomfaX) + 1;
                var finalAmount = parseFloat(finalCompVal) - simpleFinal;
                //finalAmount = finalAmount.toString().match(/^-?\d+(?:\.\d{0,3})?/)[0]
                finalAmount = parseFloat(finalAmount)
                //xFinal = xFinal.toString().match(/^-?\d+(?:\.\d{0,3})?/)[0]
                //xFinal = parseFloat(xFinal);
                if(xFinal > 0){
                    finalValToAdjust = finalAmount / xFinal;
                }else{
                    finalValToAdjust = 0;
                }
                // logic manage .1 difference
                var finalValToAdjustString = finalValToAdjust.toString().match(/^-?\d+(?:\.\d{0,2})?/)[0]
                var finalValToAdjustWholeNumber = finalValToAdjustString.split(".");
                if(Math.abs(parseFloat(finalValToAdjustWholeNumber[1])) <= 50){
                    finalValToAdjust = parseFloat(finalValToAdjustString);
                }else{
                    finalValToAdjust = finalValToAdjust.toFixed(2);
                    finalValToAdjust = Math.round(finalValToAdjust);
                }    
                
                var finalCompVal = removeCommaSep($j("#"+finalCompId+"_cncs").val());
                var finaCompPrevVal = parseFloat(removeCommaSep($j("#"+finalCompId+"_cncsprev").val()));
                if(finalCompVal != ''){
                    finalCompVal = parseFloat(finalCompVal);
                }else{
                    finalCompVal = finaCompPrevVal;
                }
                var finalValToAdjustInSec3 = finaCompPrevVal - finalCompVal;
                // logic manage .1 difference

               //finalValToAdjust = finalValToAdjust.toFixed(2);
               
            }else if(BudgetInccontributedFor == 'grantee'){

                finalCompVal = removeCommaSep($j("#"+finalCompId+"_totalprev").val());
                if(finalCompVal == ''){
                    finalCompVal = removeCommaSep($j("#"+finalCompId+"_total").val());
                }
                finalCompVal = parseFloat(finalCompVal);

                if(noCalCulationForGranteeShare == 0){
                    if(maxAmountRequestAsGranteeShare != 0 || mxGranteeShareZeroInclude == 1){
                        //calccorfa = ((SectionITotal+SectionIITotal)*0.1).toFixed(2);
                        if(subtractCorfaWithSec3Acfs == 1){
                            var cncsSubtotaSection3 = removeCommaSep($j("#"+sec3Sub+"_cncs").val());
                            if(cncsSubtotaSection3 != ''){
                                cncsSubtotaSection3 = parseFloat(cncsSubtotaSection3);
                            }else{
                                cncsSubtotaSection3 = parseFloat(removeCommaSep($j("#"+sec3Sub+"_cncsprev").val()));
                            }
                        }else{
                            var cncsSubtotaSection3 = 0;
                        }
                        calccorfaSimple = (SectionIandIITotal_Total*maxAmountRequestAsGranteeShare)-cncsSubtotaSection3;
                        calccorfaX = maxAmountRequestAsGranteeShare;
                    }else{
                        calccorfaSimple = (0).toFixed(2);
                        calccorfaX = (0).toFixed(2);
                    }
                }
                calccomfaSimple = 0;
                var comfaGranteeVal = removeCommaSep($j("#"+comfa+"_grantee").val());
                if(comfaGranteeVal == ''){
                    comfaGranteeVal = removeCommaSep($j("#"+comfa+"_granteeprev").val());
                }
                calccomfaSimple = comfaGranteeVal;
                calccomfaX = 0;

                var simpleFinal = parseFloat(calccomfaSimple) + parseFloat(calccorfaSimple) + SectionIandIITotal_Total;
                var xFinal = parseFloat(calccorfaX) + parseFloat(calccomfaX) + 1;
                var sec3cncstotal = removeCommaSep($j("#"+sec3Sub+"_cncs").val());
                if(sec3cncstotal != ''){
                    sec3cncstotal = parseFloat(sec3cncstotal);
                }else{
                    sec3cncstotal = parseFloat(removeCommaSep($j("#"+sec3Sub+"_cncsprev").val()))
                }
                var finalAmount = (parseFloat(finalCompVal) - sec3cncstotal) - simpleFinal;
                //finalAmount = finalAmount.toFixed(3);

                if(xFinal > 0){
                    finalValToAdjust = finalAmount / xFinal;
                }else{
                    finalValToAdjust = 0;
                }

                // logic manage .1 difference
                var finalValToAdjustString = finalValToAdjust.toString().match(/^-?\d+(?:\.\d{0,2})?/)[0]
                var finalValToAdjustWholeNumber = finalValToAdjustString.split(".");
                if(Math.abs(parseFloat(finalValToAdjustWholeNumber[1])) <= 50){
                    finalValToAdjust = parseFloat(finalValToAdjustString);
                }else{
                    finalValToAdjust = finalValToAdjust.toFixed(2);
                    finalValToAdjust = Math.round(finalValToAdjust);
                }
                var finalCompVal = removeCommaSep($j("#"+finalCompId+"_grantee").val());
                var finaCompPrevVal = parseFloat(removeCommaSep($j("#"+finalCompId+"_granteeprev").val()));
                if(finalCompVal != ''){
                    finalCompVal = parseFloat(finalCompVal);
                }else{
                    finalCompVal = finaCompPrevVal;
                }
                var finalValToAdjustInSec3 = finaCompPrevVal - finalCompVal;
                // logic manage .1 difference
                
                //finalValToAdjust = finalValToAdjust.toFixed(2);
                //finalValToAdjust = finalValToAdjust.toString().match(/^-?\d+(?:\.\d{0,2})?/)[0]
            }

            if(finalValToAdjust > 0){
                var textForReconcile = 'Increase by';
            }else if(finalValToAdjust < 0){
                var textForReconcile = 'Reduce by';
            }else{
                var textForReconcile = '';
            }

            if(finalValToAdjustInSec3 > 0){
                var textForReconcileSec3 = 'Increase by';
            }else if(finalValToAdjustInSec3 < 0){
                var textForReconcileSec3 = 'Reduce by';
            }else{
                var textForReconcileSec3 = '';
            }

            var compSecInfo = $j("#CompleteSectionInfoInput").val();
            var appendCompSecInfo = 'within sections I & II';
            var appendCompSec3Info = 'within section III';
            if(compSecInfo == 'onlySection1'){
                appendCompSecInfo = 'within section I';
            }else if( $j("#section1Visible").val() == "false" || $j("#section1Visible").val() == false ){
                appendCompSecInfo = 'within section II';
            }

            var checkGrantee = true;
            if($j("#editedField").val() == BudgetInccontributedFor){
                checkGrantee = false;
                if(finalValToAdjust != 0 && finalValToAdjustInSec3 !=0){
                    $j("#"+finalCompId+"_"+BudgetInccontributedFor+"_adjust").val(addCommaSep(finalValToAdjust));                    
                    if(BudgetInccontributedFor == 'cncs'){
                        $j(".reconcile-cncs").html(textForReconcile + ' $' + addCommaSep((Math.abs(finalValToAdjust)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSecInfo+ '</span>');
                        $j(".reconcile-cncs-secIII").html(textForReconcileSec3 + ' $' + addCommaSep((Math.abs(finalValToAdjustInSec3)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSec3Info+ '</span>');
                        if(SectionIIITotal_prev != 0){
                            $j(".or-text-cncs").css("display","block");
                            $j(".reconcile-cncs-secIII").css("display","block");
                        }
                    }else if(BudgetInccontributedFor == 'grantee' || BudgetInccontributedFor == 'granteeinkind'){
                        $j(".reconcile-grantee").html(textForReconcile + ' $' + addCommaSep((Math.abs(finalValToAdjust)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSecInfo+ '</span>');
                        $j(".reconcile-grantee-secIII").html(textForReconcileSec3 + ' $' + addCommaSep((Math.abs(finalValToAdjustInSec3)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSec3Info+ '</span>');
                        if(SectionIIITotal_prev != 0){
                            $j(".reconcile-grantee-secIII").css("display","block");
                            $j(".or-text-grantee").css("display","block");
                        }
                    }
                }else{
                    $j("#"+finalCompId+"_"+BudgetInccontributedFor+"_adjust").val('');
                    if(BudgetInccontributedFor == 'cncs'){
                        $j(".reconcile-cncs").html('-');
                        $j(".reconcile-cncs-secIII").css("display","none");
                        $j(".or-text-cncs").css("display","none");
                    }else if(BudgetInccontributedFor == 'grantee' || BudgetInccontributedFor == 'granteeinkind'){
                        $j(".reconcile-grantee").html('-');
                        $j(".reconcile-grantee-secIII").css("display","none");
                        $j(".or-text-grantee").css("display","none");
                    }

                    reconcileValueWithoutSection3(finalCompId);
                }
            }

            if(checkGrantee && $j("#editedField").val() != 'cncs'){
                if(BudgetInccontributedFor == 'grantee' && 
                    ( 
                        ( removeCommaSep($j('#'+finalCompId+'_grantee').val()) != '' && removeCommaSep($j('#'+finalCompId+'_grantee').val()) != removeCommaSep($j('#'+finalCompId+'_granteeprev').val()) ) || 
                        ( removeCommaSep($j('#'+finalCompId+'_granteeinkind').val()) != '' && removeCommaSep($j('#'+finalCompId+'_granteeinkind').val()) != removeCommaSep($j('#'+finalCompId+'_granteeinkindprev').val()) ) 
                    )
                ){       
                    if(finalValToAdjust != 0 && finalValToAdjustInSec3 !=0){
                        $j("#"+finalCompId+"_"+BudgetInccontributedFor+"_adjust").val(addCommaSep(finalValToAdjust));
                        if(BudgetInccontributedFor == 'cncs'){
                            $j(".reconcile-cncs").html(textForReconcile + ' $' + addCommaSep((Math.abs(finalValToAdjust)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSecInfo+ '</span>');                             
                            $j(".reconcile-cncs-secIII").html(textForReconcileSec3 + ' $' + addCommaSep((Math.abs(finalValToAdjustInSec3)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSec3Info+ '</span>');
                            if(SectionIIITotal_prev != 0){
                                $j(".or-text-cncs").css("display","block");
                                $j(".reconcile-cncs-secIII").css("display","block");
                            }
                        }else if(BudgetInccontributedFor == 'grantee' || BudgetInccontributedFor == 'granteeinkind'){
                            $j(".reconcile-grantee").html(textForReconcile + ' $' + addCommaSep((Math.abs(finalValToAdjust)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSecInfo+ '</span>');
                            $j(".reconcile-grantee-secIII").html(textForReconcileSec3 + ' $' + addCommaSep((Math.abs(finalValToAdjustInSec3)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSec3Info+ '</span>');
                            if(SectionIIITotal_prev != 0){
                                $j(".or-text-grantee").css("display","block");
                                $j(".reconcile-grantee-secIII").css("display","block");
                            }
                        }
                    }else{
                        $j("#"+finalCompId+"_"+BudgetInccontributedFor+"_adjust").val('');
                        if(BudgetInccontributedFor == 'cncs'){
                            $j(".reconcile-cncs").html('-');
                            $j(".reconcile-cncs-secIII").css("display","none");
                            $j(".or-text-cncs").css("display","none");
                        }else if(BudgetInccontributedFor == 'grantee' || BudgetInccontributedFor == 'granteeinkind'){
                            $j(".reconcile-grantee").html('-');
                            $j(".reconcile-grantee-secIII").css("display","none");
                            $j(".or-text-grantee").css("display","none");
                        }

                        reconcileValueWithoutSection3(finalCompId);
                    } 
                    
                }
            }
            
        }else if(fundingStructureName == 'Indirect'){
            if(BudgetInccontributedFor == 'cncs'){
                finalCompVal = removeCommaSep($j("#"+finalCompId+"_"+BudgetInccontributedFor+"prev").val());
                if(finalCompVal == ''){
                    finalCompVal = removeCommaSep($j("#"+finalCompId+"_"+BudgetInccontributedFor).val());
                }
                finalCompVal = parseFloat(finalCompVal);
                if(maxAmountAmericorpShare != 0){
                    //calccorfa = (((SectionITotal+SectionIITotal)*0.0526)*0.8).toFixed(2);
                    //calccomfa = (((SectionITotal+SectionIITotal)*0.0526)*0.2).toFixed(2);
                    if(indirectCostRatePercentCalc != 0 || corfa_icrZeroInclude == 1){
                        calccorfaSimple = (sec1and2TotalVal*maxAmountAmericorpShare*indirectCostRatePercentCalc);
                        calccorfaX = (maxAmountAmericorpShare*indirectCostRatePercentCalc);
                    }else{
                        calccorfaSimple = (sec1and2TotalVal*maxAmountAmericorpShare);
                        calccorfaX = (maxAmountAmericorpShare);
                    }

                    if(commissionFixedPercentCalc != 0 || comfa_cfaZeroInclude == 1){
                        calccomfaSimple = (sec1and2TotalVal*maxAmountAmericorpShare*commissionFixedPercentCalc);
                        calccomfaX = (maxAmountAmericorpShare*commissionFixedPercentCalc);
                    }else{
                        calccomfaSimple = (sec1and2TotalVal*maxAmountAmericorpShare);
                        calccomfaX = (maxAmountAmericorpShare);
                    }
                }else{
                    if(indirectCostRatePercentCalc != 0 || corfa_icrZeroInclude == 1){
                        calccorfaSimple = (sec1and2TotalVal*indirectCostRatePercentCalc);
                    }else{
                        calccorfaX = (0).toFixed(2);
                    }

                    if(commissionFixedPercentCalc != 0 || comfa_cfaZeroInclude == 1){
                        calccomfaSimple = (sec1and2TotalVal*commissionFixedPercentCalc);
                    }else{
                        calccomfaX = (0).toFixed(2);
                    }
                }

                var simpleFinal = parseFloat(calccomfaSimple) + parseFloat(calccorfaSimple) + sec1and2TotalVal;
                var xFinal = parseFloat(calccorfaX) + parseFloat(calccomfaX) + 1;
                var finalAmount = parseFloat(finalCompVal) - simpleFinal;
                
                //finalAmount = finalAmount.toString().match(/^-?\d+(?:\.\d{0,3})?/)[0]
                finalAmount = parseFloat(finalAmount)
                //xFinal = xFinal.toString().match(/^-?\d+(?:\.\d{0,3})?/)[0]
               // xFinal = parseFloat(xFinal);
    
                if(xFinal > 0){
                    finalValToAdjust = finalAmount / xFinal;
                }else{
                    finalValToAdjust = 0;
                }

                // logic manage .1 difference
                var finalValToAdjustString = finalValToAdjust.toString().match(/^-?\d+(?:\.\d{0,2})?/)[0]
                var finalValToAdjustWholeNumber = finalValToAdjustString.split(".");
                if(Math.abs(parseFloat(finalValToAdjustWholeNumber[1])) <= 50){
                    finalValToAdjust = parseFloat(finalValToAdjustString);
                }else{
                    finalValToAdjust = finalValToAdjust.toFixed(2);
                    finalValToAdjust = Math.round(finalValToAdjust);
                }
                var finalCompVal = removeCommaSep($j("#"+finalCompId+"_cncs").val());
                var finaCompPrevVal = parseFloat(removeCommaSep($j("#"+finalCompId+"_cncsprev").val()));
                if(finalCompVal != ''){
                    finalCompVal = parseFloat(finalCompVal);
                }else{
                    finalCompVal = finaCompPrevVal;
                }
                var finalValToAdjustInSec3 = finaCompPrevVal - finalCompVal;
                // logic manage .1 difference

                //finalValToAdjust = finalValToAdjust.toString().match(/^-?\d+(?:\.\d{0,2})?/)[0]

            }else if(BudgetInccontributedFor == 'grantee'){
                finalCompVal = removeCommaSep($j("#"+finalCompId+"_totalprev").val());
                if(finalCompVal == ''){
                    finalCompVal = removeCommaSep($j("#"+finalCompId+"_total").val());
                }
                finalCompVal = parseFloat(finalCompVal);

                if(noCalCulationForGranteeShare == 0){
                    var cncsSubtotaSection3 = removeCommaSep($j("#"+sec3Sub+"_cncs").val());
                    if(cncsSubtotaSection3 != ''){
                        cncsSubtotaSection3 = parseFloat(cncsSubtotaSection3);
                    }else{
                        cncsSubtotaSection3 = parseFloat(removeCommaSep($j("#"+sec3Sub+"_cncsprev").val()))
                    }
                    if(maxAmountRequestAsGranteeShare != 0 || mxGranteeShareZeroInclude == 1){
                        //calccorfa = ((SectionITotal+SectionIITotal)*0.1).toFixed(2);
                        calccorfaSimple = (SectionIandIITotal_Total*maxAmountRequestAsGranteeShare)-cncsSubtotaSection3;
                        calccorfaX = maxAmountRequestAsGranteeShare;
                    }else{
                        calccorfaSimple = (0).toFixed(2);
                        calccorfaX = (0).toFixed(2);
                    }
                }
                calccomfaSimple = 0;
                var comfaGranteeVal = removeCommaSep($j("#"+cfa+"_grantee").val());
                if(comfaGranteeVal == ''){
                    comfaGranteeVal = removeCommaSep($j("#"+cfa+"_granteeprev").val());
                }
                calccomfaSimple = comfaGranteeVal;

                calccomfaX = 0;
                var simpleFinal = parseFloat(calccomfaSimple) + parseFloat(calccorfaSimple) + SectionIandIITotal_Total;
                var xFinal = parseFloat(calccorfaX) + parseFloat(calccomfaX) + 1;

                var sec3cncstotal = removeCommaSep($j("#"+sec3Sub+"_cncs").val());
                if(sec3cncstotal != ''){
                    sec3cncstotal = parseFloat(sec3cncstotal);
                }else{
                    sec3cncstotal = parseFloat(removeCommaSep($j("#"+sec3Sub+"_cncsprev").val()))
                }
                var finalAmount = (parseFloat(finalCompVal) - sec3cncstotal) - simpleFinal;
                //finalAmount = finalAmount.toFixed(2);
    
                if(xFinal > 0){
                    finalValToAdjust = finalAmount / xFinal;
                }else{
                    finalValToAdjust = 0;
                }

                // logic manage .1 difference
                var finalValToAdjustString = finalValToAdjust.toString().match(/^-?\d+(?:\.\d{0,2})?/)[0]
                var finalValToAdjustWholeNumber = finalValToAdjustString.split(".");
                if(Math.abs(parseFloat(finalValToAdjustWholeNumber[1])) <= 50){
                    finalValToAdjust = parseFloat(finalValToAdjustString);
                }else{
                    finalValToAdjust = finalValToAdjust.toFixed(2);
                    finalValToAdjust = Math.round(finalValToAdjust);
                }
                
                var finalCompVal = removeCommaSep($j("#"+finalCompId+"_grantee").val());
                var finaCompPrevVal = parseFloat(removeCommaSep($j("#"+finalCompId+"_granteeprev").val()));
                if(finalCompVal != ''){
                    finalCompVal = parseFloat(finalCompVal);
                }else{
                    finalCompVal = finaCompPrevVal;
                }
                var finalValToAdjustInSec3 = finaCompPrevVal - finalCompVal;
                // logic manage .1 difference

                //finalValToAdjust = finalValToAdjust.toFixed(2);
               // finalValToAdjust = finalValToAdjust.toString().match(/^-?\d+(?:\.\d{0,2})?/)[0]
            }

            if(finalValToAdjust > 0){
                var textForReconcile = 'Increase by';
            }else if(finalValToAdjust < 0){
                var textForReconcile = 'Reduce by';
            }else{
                var textForReconcile = '';
            }

            if(finalValToAdjustInSec3 > 0){
                var textForReconcileSec3 = 'Increase by';
            }else if(finalValToAdjustInSec3 < 0){
                var textForReconcileSec3 = 'Reduce by';
            }else{
                var textForReconcileSec3 = '';
            }

            var compSecInfo = $j("#CompleteSectionInfoInput").val();
            var appendCompSecInfo = 'within sections I & II';
            var appendCompSec3Info = 'within section III';
            if(compSecInfo == 'onlySection1'){
                appendCompSecInfo = 'within section I';
            }else if( $j("#section1Visible").val() == "false" || $j("#section1Visible").val() == false ){
                appendCompSecInfo = 'within section II';
            }

            var checkGrantee = true;
            if($j("#editedField").val() == BudgetInccontributedFor){
                checkGrantee = false;
                if(finalValToAdjust != 0 && finalValToAdjustInSec3 !=0){
                    $j("#"+finalCompId+"_"+BudgetInccontributedFor+"_adjust").val(addCommaSep(finalValToAdjust));
                    if(BudgetInccontributedFor == 'cncs'){
                        $j(".reconcile-cncs").html(textForReconcile + ' $' + addCommaSep((Math.abs(finalValToAdjust)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSecInfo+ '</span>');
                        $j(".reconcile-cncs-secIII").html(textForReconcileSec3 + ' $' + addCommaSep((Math.abs(finalValToAdjustInSec3)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSec3Info+ '</span>');
                        if(SectionIIITotal_prev != 0){
                            $j(".or-text-cncs").css("display","block");
                            $j(".reconcile-cncs-secIII").css("display","block");
                        }
                    }else if(BudgetInccontributedFor == 'grantee' || BudgetInccontributedFor == 'granteeinkind'){
                        $j(".reconcile-grantee").html(textForReconcile + ' $' + addCommaSep((Math.abs(finalValToAdjust)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSecInfo+ '</span>');
                        $j(".reconcile-grantee-secIII").html(textForReconcileSec3 + ' $' + addCommaSep((Math.abs(finalValToAdjustInSec3).toFixed(2))) + '<span class="compsecinfo">' +appendCompSec3Info+ '</span>');
                        if(SectionIIITotal_prev != 0){
                            $j(".or-text-grantee").css("display","block");
                            $j(".reconcile-grantee-secIII").css("display","block");
                        }
                    }
                }else{
                    $j("#"+finalCompId+"_"+BudgetInccontributedFor+"_adjust").val('');
                    if(BudgetInccontributedFor == 'cncs'){
                        $j(".reconcile-cncs").html('-');
                        $j(".reconcile-cncs-secIII").css("display","none");
                        $j(".or-text-cncs").css("display","none");
                    }else if(BudgetInccontributedFor == 'grantee' || BudgetInccontributedFor == 'granteeinkind'){
                        $j(".reconcile-grantee").html('-');
                        $j(".reconcile-grantee-secIII").css("display","none");
                        $j(".or-text-grantee").css("display","none");
                    }

                    reconcileValueWithoutSection3(finalCompId);
                }
            }
            if(checkGrantee && $j("#editedField").val() != 'cncs'){
                if(BudgetInccontributedFor == 'grantee' && 
                    (
                        ( removeCommaSep($j('#'+finalCompId+'_grantee').val()) != '' && removeCommaSep($j('#'+finalCompId+'_grantee').val()) != removeCommaSep($j('#'+finalCompId+'_granteeprev').val())) || 
                        ( removeCommaSep($j('#'+finalCompId+'_granteeinkind').val()) != '' && removeCommaSep($j('#'+finalCompId+'_granteeinkind').val()) != removeCommaSep($j('#'+finalCompId+'_granteeinkindprev').val()))
                    )
                ){
                    if(finalValToAdjust != 0 && finalValToAdjustInSec3 !=0){
                        $j("#"+finalCompId+"_"+BudgetInccontributedFor+"_adjust").val(addCommaSep(finalValToAdjust));
                        if(BudgetInccontributedFor == 'cncs'){
                            $j(".reconcile-cncs").html(textForReconcile + ' $' + addCommaSep((Math.abs(finalValToAdjust)).toFixed(2)) + '<span class="compsecinfo" style="margin-left:55px;">' +appendCompSecInfo+ '</span>'); 
                            $j(".reconcile-cncs-secIII").html(textForReconcileSec3 + ' $' + addCommaSep((Math.abs(finalValToAdjustInSec3)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSec3Info+ '</span>');
                            if(SectionIIITotal_prev != 0){
                                $j(".or-text-css").css("display","block");
                                $j(".reconcile-css-secIII").css("display","block");
                            }
                        }else if(BudgetInccontributedFor == 'grantee' || BudgetInccontributedFor == 'granteeinkind'){
                            $j(".reconcile-grantee").html(textForReconcile + ' $' + addCommaSep((Math.abs(finalValToAdjust)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSecInfo+ '</span>');
                            $j(".reconcile-grantee-secIII").html(textForReconcileSec3 + ' $' + addCommaSep((Math.abs(finalValToAdjustInSec3)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSec3Info+ '</span>');
                            if(SectionIIITotal_prev != 0){
                                $j(".or-text-grantee").css("display","block");
                                $j(".reconcile-grantee-secIII").css("display","block");
                            }
                        }
                    }else{
                        $j("#"+finalCompId+"_"+BudgetInccontributedFor+"_adjust").val('');
                        if(BudgetInccontributedFor == 'cncs'){
                            $j(".reconcile-cncs").html('-');
                            $j(".reconcile-cncs-secIII").css("display","none");
                            $j(".or-text-cncs").css("display","none");
                        }else if(BudgetInccontributedFor == 'grantee' || BudgetInccontributedFor == 'granteeinkind'){
                            $j(".reconcile-grantee").html('-');
                            $j(".reconcile-grantee-secIII").css("display","none");
                            $j(".or-text-grantee").css("display","none");
                        }

                        reconcileValueWithoutSection3(finalCompId);
                    } 
                }
            }
        }

        if(removeCommaSep($j('#'+finalCompId+'_grantee').val()) == removeCommaSep($j('#'+finalCompId+'_granteeprev').val()) && removeCommaSep($j('#'+finalCompId+'_cncs').val()) == removeCommaSep($j('#'+finalCompId+'_cncsprev').val())){
            $j(".trsimple_total_Adjust_"+finalCompId).hide();
            $j(".reconcile-div").hide();
            $j(".reconcile-reason").hide();
            $j(".budgetMod-button-div").css("padding-bottom","60px");  
            $j(".sec3Toggle").removeClass("mb-10-neg");
            /*if($j("#totalLineChange").val() == 0){
                $j(".balanced-div").hide();
                $j(".nochanges-div").show();
            }else{
                $j(".nochanges-div").hide();
                $j(".balanced-div").show();
            }    */   
        }else{
            if($j('#'+finalCompId+'_grantee').val() != '' || $j('#'+finalCompId+'_cncs').val() != ''){
                $j(".trsimple_total_Adjust_"+finalCompId).show();
                $j(".reconcile-div").show();
                $j(".sec3Toggle").removeClass("mb-10-neg");
                var reconcileWindowHeight = $j(".budget-bottom-info-container").height();
                if(reconcileWindowHeight > 60){
                    $j(".budgetMod-button-div").css("padding-bottom","168px");
                }else{
                    $j(".budgetMod-button-div").css("padding-bottom","135px");
                }
                /*$j(".balanced-div").hide();
                $j(".nochanges-div").hide();    */
            }
        }

        //$j(".trsimple_total_Adjust_"+finalCompId).show();
    }else{
        
        reconcileValueWithoutSection3(finalCompId)
    }
}

function reconcileValueWithoutSection3(finalCompId){
    var finalCompValCncsPrev = removeCommaSep($j("#"+finalCompId+"_cncsprev").val());    
    var finalCompValGranteePrev = removeCommaSep($j("#"+finalCompId+"_granteeprev").val());   
    //var finalCompValTotalPrev = $j("#"+finalCompId+"_totalprev").val(); 
    
    var finalCompValCncs = removeCommaSep($j("#"+finalCompId+"_cncs").val());    
    var finalCompValGrantee = removeCommaSep($j("#"+finalCompId+"_grantee").val());   
    //var finalCompValTotal = $j("#"+finalCompId+"_total").val();
    var sec3Sub = $j("#sec3Sub").val();
    var SectionIIITotal_prev = removeCommaSep($j('#'+sec3Sub+'_totalprev').val());
    var reconcileCncsAmount = 0;
    var reconcileGranteeAmount = 0;
    var reconcileCncsAmountSecIII = 0;
    var reconcilegranteeAmountSecIII = 0;
    //var reconcileTotalAmount = 0;
    if(finalCompValCncsPrev != '' && finalCompValCncs != ''){
        reconcileCncsAmount = finalCompValCncsPrev - finalCompValCncs;
        reconcileCncsAmountSecIII = reconcileCncsAmount;
    }
    var reconcileCncsAmountString = reconcileCncsAmount.toString().match(/^-?\d+(?:\.\d{0,2})?/)[0]
    var reconcileCncsAmountWholeNumber = reconcileCncsAmountString.split(".");
    if(Math.abs(parseFloat(reconcileCncsAmountWholeNumber[1])) <= 50){
        reconcileCncsAmount = parseFloat(reconcileCncsAmountString);
    }else{
        reconcileCncsAmount = reconcileCncsAmount.toFixed(2);
        reconcileCncsAmount = Math.round(reconcileCncsAmount);
    }

    if(finalCompValGranteePrev != '' && finalCompValGrantee != ''){
        reconcileGranteeAmount = finalCompValGranteePrev - finalCompValGrantee;
        reconcilegranteeAmountSecIII = reconcileGranteeAmount;
    }
    var reconcileGranteeAmountString = reconcileGranteeAmount.toString().match(/^-?\d+(?:\.\d{0,2})?/)[0]
    var reconcileGranteeAmountWholeNumber = reconcileGranteeAmountString.split(".");
    if(Math.abs(parseFloat(reconcileGranteeAmountWholeNumber[1])) <= 50){
        reconcileGranteeAmount = parseFloat(reconcileGranteeAmountString);
    }else{
        reconcileGranteeAmount = reconcileGranteeAmount.toFixed(2);
        reconcileGranteeAmount = Math.round(reconcileGranteeAmount);
    }
    //if(finalCompValTotalPrev != '' && finalCompValTotal != ''){
    //    reconcileTotalAmount = finalCompValTotalPrev - finalCompValTotal;
    //}

    var compSecInfo = $j("#CompleteSectionInfoInput").val();
    var appendCompSecInfo = 'within sections I & II';
    var appendCompSec3Info = 'within section III';
    if(compSecInfo == 'onlySection1'){
        appendCompSecInfo = 'within section I';
    }else if( $j("#section1Visible").val() == "false" || $j("#section1Visible").val() == false ){
        appendCompSecInfo = 'within section II';
    }

    if($j("#editedField").val() == 'cncs'){
        if(reconcileCncsAmount != 0 || reconcileCncsAmountSecIII!=0){
            
            $j("#"+finalCompId+"_cncs_adjust").val(addCommaSep(reconcileCncsAmount.toFixed(2)));
            if(reconcileCncsAmount > 0 || reconcileCncsAmountSecIII > 0){
                $j(".reconcile-cncs").html('Increase by $'+ addCommaSep((Math.abs(reconcileCncsAmount)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSecInfo+ '</span>');
                $j(".reconcile-cncs-secIII").html('Increase by $'+ addCommaSep((Math.abs(reconcileCncsAmountSecIII)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSec3Info+ '</span>');
                if(SectionIIITotal_prev != 0){
                    $j(".or-text-cncs").css("display","block");
                    $j(".reconcile-cncs-secIII").css("display","block");
                }
            }else if(reconcileCncsAmount < 0 || reconcileCncsAmountSecIII < 0){
                $j(".reconcile-cncs").html('Reduce by $'+ addCommaSep((Math.abs(reconcileCncsAmount)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSecInfo+ '</span>');
                $j(".reconcile-cncs-secIII").html('Reduce by $'+ addCommaSep((Math.abs(reconcileCncsAmountSecIII)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSec3Info+ '</span>');
                if(SectionIIITotal_prev != 0){
                    $j(".or-text-cncs").css("display","block");
                    $j(".reconcile-cncs-secIII").css("display","block");
                }
            } 
        }else{
            $j(".reconcile-cncs").html('-');
            $j(".or-text-cncs").css("display","none");
            $j(".reconcile-cncs-secIII").css("display","none");
            $j("#"+finalCompId+"_cncs_adjust").val('');
        }

        if(removeCommaSep($j('#'+finalCompId+'_grantee').val()) != removeCommaSep($j('#'+finalCompId+'_granteeprev').val()) || removeCommaSep($j('#'+finalCompId+'_granteeinkind').val()) != removeCommaSep($j('#'+finalCompId+'_granteeinkindprev').val())){
            if(reconcileGranteeAmount != 0 || reconcilegranteeAmountSecIII != 0){
                $j("#"+finalCompId+"_grantee_adjust").val(addCommaSep(reconcileGranteeAmount.toFixed(2)));
                if(reconcileGranteeAmount > 0 || reconcilegranteeAmountSecIII > 0){
                    $j(".reconcile-grantee").html('Increase by $'+ addCommaSep((Math.abs(reconcileGranteeAmount)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSecInfo+ '</span>');
                    $j(".reconcile-grantee-secIII").html('Increase by $'+ addCommaSep((Math.abs(reconcilegranteeAmountSecIII)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSec3Info+ '</span>');
                    if(SectionIIITotal_prev != 0){
                        $j(".or-text-grantee").css("display","block");
                        $j(".reconcile-grantee-secIII").css("display","block");
                    }
                }else if(reconcileGranteeAmount < 0 || reconcilegranteeAmountSecIII < 0){
                    $j(".reconcile-grantee").html('Reduce by $'+ addCommaSep((Math.abs(reconcileGranteeAmount)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSecInfo+ '</span>');
                    $j(".reconcile-grantee-secIII").html('Reduce by $'+ addCommaSep((Math.abs(reconcilegranteeAmountSecIII)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSec3Info+ '</span>');
                    if(SectionIIITotal_prev != 0){
                        $j(".or-text-grantee").css("display","block");
                        $j(".reconcile-grantee-secIII").css("display","block");
                    }
                }
            }else{
                $j("#"+finalCompId+"_grantee_adjust").val('');
                $j(".reconcile-grantee").html('');
                $j(".or-text-grantee").css("display","none");
                $j(".reconcile-grantee-secIII").css("display","none");
            } 
        }
    }
    if($j("#editedField").val() == 'grantee'){
        if(reconcileGranteeAmount != 0 || reconcilegranteeAmountSecIII != 0){
            $j("#"+finalCompId+"_grantee_adjust").val(addCommaSep(reconcileGranteeAmount.toFixed(2)));
            if(reconcileGranteeAmount > 0 || reconcilegranteeAmountSecIII > 0){
                $j(".reconcile-grantee").html('Increase by $'+ addCommaSep((Math.abs(reconcileGranteeAmount)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSecInfo+ '</span>');
                $j(".reconcile-grantee-secIII").html('Increase by $'+ addCommaSep((Math.abs(reconcilegranteeAmountSecIII)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSec3Info+ '</span>');
                if(SectionIIITotal_prev != 0){
                    $j(".or-text-grantee").css("display","block");
                    $j(".reconcile-grantee-secIII").css("display","block");
                }
            }else if(reconcileGranteeAmount < 0 || reconcilegranteeAmountSecIII < 0){
                $j(".reconcile-grantee").html('Reduce by $'+ addCommaSep((Math.abs(reconcileGranteeAmount)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSecInfo+ '</span>');
                $j(".reconcile-grantee-secIII").html('Reduce by $'+ addCommaSep((Math.abs(reconcilegranteeAmountSecIII)).toFixed(2)) + '<span class="compsecinfo">' +appendCompSec3Info+ '</span>');
                if(SectionIIITotal_prev != 0){
                    $j(".or-text-grantee").css("display","block");
                    $j(".reconcile-grantee-secIII").css("display","block");
                }
            }
        }else{
            $j("#"+finalCompId+"_grantee_adjust").val('');
            $j(".reconcile-grantee").html('');
            $j(".or-text-grantee").css("display","none");
            $j(".reconcile-grantee-secIII").css("display","none");
        } 
    }
    //$j("#"+finalCompId+"_total_adjust").val(reconcileTotalAmount.toFixed(2));

    if(removeCommaSep($j('#'+finalCompId+'_grantee').val()) == removeCommaSep($j('#'+finalCompId+'_granteeprev').val()) && removeCommaSep($j('#'+finalCompId+'_cncs').val()) == removeCommaSep($j('#'+finalCompId+'_cncsprev').val())){
        $j(".trsimple_total_Adjust_"+finalCompId).hide();
        $j(".reconcile-div").hide();
        $j(".reconcile-reason").hide();
        $j(".sec3Toggle").removeClass("mb-10-neg");
        $j(".budgetMod-button-div").css("padding-bottom","60px");  
        /*if($j("#totalLineChange").val() == 0){
            $j(".balanced-div").hide();
            $j(".nochanges-div").show();
        }else{
            $j(".nochanges-div").hide();
            $j(".balanced-div").show();
        }  */
    }else{
        if(removeCommaSep($j('#'+finalCompId+'_grantee').val()) != '' || removeCommaSep($j('#'+finalCompId+'_cncs').val()) != ''){
            $j(".trsimple_total_Adjust_"+finalCompId).show();
            $j(".reconcile-div").show();
            $j(".sec3Toggle").removeClass("mb-10-neg");
            var reconcileWindowHeight = $j(".budget-bottom-info-container").height();
            if(reconcileWindowHeight > 60){
                $j(".budgetMod-button-div").css("padding-bottom","168px");
            }else{
                $j(".budgetMod-button-div").css("padding-bottom","135px");
            }  
        /* $j(".nochanges-div").hide();
            $j(".balanced-div").hide();*/
        }
    }
}

function removeAllModificationFn(){
    $j(".input-budget-increase").val('');
    $j("#budgetIncreasecncs_prev").val('0');
    $j("#budgetIncreasegrantee_prev").val('0');
    $j("#budgetIncreasegranteeinkind_prev").val('0');
    $j("#budgetIncreasetotal_prev").val('0');

    $j("#corfa_icrChanged").val('0');
    $j("#comfa_cfaChanged").val('0');
    $j("#mxGranteeShareChanged").val('0');

    $j("#updateSec3ToDefault").hide();
    $j("#updateSec3ToDefaultSpan").hide();
    
    //check all modification inputs
    $j(".input-number-prev").each(function(){ 
        var compId = $j(this).attr('data-componentid');

        if($j("#"+compId+"_cncs") != undefined){
            $j("#"+compId+"_cncs").val('');
        }
        if($j("#"+compId+"_grantee") != undefined){
            $j("#"+compId+"_grantee").val('');
        }
        if($j("#"+compId+"_granteeinkind") != undefined){
            $j("#"+compId+"_granteeinkind").val('');
        }
        if($j("#"+compId+"_total") != undefined){
            $j("#"+compId+"_total").val('');
        }

        $j(".componenttr.componenttrchange.componenttrchange_"+compId).removeClass('tr-simple');
        $j(".trsimple_total_"+compId).hide();
        $j(".trsimple_percent_"+compId).hide();
    });

    $j(".submit-button").attr("type", "button");
    $j(".submit-button").addClass("disabled");
    $j(".resubmit-button").attr("type", "button");
    $j(".resubmit-button").addClass("disabled");
}

function reasonToReconcile(){
    var sec1SubId = $j("#sec1Sub").val();
    var sec2SubId = $j("#sec2Sub").val();
    var sec3SubId = $j("#sec3Sub").val();
    var finalCompId = $j('#finalCompId').val();

    //section 1 totals
    var cncsTotalS1 = parseFloat(removeCommaSep($j("#"+sec1SubId+"_cncs").val()));
    var cncsTotalprevS1 = parseFloat(removeCommaSep($j("#"+sec1SubId+"_cncsprev").val()));
    var granteeTotalS1 = parseFloat(removeCommaSep($j("#" + sec1SubId + "_grantee").val())) + parseFloat(removeCommaSep($j("#" + sec1SubId + "_granteeinkind").val()));
    var granteeTotalprevS1 = parseFloat(removeCommaSep($j("#" + sec1SubId + "_granteeprev").val())) + parseFloat(removeCommaSep($j("#" + sec1SubId + "_granteeinkindprev").val()));

    //section 2 totals
    var cncsTotalS2 = parseFloat(removeCommaSep($j("#"+sec2SubId+"_cncs").val())); 
    var cncsTotalprevS2 = parseFloat(removeCommaSep($j("#"+sec2SubId+"_cncsprev").val()));
    var granteeTotalS2 = parseFloat(removeCommaSep($j("#" + sec2SubId + "_grantee").val())) + parseFloat(removeCommaSep($j("#" + sec2SubId + "_granteeinkind").val()));
    var granteeTotalprevS2 = parseFloat(removeCommaSep($j("#" + sec2SubId + "_granteeprev").val())) + parseFloat(removeCommaSep($j("#" + sec2SubId + "_granteeinkindprev").val()));

    var cncsTotal_Total = 0; 
    var cncsTotalprev_Total = 0;
    var granteeTotal_Total = 0;
    var granteeTotalprev_Total = 0;

    //check if section 1 or 2 modified values exists. If not then make it as prev because no modification done
    if (isNaN(cncsTotalS1) && !isNaN(cncsTotalprevS1)) {
        cncsTotalS1 = cncsTotalprevS1;
    }
    if (isNaN(granteeTotalS1) && !isNaN(granteeTotalprevS1)) {
        granteeTotalS1 = granteeTotalprevS1;
    }

    if (isNaN(cncsTotalS2) && !isNaN(cncsTotalprevS2)) {
        cncsTotalS2 = cncsTotalprevS2;
    }
    if (isNaN(granteeTotalS2) && !isNaN(granteeTotalprevS2)) {
        granteeTotalS2 = granteeTotalprevS2;
    }

    //Section 1 and 2 each column total for modified and prev values
    if (!isNaN(cncsTotalS1)) {
        cncsTotal_Total += cncsTotalS1;
        if(!isNaN(cncsTotalS2)){
            cncsTotal_Total += cncsTotalS2;
        }
    }else{
        if(!isNaN(cncsTotalS2)){
            cncsTotal_Total += cncsTotalS2;
        }
    }
    if (!isNaN(cncsTotalprevS1)) {
        cncsTotalprev_Total += cncsTotalprevS1;
        if(!isNaN(cncsTotalprevS2)){
            cncsTotalprev_Total += cncsTotalprevS2;
        }
    }else{
        if(!isNaN(cncsTotalprevS2)){
            cncsTotalprev_Total += cncsTotalprevS2;
        }
    }
    if (!isNaN(granteeTotalS1)) {
        granteeTotal_Total += granteeTotalS1;
        if(!isNaN(granteeTotalS2)){
            granteeTotal_Total += granteeTotalS2;
        }
    }else{
        if(!isNaN(granteeTotalS2)){
            granteeTotal_Total += granteeTotalS2;
        }
    }
    if (!isNaN(granteeTotalprevS1)) {
        granteeTotalprev_Total = granteeTotalprevS1;
        if(!isNaN(granteeTotalprevS2)){
            granteeTotalprev_Total += granteeTotalprevS2;
        }
    }else{
        if(!isNaN(granteeTotalprevS2)){
            granteeTotalprev_Total += granteeTotalprevS2;
        }
    }

    //Total Section each column values modified and prev
    var cncsFinal = parseFloat(removeCommaSep($j("#"+finalCompId+"_cncs").val()));
    var cncsFinalPrev = parseFloat(removeCommaSep($j("#"+finalCompId+"_cncsprev").val()));
    var granteeFinal = parseFloat(removeCommaSep($j("#" + finalCompId + "_grantee").val())) + parseFloat(removeCommaSep($j("#" + finalCompId + "_granteeinkind").val()));
    var granteeFinalPrev = parseFloat(removeCommaSep($j("#" + finalCompId + "_granteeprev").val())) + parseFloat(removeCommaSep($j("#" + finalCompId + "_granteeinkindprev").val()));

    if (isNaN(cncsFinal) && !isNaN(cncsFinalPrev)) {
        cncsFinal = cncsFinalPrev;
    }
    if (isNaN(granteeFinal) && !isNaN(granteeFinalPrev)) {
        granteeFinal = granteeFinalPrev;
    }

    // When SEC III is modified in time of submission.
    if($j("#sec3PrevModifiedInApprovals").val() == 1){
        //Section1 and 2 is reconciled
        if( ( (cncsTotalS1 == 0 && granteeTotalS1 == 0) || (cncsTotalS1 == cncsTotalprevS1 && granteeTotalS1 == granteeTotalprevS1) ) &&
            ( (cncsTotalS2 == 0 && granteeTotalS2 == 0) || (cncsTotalS2 == cncsTotalprevS2 && granteeTotalS2 == granteeTotalprevS2) ) &&
            ( (cncsTotal_Total == 0 && granteeTotal_Total == 0) || (cncsTotal_Total == cncsTotalprev_Total && granteeTotal_Total == granteeTotalprev_Total) ) &&
            ( (cncsFinal == 0 && granteeFinal == 0) || (cncsFinal != cncsFinalPrev && granteeFinal != granteeFinalPrev) ) /*&& 
            ( ( removeCommaSep($j("#"+sec3SubId+"_cncs").val()) != '' && removeCommaSep($j("#"+sec3SubId+"_cncsprev").val()) != removeCommaSep($j("#"+sec3SubId     +"_cncs").val()) ) || 
              ( removeCommaSep($j("#"+sec3SubId+"_grantee").val()) != '' && removeCommaSep($j("#"+sec3SubId+"_granteeprev").val()) != removeCommaSep($j("#"+sec3SubId+"_grantee").val()) )
            ) */
        ){
            $j(".reconcile-reason").css("display","flex");
            $j(".budgetMod-button-div").css("padding-bottom","160px"); 
            $j(".sec3Toggle").addClass("mb-10-neg");
            $j(".reconcilingMessage").html("<h4>Section I and Section II are reconciled. It looks like Section III needs updates.<br><br></h4>"+
                "<ol class='reconcileContent'>"+
                    "<li>If you're happy with Sections I and II, please review Section III.  You may need to set each value to what they were before changes were made in Sections I and II. <br><br></li>"+
                    "<li>If Section III must follow automatic calculation rules set by "+$j("#programName").val()+", please follow the guidance at the bottom of the screen about what needs to be updated in Sections I and/or II.  Note that the platform may provide multiple steps for you to follow in order to get everything balanced.</li>"+
                "</ol>");
        }
        //Direct change is Section 3 : When section 3 is changed in previous approvals
        else if( ( (cncsTotal_Total == 0 && granteeTotal_Total == 0) || (cncsTotal_Total == cncsTotalprev_Total && granteeTotal_Total == granteeTotalprev_Total) ) &&
            ( ( removeCommaSep($j("#"+sec3SubId+"_cncs").val()) != '' && removeCommaSep($j("#"+sec3SubId+"_cncsprev").val()) != removeCommaSep($j("#"+sec3SubId+"_cncs").val()) ) || 
              ( removeCommaSep($j("#"+sec3SubId+"_grantee").val()) != '' && removeCommaSep($j("#"+sec3SubId+"_granteeprev").val()) != removeCommaSep($j("#"+sec3SubId+"_grantee").val()) )
            )
        ){
            $j(".reconcile-reason").css("display","flex");
            $j(".budgetMod-button-div").css("padding-bottom","160px"); 
            $j(".sec3Toggle").addClass("mb-10-neg");
            $j(".reconcilingMessage").html("<h4>Section III is preventing reconciliation:</h4>"+
                "<ol class='reconcileContent'>"+
                    "<li style='padding-left:5px; list-style:none;'> <b>Usual Solution:</b><br> </li>"+
                    "<li style='padding-left:5px; list-style:none;'> Update the entries your program made in Section III. <br><br></li>"+
                    "<li style='padding-left:5px; list-style:none;'> <b>Another Option: Modify Values in Sections I and/or II: </b><br></li>"+
                    "<li style='padding-left:5px; list-style:none;'> Step 1: Follow guidance at the bottom of the screen to balance Sections I and II. <br><br></li>"+
                    "<li style='padding-left:5px; list-style:none;'> Step 2: Section III values were just updated as a result of <q>Step 1</q>. Please re-add the custom numbers you previously entered into that section.</li>"+
                "</ol>"
            );
        }
    }else{
        if( ( (cncsTotal_Total == 0 && granteeTotal_Total == 0) || (cncsTotal_Total == cncsTotalprev_Total && granteeTotal_Total == granteeTotalprev_Total) ) && 
            ( ( removeCommaSep($j("#"+sec3SubId+"_cncs").val()) != '' && removeCommaSep($j("#"+sec3SubId+"_cncsprev").val()) != removeCommaSep($j("#"+sec3SubId+"_cncs").val()) ) || 
              ( removeCommaSep($j("#"+sec3SubId+"_grantee").val()) != '' && removeCommaSep($j("#"+sec3SubId+"_granteeprev").val()) != removeCommaSep($j("#"+sec3SubId+"_grantee").val()) )
            )
        ){
            $j(".reconcile-reason").css("display","flex");
            $j(".budgetMod-button-div").css("padding-bottom","160px"); 
            $j(".sec3Toggle").addClass("mb-10-neg");
            $j(".reconcilingMessage").html("<h4>Section III is preventing reconciliation:</h4>"+
                "<ol class='reconcileContent'>"+
                    "<li style='padding-left:5px; list-style:none;'> <b>Usual Solution:</b><br> </li>"+
                    "<li style='padding-left:5px; list-style:none;'> Update the entries your program made in Section III. <br><br></li>"+
                    "<li style='padding-left:5px; list-style:none;'> <b>Another Option: Modify Values in Sections I and/or II: </b><br></li>"+
                    "<li style='padding-left:5px; list-style:none;'> Step 1: Follow guidance at the bottom of the screen to balance Sections I and II. <br><br></li>"+
                    "<li style='padding-left:5px; list-style:none;'> Step 2: Section III values were just updated as a result of <q>Step 1</q>. Please re-add the custom numbers you previously entered into that section.</li>"+
                "</ol>"
            );
        }
    }
}

function autoCalcDependsPrevAndReturnPrevModifiedStatus(contributedFor, compId){
    var fundingStructureName = $j("#FundingStructureName").val();
    var sec1Sub = $j('#sec1Sub').val();
    var sec2Sub = $j('#sec2Sub').val();
    var sec3Sub = $j('#sec3Sub').val();
    var SectionITotal = removeCommaSep($j('#'+sec1Sub+'_'+contributedFor+'prev').val());
    var SectionIITotal = removeCommaSep($j('#'+sec2Sub+'_'+contributedFor+'prev').val());
    if(SectionIITotal == undefined || SectionIITotal == 'undefined' || SectionIITotal == NaN || SectionIITotal == 'NaN' || isNaN(SectionIITotal)){
        SectionIITotal = 0.00;
    }
    var SectionITotal_Total = removeCommaSep($j('#'+sec1Sub+'_totalprev').val());
    var SectionIITotal_Total = removeCommaSep($j('#'+sec2Sub+'_totalprev').val());
    if(SectionIITotal_Total == undefined || SectionIITotal_Total == 'undefined' || SectionIITotal_Total == NaN || SectionIITotal_Total == 'NaN' || isNaN(SectionIITotal_Total)){
        SectionIITotal_Total = 0.00;
    }

    if(SectionITotal != '' && SectionITotal != undefined && SectionITotal != 'undefined'){
        SectionITotal = parseFloat(SectionITotal);
    }else{
        SectionITotal = removeCommaSep($j("#"+sec1Sub+"_"+contributedFor+"prev").val());
        if(SectionITotal != '' && SectionITotal != undefined && SectionITotal != 'undefined'){
            SectionITotal = parseFloat(SectionITotal);
        }else{
            SectionITotal = 0;
        }
    }

    if(SectionIITotal != ''){
        SectionIITotal = parseFloat(SectionIITotal);
    }else{
        SectionIITotal = parseFloat(removeCommaSep($j("#"+sec2Sub+"_"+contributedFor+"prev").val()));
    }
    if(SectionIITotal == undefined || SectionIITotal == 'undefined' || SectionIITotal == NaN || SectionIITotal == 'NaN' || isNaN(SectionIITotal)){
        SectionIITotal = 0.00;
    }

    if(SectionITotal_Total != ''){
        SectionITotal_Total = parseFloat(SectionITotal_Total);
    }else{
        SectionITotal_Total = parseFloat(removeCommaSep($j("#"+sec1Sub+"_totalprev").val()));
    }

    if(SectionIITotal_Total != ''){
        SectionIITotal_Total = parseFloat(SectionIITotal_Total);
    }else{
        SectionIITotal_Total = parseFloat(removeCommaSep($j("#"+sec2Sub+"_totalprev").val()));
    }
    if(SectionIITotal_Total == undefined || SectionIITotal_Total == 'undefined' || SectionIITotal_Total == NaN || SectionIITotal_Total == 'NaN' || isNaN(SectionIITotal_Total)){
        SectionIITotal_Total = 0.00;
    }

    var FundingStructureBudgetType = $j("#FundingStructureBudgetType").val();
    var indirectCostRatePercentCalc = parseFloat($j("#indirectCostRatePercentCalc").val()); //0.8
    var programFixedPercentCalc = parseFloat($j("#programFixedPercentCalc").val()); //0.8
    var noCalCulationForGranteeShare = $j("#noCalCulationForGranteeShare").val();
    var commissionFixedPercentCalc = parseFloat($j("#commissionFixedPercentCalc").val()); //0.2
    var maxAmountAmericorpShare = parseFloat($j("#maxAmountAmericorpShare").val()); //0.0526
    var maxAmountRequestAsGranteeShare = parseFloat($j("#maxAmountRequestAsGranteeShare").val()); //0.1
    var subtractCorfaWithSec3Acfs = parseFloat($j("#subtractCorfaWithSec3Acfs").val());
    var corfa_icrZeroInclude = parseFloat($j("#corfa_icrZeroInclude").val()); // It is for indirectCostRatePercentCalc, programFixedPercentCalc
    var comfa_cfaZeroInclude = parseFloat($j("#comfa_cfaZeroInclude").val()); // It is for commissionFixedPercentCalc
    var mxGranteeShareZeroInclude = parseFloat($j("#mxGranteeShareZeroInclude").val()); // It is for maxAmountRequestAsGranteeShare

    var useSection3 = true;
    if(FundingStructureBudgetType == 'Fixed'){
        if($j("#useSectionIII").val() == 0){
            useSection3 = false;
        }
    }

    var corfa = $j('#corfa').val();
    var comfa = $j('#comfa').val();
    var icr = $j('#icr').val();
    var cfa = $j('#cfa').val();
    var returnValue = false;

    if(useSection3){
        if(fundingStructureName == 'NonIndirect'){
            if(corfa != compId && comfa != compId){                
                var calccorfa = 0.00;
                var calccomfa = 0.00;

                if(contributedFor == 'cncs'){
                    if(maxAmountAmericorpShare != 0){
                        //calccorfa = (((SectionITotal+SectionIITotal)*0.0526)*0.8).toFixed(2);
                        //calccomfa = (((SectionITotal+SectionIITotal)*0.0526)*0.2).toFixed(2);
                        if(programFixedPercentCalc != 0 || corfa_icrZeroInclude == 1){
                            calccorfa = (((SectionITotal+SectionIITotal)*maxAmountAmericorpShare)*programFixedPercentCalc).toFixed(2);
                        }else{
                            calccorfa = ((SectionITotal+SectionIITotal)*maxAmountAmericorpShare).toFixed(2);
                        }

                        if(commissionFixedPercentCalc != 0 || comfa_cfaZeroInclude == 1){
                            calccomfa = (((SectionITotal+SectionIITotal)*maxAmountAmericorpShare)*commissionFixedPercentCalc).toFixed(2);
                        }else{
                            calccomfa = ((SectionITotal+SectionIITotal)*maxAmountAmericorpShare).toFixed(2);
                        }
                    }else{
                        if(programFixedPercentCalc != 0 || corfa_icrZeroInclude == 1){
                            calccorfa = ((SectionITotal+SectionIITotal)*programFixedPercentCalc).toFixed(2);
                        }else{
                            calccorfa = (0).toFixed(2);
                        }

                        if(commissionFixedPercentCalc != 0 || comfa_cfaZeroInclude == 1){
                            calccomfa = ((SectionITotal+SectionIITotal)*commissionFixedPercentCalc).toFixed(2);
                        }else{
                            calccomfa = (0).toFixed(2);
                        }
                    }
                    
                    $j('#'+corfa+'_cncs_default_DependsPrev').val(addCommaSep(calccorfa));
                    $j('#'+comfa+'_cncs_default_DependsPrev').val(addCommaSep(calccomfa));

                    if( parseFloat(removeCommaSep($j('#'+corfa+'_cncs_default_DependsPrev').val())) != parseFloat(removeCommaSep($j('#'+corfa+'_cncsprev').val()))){
                        returnValue = true;
                    }else if(parseFloat(removeCommaSep($j('#'+comfa+'_cncs_default_DependsPrev').val())) != parseFloat(removeCommaSep($j('#'+comfa+'_cncsprev').val())) ){
                        returnValue = true;
                    }

                    if( (removeCommaSep($j('#'+corfa+'_cncs').val()) != '' && 
                         parseFloat(removeCommaSep($j('#'+corfa+'_cncs').val())) != parseFloat(removeCommaSep($j('#'+corfa+'_cncs_default_DependsPrev').val())) 
                        ) || 

                        (removeCommaSep($j('#'+comfa+'_cncs').val()) != '' && 
                         parseFloat(removeCommaSep($j('#'+comfa+'_cncs').val())) != parseFloat(removeCommaSep($j('#'+comfa+'_cncs_default_DependsPrev').val()))
                        )
                    ){
                        $j("#directChangeInSec3").val(1);
                    }
                }else if(contributedFor == 'grantee'){
                    if(noCalCulationForGranteeShare == 0){
                        if(maxAmountRequestAsGranteeShare != 0 || mxGranteeShareZeroInclude == 1){
                            //calccorfa = ((SectionITotal+SectionIITotal)*0.1).toFixed(2);
                            if(subtractCorfaWithSec3Acfs == 1){
                                var cncsSubtotaSection3 = removeCommaSep($j("#"+sec3Sub+"_cncsprev").val());
                                if(cncsSubtotaSection3 != ''){
                                    cncsSubtotaSection3 = parseFloat(cncsSubtotaSection3);
                                }else{
                                    cncsSubtotaSection3 = parseFloat(removeCommaSep($j("#"+sec3Sub+"_cncsprev").val()));
                                }
                            }else{
                                var cncsSubtotaSection3 = 0;
                            }
                            calccorfa = (((SectionITotal_Total+SectionIITotal_Total)*maxAmountRequestAsGranteeShare)-cncsSubtotaSection3).toFixed(2);
                        }else{
                            calccorfa = (0).toFixed(2);
                        }
                    }else{
                        calccorfa = parseFloat(removeCommaSep($j('#'+corfa+'_'+contributedFor).val()));
                    }
                    
                    calccomfa = removeCommaSep($j('#'+comfa+'_'+contributedFor).val());
                    if(calccomfa != ''){
                        calccomfa = parseFloat(calccomfa);
                    }else{
                        calccomfa = parseFloat(removeCommaSep($j('#'+comfa+'_'+contributedFor+'prev').val()));
                        if(compId != 0){
                            $j('#'+comfa+'_'+contributedFor).val(addCommaSep(calccomfa));
                        }
                        //$j('#'+comfa+'_'+contributedFor+'_default').val(calccomfa);
                    }
                    $j('#'+corfa+'_grantee_default_DependsPrev').val(addCommaSep(calccorfa));
                    $j('#'+comfa+'_grantee_default_DependsPrev').val(addCommaSep(calccomfa));


                    if( parseFloat(removeCommaSep($j('#'+corfa+'_grantee_default_DependsPrev').val())) != parseFloat(removeCommaSep($j('#'+corfa+'_granteeprev').val()))){
                        returnValue = true;
                    }else if( parseFloat(removeCommaSep($j('#'+comfa+'_grantee_default_DependsPrev').val())) != parseFloat(removeCommaSep($j('#'+comfa+'_granteeprev').val())) ){
                        returnValue = true;
                    }

                    if( (removeCommaSep($j('#'+corfa+'_grantee').val()) != '' && 
                         parseFloat(removeCommaSep($j('#'+corfa+'_grantee').val())) != parseFloat(removeCommaSep($j('#'+corfa+'_grantee_default_DependsPrev').val())) 
                        ) || 

                        (removeCommaSep($j('#'+comfa+'_grantee').val()) != '' && 
                         parseFloat(removeCommaSep($j('#'+comfa+'_grantee').val())) != parseFloat(removeCommaSep($j('#'+comfa+'_grantee_default_DependsPrev').val()))
                        )
                    ){
                        $j("#directChangeInSec3").val(1);
                    }
                }
            }
        }else if(fundingStructureName == 'Indirect'){
            var calcicr = 0.00;
            var calccfa = 0.00;

            if(icr != compId && cfa != compId){
                if(contributedFor == 'cncs'){
                    if(maxAmountAmericorpShare != 0){
                        //calccorfa = (((SectionITotal+SectionIITotal)*0.0526)*0.8).toFixed(2);
                        //calccomfa = (((SectionITotal+SectionIITotal)*0.0526)*0.2).toFixed(2);
                        if(indirectCostRatePercentCalc != 0 || corfa_icrZeroInclude == 1){
                            calcicr = (((SectionITotal+SectionIITotal)*maxAmountAmericorpShare)*indirectCostRatePercentCalc).toFixed(2);
                        }else{
                            calcicr = ((SectionITotal+SectionIITotal)*maxAmountAmericorpShare).toFixed(2);
                        }

                        if(commissionFixedPercentCalc != 0 || comfa_cfaZeroInclude == 1){
                            calccfa = (((SectionITotal+SectionIITotal)*maxAmountAmericorpShare)*commissionFixedPercentCalc).toFixed(2);
                        }else{
                            calccfa = ((SectionITotal+SectionIITotal)*maxAmountAmericorpShare).toFixed(2);
                        }
                    }else{
                        if(indirectCostRatePercentCalc != 0 || corfa_icrZeroInclude == 1){
                            calcicr = ((SectionITotal+SectionIITotal)*indirectCostRatePercentCalc).toFixed(2);
                        }else{
                            calcicr = (SectionITotal+SectionIITotal).toFixed(2);
                        }

                        if(commissionFixedPercentCalc != 0 || comfa_cfaZeroInclude == 1){
                            calccfa = ((SectionITotal+SectionIITotal)*commissionFixedPercentCalc).toFixed(2);
                        }else{
                            calccfa = (SectionITotal+SectionIITotal).toFixed(2);
                        }
                    }
                    
                    $j('#'+icr+'_cncs_default_DependsPrev').val(addCommaSep(calcicr));
                    $j('#'+cfa+'_cncs_default_DependsPrev').val(addCommaSep(calccfa));

                    if( parseFloat(removeCommaSep($j('#'+icr+'_cncs_default_DependsPrev').val())) != parseFloat(removeCommaSep($j('#'+icr+'_cncsprev').val()))){
                        returnValue = true;
                    }else if(parseFloat(removeCommaSep($j('#'+cfa+'_cncs_default_DependsPrev').val())) != parseFloat(removeCommaSep($j('#'+cfa+'_cncsprev').val())) ){
                        returnValue = true;
                    }

                    if( (removeCommaSep($j('#'+icr+'_cncs').val()) != '' && 
                         parseFloat(removeCommaSep($j('#'+icr+'_cncs').val())) != parseFloat(removeCommaSep($j('#'+icr+'_cncs_default_DependsPrev').val())) 
                        ) || 

                        (removeCommaSep($j('#'+cfa+'_cncs').val()) != '' && 
                         parseFloat(removeCommaSep($j('#'+cfa+'_cncs').val())) != parseFloat(removeCommaSep($j('#'+cfa+'_cncs_default_DependsPrev').val()))
                        )
                    ){
                        $j("#directChangeInSec3").val(1);
                    }
                    
                }else if(contributedFor == 'grantee'){
                    if(noCalCulationForGranteeShare == 0){
                        var cncsSubtotaSection3 = removeCommaSep($j("#"+sec3Sub+"_cncsprev").val());
                        if(cncsSubtotaSection3 != ''){
                            cncsSubtotaSection3 = parseFloat(cncsSubtotaSection3);
                        }else{
                            cncsSubtotaSection3 = parseFloat(removeCommaSep($j("#"+sec3Sub+"_cncsprev").val()))
                        }
                        if(maxAmountRequestAsGranteeShare != 0 || mxGranteeShareZeroInclude == 1){
                            //calccorfa = ((SectionITotal+SectionIITotal)*0.1).toFixed(2);
                            calcicr = (((SectionITotal_Total+SectionIITotal_Total)*maxAmountRequestAsGranteeShare)-cncsSubtotaSection3).toFixed(2);
                        }else{
                            calcicr = (SectionITotal_Total+SectionIITotal_Total).toFixed(2);
                        }
                    }else{
                        calcicr = removeCommaSep($j('#'+icr+'_'+contributedFor).val());
                        if(calcicr != ''){
                            calcicr = parseFloat(calcicr);
                        }else{
                            calcicr = parseFloat(removeCommaSep($j('#'+icr+'_'+contributedFor+'prev').val()));
                            if(compId != 0){
                                $j('#'+icr+'_'+contributedFor).val(addCommaSep(calcicr.toFixed(2)));
                            }
                        }
                    }

                    calccfa = removeCommaSep($j('#'+cfa+'_'+contributedFor).val());
                    if(calccfa != ''){
                        calccfa = parseFloat(calccfa);
                    }else{
                        calccfa = parseFloat(removeCommaSep($j('#'+cfa+'_'+contributedFor+'prev').val()));
                        if(compId != 0){
                            $j("#"+cfa+"_"+contributedFor).val(addCommaSep(calccfa.toFixed(2)));
                        }
                    }

                    
                    $j('#'+icr+'_grantee_default_DependsPrev').val(addCommaSep(calcicr));
                    $j('#'+cfa+'_grantee_default_DependsPrev').val(addCommaSep(calccfa));

                    if( parseFloat(removeCommaSep($j('#'+icr+'_grantee_default_DependsPrev').val())) != parseFloat(removeCommaSep($j('#'+icr+'_granteeprev').val()))){
                        returnValue = true;
                    }else if(parseFloat(removeCommaSep($j('#'+cfa+'_grantee_default_DependsPrev').val())) != parseFloat(removeCommaSep($j('#'+cfa+'_granteeprev').val())) ){
                        returnValue = true;
                    }

                    if( (removeCommaSep($j('#'+icr+'_grantee').val()) != '' && 
                         parseFloat(removeCommaSep($j('#'+icr+'_grantee').val())) != parseFloat(removeCommaSep($j('#'+icr+'_grantee_default_DependsPrev').val())) 
                        ) || 

                        (removeCommaSep($j('#'+cfa+'_grantee').val()) != '' && 
                         parseFloat(removeCommaSep($j('#'+cfa+'_grantee').val())) != parseFloat(removeCommaSep($j('#'+cfa+'_grantee_default_DependsPrev').val()))
                        )
                    ){
                        $j("#directChangeInSec3").val(1);
                    }
                }
            }
        }
    }

    return returnValue;
}