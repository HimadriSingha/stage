
		function CountLeft(field, max) {
			
			if(typeof field.value != 'undefined') {
				tempvalue = field.value.replace(/\r\n/g,"\n");
				if(typeof tempvalue != 'undefined') {
					if (tempvalue.length > max) {
						field.value = tempvalue.substring(0, max);
						nowCount = max - field.value.length;
						document.getElementById(field.name+"_cnt").childNodes[0].nodeValue = nowCount;
					} else { 	
						nowCount = max - tempvalue.length;
						document.getElementById(field.name+"_cnt").childNodes[0].nodeValue = nowCount;
					}	field.style.height='';
				if(parseInt(field.style.minHeight)<field.scrollHeight)
				{
					field.style.height=field.scrollHeight+'px';
				}
				}
			} else {
				var ele = document.getElementById(field);
				var target_ele = document.getElementById(field+"_cnt");
				
				if( ele != null && target_ele!=null) {
				tempvalue = ele.value.replace(/\r\n/g,"\n");
				//alert(tempvalue);
				
				if(typeof tempvalue != 'undefined') {
					if (tempvalue.length > max) {
						ele.value = tempvalue.substring(0, max);
						nowCount = max - ele.value.length;
						target_ele.childNodes[0].nodeValue = nowCount;
					} else { 	
						nowCount = max - tempvalue.length;
						target_ele.childNodes[0].nodeValue = nowCount;
					}	ele.style.height='';
					if(parseInt(ele.style.minHeight)<ele.scrollHeight)
					{
						ele.style.height=ele.scrollHeight+'px';
					}
			}
			}
				
		}
			
	}
		
		function CountLeft_Challenge(field, max) {
			tempvalue = field.value.replace(/\r\n/g,"\n");
			if (tempvalue.length > max) {
				field.value = tempvalue.substring(0, max);
				nowCount = max - field.value.length;
				document.getElementById(field.name+"_cnt").childNodes[0].nodeValue = nowCount;
			} else { 	
				nowCount = max - tempvalue.length;
				document.getElementById(field.name+"_cnt").childNodes[0].nodeValue = nowCount;
			} 		
			/*field.style.height='';
			if(parseInt(field.style.minHeight)<field.scrollHeight)
			{
				field.style.height=field.scrollHeight+'px';
			}*/
		}
		
		//this function needs to run onload to preset the number of chars left for each textarea
		function PreSetCharCnt(){
			var textAreaList = getElementsByTagNames('textarea');
			
			for(i=0;i<textAreaList.length;i++) {
				formEl = "document.forms[0]." + textAreaList[i].name;
				if (textAreaList[i].name == "ChallengeCrux") {
					nowCount = 512;
				}else if(textAreaList[i].name == "ChallengeText") { 
					nowCount = 2000;
				}else if(textAreaList[i].name == "Situation") { 
					nowCount = 2500;
				}else if(textAreaList[i].name == "definition_short") { 
					nowCount = 350;
				}else if(textAreaList[i].name == "definition_long") { 
					nowCount = 2500;
				}else if(textAreaList[i].name.substring(0,4) == "Step") { 
					nowCount = 2500;
				}else {
					//nowCount = 1500;
					nowCount = 5000;
				}
				if(! textAreaList[i].name.indexOf("freetext_")) { 
					CountLeft(eval(formEl),nowCount);
				}
			}
		}
		
		function getElementsByTagNames(list,obj) {
			if (!obj) var obj = document;
			var tagNames = list.split(',');
			var resultArray = new Array();
			for (var i=0;i<tagNames.length;i++) {
				var tags = obj.getElementsByTagName(tagNames[i]);
				for (var j=0;j<tags.length;j++) {
					resultArray.push(tags[j]);
				}
			}
			var testNode = resultArray[0];
			if (!testNode) return [];
			if (testNode.sourceIndex) {
				resultArray.sort(function (a,b) {
						return a.sourceIndex - b.sourceIndex;
				});
			}
			else if (testNode.compareDocumentPosition) {
				resultArray.sort(function (a,b) {
						return 3 - (a.compareDocumentPosition(b) & 6);
				});
			}
			return resultArray;
		}