var fromApplyfilterPublic = false;
var view_display_list = "";//MV-819
var updated_user_id = "";//ASSNS-656
//Adminfunct-94
var fromSavedReport = 0;
var downloadZipRow = 0; // MV-MV-1943
var ChurnZero = ChurnZero || [];
(function() {
    var cz = document.createElement('script'); cz.type = 'text/javascript';
    cz.async = true;
    cz.src = 'https://analytics.churnzero.net/churnzero.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(cz, s);
})();
var churn_programid=$j11('#programid').val();
var churn_email=$j11('#useremail').val();
var churn_api=$j11('#churnuapi').val();	
ChurnZero.push(['setAppKey', churn_api]); // AppKey from ChurnZero
ChurnZero.push(['setContact', churn_programid, churn_email]);
var churn_SalesforceId=$j11('#SalesforceId').val();
var churn_ChurnZerotrack=$j11('#ChurnZerotrack').val();
if(churn_SalesforceId !='' && churn_ChurnZerotrack==1){
	ChurnZero.push(['setModule', 'Reporter Exporting and Updating']);
}
//Adminfunct-94
//BG-64 : Start

//Modified For MV-819 : Start
function showSubCheckboxesForView(value)
{			
		for(i=0; i<value.length;i++)
		{
				var tempID = value[i].checkbox_parent_id.split("_")[2];
				$j11("#"+value[i].checkbox_parent_id).prop("checked", true);
				$j11("#subcheckboxspan_"+tempID).show();
				$j11("#checkpanelasso_"+tempID).prop("checked", false);

				if(value[i].checkbox_current_status == true && typeof value[i].checkbox_current_id != "undefined") 
				{
					$j11("#"+value[i].checkbox_current_id).trigger("click");
				}

				if(value[i].checkbox_previous_status == true && typeof value[i].checkbox_previous_id != "undefined") 
				{
					$j11("#"+value[i].checkbox_previous_id).trigger("click");
				}

				$j11("#"+value[i].checkbox_current_id).closest('.association_fields').addClass("check_bgcolor");
		}	
		toggleDateForView(value);
}
//Modified For MV-819 : Stops

function showSubCheckboxes(fieldIDOnly){
	var scope = angular.element(document.getElementById("postservice")).scope();
	if($j11("#checkbox_parent_"+fieldIDOnly).prop("checked") == true){
		$j11("#subcheckboxspan_"+fieldIDOnly).show();
		//$j11('.sub_check_box_'+fieldIDOnly).trigger("click");
		$j11('.sub_check_box_'+fieldIDOnly).prop("checked",true);		
	}
	else if($j11("#checkbox_parent_"+fieldIDOnly).prop("checked") == false){
		//$j11("#checkbox_parent_"+fieldIDOnly).trigger("click");
		$j11('.sub_check_box_'+fieldIDOnly).prop("checked",false);
		$j11('.sub_check_box_'+fieldIDOnly).each(function(){
			if($j11(this).prop("checked") == true)
			{
				//$j11(this).trigger("click");
				$j11('.sub_check_box_'+fieldIDOnly).prop("checked",false);
			}
		});
		$j11("#subcheckboxspan_"+fieldIDOnly).hide();
	}
	scope.myClick(fieldIDOnly,'Type3','Associations_'+fieldIDOnly,'Type3')
}

//BG-64 : End

var app = angular.module('postserviceApp', ['ngAnimate', 'ngTouch', 'ui.grid', 'ui.grid.saveState', 'ui.grid.selection', 'ui.grid.cellNav', 'ui.grid.resizeColumns', 'ui.grid.moveColumns', 'ui.grid.pinning', 'ui.grid.grouping','ui.grid.pagination']);

app.controller('postserviceCtrl', ['$scope', '$http','$timeout' ,'$compile','$sce','uiGridConstants', function ($scope, $http,$timeout, $compile,$sce, uiGridConstants) {
	var colCount=[];
	var getUserListWithPairidList=[];//TS-1098
	var getUserListWithPairidListAll=[];//TS-1098
	$scope.getUserListAll = 0;//TS-1098
	var rowCount;
	var userlistid;
	var resultUserIdList = ""; // MV-893
	var resultUserStatus = ""; // MV-893
	var rosterOrganization = $j('.rosterOrganization').val();
	var sortcolumn = "";
	var sorttype = "";
	var enableSort = false;
	var iconEnable=""; //MV-862
	var emailIcon=""; //MV-862
	if(rosterOrganization == 'volunteer') {
		enableSort = true;
	}
	$scope.resultJSON = [];	//ASSNS-656
	$scope.JCounter = 0;	//ASSNS-656
	$scope.removeFieldOrder = [];
	$scope.fieldcount = 0;
	$scope.fieldorder=[];
	$scope.sortedArr = [];
	$scope.excelfieldorder=[];
	$scope.gridOptions = {			
		enableColumnResizing: true,
		enableColumnMoving: true,
		enableSorting: enableSort,
		enableHiding: false,
		onRegisterApi: function(gridApi){
			$scope.gridApi = gridApi;	
			$scope.gridApi.colMovable.on.columnPositionChanged($scope, saveOrder);				
		}
	};  
	$scope.onloadFun = function() {
		showWaitScreen();
		$j("#fieldsortorder").val('');
		$j("#setFieldOrder").val('');	
		    $j('input[name="childpanelitem"]:checked').each(function(e,i){				
				if(!$j(this).hasClass( "check_required" )){
				  var field = $j(this).attr('id');
				  $j("#"+field).attr("checked", false);
				}
			});
		    $scope.functionA(false, false, false);			
	};
	
  	$scope.state = {};	
	$scope.myClick = function(panelid,subpanelid,fieldIDOnly,fieldtype) {	
		//BG-64 : Start	
		showLoadingOverlay();
		var fieldIDOnlyInitial = fieldIDOnly;		
		if(subpanelid == "Type3"){
			var fieldIDOnly = fieldIDOnly.split("_")[1];
			$j11(".sub_check_box_"+fieldIDOnly).click(function(){
				if($j11(".sub_check_box_"+fieldIDOnly+":visible:checked").size() > 0){
					$j11("#checkbox_parent_"+fieldIDOnly).prop("checked",true);
				}
				else if($j11(".sub_check_box_"+fieldIDOnly+":visible:checked").size() == 0)
				{
					$j11("#checkbox_parent_"+fieldIDOnly).prop("checked",false);
					$j11("#subcheckboxspan_"+fieldIDOnly).css("display","none");
				}
			}); 
			
			if($j11("#checkpanelasso_"+fieldIDOnly+":visible").prop("checked") == true){
				$j11("#current_date_span_"+fieldIDOnly).show();
			}
			else if($j11("#checkpanelasso_"+fieldIDOnly+":visible").prop("checked") == false)
			{
				$j11("#current_date_span_"+fieldIDOnly).hide();
			}
	
			if($j11("#checkpanelasso_"+fieldIDOnly+"_Previous"+":visible").prop("checked") == true){
				$j11("#historical_date_span_"+fieldIDOnly).show();
			}
			else if($j11("#checkpanelasso_"+fieldIDOnly+"_Previous"+":visible").prop("checked") == false)
			{
				$j11("#historical_date_span_"+fieldIDOnly).hide();	
			}
			
		}
		//BG-64 : End
		//Loading Fix					
		$scope.getSelectedFieldData('singleField',fieldIDOnlyInitial,fieldtype); // Export Optimization
		
		setTimeout(
			function(){
				if($scope.removeFieldOrder.length)
				{			
					var tempindex = $scope.removeFieldOrder.indexOf(panelid+'_'+fieldIDOnly.toString().replace('Associations_',''));
					//console.log(tempindex);
					if(tempindex != -1)
					{
						$scope.removeFieldOrder.splice(tempindex,1);
					}	
				}
				/* Lucky - Added to handle Select ALL/None */
				$scope.changeSelectText(panelid,subpanelid);
				/* End - Lucky */
				$scope.resetfieldorder();
				//console.log("1."+view_display_list);
				$scope.displayFieldsBasedonCheckbox(view_display_list);//MV-819			
				}
		,1000);	
		//Loading Fix
		};

	/* Start - MV-693 */
	$scope.surveyRateOptions = function(panelid,subpanelid,fieldId,fieldtype) {
		if (fieldtype == "completed") {
			$j11('#completed_dates_period').attr('disabled',false);
			if($j11('.completionratecheckbox').prop('checked') == false) {
				$j11('#surveyrateflag').val('0');
				$j11('#updateresultcompleted').val('no');
				$j11('#completedsurveyrateoption').val('');
				$scope.myClick(panelid,subpanelid,fieldId,fieldtype);
			}
		} else if (fieldtype == "missed") {
			$j11('#missed_dates_period').attr('disabled',false);
			if($j11('.missedratecheckbox').prop('checked') == false) {
				$j11('#surveyrateflag').val('0');
				$j11('#updateresultmissed').val('no');
				$j11('#missedsurveyrateoption').val('');
				$scope.myClick(panelid,subpanelid,fieldId,fieldtype);
			}
		}		
	 };
	
	$scope.surveyRateCheck = function(panelid,subpanelid,fieldId,fieldtype) {			
		$scope.resetRemoveFieldOrder();		
		$scope.changeSelectText(panelid,subpanelid);
		var surveyrateflag = $j('#surveyrateflag').val();		
		if(surveyrateflag == 0 && ((fieldtype=="completed" && $j('.completionratecheckbox').prop('checked') == true) || ( fieldtype=="missed" && $j('.missedratecheckbox').prop('checked') == true))) {			
			$j('#surveyrateflag').val('1');
			$j('.style10').html('<img src="../../images/icons/animated_loading.gif">&nbsp;&nbsp;&nbsp;<strong>We\'re running a number of formulas right now. Please hold tight.</strong>');
			$scope.functionA(false, false, false);
		}
		$scope.resetfieldorder();
		$scope.displayFieldsBasedonCheckbox();					
		
		if((fieldtype=="completed" && $j('#applyfilterforcompleted').val()=='yes') || ( fieldtype=="missed" && $j('#applyfilterformissed').val()=='yes'))
		{			
			if($j('#checkpanel_'+fieldId).prop('checked') == false)
			{  						
				var commissarr=[];
				var misarr=[];
				$j("select[name=sel_field] :selected").map(function(i, v) {					
					var reltext=$j(v).attr('rel');
					var j=i+1;					
					if(reltext==fieldtype){
						commissarr.push(j);						
					}					
				});				
				if( (fieldtype=='completed' ||fieldtype=='missed') && (commissarr.length > 0)){
					$j('#completedMissedWindowfid').val(fieldId);
					$j('#completedMissedWindowftype').val(fieldtype);
					if(commissarr.length > 0){
						$j('#completedMissedfilterrow').val(commissarr);
						$j11('#rowno').text(commissarr);
					}					
					$j('#completedmissedradio').val($j('#'+fieldtype+'_dates_period option:selected').val());					
					$j('#startperiod').val($j('#beginsurvey_completed').val());
					$j('#endperiod').val($j('#endsurvey_completed').val());
					var SurveyIdArray=[];
					$j('.surveyid_list_completed:checked').each(function(e,i){				
						var surveyId = $j(this).val();
						SurveyIdArray.push(surveyId);								
					});
					$j('#surveyid').val(SurveyIdArray);
					ColdFusion.Window.show('completedMissedWindow');
				}							
			}
		}		
    };
	/* End - MV-693 */
	/* TS-633 : START */
	// TS-633 STEP-4
	$scope.showTimeSheetDetails = function() {
		showLoadingOverlay();
		$scope.resetRemoveFieldOrder();		
		
		$scope.resetfieldorder();
		$scope.displayFieldsBasedonCheckbox();		

		if($j11(".timesheetTemplateElements:not(:checked)").length != 0) {
			$j11('.timeSheetDetailsSelectAll').html('Select All');
		} else {
			$j11('.timeSheetDetailsSelectAll').html('Select None');
		}
		hideLoadingOverlay();
	}
	/* TS-633 : END */

	$scope.arrangefields = "row";
	$scope.ArrangeFieldsChange = function () {
		/* MV_1823 : start */
		var appliedFCount = $j(".filtercount").val();
		var msg = "";
		if(appliedFCount > 1) {
			msg = validateFilters();
		}
		var currentArrangments = $j("#currentArrangeField").val();
		if(msg != "" && msg == 'invalid pattern') {
			$j('input[name="arrangefields"][value="'+currentArrangments+'"]').prop('checked', true);	
			return false;
		} else if (msg != "" && msg != 'invalid pattern') {						
			$j('input[name="arrangefields"][value="'+currentArrangments+'"]').prop('checked', true);	
			alert(msg);
			return false;		
		} else if (appliedFCount > 1 && $j('#btn_apply_filter').prop('disabled') == true) {
			$j('input[name="arrangefields"][value="'+currentArrangments+'"]').prop('checked', true);	
			alert('Please update filter value.');
			return false;
		} else {
			$j('#currentArrangeField').val($j(".arrangefields:checked").val());	
		/* MV-1823 : End */
			//showLoadingOverlay();		
			$scope.resetTable();
			if(fromApplyfilterPublic) {
				//$scope.functionA(false, false, true);
			} else {
				//$scope.functionA(false, false, false);
			}		
			reArrangeFields();
		}/* MV-1823*/
    };
	
	$scope.resetRemoveFieldOrder= function () {	
		//showLoadingOverlay();
		$scope.removeFieldOrder.each(function(e){				
			var tempindex = $scope.removeFieldOrder.indexOf(e.replace('Associations_',''));			
			if(tempindex != -1){
				$scope.removeFieldOrder.splice(tempindex,1);
			}	
		});	
		//hideLoadingOverlay();
	};
	
	$scope.selectallfields = function () {
		$scope.resetRemoveFieldOrder();
		if($j('#userAssign_Panel_Select1').html() == 'Select All Fields') {				
            $j('#userAssign_Panel_Select1').html("Select None");
	    	$j("a[id^='userAssignPanelSelect']#").html("Select None");
			$j("a[id^='userAssignSubPanelSelect_']#").html("Select None");
			$j("#association_select").html("Select None");
			$j("a[id^='association_select_']#").html("Select None");
			$j("div[id^='userAssign']:not(.timeSheetDetails)").find(':checkbox').each(function(){
				if($j(this).prop("checked") == false && $j(this).hasClass('completionratecheckbox') == false 
					&& $j(this).hasClass('missedratecheckbox') == false
				 	&& $j(this).hasClass('timesheetTemplateElements') == false && $j(this).hasClass('timesheetTemplateClass') == false) {																		
	               	
					$j(this).attr("checked", true);
					$j(this).closest('.columngroup').addClass("check_bgcolor");
				}	
				//BG-64 : Start	
				if($j(this).attr("class") == "checkbox_parent")
				{
					var subcheckboxspanid = "#subcheckboxspan_"+$j(this).attr("id").split("_")[2];
					$j(subcheckboxspanid).show();
				}
				//BG-64 : End	
			});			
			$j("input[id^='checkpanel_']#").closest('.columngroup').addClass("check_bgcolor"); 
			$j("input[id^='checkpanelasso_']#").closest('.association_fields').addClass("check_bgcolor");	
			/* Start - To uncheck Archived Fields if they are hidden */	
			if($j('.archived_fields').attr('rel') == 0) {
				$j('.HideField').find('input[type=checkbox]:checked').removeAttr('checked');
				$j("input[id^='checkpanel_']#").closest('.HideField').removeClass("check_bgcolor"); 
			}
			/* End - To uncheck Archived Fields if they are hidden */	
			$j('.selectall_additionaltext').css('display','block');
			if ($j('.completionratePanel_arrow').hasClass('showIt')) {				
				$j('.completionratePanel_arrow').addClass('hideIt');
				$j('.completionratePanel_arrow').removeClass('showIt');				
				$j('.completionratePanel').css('display','block');
			}
        } else {
                $j('#userAssign_Panel_Select1').html("Select All Fields");
				$j("a[id^='userAssignPanelSelect']#").html("Select All");
				$j("a[id^='userAssignSubPanelSelect_']#").html("Select All");
				$j("#association_select").html("Select All Associations");
				$j("a[id^='association_select_']#").html("Select All");
				$j("input[id^='checkpanel_']#").closest('.columngroup').removeClass("check_bgcolor"); 
		        $j("input[id^='checkpanelasso_']#").closest('.association_fields').removeClass("check_bgcolor");
                $j("div[id^='userAssign']").find(':checkbox').each(function(){
				    $j(':checkbox').attr("checked", false);
				    $j('.check_required').attr("checked", true);
				    $j('.check_required').closest('.columngroup').addClass("check_bgcolor");
					$j('.check_required').closest('.association_fields').addClass("check_bgcolor");
					/* Start: MV-693 */
					if($j(this).hasClass('completionratecheckbox')) {					
						$j('#completed_dates_period').val('0').change();
						$j('#completeddatedropdown').css('display','none');
						$j('#close_section3_filter_completed').css('display','none');		
						$j('#div_section3_filter_completed').css('display','none');
						$j('#belowupdatefilter_result_completed').css('display','none');
						$j('#linkTosection3_filter_completed').removeClass('collapseSection_filter').addClass('expandSection_filter');
						$j('#completed_dates_period').attr("disabled",true);
						$j('#updateresultcompleted').val('no');
						$j('#completedsurveyrateoption').val('');			
					} 
					if ($j(this).hasClass('missedratecheckbox')) {				
						$j('#missed_dates_period').val('0').change();
						$j('#missed_dates_period').attr("disabled",true);	
						$j('#misseddatedropdown').css('display','none');
						$j('#close_section3_filter_missed').css('display','none');		
						$j('#div_section3_filter_missed').css('display','none');
						$j('#belowupdatefilter_result_missed').css('display','none');
						$j('#linkTosection3_filter_missed').removeClass('collapseSection_filter').addClass('expandSection_filter');	
						$j('#updateresultmissed').val('no');
						$j('#missedsurveyrateoption').val('');
					}	
					$j('.selectall_additionaltext').css('display','none');
					/* End: MV-693 */
					//BG-64 : Start	
					if($j(this).attr("class") == "checkbox_parent")
					{
						var subcheckboxspanid = "#subcheckboxspan_"+$j(this).attr("id").split("_")[2];
						$j(subcheckboxspanid).hide();
					}
					//BG-64 : End	
					// TS-633 : START
					if($j(this).hasClass('timesheetTemplateElements') || $j(this).hasClass('timesheetTemplateClass')) {
						$j(this).closest('.columngroup').removeClass("check_bgcolor");
						$j('.timesheetTemplateDetails').css('display','none');
					}
					$j(".timeSheetDetailsSelectAll").html("Select All");
					// TS-633 : END
                });				
        }		
		//Loading Fix
		showLoadingOverlay();	
		setTimeout(
			function(){
				$scope.resetfieldorder();
				$scope.getSelectedFieldData('panelFields',0,'');
				//$scope.displayFieldsBasedonCheckbox();	
			}
		,1000);	
		//Loading Fix

    };
	
	var selText;
	$scope.selectPanelAllFields = function (panelid,subpanelid) {
		$scope.resetRemoveFieldOrder();
		 var thisclass = 'userAssignPanel_' + panelid + '_Select';
		 var childid= thisclass +"_Child";
		 var subchildid = thisclass +"_SubChild";				
		 if($j('.' + thisclass).html() == 'Select All' || $j('.' + thisclass).html() == 'Select All Associations') {
			selText = $j('.' + thisclass).html();
			$j('.'+ thisclass).html("Select None");						
			$j('.'+ childid).attr("checked", true);			
			//$j('.'+ subchildid).attr("checked", true); Commented for MV-1456			
			$j("a[name^='"+thisclass+"']").html("Select None");
			$j('.'+ childid).closest('.columngroup').addClass("check_bgcolor");
			$j('.'+ childid).closest('.association_fields').addClass("check_bgcolor");
			//$j('.'+ subchildid).closest('.columngroup').addClass("check_bgcolor"); Commented for MV-1456
			$j('.'+ subchildid).closest('.association_fields').addClass("check_bgcolor");
			/* Start - To uncheck Archived Fields if they are hidden */	
			if($j('.archived_fields').attr('rel') == 0) {
				$j('.HideField').find('input[type=checkbox]:checked').removeAttr('checked');
				$j("input[id^='checkpanel_']#").closest('.HideField').removeClass("check_bgcolor"); 
			}
			//BG-64 : Start
			if($j('.' + thisclass).attr('id').trim() == 'association_select' || $j('.' + thisclass).attr('id').trim() == 'association_select_Type3Associations'){
				$j(".checkbox_parent").attr("checked", true);	
				$j(".subcheckboxspan").show();	
			}
			//BG-64 : Stops
			/* End - To uncheck Archived Fields if they are hidden */	
		} else {
			$j('.'+ thisclass).html(selText);
			//$j('.'+ thisclass).html("Select All");
			$j('.'+ childid).attr("checked", false);
			//$j('.'+ subchildid).attr("checked", false); Commented for MV-1456
			$j("a[name^='"+thisclass+"']").html("Select All");
			$j('.'+ childid).closest('.columngroup').removeClass("check_bgcolor");
			$j('.'+ childid).closest('.association_fields').removeClass("check_bgcolor");
			//$j('.'+ subchildid).closest('.columngroup').removeClass("check_bgcolor"); Commented for MV-1456
			$j('.'+ subchildid).closest('.association_fields').removeClass("check_bgcolor");
			$j('.check_required').attr("checked", true);
			$j('.check_required').closest('.columngroup').addClass("check_bgcolor");
			$j('.check_required').closest('.association_fields').addClass("check_bgcolor");
			//BG-64 : Start
			if($j('.' + thisclass).attr('id').trim() == 'association_select' || $j('.' + thisclass).attr('id').trim() == 'association_select_Type3Associations'){
				$j(".checkbox_parent").attr("checked", false);	
				$j(".subcheckboxspan").hide();	
			}
			//BG-64 : Stops
		}	
		//Loading Fix
		showLoadingOverlay();	
		setTimeout(
			function(){
				$scope.changeSelectText(panelid,subpanelid);
				$scope.resetfieldorder();
				//$scope.displayFieldsBasedonCheckbox(); // Volunteer Export Optimization
				$scope.getSelectedFieldData('panelFields',0,'');
			}
		,1000);	
		//Loading Fix
	};
	
	$scope.selectSubPanelAllFields = function (panelid,subpanelid) {
		$scope.resetRemoveFieldOrder();
		var subchildid= 'userAssignPanel_' + subpanelid + '_Select_SubChild';			
		var selectallsubpanelclass = 'userAssignPanel_' + subpanelid + '_SelectSubPanel';	
		if($j('.' + selectallsubpanelclass).html() == 'Select All') {
			//Added for BG-64 : Start
			if($j('.' + selectallsubpanelclass).attr('id').trim() == 'association_select' || $j('.' + selectallsubpanelclass).attr('id').trim() == 'association_select_Type3Associations'){
				$j(".checkbox_parent").attr("checked", true);
				$j(".subcheckboxspan").show();
				$j(".current_date_span").show(); 
			  $j(".historical_date_span").show();
			}
			//Added for BG-64 : Stops
			$j('.' + selectallsubpanelclass).html("Select None");
			$j('.'+subchildid).attr("checked", true);
			$j('.'+subchildid).closest('.columngroup').addClass("check_bgcolor"); 
			$j('.'+subchildid).closest('.association_fields').addClass("check_bgcolor");
			/* Start - To uncheck Archived Fields if they are hidden */	
			if($j('.archived_fields').attr('rel') == 0) {
				$j('.HideField').find('input[type=checkbox]:checked').removeAttr('checked');
				$j("input[id^='checkpanel_']#").closest('.HideField').removeClass("check_bgcolor"); 
			}
			/* End - To uncheck Archived Fields if they are hidden */		
		} else {
			//Added for BG-64
			if($j('.' + selectallsubpanelclass).attr('id').trim() == 'association_select' || $j('.' + selectallsubpanelclass).attr('id').trim() == 'association_select_Type3Associations'){
				$j(".checkbox_parent").attr("checked", false);
				$j(".subcheckboxspan").hide();
				$j(".current_date_span").hide();
				$j(".historical_date_span").hide();
			}
			//Added for BG-64 : Stops	
			$j('.' + selectallsubpanelclass).html("Select All");
			$j('.'+subchildid).attr("checked", false);
			$j('.'+subchildid).closest('.columngroup').removeClass("check_bgcolor"); 
			$j('.'+subchildid).closest('.association_fields').removeClass("check_bgcolor");
		}
		
		//Loading Fix
		showLoadingOverlay();	
		setTimeout(
			function(){
				$scope.changeSelectText(panelid,subpanelid);
		    		$scope.resetfieldorder();
				$scope.displayFieldsBasedonCheckbox(); // Volunteer Export Optimization
				$scope.getSelectedFieldData('panelFields',0,'');
			}
		,1000);
		//Loading Fix	

	};
/*	
	$scope.selectAssociationAllFields = function (panelid) {			
		showLoadingOverlay();
		$scope.resetfieldorder();
		$scope.displayFieldsBasedonCheckbox();		
	};*/
	
	
	$scope.addFilter = function (rel,updatefilepattern, fromDisplayField) {	
		updateFilterValues(rel,updatefilepattern,$compile,$scope, fromDisplayField);//Parameters Added For ASSNS-656	
		/* Start: BG-112 */ 
		if($j1('#archived_fields').html() === 'Show Archived Fields') {
			setTimeout(function(){
					$j1('.HideArchivedField').attr('disabled',true);
					$j1('.sel_field').select2({
				   templateResult: function(option, container) {
					   var myOption = $j1('.sel_field').find('option[value="' + option.id + '"]');
					   if(typeof option.id == "string" && (option.id.indexOf("timesheetTemplate") != -1 || option.id.indexOf("ServiceTerms") != -1 || option.id.indexOf("approvedhrs") != -1
					   || option.id.indexOf("pendingHrs") != -1 || option.id.indexOf("disallowedhrs") != -1 || option.id.indexOf("FirstDate") != -1 || option.id.indexOf("RecentDate") != -1 || option.id.indexOf("TSPersonalStartDate") != -1 || option.id.indexOf("TSPersonalEndDate") != -1 //TS-1223/TS-1341 TS-1112
					   || option.id.indexOf("BlackoutDates") != -1 || option.id.indexOf("TSStatus") != -1 || option.id.indexOf("TSTimeOffCalendar") != -1 || option.id.indexOf("submittedHrs") != -1 )) { //TS-1395/phase-2
							if(myOption.hasClass("timesheetDetailsOptions") && !$j1(container).hasClass("toggle-display-show-" + $j1(option.element).val().split("_")[1])){
								var templateid = $j1(option.element).val().split("_")[1];
								if(templateid != undefined && $j1("#timesheetTemplate_" + templateid).prop("checked")){
									$j1(container).addClass('toggle-display-show-' + templateid);
								} else if(templateid != undefined) {
									$j1(container).addClass('toggle-display-show-' + templateid + ' toggle-display-' + templateid);
								}
							}
						}
						if (myOption.css('display') != 'none') {
								return option.text;
						}
					  	return false;
				   }
				});
			},1000);
		} else {
			setTimeout(function(){
								$j1('.HideArchivedField').attr('disabled',false);
								$j1('.sel_field').select2();},1000);
		}
		/* End: BG-112 */
		//Commented For ASSNS-656	
		/*
		var loadData = updateFilterValues(rel);		
		if(loadData) {
			var filtercount1 = parseInt($j('.filtercount').val());				
			var button = $j('.btn_add_filter_' + rel).html();			
			if(button == 'Add') {
				$j('.btn_add_filter_' + rel).html('Edit');
				$j('.btn_cancel_filter_' + rel).html('Remove');
				var filtercount1 = parseInt($j('.filtercount').val());
				var filterButtons = "<div id='filterButtons_" + filtercount1 + "' class='filterButtons_" + filtercount1 + "' style='margin-top:7px'><div class='buttonBlock pull-left filter_btn_box'><a class='margin-left-6 filter_add_btn btn_add_filter btn_add_filter_" + filtercount1 + "'  name='Action' rel='"+ filtercount1 +"' ng-click='addFilter(" + filtercount1 + ",1,false)'>Add</a></div><div class='buttonBlock pull-left filter_btn_box'><a class='filter_remove_btn btn_cancel_filter btn_cancel_filter_" + filtercount1 + "'  name='Action' rel='" + filtercount1 + "' ng-click='removeFilter(" + filtercount1 + ")'>Cancel</a></div></div>"										
				var temp = $compile(filterButtons)($scope);
				angular.element(document.getElementById('subfilter_' + filtercount1)).append(temp);				
			}
			if(updatefilepattern==1){
				if($j11('select[name="sel_action"]').prop("disabled")==false)
					$scope.updateFilterPattern();
				else{
					$j11('select[name="sel_action"]').val('');
					$j11('select[name="sel_action"]').prop("disabled",true);
				}
					
			}
			//$scope.functionA(false);
		}
		*/
	};
	
	$scope.removeFilter = function (rel) {	
		$j('#errormsg_'+rel).remove();//Added for ASSNS-656 *help_tooltip2 class removed from patternButtons
		//MV-794 Related
		if($j('.errormsg_class:visible').length == 0)
		{
			$j('#filterpattern').css('display','block');	
			$j('#btn_apply_filter').prop("disabled", false);
			//$j('#btn_apply_filter').prop("disabled", true);//BG-110(MV)
			$j('.filterpattern').css('display','none');//BG-110(MV)
		}
		if($j('.btn_cancel_filter_' + rel).html() == 'Remove') {
				var patternButtons = '<div class="vol_fields tmsht-widt-100 pattern" id="editablefilterpattern"><label class="pull-left"><a id="editfilterpattern" class="editfilterpattern" ng-click="editPattern()">Edit Pattern</a></label><div class="help_tooltip"><img src="../../images/icons/question_icon_bw.gif" onmouseover="this.src=\'../../images/icons/question_icon.gif\'" onmouseout="this.src=\'../../images/icons/question_icon_bw.gif\'" border="0" alt=""/><span class="tooltiptext help_tooltip-bottom">To edit filter pattern, click on Edit Pattern and then save.</span></div></div>';	
				var oldPattern = $j11('#hiddenpattern').val();	
				
				if($j('#updateresultcompleted').val() == 'yes' || $j('#updateresultmissed').val() == 'yes') 
					$j('#surveyrateflag').val('1');

				if($j11('select[name="sel_action"]').prop("disabled")==false){
					$j11('#filtervaluepattern').val(oldPattern);
					$j11('#removeFilterFlage').val('0');
				}
				else{
					$j11('#removeFilterFlage').val('1');
				}	
				$j11('#filtervaluepattern').attr('disabled',true);
				$j11('#editablefilterpattern').html('');
				$j11('#editablefilterpattern').remove();	
				var temp = $compile(patternButtons)($scope);
				angular.element(document.getElementById('filterpattern')).append(temp);							
				var filtercount1 = parseInt($j('.filtercount').val());
				var removedFilter = rel;			
				if(filtercount1>1 && filtercount1!=rel) {
					filtercount1 = filtercount1 - 1;
					$j('.filtercount').val(filtercount1);
					$j( ".subfilter_" + rel).html('');
					$j( ".subfilter_" + rel).remove();					
					var j=removedFilter + 1;
					var k=filtercount1+1;					
					for (i = j; i <=k; i++){
						var filterno = parseInt($j('.filtercount_' + i).attr('rel'));
						var newFilterNo = filterno - 1;
						$j('.filtercount_' + i).html("<span style='line-height:21px'>" + newFilterNo + "</span>");
						$j('.filtercount_' + i).attr('rel',newFilterNo);
						$j('.filtercount_' + i).addClass('filtercount_' + newFilterNo);
						$j('.filtercount_' + i).removeClass('filtercount_' + i);	
						$j('.logical_' + i).addClass('logical_' + newFilterNo);
						$j('.logical_' + i).removeClass('logical_' + i);
						$j('.sel_action_' + i).addClass('sel_action_' + newFilterNo);
						$j('.sel_action_' + i).removeClass('sel_action_' + i);	
						$j('.sel_field_' + i).attr('rel',newFilterNo);
						$j('.sel_field_' + i).addClass('sel_field_' + newFilterNo);
						$j('.sel_field_' + i).removeClass('sel_field_' + i);	
						$j('.field_operators_' + i).addClass('field_operators_' + newFilterNo);
						$j('.field_operators_' + i).removeClass('field_operators_' + i);
						$j('.filterOperator_' + i).attr('rel',newFilterNo);
						$j('.filterOperator_' + i).addClass('filterOperator_' + newFilterNo);
						$j('.filterOperator_' + i).removeClass('filterOperator_' + i);
						$j('.filterOperator_' + newFilterNo).attr('name','filterOperator_' + newFilterNo);

						$j(".filterinput_" + i).find(".datelinkSingle").attr('for','datelink_' + newFilterNo);// BG-197
						$j(".filterinput_" + i).find(".datelink1").attr('for','datelink1_' + newFilterNo);// BG-197
						$j(".filterinput_" + i).find(".datelink2").attr('for','datelink2_' + newFilterNo);// BG-197
						$j('.filterinput_' + i).addClass('filterinput_' + newFilterNo);
						$j('.filterinput_' + i).removeClass('filterinput_' + i);

						$j("#datelink_" + i).attr('id','datelink_' + newFilterNo);// BG-197
						$j("#datelink1_" + i).attr('id','datelink1_' + newFilterNo);// BG-197
						$j("#datelink2_" + i).attr('id','datelink2_' + newFilterNo);// BG-197
						$j('.filtervalue_' + i).attr('rel',newFilterNo);
						$j('.filtervalue_' + i).addClass('filtervalue_' + newFilterNo);
						$j('.filtervalue_' + i).removeClass('filtervalue_' + i);
						$j('.filter_icon_' + i).addClass('filter_icon_' + newFilterNo);
						$j('.filter_icon_' + i).removeClass('filter_icon_' + i);
						$j('.search_magnifier_' + i).attr('rel',newFilterNo);
						$j('.search_magnifier_' + i).addClass('search_magnifier_' + newFilterNo);
						$j('.search_magnifier_' + i).removeClass('search_magnifier_' + i);
						
						if(document.getElementById('errormsg_' + i)!=null) {
							document.getElementById('errormsg_' + i).id = 'errormsg_' + newFilterNo;
						}
						
						$j('.subfilter_' + i).addClass('subfilter_' + newFilterNo);
						$j('.subfilter_' + i).attr('id','subfilter_' + newFilterNo);
						$j('.subfilter_' + i).removeClass('subfilter_' + i);	
						
						$j( ".filterButtons_" + i).html('');
						$j( ".filterButtons_" + i).remove();
						if (i < filtercount1 + 1) {
							var filterButtons = "<div style='float:right; padding-right:5px;'><div id='filterButtons_" + newFilterNo + "' class='filterButtons_" + newFilterNo + "' style='margin-top:7px'><div class='buttonBlock pull-left filter_btn_box' style='width:54px; text-align:left !important;margin-left: 0px !important;'><a class='margin-left-6 filter_add_btn btn_add_filter btn_add_filter_" + newFilterNo + "'  name='Action' rel='"+ newFilterNo +"' ng-click='addFilter(" + newFilterNo + ",1,false)'>Edit</a></div><div class='buttonBlock pull-left filter_btn_box' style='width:55px;text-align: left !important; margin-right: 5px; margin-left: 0px !important;'><a class='filter_remove_btn btn_cancel_filter btn_cancel_filter_" + newFilterNo + "'  name='Action' rel='" + newFilterNo + "' ng-click='removeFilter(" + newFilterNo + ")'>Remove</a></div></div></div>";//ASSNS-656
						} else {
							var filterButtons = "<div style='float:right; padding-right:5px;'><div id='filterButtons_" + newFilterNo + "' class='filterButtons_" + newFilterNo + "' style='margin-top:7px'><div class='buttonBlock pull-left filter_btn_box' style='width:54px; text-align:left !important;margin-left: 0px !important;'><a class='margin-left-6 filter_add_btn btn_add_filter btn_add_filter_" + newFilterNo + "'  name='Action' rel='"+ newFilterNo +"' ng-click='addFilter(" + newFilterNo + ",1,false)'>Add</a></div><div class='buttonBlock pull-left filter_btn_box' style='width:55px;text-align: left !important; margin-right: 5px; margin-left: 0px !important;'><a class='filter_remove_btn btn_cancel_filter btn_cancel_filter_" + newFilterNo + "'  name='Action' rel='" + newFilterNo + "' ng-click='removeFilter(" + newFilterNo + ")'>Cancel</a></div></div></div>";//ASSNS-656
						}
						var temp = $compile(filterButtons)($scope);
						angular.element(document.getElementById('subfilter_' + newFilterNo)).append(temp);				
					}									
					//$scope.updateFilterPattern();
					//$scope.functionA(false);				
				}
				filtercount2 = parseInt($j('.filtercount').val());		
				if(filtercount2 == 1) {		
					showLoadingOverlay();
					$j('#filtervaluepattern').val('');
					$j('.filterpattern').css('display','none');
					$j('#clearfilter').css('display','none');
					$j('#btn_apply_filter').prop("disabled", true)
					$j('.errormsg_class').remove(); //Added for ASSNS-656	
					$j('.filtercount_'+rel).addClass('padding-left-10');
					$j('.filtercount_' + rel).html('');	
					$j('.filtercount_' + rel).css('display','none');
					$j('.sel_action_' + rel).remove('');
					$j('.sel_field_' + rel).addClass('tmsht-widt-215');
					$j('.sel_field_' + rel).removeClass('tmsht-widt-134');
					$j('.filtervalue_' + rel).addClass('tmsht-widt-161');
					$j('.filtervalue_' + rel).removeClass('tmsht-widt-134');
					$j('.ffilterby').removeClass('text-right');
					$j('.fOperator').removeClass('text-right');
					$j('.fValue').removeClass('text-right');									
					$j('.filterbylable').removeClass('margin-right-63');
					$j('.operatorlabel').removeClass('margin-right-63');
					$j('.valuelabel').removeClass('margin-right-102');	

					/* Start: BG-112 */
					$j1('.sel_field_' + rel).select2('destroy');	
					$j('.filterOperator_' + rel).html('');		
					$j('.sel_field_' + rel +' option[value="0"]').attr('selected', true);
					$j('.sel_field_' + rel).trigger("change");	
					if($j1('#archived_fields').html() === 'Show Archived Fields') {
						$j1('.HideArchivedField').attr('disabled',true);
						$j1('.sel_field_' + rel).select2({
						   templateResult: function(option, container) {
							  	var myOption = $j1('.sel_field').find('option[value="' + option.id + '"]');
							  	if(typeof option.id == "string" && (option.id.indexOf("timesheetTemplate") != -1 || option.id.indexOf("ServiceTerms") != -1 || option.id.indexOf("approvedhrs") != -1
								|| option.id.indexOf("pendingHrs") != -1 || option.id.indexOf("disallowedhrs") != -1 || option.id.indexOf("FirstDate") != -1 || option.id.indexOf("RecentDate") != -1 || option.id.indexOf("TSPersonalStartDate") != -1 || option.id.indexOf("TSPersonalEndDate") != -1 //TS-1223/TS-1341 TS-1112
								|| option.id.indexOf("BlackoutDates") != -1 || option.id.indexOf("TSStatus") != -1 || option.id.indexOf("TSTimeOffCalendar") != -1 || option.id.indexOf("submittedHrs") != -1 )) { //TS-1395/phase-2
									if(myOption.hasClass("timesheetDetailsOptions") && !$j1(container).hasClass("toggle-display-show-" + $j1(option.element).val().split("_")[1])){
										var templateid = $j1(option.element).val().split("_")[1];
										if(templateid != undefined && $j1("#timesheetTemplate_" + templateid).prop("checked")){
											$j1(container).addClass('toggle-display-show-' + templateid)
										} else if (templateid != undefined){
											$j1(container).addClass('toggle-display-show-' + templateid + ' toggle-display-' + templateid);
										}
									}
								}
							  if (myOption.css('display') != 'none') {
									return option.text;
							  }
							  return false;
						   }
						});
					} else {
						$j1('.HideArchivedField').attr('disabled',false);
						$j1('.sel_field_' + rel).select2();
					}
					/* End: BG-112 */
					fromApplyfilterPublic = false;
					$j('#filterApplied').val('0');
					//$scope.functionA(false, false, false);				
					$scope.getSelectedFieldData('panelFields',0,'');
				} else {		
					if($j11('select[name="sel_action"]').prop("disabled")==false)
						$scope.updateFilterPattern();		
				}
				if(filtercount2 > 1) {
					$j('.sel_action_1').html('&nbsp;');		
					$j('.filterpattern').css('display','block'); // MV-1064
				}	
				//mv-693
				var comarr=[];
				var misarr=[];
				$j("select[name=sel_field] :selected").map(function(i, v) {					
					var reltext=$j(v).attr('rel');
					var j=i+1;					
					if(reltext=='completed'){
						comarr.push(j);						
					}else if(reltext=='missed'){
						misarr.push(j);						
					}
				});		
				if(comarr.length==0)
					$j('#applyfilterforcompleted').val('no');
				if(misarr.length==0)
					$j('#applyfilterformissed').val('no');				
				//mv-693
		} else {
			var filtercount1 = parseInt($j('.filtercount').val());	
			if(rel == 1) {
				$j('.filterpattern').css('display','none');
				$j('#btn_apply_filter').prop("disabled", true);
			}
			if($j("#editpatternflage").val() == 0) {					
				if(filtercount1>1) {
					$j('.logical_' + rel + ' option[value="1"]').attr('selected', true);				
				}
				$j('.sel_field_' + rel + ' option[value="0"]').attr('selected', true);
				//$j('.sel_field_' + rel).trigger("change");
				/* MV-1064 */
				$j1('.sel_field_' + rel).select2();
				$j1('.sel_field_' + rel).val('0').change();
				$j(".filterOperator_"+rel).html('');
				$j(".filtervalue_"+rel).val('');
				$j('.search_magnifier_'+rel).hide();
				if(rel > 1){
					$j('.filterpattern').css('display','block'); 
				}
				/* MV-1064 */
			}			
		}
	};
	
	$scope.editPattern = function () {		
		/*var patternButtons = "<div class='vol_fields tmsht-widt-100 pattern' id='editablefilterpattern'><div class='buttonBlock pull-left' style='width:auto;margin-top:8px'><a class='savepattern' id='savepattern' ng-click='savePattern()'>Save</a></div><div class='buttonBlock pull-left' style='width:auto;margin-left:8px;margin-top:8px'><a class='cancelpattern' id='cancelpattern' ng-click='cancelPattern()'>Cancel</a></div></div>";	*/
		var patternButtons = "<div class='pattern pull-left' id='editablefilterpattern' style='padding-left:3px;margin-top:7px;'><div class='buttonBlock pull-left undopattern' style='width:auto;display:none;margin-right:8px;'><a class='undopattern' id='undopattern' ng-click='undoPattern()'>Undo</a></div><div class='buttonBlock pull-left' style='width:auto;'><a class='removepattern' id='removepattern' ng-click='removeCustomPattern()'>Remove</a></div></div>";
		
		
		var currentPattern = $j11('#filtervaluepattern').val();	
		$j11('#hiddenpattern').val(currentPattern);
		$j11('#filtervaluepattern').attr('disabled',false);
		$j11('select[name="sel_action"]').attr('disabled', true);//MV-692
		$j11('select[name="sel_action"]').val('');//MV-692
		$j11('#editablefilterpattern').html('');
		$j11('#editablefilterpattern').remove();	
		var temp = $compile(patternButtons)($scope);
		angular.element(document.getElementById('filterpattern')).append(temp);
	};
	
	$scope.savePattern = function () {
		var checkPattern = validateFilterPattern();
		if(checkPattern) {
			var patternButtons = '<div class="vol_fields tmsht-widt-100 pattern" id="editablefilterpattern"><label class="pull-left"><a id="editfilterpattern" class="editfilterpattern" ng-click="editPattern()">Edit Pattern</a></label><div class="help_tooltip"><img src="../../images/icons/question_icon_bw.gif" onmouseover="this.src=\'../../images/icons/question_icon.gif\'" onmouseout="this.src=\'../../images/icons/question_icon_bw.gif\'" border="0" alt=""/><span class="tooltiptext help_tooltip-bottom">To edit filter pattern, click on Edit Pattern and then save.</span></div></div>';				
			$j11('#filtervaluepattern').attr('disabled',true);
			$j11('#editablefilterpattern').html('');
			$j11('#editablefilterpattern').remove();	
			var temp = $compile(patternButtons)($scope);
			var oldPattern = $j11('#hiddenpattern').val();
			var currentPattern = $j11('#filtervaluepattern').val().trim();			
			angular.element(document.getElementById('filterpattern')).append(temp);	
			showLoadingOverlay();
			if (oldPattern != currentPattern) {
				currentPattern = currentPattern.replace(/and/ig,'AND');
				currentPattern = currentPattern.replace(/or/ig,'OR');
				$j11('#filtervaluepattern').val(currentPattern);
				//$scope.functionA(false);
			}			
			hideLoadingOverlay();	
		}
		/*else{ commented for MV-1885
			var patternButtons = '<div class="vol_fields tmsht-widt-100 pattern" id="editablefilterpattern"><label class="pull-left"><a id="editfilterpattern" class="editfilterpattern" ng-click="editPattern()">Edit Pattern</a></label><div class="help_tooltip help_tooltip2"><img src="../../images/icons/question_icon_bw.gif" onmouseover="this.src=\'../../images/icons/question_icon.gif\'" onmouseout="this.src=\'../../images/icons/question_icon_bw.gif\'" border="0" alt=""/><span class="tooltiptext help_tooltip-bottom">To edit filter pattern, click on Edit Pattern and then save.</span></div></div>';				
			$j11('#filtervaluepattern').attr('disabled',true);
			$j11('#editablefilterpattern').html('');
			$j11('#editablefilterpattern').remove();
			var temp = $compile(patternButtons)($scope);
			angular.element(document.getElementById('filterpattern')).append(temp);
			hideLoadingOverlay();
		}*/
		return checkPattern;
	};
	
	$scope.undoPattern = function () {
		$j11('#filtervaluepattern').val($j11('#hiddenpattern').val());
		$j11('#undopattern').hide();
	};
	
	$scope.removeCustomPattern = function () {
		var patternButtons = '<div class="vol_fields pattern pull-left" id="editablefilterpattern" style=""><label class="pull-left"><a id="editfilterpattern" class="editfilterpattern" ng-click="editPattern()">Edit Pattern</a></label><div class="help_tooltip help_tooltip2"><img src="../../images/icons/question_icon_bw.gif" onmouseover="this.src=\'../../images/icons/question_icon.gif\'" onmouseout="this.src=\'../../images/icons/question_icon_bw.gif\'" border="0" alt=""/><span class="tooltiptext help_tooltip-bottom">To edit filter pattern, click on Edit Pattern and then save.</span></div></div>';
			
			if($j11('#editpatternflage').val()!=1){
				$j11('select[name="sel_action"]').prop("disabled",false);
				pattern = $j11('#patternforrestore').val()
				pattern = pattern.replace(/and/ig,'&&');
				pattern = pattern.replace(/or/ig,'||');
				var operatorsInString = get_logical(pattern);
				var filterIndex = 2;
				if(operatorsInString != null) {
					$j11('select[name="sel_action"]').val('1');
					for(i=0; i<=operatorsInString.length; i++) {					
						var htmldiv = "<select class='margin-top-5 logical_width pull-right margin-right-5 logical logical_"+ filterIndex + "'  name='sel_action' style='margin-left:18px;'>";
						if(operatorsInString[i] == '&&') {									
							htmldiv = htmldiv + "<option value='1' selected>AND</option><option value='2'>OR</option>";				
						} else if (operatorsInString[i] == '||') {						
							htmldiv = htmldiv + "<option value='1' >AND</option><option value='2' selected>OR</option>";				
						} else {
							htmldiv = htmldiv + "<option value='1' selected>AND</option><option value='2'>OR</option>";
						}
						htmldiv = htmldiv + "</select>";
						$j11('.sel_action_' + filterIndex).html(htmldiv);
						filterIndex++;
					}								
				}
				else{
					var filtercountoperator = parseInt($j('.filtercount').val());
					if(filtercountoperator > 2) {
						for(var k=2;k<=filtercountoperator;k++) {
							var htmldiv = "<select class='margin-top-5 logical_width pull-right margin-right-5 logical logical_"+ k + "'  name='sel_action' style='margin-left:18px;'>";					
							htmldiv = htmldiv + "<option value='1' selected>AND</option><option value='2'>OR</option>";
							htmldiv = htmldiv + "</select>";
							$j11('.sel_action_' + k).html(htmldiv);							
						}
					} else {
						var htmldiv = "<select class='margin-top-5 logical_width pull-right margin-right-5 logical logical_"+ filterIndex + "'  name='sel_action' style='margin-left:18px;'>";					
						htmldiv = htmldiv + "<option value='1' selected>AND</option><option value='2'>OR</option>";
						htmldiv = htmldiv + "</select>";
						$j11('.sel_action_' + filterIndex).html(htmldiv);
					}
				}
				if($j11('#removeFilterFlage').val()==1){
					$scope.updateFilterPattern();	
				}
			}
		$j11('#filtervaluepattern').val($j11('#patternforrestore').val());
		$j11('#filtervaluepattern').attr('disabled', true);
		$j11('#editablefilterpattern').html('');
		$j11('#editablefilterpattern').remove();
		var temp = $compile(patternButtons)($scope);
		angular.element(document.getElementById('filterpattern')).append(temp);
	};
	
	
	
	$scope.cancelPattern = function () {
		var patternButtons = '<div class="vol_fields tmsht-widt-100 pattern" id="editablefilterpattern"><label class="pull-left"><a id="editfilterpattern" class="editfilterpattern" ng-click="editPattern()">Edit Pattern</a></label><div class="help_tooltip help_tooltip2"><img src="../../images/icons/question_icon_bw.gif" onmouseover="this.src=\'../../images/icons/question_icon.gif\'" onmouseout="this.src=\'../../images/icons/question_icon_bw.gif\'" border="0" alt=""/><span class="tooltiptext help_tooltip-bottom">To edit filter pattern, click on Edit Pattern and then save.</span></div></div>';	
		var oldPattern = $j11('#hiddenpattern').val();	
		$j11('#filtervaluepattern').val(oldPattern);
		$j11('#filtervaluepattern').attr('disabled',true);
		$j11('#editablefilterpattern').html('');
		$j11('#editablefilterpattern').remove();	
		var temp = $compile(patternButtons)($scope);
		angular.element(document.getElementById('filterpattern')).append(temp);		
	};
	//$scope.fieldorder=[];
	$scope.functionA=function(generateExcel, fromSavedReport, fromApplyfilter){		
		var data =[];
		var fieldarr = [];		
		var associationarr = [];
		var programid = $j('#programid').val();
		var userid = $j('#userid').val();
		var usertype = $j('#usertype').val();
		//var rosterOrganization = $j('.rosterOrganization').val();
		var arrangefieldsby = $j('.arrangefields:checked').val();		
		//$scope.arrangefields=arrangefieldsby;	
		/*----------Mv-693--------------*/
		var completedradio = $j('#completed_dates_period option:selected').val();	
		var missedradio = $j('#missed_dates_period option:selected').val();	
		var selectedFieldType = [];
		/*----------Mv-693--------------*/
		data.push({			
			"rosterOrganization": rosterOrganization
		});
		if(rosterOrganization == 'custom') {
			var customfields = $j('.customfields').val();
			var customfieldvalue = $j('.customfieldvalue').val();
			// added below line for long list cfqueryparam
			var customfieldvaluenames = $j('.customfieldvaluenames').val();			
			data.push({				
				"customfields": customfields
			});
			data.push({			
				"customfieldvalue": customfieldvalue
			});
			//added below code for long list issue
			data.push({			
				"customfieldvaluenames": customfieldvaluenames
			});
		} else if(rosterOrganization == 'volunteer') {
			var volunlist = $j('.volunlist').val();
			data.push({			
				"volunlist": volunlist
			});
		} else if(rosterOrganization == 'association') {
			var associationlist = $j('.associationlist').val();
			data.push({				
				"associationlist": associationlist
			});
		} else if(rosterOrganization == 'site') {
			var sitelist = $j('.sitelist').val();
			data.push({				
				"sitelist": sitelist
			});
		}	
		$j('input[name="childpanelitem"]:checked').each(function(e,i){
			var field = $j(this).attr('id');			
			var fieldId = $j(this).val();
			fieldarr.push(fieldId);
			selectedFieldType.push($j(this).attr('fieldType'));
			//fieldorder.push($j(this).attr('panelid')+'_'+fieldId);
		});	
		
		fieldarr.push($j('input[fieldtype="userid"]').val());
		
		$j('input[name="childassociationitem"]:checked').each(function(e,i){
			var field = $j(this).attr('id');
			var fieldId = $j(this).val();
			associationarr.push(fieldId);
			selectedFieldType.push($j(this).attr('fieldType'));
			//fieldorder.push($j(this).attr('panelid')+'_'+fieldId);
		});	
					
		var filtercount1 = parseInt($j('.filtercount').val());			
		var filter = "";
		var paneltype = "";
		var fieldtype = "";
		var operator = "";
		var filtervalue = "";
		var logical = " ";
		var filterApplied = "";
		var filtercompoption = "";
		
		/* Start - MV-693 */
		var completedstartperiod = "";
		var completedendperiod = "";
		var missedstartperiod = "";
		var missedendperiod = "";	
		var completedSurveyIdArray = [];
		var missedSurveyIdArray = [];
		if($j("#completed_dates_period option:selected").val() === 'completed' && $j('#updateresultcompleted').val()=='yes') {
			$j('.surveyid_list_completed:checked').each(function(e,i){				
				var surveyId = $j(this).val();
				completedSurveyIdArray.push(surveyId);								
			});	
			if(completedSurveyIdArray.length == 0) {
				completedstartperiod = $j('#beginsurvey_completed option:selected').val();
				completedendperiod = $j('#endsurvey_completed option:selected').val();
			}
		}
		if($j("#missed_dates_period option:selected").val() === 'missed' && $j('#updateresultmissed').val()=='yes') {
			$j('.surveyid_list_missed:checked').each(function(e,i){				
				var surveyId = $j(this).val();
				missedSurveyIdArray.push(surveyId);								
			});	
			if(missedSurveyIdArray.length == 0) {
				missedstartperiod = $j('#beginsurvey_missed option:selected').val();
				missedendperiod = $j('#endsurvey_missed option:selected').val();
			}
		}		
		/* End - MV-693 */	
		if(fromApplyfilter){
			var filtervaluepattern=$j('#filtervaluepattern').val();	
			for(var i = 1; i<filtercount1; i++) {	
					filterby = $j('option:selected', '.sel_field_' + i).val();	
					panel = $j('option:selected', '.sel_field_' + i).attr('rel2');	
					field = $j('option:selected', '.sel_field_' + i).attr('rel');	
					operatorType = $j('.filterOperator_' + i + ' option:selected').text();
					if(operatorType=='is only')operatorType = 'is';
					fieldvaluefilter = "";
					if(filterby.indexOf("ServiceTerms") != -1 || filterby.indexOf("approvedhrs") != -1 || filterby.indexOf("pendingHrs") != -1 || filterby.indexOf("disallowedhrs") != -1//TS-1112
					|| filterby.indexOf("FirstDate") != -1 || filterby.indexOf("RecentDate") != -1 || filterby.indexOf("BlackoutDates") != -1 || filterby.indexOf("TSPersonalStartDate") != -1 || filterby.indexOf("TSPersonalEndDate") != -1 || filterby.indexOf("TSStatus") != -1 || filterby.indexOf("TSTimeOffCalendar") != -1 || filterby.indexOf("submittedHrs") != -1){ //TS-1395/phase-2
						filterby = filterby.split("_")[1];
					}
					if($j('#surveyrateflag').val() == 0 && (field == 'completed' || field == 'missed')) {
						$j('#surveyrateflag').val('1');
						$j('.style10').html('<img src="../../images/icons/animated_loading.gif">&nbsp;&nbsp;&nbsp;<strong>We\'re running a number of formulas right now. Please hold tight.</strong>');
					}
					if(operatorType == 'between' || operatorType == 'not between') {
						$j('.filtervalue_' + i).each(function(){
							fieldvaluefilter += $j(this).val() + ",";								  
						});
						fieldvaluefilter.substring(0, fieldvaluefilter.length-1);				
					} else {
						fieldvaluefilter = 	$j('.filtervalue_' + i).val();
						if(fieldvaluefilter == '') {
							fieldvaluefilter = ' ';
						}
					}
					if(i>1) {
						logical += $j('option:selected', '.sel_action_' + i).text();
					}
					
					if(field == 'associations') {
						associationarr.push(filterby);
					} else {
						fieldarr.push(filterby);
					}
					
					filter += filterby + "~";
					paneltype += panel + "~";
					fieldtype += field + "~";
					operator += operatorType + "~";
					//filtervalue += fieldvaluefilter + "~";
					if(typeof $j('.filtervalue_' + i).attr('data-filter-option') !== "undefined"){
						filtercompoption += $j('.filtervalue_' + i).attr('data-filter-option') + "~";
					}else{
						filtercompoption += '1~'
					}
					
					if($j('.filtervalue_' + i).attr('data-filter-option') == '2'){
						filtervalue += $j('.filtervalue_' + i).attr('data-filter-value') + "~";
					}else{
						filtervalue += fieldvaluefilter + "~";
					}	
					logical += "~";
			}
		}
		
		/* Start: Export Optimization */		
		data.push({		
			"fieldarr": fieldarr.toString()
		});	
		
		data.push({		
			"volunteerfields": fieldarr.toString()
		});
		
		data.push({		
			"selectedFields": fieldarr.toString()
		});	
		
		data.push({		
			"associationarr": associationarr.toString()
		});
		
		data.push({		
			"associationFieldId": associationarr.toString().replace(/_Previous/g, "")
		});
		/* End: Export Optimization */
		
		if(filter != '') {
		   	$j("#filterApplied").val("1");
		}
		
		data.push({			
				"filter": filter			
		});
		data.push({			
				"paneltype": paneltype
		});
		data.push({				
				"fieldtype": fieldtype
		});
		data.push({			
				"operator": operator
		});
		data.push({				
				"filtervalue": filtervalue
		});
		data.push({
			"filtercompoption": filtercompoption
		});
		data.push({				
				"logical": logical
		});	
		data.push({			
				"filterApplied": $j("#filterApplied").val()	
		});
			
		data.push({		  
		  "arrangefieldsby": arrangefieldsby
		 });
		data.push({		  
		  "sortcolumn": sortcolumn
		 });
		data.push({		  
		  "sorttype": sorttype
		 });
		 data.push({		  
		  "programid": programid
		 });
		 data.push({		  
		  "userid": userid
		 });
		 data.push({
			"filtervaluepattern": filtervaluepattern
		 });
		 /* Start - MV-693 */
		 data.push({		  
		  "completedSurveyIdArray": completedSurveyIdArray
		 });
		 data.push({		  
		  "missedSurveyIdArray": missedSurveyIdArray
		 });		 
		 data.push({		  
		  "completedstartperiod": completedstartperiod
		 });
		 data.push({		  
		  "completedendperiod": completedendperiod
		 });
		 data.push({		  
		  "missedstartperiod": missedstartperiod
		 });
		 data.push({
			"missedendperiod": missedendperiod
		 });
		 var surveyrateflag = $j('#surveyrateflag').val();	
		 data.push({
			"surveyrateflag": surveyrateflag
		 });		 
		 /* End - MV-693 */	
		 
		data.push({		
			"selectedFieldType": selectedFieldType.toString()
		});
		 
		data.push({				
				"sessionvolunteerlist": $j('#sessionvolunteerlist').val()
		});
		 data.push({		  
		  "currentusertype": usertype
		 });	
		if ($j11(".timesheetTemplateClass") != undefined) {
			if($j11(".arrangefields:checked").val() == "column") {
				var leftCol = [];
				var rightCol = [];
				var timesheetTemplateIdList = [];
				$j11(".timesheetTemplateClass:checked").each((i, e) => { 
					if(i % 2 == 0){
						leftCol.push(e);
					} else {
						rightCol.push(e);
					}
				});
				timesheetTemplateIdList = leftCol.concat(rightCol);
				data.push({		  
					"templateIdList": timesheetTemplateIdList.map((el,i) => el.value).join(",")
				});
			} else {
				data.push({		  
					"templateIdList": $j11(".timesheetTemplateClass:checked").map((_,el) => el.value).get().join(",")
				});	
			}
		}
		//console.log(data);	 		
		$scope.loadResponse(data,generateExcel, fromSavedReport);			
	}; 
	
	/* Start: Export Optimization */
	$scope.getSelectedFieldData = function(selectionType,fieldId, selectedFieldType) {	
		var data =[];
		var fieldarr = [];		
		var associationarr = [];
		var programid = $j('#programid').val();
		var userid = $j('#userid').val();
		var usertype = $j('#usertype').val();		
		var arrangefieldsby = $j('.arrangefields:checked').val();				
		var completedradio = $j('#completed_dates_period option:selected').val();	
		var missedradio = $j('#missed_dates_period option:selected').val();	
		var assoFieldId = "";
		var fieldSelectionStatus = 0;	
		var fieldarr = [];
		var fieldTypearr = [];
		var panelTypearr = [];		
		var subpanelNamearr = [];
		var timesheetTemplateIdList = [];
		var logicalE = "";//TS-1098
		var logicalOpr = "";//TS-1098
		
		data.push({			
			"rosterOrganization": rosterOrganization
		});
		if(rosterOrganization == 'custom') {
			var customfields = $j('.customfields').val();
			var customfieldvalue = $j('.customfieldvalue').val();			
			var customfieldvaluenames = $j('.customfieldvaluenames').val();			
			data.push({				
				"customfields": customfields
			});
			data.push({			
				"customfieldvalue": customfieldvalue
			});
			//added below code for long list issue
			data.push({			
				"customfieldvaluenames": customfieldvaluenames
			});
		} else if(rosterOrganization == 'volunteer') {
			var volunlist = $j('.volunlist').val();
			data.push({			
				"volunlist": volunlist
			});
		} else if(rosterOrganization == 'association') {
			var associationlist = $j('.associationlist').val();
			data.push({				
				"associationlist": associationlist
			});
		} else if(rosterOrganization == 'site') {
			var sitelist = $j('.sitelist').val();
			data.push({				
				"sitelist": sitelist
			});
		}							
		
		/* Start: Export Optimization */		
		data.push({		
			"selectionType": selectionType
		});
		
		data.push({		
			"selectedFields": fieldId
		});
		
		data.push({		
			"selectedFieldType": selectedFieldType
		});				
		
		$j('input[name="childpanelitem"]:checked').each(function(e,i){
			var field = $j(this).attr('id');			
			var fieldId = $j(this).val();
			fieldarr.push(fieldId);	
			if(selectionType == 'panelFields') {
				fieldTypearr.push($j(this).attr('fieldType'));
				panelTypearr.push($j(this).attr('paneltype'));
				if($j(this).attr('subpanelname') != 'Default') {
					subpanelNamearr.push('User');
				} else {
					subpanelNamearr.push($j(this).attr('subpanelname'));
				}
			}
			//fieldorder.push($j(this).attr('panelid')+'_'+fieldId);
		});
		
		if(selectionType == 'panelFields') {
			fieldarr.push($j('input[fieldtype="userid"]').val());
			fieldTypearr.push('userid');
			panelTypearr.push('Standard');
			subpanelNamearr.push('Default');
		}
		
		if(selectionType == 'timesheetField') {
			fieldarr.push($j('input[fieldtype="userid"]').val());
		}
		
		data.push({		
			"fieldarr": fieldarr.toString()
		});
						
		$j('input[name="childassociationitem"]:checked').each(function(e,i){
			var field = $j(this).attr('id');
			var fieldId = $j(this).val();
			associationarr.push(fieldId);
			if(selectionType == 'panelFields' && $j(this).attr('paneltype') == 'Association') {
				fieldTypearr.push("associations");
				panelTypearr.push("Associations");
				subpanelNamearr.push('Default');
			}
			
			//fieldorder.push($j(this).attr('panelid')+'_'+fieldId);
		});
						
		if((selectedFieldType == 'Type1' || selectedFieldType == 'Type2' || selectedFieldType == 'Type3')) {			
			if(fieldId.indexOf('Associations_') >=0  || fieldId.indexOf('_Previous') >=0 ) {
				assoFieldId = fieldId.split('_')[1]
			} else {
				assoFieldId = fieldId;
			}			
			fieldSelectionStatus = $j('#checkpanelasso_' + assoFieldId).is(':checked');
		} else {
			fieldSelectionStatus = $j('#checkpanel_' + fieldId).is(':checked');
		}				
		
		data.push({		
			"associationFieldId": assoFieldId
		});
		
		data.push({		
			"associationarr": associationarr.toString() //.replace(/_Previous/g, "")
		});						
		
		if ((selectionType == 'panelFields' || selectionType == 'timesheetField') && $j11(".timesheetTemplateClass") != undefined) {			
			if($j11(".arrangefields:checked").val() == "column") {
				var leftCol = [];
				var rightCol = [];				
				$j11(".timesheetTemplateClass:checked").each((i, e) => { 
					if(i % 2 == 0){
						leftCol.push(e);
					} else {
						rightCol.push(e);
					}										
				});
				timesheetTemplateIdList = leftCol.concat(rightCol);
				data.push({		  
					"templateIdList": timesheetTemplateIdList.map((el,i) => el.value).join(",")
				});
			} else {				
				data.push({		  
					"templateIdList": $j11(".timesheetTemplateClass:checked").map((_,el) => el.value).get().join(",")
				});	
			}
			
			$j11(".timesheetTemplateClass:checked").each((i, e) => {				
				fieldTypearr.push("timesheetTemplateDetail");
				panelTypearr.push("Timesheet");
				subpanelNamearr.push('TimesheetDetails');
			});
		}else{//S:TS-1098
			var tempList = "";
			$j11('.timesheetTemplateClass:checked').each(function () {
				tempList += $j11(this).val() + ",";
			});
			data.push({		  
				"templateIdList": tempList
			});	
		}	//E:TS-1098	
				
		if(fieldId == 0) {
			data.push({		
				"fieldTypearr": fieldTypearr.toString()
			});
								
			data.push({		
				"panelTypearr": panelTypearr.toString()
			});
						
			data.push({		
				"subpanelNamearr": subpanelNamearr.toString()
			});
			
		} else if($j11('input[name="' + fieldId + '"]').hasClass('timesheetTemplateElements')) {
			data.push({		
				"fieldTypearr": 'timesheetTemplateDetail'
			});
			
			data.push({		
				"panelTypearr": 'Timesheet'
			});
						
			data.push({		
				"subpanelNamearr": 'timesheetTemplateElements'
			});			
			
		} else {
			data.push({		
				"fieldTypearr": $j('#checkpanel_' + fieldId).attr('fieldtype')
			});
			
			data.push({		
				"panelTypearr": $j('#checkpanel_' + fieldId).attr('paneltype')
			});
			
			if($j('#checkpanel_' + fieldId).attr('subpanelname') != 'Default') {
				data.push({		
					"subpanelNamearr": "User"
				});
			} else {
				data.push({		
					"subpanelNamearr": $j('#checkpanel_' + fieldId).attr('subpanelname')
				});
			}
		}
		
		if(selectionType == 'addFilter' || selectionType == 'sortField' || selectionType == 'filterField' || (fieldId == 0 && selectionType == 'panelFields' && (fieldarr.length || associationarr.length)) || (selectionType == 'timesheetField')) {		   
		   fieldSelectionStatus = true;
		}
		
		data.push({		
			"fieldSelectionStatus": fieldSelectionStatus
		});				
		/* End: Export Optimization */								
								
		var filtercount1 = parseInt($j('.filtercount').val());			
		var filter = "";
		var paneltype = "";
		var subpaneltype = "";
		var fieldtype = "";
		var operator = "";
		var filtervalue = "";
		var logical = " ";
		var filtervaluepattern = "";
		var filtercompoption = "";
		
		/* Start - MV-693 */
		var completedstartperiod = "";
		var completedendperiod = "";
		var missedstartperiod = "";
		var missedendperiod = "";	
		var completedSurveyIdArray = [];
		var missedSurveyIdArray = [];
		if($j("#completed_dates_period option:selected").val() === 'completed' && $j('#updateresultcompleted').val()=='yes') {
			$j('.surveyid_list_completed:checked').each(function(e,i){				
				var surveyId = $j(this).val();
				completedSurveyIdArray.push(surveyId);								
			});	
			if(completedSurveyIdArray.length == 0) {
				completedstartperiod = $j('#beginsurvey_completed option:selected').val();
				completedendperiod = $j('#endsurvey_completed option:selected').val();
			}
		}
		if($j("#missed_dates_period option:selected").val() === 'missed' && $j('#updateresultmissed').val()=='yes') {
			$j('.surveyid_list_missed:checked').each(function(e,i){				
				var surveyId = $j(this).val();
				missedSurveyIdArray.push(surveyId);								
			});	
			if(missedSurveyIdArray.length == 0) {
				missedstartperiod = $j('#beginsurvey_missed option:selected').val();
				missedendperiod = $j('#endsurvey_missed option:selected').val();
			}
		}		
		/* End - MV-693 */		
		filtervaluepattern=$j('#filtervaluepattern').val();		
		if(selectionType == "filterField" || $j('#filterApplied').val() == '1'){			
			for(var i = 1; i<filtercount1; i++) {	
				filterby = $j('option:selected', '.sel_field_' + i).val();	
				panel = $j('option:selected', '.sel_field_' + i).attr('rel2');	
				field = $j('option:selected', '.sel_field_' + i).attr('rel');
				if($j('option:selected', '.sel_field_' + i).attr('subpanel') != 'Default') {
					subpanel = "User";
				} else {
					subpanel = $j('option:selected', '.sel_field_' + i).attr('subpanel');
				}
				operatorType = $j('.filterOperator_' + i + ' option:selected').text();
				if(operatorType=='is only')operatorType = 'is';
				fieldvaluefilter = "";
				if(filterby.indexOf("ServiceTerms") != -1 || filterby.indexOf("approvedhrs") != -1 || filterby.indexOf("pendingHrs") != -1 || filterby.indexOf("disallowedhrs") != -1//TS-1112
				|| filterby.indexOf("FirstDate") != -1 || filterby.indexOf("RecentDate") != -1 || filterby.indexOf("BlackoutDates") != -1 || filterby.indexOf("TSPersonalStartDate") != -1 || filterby.indexOf("TSPersonalEndDate") != -1 || filterby.indexOf("TSStatus") != -1 || filterby.indexOf("TSTimeOffCalendar") != -1 || filterby.indexOf("submittedHrs") != -1){ //TS-1395/phase-2 //TS-1223/TS-1341
					filterby = filterby.split("_")[1];
				}
				if($j('#surveyrateflag').val() == 0 && (field == 'completed' || field == 'missed')) {
					$j('#surveyrateflag').val('1');
					$j('.style10').html('<img src="../../images/icons/animated_loading.gif">&nbsp;&nbsp;&nbsp;<strong>We\'re running a number of formulas right now. Please hold tight.</strong>');
				}
				if(operatorType == 'between' || operatorType == 'not between') {
					$j('.filtervalue_' + i).each(function(){
						fieldvaluefilter += $j(this).val() + ",";								  
					});
					fieldvaluefilter.substring(0, fieldvaluefilter.length-1);				
				} else {
					fieldvaluefilter = 	$j('.filtervalue_' + i).val();
					if(fieldvaluefilter == '') {
						fieldvaluefilter = ' ';
					}
				}
				if(i>1) {
					logical += $j('option:selected', '.sel_action_' + i).text();
				}
				/*Sitemanage-176 : start*/
				if(field == 'cohort_name'){
					fieldvaluefilter= fieldvaluefilter.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;");
				}
        		/*sitemanage-176 : end*/
				filter += filterby + "~";
				paneltype += panel + "~";
				subpaneltype += subpanel + "~";
				fieldtype += field + "~";
				operator += operatorType + "~";
				//filtervalue += fieldvaluefilter.replaceAll("~","&tilde;") + "~";	//MV-1877
				if(typeof $j('.filtervalue_' + i).attr('data-filter-option') !== "undefined"){
					filtercompoption += $j('.filtervalue_' + i).attr('data-filter-option') + "~";
				}else{
					filtercompoption += '1~'
				}
				
				if($j('.filtervalue_' + i).attr('data-filter-option') == '2'){
					filtervalue += $j('.filtervalue_' + i).attr('data-filter-value') + "~";
				}else{
					filtervalue += fieldvaluefilter.replaceAll("~","&tilde;") + "~";
				}
				logical += "~";
			}
			//S:TS-1098
			if(!logical.includes("OR") && !logical.includes("AND")){
				logicalE = $j("#filtervaluepattern").val();
				logicalOpr = logicalE.match(/\b(AND|OR)\b/g);
				logical = logicalOpr ? logicalOpr.join("~") + "~" : "";
			}
			//E:STS-1098
		}
		data.push({			
			"filter": filter			
		});
		data.push({			
			"paneltype": paneltype
		});
		data.push({			
			"subpaneltype": subpaneltype
		});
		data.push({				
			"fieldtype": fieldtype
		});
		data.push({			
			"operator": operator
		});
		data.push({				
			"filtervalue": filtervalue
		});
		data.push({
			"filtercompoption": filtercompoption
		});
		data.push({				
			"logical": logical
		});	
		
		data.push({				
			"filterApplied": $j('#filterApplied').val()
		});
			
		data.push({		  
			"arrangefieldsby": arrangefieldsby
		});
		data.push({		  
			"sortcolumn": sortcolumn
		});
		data.push({		  
			"sorttype": sorttype
		});
		data.push({		  
			"programid": programid
		});
		data.push({		  
			"userid": userid
		});
		 data.push({
			"filtervaluepattern": filtervaluepattern
		 });
		 /* Start - MV-693 */
		 data.push({		  
		 	"completedSurveyIdArray": completedSurveyIdArray.toString()
		 });
		 data.push({		  
		 	"missedSurveyIdArray": missedSurveyIdArray.toString()
		 });		 
		 data.push({		  
		 	"completedstartperiod": completedstartperiod
		 });
		 data.push({		  
		 	"completedendperiod": completedendperiod
		 });
		 data.push({		  
		 	"missedstartperiod": missedstartperiod
		 });
		 data.push({
			"missedendperiod": missedendperiod
		 });
		 var surveyrateflag = $j('#surveyrateflag').val();	
		 data.push({
			"surveyrateflag": surveyrateflag
		 });	
		 var surveyCompletedUpdated = 0;
		 if(selectedFieldType == 'completed') {
			 surveyCompletedUpdated = 1;
		 }
		data.push({				
			"surveyCompletedUpdated": surveyCompletedUpdated
		});
		 var surveyMissedUpdated = 0;
		 if(selectedFieldType == 'missed') {
			 surveyMissedUpdated = 1;
		 }
		data.push({				
			"surveyMissedUpdated": surveyMissedUpdated
		});
		 /* End - MV-693 */	
		data.push({				
			"sessionvolunteerlist": $j('#sessionvolunteerlist').val()
		});
		data.push({		  
		  "currentusertype": usertype
		});	
							
		if(fieldSelectionStatus) {
			//console.log('Before Reset: ' + $scope.fieldorder);
			//$scope.resetfieldorder();
			//console.log('Before loadSelectedFieldResponse: ' + $scope.fieldorder);
			$scope.loadSelectedFieldResponse(data);
		}
	};	
	/* MV-2073:Start */
	function showLoadingOverlay1() {
		$j('#ajaxFilterLoading').css('display','block');
		$j('#ajaxFilterLoading').css('opacity','1');
		$j('#ajaxFilterLoading .bg').height('100%');
		$j('#ajaxFilterLoading').fadeIn(300);
		$j("#ajaxFilterLoading").attr("tabindex",-1).focus();
	}		
	
	function hideLoadingOverlay1() {
		$j('#ajaxFilterLoading').css('display','none');
		$j('#ajaxFilterLoading .bg').height('100%');
		$j('#ajaxFilterLoading').fadeOut(300);
		$j('#ajaxFilterLoading').css('opacity','0.3');
	}
	/* MV-2073:Stops */
	$scope.loadSelectedFieldResponse = function(data){
		var programid = $j('#programid').val();
		var userid = $j('#userid').val();
		var keyid = $j('#keyid').val();		
		var surveyrateflag = $j('#surveyrateflag').val(); 								
		var formData = {};
		data.forEach(obj => {
		   Object.entries(obj).forEach(([key, value]) => {
			  formData[key] = value;
		   });
		});
		
		if (surveyrateflag == 1 && (formData.selectedFieldType == 'completed' || formData.selectedFieldType == 'missed')) {
			$j('.style10').html('<img src="../../images/icons/animated_loading.gif">&nbsp;&nbsp;&nbsp;<strong>We\'re running a number of formulas right now. Please hold tight.</strong>');	
		}
		
		formData.id = userid;
		formData.key = keyid;
		
		showLoadingOverlay1();// MV-2073 
		if(formData['selectionType'] != 'addFilter'){
			setTimeout(function() {// MV-2073 
				$j.ajax({
					type: "POST",		
					url: "index.cfm?event=user.getExportFieldValue",
					data: formData,
					dataType: "json",
					async: false,
					beforeSend: function() {			
						if(formData['selectionType'] != 'addFilter') {				
							showWaitScreen();					
						} else {
							showLoadingOverlay();
						} 
					},
					success: function(data) {	
			// SM-273 : Start
						// Parse JSON only if it's a string
						let rows = typeof data.data === "string" ? JSON.parse(data.data) : data.data;
						let originalRows = typeof data.originalResult.data === "string" ? JSON.parse(data.originalResult.data) : data.originalResult.data;

						// Check if rows and originalRows are arrays
						if (!Array.isArray(rows) || !Array.isArray(originalRows)) {
							console.error("Invalid data format: Expected arrays for 'data' and 'originalResult.data'.");
							return; // Exit early if data is invalid
						}

						// Function to update "siteediting" in-place
						const updateSiteEditingInPlace = (arr) => {
							for (let i = 0; i < arr.length; i++) {
								arr[i].siteediting = arr[i].siteediting ? "Yes" : "No";
							}
						};

						// Update both datasets in place
						updateSiteEditingInPlace(rows);
						updateSiteEditingInPlace(originalRows);

						// Reassign updated values only if the original data was a string
						if (typeof data.data === "string") {
							data.data = JSON.stringify(rows);
						}
						if (typeof data.originalResult.data === "string") {
							data.originalResult.data = JSON.stringify(originalRows);
						}
			// SM-273 : Stop	
						if ($j11(".timesheetTemplateClass:checked").length > 0) {
							$j11(".timesheetTemplateClass:checked").each((i, e) => {
								var templateId = $j11(e).val();
								$j11(".timesheetTemplateDetails_"+templateId).show();
							});
						}
						
						$j11(".timesheetTemplateClass:not(:checked)").each((i, e) => {
							var templateId = $j11(e).val();
							$j11(".timesheetTemplateDetails_"+templateId).hide();					
						});
							
							
						/*if($scope.JCounter == 0){
							$scope.resultJSON = data.originalResult;
							$scope.JCounter++;
						}
						else
						{	
							for(i=0;i<data.data.length;i++){
								if(data.data[i]["userid"] == updated_user_id)
								{
									$scope.resultJSON.data[i]=data.data[i];
								}
							}
							updated_user_id ="";
						}*/
						
						//$scope.resultJSON = data;		
						if(!fromSavedReport){
							$scope.resetfieldorder();	
						}
						$scope.resultJSON = data.originalResult;
						if($scope.arrangefields=='row'){					
							header=data.headers;					
							var arr=[];			
							var arr4=[];
							var arr1=[];
							var arr2=[];
							var arr3=[];	
							var arr5=[];					
							var sortedarr=[];					
							$j(".dataGroupHeader").each(function(){
								var panel_id = $j(this).find('a').attr("rel").toString().replace("userAssign","");
								var panel_name = $j(this).find('span').text().trim()
								sortedarr.push( panel_id + ":" + panel_name );
							});								
							var assopnlid='';
							for(m=0;m<header.length;m++){				
								if(header[m].paneltype=='Associations')//Minor Fix Along With ASSNS-656	
									assopnlid=header[m].panelid;
								if(header[m].subpanelname=='Associations1')
									arr1.push(header[m]);
								else if(header[m].subpanelname=='Associations2')
									arr2.push(header[m]);
								else if(header[m].subpanelname=='Associations3')
									arr3.push(header[m]);
								else if(header[m].subpanelname === 'Timesheet Details')//<!---TS-1221--->
									arr5.push(header[m]);	
								else
									arr4.push(header[m]);							
							}
							//sortedarr.forEach(forder=>{ 							
							sortedarr.forEach(function(forder){ 
								if(forder.split(':')[0]==assopnlid){										
									for(i=0;i<arr1.length;i++){									
										arr.push(arr1[i]);
									}									
									for(j=0;j<arr2.length;j++){									
										arr.push(arr2[j]);
									}									
									for(k=0;k<arr3.length;k++){									
										arr.push(arr3[k]);
									}						
								}else{
									for(l=0;l<arr4.length;l++){									
										if(forder.split(':')[0]==arr4[l].panelid){										
											arr.push(arr4[l]);
										}
									}
			
									if (forder.split(':')[1]=="Timesheet Settings") {//<!---TS-1221--->
										for(l=0;l<arr5.length;l++){																		
											arr.push(arr5[l]);
										}
									}	
								}								
							});	
													
							colCount=arr;
						}else{
							colCount=data.headers;
						}	
						if(data.getUserListWithPairid != undefined){
							getUserListWithPairidList = data.getUserListWithPairid;//TS-1098
						}else{
							getUserListWithPairidList = [];
						}
						rowCount=data.data;	
						iconEnable=data.iconEn; //MV-862
						userlistid=data.USERLISTID;				
						resultUserIdList=data.RESULTUSERLISTID;	
						$j11('#resultUserIdList').val(resultUserIdList);
						resultUserStatus=data.RESULTUSERSTATUS;	
						$j11('#resultUserStatus').val(resultUserStatus);					
						$scope.displayFieldsBasedonCheckbox(view_display_list,fromSavedReport);//MV-819							
						//$scope.displayFieldsBasedonCheckbox(view_display_list, fromSavedReport);//MV-819	*/					
					},		
					complete: function() {	
						//$scope.displayFieldsBasedonCheckbox();//MV-819				
						hideLoadingOverlay1();	// MV-2073 
						hideWaitScreen();					
						$j('.style10').html('<img src="../../images/icons/animated_loading.gif">&nbsp;&nbsp;&nbsp;<strong>Please wait while we build your custom export.</strong>');//BG-64				
					},
					error: function(data) {
						status = false;
					}
				});	
			}, 250);// MV-2073 
		}else{
			$j.ajax({
				type: "POST",		
				url: "index.cfm?event=user.getExportFieldValue",
				data: formData,
				dataType: "json",
				async: false,
				beforeSend: function() {			
					if(formData['selectionType'] != 'addFilter') {				
						showWaitScreen();					
					} else {
						showLoadingOverlay();
					} 
				},
				success: function(data) {	
		// SM-273 : Start
					// Parse JSON only if it's a string
					let rows = typeof data.data === "string" ? JSON.parse(data.data) : data.data;
					let originalRows = typeof data.originalResult.data === "string" ? JSON.parse(data.originalResult.data) : data.originalResult.data;

					// Check if rows and originalRows are arrays
					if (!Array.isArray(rows) || !Array.isArray(originalRows)) {
						console.error("Invalid data format: Expected arrays for 'data' and 'originalResult.data'.");
						return; // Exit early if data is invalid
					}

					// Function to update "siteediting" in-place
					const updateSiteEditingInPlace = (arr) => {
						for (let i = 0; i < arr.length; i++) {
							arr[i].siteediting = arr[i].siteediting ? "Yes" : "No";
						}
					};

					// Update both datasets in place
					updateSiteEditingInPlace(rows);
					updateSiteEditingInPlace(originalRows);

					// Reassign updated values only if the original data was a string
					if (typeof data.data === "string") {
						data.data = JSON.stringify(rows);
					}
					if (typeof data.originalResult.data === "string") {
						data.originalResult.data = JSON.stringify(originalRows);
					}
		// SM-273 : Stop	
					if ($j11(".timesheetTemplateClass:checked").length > 0) {
						$j11(".timesheetTemplateClass:checked").each((i, e) => {
							var templateId = $j11(e).val();
							$j11(".timesheetTemplateDetails_"+templateId).show();
						});
					}
					
					$j11(".timesheetTemplateClass:not(:checked)").each((i, e) => {
						var templateId = $j11(e).val();
						$j11(".timesheetTemplateDetails_"+templateId).hide();					
					});
						
						
					/*if($scope.JCounter == 0){
						$scope.resultJSON = data.originalResult;
						$scope.JCounter++;
					}
					else
					{	
						for(i=0;i<data.data.length;i++){
							if(data.data[i]["userid"] == updated_user_id)
							{
								$scope.resultJSON.data[i]=data.data[i];
							}
						}
						updated_user_id ="";
					}*/
					
					//$scope.resultJSON = data;		
					if(!fromSavedReport){
						$scope.resetfieldorder();	
					}
					$scope.resultJSON = data.originalResult;
					if($scope.arrangefields=='row'){					
						header=data.headers;					
						var arr=[];			
						var arr4=[];
						var arr1=[];
						var arr2=[];
						var arr3=[];	
						var arr5=[];					
						var sortedarr=[];					
						$j(".dataGroupHeader").each(function(){
							var panel_id = $j(this).find('a').attr("rel").toString().replace("userAssign","");
							var panel_name = $j(this).find('span').text().trim()
							sortedarr.push( panel_id + ":" + panel_name );
						});								
						var assopnlid='';
						for(m=0;m<header.length;m++){				
							if(header[m].paneltype=='Associations')//Minor Fix Along With ASSNS-656	
								assopnlid=header[m].panelid;
							if(header[m].subpanelname=='Associations1')
								arr1.push(header[m]);
							else if(header[m].subpanelname=='Associations2')
								arr2.push(header[m]);
							else if(header[m].subpanelname=='Associations3')
								arr3.push(header[m]);
							else if(header[m].subpanelname === 'Timesheet Details')//<!---TS-1221--->
								arr5.push(header[m]);	
							else
								arr4.push(header[m]);							
						}
						//sortedarr.forEach(forder=>{ 							
						sortedarr.forEach(function(forder){ 
							if(forder.split(':')[0]==assopnlid){										
								for(i=0;i<arr1.length;i++){									
									arr.push(arr1[i]);
								}									
								for(j=0;j<arr2.length;j++){									
									arr.push(arr2[j]);
								}									
								for(k=0;k<arr3.length;k++){									
									arr.push(arr3[k]);
								}						
							}else{
								for(l=0;l<arr4.length;l++){									
									if(forder.split(':')[0]==arr4[l].panelid){										
										arr.push(arr4[l]);
									}
								}
		
								if (forder.split(':')[1]=="Timesheet Settings") {//<!---TS-1221--->
									for(l=0;l<arr5.length;l++){																		
										arr.push(arr5[l]);
									}
								}	
							}								
						});	
												
						colCount=arr;
					}else{
						colCount=data.headers;
					}	
					if(data.getUserListWithPairid != undefined){
						getUserListWithPairidList = data.getUserListWithPairid;//TS-1098
					}else{
						getUserListWithPairidList = [];
					}
					rowCount=data.data;	
					iconEnable=data.iconEn; //MV-862
					userlistid=data.USERLISTID;				
					resultUserIdList=data.RESULTUSERLISTID;	
					$j11('#resultUserIdList').val(resultUserIdList);
					resultUserStatus=data.RESULTUSERSTATUS;	
					$j11('#resultUserStatus').val(resultUserStatus);					
					$scope.displayFieldsBasedonCheckbox(view_display_list,fromSavedReport);//MV-819							
					//$scope.displayFieldsBasedonCheckbox(view_display_list, fromSavedReport);//MV-819	*/					
				},		
				complete: function() {	
					//$scope.displayFieldsBasedonCheckbox();//MV-819				
					hideLoadingOverlay1();	// MV-2073 
					hideWaitScreen();					
					$j('.style10').html('<img src="../../images/icons/animated_loading.gif">&nbsp;&nbsp;&nbsp;<strong>Please wait while we build your custom export.</strong>');//BG-64				
				},
				error: function(data) {
					status = false;
				}
			});
		}		
	};
	
	/* End: Export Optimization */

	function saveOrder() {
		var state = $scope.gridApi.saveState.save();	
		var fieldorder1=[];
		$scope.fieldorder=[];
		$scope.excelfieldorder=[];
		var count=0;
		var currcount=0;
		var hiscount=0;
		var currpnlid_fid=0;
		var hispnlid_fid=0;	
		/* Start: BG-113 */	
		var freezedColumnId = 0;
		var freezedColumnPanelId = 0;
		/* End: BG-113 */			
		for(var j=0;j<$scope.gridOptions.columnDefs.length;j++){
			/* Start: BG-113 */	
			if ($scope.gridOptions.columnDefs[j].fieldtype == 'fname') {
				freezedColumnPanelId = $scope.gridOptions.columnDefs[j].name.split(':')[1];
				freezedColumnId = $scope.gridOptions.columnDefs[j].name.split(':')[2];
			}
			/* End: BG-113 */
			if($scope.gridOptions.columnDefs[j].fieldtype=='completionrate'){
				currcount=currcount+1;
				currpnlid_fid=$scope.gridOptions.columnDefs[j].name.split(':')[2]+'_'+$scope.gridOptions.columnDefs[j].name.split(':')[3];
			}else if($scope.gridOptions.columnDefs[j].fieldtype=='historicalrates'){
				hiscount=hiscount+1;
				hispnlid_fid=$scope.gridOptions.columnDefs[j].name.split(':')[2]+'_'+$scope.gridOptions.columnDefs[j].name.split(':')[3];
			}			
		}
		/* Start: BG-113 */	
		fieldorder1.push(freezedColumnPanelId + '_' + freezedColumnId);
		$scope.excelfieldorder.push(freezedColumnPanelId + '_' + freezedColumnId); // Added for MV-1385
		//commented for CF18-30
		//$scope.excelfieldorder.push(freezedColumnPanelId + '_' + freezedColumnId);
		/* End: BG-113 */		
		for(var i=0;i<state.columns.length;i++){			
			if(state.columns[i].name.split(':').length==4 && (state.columns[i].name.split(':')[2].indexOf('serviceterms_') == -1 && state.columns[i].name.split(':')[2].indexOf('blackoutdates_')==-1 
			&& state.columns[i].name.split(':')[2].indexOf('approvedhrs_')== -1 && state.columns[i].name.split(':')[2].indexOf('pendingHrs_')== -1 && state.columns[i].name.split(':')[2].indexOf('disallowedHrs_')== -1//TS-1112
			&&  state.columns[i].name.split(':')[2].indexOf('firstdate_')== -1 && state.columns[i].name.split(':')[2].indexOf('recentdate_')==-1 && state.columns[i].name.split(':')[2].indexOf('TSPersonalStartDate_')==-1 && state.columns[i].name.split(':')[2].indexOf('TSPersonalEndDate_')==-1 && state.columns[i].name.split(':')[2].indexOf('tsstatus_')==-1 && state.columns[i].name.split(':')[2].indexOf('tstimeoffcalendar_')==-1 && state.columns[i].name.split(':')[2].indexOf('submittedhrs_')==-1)){	 //TS-1223/TS-1341	//TS-1395/phase-2		
				var panelid=state.columns[i].name.split(':')[2];
				 var Id1=state.columns[i].name.split(':')[3];		 
				 fieldorder1.push(panelid+'_'+Id1);				
				if(currpnlid_fid==panelid+'_'+Id1){
					count=count+1;					
					$scope.excelfieldorder.push(panelid+'_'+Id1+'_'+count);	
					//$scope.fieldorder.push(panelid+'_'+Id1);//Commented MVBG Fix
				}
				else if(hispnlid_fid==panelid+'_'+Id1){
					currcount=currcount+1;					
					$scope.excelfieldorder.push(panelid+'_'+Id1+'_'+currcount);	
					//$scope.fieldorder.push(panelid+'_'+Id1);//Commented MVBG Fix
				}else{				
					$scope.excelfieldorder.push(panelid+'_'+Id1);	
					//$scope.fieldorder.push(panelid+'_'+Id1);//Commented MVBG Fix
				}	
				
			}else{
			
				var pnlidlen=state.columns[i].name.split(':').length-2;
				var fidlen=state.columns[i].name.split(':').length-1;			
				var panelid=state.columns[i].name.split(':')[parseInt(pnlidlen)];
				var Id1=state.columns[i].name.split(':')[parseInt(fidlen)];			 
				
				//BG-81 : Start
				var fldType = ''; // Added fldType for MV-1588
				if(Id1.indexOf('Association_')==0){
						fldType = 'association'; // Added fldType for MV-1588
						Id1=Id1.split('_');
						if(Id1.length == 2){//Current Association
							Id1=Id1[1];
						}
						else{//Previous Association
							Id1=Id1[1]+"_"+Id1[2];
						}
				}  
				// TS-633 : START
				// TS-633 STEP-10
				// TS-633 : NOTE: This is because panelid already have Name_ID pattern
				if (panelid.indexOf('serviceterms_')==0 || panelid.indexOf('blackoutdates_')==0 || panelid.indexOf('approvedhrs_')==0 || panelid.indexOf('pendinghrs_')==0 || panelid.indexOf('disallowedhrs_')==0 ||  panelid.indexOf('firstdate_')==0 || panelid.indexOf('recentdate_')==0 ||  panelid.indexOf('tspersonalstartdate_')==0 || panelid.indexOf('tspersonalenddate_')==0 || panelid.indexOf('tsstatus_')==0 || panelid.indexOf('tstimeoffcalendar_')==0 || panelid.indexOf('submittedhrs_')==0) { //TS-1223/TS-1341 //TS-1395/phase-2
					fieldorder1.push(panelid);
					$scope.excelfieldorder.push(panelid);	
					
				} // TS-633 : END 
				else {
					//BG-81 : Stops
					//commented if condition for CF18-30 -> Uncommented Below Condition for MV-1385
					if(freezedColumnId != Id1 || fldType == 'association') { // BG-113 // Added fldType for MV-1588
						 fieldorder1.push(panelid+'_'+Id1);
						 //$scope.fieldorder.push(panelid+'_'+Id1);//Commented MVBG Fix	
						 $scope.excelfieldorder.push(panelid+'_'+Id1);	
					}
				}
			}
		}				
		$j("#fieldsortorder").val(fieldorder1);	
		$j("#setFieldOrder").val('1');		
	}	
	
	$scope.displayField=function(generateExcel) {	
		showLoadingOverlay();
		$j("#fieldsortorderFlag").val('1');
		var rep_Id= $j(".report_radio:checked").val();					
		var filtercount = parseInt($j('.filtercount').val());		
		for(i=2;i<=filtercount;i++) {
			$j('#subfilter_' + i).remove();
		}
		$j('.filtercount').val('1');
		$j('#filtervaluepattern').val('');
		$j('#patternforrestore').val('');
		$j('#editpatternflage').val('0');
		$j('.filterpattern').css('display','none');		
		$j('#clearfilter').css('display','none');
		$j('#btn_apply_filter').prop("disabled", true)	
		$j('.filtercount_1').addClass('padding-left-10');
		$j('.filtercount_1').html('');	
		$j('.filtercount_1').css('display','none');
		$j('.sel_action_1').remove('');
		$j('.sel_field_1').addClass('tmsht-widt-215');
		$j('.sel_field_1').removeClass('tmsht-widt-134');
		$j('.filtervalue_1').addClass('tmsht-widt-161');
		$j('.filtervalue_1').removeClass('tmsht-widt-134');
		$j('.filtervalue_1').val('');
		$j('.ffilterby').removeClass('text-right');
		$j('.fOperator').removeClass('text-right');
		$j('.fValue').removeClass('text-right');									
		$j('.filterbylable').removeClass('margin-right-63');
		$j('.operatorlabel').removeClass('margin-right-63');
		$j('.valuelabel').removeClass('margin-right-102');	
		$j('.btn_add_filter_1').html('Add');
		$j('.btn_cancel_filter_1').html('Cancel');		
		$j('.sel_field_1 option[value="0"]').attr('selected', true);
		
		$j1('.sel_field_1').select2('destroy');	
		$j('.filterOperator_1').html('');		
		$j('.sel_field_1 option[value="0"]').attr('selected', true);
		$j('.sel_field_1').trigger("change");				
		$j1('.sel_field_1').select2();
		$j('#filterApplied').val('0'); // Volunteer Export Optimization
		
		
		
		$j("#filterbox").hide();

		//Added for BG-64
		$j(".Associations_Panel").addClass('showIt').removeClass('hideIt');
		$j11(".subcheckboxspan").hide();
		//$j11(".checkbox_parent").attr("checked",false);
		
		if(rep_Id.length)
		{
			var editpatternflage=0;
		 	$j.ajax({
			type:"post",
			url:"index.cfm?event=user.displayfields",
			data:{rep_Id:rep_Id,tempListByUser:tempListByUser},//TS-1098
			datatype:"json",
			async: false,
			success: function(Report) { 
				$scope.fieldorder = [];
				var filterCnt=0;
				var fieldorder=[];				
				var filtervaluepattern='';
				fromSavedReport = 1;
				$j('input:checkbox:checked').each(function () {	
			        $j("#"+this.id).attr("checked", false);
				   $j("#"+this.id).closest('.columngroup').removeClass("check_bgcolor");
				   $j("#"+this.id).closest('.association_fields').removeClass("check_bgcolor");
		  		});

				  let parsedReport = typeof Report === "string" ? JSON.parse(Report) : Report;

					if (Array.isArray(parsedReport)) {
						for (let i = 0; i < parsedReport.length; i++) {
							if (
								parsedReport[i].FieldType === "siteEditing" &&
								typeof parsedReport[i].FilterValue === "boolean"
							) {
								Report[i].FilterValue = parsedReport[i].FilterValue ? "Yes" : "No";
							}
						}
					}
				  setTimeout(function() { 
					$j('.attrItemdata ').each(function () {
					var $link = $j(this);
					var $section = $link.find('.arraneglikeTable');
					var $checkboxes = $section.find("input[type='checkbox']");
					var $checked = $checkboxes.filter(":checked"); 
					var $button = $link.find("#userAssignPanelSelect");
					
					if ($checkboxes.length && $checked.length === $checkboxes.length) {
						$button.text("Select None");

					} else {
						$button.text("Select All");
					}
				});	
			},
			250);	
				/* Start: MV-693 */
				$j11('#surveyrateflag').val('0');
				$j11('#completed_dates_period').val('0').change();
				$j11('#updateresultcompleted').val('no');
				$j11('#completed_dates_period').prop("disabled","disabled");
				$j11('#completeddatedropdown').css('display','none');
				$j11('#close_section3_filter_completed').css('display','none');		
				$j11('#div_section3_filter_completed').css('display','none');
				$j11('#belowupdatefilter_result_completed').css('display','none');
				$j11('#linkTosection3_filter_completed').removeClass('collapseSection_filter').addClass('expandSection_filter');
				
				$j11('#missed_dates_period').val('0').change();
				$j11('#updateresultmissed').val('no');
				$j11('#missed_dates_period').prop("disabled","disabled");	
				$j11('#misseddatedropdown').css('display','none');
				$j11('#close_section3_filter_missed').css('display','none');		
				$j11('#div_section3_filter_missed').css('display','none');
				$j11('#belowupdatefilter_result_missed').css('display','none');
				$j11('#linkTosection3_filter_missed').removeClass('collapseSection_filter').addClass('expandSection_filter');
				/* End: MV-693 */		
				
				//Commented for BG-64

				/* MS-278 :: START*/
				$j('.attrItemdata').css('display','none'); 
				$j('.showHide').removeClass('hideIt').addClass('showIt');
				$j.each($j.parseJSON(Report), function(key,value) // loop to check fileds
				{	
					if (value.FieldType === "siteEditing" && typeof value.FilterValue === "boolean") {
						value.FilterValue = value.FilterValue ? "Yes" : "No";
					}
					var panelids = value.PanelId;
					var showHide=$j('#UserPanel_'+panelids).siblings();
					showHide.removeClass('showIt').addClass('hideIt');
					$j('#userAssign'+panelids).css('display','block');
				});
				/* MS-278 :: END*/

				var array_value = []; /* Added For MV-819 */
				var array_value_counter = 0; /* Added For MV-819 */
				$j.each($j.parseJSON(Report), function(key,value) // loop to check fileds
				{ 
					if (value.FieldType === "siteEditing" && typeof value.FilterValue === "boolean") {
						value.FilterValue = value.FilterValue ? "Yes" : "No";
					}
					if(typeof value.EditPatternFlage != 'undefined'){
						editpatternflage=value.EditPatternFlage;
						filtervaluepattern=value.FilterValuePattern;
					}
					if(typeof value.ArrangeFieldsBy != 'undefined' && (value.ArrangeFieldsBy).length)	
					{
						//$j('input[value="'+value.ArrangeFieldsBy+'"]').prop("checked",true);
						$j('input[name="arrangefields"][value="' + value.ArrangeFieldsBy + '"]').prop('checked', true); //MV-1823
						$j("#currentArrangeField").val(value.ArrangeFieldsBy); //MV-1823
					}
					else
					{
						$j('input[value="row"]').prop("checked",true);
						$j("#currentArrangeField").val("row"); //MV-1823
					}
					if($j("#checkpanel_"+value.FieldId).hasClass('completionratecheckbox') || $j("#checkpanel_"+value.FieldId).hasClass('missedratecheckbox')) {
						$j('#surveyrateflag').val('1');
					}
					// TS-633 : START
					if(value.selectedTemplateElements != undefined && value.selectedTemplateElements.length) {
						$j("#userAssign"+value.PanelId).show();
						//var selectedTemplateElementsArr = value.selectedTemplateElements.split(',');
						$j('#timesheetTemplate_' + value.selectedTemplateElements.split('_')[1]).prop("checked", true);
						$j('#timesheetTemplate_' + value.selectedTemplateElements.split('_')[1]).closest('.columngroup').addClass("check_bgcolor");
						$j('#'+value.selectedTemplateElements).prop("checked", true);
						fieldorder.push("TimeSheetSetting_" + value.selectedTemplateElements);
						$scope.fieldorder.push("TimeSheetSetting_" + value.selectedTemplateElements);
						//selectedTemplateElementsArr.each((v, i) => {
						//	$j('#'+v).prop("checked", true);
						//});

						if ($j('.timesheetTemplateClass').length == $j('.timesheetTemplateClass:checked').length 
							&& $j('.timesheetTemplateElements').length == $j('.timesheetTemplateElements:checked').length) {

							$j('.timeSheetDetailsSelectAll').html('Select None');
						}
					}
					// TS-633 : END
					/* Start: MV-693 */
					else if(value.completedflage == 1) {
						fieldorder.push(value.PanelId+'_'+value.FieldId);
						$scope.fieldorder.push(value.PanelId+'_'+value.FieldId);
						var section="";
						$j("#checkpanel_"+value.FieldId).attr("checked", true);
						$j("#checkpanel_"+value.FieldId).closest('.columngroup').addClass("check_bgcolor");
						$j11('#completed_dates_period').attr("disabled",false);
						if(value.surveyidcompleted == '' && value.startperiodcompleted == '' && value.endperiodcompleted == '') {
							$j('#completed_dates_period').val('no').change();
						} else {
							$j('#completed_dates_period').val('completed').change();						
							$j11('#completeddatedropdown').css('display','block');												
							if(value.surveyidcompleted =='') {
								$j("#beginsurvey_completed [value="+'"'+value.startperiodcompleted+'"'+"]")
								.attr('selected', 'true');
								$j("#endsurvey_completed [value="+'"'+value.endperiodcompleted+'"'+"]")
								.attr('selected', 'true');												
								$j('#updatefilter_result_completed').html('<a class="updatefiltercompleted linkToSection_filter" rel="updatefilter_filter" Style="color:grey;" disabled>Updated</a><span class="updateor" Style="margin-left:5px;color:grey;">or</span>');
								$j('#belowupdatefilter_result_completed').html('<a class="updatefiltercompleted linkToSection_filter" rel="updatefilter_filter" Style="color:grey;" disabled>Updated</a>');
							} else {
								$j("#beginsurvey_completed [value="+'"'+value.startperiodcompleted+'"'+"]").attr('selected', 'true');
								$j("#endsurvey_completed [value="+'"'+value.endperiodcompleted+'"'+"]").attr('selected', 'true');													
								section = $j11.trim($j11('#linkTosection3_filter_completed').attr('rel')); 
								if(!$j11('#linkTosection3_filter_'+section).hasClass('sliding')){		
									$j11('#imgLoading_section3_filter_'+section).show(); 
									$j11('#updatefilter_result_'+section).show(); 		
									$j11('#linkTosection3_filter_completed').addClass('sliding'); 
									Effect.SlideDown('div_section3_filter_' + section,{ afterFinish: function () { 		 
										$j11('#linkTosection3_filter_completed').removeClass('sliding')
										.removeClass('expandSection_filter').addClass('collapseSection_filter');
										$j11('#imgLoading_section3_filter_' + section).hide(); 		
										$j11('#close_section3_filter_'+section).show();
										//document.getElementById("is_surveytable_open").value ="1" ;			 
										}
									});
								}	
								var datebegin_survey =value.startperiodcompleted;
								var dateend_survey =value.endperiodcompleted;
								
								var programID =$j11("#programid").val();	 
								var retval=loadSurveyTable(datebegin_survey,dateend_survey,programID,'','',0,0,section); //MV-1900			
								if(retval){
									$j11('#belowupdatefilter_result_'+section).show();
								}
								var array = value.surveyidcompleted.toString().split(",");
								$j11.each(array,function(i){	
									var id="completed_"+array[i];
								   $j11("#"+id).attr('checked', 'true');
								});
								callCheckBox(section);
								$j11(document).find('#updatefilter_result_completed').html('<a class="updatefiltercompleted linkToSection_filter" rel="updatefilter_filter" Style="color:grey;" disabled>Updated</a><span class="updateor" Style="margin-left:5px;color:grey;">or</span>');
								$j11(document).find('#belowupdatefilter_result_completed').html('<a class="updatefiltercompleted linkToSection_filter" rel="updatefilter_filter" Style="color:grey;" disabled>Updated</a>');													
							}//end inner if	
						}
						$j11('#surveyrateflag').val('1');
						$j11('#updateresultcompleted').val('yes');	
					}//end main if 
					else if(value.missedflage == 1)
					{
						fieldorder.push(value.PanelId+'_'+value.FieldId);
						$scope.fieldorder.push(value.PanelId+'_'+value.FieldId);
						var section="";
						$j("#checkpanel_"+value.FieldId).attr("checked", true);
						$j("#checkpanel_"+value.FieldId).closest('.columngroup').addClass("check_bgcolor");
						$j11('#missed_dates_period').attr("disabled",false);
						if(value.surveyidmissed == '' && value.startperiodmissed == '' && value.endperiodmissed == '') {
							$j('#missed_dates_period').val('no').change();
						} else {							
							$j('#missed_dates_period').val('missed').change();
							$j11('#misseddatedropdown').css('display','block');
													
							if(value.surveyidmissed =='')
							{
								$j("#beginsurvey_missed [value="+'"'+value.startperiodmissed+'"'+"]").attr('selected', 'true');
								$j("#endsurvey_missed [value="+'"'+value.endperiodmissed+'"'+"]").attr('selected', 'true');									
								$j('#updatefilter_result_missed').html('<a class="updatefiltermissed linkToSection_filter" rel="updatefilter_filter" Style="color:grey;" disabled>Updated</a><span class="updateor" Style="margin-left:5px;color:grey;">or</span>');
								$j('#belowupdatefilter_result_missed').html('<a class="updatefiltermissed linkToSection_filter" rel="updatefilter_filter" Style="color:grey;" disabled>Updated</a>');							
							} else {
								$j("#beginsurvey_missed [value="+'"'+value.startperiodmissed+'"'+"]").attr('selected', 'true');
								$j("#endsurvey_missed [value="+'"'+value.endperiodmissed+'"'+"]").attr('selected', 'true');									
								section = $j11.trim($j11('#linkTosection3_filter_missed').attr('rel')); 
								if(!$j11('#linkTosection3_filter_'+section).hasClass('sliding')){		
									$j11('#imgLoading_section3_filter_'+section).show(); 
									$j11('#updatefilter_result_'+section).show(); 		
									$j11('#linkTosection3_filter_missed').addClass('sliding'); 
									Effect.SlideDown('div_section3_filter_' + section,{ afterFinish: function () { 		 
										$j11('#linkTosection3_filter_missed').removeClass('sliding')
										.removeClass('expandSection_filter').addClass('collapseSection_filter');
										$j11('#imgLoading_section3_filter_' + section).hide(); 		
										$j11('#close_section3_filter_'+section).show();												 
										}
									});
								}
								var datebegin_survey =value.startperiodmissed;
								var dateend_survey =value.endperiodmissed;
								var programID =$j11("#programid").val();	 
								var retval=loadSurveyTable(datebegin_survey,dateend_survey,programID,'','',0,0,section);	//MV-1900	
								if(retval)
									$j11('#belowupdatefilter_result_'+section).show();
								var array = value.surveyidmissed.toString().split(",");
								$j11.each(array,function(i){						  
								  var id="missed_"+array[i];
								   $j11("#"+id).attr('checked', 'true');
								});
								callCheckBox(section);
								$j('#updatefilter_result_missed').html('<a class="updatefiltermissed linkToSection_filter" rel="updatefilter_filter" Style="color:grey;" disabled>Updated</a><span class="updateor" Style="margin-left:5px;color:grey;">or</span>');
								$j('#belowupdatefilter_result_missed').html('<a class="updatefiltermissed linkToSection_filter" rel="updatefilter_filter" Style="color:grey;" disabled>Updated</a>');							
							}//end inner if	
						}
						$j11('#surveyrateflag').val('1');
						$j11('#updateresultmissed').val('yes');	
					}//end main else if 	
					/* End: MV-693 */
					else if(value.PanelId && $j("#checkpanel_" + value.FieldId).length && $j("#checkpanel_" + value.FieldId).attr('panelid') == value.PanelId)
					{
						fieldorder.push(value.PanelId+'_'+value.FieldId);
						$scope.fieldorder.push(value.PanelId+'_'+value.FieldId);
						$j("#checkpanel_"+value.FieldId).attr("checked", true);						
						$j("#checkpanel_"+value.FieldId).closest('.columngroup').addClass("check_bgcolor");	
						
					}
					//BG-64 : Start
					else if(value.PanelId || typeof value.checkbox_parent_id != "undefined") 
					{	
						$j("#userAssign"+value.PanelId).show();
						$j(".Associations_Panel").addClass('hideIt').removeClass('showIt');

						if(value.checkbox_parent_id != undefined || value.checkbox_parent_id != null){
							$j('#'+value.checkbox_parent_id).prop("checked", true);
							$j('#subcheckboxspan_'+ value.checkbox_parent_id.split('_')[2]).show();
							$j('#subcheckboxspan_'+ value.checkbox_parent_id.split('_')[2]).closest('.association_fields').addClass("check_bgcolor");
						}
						if(value.Type3AssociationFieldId != undefined && value.Type3AssociationFieldId != null && value.Type3AssociationFieldId != ""){
							if(value.checkbox_current_id != undefined && value.checkbox_current_id != null && value.Type3AssociationFieldId.indexOf('_Previous') == -1){
								$j('#'+ value.checkbox_current_id).prop('checked', true);
								fieldorder.push(value.Type3AssociationFieldId);
								$scope.fieldorder.push(value.Type3AssociationFieldId);
								
							} else if(value.checkbox_previous_id != undefined && value.checkbox_previous_id != null){
								$j('#'+ value.checkbox_previous_id).prop('checked', true);
								fieldorder.push(value.Type3AssociationFieldId);
								$scope.fieldorder.push(value.Type3AssociationFieldId);
							}
						} else {
							if(value.PanelId && $j("#checkpanelasso_" + value.FieldId).length) //for name=childassociationitem
							{
								$j("#checkpanelasso_"+value.FieldId).attr("checked", true);
								$j("#checkpanelasso_"+value.FieldId).closest('.association_fields').addClass("check_bgcolor");
								
								fieldorder.push(value.PanelId + "_Association_" + value.FieldId);
								$scope.fieldorder.push(value.PanelId + "_Association_" + value.FieldId);
							}
						}
						
						if(value.checkbox_panel_id && typeof value.checkbox_parent_id != "undefined") 
						{
							array_value[array_value_counter] = value; /* Added For MV-819 */	
							array_value_counter++; /* Added For MV-819 */
						}
					}	
					//BG-64 : Stops
					else if(typeof value.FieldType != 'undefined' && (value.FieldType).length)
					{
						filterCnt++;
					}	
				});
				
				$j("#fieldsortorder").val($scope.fieldorder);
				$j("#setFieldOrder").val('1');
				showSubCheckboxesForView(array_value); /* Repositioned For MV-819 */

				if(filterCnt)
				{	
					$j("#filterbox").show();
					$j('#filterApplied').val('1'); // Volunteer Export Optimization
					$j("#filteroption").text('Hide Filter');
				} else {
					$j("#filteroption").text('Show Filter');
				}
				$j('.filtercount').val('1');
				var fcnt=0;

				$j.each($j.parseJSON(Report), function(key,value) // loop to display field values on filter box
				{	
					if (value.FieldType === "siteEditing" && typeof value.FilterValue === "boolean") {
						value.FilterValue = value.FilterValue ? "Yes" : "No";
					}
					if(typeof value.FieldType != 'undefined' && (value.FieldType).length)
					{										
						fcnt++;
						//mv-693
						if(value.FieldType=='completed' || value.FieldType=='missed') {
							$j('#surveyrateflag').val('1');
							$j('#applyfilterfor'+value.FieldType).val('yes');
						}
						//mv-693	
						if (value.FieldType.toLowerCase().indexOf('serviceterms_')==0 || value.FieldType.toLowerCase().indexOf('blackoutdates_')==0 || value.FieldType.toLowerCase().indexOf('approvedhrs_')==0 || value.FieldType.toLowerCase().indexOf('pendinghrs_')==0 || value.FieldType.toLowerCase().indexOf('disallowedhrs_')==0 ||  value.FieldType.toLowerCase().indexOf('firstdate_')==0 || value.FieldType.toLowerCase().indexOf('recentdate_')==0 ||  value.FieldType.toLowerCase().indexOf('tspersonalstartdate_')==0 || value.FieldType.toLowerCase().indexOf('tspersonalenddate_')==0  || value.FieldType.toLowerCase().indexOf('tsstatus_')==0 || value.FieldType.toLowerCase().indexOf('tstimeoffcalendar_')==0 || value.FieldType.toLowerCase().indexOf('submittedhrs_')==0) { // MV-1761 //TS-1223/TS-1341 //TS-1395/phase-2
							//if ($j('.sel_field_'+ fcnt + ' option[id='+value.FieldType+']').length == 0){
							//	return;
							//}
							
							//$j('.timesheetDetailsOptions').removeClass('toggle-display-' + value.FieldId);
							//$j('.timesheetDetailsOptions').addClass('toggle-display-show-' + value.FieldId);
							
							//$j('select2-container .select2-results__option.toggle-display-'+value.FieldId).css('display','');
							
							$j('#timesheetTemplate_'+value.FieldId).prop("checked",true);	
																																			
							if($j(".timesheetTemplateClass:not(:checked)").length > 0){
								$j('.timeSheetDetailsSelectAll').html("Select All");
							}							
																					
							$j('.sel_field_'+ fcnt + ' option[id='+value.FieldType+']').attr("selected", "selected");
						} else {
								/* MV-1764 : Start */
								if(value.FieldType == 'associations_previous'){
									$j('.sel_field_'+ fcnt + ' option[id=associations_'+value.FieldId+'_previous]').attr("selected", "selected");
								}else{
									$j('.sel_field_'+ fcnt + ' option[id='+value.FieldType+'_'+value.FieldId+']').attr("selected", "selected");
								}
								/* MV-1764 : End */
							}			
					 	
					 	$j1('.sel_field_'+ fcnt).trigger("change");
					 	// $j('.filterOperator_'+ fcnt).val(value.FilterOperator);
					 	$j1('.filterOperator_'+ fcnt).val(value.FilterOperatorValue);
					 	$j1('.filterOperator_'+ fcnt).trigger("change");
						
						var operatorText = $j1('.filterOperator_'+ fcnt + ' option:selected').text();						
						if(operatorText == 'between' || operatorText == 'not between') {							
							var datebetweenValues = value.FilterValue.split(',');
							//BG-110(MV) : Start
							if(isDate(datebetweenValues[0]) && isDate(datebetweenValues[1])){
								$j('#datelink1_' + fcnt).val(datebetweenValues[0]);	
								$j('#datelink2_' + fcnt).val(datebetweenValues[1]);
							}
							else{
								$j('#agetxtbox_1_' + fcnt).val(datebetweenValues[0]);	
								$j('#agetxtbox_2_' + fcnt).val(datebetweenValues[1]);
							}
							//BG-110(MV) : Stops
						} else {
							if(value.FilterValueOption == 2){
								if(value.FieldType.toLowerCase().indexOf('select') == 0 || value.FieldType.toLowerCase().indexOf('number') == 0){
									$j(".filtervalue_"+fcnt).attr("readonly","true");
									$j(".filtervalue_"+fcnt).attr("disabled","true");
								}
								$j('.filtervalue_'+ fcnt).val(value.FilterValueDisplay);
							}else{
					 			$j('.filtervalue_'+ fcnt).val(value.FilterValue);
							}
							$j('.filtervalue_' + fcnt).attr('data-filter-option',value.FilterValueOption);
							$j('.filtervalue_' + fcnt).attr('data-filter-value',value.FilterValue);
						}
												
					 	//updateFilterValues(fcnt);							
						var rel = fcnt;
						var updatefilepattern = 1;
						updateFilterValues(rel,updatefilepattern,$compile,$scope, true);//Parameters Added For ASSNS-656
						//Commented For ASSNS-656	
						/*
						var loadData = updateFilterValues(rel);		
						if(loadData) {							
							var filtercount1 = parseInt($j('.filtercount').val());			
							var button = $j('.btn_add_filter_' + rel).html();			
							if(button == 'Add') {
								$j('.btn_add_filter_' + rel).html('Edit');
								$j('.btn_cancel_filter_' + rel).html('Remove');
								var filtercount1 = parseInt($j('.filtercount').val());
								var filterButtons = "<div id='filterButtons_" + filtercount1 + "' class='filterButtons_" + filtercount1 + "' style='margin-top:7px'><div class='buttonBlock pull-left filter_btn_box'><a class='margin-left-6 filter_add_btn btn_add_filter btn_add_filter_" + filtercount1 + "'  name='Action' rel='"+ filtercount1 +"' ng-click='addFilter(" + filtercount1 + ",1,false)'>Add</a></div><div class='buttonBlock pull-left filter_btn_box'><a class='filter_remove_btn btn_cancel_filter btn_cancel_filter_" + filtercount1 + "'  name='Action' rel='" + filtercount1 + "' ng-click='removeFilter(" + filtercount1 + ")'>Cancel</a></div></div>"										
								var temp = $compile(filterButtons)($scope);
								angular.element(document.getElementById('subfilter_' + filtercount1)).append(temp);				
							}							
						}
						*/
						
					 	if(fcnt > 1)  
					 	{	
					 		if(value.Logical == 'AND')
					 			$j('.logical_'+fcnt).val(1);
					 		else if(value.Logical == 'OR')
					 			$j('.logical_'+fcnt).val(2);	
							$scope.updateFilterPattern();

					 	} 
						
						if(editpatternflage==1)
						{
							$scope.addFilter(fcnt,0, true);	
							$j11('select[name="sel_action"]').val('');
							$j11('select[name="sel_action"]').prop("disabled",true);
							$j11('#filtervaluepattern').val(filtervaluepattern);
							$j11('#hiddenpattern').val('');
							$j11('#patternforrestore').val(filtervaluepattern);
							$j11('#editpatternflage').val(editpatternflage);
						}
						 else {							
							$scope.addFilter(fcnt,1, true);								
						} 		
					}
				});	
				
				/* Start: MV-1929 */
				if($j('#filterApplied').val() == '0') {
					$scope.removeFilter('1');
				}
				/* End: MV-1929 */
				
				$scope.resetTable();
				//if($j(".errormsg_class").length == 0) {
					//$scope.functionA(generateExcel, true, true);
					$scope.getSelectedFieldData('panelFields',0,''); // Volunteer Export Optimization
					$timeout(function () {
						if(generateExcel){							
							$scope.exportExcel();
						}
					},5000); // MV-2174
				//}
			}
		});
		 }		
	}
	$scope.removeColumn = function (panelid,subpanelid,Id) {  
		var searchdata = "";
		if(Id.indexOf("Association") != -1)
		{
			searchdata = panelid+"_"+Id.split("_")[1];
		} else if (panelid == 'TimeSheetSetting' && (subpanelid == 'serviceterms' || subpanelid == 'approvedhrs'
		|| subpanelid == 'pendinghrs' || subpanelid == 'disallowedhrs' || subpanelid == 'firstdate' || subpanelid == 'recentdate' || subpanelid == 'blackoutdates' || subpanelid == 'tspersonalstartdate' || subpanelid == 'tspersonalenddate' || subpanelid == 'tsstatus' || subpanelid == 'tstimeoffcalendar' || subpanelid == 'submittedhrs')) { //TS-1223/TS-1341 TS-1112 //TS-1395/phase-2
			searchdata = "TimeSheetSetting_"+subpanelid + "_" + Id;
		} else{
			searchdata = panelid+"_"+Id;
		}
		$scope.removeFieldOrder.push(searchdata);
		if(Id.indexOf('Association_') == 0) {
		   //BG-64:Start
			if(subpanelid == "Type3"){
				if(Id.indexOf("_Previous") != -1)
				{
					var assoId=Id.split('_')[1];		   
					$j("#checkpanelasso_"+assoId+"_Previous").attr("checked", false);  
					$j("input[id^='checkpanelasso_" + assoId + "_Previous']#").closest('.association_fields').removeClass("check_bgcolor");
					
					if($j("#checkpanelasso_"+assoId).prop("checked") == false)
					{
						$j("#checkbox_parent_"+assoId).attr("checked", false); 
						$j("#subcheckboxspan_"+assoId).hide();
					}
				}
				else
				{
					var assoId=Id.split('_')[1];		   
					$j("#checkpanelasso_"+assoId).attr("checked", false);  
					$j("input[id^='checkpanelasso_" + assoId + "']#").closest('.association_fields').removeClass("check_bgcolor");

					if($j("#checkpanelasso_"+assoId+"_Previous").prop("checked") == false)
					{
						$j("#checkbox_parent_"+assoId).attr("checked", false);
						$j("#subcheckboxspan_"+assoId).hide();
					}
				}
			}
			else{
				var assoId=Id.split('_')[1];		   
				$j("#checkpanelasso_"+assoId).attr("checked", false);  
				$j("input[id^='checkpanelasso_" + assoId + "']#").closest('.association_fields').removeClass("check_bgcolor");		    		   
			}
			//BG-64:Stops		    		   
		 } else if (panelid == 'TimeSheetSetting' && (subpanelid == 'serviceterms' || subpanelid == 'approvedhrs'
		 || subpanelid == 'pendinghrs' || subpanelid == 'disallowedhrs' || subpanelid == 'firstdate' || subpanelid == 'recentdate' || subpanelid == 'blackoutdates' || subpanelid == 'tspersonalstartdate' || subpanelid == 'tspersonalenddate' || subpanelid == 'tsstatus' || subpanelid == 'tstimeoffcalendar' || subpanelid == 'submittedhrs')) { //TS-1223/TS-1341 TS-1112 //TS-1395/phase-2
			$j("#" + subpanelid + "_" + Id).attr("checked", false);
			if($j11(".timesheetTemplateElements:not(:checked)").length > 0){
				$j11('.timeSheetDetailsSelectAll').html("Select All");
			} 
		 } else {
		   $j("#checkpanel_"+Id).attr("checked", false);
		   $j("input[id='checkpanel_" + Id + "']").closest('.columngroup').removeClass("check_bgcolor"); 
		 }  
		 /* Lucky - Added to handle Select ALL/None */
		 $scope.changeSelectText(panelid,subpanelid);
		 /* End - Lucky */
		 var order=$j("#fieldsortorder").val();
		 if(order != '') { 
		  	var columnorder=order.split(',');  
		  	var arr=[];
		  	for(var i=0;i<columnorder.length;i++) {
		   		var column=panelid+'_'+Id;
		   		if(columnorder[i]!=column){
					arr.push(columnorder[i]);
		   		}
		  	}   
		  	$j("#fieldsortorder").val(arr);
		  }  
		  var pos;		 
		  for(var j=0;j<$scope.gridOptions.columnDefs.length;j++) {	   
			   if(panelid != 'TimeSheetSetting' && (subpanelid != 'ServiceTerms' && subpanelid != 'approvedhrs'
			   && subpanelid != 'pendingHrs' && subpanelid != 'disallowedhrs' && subpanelid != 'FirstDate' && subpanelid != 'RecentDate' && subpanelid != 'BlackoutDates' && subpanelid != 'TSPersonalStartDate' && subpanelid != 'TSPersonalEndDate' && subpanelid != 'TSStatus' && subpanelid != 'TSTimeOffCalendar' && subpanelid != 'submittedHrs') //TS-1223/TS-1341 TS-1112 //TS-1395/phase-2
			   && $scope.gridOptions.columnDefs[j].name.split(":").length==4){//historical column count area
					var name=$scope.gridOptions.columnDefs[j].name.split(":");
					pid=name[2];
					fid=name[3];				
					if(panelid+'_'+Id==pid+'_'+fid) {
					 	pos=j;
						$scope.gridOptions.columnDefs[pos].visible = false;
					}
			   } else {//other column count area
					var name=$scope.gridOptions.columnDefs[j].name.split(":");
					pid=name[name.length - 2];
					fid=name[name.length - 1];	
					if(panelid == 'TimeSheetSetting' && (subpanelid == 'serviceterms' || subpanelid == 'approvedhrs'
					|| subpanelid == 'pendinghrs' || subpanelid == 'disallowedhrs' || subpanelid == 'firstdate' || subpanelid == 'recentdate' || subpanelid == 'blackoutdates' || subpanelid == 'tspersonalstartdate' || subpanelid == 'tspersonalenddate' || subpanelid == 'tsstatus' || subpanelid == 'tstimeoffcalendar' || subpanelid == 'submittedhrs')) {	//TS-1223/TS-1341 TS-1112 //TS-1395/phase-2
						if(subpanelid+'_'+Id==pid){
							pos=j;
							$scope.gridOptions.columnDefs[pos].visible = false;
						}
					} else if(panelid+'_'+Id==pid+'_'+fid){
						pos=j;
						$scope.gridOptions.columnDefs[pos].visible = false;
					}
			   }
		  }//end for loop
		  if($scope.removeFieldOrder.length > 0 )
		  {
			$scope.removeFieldOrder.each(function(e){
				
				var tempindex = $scope.fieldorder.indexOf(e);
				
				if(tempindex != -1){
					
					$scope.fieldorder.splice(tempindex,1);
				}
			});
			
		  }	   		
		  var fieldarr = $scope.fieldorder;
		  $scope.fieldorder=[];
		  for(var i=0;i<fieldarr.length;i++){
				if(panelid == 'TimeSheetSetting' && (subpanelid == 'serviceTerms' || subpanelid == 'approvedhrs'
				|| subpanelid == 'pendinghrs'  || subpanelid == 'disallowedhrs' || subpanelid == 'firstdate' || subpanelid == 'recentdate' || subpanelid == 'blackoutdates' || subpanelid == 'tspersonalstartdate' || subpanelid == 'tspersonalenddate' || subpanelid == 'TSStatus' || subpanelid == 'TSTimeOffCalendar' || subpanelid == 'submittedHrs')) { //TS-1223/TS-1341 TS-1112 //TS-1395/phase-2
					if(fieldarr[i] != 'TimeSheetSetting_' + subpanelid + '_' + Id){
						$scope.fieldorder.push(fieldarr[i]);
					}
				} else if(fieldarr[i]!=panelid+'_'+Id){
					$scope.fieldorder.push(fieldarr[i]);
			 	}
		  }  
		  $scope.fieldcount = $scope.fieldorder.length;			  		
		  if($scope.fieldcount == 2) {
			for (var i = 0; i < $scope.gridOptions.columnDefs.length; i++) {
				  $scope.gridOptions.columnDefs[i].width = 615;
			} 
			}   
			else  if($scope.fieldcount == 3) {
				for (var i = 0; i < $scope.gridOptions.columnDefs.length; i++) {
						$scope.gridOptions.columnDefs[i].width = 410;
				}
			}
			else if($scope.fieldcount == 4) {
					for (var i = 0; i < $scope.gridOptions.columnDefs.length; i++) {
							$scope.gridOptions.columnDefs[i].width = 307;
					}         
			} else {
				for (var i = 0; i < $scope.gridOptions.columnDefs.length; i++) {
					$scope.gridOptions.columnDefs[i].width = 246;
				} 
			}
		  $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);		  
		  /* Start - MV-693 */
		  if($j("#checkpanel_"+Id).hasClass('completionratecheckbox') || $j("#checkpanel_"+Id).hasClass('missedratecheckbox')) {
			  	if($j("#checkpanel_"+Id).hasClass('completionratecheckbox')) {					
					$j('#completed_dates_period').val('0').change();
					$j('#completeddatedropdown').css('display','none');
					$j('#close_section3_filter_completed').css('display','none');		
					$j('#div_section3_filter_completed').css('display','none');
					$j('#belowupdatefilter_result_completed').css('display','none');
					$j('#linkTosection3_filter_completed').removeClass('collapseSection_filter').addClass('expandSection_filter');
					$j('#completed_dates_period').attr("disabled",true);	
					$j('#surveyrateflag').val('0');
					$j('#updateresultcompleted').val('no');
					$j('#completedsurveyrateoption').val('');																		  
				} else {
					$j('#missed_dates_period').val('0').change();
					$j('#missed_dates_period').attr("disabled",true);	
					$j('#misseddatedropdown').css('display','none');
					$j('#close_section3_filter_missed').css('display','none');		
					$j('#div_section3_filter_missed').css('display','none');
					$j('#belowupdatefilter_result_missed').css('display','none');
					$j('#linkTosection3_filter_missed').removeClass('collapseSection_filter').addClass('expandSection_filter');					
					$j('#surveyrateflag').val('0');
					$j('#updateresultmissed').val('no');
					$j('#missedsurveyrateoption').val('');					
				}
		  }
		  /* End - MV-693 */
	};
	
	$scope.loadResponse=function(data,generateExcel, fromSavedReport){
		var programid = $j('#programid').val();
		var userid = $j('#userid').val();
		var keyid = $j('#keyid').val();		
		/* Start: MV-693 */
		var surveyrateflag = $j('#surveyrateflag').val(); 
		if (surveyrateflag == 1) {
			$j('.style10').html('<img src="../../images/icons/animated_loading.gif">&nbsp;&nbsp;&nbsp;<strong>We\'re running a number of formulas right now. Please hold tight.</strong>');	
		}
		/* End: MV-693 */
		
		//alert('loadresponse');
		var formData = {};
		data.forEach(obj => {
		   Object.entries(obj).forEach(([key, value]) => {
			  formData[key] = value;
		   });			  
	    	});
		formData.id = userid;
		formData.key = keyid;
		$j.ajax({
		type: "POST",
		//url: "https://reports.americalearns.net/index.cfm?event=user.volunteerfieldvalueslistingsection",
		url: "index.cfm?event=user.volunteerfieldvalueslistingsection",
		data: formData,
		dataType: "json",
		beforeSend: function() {				
			showWaitScreen();
		},
		success: function(data) { 
			// SM-273 : Start
			setTimeout(() => {
			let rows = typeof data.data === "string" ? JSON.parse(data.data) : data.data;
			let originalRows = typeof data.originalResult.data === "string" ? JSON.parse(data.originalResult.data) : data.originalResult.data;


			if (!Array.isArray(rows) || !Array.isArray(originalRows)) {
				console.error("Invalid data format: Expected arrays for 'data' and 'originalResult.data'.");
				return; 
			}


			const updateSiteEditingInPlace = (arr) => {
				for (let i = 0; i < arr.length; i++) {
					arr[i].siteediting = arr[i].siteediting ? "Yes" : "No";
				}
			};

			updateSiteEditingInPlace(rows);
			updateSiteEditingInPlace(originalRows);

			if (typeof data.data === "string") {
				data.data = JSON.stringify(rows);
			}
			if (typeof data.originalResult.data === "string") {
				data.originalResult.data = JSON.stringify(originalRows);
			}
      // SM-273 : Stop	

			getUserListWithPairidListAll = data.getUserListWithPairid;//TS-1098
			if ($j11(".timesheetTemplateClass:checked").length > 0) {
				$j11(".timesheetTemplateClass:checked").each((i, e) => {
					var templateId = $j11(e).val();
					$j11(".timesheetTemplateDetails_"+templateId).show();
				});
			}
			$j11(".timesheetTemplateClass:not(:checked)").each((i, e) => {
				var templateId = $j11(e).val();
				$j11(".timesheetTemplateDetails_"+templateId).hide();
				
			});
				//ASSNS-656 Start
				if($scope.JCounter == 0){
					$scope.resultJSON = data.originalResult;
					$scope.JCounter++;
				}
				else
				{	
					for(i=0;i<data.data.length;i++){
						if(data.data[i]["userid"] == updated_user_id)
						{
							$scope.resultJSON.data[i]=data.data[i];
						}
					}
					updated_user_id ="";
				}
				//console.log($scope.resultJSON);
				//ASSNS-656 End
				if(!fromSavedReport){
					$scope.resetfieldorder();	
				}
				//console.log(data);					
				if($scope.arrangefields=='row'){
					
					header=data.headers;					
					var arr=[];			
					var arr4=[];
					var arr1=[];
					var arr2=[];
					var arr3=[];	
					var arr5=[];					
					var sortedarr=[];					
					$j(".dataGroupHeader").each(function(){
						var panel_id = $j(this).find('a').attr("rel").toString().replace("userAssign","");
						var panel_name = $j(this).find('span').text().trim()
						sortedarr.push( panel_id + ":" + panel_name );
					});								
					var assopnlid='';
					for(m=0;m<header.length;m++){				
						if(header[m].paneltype=='Associations')//Minor Fix Along With ASSNS-656	
							assopnlid=header[m].panelid;
						if(header[m].subpanelname=='Associations1')
							arr1.push(header[m]);
						else if(header[m].subpanelname=='Associations2')
							arr2.push(header[m]);
						else if(header[m].subpanelname=='Associations3')
							arr3.push(header[m]);
						else if(header[m].subpanelname === 'Timesheet Details')//<!---TS-1221--->
							arr5.push(header[m]);	
						else
							arr4.push(header[m]);							
					}
					//sortedarr.forEach(forder=>{ 							
					sortedarr.forEach(function(forder){ 
						if(forder.split(':')[0]==assopnlid){										
							for(i=0;i<arr1.length;i++){									
								arr.push(arr1[i]);
							}									
							for(j=0;j<arr2.length;j++){									
								arr.push(arr2[j]);
							}									
							for(k=0;k<arr3.length;k++){									
								arr.push(arr3[k]);
							}						
						}else{
							for(l=0;l<arr4.length;l++){									
								if(forder.split(':')[0]==arr4[l].panelid){										
									arr.push(arr4[l]);
								}
							}

							if (forder.split(':')[1]=="Timesheet Settings") {//<!---TS-1221--->
								for(l=0;l<arr5.length;l++){																		
									arr.push(arr5[l]);
								}
							}	
						}								
					});	
											
					colCount=arr;
				}else{
					colCount=data.headers;
				}					
				rowCount=data.data;	
				emailIcon=data.mailIcon; //MV-862
				userlistid=data.USERLISTID;	
				/* Start: MV-893 */
				resultUserIdList=data.RESULTUSERLISTID;	
				$j11('#resultUserIdList').val(resultUserIdList);
				resultUserStatus=data.RESULTUSERSTATUS;	
				$j11('#resultUserStatus').val(resultUserStatus);
				/* End: MV-893 */
				//console.log("2."+view_display_list)			
				$timeout(function () {  //MV-862
				  $scope.displayFieldsBasedonCheckbox(view_display_list, fromSavedReport);//MV-819
				});	
			}, 100);			
			},		
			complete: function() {
			
				//$scope.updateFilterPattern();				
				$timeout(function () {
					if(generateExcel){						
						//$j("#createReportExcel").click();
						$scope.exportExcel();
					}
				});			
				hideLoadingOverlay();	
				hideWaitScreen();				
				$j('.style10').html('<img src="../../images/icons/animated_loading.gif">&nbsp;&nbsp;&nbsp;<strong>Please wait while we build your custom export.</strong>');//BG-64		
			},
			error: function(data) {
				status = false;
			}
		});	
			
	};//End LoadResponse

	/* TS-633 : START */
	// TS-633 STEP-2
	$scope.prepareDataForTimeSheetDetails=function(generateExcel, displayAll){		
		var data =[];
		var fieldarr = [];		
		var associationarr = [];
		var programid = $j('#programid').val();
		var userid = $j('#userid').val();
		var usertype = $j('#usertype').val();
		//var rosterOrganization = $j('.rosterOrganization').val();
		var arrangefieldsby = $j('.arrangefields:checked').val();		
		//$scope.arrangefields=arrangefieldsby;	
		/*----------Mv-693--------------*/
		var completedradio = $j('#completed_dates_period option:selected').val();	
		var missedradio = $j('#missed_dates_period option:selected').val();	
		/*----------Mv-693--------------*/
		data.push({			
			"rosterOrganization": rosterOrganization
		});
		if(rosterOrganization == 'custom') {
			var customfields = $j('.customfields').val();
			var customfieldvalue = $j('.customfieldvalue').val();
			// added below line for long list cfqueryparam
			var customfieldvaluenames = $j('.customfieldvaluenames').val();			
			data.push({				
				"customfields": customfields
			});
			data.push({			
				"customfieldvalue": customfieldvalue
			});
			//added below code for long list issue
			data.push({			
				"customfieldvaluenames": customfieldvaluenames
			});
		} else if(rosterOrganization == 'volunteer') {
			var volunlist = $j('.volunlist').val();
			data.push({			
				"volunlist": volunlist
			});
		} else if(rosterOrganization == 'association') {
			var associationlist = $j('.associationlist').val();
			data.push({				
				"associationlist": associationlist
			});
		} else if(rosterOrganization == 'site') {
			var sitelist = $j('.sitelist').val();
			data.push({				
				"sitelist": sitelist
			});
		}	
		$j('input[name="childpanelitem"]:checked').each(function(e,i){
			var field = $j(this).attr('id');
			
			var fieldId = $j(this).val();
			fieldarr.push(fieldId);				
			//fieldorder.push($j(this).attr('panelid')+'_'+fieldId);
		});	
		
		data.push({		
			"volunteerfields": fieldarr
		});
		$j('input[name="childassociationitem"]:checked').each(function(e,i){
			var field = $j(this).attr('id');
			var fieldId = $j(this).val();
			associationarr.push(fieldId);
			//fieldorder.push($j(this).attr('panelid')+'_'+fieldId);
		});	
		data.push({		
			"associationarr": associationarr.toString()
		});			
		var filtercount1 = parseInt($j('.filtercount').val());			
		var filter = "";
		var paneltype = "";
		var fieldtype = "";
		var operator = "";
		var filtervalue = "";
		var logical = " ";
		
		/* Start - MV-693 */
		var completedstartperiod = "";
		var completedendperiod = "";
		var missedstartperiod = "";
		var missedendperiod = "";	
		var completedSurveyIdArray = [];
		var missedSurveyIdArray = [];
		if($j("#completed_dates_period option:selected").val() === 'completed' && $j('#updateresultcompleted').val()=='yes') {
			$j('.surveyid_list_completed:checked').each(function(e,i){				
				var surveyId = $j(this).val();
				completedSurveyIdArray.push(surveyId);								
			});	
			if(completedSurveyIdArray.length == 0) {
				completedstartperiod = $j('#beginsurvey_completed option:selected').val();
				completedendperiod = $j('#endsurvey_completed option:selected').val();
			}
		}
		if($j("#missed_dates_period option:selected").val() === 'missed' && $j('#updateresultmissed').val()=='yes') {
			$j('.surveyid_list_missed:checked').each(function(e,i){				
				var surveyId = $j(this).val();
				missedSurveyIdArray.push(surveyId);								
			});	
			if(missedSurveyIdArray.length == 0) {
				missedstartperiod = $j('#beginsurvey_missed option:selected').val();
				missedendperiod = $j('#endsurvey_missed option:selected').val();
			}
		}		
		/* End - MV-693 */	
		
		
		var filtervaluepattern=$j('#filtervaluepattern').val();	
		for(var i = 1; i<filtercount1; i++) {	
				filterby = $j('option:selected', '.sel_field_' + i).val();	
				panel = $j('option:selected', '.sel_field_' + i).attr('rel2');	
				field = $j('option:selected', '.sel_field_' + i).attr('rel');	
				operatorType = $j('.filterOperator_' + i + ' option:selected').text();
				if(operatorType=='is only')operatorType = 'is';
				fieldvaluefilter = "";
				if(filterby.indexOf("ServiceTerms") != -1 || filterby.indexOf("approvedhrs") != -1 || filterby.indexOf("pendingHrs") != -1 || filterby.indexOf("disallowedhrs") != -1//TS-1112
				|| filterby.indexOf("FirstDate") != -1 || filterby.indexOf("RecentDate") != -1 || filterby.indexOf("BlackoutDates") != -1 || filterby.indexOf("TSPersonalStartDate") != -1 || filterby.indexOf("TSPersonalEndDate") != -1 || filterby.indexOf("TSStatus") != -1 || filterby.indexOf("TSTimeOffCalendar") != -1 || filterby.indexOf("submittedHrs") != -1){ //TS-1223/TS-1341 //TS-1395/phase-2
					filterby = filterby.split("_")[1];
				}
				if($j('#surveyrateflag').val() == 0 && (field == 'completed' || field == 'missed')) {
					$j('#surveyrateflag').val('1');
					$j('.style10').html('<img src="../../images/icons/animated_loading.gif">&nbsp;&nbsp;&nbsp;<strong>We\'re running a number of formulas right now. Please hold tight.</strong>');
				}
				if(operatorType == 'between' || operatorType == 'not between') {
					$j('.filtervalue_' + i).each(function(){
						fieldvaluefilter += $j(this).val() + ",";								  
					});
					fieldvaluefilter.substring(0, fieldvaluefilter.length-1);				
				} else {
					fieldvaluefilter = 	$j('.filtervalue_' + i).val();
					if(fieldvaluefilter == '') {
						fieldvaluefilter = ' ';
					}
				}
				if(i>1) {
					logical += $j('option:selected', '.sel_action_' + i).text();
				}
				filter += filterby + "~";
				paneltype += panel + "~";
				fieldtype += field + "~";
				operator += operatorType + "~";
				filtervalue += fieldvaluefilter + "~";	
				logical += "~";			
		}
		data.push({			
				"filter": filter			
		});
		data.push({			
				"paneltype": paneltype
		});
		data.push({				
				"fieldtype": fieldtype
		});
		data.push({			
				"operator": operator
		});
		data.push({				
				"filtervalue": filtervalue
		});
		data.push({				
				"logical": logical
		});		
		data.push({		  
		  "arrangefieldsby": arrangefieldsby
		 });
		data.push({		  
		  "sortcolumn": sortcolumn
		 });
		data.push({		  
		  "sorttype": sorttype
		 });
		 data.push({		  
		  "programid": programid
		 });
		 data.push({		  
		  "userid": userid
		 });
		 data.push({
			"filtervaluepattern": filtervaluepattern
		 });
		 /* Start - MV-693 */
		 data.push({		  
		  "completedSurveyIdArray": completedSurveyIdArray
		 });
		 data.push({		  
		  "missedSurveyIdArray": missedSurveyIdArray
		 });		 
		 data.push({		  
		  "completedstartperiod": completedstartperiod
		 });
		 data.push({		  
		  "completedendperiod": completedendperiod
		 });
		 data.push({		  
		  "missedstartperiod": missedstartperiod
		 });
		 data.push({
			"missedendperiod": missedendperiod
		 });
		 var surveyrateflag = $j('#surveyrateflag').val();	
		 data.push({
			"surveyrateflag": surveyrateflag
		 });		 
		 /* End - MV-693 */	
		data.push({				
				"sessionvolunteerlist": $j('#sessionvolunteerlist').val()
		});
		 data.push({		  
		  "currentusertype": usertype
		 });	
		//console.log(data);
		if ($j11(".timesheetTemplateClass") != undefined) {
			if($j11(".arrangefields:checked").val() == "column") {
				var leftCol = [];
				var rightCol = [];
				var timesheetTemplateIdList = [];
				$j11(".timesheetTemplateClass:checked").each((i, e) => { 
					if(i % 2 == 0){
						leftCol.push(e);
					} else {
						rightCol.push(e);
					}
				});
				timesheetTemplateIdList = leftCol.concat(rightCol);
				data.push({		  
					"templateIdList": timesheetTemplateIdList.map((el,i) => el.value).join(",")
				});
			} else {
				data.push({		  
					"templateIdList": $j11(".timesheetTemplateClass:checked").map((_,el) => el.value).get().join(",")
				});
			}
				 
		}
				
		$scope.loadTimeSheetDetails(data,generateExcel, displayAll);			
	}; 

	// TS-633 STEP-3
	$scope.loadTimeSheetDetails=function(data,generateExcel, displayAll){
			var programid = $j('#programid').val();
			var userid = $j('#userid').val();
			var keyid = $j('#keyid').val();		
			/* Start: MV-693 */
			var surveyrateflag = $j('#surveyrateflag').val(); 
			if (surveyrateflag == 1) {
				$j('.style10').html('<img src="../../images/icons/animated_loading.gif">&nbsp;&nbsp;&nbsp;<strong>We\'re running a number of formulas right now. Please hold tight.</strong>');	
			}
			if ($j11(".timesheetTemplateClass:checked") > 0) {
				$j('.style10').html('<img src="../../images/icons/animated_loading.gif">&nbsp;&nbsp;&nbsp;<strong>We\'re loading export options for this template.</strong>');	
			}
			
			var formData = {};
			data.forEach(obj => {
			   Object.entries(obj).forEach(([key, value]) => {
				  formData[key] = value;
			   });			  
		    	});
			formData.id = userid;
			formData.key = keyid;
			
			/* End: MV-693 */
			$j.ajax({
			type: "POST",
			url: "index.cfm?event=user.volunteerfieldvalueslistingsection",
			data: formData,			
			dataType: "json",
			beforeSend: function() {				
				showWaitScreen();
			},
			success: function(data) { 
				getUserListWithPairidList = data.getUserListWithPairid;//TS-1098
				if ($j11(".timesheetTemplateClass:checked").length > 0) {
					$j11(".timesheetTemplateClass:checked").each((i, e) => {
						var templateId = $j11(e).val();
						$j11(".timesheetTemplateDetails_"+templateId).show();
					});
				}
				$j11(".timesheetTemplateClass:not(:checked)").each((i, e) => {
					var templateId = $j11(e).val();
					$j11(".timesheetTemplateDetails_"+templateId).hide();
					
				});
				//ASSNS-656 Start
				if($scope.JCounter == 0){
					$scope.resultJSON = data.originalResult;
					$scope.JCounter++;
				}
				else
				{	
					for(i=0;i<data.data.length;i++){
						if(data.data[i]["userid"] == updated_user_id)
						{
							$scope.resultJSON.data[i]=data.data[i];
						}
					}
					updated_user_id ="";
				}
				//console.log($scope.resultJSON);
				//ASSNS-656 End
				$scope.resetfieldorder();						
				if($scope.arrangefields=='row'){
					header=data.headers;					
					var arr=[];			
					var arr4=[];
					var arr1=[];
					var arr2=[];
					var arr3=[];	
					var arr5=[];					
					var sortedarr=[];					
					$j(".dataGroupHeader").each(function(){
						var panel_id = $j(this).find('a').attr("rel").toString().replace("userAssign","");
						var panel_name = $j(this).find('span').text().trim()
						sortedarr.push( panel_id + ":" + panel_name );
					});								
					var assopnlid='';
					for(m=0;m<header.length;m++){	
						if(header[m].paneltype=='Associations')//Minor Fix Along With ASSNS-656	
							assopnlid=header[m].panelid;
						if(header[m].subpanelname=='Associations1')
							arr1.push(header[m]);
						else if(header[m].subpanelname=='Associations2')
							arr2.push(header[m]);
						else if(header[m].subpanelname=='Associations3')
							arr3.push(header[m]);
						else if(header[m].subpanelname === 'Timesheet Details')//<!---TS-1221--->
							arr5.push(header[m]);	
						else
							arr4.push(header[m]);							
					}							
					//sortedarr.forEach(forder=>{ 							
					sortedarr.forEach(function(forder){ 
						if(forder.split(':')[0]==assopnlid){										
							for(i=0;i<arr1.length;i++){									
								arr.push(arr1[i]);
							}									
							for(j=0;j<arr2.length;j++){									
								arr.push(arr2[j]);
							}									
							for(k=0;k<arr3.length;k++){									
								arr.push(arr3[k]);
							}						
						}else{
							for(l=0;l<arr4.length;l++){									
								if(forder.split(':')[0]==arr4[l].panelid){										
									arr.push(arr4[l]);
								}
							}

							if (forder.split(':')[1]=="Timesheet Settings") {//<!---TS-1221--->
								for(l=0;l<arr5.length;l++){																		
									arr.push(arr5[l]);
								}
							}	
						}								
					});		
							
					colCount=arr;
				}else{
					colCount=data.headers;
				}					
				rowCount=data.data;	
				userlistid=data.USERLISTID;		
				//console.log("2."+view_display_list)	
				if (displayAll) {
					$scope.displayFieldsBasedonCheckbox(view_display_list);
				}		
				//$scope.displayFieldsBasedonCheckbox(view_display_list);//MV-819				
			},		
			complete: function() {
			
				//$scope.updateFilterPattern();				
				$timeout(function () {
					if(generateExcel){						
						//$j("#createReportExcel").click();
						$scope.exportExcel();
					}
				});			
				hideLoadingOverlay();	
				hideWaitScreen();				
				$j('.style10').html('<img src="../../images/icons/animated_loading.gif">&nbsp;&nbsp;&nbsp;<strong>Please wait while we build your custom export.</strong>');//BG-64		
			},
			error: function(data) {
				status = false;
			}
		});	
			
	};//End loadTimeSheetDetails	
	/* TS-633 : END */

	$scope.resetfieldorder = function() {
		var userListPair = $scope.getUserListAll?getUserListWithPairidListAll:getUserListWithPairidList;//TS-1098
		//showLoadingOverlay();
		$scope.fieldorder=[];
		$j('input[name="childpanelitem"]:checked').each(function(e,i){		
			var panelId = $j(this).attr('panelid');																 	
			var fieldId = $j(this).val();					
			$scope.fieldorder.push(panelId + '_' + fieldId);
								  
		});
		$j('input[name="childassociationitem"]:checked').each(function(e,i){		
			var panelId = $j(this).attr('panelid');																 	
			var fieldId = 'Association_' + $j(this).val();	
			$scope.fieldorder.push(panelId + '_' + fieldId);
									  
		}); 
		/* TS-633 : START */
		// TS-633 STEP-5
		//S:TS-1098 
		var indexCol = 0;
		var prevTempid = 0;
		var fieldValuesTS = ['serviceterms','tspersonalstartdate','tspersonalenddate','firstdate','recentdate','blackoutdates','approvedhrs','pendinghrs','disallowedhrs','tsstatus','tstimeoffcalendar','submittedhrs'];//TS-1395/phase-2
		if(userListPair.length){
			userListPair.forEach(function(item,i){
				for(indexCol = 1; indexCol<=item.PAIRID_COUNT;indexCol++){
					$j('.timesheetTemplateElements:checked').each(function(e,j){		
						var panelId = "TimeSheetSetting";													 	
						var fieldId = $j(this).attr('id');
						if(prevTempid != item.TEMPLATEIDFK && indexCol == 1){
							prevTempid = item.TEMPLATEIDFK;
						}	
						if(fieldValuesTS.includes(fieldId.split("_")[0]) && fieldId.split("_")[1] == prevTempid){
							$scope.fieldorder.push(panelId + '_' + fieldId + '_' + indexCol);
						}
					});
				}
			});
		}
		//E:TS-1098 
		/* TS-633 : END */
		$scope.fieldcount = $scope.fieldorder.length;
		//hideLoadingOverlay();
	}
	
	//Added for BG-64 : Start
	$scope.current_date_decider_flag ="remove";
	$scope.historical_date_decider_flag ="remove";

	$scope.current_decider_flag ="";
	$scope.historical_decider_flag ="";

	$scope.current_date_decider_fieldtype ="";
	$scope.historical_date_decider_fieldtype ="";

	$scope.currentStatusList = [];
	$scope.previousStatusList = [];
	//Added for BG-64 : End

	$scope.displayFieldsBasedonCheckbox = async function(view_data_as_list, fromSavedReport) { //TS-1098/* view_data_as_list added for MV-819 */
		$scope.gridOptions.columnDefs = [];
		$scope.gridOptions.data = [];
		var totalVolunCount = []; // BG-113
		$scope.fieldcount = $scope.fieldorder.length;
		//S:TS-1098
		var userListPair = $scope.getUserListAll?getUserListWithPairidListAll:getUserListWithPairidList;
		if(fromSavedReport != undefined && fromSavedReport == 1){
			$scope.fieldorder = await resetfieldorderterm($scope.fieldorder,userListPair);
			$scope.fieldcount = $scope.fieldorder.length;
		}
		//E:TS-1098
		//console.log('Display Field: ' + $scope.fieldorder);
		$timeout( function() {			
				var ratecount=0;
				//S:TS-1098
				var previndex = 0;
				var lastIndex = 0;
				var lastArr = [];
				var localArr = [];
				var colCount1 = [];
				var indexCol = 0;
				var prevUserid = 0;
				var prevTempid = 0;
				var existsL = 0;
				var exists = 0;
				var tsFieldTypes = ['serviceterms','TSPersonalStartDate','TSPersonalEndDate','TSStatus','TSTimeOffCalendar','firstdate','recentdate','blackoutdates','submittedHrs','approvedhrs','pendingHrs','disallowedhrs'];
				var tempArr = [];	
				colCount1 = colCount;
				userListPair.forEach(function(item,i){
					for(indexCol = 1; indexCol<=item.PAIRID_COUNT;indexCol++){
						colCount1.forEach(function(col,index){
							allObj = "";
							allObj = Object.assign({}, col);
							if(allObj.panelid == "TimeSheetSetting" && tsFieldTypes.includes(allObj.fieldtype) && allObj.name.split("_").length == 2 && item.TEMPLATEIDFK == allObj.name.split("_")[1]) {
								allObj.name = allObj.name + '_' + indexCol;
								allObj.id = allObj.id + '_' + indexCol;
								tempArr = colCount.filter(obj => obj.name === allObj.name && obj.id === allObj.id);
								if(!tempArr.length){
									if(previndex == 0){
										previndex = index;
										localArr = [];
									}
									localArr.push(allObj);
									lastIndex = index;
								}
							}
							else if(previndex > 0 && lastIndex > 0 && !tsFieldTypes.includes(allObj.fieldtype)){
								existsL = lastArr.some(obj => obj.id === allObj.id);
								if (!existsL) {
									lastArr.push(allObj);
								}
							}
						});	
					}
				});
				if(localArr.length){
					colCount.splice(previndex, lastIndex, ...localArr);
					if(lastArr.length){
						lastArr.forEach(obj2 => {
							exists = colCount.some(obj1 => obj1.id === obj2.id);
							if (!exists) {
								colCount.push(obj2);
							}
						});
					}
				}
				//E:TS-1098
					for (var colIndex = 0; colIndex < colCount.length; colIndex++) {
							var arrelement = "";
							
							var panelId = colCount[colIndex].panelid;
							/* TS-633 : START */
							// TS-633 STEP-6
							if (panelId == "TimeSheetSetting") {
								arrelement = colCount[colIndex].panelid + '_' + colCount[colIndex].name;
							} else {
								arrelement = colCount[colIndex].panelid + '_' + colCount[colIndex].id;		
							}
							/* TS-633 : END */
							var usertype=$j("#currentusertype").val();	
							var permission=	$j("#listcontain").val();			
							if($scope.fieldorder.indexOf(arrelement) != -1) { 						
								var headerTemp;	
								var cellclass;
								var columnmove=true;
								var freezecolumn=false;
								var cellTemp;
								var editCellTemp;
								var editCellClass = '';
								var pencilCellClass = '';
								var pencilCellId = ''; //MV-2153
								var spanid="";//MV-2153
								var dispName;
								var wid;
								var fieldtype='string';
								var fieldname='';
								var pnlid_fid='';
								var type='string';
								//var encodedColName = colCount[colIndex].displayName.replace(/[\u00A0-\u9999<>\&]/gim, function(i) {
									//   return i.charCodeAt(0)
								//});	
								/* Start: BG-113 */
								var subpanelid = colCount[colIndex].subpanelid;
								var isQualitative = colCount[colIndex].isQualitative;
								var agefield = colCount[colIndex].description;								
								/* End: BG-113 */
								/*MV-2153:Start*/
								var encodedColName =''
								if(colCount[colIndex].fieldtype=='SurveyParticipation'){
									encodedColName =$scope.htmlEncode(colCount[colIndex].displayName.replace('Survey',surveyAlias));
								}else{
									encodedColName =$scope.htmlEncode(colCount[colIndex].displayName);
								}
								/*MV-2153:End*/								
								var encodedPanelName=$scope.htmlEncode(colCount[colIndex].panelname);
								if(colCount[colIndex].subpanelname=='Associations1' && colCount[colIndex].panelname=='Associations'){
									var encodedSubpanelName=': '+'Type 1 Associations';
								}else if(colCount[colIndex].subpanelname=='Associations2' && colCount[colIndex].panelname=='Associations'){
									var encodedSubpanelName=': '+'Type 2 Associations';
								}else if(colCount[colIndex].subpanelname=='Associations3' && colCount[colIndex].panelname=='Associations'){
									//var encodedSubpanelName=': '+'Type 3 Associations';
									var encodedSubpanelName=" & "+beneficiaryAlias+' Groups: '+'Groups'; //MCR-174
								}else if(colCount[colIndex].subpanelname!='Default'){
								var encodedSubpanelName=': '+$scope.htmlEncode(colCount[colIndex].subpanelname);
								}else{
									var encodedSubpanelName='';
								}
								if(colCount[colIndex].subpanelname=='Default'){
									dispName=colCount[colIndex].panelname;
								}else{
									dispName=colCount[colIndex].panelname + " : " +  colCount[colIndex].subpanelname;
								}
								// TS-633 : START
								// TS-633 STEP-7
								if(colCount[colIndex].subpanelid === "TimeSheetDetails"){
									dispName = "Timesheet Details";//<!---TS-1221--->
								}
								// TS-633 : END
								if($scope.fieldcount == 2) {
                                    wid = 615;
                                } else if ($scope.fieldcount == 3){
                                    wid = 410;
                                } else if ($scope.fieldcount == 4){
                                    wid = 307;
                                } else {
                                    wid = 246;
                                }							
								headerTemp = '<div style="height:58px;" role="columnheader" ng-class="{ \'sortable\': sortable }"  ui-grid-one-bind-aria-labelledby-grid="col.uid + \'-header-text \' + col.uid + \'-sortdir-text\'" aria-sort="{{col.sort.direction == asc ? \'ascending\' : ( col.sort.direction == desc ? \'descending\' : (!col.sort.direction ? \'none\' : \'other\'))}}">' + '<div role="button" tabindex="0" class="ui-grid-cell-contents ui-grid-header-cell-primary-focus" col-index="renderIndex" title="TOOLTIP"';
								
								/*MV-2153:Start*/
								if(rosterOrganization != 'volunteer') {
									headerTemp += ' ng-click="grid.appScope.cellClickedSort(' +"'"+colCount[colIndex].name.trim()+"'"+')"';
								}else if(rosterOrganization == 'volunteer' && colCount[colIndex].fieldtype=='status'){
									headerTemp += ' ng-click="grid.appScope.cellClickedSort(' +"'"+colCount[colIndex].name.trim()+"'"+')"';
								}
								/*MV-2153:End*/
								headerTemp += '>' + '<span  class="ui-grid-header-cell-label" ui-grid-one-bind-id-grid="col.uid + \'-header-text\'">';
								if(colCount[colIndex].paneltype=='Association'){								
									headerTemp += encodedSubpanelName.replace(':','')+'{{  CUSTOM_FILTERS }}</span>' + '</br><div style="float:left;margin-top:10px;color:#fff">'+encodedColName+'</div>';
								} else {
									headerTemp += encodedPanelName + encodedSubpanelName+'{{  CUSTOM_FILTERS }}</span>' + '</br><div style="float:left;margin-top:10px;color:#fff">'+encodedColName+'</div>';
								}
								//headerTemp += '>' + '<span class="ui-grid-header-cell-label" ui-grid-one-bind-id-grid="col.uid + //\'-header-text\'">'+encodedPanelName+encodedSubpanelName+'{{  CUSTOM_FILTERS }}</span>' + '</br><div //style="float:left;margin-top:10px;color:#fff">'+encodedColName+'</div>';					
								headerTemp += '<span ui-grid-one-bind-id-grid="col.uid + \'-sortdir-text\'" ui-grid-visible="col.sort.direction"'+
							'aria-label="{{getSortDirectionAriaLabel()}}" style="float:left;margin-left: 5px;margin-top: 14px;"> <i id="' + colCount[colIndex].name.trim() + '" ng-class="{ \'ui-grid-icon-up-dir\': col.sort.direction == asc, \'ui-grid-icon-down-dir\':'+ 'col.sort.direction == desc, \'ui-grid-icon-blank\': !col.sort.direction }"'+
							'title="{{isSortPriorityVisible() ? i18n.headerCell.priority + \' \' + ( col.sort.priority + 1'+' )  : null}}"' + ' aria-hidden="true">&nbsp;&nbsp;</i>'+ '<sub ui-grid-visible="isSortPriorityVisible()" class="ui-grid-sort-priority-number">' + '{{col.sort.priority + 1}}</sub>' + '</span> </div>' + '<div role="button" tabindex="0" ui-grid-one-bind-id-grid="col.uid + \'-menu-button\'" ' + 'class="ui-grid-column-menu-button" ng-if="grid.options.enableColumnMenus && !col.isRowHeader  &&'+ 'col.colDef.enableColumnMenu !== false" ng-click="toggleMenu($event)" ng-class="{\'ui-grid-column-menu-button-last-col\': isLastCol}"'+
							'ui-grid-one-bind-aria-label="i18n.headerCell.aria.columnMenuButtonLabel" aria-haspopup="true">'+
							'<i class="ui-grid-icon-angle-down" aria-hidden="true"> &nbsp;</i></div>' + '<div ui-grid-filter></div>';
							
							/* MV-862:Start */
								if(colCount[colIndex].displayName == "Password Setup Status") {
									if(iconEnable == 1) {
										headerTemp +='<span ng-controller="postserviceCtrl" ng-click="passwordSetupPopup()" style="position: absolute; left: 81%; top: 50%; webkit-transform: translate(-50%, -50%);transform: translate(-50%, -50%);"><img src="../../images/icons/mail2_24.gif"></span>';
									}
									else if(emailIcon ==1 && iconEnable ==2){
										headerTemp+='<span ng-controller="postserviceCtrl" ng-click="passwordSetupPopup()" style="position: absolute; left: 81%; top: 50%; webkit-transform: translate(-50%, -50%);transform: translate(-50%, -50%);"><img src="../../images/icons/mail2_24.gif"></span>';
									}
								}
								headerTemp +='</div>';
             				/* MV-862:End */
							cellclass='{{ row.entity.cellclass }}';
							if(colCount[colIndex].name.trim() == "fname" || colCount[colIndex].name.trim() == "lname") {
								// if(rosterOrganization != 'volunteer' && colCount[colIndex].name.trim() == "fname") {
								if(colCount[colIndex].name.trim() == "fname" || colCount[colIndex].name.trim() == "lname") { // BG-113 Removed above Condition
									columnmove=false;	
									freezecolumn=true;
								}
								headerTemp += '';
							} else {			
								if(colCount[colIndex].subpanelid == "TimeSheetDetails")			
									headerTemp += '<div class="delColumn" ng-controller="postserviceCtrl"><div class="deletecolumn" ng-click="grid.appScope.removeColumn(' + "'"+colCount[colIndex].panelid + "'" +','+"'"+colCount[colIndex].name.split('_')[0]+"'"+','+"'"+colCount[colIndex].id+"'"+')" style="float:right;" rel="' + colCount[colIndex].id + '"></div></div>';
								else {
									headerTemp += '<div class="delColumn" ng-controller="postserviceCtrl"><div class="deletecolumn" ng-click="grid.appScope.removeColumn('+colCount[colIndex].panelid+','+"'"+colCount[colIndex].subpanelid+"'"+','+"'"+colCount[colIndex].id+"'"+')" style="float:right;" rel="' + colCount[colIndex].id + '"></div></div>';
								}
							}	
							
							if(colCount[colIndex].name.trim() == "volunteer_userid" || colCount[colIndex].name.trim() == "siteid" || colCount[colIndex].fieldtype == "completionrate" || colCount[colIndex].fieldtype == "historicalrates" || colCount[colIndex].fieldtype == "completed" || colCount[colIndex].fieldtype == "missed" || colCount[colIndex].name.indexOf("previous") > 0 /*Added for BG-64*/ || colCount[colIndex].fieldtype == "passwordStatus" /*Added for MV-862*/ || (colCount[colIndex].fieldtype == "email" && colCount[colIndex].paneltype=='Standard' && colCount[colIndex].subpanelname == 'Default') /*Added for Adminfunct-34*/ 
							|| (colCount[colIndex].fieldtype=='serviceterms' || colCount[colIndex].fieldtype=='blackoutdates' 
										|| colCount[colIndex].fieldtype=='approvedhrs'	|| colCount[colIndex].fieldtype=='pendingHrs' || colCount[colIndex].fieldtype=='disallowedhrs' //TS-1112
										|| colCount[colIndex].fieldtype=='firstdate' || colCount[colIndex].fieldtype=='recentdate' || colCount[colIndex].fieldtype == "DateArchived" || colCount[colIndex].fieldtype == "DateCreated" // MV-2153(K)
										|| colCount[colIndex].fieldtype=='pasttemplateassignments') || colCount[colIndex].fieldtype=='signdocument'
										|| colCount[colIndex].fieldtype=='cohortid' || colCount[colIndex].fieldtype=='PersonalStartDate' || colCount[colIndex].fieldtype=='PersonalEndDate' || colCount[colIndex].fieldtype=='TSPersonalStartDate' || colCount[colIndex].fieldtype=='TSPersonalEndDate' || colCount[colIndex].fieldtype=='TSStatus' || colCount[colIndex].fieldtype=='TSTimeOffCalendar' || colCount[colIndex].fieldtype=='submittedHrs' || colCount[colIndex].fieldtype=='status') {//MV-1389 //TS-1223/TS-1297/TS-1341//TS-1395/phase-2 //MV-2153
								/* Start: MV-2064(Added if condition ,else code already available) */
								if(colCount[colIndex].fieldtype=='signdocument') {
									editCellTemp = 'title="'+encodedColName.replace('"','&quot;')+'"';
								}else{
									editCellTemp = 'title="{{ COL_FIELD }}"';
								}
								/* End: MV-2064*/
							} else {
								if((usertype=='submanager' && permission!=0)||(usertype=='manager')){//TS-1223/TS-1297
									if(colCount[colIndex].fieldtype == "fileattachment") {
										editCellTemp = 'panelid="'+colCount[colIndex].panelid+'" panelname="'+encodedPanelName+'" paneltype="'+colCount[colIndex].paneltype+'" subpanelid="'+colCount[colIndex].subpanelid+'" subpanelname="'+colCount[colIndex].subpanelname+'" column="'+colCount[colIndex].name+'" columnvalue="{{ COL_FIELD }}" userid="{{ row.entity.userid }}" title="'+encodedColName.replace('"','&quot;')+'" fieldtype="'+ colCount[colIndex].fieldtype +'"';
									} else {
										editCellTemp = 'panelid="'+colCount[colIndex].panelid+'" panelname="'+encodedPanelName+'" paneltype="'+colCount[colIndex].paneltype+'" subpanelid="'+colCount[colIndex].subpanelid+'" subpanelname="'+colCount[colIndex].subpanelname+'" column="'+colCount[colIndex].name+'" columnvalue="{{ COL_FIELD }}" userid="{{ row.entity.userid }}" title="'+encodedColName.replace('"','&quot;')+'" fieldtype="'+ colCount[colIndex].fieldtype +'"';
									}
									//S:TS-1112 TO HIDE PENCIL ICON
									if(colCount[colIndex].fieldtype != 'disallowedhrs' || colCount[colIndex].fieldtype != 'submittededHrs' || colCount[colIndex].fieldtype != 'tsstatus' || colCount[colIndex].fieldtype != 'tstimeoffcalendar') //TS-1395/phase-2
									{
									editCellClass = cellclass + 'section';
									pencilCellClass = cellclass;
									}
									//E:TS-1112
									/*MV-2153:Start*/
									if(colCount[colIndex].fieldtype=='SurveyParticipation'){
										pencilCellId='LP_{{ row.entity.userid }}';	
										editCellClass =	editCellClass +' '+'SurveyParticipation';							
									}
									/*MV-2153:End*/
								}
							}
							cellTemp = '<div class="ngCellText ui-grid-cell-contents ng-binding ng-scope '+editCellClass+'"';
							
							cellTemp += editCellTemp;
							
							cellTemp +=  '>';
							if(colCount[colIndex].name.trim() == "fname" || colCount[colIndex].name.trim() == "lname") {
								 fieldtype=colCount[colIndex].fieldtype; // BG-113
								 fieldname=colCount[colIndex].displayName;
								 pnlid_fid=colCount[colIndex].panelid+'_'+colCount[colIndex].id;
								 
								cellTemp += '<span class="link" user="{{ row.entity.userid }}" style="float:left;overflow: hidden;position: absolute;text-overflow: ellipsis;white-space: nowrap;">{{ COL_FIELD }}</span>';
							} else if (colCount[colIndex].fieldtype == "fileattachment" || colCount[colIndex].fieldtype == "photo" || colCount[colIndex].fieldtype == "signdocument") {	
								fieldtype=colCount[colIndex].fieldtype;
								fieldname=colCount[colIndex].displayName;
								pnlid_fid=colCount[colIndex].panelid+'_'+colCount[colIndex].id;
								cellTemp += '<span style="float:left;overflow: hidden;position: absolute;text-overflow: ellipsis;white-space: nowrap;"><div ng-bind-html="COL_FIELD | trusted"></div></span>';
							} else {	
									if(colCount[colIndex].fieldtype=='completionrate' || colCount[colIndex].fieldtype=='historicalrates' ||colCount[colIndex].fieldtype=='associations' || colCount[colIndex].fieldtype=='completed' || colCount[colIndex].fieldtype=='missed'){
										fieldtype=colCount[colIndex].fieldtype;
										if(colCount[colIndex].fieldtype=='completionrate' || colCount[colIndex].fieldtype=='historicalrates' || colCount[colIndex].fieldtype=='completed' || colCount[colIndex].fieldtype=='missed') {
											type='number';
										}
									}else if(colCount[colIndex].fieldtype=='date'){
										type=colCount[colIndex].fieldtype;
										if(colCount[colIndex].fieldtype == 'date' && agefield != 'undefined' && agefield != null && agefield != "" && agefield == "Current Age") {
											type='number';
										}
									} else if(colCount[colIndex].name.trim() == "volunteer_userid" || colCount[colIndex].fieldtype=='number' || (colCount[colIndex].fieldtype=='select' && isQualitative == '0')) {
										type='number';
									}
									fieldtype=colCount[colIndex].fieldtype; // BG-113
									if(colCount[colIndex].fieldtype=='completionrate' || colCount[colIndex].fieldtype=='historicalrates'){
										fieldname=colCount[colIndex].displayName.split(':')[0];	
										ratecount=ratecount+1;	
										//Apply If condition for CF18-30									
										if(colCount[colIndex].displayName.split(':').length==2)
											pnlid_fid=colCount[colIndex].panelid+'_'+colCount[colIndex].id+"_"+ratecount;	
										else
											pnlid_fid=colCount[colIndex].panelid+'_'+colCount[colIndex].id;
										//pnlid_fid=colCount[colIndex].panelid+'_'+colCount[colIndex].id;
									}else if (colCount[colIndex].fieldtype=='serviceterms' || colCount[colIndex].fieldtype=='blackoutdates' || colCount[colIndex].fieldtype=='approvedhrs'	|| colCount[colIndex].fieldtype=='pendingHrs' || colCount[colIndex].fieldtype=='disallowedhrs' || colCount[colIndex].fieldtype=='firstdate' || colCount[colIndex].fieldtype=='recentdate' || colCount[colIndex].fieldtype=='TSPersonalStartDate' || colCount[colIndex].fieldtype=='TSPersonalEndDate' || colCount[colIndex].fieldtype=='TSStatus' || colCount[colIndex].fieldtype=='TSTimeOffCalendar' || colCount[colIndex].fieldtype=='submittedHrs'){ //TS-1223/TS-1341 //TS-1395/phase-2
										// TS-633 STEP-8
										/* TS-633 : New Condition Added */
										// NOTE: pnlid_fid is used during export.

										fieldname=colCount[colIndex].displayName;
										pnlid_fid= colCount[colIndex].name;
										if(colCount[colIndex].fieldtype=='approvedhrs' || colCount[colIndex].fieldtype=='pendingHrs' || colCount[colIndex].fieldtype=='disallowedhrs' || colCount[colIndex].fieldtype=='submittedHrs') {//TS-1112//TS-1395/phase-2
											type='number';
										} else if (colCount[colIndex].fieldtype=='firstdate' || colCount[colIndex].fieldtype=='recentdate') {
											type='date';
										}
									} else {
										fieldname=colCount[colIndex].displayName;
										pnlid_fid=colCount[colIndex].panelid+'_'+colCount[colIndex].id;
										pnlid_fid=pnlid_fid.replace('Association_','');
									}
									/*MV-2153:Start*/
									if (colCount[colIndex].fieldtype=='status'){
										spanid='id="AStatus_{{ row.entity.userid }}"';
									}
								cellTemp += '<span '+spanid+' style="float:left;overflow: hidden;position: absolute;text-overflow: ellipsis;white-space: nowrap;">{{ COL_FIELD }}</span>';
                /*MV-2153:End*/
							}
							cellTemp += '</span>';
							
							cellTemp += '<div id="'+pencilCellId+'" class="'+pencilCellClass+'" style="float:right;cursor:pointer;"' + editCellTemp + '></div>'; //MV-2153
										
							cellTemp += '</div>';
							
							//BG-81 : Start
							var counterflag = 0;
							var panelIdForTimeSheet = colCount[colIndex].panelid;
							var tmp_name = "";
							/* TS-633 : START */
							// TS-633 STEP-9 PART-1
							if (panelIdForTimeSheet == 'TimeSheetSetting') {
								// NOTE: Use Name field after displayName for TimeSheetSetting 
								tmp_name = colCount[colIndex].displayName.toString().replace(/\./g,' ')+':'+colCount[colIndex].name+':'+colCount[colIndex].id;
							} else {
								tmp_name = colCount[colIndex].displayName.toString().replace(/\./g,' ')+':'+colCount[colIndex].panelid+':'+colCount[colIndex].id;
							}
							/* TS-633 : END */
							$scope.gridOptions.columnDefs.each(function(e){
								if(e.name == tmp_name){counterflag++;}
							});
							
							if (counterflag == 0)
							{
								$scope.gridOptions.columnDefs.push({
									name: tmp_name,		// TS-633 STEP-9 PART-2
									displayName:dispName,	
									enableColumnMenu: false ,
									width: wid	,	
									cellTemplate:cellTemp,
									headerCellTemplate:headerTemp,
									pinnedLeft:freezecolumn,
									enableColumnMoving:columnmove,
									fieldtype:fieldtype	,
									fieldname:fieldname,
									pnlid_fid:pnlid_fid,
									type:type,
									/* Start: BG-113 */
									subpanelid: subpanelid,
									isQualitative: isQualitative,
									agefield: agefield
									/* End: BG-113 */
								});													
							}
							//BG-81 : Stop

							}//end if
					}//end for loop	
					
					/*
					TS-633 : START
					Sort column based on fieldorder
					*/
					//console.log($scope.fieldorder);
					//console.log($scope.gridOptions.columnDefs);
					if(fromSavedReport){
						var newColumnDefs = [];
						$scope.fieldorder.forEach(function(e){
							$scope.gridOptions.columnDefs.filter(function(item){
								if(item.subpanelid == "Type1" || item.subpanelid == "Type2"){
									if(e.indexOf(item.name.split(":")[2]) != -1 && e.split('_')[0] + '_' + e.split('_')[2] == item.pnlid_fid){
										var pos = newColumnDefs.map(function(ee) { return ee.pnlid_fid; }).indexOf(item.pnlid_fid);
										if(pos == -1){
											newColumnDefs.push(item);
										}
									}
								} else if(item.subpanelid == "Type3"){
									if(e.split('_').length == 3) {
										// This is current Type3
										if(e.indexOf(item.name.split(":")[2]) != -1 && e.split('_')[0] + '_' + e.split('_')[2] == item.pnlid_fid){
											var pos = newColumnDefs.map(function(ee) { return ee.pnlid_fid; }).indexOf(item.pnlid_fid);
											if(pos == -1){
												newColumnDefs.push(item);
											}
										}
									} else if(e.split('_').length == 4){
										// This is previous Type3
										if (e.indexOf(item.name.split(":")[2]) != -1 && e.split('_')[0] + '_' + e.split('_')[2] + '_' + e.split('_')[3] == item.pnlid_fid){
											var pos = newColumnDefs.map(function(ee) { return ee.pnlid_fid; }).indexOf(item.pnlid_fid);
											if(pos == -1){
												newColumnDefs.push(item);
											}
										}
									}
								} else if(item.fieldtype == "completionrate" || item.fieldtype == "historicalrates") {
									// there can be more than one completionrate and historicalrates with same id. 
									if(item.pnlid_fid.indexOf(e) != -1){
										var pos = newColumnDefs.map(function(ee) { return ee.pnlid_fid; }).indexOf(item.pnlid_fid);
										if(pos == -1){
											newColumnDefs.push(item);
										}
									}
								} else if(e.indexOf(item.pnlid_fid) != -1){
									var pos = newColumnDefs.map(function(ee) { return ee.pnlid_fid; }).indexOf(item.pnlid_fid);
									if(pos == -1){
										newColumnDefs.push(item);
									}
								} else {
									return true;
								}
							});
						});			
						$scope.gridOptions.columnDefs = newColumnDefs;
						$scope.fieldcount = $scope.fieldorder.length;
					}
					
					/*
					TS-633 : END
					*/
				});//end column timeout
				
				var data = [];
				/*MV-2153:Start*/				
				var columnname='';
				/*MV-2153:End*/
				/***** BG-64 : Start *****/
				$timeout( function() {
							
							/* MV-819 : Start */
							var view_data_as_list_array = [];
							if(typeof view_data_as_list != "undefined")
							{
									view_data_as_list = view_data_as_list.substring(1,view_data_as_list.length);
									//console.log(view_data_as_list);
									view_data_as_list_array = view_data_as_list.split("~");
							}	
							/* MV-819 : Stops */	

							//console.log("current_date_decider_flag : "+$scope.current_date_decider_flag +" : "+"historical_date_decider_flag : "+$scope.historical_date_decider_flag);
							for (var rowIndex = 0; rowIndex < rowCount.length; rowIndex++) {
								var row = {};
								for (var colIndex = 0; colIndex < colCount.length; colIndex++) {									
									var val=colCount[colIndex].name;														
								//console.log("val : " + val);
								var panel_type = colCount[colIndex].subpanelname;
								var field_value = rowCount[rowIndex][val];
								/*MV-2153:Start*/
								if(colCount[colIndex].fieldtype=='status'){							
									columnname=colCount[colIndex].fieldtype;
								}
								/*MV-2153:End*/
								var field_value_original = rowCount[rowIndex][val];
								//console.log("[panel_type : "+panel_type+", field_type : "+val+", field_value : "+field_value+"]");
								
								/* MV-819 : Start */
								var boolean_flag_current = false;
								var boolean_flag_previous = false;
								var status_flag_current = "";
								var status_flag_previous = "";
								for(i=0; i<view_data_as_list_array.length;i++)
								{	
										if(view_data_as_list_array[i].split(":")[1] == val)
										{		
												if(val.split("_")[2] == "Previous")
												{
														boolean_flag_previous = true;
														status_flag_previous = view_data_as_list_array[i].split(":")[0];
												}
												else
												{
														boolean_flag_current = true;
														status_flag_current = view_data_as_list_array[i].split(":")[0];
												}
										}
								}
								/* MV-819 : Stops */

								if(panel_type == "Associations3")
								{		
										if(val.indexOf("previous") < 0) //Current Assignment
										{		
												if($scope.current_date_decider_fieldtype == val){
													if($scope.currentStatusList.length == 0){
														$scope.currentStatusList.push({associd : $scope.current_date_decider_fieldtype, flag : $scope.current_decider_flag});
													}
													else{
														var findCounter = 0;
														for(cnt1 = 0; cnt1<$scope.currentStatusList.length ; cnt1++){
																if($scope.currentStatusList[cnt1].associd == $scope.current_date_decider_fieldtype){
																	$scope.currentStatusList[cnt1].flag = $scope.current_decider_flag;
																	findCounter++;
																}
														}
														if(findCounter == 0){
															$scope.currentStatusList.push({associd : $scope.current_date_decider_fieldtype, flag : $scope.current_decider_flag});
														}
													}
												}
												for(cnt2 = 0; cnt2<$scope.currentStatusList.length ; cnt2++)
												{	
													if($scope.currentStatusList[cnt2].associd == val){
														$scope.current_date_decider_flag = $scope.currentStatusList[cnt2].flag;
													}
												}	
												/* MV-819 : Starts */
												if(boolean_flag_current)
												{
													$scope.current_date_decider_flag = status_flag_current;
												}
												/* MV-819 : Stops */
												if($scope.current_date_decider_flag == "remove"){ 
														if(typeof field_value != "undefined" && field_value.length != 0){
																var current_date_array = field_value.split(";; ");
																var only_name_part = "";
																for(counter_i = 0; counter_i < current_date_array.length; counter_i++){
																		var single_row_value = current_date_array[counter_i];
																		if(only_name_part == ""){
																				if(single_row_value.match(/\(([^)]*)\)[^(]*$/) != null){
																					only_name_part = (single_row_value.replace(single_row_value.match(/\(([^)]*)\)[^(]*$/)[0],"")).trim();
																				}
																				else{
																					only_name_part = single_row_value.trim();
																				}
																		}
																		else
																		{	
																				if(single_row_value.match(/\(([^)]*)\)[^(]*$/) != null){
																					only_name_part = only_name_part.trim() + ";; " + (single_row_value.replace(single_row_value.match(/\(([^)]*)\)[^(]*$/)[0],"")).trim();
																				}
																				else{
																					only_name_part = single_row_value.trim();
																				}
																		}
																}
																field_value = only_name_part;
														}	
												}
												else if($scope.current_date_decider_flag == "add")
												{	
													field_value = field_value_original;
													/* MV-819 : Start */
													if(boolean_flag_current == false && $scope.current_date_decider_flag.length > 0)
													{
														$scope.current_date_decider_flag ="remove";	
													}
													/* MV-819 : Stops */
												}
										}//End Of Current
										else if(val.indexOf("previous") > 0) //Previous Assignment
										{		
												if($scope.historical_date_decider_fieldtype == val){
													if($scope.previousStatusList.length == 0){
														$scope.previousStatusList.push({associd : $scope.historical_date_decider_fieldtype, flag : $scope.historical_decider_flag});
													}
													else{
														var findPCounter = 0;
														for(cnt3 = 0; cnt3<$scope.previousStatusList.length ; cnt3++){
																if($scope.previousStatusList[cnt3].associd == $scope.historical_date_decider_fieldtype){
																	$scope.previousStatusList[cnt3].flag = $scope.historical_decider_flag;
																	findPCounter++;
																}
														}
														if(findPCounter == 0){
															$scope.previousStatusList.push({associd : $scope.historical_date_decider_fieldtype, flag : $scope.historical_decider_flag});
														}
													}
												}
												for(cnt4 = 0; cnt4<$scope.previousStatusList.length ; cnt4++)
												{	
													if($scope.previousStatusList[cnt4].associd == val){
														$scope.historical_date_decider_flag = $scope.previousStatusList[cnt4].flag;
													}
												}	
												/* MV-819 : Start */
												if(boolean_flag_previous)
												{
													$scope.historical_date_decider_flag = status_flag_previous;
												}
												/* MV-819 : Stops */
												if(typeof field_value != "undefined" && $scope.historical_date_decider_flag == "remove"){													
													if(field_value.length != 0){
															var previous_date_array = field_value.split(";; ");
															var only_name_part = "";
															for(counter_i = 0; counter_i < previous_date_array.length; counter_i++){
																	var single_row_value = previous_date_array[counter_i];
																	if(only_name_part == ""){
																			if(single_row_value.match(/\(([^)]*)\)[^(]*$/) != null){
																				only_name_part = (single_row_value.replace(single_row_value.match(/\(([^)]*)\)[^(]*$/)[0],"")).trim();
																			}
																			else{
																				only_name_part = single_row_value.trim();
																			}
																	}
																	else
																	{	
																			if(single_row_value.match(/\(([^)]*)\)[^(]*$/) != null){
																				only_name_part = only_name_part.trim() + ";; " + (single_row_value.replace(single_row_value.match(/\(([^)]*)\)[^(]*$/)[0],"")).trim();
																			}
																			else{
																				only_name_part = single_row_value.trim();
																			}
																	}
															}
															field_value = only_name_part;
													}
												}
												else if($scope.historical_date_decider_flag == "add")
												{	
													field_value = field_value_original;
													/* MV-819 : Start */
													if(boolean_flag_previous == false && $scope.historical_date_decider_flag.length > 0)
													{
														$scope.historical_date_decider_flag = "remove";
													}
													/* MV-819 : Stops */
												}	
										}//End Of Previous
								}
								if (typeof field_value == "string") {
									field_value = field_value.toString().replace(/amp;/g,'').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"');									
									field_value = field_value.toString().replace(/\$comma\$/g,",").replace(/\$openbraces\$/g,"(");//BG-97 Replace Comma
								}
							/* TS-633 : START */
							// TS-633 STEP-9 PART-3
							var tempTimesheet = colCount[colIndex].panelid;
							if(tempTimesheet == 'TimeSheetSetting'){
								if ((colCount[colIndex].fieldtype == 'approvedhrs' || colCount[colIndex].fieldtype == 'pendinghrs' || colCount[colIndex].fieldtype == 'disallowedhrs' || colCount[colIndex].fieldtype == 'submittedHrs') && (field_value == null || field_value == "")) {//TS-1112 TS-1395/phase-2
									field_value = "";
								}
								row[colCount[colIndex].displayName.toString().replace(/\./g,' ')+':'+colCount[colIndex].name+':'+colCount[colIndex].id] = field_value; //BG-64 : rowCount[rowIndex][val] replaced by field_value 	
							} else {
								row[colCount[colIndex].displayName.toString().replace(/\./g,' ')+':'+colCount[colIndex].panelid+':'+colCount[colIndex].id] = field_value; //BG-64 : rowCount[rowIndex][val] replaced by field_value 												
							}
							/* TS-633 : END */												
							row['userid']=rowCount[rowIndex].userid;
							row['cellclass']=rowCount[rowIndex].classname;																	
						}//inner for loop
					/* Start: BG-113 */
					var volunId = row['userid'];					
					if(volunId != '' && totalVolunCount.indexOf(volunId) == -1) {
						totalVolunCount.push(volunId);
					}					
					/* End: BG-113 */
					data.push(row);								
					}//for loop
					$j11('#totalvolunteercount').html('Total ' + volunteerAliasPlural + ': ' + totalVolunCount.length); // BG-113
				});//End Row Timeout
				$scope.gridOptions.data = data;	
				/*MV-2153:Start(Block will execute when column='status' )*/
				setTimeout(function(){
													
					if(sortcolumn=='status' && sorttype=='desc'){	
								
						$j('#' + columnname).removeClass('ui-grid-icon-blank');
						$j('#' + columnname).removeClass('ui-grid-sort-asc');
						$j('#' + columnname).addClass('ui-grid-sort-desc');
					}else if(sortcolumn=='status' && sorttype=='asc'){
						
						$j('#' + columnname).removeClass('ui-grid-icon-blank');
						$j('#' + columnname).removeClass('ui-grid-sort-desc');
						$j('#' + columnname).addClass('ui-grid-sort-asc');
					}else if(sortcolumn=='status' && sorttype==''){
						
						$j('#' + columnname).removeClass('ui-grid-sort-desc');
						$j('#' + columnname).removeClass('ui-grid-sort-asc');
						$j('#' + columnname).addClass('ui-grid-icon-blank');
					}
				}, 100);
				/*MV-2153:End*/
				hideLoadingOverlay();
	};
	/***** BG-64 : Stops *****/

	$scope.clearfilters = function (rel) {
		$j('.errormsg_class').css('display', 'none');//ASSNS-656
		var programid = $j('#programid').val();
		var userid = $j('#userid').val();
		var usertype = $j('#usertype').val();
		showLoadingOverlay();
		var filtercount = parseInt($j('.filtercount').val());		
		for(i=2;i<=filtercount;i++) {
			$j('#subfilter_' + i).remove();
		}
		$j('.filtercount').val('1');
		$j('#filtervaluepattern').val('');
		$j('.filterpattern').css('display','none');
		$j('#clearfilter').css('display','none');
		$j('#btn_apply_filter').prop("disabled", true)	
		$j('.filtercount_1').addClass('padding-left-10');
		$j('.filtercount_1').html('');	
		$j('.filtercount_1').css('display','none');
		$j('.sel_action_1').remove('');
		$j('.sel_field_1').addClass('tmsht-widt-215');
		$j('.sel_field_1').removeClass('tmsht-widt-134');
		$j('.filtervalue_1').addClass('tmsht-widt-161');
		$j('.filtervalue_1').removeClass('tmsht-widt-134');
		$j('.filtervalue_1').val('');
		$j('.search_magnifier_1').hide();
		$j('.ffilterby').removeClass('text-right');
		$j('.fOperator').removeClass('text-right');
		$j('.fValue').removeClass('text-right');									
		$j('.filterbylable').removeClass('margin-right-63');
		$j('.operatorlabel').removeClass('margin-right-63');
		$j('.valuelabel').removeClass('margin-right-102');	
		$j('.btn_add_filter_1').html('Add');
		$j('.btn_cancel_filter_1').html('Cancel');	
		/* Start: BG-112 */
		$j1('.sel_field_1').select2('destroy');	
		$j('.filterOperator_1').html('');		
		$j('.sel_field_1 option[value="0"]').attr('selected', true);
		$j('.sel_field_1').trigger("change");	
		if($j1('#archived_fields').html() === 'Show Archived Fields') {
			$j1('.HideArchivedField').attr('disabled',true);
			$j1(".sel_field").select2({
			   	templateResult: function(option, container) {
					var myOption = $j1('.sel_field').find('option[value="' + option.id + '"]');
					if(typeof option.id == "string" && (option.id.indexOf("timesheetTemplate") != -1 || option.id.indexOf("ServiceTerms") != -1 || option.id.indexOf("approvedhrs") != -1
					|| option.id.indexOf("pendingHrs") != -1 || option.id.indexOf("disallowedhrs") != -1 || option.id.indexOf("FirstDate") != -1 || option.id.indexOf("RecentDate") != -1 || option.id.indexOf("TSPersonalStartDate") != -1 || option.id.indexOf("TSPersonalEndDate") != -1 //TS-1223/TS-1341 TS-1112
					|| option.id.indexOf("BlackoutDates") != -1 || option.id.indexOf("TSStatus") != -1 || option.id.indexOf("TSTimeOffCalendar") != -1 || option.id.indexOf("submittedHrs") != -1)) {//TS-1395/phase-2
						if(myOption.hasClass("timesheetDetailsOptions") && !$j1(container).hasClass("toggle-display-show-" + $j1(option.element).val().split("_")[1])){
							var templateid = $j1(option.element).val().split("_")[1];
							if(templateid != undefined && $j1("#timesheetTemplate_" + templateid).prop("checked")){
								$j1(container).addClass('toggle-display-show-' + templateid)
							} else if(templateid != undefined) {
								$j1(container).addClass('toggle-display-show-' + templateid + ' toggle-display-' + templateid);
							}
						}
				}
				  if (myOption.css('display') != 'none') {
						return option.text;
				  }
				  return false;
			   }
			});
		} else {
			$j1('.HideArchivedField').attr('disabled',false);
			$j1('.sel_field_1').select2();
		}
		/* End: BG-112 */		
		
		//On Clicking "Clear Filter" Link Error Fix : Code Replaced By Function - "$scope.functionA(false);"  
		/*
		var data =[];
		var fieldarr = [];		
		var associationarr = [];
		var rosterOrganization = $j('.rosterOrganization').val();
		var arrangefieldsby = $j('.arrangefields:checked').val();			
		data.push({			
			"rosterOrganization": rosterOrganization
		});
		if(rosterOrganization == 'custom') {
			var customfields = $j('.customfields').val();
			var customfieldvalue = $j('.customfieldvalue').val();
			data.push({				
				"customfields": customfields
			});
			data.push({			
				"customfieldvalue": customfieldvalue
			});
		} else if(rosterOrganization == 'volunteer') {
			var volunlist = $j('.volunlist').val();
			data.push({			
				"volunlist": volunlist
			});
		} else if(rosterOrganization == 'association') {
			var associationlist = $j('.associationlist').val();
			data.push({				
				"associationlist": associationlist
			});
		} else if(rosterOrganization == 'site') {
			var sitelist = $j('.sitelist').val();
			data.push({				
				"sitelist": sitelist
			});
		}	
		$j('input[name="childpanelitem"]:checked').each(function(e,i){
			var field = $j(this).attr('id');			
			var fieldId = $j(this).val();
			fieldarr.push(fieldId);							
		});	
		
		data.push({		
			"volunteerfields": fieldarr
		});
		$j('input[name="childassociationitem"]:checked').each(function(e,i){
			var field = $j(this).attr('id');
			var fieldId = $j(this).val();
			associationarr.push(fieldId);			
		});	
		data.push({		
			"associationarr": associationarr
		});						
		var filter = "";
		var paneltype = "";
		var fieldtype = "";
		var operator = "";
		var filtervalue = "";
		var logical = " ";		
		data.push({			
				"filter": filter			
		});
		data.push({			
				"paneltype": paneltype
		});
		data.push({				
				"fieldtype": fieldtype
		});
		data.push({			
				"operator": operator
		});
		data.push({				
				"filtervalue": filtervalue
		});
		data.push({				
				"logical": logical
		});		
		data.push({		  
		  "arrangefieldsby": arrangefieldsby
		 });	
		data.push({		  
		  "programid": programid
		 });
		 data.push({		  
		  "userid": userid
		 });
		 data.push({
			"filtervaluepattern": filtervaluepattern
		});
		 data.push({		  
		  "currentusertype": usertype
		 });
		$scope.loadResponse(data);
		*/
    iconEnable = 2; //MV-862
		$j('#btn_apply_filter').prop("disabled", true); // Sitemanage-285
		$j('#filterApplied').val('0');
		$scope.functionA(false, false, false);
	};
	
	$scope.cellClickedSort = function(columnname){
		showLoadingOverlay();
		$j('#' + sortcolumn).removeClass('ui-grid-icon-blank');
		$j('#' + sortcolumn).removeClass('ui-grid-sort-asc');
		$j('#' + sortcolumn).removeClass('ui-grid-sort-desc');
		if(sortcolumn != columnname) {
			sorttype = '';	
		}
		sortcolumn = columnname;		
		if(sorttype == 'asc') {	
			/*MV-2153:Start*/		
			if(columnname=='status'){
				sorttype = '';
			}else{
				sorttype = 'desc';
				$j('#' + columnname).removeClass('ui-grid-icon-blank');
				$j('#' + columnname).removeClass('ui-grid-sort-asc');
				$j('#' + columnname).addClass('ui-grid-sort-desc');
			}
			/*MV-2153:End*/			
		} else if(sorttype == 'desc') {
			/*MV-2153:Start*/		
			if(columnname=='status'){
				sorttype = 'asc';
			}else{
				sorttype = '';
				$j('#' + columnname).removeClass('ui-grid-sort-desc');
				$j('#' + columnname).removeClass('ui-grid-sort-asc');
				$j('#' + columnname).addClass('ui-grid-icon-blank');
			}
			/*MV-2153:End*/			
		} else {
			/*MV-2153:Start*/			
			if(columnname=='status'){
				sorttype = 'desc';				
			}else{
				sorttype = 'asc';
				$j('#' + columnname).removeClass('ui-grid-icon-blank');
				$j('#' + columnname).removeClass('ui-grid-sort-desc');
				$j('#' + columnname).addClass('ui-grid-sort-asc');
			}
			/*MV-2153:End*/			
		}		
		//$scope.functionA(false, false, false);	
		var scope = angular.element(document.getElementById("postservice")).scope();		
		scope.getSelectedFieldData('sortField',0,'');
		
	}
	
	$scope.applyfilter = function(){	
		//Start : mv-693
		var comcount=0;
		var miscount=0;
		$j("select[name=sel_field] :selected").map(function(i, v) {	
			var reltext=$j(v).attr('rel');				
			var i=i+1;		
			if(reltext=='completed' && $j('#subfilter_'+i+' .btn_add_filter_'+i).text()=='Edit' ){					
				comcount=comcount+1;
			}else if(reltext=='missed' && $j('#subfilter_'+i+' .btn_add_filter_'+i).text()=='Edit'){				
				miscount=miscount+1;
			}
		});	
		if(comcount>0 )
			$j('#applyfilterforcompleted').val('yes');
		if(miscount > 0)
			$j('#applyfilterformissed').val('yes');
		//End :mv-693
		/*var validationstatus = $scope.savePattern();
		if(validationstatus){
			var filtercount = parseInt($j('.filtercount').val());		
			for(var rel=1;rel < filtercount; rel++) {
				var button = $j('.btn_add_filter_' + rel).html();
				var filterby = $j('option:selected', '.sel_field_' + rel).val();
				var filterbySelected = $j('option:selected', '.sel_field_' + rel).attr('rel');	//added for mv-693				
				var fieldvalueclass = 'btn_add_filter_' + rel;
				var operatorType = $j('.filterOperator_' + rel + ' option:selected').text();
				var fieldvaluefilter = 	$j('.filtervalue_' + rel).val();
				if(filterby.indexOf("ServiceTerms") != -1 || filterby.indexOf("approvedhrs") != -1 || filterby.indexOf("pendingHrs") != -1
				|| filterby.indexOf("FirstDate") != -1 || filterby.indexOf("RecentDate") != -1 || filterby.indexOf("BlackoutDates") != -1){
					filterby = filterby.split("_")[1];
				}
				var msg = "";
				if(filterby == 0) {
					msg += "Please select filter by.\n";		
				} 	
				if(operatorType != "is empty" && operatorType != "isn't empty" && operatorType != "today" && operatorType != "tomorrow" && operatorType != "tomorrow onwards"  && operatorType != "yesterday" && operatorType != "until yesterday" && operatorType != "last month"  && operatorType != "current month" && operatorType != "next month"  && operatorType != "last week" && operatorType != "current week" && operatorType != "next week" && operatorType != "is fully executed" && operatorType != "is waiting for supervisor signature" && operatorType != "is waiting for director signature" && operatorType != "is waiting for " + volunteerAliasLcase + " signature" && operatorType != "has no signatures") {
						if($j('option:selected', '.sel_field_' + rel).attr('rel') == 'date' || ($j('option:selected', '.sel_field_' + rel).attr('rel') != undefined &&  ($j('option:selected', '.sel_field_' + rel).attr('rel').split('_')[0] == 'BlackoutDates'
						|| $j('option:selected', '.sel_field_' + rel).attr('rel').split('_')[0] == 'FirstDates' || $j('option:selected', '.sel_field_' + rel).attr('rel').split('_')[0] == 'RecentDate'))) {
							if((operatorType == "between" || operatorType == "not between") && (($j('#datelink1_' + rel).val() != 'undefined' && $j('#datelink1_' + rel).val() == "") || ($j('#datelink2_' + rel).val() != 'undefined' && $j('#datelink2_' + rel).val() == ""))) {
								msg += "Please provide both between date filter value.";	
							} else {
								if(typeof fieldvaluefilter != 'undefined' && fieldvaluefilter.trim() == "") {
									msg += "Please provide date filter value.";
								}
							}			
						}else {							
							if((filterbySelected=='completed' || filterbySelected=='missed' || filterbySelected=='completionrate' || filterbySelected=='historicalrates') && fieldvaluefilter!='' && /^[0-9\s]*$/.test(fieldvaluefilter)==false){	//added for mv-693	
								 //if the letter is not digit then display error and don't type anything					
								//display error message						
								msg +='Please provide number filter value.';							 
							}
							else if(typeof fieldvaluefilter != 'undefined' && fieldvaluefilter.trim() == "") {
								msg += "Please provide filter value.";
							}
						}	
				}
				if(msg != "") {
					break;
				}			
			}
			if(msg != "") {
				alert(msg);			
			} else {
				$j('.appliedfiltercount').val(filtercount);
				//showLoadingOverlay();
				if($j('select[name="sel_action"]').prop("disabled") == false)
				$scope.updateFilterPattern();
				fromApplyfilterPublic = true
				//$scope.functionA(false, false, true); // Volunteer Export Optimization
				$j('#filterApplied').val('1');
				$scope.getSelectedFieldData('filterField',0,'');
				//hideLoadingOverlay();
			}
		}*/
		/* Start :: MV-1823 */
		var msg = validateFilters();
		var filtercount = parseInt($j('.filtercount').val());
		if(msg != "" && msg == 'invalid pattern') {
			return false;
		} else if (msg != "" && msg != 'invalid pattern') {
			alert(msg);
			return false;
		} else {
		/* End :: MV-1823 */
			$j('.appliedfiltercount').val(filtercount);
			//showLoadingOverlay();
			if($j('select[name="sel_action"]').prop("disabled") == false)
			$scope.updateFilterPattern();
			fromApplyfilterPublic = true
			//$scope.functionA(false, false, true); // Volunteer Export Optimization
			$j('#filterApplied').val('1');
			$scope.getSelectedFieldData('filterField',0,'');
			//hideLoadingOverlay();
		}
    /* End :: MV-1823 */
	}
	
	$scope.updateFilterPattern = function(){
		var filtervaluepattern = "(1)";
		var filtercount=$j('.filtercount').val();
		for (i = 2; i <filtercount; i++){
			var filterjoin = $j('option:selected', '.sel_action_' + i).text();
			filtervaluepattern = "(" + filtervaluepattern;
			filtervaluepattern+=  " " + filterjoin + " " + i + ")";			 
		}		
		$j11('#filtervaluepattern').val(filtervaluepattern);
		$j11('#patternforrestore').val(filtervaluepattern);
	}
	
	$scope.resetTable=function(){
	  var columnDefs = $scope.gridOptions.columnDefs;
	  var columnDefsBak = columnDefs.slice();
	  columnDefs.length = 0;
	  $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN );
	  columnDefs.push.apply(columnDefs, columnDefsBak)
	  $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN );
	}
/* MV-862:Start */
$scope.passwordSetupPopup = function() {
	var postData = [];
	postData.push({
		"name": "sendPasswordUserIds",
		"value": $j('#resultUserIdList').val()
	});
	var title = "Send Password Setup E-mail to " +volunteerAliasPlural+ " Without Passwords";

	$j.ajax({
		type: "post",
		url: "index.cfm?event=user.ShowPasswordResetWindow&value=sendmail&pagereq=volunteers&isSetup=passwordMail",
		data: postData,
		success: function(resp) {   
			ColdFusion.Window.create("PasswordReset",title,"",{modal:true,width:420,height:260,center:true,draggable:false,resizable:false});
			$j('#PasswordReset-body').html(resp);
			ColdFusion.Window.onHide("PasswordReset",function(){destroyWindow('PasswordReset')});	

			myWindow = ColdFusion.Window.getWindowObject('PasswordReset');
			popupID = $j11(myWindow).attr("divid");		
			$j11('#'+popupID).removeClass("x-hidden");	
			$j11('#'+popupID).css({transform: "translate(0%, -50%)",left:"0%",right:"0%",margin:"0 auto" ,top:"50%" , position:"fixed" ,'border-left':"3px solid #3266CC",'border-right':"3px solid #3266CC",'border-bottom':"3px solid #3266CC"});
			$j11(document).find('.x-shadow').css('display','none');
		},
		error: function(resp) {						
		}
	});
}
/* MV-862:End */
	$scope.changeSelectText = function(panelid,subpanelid) {
		var selectallpanelclass = 'userAssignPanel_' + panelid + '_Select';	
		var selectallsubpanelclass = 'userAssignPanel_' + subpanelid + '_SelectSubPanel';	
		var childid= 'userAssignPanel_' + panelid + '_Select_Child';
		var subchildid= 'userAssignPanel_' + subpanelid + '_Select_SubChild';	
		var allfieldcount = 0;
		var panelfieldcount = 0;
		var subpanelfieldcount = 0;	
		
		$j('.childpanelitem').each(function(e,i) {
			if($j(this).prop("checked") == false && $j(this).closest('.columngroup').css('display') != 'none' && $j(this).hasClass('completionratecheckbox') == false && $j(this).hasClass('missedratecheckbox') == false) {
				allfieldcount++;
				//break;
			}
		});		
		
		if(allfieldcount > 0) {
			$j('#userAssign_Panel_Select1').html("Select All Fields");
			//$j('.selectall_additionaltext').css('display','none');
		} else {
			$j('#userAssign_Panel_Select1').html("Select None");
			//$j('.selectall_additionaltext').css('display','block');
		}
		
		$j('.' + childid).each(function(e,i) {
			if($j(this).prop("checked") == false && $j(this).closest('.columngroup').css('display') != 'none') {
				panelfieldcount++;		
				//break;
			}
		});
		
		$j('.' + subchildid).each(function(e,i) {
			if($j(this).prop("checked") == false && $j(this).closest('.columngroup').css('display') != 'none') {				
				subpanelfieldcount++;				
				//break;
			}
		});		
		
		if (panelfieldcount == 0) {					
			$j('.' + selectallpanelclass).html("Select None");	
		} else if(panelfieldcount > 0 || subpanelfieldcount > 0) {
			if( $j('.' + selectallpanelclass).attr('id') == 'association_select') {
				$j('#association_select').html("Select All Associations");
			} else {
				$j('.' + selectallpanelclass).html("Select All");
			}
		}
		
		if(subpanelfieldcount > 0) {								
			$j('.' + selectallsubpanelclass).html("Select All");	
		} else {
			$j('.' + selectallsubpanelclass).html("Select None");	
		}
	}
	$scope.htmlEncode=function(value){	
	  //create a in-memory div, set it's inner text(which jQuery automatically encodes)
	  //then grab the encoded contents back out.  The div never exists on the page.
	  return $j('<div/>').text(value).html();
	}
	$scope.htmlDecode=function(value){	
	  return $j('<div/>').html(value).text();
	}
	
	$scope.downloadSelectedReport=function() { 
		$j('#userinputfilename').val('');
		$j('#userinputfilename_cnt').val('80');
		//angular.element(document.getElementById('postserviceCtrl')).scope().displayField(1);
		$scope.displayField(1);
		//$j(".DisplayFields").click();		
	}
	
	$scope.exportExcel= function(){	
		var wb = new ExcelJS.Workbook();
		var ws = wb.addWorksheet('Export');
		var origin   = window.location.origin;
		
		// Header
		var utc =  moment.utc(new Date());		
		var pst = moment.tz(utc,'America/Los_Angeles');
		var fileDate = pst.format('MMMM_D_YYYY_h_mmA');
		  
		row1 = ws.getRow(1);
		row1.getCell(1).value = volunteerAliasPlural + ' Export Report (' + fileDate + ' )';//MV-778 + BG-82
		row1.font = { name: 'Arial', size: 10 };
		var com_his_count=1;
		saveOrder();	
	
		if($scope.removeFieldOrder.length > 0 )
		{
			$scope.removeFieldOrder.each(function(e){				
				var tempindex = $scope.excelfieldorder.indexOf(e);				
				if(tempindex != -1){
					$scope.excelfieldorder.splice(tempindex,1);
				}else{					
					do {				
						var val=e+'_'+com_his_count;						
						var tempindex1 = $scope.excelfieldorder.indexOf(val);				
						if(tempindex1 != -1){
							$scope.excelfieldorder.splice(tempindex1,1);
						}else{					
							break;
						}
						com_his_count++;
					}
					while (com_his_count>0);
				}
			});
			tableorder=$scope.excelfieldorder;			
		}
		else
		{				
			tableorder=$scope.excelfieldorder;
		}	
		
		var fileorder=[];
			
		var cellcount=1;
		var completionratecount=1;
		var currentuserid = "";	

		/* Start: BG-113 */
		var cellNumber;
		var columnType;
		var colname;
		/* End: BG-113 */
		//tableorder.forEach(ord => {						
		tableorder.forEach(function(ord) {						
			//write column of excel
			row3 = ws.getRow(3);		
			//$scope.gridOptions.columnDefs.map( (head, index) => {					
			$scope.gridOptions.columnDefs.map( function(head, index) {				
				pnlid_fid=head.pnlid_fid;			
				if(ord==pnlid_fid){					
					asscol='';
					try{						
						if(head.displayName.indexOf(':') > 0){
							asscol=head.displayName.split(':')[1];								
						}
					}catch(err){				
						asscol='';
					}
					cellName = head.fieldname;
					
					if(head.fieldtype.toLowerCase()=='completionrate' || head.fieldtype.toLowerCase()=='historicalrates'){	
						cellNumber = cellcount;	
						//Apply If condition for CF18-30					
						if(head.name.split(':').length==4){
							completionratedate=head.name.split(':')[1];	
							cellwidth=head.displayName.length+cellName.length+completionratedate.length;		 
							ws.getColumn(cellNumber).width = cellwidth+2;
							row3.getCell(cellNumber).value = {
								richText: [
									{ font: { name: 'Arial', size: 10, bold: true }, text: head.displayName },
									{ font: { name: 'Arial', size: 10, color: { argb: '000366d6' } }, text: ': ' + cellName + ': '+completionratedate},
								]
							};
						}else{
							cellwidth=head.displayName.length+cellName.length;		 
							ws.getColumn(cellNumber).width = cellwidth+2;
							row3.getCell(cellNumber).value = {
								richText: [
									{ font: { name: 'Arial', size: 10, bold: true }, text: head.displayName },
									{ font: { name: 'Arial', size: 10, color: { argb: '000366d6' } }, text: ': ' + cellName},
								]
							};
						}
						index=cellNumber-1;
						cellcount=index+1;
						cellcount=cellcount+1;						
					}else if(head.fieldtype.toLowerCase()=='completed' || head.fieldtype.toLowerCase()=='missed'){	
						cellNumber = cellcount;								
						completionratedate=head.name.split(':')[1];													
						cellwidth=head.displayName.length+cellName.length;						
						ws.getColumn(cellNumber).width =cellwidth;
						row3.getCell(cellNumber).value = {
							richText: [
								{ font: { name: 'Arial', size: 10, bold: true }, text: head.displayName },
								{ font: { name: 'Arial', size: 10, color: { argb: '000366d6' } }, text: ': ' + cellName},
							]
						};
						index=cellNumber-1;
						cellcount=index+1;
						cellcount=cellcount+1;						
					}else if(asscol.trim()=='Associations1' || asscol.trim()=='Associations2'){
						cellNumber = cellcount;							
						//var assname=head.displayName.split(":")[0];
						if(asscol.trim()=='Associations1') {
							assname='Type 1 Associations';
						} else {
							assname='Type 2 Associations';
						}
						cellwidth=assname.trim().length + cellName.length ;		 
						ws.getColumn(cellNumber).width = cellwidth+2;
						row3.getCell(cellNumber).value = {
							richText: [
							  { font: { name: 'Arial', size: 10, bold: true }, text: assname },
							  { font: { name: 'Arial', size: 10, color: { argb: '000366d6' } }, text: ': ' + cellName },
							]
						};
						index=cellNumber-1;
						cellcount=index+1;
						cellcount=cellcount+1;							
					}else if(asscol.trim()=='Associations3' ){						
						cellNumber = cellcount;							
						//var assname=head.displayName.split(":")[0];
						assname='Groups';
						cellwidth=assname.length + cellName.length ;		 
						ws.getColumn(cellNumber).width = cellwidth+2;
						row3.getCell(cellNumber).value = {
							richText: [
							  { font: { name: 'Arial', size: 10, bold: true }, text: assname },
							  { font: { name: 'Arial', size: 10, color: { argb: '000366d6' } }, text: ': ' + cellName },
							]
						};
						index=cellNumber-1;
						cellcount=index+1;
						cellcount=cellcount+1;
					/*MV-2153:Start*/
					}else if(head.fieldtype.toLowerCase()=='surveyparticipation'){						
						cellNumber = cellcount;		
						//console.log(cellName)
						//console.log(cellName.replace('Survey',surveyAlias));
						cellName=cellName.replace('Survey',surveyAlias);
						cellwidth=head.displayName.length + cellName.length;		 
						ws.getColumn(cellNumber).width = cellwidth +2;	
						row3.getCell(cellNumber).value = {
							richText: [
							  { font: { name: 'Arial', size: 10, bold: true }, text: head.displayName },
							  { font: { name: 'Arial', size: 10, color: { argb: '000366d6' } }, text: ': ' + cellName },
							]
						};
						index=cellNumber-1;
						cellcount=index+1;
						cellcount=cellcount+1;	
					/*MV-2153:End*/
					}else{						
						if(head.fieldtype.toLowerCase()=='fileattachment' || head.fieldtype.toLowerCase()=='photo' || head.fieldtype.toLowerCase()=='signdocument'){
							fileorder.push(pnlid_fid+':'+cellcount);
							
						}
						cellNumber = cellcount;							
						cellwidth=head.displayName.length + cellName.length;		 
						ws.getColumn(cellNumber).width = cellwidth +2;						
						row3.getCell(cellNumber).value = {
							richText: [
							  { font: { name: 'Arial', size: 10, bold: true }, text: head.displayName },
							  { font: { name: 'Arial', size: 10, color: { argb: '000366d6' } }, text: ': ' + cellName },
							]
						};						
						index=cellNumber-1;
						cellcount=index+1;
						cellcount=cellcount+1;	
					}					
				}				
			})					
		})
		//write header download zip link in excel			
		var row4count=0
		row4 = ws.getRow(4);	
		var flag=false;	
		//tableorder.forEach(ord => {	
		tableorder.forEach(function(ord) {	
			row4count=row4count+1;
			findex=0;
			
				for (var i = 0; i < $scope.gridOptions.columnDefs.length; i++) {
					var pnlid_fid=$scope.gridOptions.columnDefs[i].pnlid_fid;					
					if(ord==pnlid_fid){
						flag=false; // MV-1943	
						if($scope.gridOptions.columnDefs[i].fieldtype=='fileattachment' || $scope.gridOptions.columnDefs[i].fieldtype=='photo' || $scope.gridOptions.columnDefs[i].fieldtype=='signdocument'){		
							colname=$scope.gridOptions.columnDefs[i].name;
							columnType =$scope.gridOptions.columnDefs[i].fieldtype;	
							/* Start: MV-893 */
							if($scope.gridOptions.columnDefs[i].fieldtype=='signdocument') {								
								for (var j = 0; j < $scope.gridOptions.data.length; j++) {									
									/* Start: MV-2064 */
									var signenowHtml=$scope.gridOptions.data[j][colname];
									if(signenowHtml.indexOf('<') != -1 && signenowHtml.indexOf('>') != -1) {
										var txtsplic1 = signenowHtml.split('>');						
										var len = txtsplic1[1].indexOf('<');										
										signenowHtml = txtsplic1[1].substring(0,len);
									}
									/* End: MV-2064 */
									if($scope.gridOptions.data[j][colname]!='' && $scope.gridOptions.data[j][colname]!='Waiting for director signature' && $scope.gridOptions.data[j][colname]!='Waiting for ' + lcase_siteAlias + ' supervisor signature' && $scope.gridOptions.data[j][colname]!="Waiting for " + volunteerAliasLcase + " signature" && $scope.gridOptions.data[j][colname]!="has no signatures" && signenowHtml!="Upload a signed document"){//MV-2064
										flag=true;
										downloadZipRow = 1; // MV-1943	
										break;
									}
								}
							} else {								
								for (var j = 0; j < $scope.gridOptions.data.length; j++) {
									if($scope.gridOptions.data[j][colname]!=''){
										flag=true;
										downloadZipRow = 1; // MV-1943	
										break;
									}
								}	
							}
							/* End: MV-893 */
							if(flag){
								//fileorder.forEach(ord1 => {
								fileorder.forEach(function(ord1) {
									if(ord1.split(':')[0]==pnlid_fid)
										findex=ord1.split(':')[1];
								})							
								fileIndex = parseInt(findex);									
								pid=$j("#programid").val();	
								uid=$j("#userid").val();								
								pnlid=pnlid_fid.split('_')[0].trim();
								fid=pnlid_fid.split('_')[1].trim();
								/* Start: MV-893 */
								if($scope.gridOptions.columnDefs[i].fieldtype=='signdocument') {
									mainhyperlinkurl=origin+"/index.cfm?event=user.downloadsignedfilezip&prg="+pid+"&usr="+uid+"&field="+fid+"&userlistid="+userlistid+"&pnl="+pnlid+"&fieldtype="+columnType;			
								} else {
									mainhyperlinkurl=origin+"/index.cfm?event=user.downloadfilezip&prg="+pid+"&usr="+uid+"&field="+fid+"&userlistid="+userlistid+"&pnl="+pnlid+"&fieldtype="+columnType;			
								}
								/* End: MV-893 */
								
								row4.getCell(fileIndex).value = { formula:'HYPERLINK("' + mainhyperlinkurl + '","Download.Zip")' };
								row4.getCell(fileIndex).font = { name: 'Arial', size: 10, underline: 'single', color: { argb: '000366d6' } };
							}
						}
					}
				}
			})			

			/* Start: BG-113 */
			var cellValuesArray = [[]];
			var volunteersCount = 0;
			var cellNumberArray = [];
			var cellValuesTypeArray = [];
			var objectValues = {};
			var rosterOrganization = $j('.rosterOrganization').val();
			/* End: BG-113 */
			var cellFieldTypeArray = []; // BG-209
			// write Data in excel
			ws.addRows($scope.gridOptions.data);
			var visibleRows=$scope.gridApi.core.getVisibleRows();
			volunteersCount = visibleRows.length; // BG-113
			$scope.resetfieldorder();
			/* MV-872 */
			/*var flag=0;
			for (var gridindex = 0; gridindex < $scope.gridOptions.columnDefs.length; gridindex++) {					
				//console.log('FieldType: ' +$scope.gridOptions.columnDefs[gridindex].fieldtype);				
				//if($scope.gridOptions.columnDefs[gridindex].pnlid_fid === $scope.fieldorder[gridindex] && ($scope.gridOptions.columnDefs[gridindex].fieldtype === 'fileattachment' || $scope.gridOptions.columnDefs[gridindex].fieldtype === 'photo' || $scope.gridOptions.columnDefs[gridindex].fieldtype === 'signdocument')) { //MV-1344 - Commented this line and added below
				if(($scope.gridOptions.columnDefs[gridindex].fieldtype === 'fileattachment' || $scope.gridOptions.columnDefs[gridindex].fieldtype === 'photo' || $scope.gridOptions.columnDefs[gridindex].fieldtype === 'signdocument')) {
						flag++;
						break;
				}
			}*/
			/* Mv-872 */			
			//alert($scope.gridOptions.columnDefs.length)
			for(l=0;l<visibleRows.length;l++){	
				
                 /* MV-872 */				 	
					if(downloadZipRow == 1){ // MV-1943
						rowIndex = l + 5;
					}
					else {
						rowIndex = l + 4;
					}
				 
				
				row = ws.getRow(rowIndex);
				var rowdatacount=1;
				var completionratecount=1;
				//tableorder.forEach(ord => {	
				tableorder.forEach(function(ord) {	
					/* Start: BG-113 */						
					if(cellNumberArray.indexOf(rowdatacount) == -1) {
						cellValuesArray[rowdatacount] = [];
						cellNumberArray.push(rowdatacount);						
					}
					/* End: BG-113 */											
					//$scope.gridOptions.columnDefs.map((head, index) => {						
					$scope.gridOptions.columnDefs.map(function(head, index) {						
						var pnlid_fid=head.pnlid_fid;
						var cellisQualitative = head.isQualitative; // BG-113						
						var agefield = head.agefield; // BG-113											
						if(ord==pnlid_fid){
							cellNumber = rowdatacount;	 	 
							columnType = head.fieldtype.trim();	
							fileText='';
							filename='';							
							if (columnType === 'fileattachment' || columnType === 'photo'  ){						
								if(visibleRows[l].entity[head.name].split(';;').length > 1){
									fileText = 'Download.zip' ;
									filename='';
									z=1;
									}
								else if(visibleRows[l].entity[head.name].split(';;')[0]){
									fileText=visibleRows[l].entity[head.name];
									filename=fileText.split('id')[1];
									filename=filename.substring(2);
								
									var txtsplic=fileText.split('>');						
									var len=txtsplic[1].indexOf('<');	
									
									fileText=txtsplic[1].substring(0,len);
									filename=filename.substring(0,filename.indexOf("'"));						
									z=0;
								}									
								if (fileText !== ''){
									pid=$j("#programid").val();	
									uid=visibleRows[l].entity.userid;
									pnlid=pnlid_fid.split('_')[0].trim();
									fid=pnlid_fid.split('_')[1].trim();										
									innerhyperlinkurl=origin+"/index.cfm?event=user.downloadfile&prg="+pid+"&usr="+uid+"&pnl="+pnlid+"&field="+fid+"&fieldtype="+columnType+"&fn="+filename+"&z="+z;
										
									row.getCell(cellNumber).value = { formula: 'HYPERLINK("' + innerhyperlinkurl + '","' + fileText + '")' };
									row.getCell(cellNumber).font = { name: 'Arial', size: 10, underline: 'single', color: { argb: '000366d6' } }; 																
								 }								
								rowdatacount=rowdatacount+1;
							} else if (columnType === 'signdocument') {
									fileText=visibleRows[l].entity[head.name];	
									
									if(fileText.indexOf('<') != -1 && fileText.indexOf('>') != -1) {
										var txtsplic = fileText.split('>');						
										var len = txtsplic[1].indexOf('<');										
										fileText = txtsplic[1].substring(0,len);
									}
									if(fileText != '' && fileText != 'Waiting for ' + lcase_siteAlias + ' supervisor signature' && fileText != 'Waiting for director signature' && fileText != 'Waiting for ' + volunteerAliasLcase + ' signature') {		
										fileNameText=visibleRows[l].entity[head.name];										
										filename=fileNameText.split('id')[1];	
										filename=filename.substring(2);										
										filename=filename.substring(0,filename.indexOf("'"));
										
										pid=$j("#programid").val();	
										uid=visibleRows[l].entity.userid;									
										fid=pnlid_fid.split('_')[1].trim();										
										innerhyperlinkurl=origin+"/index.cfm?event=user.downloadsignedfile&prg="+pid+"&usr="+uid+"&field="+fid+"&fieldtype="+columnType+"&fn="+filename+"&z=0";
										/* Start: MV-2064(Added if condition ,inner code already available) */
										if(fileText!='Upload a signed document'){
											row.getCell(cellNumber).value = { formula: 'HYPERLINK("' + innerhyperlinkurl + '","' + fileText + '")' };
											row.getCell(cellNumber).font = { name: 'Arial', size: 10, underline: 'single', color: { argb: '000366d6' } };
										}
										/* End: MV-2064 */
									} else {
										row.getCell(cellNumber).value = fileText;
									}
									rowdatacount=rowdatacount+1;
							} else {	
								/* Start: BG-113 */
								var excelCellValue = visibleRows[l].entity[head.name];
								var cellValueType = '';
								if(excelCellValue != '' && typeof excelCellValue == 'number' && (columnType == 'userid' || columnType == 'number' || (columnType == 'select' && cellisQualitative == 0) || (columnType == 'date' && agefield != 'undefined' && agefield != null && agefield != "" && agefield == "Current Age"))) {
									excelCellValue = Number(excelCellValue);									
								}																
								
								row.getCell(cellNumber).value = excelCellValue;
								
								/* Start: MV-973 */
								if(excelCellValue != '' && columnType == 'date' && (agefield == 'undefined' || agefield == null || agefield == "")) {
									//row.getCell(cellNumber).value = new Date(excelCellValue);
									row.getCell(cellNumber).numFmt = 'm/d/yyyy';	
								}
								/* End: MV-973 */ 
								
								row.getCell(cellNumber).font = { name: 'Arial', size: 10};
								rowdatacount=rowdatacount+1;
								
								if (rosterOrganization == 'volunteer') {								
									var fieldsubpanelid = head.subpanelid.toString().trim();
									
									if (columnType == 'userid' || columnType == 'siteid' || columnType == 'cohortid' || columnType == 'number' || ((columnType == 'select' || columnType == 'checkbox') && cellisQualitative == 0) || (columnType == 'date' && agefield != 'undefined' && agefield != null && agefield != "" && agefield == "Current Age")) {										
										cellValueType = 'number';
									} else if (columnType == 'date') {
										cellValueType = 'date';
									} else if (columnType == 'site' || columnType == 'cohort_name' || columnType == 'associations' || ((columnType == 'select' || columnType == 'checkbox') && cellisQualitative == 1)) {
										cellValueType = 'text';
									}
									
									cellValuesTypeArray[cellNumber] = cellValueType;	
									cellFieldTypeArray[cellNumber] = columnType;
									
									if(columnType != 'lname' && columnType != 'userid' && columnType != 'email' && columnType != 'phone' && columnType != 'text' && columnType != 'encryptedtext' && columnType != 'freetextarea' && columnType != 'completionrate' && columnType != 'historicalrates' && row.getCell(cellNumber).value.toString().trim() != '') {										
										if(columnType == 'checkbox' || columnType == 'site' || columnType == 'siteid' || columnType == 'cohortid' || columnType == 'cohort_name' || columnType == 'BlackoutDates' || columnType == 'associations' || columnType == 'PastTemplateAssignments') {
											var cellValueCheckbox = row.getCell(cellNumber).value.toString().trim();
											var cellValueCheckboxArray = cellValueCheckbox.split(";;");
											for(var j = 0; j < cellValueCheckboxArray.length; j++) {
												if (columnType == 'associations' && fieldsubpanelid == 'Type3' && ($j11('.hide_current_date').text() == 'Remove Dates' || $j11('.hide_historical_date').text() == 'Remove Dates')) {
													var associationAssigned = cellValueCheckboxArray[j].trim();		
													var dateperiod = associationAssigned.lastIndexOf('(');										
													if (dateperiod != -1) {
														var association = associationAssigned.substring(0, dateperiod).trim();	
														cellValuesArray[cellNumber].push(association)
													} else {
														cellValuesArray[cellNumber].push(associationAssigned)
													}												
												} else {
													cellValuesArray[cellNumber].push(cellValueCheckboxArray[j].toString().trim());
												}
											}
										} else {
											cellValuesArray[cellNumber].push(row.getCell(cellNumber).value.toString().trim());
										}
									}
								}
								/* End: BG-113 */
							}							
						}
					});					
				})
			}//end for loop	
			downloadZipRow = 0; // MV-1943
			/* Start: BG-113 */			
			if (rosterOrganization == 'volunteer' && typeof rowIndex != 'undefined') {
				rowIndex = rowIndex + 2;
				row = ws.getRow(rowIndex);
				row.getCell(1).alignment = {wrapText: true};
				row.getCell(1).value = {
					richText: [
						{ font: { name: 'Arial', size: 10, bold: true }, text: 'Total ' + volunteerAliasPlural + ': ' + volunteersCount },							
					]
				};
				for(var i =1;i<cellNumberArray.length;i++) {
					var currentCellNum = cellNumberArray[i];
					var cellValuesCountArray;
					var dataCount = '';		

					if (cellValuesTypeArray[currentCellNum] == 'number') {
						cellValuesArray[currentCellNum] = cellValuesArray[currentCellNum].sort(function (a, b) {  return a - b;  });					
						cellValuesCountArray = arrayElementCount(cellValuesArray[currentCellNum]);
					} else if (cellValuesTypeArray[currentCellNum] == 'date') {					
						cellValuesArray[currentCellNum] = cellValuesArray[currentCellNum].sort(function (a, b) {  var dateA = new Date(a), dateB = new Date(b); return dateA - dateB;});					
						cellValuesCountArray = arrayElementCount(cellValuesArray[currentCellNum]);
					} else if (cellValuesTypeArray[currentCellNum] == 'text') {
						cellValuesArray[currentCellNum] = cellValuesArray[currentCellNum].sort(function(a, b) {
																								if (a.toLowerCase() < b.toLowerCase()) return -1;
																								if (a.toLowerCase() > b.toLowerCase()) return 1;
																								return 0;
																							  });
						cellValuesCountArray = arrayElementCount(cellValuesArray[currentCellNum]);
						cellValuesCountArray = cellValuesCountArray.sort(function (a, b) {  return b.count - a.count;  });
					} else {
						cellValuesCountArray = arrayElementCount(cellValuesArray[currentCellNum]);
					}
					
					var totalDataCount = 0; // BG-209
					for(let i = 0; i < cellValuesCountArray.length; i++){						
						/* Start: BG-209 */
						if (cellValuesTypeArray[currentCellNum] == 'number' && cellFieldTypeArray[currentCellNum] != 'date') {
							totalDataCount = totalDataCount + (parseFloat(cellValuesCountArray[i].value) * parseInt(cellValuesCountArray[i].count));
						}
						/* End: BG-209 */					
						dataCount = dataCount + cellValuesCountArray[i].value + ' (' + cellValuesCountArray[i].count + ')' + '\n';			
					}	
					
					/* Start: BG-209 */
					if (cellValuesTypeArray[currentCellNum] == 'number' && cellFieldTypeArray[currentCellNum] != 'date' && dataCount != '') {
						if(cellFieldTypeArray[currentCellNum] == 'number') {
							dataCount = 'Total (' + totalDataCount + ')';
						} else {
							dataCount = 'Total (' + totalDataCount + ')' + '\n' + '\n' + dataCount;
						}
					}
					/* End: BG-209 */					
					row.getCell(currentCellNum).alignment = {wrapText: true};
					row.getCell(currentCellNum).value = {
						richText: [
							{ text: dataCount },							
						]
					};	
					row.font = { name: 'Arial', size: 10, bold: true };
				}	
			}
			/* End: BG-113 */
			
		//export excel
		wb.xlsx.writeBuffer( {
				base64: true
			})
			.then( function (xls64) {
				// build anchor tag and attach file (works in chrome)
				var a = document.createElement("a");
				var data = new Blob([xls64], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });				
				var url = URL.createObjectURL(data);				
				a.href = url;			
				a.download = "CustomRoster_"+fileDate+".xlsx";
				document.body.appendChild(a);
				a.click();
				setTimeout(function() {
						document.body.removeChild(a);
						window.URL.revokeObjectURL(url);
					},
					0);
			})
			.catch(function(error) {
				console.log(error.message);
			});
    };//End exportExcel				
	
	/*$scope.exportExcel= function(){
		//loadListingTable0();
		var wb = new ExcelJS.Workbook();
		var ws = wb.addWorksheet('Export');
		var origin   = window.location.origin;
		
		// Header
		var utc =  moment.utc(new Date());
		//var pst = moment(utc).zone('-0700'); // -0700 is code for PST
		//var pst = moment(utc).zone('America/Los_Angeles'); // -0800 is code for PDT
		var pst = moment.tz(utc,'America/Los_Angeles');
		var fileDate = pst.format('MMMM_D_YYYY_h_mmA');
		  
		row1 = ws.getRow(1);
		row1.getCell(1).value = 'Volunteer Export Report (' + fileDate + ' )';
		
		//write column of excel
		row3 = ws.getRow(3);		
		$scope.gridOptions.columnDefs.map( (head, index) => {	
			asscol='';
			try{				
				if(head.displayName.indexOf(':') > 0)
					asscol=head.displayName.split(':')[1];				
			}catch(err){				
				asscol='';
			}
			completionratedate='';
			//console.log(head.name)
			//cellName = head.name.split(':')[0];
			var a=head.name.split(':').length-2;
			//console.log(a);
			//console.log(a-2);
cellName ='';		
			if(head.fieldtype.toLowerCase()!='completionrate' || head.fieldtype.toLowerCase()!='historicalrates'){
				for(i=0;i<a;i++){
					cellName += head.name.split(':')[i];	
				}
			}
//console.log(cellName1)			
			cellNumber = index + 1;			
			if(head.fieldtype.toLowerCase()=='completionrate' || head.fieldtype.toLowerCase()=='historicalrates'){
				cellName = head.name.split(':')[0];
				completionratedate=head.name.split(':')[1];				
				cellwidth=head.displayName.trim().length+cellName.trim().length+completionratedate.trim().length;		 
				ws.getColumn(cellNumber).width = cellwidth;
				row3.getCell(cellNumber).value = {
					richText: [
						{ font: { bold: true }, text: head.displayName },
						{ font: { color: { argb: '000366d6' } }, text: ': ' + cellName + ': '+completionratedate},
					]
				};
			}else if(asscol.trim()=='Associations1' || asscol.trim()=='Associations2'){				
				var assname=head.displayName.split(":")[0];
				if(asscol.trim()=='Associations1') {
					assname=assname+" : "+' Type 1 Associations';
				} else {
					assname=assname+" : "+' Type 2 Associations';
				}
				cellwidth=assname.trim().length + cellName.trim().length +2;		 
				ws.getColumn(cellNumber).width = cellwidth;
				row3.getCell(cellNumber).value = {
					richText: [
					  { font: { bold: true }, text: assname },
					  { font: { color: { argb: '000366d6' } }, text: ': ' + cellName },
					]
				};
			}else if(asscol.trim()=='Associations3' ){			
				var assname=head.displayName.split(":")[0];
				assname=assname+' : '+' Type 3 Associations';
				cellwidth=assname.length + cellName.trim().length +2;		 
				ws.getColumn(cellNumber).width = cellwidth;
				row3.getCell(cellNumber).value = {
					richText: [
					  { font: { bold: true }, text: assname },
					  { font: { color: { argb: '000366d6' } }, text: ': ' + cellName },
					]
				};
			}else{
				cellwidth=head.displayName.length + cellName.length +2;		 
				ws.getColumn(cellNumber).width = cellwidth;
				row3.getCell(cellNumber).value = {
					richText: [
					  { font: { bold: true }, text: head.displayName },
					  { font: { color: { argb: '000366d6' } }, text: ': ' + cellName },
					]
				};
			}
		})
		//write header download zip link in excel
		row4 = ws.getRow(4);				
		for (var i = 0; i < $scope.gridOptions.columnDefs.length; i++) {
			var flag=false;			
			if($scope.gridOptions.columnDefs[i].fieldtype=='fileattachment' || $scope.gridOptions.columnDefs[i].fieldtype=='photo'){			
				colname=$scope.gridOptions.columnDefs[i].name
				for (var j = 0; j < $scope.gridOptions.data.length; j++) {
					if($scope.gridOptions.data[j][colname]!=''){
						flag=true;
						break;
					}
				}				
				if(flag){						
					fileIndex = i;
					pid=$j("#programid").val();	
					uid=$j("#userid").val();
					pnlid=$scope.gridOptions.columnDefs[i].name.split(':')[1].trim();
					fid=$scope.gridOptions.columnDefs[i].name.split(':')[2].trim();		
					mainhyperlinkurl=origin+"/index.cfm?event=user.downloadfilezip&prg="+pid+"&usr="+uid+"&field="+fid+"&userlistid="+userlistid+"&pnl="+pnlid;				
					row4.getCell(fileIndex +1).value = { formula:'HYPERLINK("' + mainhyperlinkurl + '","Download.Zip")' };
					row4.getCell(fileIndex +1).font = { underline: 'single', color: { argb: '000366d6' } };					
				}
			}
		}
		// write Data in excel
		ws.addRows($scope.gridOptions.data);
		$scope.gridOptions.data.map((columnObj, colIndex) => {
			rowIndex = colIndex + 5;
			row = ws.getRow(rowIndex);
			$scope.gridOptions.columnDefs.map((head, index) => {
				cellNumber = index + 1;	 	 
				columnType = head.fieldtype.trim();	
				fileText='';
				filename='';
				
				if (columnType === 'fileattachment' || columnType === 'photo'){						
					if(columnObj[head.name].split(';;').length > 1){
						fileText = 'Download.zip' ;
						filename='';
						z=1;
						}
					else if(columnObj[head.name].split(';;')[0]){
						fileText=columnObj[head.name];
						filename=fileText.split('id')[1];
						filename=filename.substring(2);
					
						var txtsplic=fileText.split('>');						
						var len=txtsplic[1].indexOf('<');	
						
						fileText=txtsplic[1].substring(0,len);
						filename=filename.substring(0,filename.indexOf("'"));						
						z=0;
					}		  
				
					if (fileText !== ''){
						pid=$j("#programid").val();	
						uid=columnObj.userid;
						pnlid=head.name.split(':')[1].trim();
						fid=head.name.split(':')[2].trim();
						innerhyperlinkurl=origin+"/index.cfm?event=user.downloadfile&prg="+pid+"&usr="+uid+"&pnl="+pnlid+"&field="+fid+"&fieldtype="+columnType+"&fn="+filename+"&z="+z;
							
						row.getCell(cellNumber).value = { formula: 'HYPERLINK("' + innerhyperlinkurl + '","' + fileText + '")' };
						row.getCell(cellNumber).font = { underline: 'single', color: { argb: '000366d6' } };
					 }
				}else {
					  row.getCell(cellNumber).value = columnObj[head.name];
				}
			});
		})
		
		//export excel
		wb.xlsx.writeBuffer( {
				base64: true
			})
			.then( function (xls64) {
				// build anchor tag and attach file (works in chrome)
				var a = document.createElement("a");
				var data = new Blob([xls64], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
				var url = URL.createObjectURL(data);
				a.href = url;
				
				a.download = "CustomRoster_"+fileDate+".xlsx";
				document.body.appendChild(a);
				a.click();
				setTimeout(function() {
						document.body.removeChild(a);
						window.URL.revokeObjectURL(url);
					},
					0);
			})
			.catch(function(error) {
				console.log(error.message);
			});
    };*///End exportExcel		
}]);

app.filter('trusted', function ($sce) {
  return function (value) {
    return $sce.trustAsHtml(value);
  }
});


function loadListingTable() {
	
    var scope = angular.element(document.getElementById("postservice")).scope();
    scope.$apply(function () {		
		scope.functionA(false, false, true);
	});    
}

function callsaveOrder() 
{
	var scope = angular.element(document.getElementById("postservice")).scope();
	var state = scope.gridApi.saveState.save();	
	var fieldorder1=[];
	scope.excelfieldorder=[];
	var count=0;
		scope.fieldorder=[];
		for(var i=0;i<state.columns.length;i++){			
			if(state.columns[i].name.split(':').length==4){
				count=count+1;
				var panelid=state.columns[i].name.split(':')[2];
			    var Id1=state.columns[i].name.split(':')[3];

				if (panelid.indexOf('serviceterms_')==0 || panelid.indexOf('blackoutdates_')==0 || panelid.indexOf('approvedhrs_')==0 || panelid.indexOf('pendinghrs_')==0 || panelid.indexOf('disallowedhrs_')==0 ||  panelid.indexOf('firstdate_')==0 || panelid.indexOf('recentdate_')==0 || panelid.indexOf('tspersonalstartdate_')==0 || panelid.indexOf('tspersonalenddate_')==0 || panelid.indexOf('tsstatus_')==0 || panelid.indexOf('tstimeoffcalendar_')==0 || panelid.indexOf('submittedhrs_')==0) { //TS-1395/phase-2
					// TS-633
					fieldorder1.push(panelid);
					scope.fieldorder.push(panelid);
				} else {
					fieldorder1.push(panelid+'_'+Id1);
					scope.fieldorder.push(panelid+'_'+Id1);	
				}
			}else{
				var panelid=state.columns[i].name.split(':')[1];
				var Id1=state.columns[i].name.split(':')[2];
				//console.log(state.columns[i].name);
				if(Id1.indexOf('Association_')==0){
					Id1=Id1.split('_')[1];
					if(state.columns[i].name.split(':')[2].indexOf('_Previous') != -1){
						Id1 += '_Previous';
					}
				}			 
				
				if (panelid.indexOf('serviceterms_')==0 || panelid.indexOf('blackoutdates_')==0 || panelid.indexOf('approvedhrs_')==0 || panelid.indexOf('pendinghrs_')==0 || panelid.indexOf('disallowedhrs_')==0 ||  panelid.indexOf('firstdate_')==0 || panelid.indexOf('recentdate_')==0 || panelid.indexOf('tspersonalstartdate_')==0 || panelid.indexOf('tspersonalenddate_')==0 || panelid.indexOf('tsstatus_')==0 || panelid.indexOf('tstimeoffcalendar_')==0 || panelid.indexOf('submittedhrs_')==0) { //TS-1223/TS-1341 //TS-1395/phase-2
					// TS-633
					fieldorder1.push(panelid);
					scope.fieldorder.push(panelid);
				} else {
					fieldorder1.push(panelid+'_'+Id1);
					scope.fieldorder.push(panelid+'_'+Id1);	
				}
			}
		}
		$j("#fieldsortorder").val(fieldorder1);	
		$j("#setFieldOrder").val('1');
}


function saveReport(saveReport,action,overwrite){
	var scope = angular.element(document.getElementById("postservice")).scope();
	/*****Start Mv-693********/

	var completedradio=$j('#completed_dates_period option:selected').val()	
	var missedradio=$j('#missed_dates_period option:selected').val();	
	var fieldorder=[];
	/*****End Mv-693********/
	// TS-633 : START
	var timesheetDetailsPanelId = $j(".timesheetDetailsPanelId").attr("panelid");
	var templatesArr = $j('.timesheetTemplateClass:checked');

	var templatesToSave = [];
	
	var templatesArrNew = templatesArr.map((i, e) => {
		
		var templateElements = $j(`.timesheetTemplateElements_${$j(e).val()}:checked`);
		var templateElementsIdArr = [];
		templateElements.each((idx, ele) => {
			templateElementsIdArr.push($j(ele).prop("id"));
		})

		var templateId = $j(e).val();
		return `{ "timesheetDetailsPanelId": "${timesheetDetailsPanelId}";; "templateId" : "${templateId}";; "templateElementsIdArr": "${templateElementsIdArr.join(";;")}"}`;
	});

	templatesArrNew.each((i, e) => {
		templatesToSave.push(e);
	});

	// TS-633 : END
    var arrangefieldsby = $j('.arrangefields:checked').val(); 
    var reportname = $j('#userinputfilename').val().trim();	
	/* Start :: MV-1859 & MV-1885 */	
	var appliedFCount = $j(".filtercount").val();
	var msg = "";
	if(appliedFCount > 1){
		msg = validateFilters();
	}
	if(msg != "" && msg == 'invalid pattern') {
		return false;
	} else if (msg != "" && msg != 'invalid pattern') {
		alert(msg);
		return false;
	} else {
	/* End :: MV-1859 & MV-1885 */
		if(action == "save") {
			var _current_time_cache = new Date().getTime();	
			if(reportname.length == 0) {
				alert('Please provide a report name.');
				$j("#userinputfilename").focus();
				return;
			}
			else if(check(reportname)){ 
				alert('Please choose a report name without any special characters (letters, numbers, and spaces only).');
				$j("#userinputfilename").focus();
				return false;
			} else {
				callsaveOrder();
				var fsortorder = [];
				fsortorder.push( $j('#fieldsortorder').val());
				var rosterOrganization = $j('.rosterOrganization').val();
				
				var editpatternflage = 0;
					if($j('select[name="sel_action"]').prop("disabled")==true)
						editpatternflage=1;
				
				var data =[];
				var fieldarr = [];					
				data.push({
					"name": "rosterOrganization",
					"value": rosterOrganization
				});					
				data.push({
					"name": "arrangefieldsby",
					"value": arrangefieldsby
				}); 
				$j('input[name="childpanelitem"]:checked').each(function(e,i){
					var panelId = $j(this).attr('panelid');
					var fieldId = $j(this).val();
					var panelfieldId = panelId + '_' + fieldId;
					fieldarr.push(panelfieldId);					  
				}); 
				$j('input[name="childassociationitem"]:checked').each(function(e,i){
					var panelId = $j(this).attr('panelid');
					var fieldId = $j(this).val();
					var fieldType = $j(this).attr('fieldtype');
					var panelfieldId = '';
					if(fieldType != undefined && fieldType == 'Type3'){
						panelfieldId = panelId + '_' + fieldId + '_Type3' ;
					} else {
						panelfieldId = panelId + '_' + fieldId;
					}
					
					fieldarr.push(panelfieldId);					  
				}); 
				
				//BG-64 : Start
				var checkboxarr = [];
				$j('input[name="checkbox_parent"]:checked').each(function(e,i){
				
					var checkbox_parent_id = $j(this).attr("id");
					var checkbox_panel_id =  $j(this).attr("panelid");
					var tempID = checkbox_parent_id.split("_")[2];
				
					var checkbox_current_id = "checkpanelasso_"+tempID;
					var checkbox_current_status = $j("#"+checkbox_current_id).prop("checked");

					var checkbox_previous_id = "checkpanelasso_"+tempID+"_Previous";
					var checkbox_previous_status = $j("#"+checkbox_previous_id).prop("checked");

					var current_date_span_id = "current_date_span_"+tempID;
					var current_date_span_class = $j("#"+current_date_span_id).children('a').attr("class");

					var historical_date_span_id = "historical_date_span_"+tempID;
					var historical_date_class = $j("#"+historical_date_span_id).children('a').attr("class");

				var viewInfo =	checkbox_parent_id + ";" + checkbox_panel_id + ";" + 
												checkbox_current_id + ";" + checkbox_current_status + ";" + 
												checkbox_previous_id + ";" + checkbox_previous_status + ";" + 
												current_date_span_id + ";" + current_date_span_class + ";" + 
												historical_date_span_id + ";" + historical_date_class;
					checkboxarr.push(viewInfo);
					//console.log("viewInfo : "+viewInfo);
				});
				//Bg-64 : Stops

				var filtercount = parseInt($j('.filtercount').val()); 
				var filter = "";
				var paneltype = "";
				var fieldtype = "";
				var operator = "";
				var operatorval = "";
				var filtervalue = "";
				var logical = " ";
				var filtercompoption = "";
				for(i = 1; i <filtercount; i++) { 
					filterby = $j('option:selected', '.sel_field_' + i).val();  
					panel = $j('option:selected', '.sel_field_' + i).attr('rel2'); 
					field = $j('option:selected', '.sel_field_' + i).attr('rel');
					operatorType = $j('.filterOperator_' + i + ' option:selected').text();
					if(operatorType=='is only')operatorType = 'is';
					operatorValue = $j('.filterOperator_' + i + ' option:selected').val();
					if(filterby.indexOf("ServiceTerms") != -1 || filterby.indexOf("approvedhrs") != -1 || filterby.indexOf("pendingHrs") != -1 || filterby.indexOf("disallowedhrs") != -1 || filterby.indexOf("FirstDate") != -1 || filterby.indexOf("RecentDate") != -1 || filterby.indexOf("BlackoutDates") != -1 || filterby.indexOf("TSPersonalStartDate") != -1 || filterby.indexOf("TSPersonalEndDate") != -1 || filterby.indexOf("TSStatus") != -1 || filterby.indexOf("TSTimeOffCalendar") != -1 || filterby.indexOf("submittedHrs") != -1) //TS-1395/phase-2 //TS-1112
					{
						filterby = filterby.split("_")[1];
					}
					fieldvaluefilter = "";
					if(operatorType == 'between' || operatorType == 'not between') {
					$j('.filtervalue_' + i).each(function(){
						fieldvaluefilter += $j(this).val() + ",";                 
					});
					fieldvaluefilter.substring(0, fieldvaluefilter.length-1);       
					} else {
					fieldvaluefilter =  $j('.filtervalue_' + i).val();
					if(fieldvaluefilter == '') {
						fieldvaluefilter = ' ';
					}
					}
					if(i>1) {
					logical += $j('option:selected', '.sel_action_' + i).text();
					}
					filter += filterby + "~";
					paneltype += panel + "~";
					fieldtype += field + "~";
					operator += operatorType + "~";
					operatorval += operatorValue + "~";
					//filtervalue += fieldvaluefilter.replaceAll("~","&tilde;") + "~";	//MV-1877
					if(typeof $j('.filtervalue_' + i).attr('data-filter-option') !== "undefined"){
						filtercompoption += $j('.filtervalue_' + i).attr('data-filter-option') + "~";
					}else{
						filtercompoption += '1~'
					}
					
					if($j('.filtervalue_' + i).attr('data-filter-option') == '2'){
						filtervalue += $j('.filtervalue_' + i).attr('data-filter-value') + "~";
					}else{
						filtervalue += fieldvaluefilter.replaceAll("~","&tilde;") + "~";
					}
					logical += "~";     
				}
				/*****Start Mv-693********/
				if($j('#updateresultcompleted').val()=='yes')
				{
					var panelId = $j('#completed_dates_period').attr('panelid');
					var fieldId = $j('#completed_dates_period').attr('fieldid');
					var panelfieldId = panelId + '_' + fieldId;
					if (completedradio=="completed") { 
						var startperiodcompleted=$j('#beginsurvey_'+completedradio+' :selected').val();
						var endperiodcompleted=$j('#endsurvey_'+completedradio+' :selected').val();
					
						if(jQuery.inArray(panelfieldId, fieldarr)==-1){			
							fieldarr.push(panelfieldId);
						}
						var completedarr=[];
						$j(".surveyid_list_"+completedradio+":checked").each(function(){
						var chkid=$j(this).val();
						completedarr.push(chkid)
						});				
						
						data.push({
							"name": "surveyidcompleted",
							"value": completedarr
						});										
						data.push({
							"name": "startperiodcompleted",
							"value": startperiodcompleted
						});
						data.push({
							"name": "endperiodcompleted",
							"value": endperiodcompleted
						});			
					}
					data.push({
						"name": "completedpnlidfieldid",
						"value": panelfieldId
					});								
				}
				if($j('#updateresultmissed').val()=='yes') {
					var panelId = $j('#missed_dates_period').attr('panelid');
					var fieldId = $j('#missed_dates_period').attr('fieldid');
					var panelfieldId = panelId + '_' + fieldId;

					if(missedradio=="missed") {
						var startperiodmissed=$j('#beginsurvey_'+missedradio+' :selected').val();
						var endperiodmissed=$j('#endsurvey_'+missedradio+' :selected').val();
						if(jQuery.inArray(panelfieldId, fieldarr)==-1){			
							fieldarr.push(panelfieldId);
						}				
						var missedarr=[];
						$j(".surveyid_list_"+missedradio+":checked").each(function(){
						var chkid=$j(this).val();
						missedarr.push(chkid)
						});				
						data.push({
							"name": "surveyidmissed",
							"value": missedarr
						});									
						data.push({
							"name": "startperiodmissed",
							"value": startperiodmissed
						});
						data.push({
							"name": "endperiodmissed",
							"value": endperiodmissed
						});
					}
					data.push({
						"name": "missedpnlidfieldid",
						"value": panelfieldId
					});							
				}
				/*****End Mv-693********/
				//BG-64 : Start
				data.push({
					"name": "SelectedCheckBoxes",
					"value": checkboxarr
				});
				//BG-64 : Stops
				data.push({
					"name": "SelectedFields",
					"value": fieldarr
				});
				data.push({
					"name": "filter",
					"value": filter
				});
				data.push({
				"name": "paneltype",
				"value": paneltype
				});
				data.push({
				"name": "fieldtype",
				"value": fieldtype
				});
				data.push({
					"name": "operator",
					"value": operator
				});
				data.push({
					"name": "operatorval",
					"value": operatorval
				});
				data.push({
					"name": "filtervalue",
					"value": filtervalue
				});
				data.push({
					"name": "filtercompoption",
					"value": filtercompoption
				});
				data.push({
					"name": "logical",
					"value": logical
				});
				data.push({
					"name": "fieldorder",
					"value": fsortorder
				});
				data.push({
					"name": "reportname",
					"value": reportname
				});	
				data.push({	
					"name": "filtervaluepattern",
					"value": $j('#filtervaluepattern').val()
				});	
				data.push({				
					"name": "editpatternflage",
					"value": editpatternflage
				});

				// TS-633 : START
				data.push({
					"name": "timesheetTemplate",
					"value": templatesToSave
				});
				// TS-633 : END
				
				var url = "index.cfm?event=user.saveReportDetails&overwrite="+overwrite+"&currenttimestamp=" + _current_time_cache;
				
				$j.ajax({
					type: "POST",
					url: url,
					data: data,
					dataType: "json",
					beforeSend: function() {
						showLoadingOverlay();							
					},
					success: function(saveReportStatus) {							
						if(saveReportStatus == "1") {
							overwritewindow(reportname,0); 
						} else {
							if(overwrite == 1)
								closeCRWindow();
							showLoadingOverlay();
							overwritewindow(reportname,1);
							renamedeletereport(0,'','fetch');				
						}	
					},
					complete: function() {
						hideLoadingOverlay();						  
					},
					error: function(data) {
						status = false;
					}
				});
			} 	
		} else {
			
			showLoadingOverlay();
			scope.$apply(function (){		
				scope.exportExcel();
			});
			
			var churn_SalesforceId=$j11('#SalesforceId').val();
			var churn_ChurnZerotrack=$j11('#ChurnZerotrack').val();
			if(churn_SalesforceId !='' && churn_ChurnZerotrack==1){
				ChurnZero.push(['trackEvent', 'Reporters: Reporter Profile Export Run']);
			}
			hideLoadingOverlay();
		}
	} // MV-1859 & MV-1885
}
function GetUnique(inputArray)
{
	var outputArray = [];
	for (var i = 0; i < inputArray.length; i++)
	{
		if ((jQuery.inArray(inputArray[i], outputArray)) == -1)
		{
			outputArray.push(inputArray[i]);
		}
	}
	return outputArray;
}

function overwritewindow(reportname,status){
  var cfwindowTitle = "";
  if(status==0){
  ColdFusion.Window.create("overwriteWindow",cfwindowTitle,"index.cfm?event=association.overwritewindow&reportname="+reportname+"&statusow="+status,{modal:true,width:450,height:180,center:true,draggable:true});
  }
  else{
   ColdFusion.Window.create("overwriteWindow",cfwindowTitle,"index.cfm?event=association.overwritewindow&reportname="+reportname+"&statusow="+status,{modal:true,width:250,height:180,center:true,draggable:true}); 
  }
  ColdFusion.Window.onHide("overwriteWindow", closeCRWindow); 
}

function closeCRWindow(){
  ColdFusion.Window.destroy("overwriteWindow");        
}

function contineOW(){
	saveReport('checkSaveReport','save',1);
}

function applyCompletionFilter() {		
	showLoadingOverlay();
	var scope = angular.element(document.getElementById("postservice")).scope();
	$j('#updateresultcompleted').val('yes');	
	var completedoption = $j('#completed_dates_period option:selected').val();	
	//if($j('#surveyrateflag').val() == 0 || $j('#completed_dates_period option:selected').val() == "completed" || $j('#missed_dates_period option:selected').val() == "missed") {
	if(completedoption != $j('#completedsurveyrateoption').val() || $j('#completeddatedropdown .updatefiltercompleted').html() == 'Update Results' || $j('#belowupdatefilter_result_completed .updatefiltercompleted').html() == 'Update Results') {
		$j('#completedsurveyrateoption').val(completedoption);
		$j('.style10').html('<img src="../../images/icons/animated_loading.gif">&nbsp;&nbsp;&nbsp;<strong>We\'re running a number of formulas right now. Please hold tight.</strong>');
		$j('#surveyrateflag').val('1');
		//loadListingTable();	
		scope.getSelectedFieldData('singleField',$j('.completionratecheckbox').val(),'completed'); // export optimization
	}
	//} else {
	//	$scope.myClick(panelid,subpanelid,fieldId,fieldtype);
	//}
	$j('.updatefiltercompletedwithNoOption').html('<a class="updatefiltercompleted linkToSection_filter" rel="updatefilter_filter" style="font-weight:bold;color:grey;" disabled>Updated</a>');
	
	$j('#updatefilter_result_completed').html('<a class="updatefiltercompleted linkToSection_filter" rel="updatefilter_filter" Style="color:grey;" disabled>Updated</a><span class="updateor" Style="margin-left:5px;color:grey;">or</span>');
	$j('#belowupdatefilter_result_completed').html('<a class="updatefiltercompleted linkToSection_filter" rel="updatefilter_filter" Style="color:grey;" disabled>Updated</a>');	
	hideLoadingOverlay();
}

function applyMissedFilter(panelid,subpanelid,fieldId,fieldtype) {		
	showLoadingOverlay();
	var scope = angular.element(document.getElementById("postservice")).scope();
	$j('#updateresultmissed').val('yes');
	var missedoption = $j('#missed_dates_period option:selected').val();	
	//if($j('#surveyrateflag').val() == 0 || $j('#completed_dates_period option:selected').val() == "completed" || $j('#missed_dates_period option:selected').val() == "missed") {
	if(missedoption != $j('#missedsurveyrateoption').val() || $j('#misseddatedropdown .updatefiltermissed').html() == 'Update Results' || $j('#belowupdatefilter_result_missed .updatefiltermissed').html() == 'Update Results') {
		$j('#surveyrateflag').val('1');
		$j('#missedsurveyrateoption').val(missedoption);
		$j('.style10').html('<img src="../../images/icons/animated_loading.gif">&nbsp;&nbsp;&nbsp;<strong>We\'re running a number of formulas right now. Please hold tight.</strong>');
		//loadListingTable();	
		scope.getSelectedFieldData('singleField',$j('.missedratecheckbox').val(),'missed');
	}
	//} else {
	//	$scope.myClick(panelid,subpanelid,fieldId,fieldtype);
	//}
	
	$j('.updatefiltermissedwithNoOption').html('<a class="updatefiltermissed linkToSection_filter" rel="updatefilter_filter" style="font-weight:bold;color:grey;" disabled>Updated</a>');
	
	$j('#updatefilter_result_missed').html('<a class="updatefiltermissed linkToSection_filter" rel="updatefilter_filter" Style="color:grey;" disabled>Updated</a><span class="updateor" Style="margin-left:5px;color:grey;">or</span>');
	$j('#belowupdatefilter_result_missed').html('<a class="updatefiltermissed linkToSection_filter" rel="updatefilter_filter" Style="color:grey;" disabled>Updated</a>');
	hideLoadingOverlay();
}
function confirmRemoval(){	
	var filtercount=$j('.filtercount').val();
	var ftype=$j('#completedMissedWindowftype').val();	
	var filrow=$j('#completedMissedfilterrow').val().split(',');	
	var scope = angular.element(document.getElementById("postservice")).scope();
	var count=0;
	var filtercount=0;		
	$j.each(filrow,function(i){
		count=count+1;
		var remfilrow=parseInt(filrow[i]);
		if(count >1)
			remfilrow=parseInt(filrow[i])-1;		
		scope.removeFilter(remfilrow);
	});	
	ColdFusion.Window.hide('completedMissedWindow');
	$j("select[name=sel_field] :selected").map(function(i, v) {		
	
		if($j(v).val()>0)
			filtercount=i+1;
	});		
	if($j('#updateresult'+ftype).val()=='yes' && filtercount >0){
		loadListingTable();
		$j('#updateresult'+ftype).val('no')
	}
}
function confirmRemovalCancel(){
	
	var scope = angular.element(document.getElementById("postservice")).scope();
	ColdFusion.Window.hide('completedMissedWindow');
	var fid=$j('#completedMissedWindowfid').val();	
	var ftype=$j('#completedMissedWindowftype').val();	
	var completedmisedradio=$j('#completedmissedradio').val();				
	var sdate=$j('#startperiod').val();
	var edate=$j('#endperiod').val();
	var surveyid=$j('#surveyid').val();
	
	$j11("#checkpanel_"+fid).prop("checked", true);
	$j11('#'+ftype+'_dates_period').prop("disabled",false);
	if(completedmisedradio==ftype)
	{
		$j('input[value='+ftype+']').prop("checked",true);		
		$j11('#completeddatedropdown').css('display','block');
		if(surveyid!='')
		{
			$j("#beginsurvey_"+ftype+"[value="+'"'+sdate+'"'+"]")
							.attr('selected', 'true');
			$j("#endsurvey_"+ftype+" [value="+'"'+edate+'"'+"]")
							.attr('selected', 'true');
			section = $j11.trim($j11('#linkTosection3_filter_completed').attr('rel')); 
			if(!$j11('#linkTosection3_filter_'+ftype).hasClass('sliding')){		
				$j11('#imgLoading_section3_filter_'+ftype).show(); 
				$j11('#updatefilter_result_'+ftype).show(); 		
				$j11('#linkTosection3_filter_completed').addClass('sliding'); 
				Effect.SlideDown('div_section3_filter_' + ftype,{ afterFinish: function () { 		 
					$j11('#linkTosection3_filter_completed').removeClass('sliding')
					.removeClass('expandSection_filter').addClass('collapseSection_filter');
					$j11('#imgLoading_section3_filter_' + ftype).hide(); 		
					$j11('#close_section3_filter_'+ftype).show();					
					}
				});								
			}			
			var array = surveyid.split(",");
			$j11.each(array,function(i){	
				var id=ftype+"_"+array[i];
			   $j11("#"+id).attr('checked', 'true');
			});
			callCheckBox(ftype);
			$j('#updatefilter_result_'+ftype).html('<a class="updatefiltercompleted linkToSection_filter" rel="updatefilter_filter" Style="color:grey;" disabled>Updated</a><span class="updateor" Style="margin-left:5px;color:grey;">or</span>');
			$j('#belowupdatefilter_result_'+ftype).html('<a class="updatefiltercompleted linkToSection_filter" rel="updatefilter_filter" Style="color:grey;" disabled>Updated</a>');
			$j('#updateresult'+ftype).val('yes');
			scope.resetRemoveFieldOrder();		
			scope.resetfieldorder();
			scope.displayFieldsBasedonCheckbox();			
		}else
		{				
			$j("#beginsurvey_"+ftype+"[value="+'"'+sdate+'"'+"]")
							.attr('selected', 'true');
			$j("#endsurvey_"+ftype+" [value="+'"'+edate+'"'+"]")
							.attr('selected', 'true');
			$j('#updatefilter_result_'+ftype).html('<a class="updatefiltercompleted linkToSection_filter" rel="updatefilter_filter" Style="color:grey;" disabled>Updated</a><span class="updateor" Style="margin-left:5px;color:grey;">or</span>');
			$j('#belowupdatefilter_result_'+ftype).html('<a class="updatefiltercompleted linkToSection_filter" rel="updatefilter_filter" Style="color:grey;" disabled>Updated</a>');
			$j('#updateresult'+ftype).val('yes');
			scope.resetRemoveFieldOrder();		
			scope.resetfieldorder();
			scope.displayFieldsBasedonCheckbox();			
		}		
	}else{
		scope.resetRemoveFieldOrder();		
		scope.resetfieldorder();
		scope.displayFieldsBasedonCheckbox();
	}	
}

/* Start: BG-113 */
function arrayElementCount(original) {
 
	var compressed = [];
	// make a copy of the input array
	var copy = original.slice(0);
 
	// first loop goes over every element
	for (var i = 0; i < original.length; i++) {
 
		var myCount = 0;	
		// loop over every element in the copy and see if it's the same
		for (var w = 0; w < copy.length; w++) {
			if (original[i] == copy[w]) {
				// increase amount of times duplicate is found
				myCount++;
				// sets item to undefined
				delete copy[w];
			}
		}
 
		if (myCount > 0) {
			var a = new Object();
			a.value = original[i];
			a.count = myCount;
			compressed.push(a);
		}
	}
 
	return compressed;
};
/* End: BG-113 */

// TS-633 : START 
// TS-633 STEP-1
$j11(document).ready(function(){
	$j11(".timesheetTemplateClass").click(function () {
		showLoadingOverlay();													 
		let scope = angular.element(document.getElementById("postservice")).scope();
		scope.getUserListAll = 0;//TS-1098
		/*$j11(".timesheetTemplateClass:not(:checked)").each((i, e) =>{
			var templateId = $j11(e).val();
			$j11(".timesheetTemplateElements_"+templateId).prop("checked", false);
			$j11(".timesheetTemplateDetails_"+templateId).hide();
		});*/
		
		var thisTSId = $j11(this).attr("id");		
		var templateId = thisTSId.split("_")[1];		
		if($j11("#" + thisTSId).prop("checked") == false) {
			$j11(".timesheetTemplateElements_"+templateId).prop("checked", false);
			$j11(".timesheetTemplateDetails_"+templateId).hide();
		}

		if($j11(".timesheetTemplateClass:not(:checked)").length > 0){
			$j11('.timeSheetDetailsSelectAll').html("Select All");
		} 

		if($j11(this).prop("checked") == true){
			// prepareDataForTimeSheetDetails(generateExcel, displayAll);
			//scope.prepareDataForTimeSheetDetails(false, false);
			scope.getSelectedFieldData('timesheetField',0,'');
		} else {
			scope.resetRemoveFieldOrder();		
			scope.resetfieldorder();
			scope.displayFieldsBasedonCheckbox();
		}
		hideLoadingOverlay();
	});
	
});

$j11('.timeSheetDetailsSelectAll').click(function() {
//$j11('.timeSheetDetailsSelectAll').click((a) => {
	showLoadingOverlay();											
	setTimeout(	
		function() {			   
			let scope = angular.element(document.getElementById("postservice")).scope();
			scope.getUserListAll = 1;//TS-1098
			if ($j11('.timeSheetDetailsSelectAll').html() == 'Select All') {			
				//$j11('.style10').html('<img src="../../images/icons/animated_loading.gif">&nbsp;&nbsp;&nbsp;<strong>We\'re loading export options for these template.</strong>');
				//showWaitScreen();
				$j11('.timesheetTemplateClass').prop('checked', true);
				$j11('.timesheetTemplateElements').prop('checked',true);		
				/* Load Data
				* scope.prepareDataForTimeSheetDetails(generateExcel, displayAll);
				*/
				//scope.prepareDataForTimeSheetDetails(false, true);					
				scope.getSelectedFieldData('timesheetField',0,''); // Export Optimization
				$j11('.timesheetTemplateClass').closest('.columngroup').addClass("check_bgcolor");
				$j11('.timeSheetDetailsSelectAll').html('Select None');			
				//hideWaitScreen();
			} else {
				$j11('.timesheetTemplateClass').prop('checked', false);
				$j11('.timesheetTemplateElements').prop('checked',false);
				$j11('.timesheetTemplateClass').closest('.columngroup').removeClass("check_bgcolor"); 
				//scope.prepareDataForTimeSheetDetails(false, true);
				scope.resetRemoveFieldOrder();		
				scope.resetfieldorder();
				//scope.displayFieldsBasedonCheckbox();
		
				$j11(".timesheetTemplateDetails").hide();
				$j11('.timeSheetDetailsSelectAll').html('Select All');
				scope.displayFieldsBasedonCheckbox();
			}
		}
	,100);
	hideLoadingOverlay();
});
// TS-633 : STOP

/* Start: Volunteer Export */

function reArrangeFields() {
	showLoadingOverlay();
	var scope = angular.element(document.getElementById("postservice")).scope();
	var checkedFieldId = $j("input[name='childpanelitem']:checked").val();
	var checkedFieldType = $j("input[name='childpanelitem']:checked").attr('fieldtype');	
	scope.getSelectedFieldData('singleField',checkedFieldId,checkedFieldType);	
}


/* Start: Mv-1823 */
function validateFilters() {
	var validationstatus = angular.element(document.getElementById('postservice')).scope().savePattern();
	if(validationstatus){
		var filtercount = parseInt($j('.filtercount').val());		
		for(var rel=1;rel < filtercount; rel++) {
			var button = $j('.btn_add_filter_' + rel).html();
			var filterby = $j('option:selected', '.sel_field_' + rel).val();
			var filterbySelected = $j('option:selected', '.sel_field_' + rel).attr('rel');	//added for mv-693				
			var fieldvalueclass = 'btn_add_filter_' + rel;
			var operatorType = $j('.filterOperator_' + rel + ' option:selected').text();
			var fieldvaluefilter = 	$j('.filtervalue_' + rel).val();
      // TS-1112
			if(filterby.indexOf("ServiceTerms") != -1 || filterby.indexOf("approvedhrs") != -1 || filterby.indexOf("pendingHrs") != -1 || filterby.indexOf("disallowedhrs") != -1 || filterby.indexOf("FirstDate") != -1 || filterby.indexOf("RecentDate") != -1 || filterby.indexOf("BlackoutDates") != -1 || filterby.indexOf("TSPersonalStartDate") != -1 || filterby.indexOf("TSPersonalEndDate") != -1 || filterby.indexOf("TSStatus") != -1 || filterby.indexOf("TSTimeOffCalendar") != -1 || filterby.indexOf("submittedHrs") != -1){ //TS-1223/TS-1341 //TS-1395/phase-2
				filterby = filterby.split("_")[1];
			}
			var msg = "";
			if(filterby == 0) {
				msg += "Please select filter by.\n";		
			} 	
			if(operatorType != "is empty" && operatorType != "isn't empty" && operatorType != "is set" && operatorType != "is not set" && operatorType != "today" && operatorType != "tomorrow" && operatorType != "tomorrow onwards"  && operatorType != "yesterday" && operatorType != "until yesterday" && operatorType != "last month"  && operatorType != "current month" && operatorType != "next month"  && operatorType != "last week" && operatorType != "current week" && operatorType != "next week" && operatorType != "is fully executed" && operatorType != "is waiting for supervisor signature" && operatorType != "is waiting for director signature" && operatorType != "is waiting for " + volunteerAliasLcase + " signature" && operatorType != "has no signatures" && operatorType != "is yes" && operatorType != "is no") { //Mv-862 //MV-2153
					if($j('option:selected', '.sel_field_' + rel).attr('rel') == 'date' || ($j('option:selected', '.sel_field_' + rel).attr('rel') != undefined &&  ($j('option:selected', '.sel_field_' + rel).attr('rel').split('_')[0] == 'BlackoutDates'
					|| $j('option:selected', '.sel_field_' + rel).attr('rel').split('_')[0] == 'FirstDates' || $j('option:selected', '.sel_field_' + rel).attr('rel').split('_')[0] == 'RecentDate' || $j('option:selected', '.sel_field_' + rel).attr('rel').split('_')[0] == 'TSPersonalStartDate' || $j('option:selected', '.sel_field_' + rel).attr('rel').split('_')[0] == 'TSPersonalEndDate' || $j('option:selected', '.sel_field_' + rel).attr('rel').split('_')[0] == 'TSStatus' || $j('option:selected', '.sel_field_' + rel).attr('rel').split('_')[0] == 'TSTimeOffCalendar' || $j('option:selected', '.sel_field_' + rel).attr('rel').split('_')[0] == 'submittedHrs'))) { //TS-1223/TS-1341 //TS-1395/phase-2
						if((operatorType == "between" || operatorType == "not between") && (($j('#datelink1_' + rel).val() != 'undefined' && $j('#datelink1_' + rel).val() == "") || ($j('#datelink2_' + rel).val() != 'undefined' && $j('#datelink2_' + rel).val() == ""))) {
							msg += "Please provide both between date filter value.";	
						} else {
							if(typeof fieldvaluefilter != 'undefined' && fieldvaluefilter.trim() == "") {
								msg += "Please provide date filter value.";
							}
						}			
					}else {							
						if((filterbySelected=='completed' || filterbySelected=='missed' || filterbySelected=='completionrate' || filterbySelected=='historicalrates') && fieldvaluefilter!='' && /^[0-9\s]*$/.test(fieldvaluefilter)==false){	//added for mv-693	
								//if the letter is not digit then display error and don't type anything					
							//display error message						
							msg +='Please provide number filter value.';							 
						}
						else if(typeof fieldvaluefilter != 'undefined' && fieldvaluefilter.trim() == "") {
							msg += "Please provide filter value.";
						}
					}	
			}
			if(msg != "") {
				break;
			}			
		}
	}
	if(validationstatus == false) {
		return "invalid pattern";
	}
	return msg;
}
/* End: MV-1823 */
//S:TS-1098
function resetfieldorderterm(field,userlist) {
	var fieldorder=[];
	var fieldorderT1=[];
	var fieldorderT=[];
	var fieldorderO=[];
	var indexCol = 0;
	var prevTempid = 0;
	var fieldName = "";
	var generate = false;
	var fieldValuesTS = ['serviceterms','tspersonalstartdate','tspersonalenddate','firstdate','recentdate','blackoutdates','approvedhrs','pendinghrs','disallowedhrs','tsstatus','tstimeoffcalendar','submittedhrs'];//TS-1395/phase-2
	if(userlist.length){
		var templateIds = userlist.map(item => item.TEMPLATEIDFK);
		userlist.forEach(function(item,i){
			for(indexCol = 1; indexCol<=item.PAIRID_COUNT;indexCol++){
				field.forEach(function(value,j){
					fieldName = value.split("_")[1];
					if(prevTempid != item.TEMPLATEIDFK && indexCol == 1){
						prevTempid = item.TEMPLATEIDFK;
					}
					if(fieldValuesTS.includes(fieldName) && (value.split("_").length === 3) && (prevTempid == value.split("_")[2])){//&& templateIds.includes(Number(value.split("_")[2])) 
						fieldorderT1.push(value + '_'+ indexCol);
					}else if(!fieldValuesTS.includes(fieldName) && (indexCol == item.PAIRID_COUNT) && (!fieldorderO.includes(value))){
						fieldorderO.push(value);
					}else if(value.split("_").length >= 4 && fieldValuesTS.includes(fieldName)){
						generate = true;
					}	
				});
			}
			fieldorderT = fieldorderT.concat(fieldorderT1);
			fieldorderT1 = [];
		});
		fieldorder = fieldorderO.concat(fieldorderT);
	}else{
		fieldorder = field;
	}
	if(generate){
		return field;
	} else{
		return fieldorder;
	}
	
}
//E:TS-1098

/* MV-2153:Start */
$j11(document).on('mouseover', '.SurveyParticipation', function(e){
    //stuff to do on mouseover	
	var ftype=$j11(this).attr('fieldtype');
	var spvalue=$j11(this).attr('columnvalue').trim();
	var spuserid=$j11(this).attr('userid').trim();
	var statusValue=$j11('#AStatus_'+spuserid).text();	
	if(ftype=='SurveyParticipation' && spvalue=='No' && statusValue=='Archived'){
		$j11('#LP_'+spuserid).removeClass("editfield");
	}
});
/* MV-2153:End */

