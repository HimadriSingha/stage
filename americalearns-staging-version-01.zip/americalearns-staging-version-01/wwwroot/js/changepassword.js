// this function is to open up the change password scroll down
function OpenChangePassword()
{
/* ADMINFUNCT-331 START */
		jQuery.ajax({
			type: "post",
			data: {
				currentuseremail: currentuseremail
			},
			url: "index.cfm?event=user.getPasswordHistory",
			success: function(data) {
				jQuery("#oldpasswords-hidden").val(JSON.stringify(data));
			}
		});
/* ADMINFUNCT-331 STOP */
	if (document.getElementById("div_changepassword").style.display == "none")
	{
		new Ajax.Request("/index.cfm?event=user.openchangepassword",{ 
	
				onSuccess: function(returnHtml) { 
	
				 Element.update("div_changepassword", returnHtml.responseText);
				 //Effect.SlideDown("div_changepassword");
				 jQuery('#div_changepassword').slideDown(1000);
				}, 
				onFailure: function(){ 
				alert('Oops...mistake on server');
				} 
			});
	}
	else
	{
		jQuery('#div_changepassword').slideUp(1000);
	}		
}

//this is to close the window when the cancel button is clicked.
function CancelCloseChangePassword()
{
	document.getElementById("imgLoadingChangePassword").style.display = "block";
	//Effect.SlideUp("div_changepassword");
	jQuery('#div_changepassword').slideUp(1000);
	document.getElementById("imgLoadingChangePassword").style.display = "none";
}

//this is to update the password for the user
/* Commented for ADMINFUNCT-34 
function updatePasswordwithValidations(currentUserid)
{
	var currentUserid = currentUserid;
	document.getElementById("imgLoadingChangePassword").style.display = "block";
	
	
	var PasswordEntered = trim(document.getElementById("txt_password").value,' ');
	var ConfirmPasswordEntered = trim(document.getElementById("txt_confirmpassword").value,' ');

	//checking the password and confirm passwords are the same
	if (PasswordEntered == ConfirmPasswordEntered)
	{
		//the entered password has to be more than 6 characters long
		if (PasswordEntered.length > 5)
		{
			var regexp = new RegExp ("^(?=.*[0-9]+.*)[0-9a-zA-Z!@$##%&^*=:_-~\s\-]{6,}$");

			if (PasswordEntered.match(regexp))
			{
				//entered password should have one alphabet 
				var regexp = new RegExp("^(?=.*[a-zA-Z]+.*)[0-9a-zA-Z!@$##%&^*=:_-~\s\-]{6,}$");
				
				if (PasswordEntered.match(regexp))
				{
					//entered password should have one number and one alphabet 
					var regexp = new RegExp("^(?=.*[0-9]+.*)(?=.*[a-zA-Z]+.*)[0-9a-zA-Z!@$##%&^*=:_-~\s\-]{6,}$");
			
					if (PasswordEntered.match(regexp))
					{
						//new Ajax.Request("/index.cfm?event=user.changeuserpassword&currentUserid="+currentUserid+"&PasswordEntered="+PasswordEntered,{ 
						//onSuccess: function(returnHtml) {				
				 //		document.getElementById("imgLoadingChangePassword").style.display = "none";
				 //		CancelCloseChangePassword();
				//		}, 
				//		onFailure: function(){ 
				//			alert('Oops...mistake on server');
				//			} 
				//		});
						var URL="/index.cfm?event=user.changeuserpassword&currentUserid="+currentUserid+"&PasswordEntered="+PasswordEntered;
						jQuery.ajax({url: URL , success: function(result){
							document.getElementById("imgLoadingChangePassword").style.display = "none";							
							if(result ==1)
								alert('Please enter an alternative password.');
							if(result ==0)
								CancelCloseChangePassword();
								
						}});
						
					}
					else
					{
						
					}
				}
				else
				{
					alert("All new passwords can contains only letters, numbers and special characters (!, @, $, #, %, &, ^, *, =, :, _, - and ~), and need to include at least one number and one letter. Please enter a different password.");
					document.getElementById("txt_password").value = "";
					document.getElementById("txt_confirmpassword").value = "";
					document.getElementById("imgLoadingChangePassword").style.display = "none";
					document.userpersonal.txt_password.focus();					
				}
				
			}
			else
			{
				alert("All new passwords can contains only letters, numbers and special characters (!, @, $, #, %, &, ^, *, =, :, _, - and ~), and need to include at least one number and one letter. Please enter a different password.");
				document.getElementById("txt_password").value = "";
				document.getElementById("txt_confirmpassword").value = "";
				document.getElementById("imgLoadingChangePassword").style.display = "none";
				document.userpersonal.txt_password.focus();				
			}		
			
		}
		else
		{
			alert("The password you entered is fewer than six characters in length.\n\nPlease create a new password that is at least six characters long, and contains at least one number and one letter.");
			document.getElementById("txt_password").value = "";
			document.getElementById("txt_confirmpassword").value = "";
			document.getElementById("imgLoadingChangePassword").style.display = "none";
			document.userpersonal.txt_password.focus();
		}
	}
	else
	{
		alert("Passwords in the \"New Password\" and \"Confirm Password\" boxes need to match. Please try again.");
		document.getElementById("txt_password").value = "";
		document.getElementById("txt_confirmpassword").value = "";
		document.getElementById("imgLoadingChangePassword").style.display = "none";
		document.userpersonal.txt_password.focus();
	}
	
	
}*/

function trim(str, chars) {
	return ltrim(rtrim(str, chars), chars);
}
 
function ltrim(str, chars) {
	chars = chars || "\\s";
	return str.replace(new RegExp("^[" + chars + "]+", "g"), "");
}
 
function rtrim(str, chars) {
	chars = chars || "\\s";
	return str.replace(new RegExp("[" + chars + "]+$", "g"), "");
}
//ADMINFUNCT-34
function charLength(passwordField)
{
	
	if(passwordField.length >= 8){
		document.getElementById("charLength").style.color="green";
		return true;
	}
	else{
		document.getElementById("charLength").style.color="#333333";
		return false;
	}
}

function OneUpperCase(passwordField)
{
	if(passwordField.match(/[A-Z]/)){
		document.getElementById("OneUpperCase").style.color="green";
		return true;
	}
	else{
		document.getElementById("OneUpperCase").style.color="#333333";
		return false;
	}
}
function OneLowerCase(passwordField)
{
	if(passwordField.match(/[a-z]/)){
		document.getElementById("OneLowerCase").style.color="green";
		return true;
	}
	else{
		document.getElementById("OneLowerCase").style.color="#333333";
		return false;
	}
}
function OneNumber(passwordField)
{
	if(passwordField.match(/[0-9]/)){
		document.getElementById("OneNumber").style.color="green";
		return true;		
	}
	else{
		document.getElementById("OneNumber").style.color="#333333";
		return false;
	}
}

function showHidePass(linkId)
{	
	if(linkId == "linkShowPass"){
		document.getElementById("textNewPassword").setAttribute("type", "text");
		document.getElementById("linkShowPass").style.display="none";
		document.getElementById("linkHidePass").style.display="block";
		}
	if(linkId == "linkHidePass"){
		document.getElementById("textNewPassword").setAttribute("type", "password");
		document.getElementById("linkHidePass").style.display="none";
		document.getElementById("linkShowPass").style.display="block";}
}

function checkPassReq()
{
	passwordField = document.getElementById("textNewPassword").value;
	confirmPasswordField = document.getElementById("textConfirmNewPassword").value;	
	
	//remId = document.getElementById("textNewPassword");
	//remId.addEventListener("keydown", KeyCheck);
	
	//for charLength
	charLength(passwordField);	
	//for OneUpperCase
	OneUpperCase(passwordField);		
	//for OneLowerCase
	OneLowerCase(passwordField);		
	//for OneNumbercharLength
	OneNumber(passwordField);
	
	if(confirmPasswordField.length>0)
		checkConfirmPass();
	
}

function checkConfirmPass()
{
	passwordField = document.getElementById("textNewPassword").value;
	confirmPasswordField = document.getElementById("textConfirmNewPassword").value;	
	if(passwordField == confirmPasswordField && passwordField.length == 0 && confirmPasswordField.length == 0)
	{
		document.getElementById("passMatchText").innerHTML = "";
	}
	else if(passwordField == confirmPasswordField)
	{
		if (charLength(passwordField) == true && OneUpperCase(passwordField) == true && OneLowerCase(passwordField) == true && OneNumber(passwordField) == true)
		{
			document.getElementById("passMatchText").innerHTML="Passwords match!";
			document.getElementById("passMatchText").style.color="green";
			return true;
		}		
		else
		{
			document.getElementById("passMatchText").innerHTML="Password criteria not fulfilled!";
			document.getElementById("passMatchText").style.color="red";
			document.getElementById("textNewPassword").focus();
			//document.getElementById("textNewPassword").style.border = "1px solid red";
			return false;
		}
		
	}
	else
	{
		document.getElementById("passMatchText").innerHTML="Passwords do not match yet.";
		document.getElementById("passMatchText").style.color="red";
		return false;
	}
}

function checkValid(currentUserid)
{
	passwordField = document.getElementById("textNewPassword").value;
	confirmPasswordField = document.getElementById("textConfirmNewPassword").value;    
	//alert(passwordField)
	//alert(charLength(passwordField));	
	//alert(charLength(confirmPasswordField))
	//alert(checkConfirmPass())
	//for OneUpperCase
	//alert(OneUpperCase(passwordField));		
	//for OneLowerCase
	//alert(OneLowerCase(passwordField));		
	//for OneNumbercharLength
	//alert(OneNumber(passwordField));
	
	//if(confirmPasswordField.length>0)
//		checkConfirmPass();
/* adminfunct-331 Start anurag*/
	if (passwordField === confirmPasswordField) {
		var oldPasswords = JSON.parse(jQuery("#oldpasswords-hidden").val());
		jQuery.ajax({
			type: "post",
			data: {
				passwordField: passwordField
			},
			url: "index.cfm?event=user.getPasswordHashed",
			success: function(data) {
				var data = data.trim();
				if (oldPasswords.includes(data)) {
					document.getElementById("passMatchText").innerHTML="Please choose a password you have not used recently.";
					document.getElementById("passMatchText").style.color="red";
					document.getElementById("textNewPassword").focus();
					document.getElementById("textNewPassword").style.border = "1px solid red";
				}
				else{
					continueValidation(currentUserid);
				}
			}
		});
	}
/* adminfunct-331 Stop anurag*/
	
}

function continueValidation(currentUserid){
	if(passwordField.length >= 150)
    {
	    document.getElementById("passMatchText").innerHTML="Password is very lengthy!";
		document.getElementById("passMatchText").style.color="red";
		document.getElementById("textNewPassword").focus();
		document.getElementById("textNewPassword").style.border = "1px solid red";
        return false;
    }
	else if(passwordField.length == 0)
	{
		document.getElementById("passMatchText").innerHTML="Password is required!";
		document.getElementById("passMatchText").style.color="red";
		document.getElementById("textNewPassword").focus();
		return false;
	}
	else if(confirmPasswordField.length == 0)
	{
		document.getElementById("passMatchText").innerHTML="Confirm Password is required!";
		document.getElementById("passMatchText").style.color="red";
		document.getElementById("textConfirmNewPassword").focus();
		return false;
	}
    else if (charLength(passwordField) == true && charLength(confirmPasswordField) == true && checkConfirmPass()==true && OneUpperCase(passwordField) == true && OneLowerCase(passwordField) == true && OneNumber(passwordField) == true)
	{
		
		document.getElementById("imgLoadingChangePassword").style.display = "block";
		var URL="/index.cfm?event=user.changepassword&currentUserid="+currentUserid+"&PasswordEntered="+encodeURIComponent(passwordField);
		jQuery.ajax({url: URL, success: function(result){
			document.getElementById("imgLoadingChangePassword").style.display = "none";							
			jQuery('#passsuccssfully').css('display', 'block');
			jQuery('#passsuccssfully').text('Password Reset Successfully');
			jQuery('#resetpass').text('Reset Again');
			CancelCloseChangePassword();
				
		}});
	}else{
		document.getElementById("passMatchText").innerHTML="Password criteria not fulfilled!";
		document.getElementById("passMatchText").style.color="red";
		document.getElementById("textNewPassword").focus();
		return false;
	}
  
	
}