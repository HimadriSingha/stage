var tmp = 0;
var $dialog = {}; //MV-2153
window.bit_change = 0;		//MV-1697::MV-1779
$(document).ready(function () {

    if ($('#allowedsection').val() == 'add' || $('#allowedsection').val() == 'view' || $('#allowedsection').val() == 'add_view') {
        $('#action_box').css('padding-bottom', '30px');
        $('#action_box').hide();
        $('#search_box').css('margin-bottom', '10px')
    }

    /*begin loading image*/
    if ($('body').find('#ajaxFilterLoading').attr('id') != 'ajaxFilterLoading') {
        var html = '<div id="ajaxFilterLoading" style="display:none"><img id="loading" src="../../images/icons/animated_loading.gif"><div>';
        html += '<div></div></div><div class="bg"></div></div>'
        $('body').append(html);
    }

    var height = $('body').outerHeight();
    var width = $('body').outerWidth();
    $('#ajaxFilterLoading').css({
        'width': '100%',
        'height': '100%',
        'position': 'fixed',
        'z-index': '10000000',
        'top': '0',
        'left': '0'
    });

    $('#ajaxFilterLoading .bg').css({
        'background': '#000000',
        'opacity': '0.15',
        'width': '100%',
        'height': '100%',
        'position': 'absolute',
        'top': '0'
    });

    $('#ajaxFilterLoading>div:first').css({
        'width': '100%',
        'text-align': 'center',
        'position': 'absolute',
        'left': '0',
        'top': '48%',
        'font-size': '16px',
        'z-index': '10',
        'color': '#ffffff'
    });
    /*end loading image*/

    $('#frm_volunteer_list').submit(function (e) {
        e.preventDefault();
        e.stopImmediatePropagation();
        //$('#search_icon_new').trigger('click');
        $('.search_inactive').trigger('click');
    });

    $(document).keydown(function (e) { /* MS-147*/
        e.stopImmediatePropagation();
        var element = e.target.nodeName.toLowerCase();
        if (element == 'div') {
            if (e.keyCode === 8) {
                return false;
            }
        }
    });
    //var bit_change = 0;		//MV-1779
    var bit_rad = 0;    //MV-1697
    $('#rad_saved_views').click(function (e) { /* MS-147*/
        //$(document).on('click','#rad_saved_views',function(){
        e.stopImmediatePropagation();
        if ($('#insidebox_saved').css('display') == 'none') {
            var saved_views = $('#insidebox_saved_views');
            var $saved_view_string = '';
            var _this = $(this);
            var savedviewselected = $('#savedviewselection').val();  //MV-1697

            var truecall = 0;
            savedviewselected = $.trim(savedviewselected);
            var _current_time_cache = new Date().getTime();             //MV-1697
            $(this).prop("checked",true);
            $.ajax({
                type: "post",
                url: "index.cfm?event=user.savedviewsForStaffs&currenttimestamp="+_current_time_cache,          //MV-1697
                data: [],
                dataType: "json",
                beforeSend: function () {
                    showLoadingOverlay();
                },
                success: function (data) {
                    $saved_view_string = '<div>';
                    $.each(data.savedviews, function (key, saved_view) {
                        // $saved_view_string = $saved_view_string + '<div class="radio show_sectn"><label><input type="radio" name="' + saved_view.name + '" id="' + saved_view.id + '" value="' + saved_view.value + '">' + saved_view.displayname + '</label></div>';
                        let isDefaultRel = 0;
                        let defaultView = '<div class="isDefaultView" id="isDefaultView_' + saved_view.value + '" style="display:none">(Current Default View)</div>';
                        if (saved_view.isDefaultView) {
                            defaultView = '<div class="isDefaultView" id="isDefaultView_' + saved_view.value + '" style="display:inline-block;">(Current Default View)</div>';
                            isDefaultRel = 1;   
                        }  
                        $saved_view_string = $saved_view_string
                            + '<div class="radio show_sectn setradiopanel"><label class="setradiopanllabel" id="saved_view_label_'
                            + saved_view.value
                            + '"><input rel="' + isDefaultRel + '" type="radio" name="'
                            + saved_view.name
                            + '" id="'
                            + saved_view.id
                            + '" value="'
                            + saved_view.value
                            + '" sid="'
                            + saved_view.value
                            + '">' + saved_view.displayname
                            + '</label> ' + defaultView
                            + ' <div class="defaultViewManage" id="defaultViewManage_'
                            + saved_view.value
                            + '" style="display: none;"><a href="javascript:void(0);" class="btn_makeDefault" id="btn_makeDefault_'
                            + saved_view.value
                            + '">Make Default</a> '
                            + '<a class="btn_rename" id="btn_rename_' + saved_view.value + '" href="javascript:void(0);">Rename</a> '
                            + '<a href="javascript:void(0);" class="btn_delete" id="btn_delete_' + saved_view.value + '">Delete</a>'
                            + '</div></div>';

                    });
                    $saved_view_string = $saved_view_string + '</div>';

                    saved_views.html($saved_view_string);

                    var activeView = $("#" + data['default']);

                    //savedviewselected !='defaultView'
                    if (savedviewselected.length != 0) {
                        //alert(savedviewselected);
                        truecall = 1;
                        alphabeticFilterhid = $('#alphabeticFilterhid').val();
                        searchfilterhid = $('#strsearchhid').val();
                        intstartrowhid = $('#intstartrowhid').val();
                        sortColumnhid = $('#sortColumnhid').val();
                        sortTypehid = $('#sortTypehid').val();
                        if($.trim(alphabeticFilterhid) != ''){  /* MS 147 */
                            $('#' + alphabeticFilterhid).parent().addClass('active');
                            $('#' + alphabeticFilterhid).parent().siblings('li').removeClass('active');
                        }  /* MS 147 */
                        $('#alphabeticFilter').val(alphabeticFilterhid);
                        $('#str_search').val(searchfilterhid);
                        $('#sortColumn').val(sortColumnhid);
                        $('#sortType').val(sortTypehid);
                        if (savedviewselected == 'AllactivestaffView') {
                            $("#" + savedviewselected).val('');
                            $('#btn_delete').hide();
                        }
                        else {
                            $('#btn_delete').show();
                        }
                        $("#" + savedviewselected).prop('checked', true);
                        $('#insidebox_customize').slideUp(1000);
                        $('#insidebox_saved').css('display', 'block');
                        rendersavedview();
                    } else {
                        truecall = 0;
                        $("#" + data['default']).prop('checked', true);
                        $('#insidebox_new_member').slideUp(1000);
                        $('#user_remaining').hide();
                        $('#insidebox_customize').slideUp(1000);
                        $('#insidebox_saved').slideDown(1000);
                        $('#btn_delete').hide();
                    }
                    $("#" + data['default']).attr('value', "0");
                    //MV-1368 :: 1402
  					var selectedViews=$("#hidselectedsavedviewreload").val();
  					if(selectedViews==0 || selectedViews == 'AllactivestaffView' ){
  						$("#AllactivestaffView").prop('checked', true);
  					}else{
  						$("#saved_view_"+selectedViews).prop('checked', true);						
  					}
  					//MV-1368 :: 1402
                },
                complete: function () {
                    if (truecall == 0)
                        hideLoadingOverlay();
                },
                error: function (data) {

                }
            });
        } else {
            $(this).prop('checked', false);
            $('#insidebox_saved').slideUp(1000);      //MV-1697::1827
        }
    });
    
    /* Ms-147 (29-08-2022) :: Start*/
    var frmData = [];
    var saved_views = $('#insidebox_saved_views');
    var $saved_view_string = '';
    //MV-1697::MV-1801  Detect safari and back press in browser
    var ua = navigator.userAgent.toLowerCase(); 
    if (ua.indexOf('safari') != -1) { 
    if (ua.indexOf('chrome') > -1) { 
    } else {
        window.addEventListener('beforeunload', () => {                 
            $('#tempid').val(0);        
          }); 
    }
    }
    //MV-1697::MV-1801  Detect safari and back press in browser
    if (($.trim($('#intstartrowhid').val()).length == 0 || $.trim($('#intstartrowhid').val()).length == 1) 
            && $('#tempid').val() == 0){              //MV-1697::MV-1801
     /* MV-1697 */
    var hidselectedviews = '';
    var hidselectedview_idd = '';
    var savedviewselected_onload = '';
    if ($('#savedviewselection').val().length != 0) {
        bit_rad = 1;
        tmp = 1;
        $('#tempid').val(tmp);
         savedviewselected_onload = $('#savedviewselection').val();
        if(savedviewselected_onload == 'AllactivestaffView'){
            hidselectedview_idd = 'AllactivestaffView';
            $('#hidselectedsavedviewreload').val(hidselectedview_idd);
        }
        else{
            hidselectedviews = savedviewselected_onload.split("_")[2];
            $('#hidselectedsavedviewreload').val(hidselectedviews);
        }
    }
    /* MV-1697 */
        var savedviewselected = $('#savedviewselection').val();
        var hidselectedview_id = '';
        var hidselectedview = '';
        if(savedviewselected == 'AllactivestaffView'){
			 hidselectedview_id = 'AllactivestaffView';
		}
        else if(savedviewselected != '' || savedviewselected.length != 0 ){
             hidselectedview = savedviewselected.split("_")[2];
            }   
        var alphabeticFilterhid = $('#alphabeticFilterhid').val();
   		var searchfilterhid = $('#strsearchhid').val(); 
        var _current_time_cache = new Date().getTime();             //MV-1697
        /* MV-1697 */
    if(bit_rad == 0){           //MV-1697
      $.ajax({
          type: "post",
          url: "index.cfm?event=user.savedviewsForStaffs&currenttimestamp="+_current_time_cache,            //MV-1697
          data: [],
          dataType: "json",
          beforeSend: function () {
              showLoadingOverlay();
          },
          success: function (data) {
              $saved_view_string = '<div>';
              $.each(data.savedviews, function (key, saved_view) {
                  // $saved_view_string = $saved_view_string + '<div class="radio show_sectn"><label><input type="radio" name="' + saved_view.name + '" id="' + saved_view.id + '" value="' + saved_view.value + '">' + saved_view.displayname + '</label></div>';
                  let isDefaultRel = 0;
                  let defaultView = '<div class="isDefaultView" id="isDefaultView_' + saved_view.value + '" style="display:none">(Current Default View)</div>';
                  if (saved_view.isDefaultView) {
                      defaultView = '<div class="isDefaultView" id="isDefaultView_' + saved_view.value + '" style="display:inline-block;">(Current Default View)</div>';
                      isDefaultRel = 1;   
                  }
                  $saved_view_string = $saved_view_string
                      + '<div class="radio show_sectn"><label id="saved_view_label_'
                      + saved_view.value
                      + '"><input rel="' + isDefaultRel + '" type="radio" name="'
                      + saved_view.name
                      + '" id="'
                      + saved_view.id
                      + '" value="'
                      + saved_view.value
                      + '" sid="'
                      + saved_view.value
                      + '">' + saved_view.displayname 
                      + '</label> ' + defaultView
                      + ' <div class="defaultViewManage" id="defaultViewManage_'
                      + saved_view.value
                      + '" style="display: none;"><a href="javascript:void(0);" class="btn_makeDefault" id="btn_makeDefault_'
                      + saved_view.value
                      + '">Make Default</a> '
                      + '<a class="btn_rename" id="btn_rename_' + saved_view.value + '" href="javascript:void(0);">Rename</a> '
                      + '<a href="javascript:void(0);" class="btn_delete" id="btn_delete_' + saved_view.value + '">Delete</a>'
                      + '</div></div>';
                    
              });
              $saved_view_string = $saved_view_string + '</div>';

              saved_views.html($saved_view_string);
              var activeView = $("#" + data['default']).prop("checked",true);
              var data_saved = $("input[name='saved_view']:checked").attr('sid');
             
              var savedID = $("input[name='saved_view']:checked").attr('id');
              var staffcusttoken = $('#staffcusttoken').val();
              if(savedID == 'AllactivestaffView') {
                  frmData.push({
                      "name": "savedID",
                      "value": savedID
                  });
                  /*--- MV-1697 ---*/
                  if($('#rad_saved_views').is(':checked')){
					if($.trim(alphabeticFilterhid) != ''){ 
						$('#' + alphabeticFilterhid).parent().addClass('active');
						$('#' + alphabeticFilterhid).parent().siblings('li').removeClass('active');
						frmData.push({
							"name": "alphabeticFilter",
							"value": alphabeticFilterhid
						});
					} 
					frmData.push({
						"name": "searchfilter",
						"value": searchfilterhid
					});
                  }
					/*--- MV-1697 ---*/
              }else{
                /* MV-1697 */
                    if(hidselectedview_id == 'AllactivestaffView'){
                        frmData.push({
                            "name": "savedID",
                            "value": hidselectedview_id
                        });
                        if($.trim(alphabeticFilterhid) != ''){ 
                            $('#' + alphabeticFilterhid).parent().addClass('active');
                            $('#' + alphabeticFilterhid).parent().siblings('li').removeClass('active');
                            frmData.push({
                                "name": "alphabeticFilter",
                                "value": alphabeticFilterhid
                            });
                        } 
                        frmData.push({
                            "name": "searchfilter",
                            "value": searchfilterhid
                        });
                    }
					else if(hidselectedview > 0){
			            //MV-1368::1402
			            var selectedViews=$("#hidselectedsavedviewreload").val();
			            if(hidselectedview != selectedViews){
			                hidselectedview = selectedViews;
			            }
						//MV-1368::1402
						if($.trim(alphabeticFilterhid) != ''){ 
                            $('#' + alphabeticFilterhid).parent().addClass('active');
                            $('#' + alphabeticFilterhid).parent().siblings('li').removeClass('active');
							//$('#alphabeticFilter').val(alphabeticFilterhid);
							frmData.push({
								"name": "alphabeticFilter",
								"value": alphabeticFilterhid
							});
                        } 
						frmData.push({
							"name": "searchfilter",
							"value": searchfilterhid
						});
						frmData.push({
							"name": "saved_view",
							"value": hidselectedview
						});
					}
                    /* MV-1697 */
					else{
	                frmData.push({
	                    "name": "saved_view",
	                    "value": data_saved
	                });
					}
              }
              frmData.push({
                  "name": "bit_all_enrolled",
                  "value": 1
              });
              /* MS 147 */
              frmData.push({
                  "name": "staffcusttoken",
                  "value": staffcusttoken
              });
           
              tmp = 1;
              $('#tempid').val(tmp);
              loadUsersList(frmData, "");
              $('#checksaved').val(1);
           
          },
          complete: function () {
            // hide overloading remove
          },
          error: function (data) {
            
          }
      });
    }       //MV-1697
  }

 $('body').data('formdata', frmData);
 /* Ms-147 (29-08-2022) :: End*/
    /* customize view start here*/
    $('#rad_customize_view').click(function (e) { //MS 147
        e.stopImmediatePropagation();//MS 147
        $('#insidebox_customize_main_replace').remove(); //MS 147
        var custviewselected = $('#customizedviewselection').val();
        custviewselected = $.trim(custviewselected);
        truecall = 0;
        if ($('#insidebox_customize').css('display') == 'none') {
            if ($('#bit_all_enrolled').length != 0) {
                $('#str_view_name').val('');//Added by MN
                $('#str_view_name').trigger('keyup','#str_view_name');//Added by MN
                $('#insidebox_saved').slideUp(1000);
                $('#insidebox_customize').slideDown(1000);
            } else {
                var $showText = '';
                var $subshowtext = '';
                var insidebox_customize_main = $('#insidebox_customize_main');
                showLoadingOverlay();
                $.ajax({
                    type: "post",
                    url: "index.cfm?event=user.customizeViewSectionForStaff",
                    data: [],
                    dataType: "json",
                    success: function (data) {
                        $('#str_view_name').val('');//Added by MN
                        $('#str_view_name').trigger('keyup','#str_view_name');//Added by MN
                        /*	var displayname = data.optionalbreak ;
                            console.log(displayname);*/
                        /*var customview = data.customview;
                        var show = customview.show;
                        var column = customview.Column;
                        var optionalbreak = customview.optionalbreak;
                        var viewname = customview.viewname;*/

                        $showText = $showText + '<div class="padding-left-5 >show : <div class="padding-left-10"></div><div class="padding-left-10">';
                        $subshowtext = $subshowtext + '<div class="sub_radio show_sectn">';
                        $subshowtext = $subshowtext + '</div>';
                        $showText = $showText + '<div class="radio show_sectn">';
                        $.each(data.show, function (index, showEl) {
                            if (showEl.id == 'bit_all_enrolled') {
                                $showText = $showText + '<label><input class="enrollvol" type="checkbox" name="' + showEl.name + '" id="' + showEl.id + '" value="' + showEl.value + '">' + showEl.displayname + '</label>' + $subshowtext;
                            } else if (showEl.id == 'bit_not_enrolled') {
                                $showText = $showText + '<div class="clear"></div><label><input class="enrollvol" type="checkbox" name="' + showEl.name + '" id="' + showEl.id + '" value="' + showEl.value + '">' + showEl.displayname + '</label>';
                            }
                        });
                        $showText = $showText + '</div></div><div>--------------</div></div>';
                        $showText = $showText + '<div><div class="padding-top-5">';
                        $showText = $showText + '<div class="padding-left-5 sectiontitle"><a href="javascript:void(0);" id="column-selection-link"> Column Selection </a></div>';/*Sitemanage-188*/
                        $showText = $showText + '<div class="hide" id="column-selection-list" style="display: none;"><div class="padding-top-5 padding-left-15"><a href="javascript:void(0);" id="column-selection-selectall">Select All</a></div><div class="padding-top-5 padding-left-15">';

                        $.each(data.Column[0].data, function (index, columnEl) {
                            if (typeof columnEl.data == 'object') {
                                $showText = $showText + '<div class="radio show_sectn"><span id="changeArrowid" class="changeArrow pull-left showarrow"></span> <label class="assignment_header"><input type="checkbox" class="columns" name="' + htmlEncode(columnEl.name) + '" id="' + columnEl.id + '" value="">' + columnEl.displayname + '</label><div class="assignment_box margin-left-45" style="display: none;"><div class="padding-top-5 no-left-padding">';
                                $.each(columnEl.data, function (index, aa_type1El) {
                                    if (typeof aa_type1El.data == 'object') {
                                        $showText = $showText + '<div class="radio show_sectn" style="width:320px;"><label class="assignment_header" style="word-break: break-all; padding-right:10px"><input type="checkbox" class="columns" name="' + aa_type1El.name + '" id="' + aa_type1El.id + '" value="">' + htmlEncode(aa_type1El.displayname) + '</label><div class="assignment_box margin-left-25" style="display:none;"><div class="padding-top-5 no-left-padding">';//MCR-58
                                        $.each(aa_type1El.data, function (index, aa_type1El1) {
                                            if (typeof aa_type1El1.data == 'object') {
                                                $showText = $showText + '<div class="radio show_sectn"><label class="assignment_header" style="word-break: break-all; padding-right:10px"><input type="checkbox" class="columns" name="' + aa_type1El1.name + '" id="' + aa_type1El1.id + '" value="">' + htmlEncode(aa_type1El1.displayname) + '</label><div class="assignment_box margin-left-25" style="display:none;"><div class="overflow-122 padding-top-5 no-left-padding">'; //MCR-58
                                                $.each(aa_type1El1.data, function (index, aa_type1El12) {
                                                    $showText = $showText + '<div class="radio show_sectn"><label class="no-left-padding-1" style="word-break: break-all; padding-right:10px"><input type="checkbox" class="columns_sub" name="' + aa_type1El12.name + '" id="' + aa_type1El12.id + '" value="' + htmlEncode(aa_type1El12.value) + '">' + htmlEncode(aa_type1El12.displayname) + '</label></div>';
                                                });
                                                $showText = $showText + '</div></div>';
                                            } else {
                                                if (aa_type1El1.name != 'dontshow')//MV-653
                                                    $showText = $showText + '<div class="radio show_sectn"><label><input type="checkbox" class="columns" name="' + aa_type1El1.name + '" id="' + aa_type1El1.id + '" value="' + htmlEncode(aa_type1El1.value) + '">' + aa_type1El1.displayname + '</label>';
                                            }
                                            if (aa_type1El1.name != 'dontshow')
                                                $showText = $showText + '</div>';
                                        });
                                        $showText = $showText + '</div></div>';
                                    } else {
                                        if (aa_type1El.name != 'dontshow')//MV-653
                                            $showText = $showText + '<div class="radio show_sectn" style="width:320px;"><label><input type="checkbox" class="columns" name="' + aa_type1El.name + '" id="' + aa_type1El.id + '" value="' + htmlEncode(aa_type1El.value) + '">' + aa_type1El.displayname + '</label>';
                                    }
                                    if (aa_type1El.name != 'dontshow')
                                        $showText = $showText + '</div>';
                                });
                                $showText = $showText + '</div></div>';
                                //end
                            } else {
                                if (columnEl.name != 'dontshow')//MV-653
                                    $showText = $showText + '<div class="radio show_sectn"><label><input type="checkbox" class="columnsfgfgfg" name="' + columnEl.name + '" id="' + columnEl.id + '" value="' + columnEl.value + '">' + columnEl.displayname + '</label>';
                            } if (columnEl.name != 'dontshow')
                                $showText = $showText + '</div>';
                        });
                        $showText = $showText + '</div></div>';  //</div>';

                        /*column selectionn*/
                        if (data.optionalbreak[0]) {
                            $showText = $showText + '<div class="padding-top-5"><div class="padding-left-5 sectiontitle"><a href="javascript:void(0);" id="breakoutby-link"> Optional: Break Out By </a></div><div class="hide" id="breakoutby-list" style="display: none;"><div class="padding-left-15">';
                        }

                        $.each(data.optionalbreak[0].data, function (index, optionalbreakEl) {

                            if (optionalbreakEl.id === "str_none_break_out") {
                                $showText = $showText + '<div class="radio show_sectn"><label class="none_break_hdr"><input type="radio" class="assignment_columns" name="' + optionalbreakEl.name + '" id="' + optionalbreakEl.id + '" value="' + optionalbreakEl.value + '">' + optionalbreakEl.displayname + '</label>';
                            /* MV-2153(K):Start */
							} else if (optionalbreakEl.id === "str_account_status_assgmnt_optnl_break_out") {
								$showText = $showText + '<div class="radio show_sectn"><label class="asso_assign_break_hdr"><input type="radio" class="assignment_columns" name="' + optionalbreakEl.name + '" id="' + optionalbreakEl.id + '" value="' + optionalbreakEl.value + '">' + optionalbreakEl.displayname + '</label>';
							 	$showText = $showText + '<div id="account-toggle-wrapper" class="account-toggle-wrapper">';
								 $showText = $showText + '<div id="accountBox" class="account-status-box">';
								 $showText = $showText + `<div class="padding-top-5"><a href="javascript:void(0);" id="account-status-option-break-selectall" onclick="selectUnselect(this,'vol_account_status');">Select All</a></div>`
								$showText = $showText + '<label id="status_1"><input type="checkbox" class="vol_account_status" name="account_status" value="Live">Live</label>';
								$showText = $showText + '<label id="status_2"><input type="checkbox" class="vol_account_status" name="account_status" value="Invited">Invited</label>';
								$showText = $showText + '<label id="status_3"><input type="checkbox" class="vol_account_status" name="account_status" value="Awaiting Invitation">Awaiting Invitation</label>';
								$showText = $showText + '<label id="status_4"><input type="checkbox" class="vol_account_status" name="account_status" value="Archived">Archived</label>';
								$showText = $showText + '</div>';
								$showText = $showText + '</div>';
                            /* MV-2153(K):Stop */
                            } else if (optionalbreakEl.id === "str_site_assgmnt_optnl_break_out") {
                                $showText = $showText + '<div class="radio show_sectn"><label class="asso_assign_break_hdr"><input type="radio" class="assignment_columns" name="' + optionalbreakEl.name + '" id="' + optionalbreakEl.id + '" value="' + optionalbreakEl.value + '">' + optionalbreakEl.displayname + '</label><div id="site_assgment_break_box1" class="asso_assign_break_box overflowBox-130 inner-bordered-box margin-top-5 margin-left-35" style="display: none;"><div>Show:</div><div class="no-left-padding">';
                                $.each(optionalbreakEl.data, function (index, optionalbreakoption1El) {
                                    $showText = $showText + '<div class="radio show_sectn"><label class="no-left-padding-1"><input type="checkbox" class="siteassign_select" name="' + optionalbreakoption1El.name + '" id="' + optionalbreakoption1El.id + '" value="all_enrolled">' + optionalbreakoption1El.displayname + '</label></div>';

                                });

                                $showText = $showText + '<div>--------------</div><div class="padding-top-5"><a href="javascript:void(0);" id="option-break-selectall-site" onclick="selectUnselect(this,&#39;site_assignments&#39;);">Select All</a></div><br>'; //MS-147 + MS-163

                                $.each(optionalbreakEl.other, function (index, optionalbreakoption1otherEl) {
                                    if (optionalbreakoption1otherEl.displayname == '*Unassigned') {
                                        var className = "";
                                    } else {
                                        var className = "hide";
                                    }
                                    $showText = $showText + '<div class="option_break_type1 radio ' + className + '"><label class="no-left-padding-1"><input type="checkbox" class="site_assignments" name="' + optionalbreakoption1otherEl.name + '" id="' + optionalbreakoption1otherEl.id + '" value="' + optionalbreakoption1otherEl.value + '" data-active="' + optionalbreakoption1otherEl.active + '">' + optionalbreakoption1otherEl.displayname + '</label></div>';
                                });
                                $showText = $showText + '</div></div>';
                            }
                            else if (optionalbreakEl.id === "str_staffrole_optnl_break_out") {
                                $showText = $showText + '<div class="radio show_sectn"><label class="asso_assign_break_hdr"><input type="radio" class="assignment_columns" name="' + optionalbreakEl.name + '" id="' + optionalbreakEl.id + '" value="' + optionalbreakEl.value + '">' + optionalbreakEl.displayname + '</label><div id="assoc_assgment_break_box3" class="asso_assign_break_box overflowBox-130 inner-bordered-box margin-top-5 margin-left-35" style="display: none;">';

                                $showText = $showText + '<div class="padding-top-5"><a href="javascript:void(0);" id="option-break-selectall-role" onclick="selectUnselect(this,&#39;role_assignments&#39;);">Select All</a></div><br>'; //MS-147 + MS-161
                                $.each(optionalbreakEl.data, function (index, optionalbreakEl) {
                                    $showText = $showText + '<div class="radio show_sectn"><label class="no-left-padding-1"><input type="checkbox" class="role_assignments" name="' + optionalbreakEl.name + '" id="' + optionalbreakEl.id + '" value="' + optionalbreakEl.value + '">' + optionalbreakEl.displayname + '</label></div>';
                                });
                                $showText = $showText + '</div>';
                            }
                            $showText = $showText + '</div>';

                        });

                        $showText = $showText + '</div></div></div></div><div class="padding-top-5 padding-left-5" style=" width: 320px; "><label for="str_view_name">' + data.viewname[0].displayname + '</label> <input type="text" id="str_view_name" name="' + data.viewname[0].name + '" value="" maxlength="80" style="width:170px"><br><span class="help-text">80 characters remaining</span></div></div></div>';
                        /* customize view End here*/

                        insidebox_customize_main.html($showText);
                        if (custviewselected.length != 0) {
                            cuatarr = custviewselected.split(",");
                            truecall = 1;
                            $.each(cuatarr, function (i) {
                                //alert(cuatarr[i]);
                                $('#' + cuatarr[i]).prop('checked', true);
                            });
                            $('#str_none_break_out').prop('checked', true);
                            $('#insidebox_saved').slideUp(1000);
                            $('#insidebox_customize').css('display', 'block');
                            rendercustomisedview();

                        } else {
                            truecall = 0;
                            $('#bit_all_enrolled').prop('checked', true);
                            $('#str_none_break_out').prop('checked', true);
                            $('#insidebox_saved').slideUp(1000);
                            $('#insidebox_customize').slideDown(1000);
                            $('#insidebox_new_member').slideUp(1000);
                            $('#user_remaining').hide();
                        }
                        if (truecall == 0)
                            hideLoadingOverlay();
                        $('#retain_customize_val').val(1);// MV-2153(K) //
                    },
                    error: function (data) {

                    }
                });
            }
        }else {
            $(this).prop('checked', false);
            $('#insidebox_customize').slideUp(1000);
        }
    });
    /*  MV-1697 -- Retain saved View */
    if($('#rad_add_member').is(':checked'))
    {
        $('#rad_add_member').trigger('click');	
    }
    else if($('#rad_saved_views').is(':checked'))
    {
        if($('#rad_saved_views').is(':checked') == true){
            if($('#retain_rad_val').val() == 1){
                $('#rad_saved_views').prop('checked', true);
            }
            else{
		        $('#rad_saved_views').trigger('click');	
		        $('#rad_saved_views').prop('checked', true);    //UI-Fix
            }
        }
    }
    else if($('#rad_customize_view').is(':checked'))
    {  
        // $('#rad_customize_view').prop('checked', true);     //UI-Fix
        // MV-2153(K):Start //
        if($('#retain_customize_val').val() == 1){
            $('#rad_customize_view').prop('checked', true)
        }else{
            $('#rad_customize_view').trigger('click');
           
        }
        // MV-2153(K):Stop //
    }
    else  												
    {  //Start 
        if ($('#alphabeticFilterhid').val() != '') {
        //alert($('#alphabeticFilterhid').val());
            renderalphabeticfilter();
         }
        else {
        //alert($('#alphabeticFilterhid').val());
         renderprevnextlink();
         }
    } //End
/*  MV-1697 -- Retain saved View */

    //$('#str_site_assgmnt_optnl_break_out_all_active, #str_site_assgmnt_optnl_break_out_all_inactive').change(function(e) {
    $(document).on('change', '#str_site_assgmnt_optnl_break_out_all_active, #str_site_assgmnt_optnl_break_out_all_inactive', function (e) {    /* MS-147*/
        e.stopImmediatePropagation(); /* MS-147*/
        var elements_active = $('.option_break_type1 label input[data-active=1]');
        var elements_inactive = $('.option_break_type1 label input[data-active=0]');

        if ($('#str_site_assgmnt_optnl_break_out_all_active').is(':checked')) {
            elements_active.parent().parent().show();
            elements_active.prop("disabled",false);//MV-2198
        } else {
            elements_active.parent().parent().hide();
            elements_active.prop("disabled",true);//MV-2198
        }
        if ($('#str_site_assgmnt_optnl_break_out_all_inactive').is(':checked')) {
            elements_inactive.parent().parent().show();
            elements_inactive.prop("disabled",false);//MV-2198
        } else {
            elements_inactive.parent().parent().hide();
            elements_inactive.prop("disabled",true);//MV-2198
        }
        var totalcount = $(".option_break_type1 :visible").find('input[type="checkbox"]').length;
        var checkedcount = $(".option_break_type1 :visible").find('input[type="checkbox"]:checked').length;
        if (totalcount == checkedcount) {
            $('#option-break-selectall-site').html('Select None');
        }
        if (totalcount > checkedcount) {
            $('#option-break-selectall-site').html('Select All');
        }
    });

    /* commented for MS-147 */
    // $(document).on('click','input[name=saved_view]',function(e){
    // //$('input[name=saved_view]').click(function() {
    //     e.stopImmediatePropagation();
    //     if ($(this).val()>0 ) {
    //         $('#btn_delete').show();
    //     } else {
    //         $('#btn_delete').hide();
    //     }
    // });

    $(document).on('click', '.btn_delete', function (e) {  /* MS-147*/
        e.stopImmediatePropagation();  /* MS-147*/
        var staffsavedtoken = $('#staffsavedtoken').val();
        var saved_view_name = '';
        var selectedView = $('#insidebox_saved_views .radio input:radio:checked');
        saved_view_name = selectedView.parent().text();
        value = selectedView.attr('sid');

        var values = {
            "viewid": value,
            "staffsavedtoken": staffsavedtoken
        }
        $('.view_success_message').slideUp(1000)
        if (confirm('Are you sure you want to delete the saved view, "' + saved_view_name + '" ?')) {
            showLoadingOverlay();
            $.ajax({
                type: "post",
                url: "index.cfm?event=user.deleteaStaffview",
                data: values,
                dataType: "json",
                success: function (resp) {
                    selectedView.parent().parent().remove();
                    $('#view_success_msg').html(resp.data.msg);
                    $('.view_success_message').removeClass('hide').slideDown(1000);
                    hideLoadingOverlay();
                    $('#AllactivestaffView').prop('checked', true);   //MS-147
                },
                error: function (resp) {

                }
            });
        }

    });

    $(document).on('change', '#check_all', function (e) {  /* MS-147*/
        e.stopImmediatePropagation();   /* MS-147*/
        if ($(this).is(':checked')) {
            $('input[name=userid_list]').prop('checked', true);
            setSelectedCount(false);
        } else {
            $('input[name=userid_list]').prop('checked', false);
            var arr = [];
            $(".check_userid_list:checkbox:not(:checked)").each(function () {
                _val = $(this).val().toString();
                var arr_selected = $('#selectedUsers').val().split(',');
                $(arr_selected).each(function (e, i) {
                    var _iValue = i.toString();
                    if (_iValue == _val) {
                        arr_selected.splice($.inArray(_iValue, arr_selected), 1);
                    }
                });
                $('#selectedUsers').val(arr_selected.toString());
            });
            setSelectedCount(false);
        }
    });

    //$('#column-selection-link').click(function() {
    $(document).on('click', '#column-selection-link', function (e) {  /* MS-147*/
        e.stopImmediatePropagation();  // MS-147
        $('#column-selection-list').slideToggle(1000);
    });

    $(document).on('click', '#breakoutby-link', function (e) { /* MS-147*/
        e.stopImmediatePropagation(); //MS-147
        $('#breakoutby-list').slideToggle(1000);
    });

    $(document).on('click', '.assignment_header input', function (e) { /* MS-147*/
        //$('.assignment_header input').click(function() {
        e.stopImmediatePropagation(); //Ms-147
        var _this = $(this);
        var name = _this.attr('name');
        var child_elem_name = name + '_item';

        if (_this.is(':checked')) {
            _this.parent().siblings('.changeArrow').removeClass("showarrow");
            _this.parent().siblings('.changeArrow').addClass("hidearrow");
            _this.parent().siblings('.assignment_box').slideToggle(1000);
        } else {
            _this.parent().siblings('.changeArrow').removeClass("hidearrow");
            _this.parent().siblings('.changeArrow').addClass("showarrow");
            _this.parent().siblings('.assignment_box').slideUp(1000);
            _this.parent().siblings().children().children('.column-selection-selectall').html('Select All');
            $('input[name=' + child_elem_name + ']').prop('checked', false);
        }
    });


    $(document).on('click', '#str_none_break_out', function (e) { /* MS-147*/
        e.stopImmediatePropagation(); //MS-147
        $('#str_site_assgmnt_optnl_break_out').parent().siblings('.asso_assign_break_box').slideUp(1000);
        $('#str_staffrole_optnl_break_out').parent().siblings('.asso_assign_break_box').slideUp(1000);
        $('#str_site_assgmnt_optnl_break_out_all_active').prop('checked', false);
        $('#str_site_assgmnt_optnl_break_out_all_inactive').prop('checked', false);
        $('input[class=site_assignments]:checked').prop('checked', false); //MS-147
        $('input[class=role_assignments]:checked').prop('checked', false); //MS-147
        // MV-2153(K):Start
		$('#account-toggle-wrapper').slideUp(1000);
		$("input:checkbox[name=account_status]:checked").each(function() { 
			$(this).prop('checked', false);
		});
		$('#account-status-option-break-selectall').html('Select All');
		// MV-2153(K):Stops
    });

    $(document).on('click', '#str_site_assgmnt_optnl_break_out', function (e) {  /* MS-147*/
        e.stopImmediatePropagation();  //MS-147
        $(this).parent().siblings('.asso_assign_break_box').slideDown(1000);
        $('#str_staffrole_optnl_break_out').parent().siblings('.asso_assign_break_box').slideUp(1000);
        if (!$('#str_site_assgmnt_optnl_break_out_all_active').is(':checked')) {
            $('#str_site_assgmnt_optnl_break_out_all_active').trigger('click');
        }
        $('input[class=role_assignments]:checked').prop('checked', false);
        // MV-2153(K):Start
		$('#account-toggle-wrapper').slideUp(1000);
		$("input:checkbox[name=account_status]:checked").each(function() { 
			$(this).prop('checked', false);
		});
		$('#account-status-option-break-selectall').html('Select All');
		// MV-2153(K):Stops
    });

    $(document).on('click', '#str_staffrole_optnl_break_out', function (e) { /* MS-147*/
        e.stopImmediatePropagation();  //MS-147
        $(this).parent().siblings('.asso_assign_break_box').slideDown(1000);
        $('#str_site_assgmnt_optnl_break_out').parent().siblings('.asso_assign_break_box').slideUp(1000);
        $('#str_association_assgmnt_optnl_break_out').parent().siblings('.asso_assign_break_box').slideUp(1000);
        $('input[class=site_assignments]:checked').prop('checked', false);
        // MV-2153(K):Start
		$('#account-toggle-wrapper').slideUp(1000);
		$("input:checkbox[name=account_status]:checked").each(function() { 
			$(this).prop('checked', false);
		});
		$('#account-status-option-break-selectall').html('Select All');
		// MV-2153(K):Stops
    });

    //Ms-147
    $(document).on('keyup', '#str_view_name', function (e) {  /* MS-147*/
        e.stopImmediatePropagation();  //MS-147
        var value_length = 80 - $(this).val().length;
        $(this).nextAll('.help-text:first').html(value_length + ' characters remaining');
    });

    $('#restAll').hide();
    $("#restSel").hide();  //sel-count fix
    $("#label1").hide();  //sel-count fix
    //ADMINFUNCT-34

    //$('#sel_action-button').click(function() {
    $(document).on("click", '#sel_action-button', function (e) {	/* MS-147*/
        e.stopImmediatePropagation();  //MS-147
        $('#sel_action').selectmenu('refresh');
        $('#sel_action').selectmenu();
        var elements = $('#sel_action').selectmenu()[0];
        dropdownremove();
        if ($('.ui-selectmenu-menu').css('display') == 'none' && $('#sel_action-menu').length == 2) {
            $('.ui-selectmenu-menu ul:eq(0)').remove();
        }
        var sellen = $('#sel_action option').length;
        var finalcount = 0;
        $('#sel_action-menu li:nth-child(1)').each(function () {
            curid = $(this)[0]['firstChild']['id'];
            finalcount = curid.split('-')[2];
        });
        var count = finalcount;
        //setTimeout(function(){		
        for (i = 0; i < sellen; i++) {
            $("#ui-id-" + count).parents('li').css('display', elements[i].style['display']);
            $("#ui-id-" + count).text(elements[i].innerText);
            if (elements[i].disabled) {
                $("#ui-id-" + count).parents('li').addClass('ui-state-disabled ui-menu-item');
            }
            else {
                $("#ui-id-" + count).parents('li').removeClass('ui-state-disabled ui-menu-item').addClass('ui-menu-item');
            }
            /*MV-2153: Start*/
            var target_text = $("#ui-id-"+count).text();
            if(target_text.includes('Account Status') || target_text.includes('Participation') || target_text.includes('Password Tools')){
                //console.log($j11("#ui-id-"+count).text());
                var target_item = $("#ui-id-" + count);
                target_item.parent().css("opacity", "1");
                target_item.css("color", "black");
                target_item.css("font-weight", "bold");
            }
            /*MV-2153: Start*/
            count = parseInt(count) + 1;
        }
        var userid_list = $('[name="userid_list"]:checked');
        var selected_user_count = userid_list.length;
        var selected = setSelectedUsers();//MV-2058
        var user_selected_len = selected.length;//MV-2058
        $("#sel_action-button span:nth-child(2)").text('Select action... (' + user_selected_len + ')');//MV-2058
        $('.ui-selectmenu-button:eq(1)').remove();
        //	}, 100);
    });
    //ADMINFUNCT-34

    //$('#btn_show_savedviews').click(function() {
    $(document).on('click', '#btn_show_savedviews', function (e) { //MS 147
        showLoadingOverlay();//MS-147 New added
        //MV-1697::MV-1779
        if($('#column-selection-list #standardpanel').is(":checked") == true){
            $('#column-selection-list #standardpanel').trigger('click');
        }
        if($('#column-selection-list #UserCustompanel').is(":checked") == true){
            $('#column-selection-list #UserCustompanel').trigger('click');
        }
        if($('#breakoutby-list #str_none_break_out').is(':visible') == false){
            $('#breakoutby-list #str_none_break_out').trigger("click");
        }
        //MV-1697::MV-1779
        e.stopImmediatePropagation();  //MS-147
        var _this = $("#form_savedviews");
        //$('#selectedview').val('savedviews');
        var postData = _this.serializeArray();
        $('#sortColumn').val('');
        $('#sortType').val('');
        $('#alphabeticFilter').val('');
        $('#str_search').val('');
        $('#restAll').show();
        $('#ui-id-6').show();//ADMINFUNCT-34
        $("#viewsaved").val(1);
        var postData = $('body').data('formdata', postData);
        /* MS-147*/
        $('#checksaved').val(1);/* MS-147*/
        var data = $("input[name='saved_view']:checked").attr('sid');
        var savedID = $("input[name='saved_view']:checked").attr('id');
        var count = 0;
        var saved_count = 0;
        var staffcusttoken = $('#staffcusttoken').val();
        var custtoken = 0;
        $(postData).each(function (i) {
            if (postData[i]['name'] == "saved_view") {
                postData[i]['value'] = data;
                count = 1;
            } else if (savedID == 'AllactivestaffView' && postData[i]['name'] == "savedID") {
                postData[i]['value'] = savedID;
                saved_count = 1;
            } else if (postData[i]['name'] == 'staffcusttoken') {
                postData[i]['value'] = staffcusttoken;
                custtoken = 1;
            }
        });
        if (count == 0) {
            postData.push({
                "name": "saved_view",
                "value": data
            });
        }
        if (savedID == 'AllactivestaffView' && saved_count == 0) {
            postData.push({
                "name": "savedID",
                "value": savedID
            });
        }
        if (custtoken == 0) {
            postData.push({
                "name": "staffcusttoken",
                "value": staffcusttoken
            });
        }
        /* MS-147*/
        var arr_selected = $('#selectedUsers').val().split(','); /* MS-630 */
        var status = loadUsersList(postData, "",arr_selected,'updatedView');
        $('#hidselectedsavedviewreload').val(data);		//MV-1697
        window.bit_change = 0;				//MV-1697::MV-1779
        $('#retain_rad_val').val(1);		//MV-1697
        $('.volunteer_success_message').hide();
        $('.view_success_message').hide();
    });

    $(document).on('click', '#btn_show_customize_view', function (e) { /* MS-147*/
        e.stopImmediatePropagation(); /* MS-147*/
        //$('#selectedview').val('customizeviews');//ADMINFUNCT-34
        $('#sortColumn').val('');
        $('#sortType').val('');
        $('#alphabeticFilter').val('');
        $('#str_search').val('');
        $('#actAll').show();
        $('#deactAll').show();
        $('#archAll').show();
        $('#restAll').show();
        $("#restSel").show();  //sel-count fix
        $("#label1").show(); //sel-count fix
        $('#actSel').prop('disabled', false);
        $('#deactSel').prop('disabled', false);
        $('#archSele').prop('disabled', false);
        $('#restSel').prop('disabled', false); //sel-count fix
        var arr_selected = $('#selectedUsers').val().split(','); /* MS-630 */
        if ($('#bit_all_enrolled').is(':checked') || $('#bit_not_enrolled').is(':checked')) {
            // MS-48 Starts
            if ($('#bit_all_enrolled').is(':checked')) {
                if ($('#bit_not_enrolled').is(':checked')) {
                    $('#archAll').show();
                    $('#archSele').show();
                    $('#archAll').prop('disabled', false);
                } else {
                    $('#archSele').show();
                    $('#archAll').prop('disabled', false);
                }
            } else if ($('#bit_not_enrolled').is(':checked')) {
                $('#archAll').hide();
                $('#archSele').hide();
            }
            // MS-48 Ends
            showLoadingOverlay();
            /* MV-2153(K):Start */
			var currentaccountstatusvaluelist = [];
			$('input:checkbox[name="account_status"]:checked').each(function() { 
				currentaccountstatusvaluelist.push($(this).val());
			});	
			$('#currentaccountstatusvalue').val(currentaccountstatusvaluelist);
			/* MV-2153(K):Stop */
            $('.volunteer_success_message').hide();
            $('.view_success_message').hide();
            var _this = $("#form_customizedviews");
            var str_viewname = $("#str_view_name").val();
            if (str_viewname != '') {
                mtchFnd = matchRegEx(str_viewname, "^[a-z A-Z0-9]+$");/* MS 147 */
                if (mtchFnd == null) {
                    alert("Enter valid data into 'Save View As' text field");//Added by MN
                    hideLoadingOverlay();
                    return false;
                }
            }
            $('#checksaved').val(0);/* MS-147*/
            var staffcusttoken = $('#staffcusttoken').val();/* MS 147 */
            var str_viewname = $("#str_view_name").val();
            var searchfilter = $('#str_search').val();
            var int_start_row = 1;
            var alphabeticFilter = $('#alphabeticFilter').val();
            var sortColumn = $('#sortColumn').val();
            var sortType = $('#sortType').val();
            /* MS-147*/
            var postData = _this.serializeArray();
            //validation
            var frmData = _this.serializeArray();
            $('body').data('formdata', frmData);
            var not_enrolled_count = 0;
            var all_enrolled_count = 0;
            var count_alphabetic = 0;
            var count_searchfilter = 0;
            var count_column = 0;
            var count_sortType = 0;
            var count_startRow = 0;
            var custtoken = 0;
            var site_breakOut = [];
            var site_breakOutList = $('input[name=str_site_assgmnt_optnl_break_out_site]:checked');
            /* MS-147*/
            $(postData).each(function (i) {
                if (postData[i]['name'] == "bit_not_enrolled") {
                    postData[i]['value'] = 1;
                    not_enrolled_count = 1;
                } else if (postData[i]['name'] == "bit_all_enrolled") {
                    postData[i]['value'] = 1;
                    //if($('#bit_all_enrolled').is(':checked')){
                    all_enrolled_count = 1;
                    //}
                } else if (postData[i]['name'] == "alphabeticFilter") {
                    postData[i]['value'] = alphabeticFilter;
                    count_alphabetic = 1;
                }
                else if (postData[i]['name'] == "searchfilter") {
                    postData[i]['value'] = searchfilter;
                    count_searchfilter = 1;
                }
                else if (postData[i]['name'] == "sort_column") {
                    postData[i]['value'] = sortColumn;
                    count_column = 1;
                } else if (postData[i]['name'] == "sort_type") {
                    postData[i]['value'] = sortType;
                    count_sortType = 1;
                } else if (postData[i]['name'] == "int_start_row") {
                    postData[i]['value'] = int_start_row;
                    count_startRow = 1;
                } else if (postData[i]['name'] == 'staffcusttoken') {
                    postData[i]['value'] = staffcusttoken;
                    custtoken = 1;
                }
            });
            var not_enrolled_checked = $('#bit_not_enrolled').prop('checked');
            if (all_enrolled_count == 1 && $('#bit_all_enrolled').not(':checked').length == 1) {
                $.each(postData, function () {
                    postData = $.grep(postData, function (value) {
                        return value.name != 'bit_all_enrolled';
                    });
                });
            }
            else if (all_enrolled_count == 1 && $('#bit_all_enrolled').is(':checked').length == 1) {
                postData.push({
                    "name": "bit_all_enrolled",
                    "value": 1
                });
            }
            if (custtoken == 0) {
                postData.push({
                    "name": "staffcusttoken",
                    "value": staffcusttoken
                });
            }
            if (not_enrolled_checked && not_enrolled_count == 0) {
                postData.push({
                    "name": "bit_not_enrolled",
                    "value": 1
                });
            }
            if (count_alphabetic == 0) {   /* MS-147*/
                postData.push({
                    "name": "alphabeticFilter",
                    "value": alphabeticFilter
                });
            }
            if (count_searchfilter == 0) {   /* MS-147*/
                postData.push({
                    "name": "searchfilter",
                    "value": searchfilter
                });
            }
            if (count_startRow == 0) {   /* MS-147*/
                postData.push({
                    "name": "int_start_row",
                    "value": int_start_row
                });
            }
            if (count_column == 0) {   /* MS-147*/
                postData.push({
                    "name": "sort_column",
                    "value": sortColumn
                });
            }
            if (count_sortType == 0) {   /* MS-147*/
                postData.push({
                    "name": "sort_type",
                    "value": sortType
                });
            }

            var status = false;
            if (str_viewname && str_viewname.trim().length) {
                //validate for similar name
                $.ajax({
                    url: "index.cfm?event=user.saveAStaffView",
                    type: "post",
                    data: postData,
                    dataType: "json",
                    success: function (resp, textStatus, jqXHR) {
                        if (resp.data.usertoken) {
                            if (resp.data.status == "ok") {
                                $('#str_view_name').val('');//Added by MN
                                $('#str_view_name').trigger('keyup','#str_view_name');//Added by MN
                                if ($('#bit_not_enrolled').is(':checked')) {
                                    status = loadUsersList(postData, 'removeall',arr_selected,'updatedView');/* MS-630 */
                                    window.bit_change = 1;   //MV-1697::MV-1779
                                    $('#hidselectedsavedviewreload').val(resp.data.sviewid);          //MV-1697::MV-1803 
                                }
                                else {
                                    status = loadUsersList(postData, '',arr_selected,'updatedView');/* MS-630 */
                                    window.bit_change = 1;   //MV-1697::MV-1779
                                    $('#hidselectedsavedviewreload').val(resp.data.sviewid);          //MV-1697::MV-1803 
                                }
                                hideLoadingOverlay();
                                $('#view_success_msg').html(resp.data.msg);
                                $('.view_success_message').removeClass('hide').show();
                            } else {
                                alert(resp.data.msg);
                                hideLoadingOverlay();
                                return false;
                            }
                        }
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        //if fails      
                    }
                });
            } else {
                if ($('#bit_not_enrolled').is(':checked')) {
                    status = loadUsersList(postData, 'removeall',arr_selected,'updatedView');/* MS-630 */
                }
                else {
                    status = loadUsersList(postData, '',arr_selected,'updatedView');/* MS-630 */
                }
                $('#archSele').prop('disabled', true);
                //document.getElementById('archSele').disabled = true;				
                if (status == true)
                    hideLoadingOverlay();
            }
        } else {
            alert('Please select one of the checkboxes in the "Show" section at the top of this table.');
            return false;
        }
    });

    //$('.alphabet li a').on('click',function() {
    $(document).on('click', '.alphabet li a', function (e) {   /* MS-147*/
        e.stopImmediatePropagation();   /* MS-147*/
        showLoadingOverlay();
        _this = $(this);
        _this.parent().addClass('active');
        _this.parent().siblings('li').removeClass('active');
	    var arr_selected = $('#selectedUsers').val().split(','); /*MS-630*/
        var alphabeticFilter = _this.attr('id');
        $('#alphabeticFilter').val(alphabeticFilter);
        var searchfilter = $('#str_search').val();
        var int_start_row = 1;
        var bit_saved = 1;
        var sortColumn = $('#sortColumn').val();
        var sortType = $('#sortType').val();
        $('#newstartrowhid').val(int_start_row);
        /* MS-147*/
        var checksaved = $('#checksaved').val(); /* MS-147*/
       // var savedData1 = $("input[name='saved_view']:checked").attr('sid');        //MV-1697::MV-1779
        //MV-1697::MV-1779
        var savedData = '';
        var sidnew = '';
    		var dataIDs = $('#hidselectedsavedviewreload').val(); 
    			$('#insidebox_saved_views .radio .isDefaultView').each(function(){			
    				if($(this).is(":visible") == true){
    					sidnew = $(this).attr('id').split('_')[1];
    				}
    			});
		if((sidnew == '') || sidnew == dataIDs){
            savedData = dataIDs;
    			}
		else if(sidnew != dataIDs){
			savedData = dataIDs;
    		}
            if(savedData == 'AllactivestaffView'){
    			savedData = 0;
		}
		// if((window.bit_change == 1) && $('#savedviewselection').val().length == 0){
		// 	savedData = sidnew;
		// 	$('#hidselectedsavedviewreload').val(savedData);
    	// 	}
        //MV-1697::MV-1779
        var customizedata = $("#form_customizedviews").serializeArray();
        /* MS 147 changes*/
        var formData = $('body').data('formdata');
        $.each(formData, function () {
            formData = $.grep(formData, function (value) {
                return value.name != 'staffcusttoken'; /* Start MS 147 */
            });
        });

        var postData = $.extend(formData, customizedata);
        postData.filter((item, index) => postData.indexOf(item) === index);
        var panelfield_push = 1;
        var bit_push = 1;
        var bit_count_enrolled = 1;
        /* MS-147*/
        $(postData).each(function (i) {
            if (postData[i]['name'] == "alphabeticFilter") {
                postData[i]['value'] = alphabeticFilter;
                bit_push = 0;
            } else if (postData[i]['name'] == "searchfilter") {
                postData[i]['value'] = searchfilter;
            }  else if (postData[i]['name'] == "sort_column") {
                if(sortColumn == 'undefined'){                       /*  MV-1697 -- Retain saved View */
                    postData[i]['value'] = ''; 
                }
                else{
                postData[i]['value'] = sortColumn;   
            }                    
            } else if (postData[i]['name'] == "sort_type") {
                if(sortType == 'undefined'){                     /*  MV-1697 -- Retain saved View */
                    postData[i]['value'] = '';   
                }
                else{
                postData[i]['value'] = sortType;      
            }                       
            } else if (postData[i]['name'] == "int_start_row") {
                postData[i]['value'] = int_start_row;
                /* MS-147*/
            } else if (postData[i]['name'] == "bit_all_enrolled") {
                postData[i]['value'] = 1;
                bit_count_enrolled = 0;
            } else if (postData[i]['name'] == "saved_view") {           /*  MV-1697 -- Retain saved View */
                postData[i]['value'] = savedData
                bit_saved = 0;
            }
            /* MS-147*/
        });

        if (bit_push == 1) {
            postData.push({
                "name": "alphabeticFilter",
                "value": alphabeticFilter
            });
        }
        /* MS-147*/
        if (bit_count_enrolled == 1 && $('#bit_all_enrolled').is(':checked') == true) {
            postData.push({
                "name": "bit_all_enrolled",
                "value": 1
            });
        }
        /*  MV-1697 -- Retain saved View */
        if (bit_saved == 1) {
            postData.push({
                "name": "saved_view",
                "value": savedData
            });
        }
        /* MS-147*/
        $('input[name=userid_list]').each(function () {
            $(this).prop('checked', false)
        });
        /* $('#selectedUsers').val(''); */
        $("#sel_action option[value='-1']").prop('selected', true);
        // postData = $.merge($("#form_customizedviews").serializeArray(), postData);
        setSelectedUsers();
	    var status = loadUsersList(postData,"",arr_selected); /* MS-630 */
        $('#alphabeticFilter').val(alphabeticFilter);
        //MV-1697::MV-1779
        $('#alphabeticFilterhid').val('');				
        //$('#hidselectedsavedviewreload').val(savedData);
        //MV-1697::MV-1779
        if (status === true) {
            hideLoadingOverlay();
        }
        $('.volunteer_success_message').hide();
        $('.view_success_message').hide();
    });

    //$('#report_list_previous').click(function(e) {
    $(document).on('click', '#report_list_previous', function (e) { /* MS-147*/
        showLoadingOverlay();
        e.preventDefault();
        e.stopImmediatePropagation();  /* MS-147*/
	    var arr_selected = $('#selectedUsers').val().split(','); /* MS-630 */
        var alphabeticFilter = $('#alphabeticFilter').val();
        var searchfilter = $('#str_search').val();
        var int_start_row = $('#int_prev_start_row').val();
        $('#newstartrowhid').val(int_start_row);
        var sortColumn = $('#sortColumn').val();
        var sortType = $('#sortType').val();

        /* MS 147 */
        var checksaved = $('#checksaved').val();
        var customizedata = $("#form_customizedviews").serializeArray();
        var formData = $('body').data('formdata');
        $.each(formData, function () {
            formData = $.grep(formData, function (value) {
                return value.name != 'staffcusttoken'; /* MS 147 changes*/
            });
        });
        var postData = $.extend(formData, customizedata);
        postData.filter((item, index) => postData.indexOf(item) === index);

        //var data = $("input[name='saved_view']:checked").attr('sid');         //MV-1697::MV-1779
        //MV-1697::MV-1779
         var data = '';
        var sidnew = '';
		var dataIDs = $('#hidselectedsavedviewreload').val(); 
			$('#insidebox_saved_views .radio .isDefaultView').each(function(){			
				if($(this).is(":visible") == true){
					sidnew = $(this).attr('id').split('_')[1];
				}
			});
         if((sidnew == '') || sidnew == dataIDs){
            data = dataIDs;
			}
         else if(sidnew != dataIDs){
            data = dataIDs;
		}
        if(data == 'AllactivestaffView'){
			data = 0;
         }
        //  if((window.bit_change == 1) && $('#savedviewselection').val().length == 0){
        //     data = sidnew;
        //      $('#hidselectedsavedviewreload').val(data);
		// }
        //MV-1697::MV-1779
        var bit_push = 1;
        var count = 0;
        var bit_count_enrolled = 1; /* start MS 147 changes*/
        /* MS 147 */

        $(postData).each(function (i) {
            if (postData[i]['name'] == "alphabeticFilter") {
                postData[i]['value'] = alphabeticFilter;

            } else if (postData[i]['name'] == "searchfilter") {
                postData[i]['value'] = searchfilter;
            } else if (postData[i]['name'] == "sort_column") {
                postData[i]['value'] = sortColumn;
            } else if (postData[i]['name'] == "sort_type") {
                postData[i]['value'] = sortType;
            } else if (postData[i]['name'] == "int_start_row") {
                postData[i]['value'] = int_start_row;
                bit_push = 0;
            } else if (postData[i]['name'] == "saved_view") {
                postData[i]['value'] = data;
                count = 1;
            }/* start MS 147  changes*/
            else if (postData[i]['name'] == "bit_all_enrolled") {
                postData[i]['value'] = 1
                bit_count_enrolled = 0;
            }/*  End MS 147  changes*/

        });
        if (bit_push == 1) {
            postData.push({
                "name": "int_start_row",
                "value": int_start_row
            });
        }
        /* start MS 147 changes*/
        if (count == 0 && checksaved ==1) {
            postData.push({
                "name": "saved_view",
                "value": data
            });
        }
       
        if (bit_count_enrolled == 1 && $('#bit_all_enrolled').is(':checked') == true) {
            postData.push({
                "name": "bit_all_enrolled",
                "value": 1
            });
        }
        /* end MS 147 changes*/
        //postData = $.merge($("#form_customizedviews").serializeArray(), postData);
        var status = loadUsersList(postData, "",arr_selected);/* MS-630 */
       // $('#hidselectedsavedviewreload').val(data);    //MV-1697::MV-1779
        if (status === true) {
            hideLoadingOverlay();
        }
        $('.volunteer_success_message').hide();
        $('.view_success_message').hide();
    });

    //$('#report_list_next').click(function(e) {
    $(document).on('click', '#report_list_next', function (e) { /* MS-147*/
        showLoadingOverlay();
        e.preventDefault();
        e.stopImmediatePropagation();  /* MS-147*/
        var arr_selected = $('#selectedUsers').val().split(','); /*MS-630*/
        var alphabeticFilter = $('#alphabeticFilter').val();
        var searchfilter = $('#str_search').val();
        var int_start_row = $('#int_next_start_row').val();
        $('#newstartrowhid').val(int_start_row);
        var sortColumn = $('#sortColumn').val();
        var sortType = $('#sortType').val();
        /* MS 147 */
        var checksaved = $('#checksaved').val();
        var customizedata = $("#form_customizedviews").serializeArray();
        var formData = $('body').data('formdata');
        $.each(formData, function () {
            formData = $.grep(formData, function (value) {
                return value.name != 'staffcusttoken'; /*  start MS 147 changes*/
            });
        });
        var postData = $.extend(formData, customizedata);
        
        postData.filter((item, index) => postData.indexOf(item) === index);

       // var data = $("input[name='saved_view']:checked").attr('sid');         //MV-1697::MV-1779
        //MV-1697::MV-1779
         var data = '';
        var sidnew = '';
		var dataIDs = $('#hidselectedsavedviewreload').val(); 
			$('#insidebox_saved_views .radio .isDefaultView').each(function(){			
				if($(this).is(":visible") == true){
					sidnew = $(this).attr('id').split('_')[1];
				}
			});
         if((sidnew == '') || sidnew == dataIDs){
            data = dataIDs;
			}
         else if(sidnew != dataIDs){
            data = dataIDs;
		}
        if(data == 'AllactivestaffView'){
			data = 0;
         }
        //  if((window.bit_change == 1) && $('#savedviewselection').val().length == 0){
        //     data = sidnew;
        //      $('#hidselectedsavedviewreload').val(data);
		// }
        //MV-1697::MV-1779
        var bit_push = 1;
        var count = 0;
        var bit_count_enrolled = 1; /*  start MS 147 changes*/
        $(postData).each(function (i) {
            if (postData[i]['name'] == "alphabeticFilter") {
                postData[i]['value'] = alphabeticFilter;

            } else if (postData[i]['name'] == "searchfilter") {
                postData[i]['value'] = searchfilter;
            } else if (postData[i]['name'] == "sort_column") {
                postData[i]['value'] = sortColumn;
            } else if (postData[i]['name'] == "sort_type") {
                postData[i]['value'] = sortType;
            } else if (postData[i]['name'] == "int_start_row") {
                postData[i]['value'] = int_start_row;
                bit_push = 0;
            } else if (postData[i]['name'] == "saved_view") {
                postData[i]['value'] = data;
                count = 1;
            }/* start MS 147 changes*/
            else if (postData[i]['name'] == "bit_all_enrolled") {
                postData[i]['value'] = 1
                bit_count_enrolled = 0;
            }/* end MS 147 changes*/
        });
        if (bit_push == 1) {
            postData.push({
                "name": "int_start_row",
                "value": int_start_row
            });
        }
        /* start MS 147 changes*/
        if (count == 0 && checksaved ==1) {
            postData.push({
                "name": "saved_view",
                "value": data
            });
        }
        /* start MS 147 changes*/
        if (bit_count_enrolled == 1 && $('#bit_all_enrolled').is(':checked') == true) {
            postData.push({
                "name": "bit_all_enrolled",
                "value": 1
            });
        }
        /* end MS 147 changes*/
        var status = loadUsersList(postData, "",arr_selected); /* MS-630 */
        //$('#hidselectedsavedviewreload').val(data);    //MV-1779
        if (status === true) {
            hideLoadingOverlay();

        }
        $('.volunteer_success_message').hide();
        $('.view_success_message').hide();
    });

    $("#str_search").keyup(function (e) {
        e.stopImmediatePropagation();   /* MS-147*/
        var _this = $(this);
        if (_this.val().length == 0) {
            $('.search_inactive').removeClass('search_inactive').addClass('search_active');
            $('.search_active').trigger('click');
        } else {
            autoCompleteInit();
        }
    });

    // $('#search_icon_new').live('click', function(e) {
    $(document).on('click', '.search_inactive', function (e) { /* MS-147*/
        e.stopImmediatePropagation();  /* MS-147*/
        var str = $.trim($('#str_search').val());
        if (str.length == 0) {
            alert('Please enter at least one character to filter.');
            $('#str_search').focus();
            return false;
        }
        showLoadingOverlay();
        e.preventDefault();
        var alphabeticFilter = $('#alphabeticFilter').val();
        var searchfilter = $('#str_search').val();
        var int_start_row = $('#int_next_start_row').val();
        var sortColumn = $('#sortColumn').val();
        var sortType = $('#sortType').val();
        /* MS-147*/
        var checksaved = $('#checksaved').val();
       // var savedData = $("input[name='saved_view']:checked").attr('sid');            //MV-1697::MV-1779
        //MV-1697::MV-1779
         var savedData = '';
        var sidnew = '';
		var dataIDs = $('#hidselectedsavedviewreload').val(); 
			$('#insidebox_saved_views .radio .isDefaultView').each(function(){			
				if($(this).is(":visible") == true){
					sidnew = $(this).attr('id').split('_')[1];
				}
			});
         if((sidnew == '') || sidnew == dataIDs){
            savedData = dataIDs;
			}
         else if(sidnew != dataIDs){
            savedData = dataIDs;
		}
        if(savedData == 'AllactivestaffView'){
			savedData = 0;
         }
        //  if((window.bit_change == 1) && $('#savedviewselection').val().length == 0){
        //     savedData = sidnew;
        //      $('#hidselectedsavedviewreload').val(savedData);
		// }
        //MV-1697::MV-1779
        var bit_saved = 1;
        var customizedata = $("#form_customizedviews").serializeArray();
        var formData = $('body').data('formdata');
        $.each(formData, function () {
            formData = $.grep(formData, function (value) {
               
                return value.name != 'staffcusttoken';
            });
        });
        
        var postData = $.extend(formData, customizedata);
        postData.filter((item, index) => postData.indexOf(item) === index);
        var bit_count_enrolled = 1;
        /* MS-147*/
        var bit_push = 1;
        $(postData).each(function (i) {
            if (postData[i]['name'] == "alphabeticFilter") {
                postData[i]['value'] = alphabeticFilter;
            } else if (postData[i]['name'] == "searchfilter") {
                bit_push = 0;
                postData[i]['value'] = searchfilter;
            } else if (postData[i]['name'] == "sort_column") {
                postData[i]['value'] = sortColumn;
            } else if (postData[i]['name'] == "sort_type") {
                postData[i]['value'] = sortType;
            } else if (postData[i]['name'] == "int_start_row") {
                postData[i]['value'] = 0;
            } else if (postData[i]['name'] == "saved_view") {
                postData[i]['value'] = savedData;
                bit_saved = 0;
            } else if (postData[i]['name'] == "bit_all_enrolled") {
                postData[i]['value'] = 1
                bit_count_enrolled = 0;
            }
        });
        if (bit_push == 1) {
            postData.push({
                "name": "searchfilter",
                "value": searchfilter
            });
        }
        /* MS-147*/
        if (bit_saved == 1) {
            postData.push({
                "name": "saved_view",
                "value": savedData
            });
        }
        if (bit_count_enrolled == 1 && $('#bit_all_enrolled').is(':checked') == true) {
            postData.push({
                "name": "bit_all_enrolled",
                "value": 1
            });
        }
        /* MS-147*/
        //postData = $.merge( $("#form_customizedviews").serializeArray(), postData );
        $('input[name=userid_list]').each(function () {
            $(this).prop('checked', false);
        });
        $('#selectedUsers').val('');
        $("#sel_action option[value='-1']").prop('selected', true);
        /* End Code */
        var status = loadUsersList(postData, "");
        //$('#hidselectedsavedviewreload').val(savedData); //MV-1697::MV-1779
        if (status === true) {
            hideLoadingOverlay();
        }
        $('.volunteer_success_message').hide();
        $('.view_success_message').hide();
        $(this).attr('src', 'images/icons/cancel_icon.png');
        $(this).removeClass('search_inactive').addClass('search_active');
    });

    //$('.search_active').click(function(e){
    $(document).on("click", '.search_active', function (e) { /* MS-147*/
        e.stopImmediatePropagation(); /* MS-147*/
        $(this).attr('src', 'images/icons/lens_icon.png');
        $(this).removeClass('search_active').addClass('search_inactive');
        showLoadingOverlay();
        e.preventDefault();
        $('#str_search').val('');
        var alphabeticFilter = $('#alphabeticFilter').val();
        var searchfilter = $('#str_search').val();
        var int_start_row = $('#int_next_start_row').val();
        var sortColumn = $('#sortColumn').val();
        var sortType = $('#sortType').val();
        /* MS 147 */
        var checksaved = $('#checksaved').val();
        var customizedata = $("#form_customizedviews").serializeArray();
        var formData = $('body').data('formdata');
        $.each(formData, function () {
            formData = $.grep(formData, function (value) {
                
                return value.name != 'staffcusttoken';
            });
        });
        //console.log('formData',formData);
        var postData = $.extend(formData, customizedata);
        postData.filter((item, index) => postData.indexOf(item) === index);
        /* MS 147 */
        //var postData = $('body').data('formdata');
        var bit_push = 1;
       // var savedData = $("input[name='saved_view']:checked").attr('sid');        //MV-1697::MV-1779
        //MV-1697::MV-1779
        var savedData = '';
        var sidnew = '';
		var dataIDs = $('#hidselectedsavedviewreload').val(); 
			$('#insidebox_saved_views .radio .isDefaultView').each(function(){			
				if($(this).is(":visible") == true){
					sidnew = $(this).attr('id').split('_')[1];
				}
			});
        if((sidnew == '') || sidnew == dataIDs){
           savedData = dataIDs;
			}
        else if(sidnew != dataIDs){
           savedData = dataIDs;
		}
        if(savedData == 'AllactivestaffView'){
			savedData = 0;
        }
        // if((window.bit_change == 1) && $('#savedviewselection').val().length == 0){
        //    savedData = sidnew;
        //     $('#hidselectedsavedviewreload').val(savedData);
		// }
        //MV-1697::MV-1779
        var bit_saved = 1;
        var bit_count_enrolled = 1;
        var bit_alpha = 1;
        $(postData).each(function (i) {
            if (postData[i]['name'] == "alphabeticFilter") {
                postData[i]['value'] = alphabeticFilter;
                bit_alpha = 0;
            } else if (postData[i]['name'] == "searchfilter") {
                bit_push = 0;
                postData[i]['value'] = '';
            } else if (postData[i]['name'] == "sort_column") {
                if(sortColumn == 'undefined'){                   /*  MV-1697 -- Retain saved View */
                    postData[i]['value'] = ''; 
                }
                else{
                postData[i]['value'] = sortColumn; 
                }
            } else if (postData[i]['name'] == "sort_type") {
                if(sortType == 'undefined'){                    /*  MV-1697 -- Retain saved View */
                postData[i]['value'] = '';  
                } 
            } else if (postData[i]['name'] == "int_start_row") {
                postData[i]['value'] = 0;
            } /* MS-147*/
            else if (postData[i]['name'] == "saved_view") {
                postData[i]['value'] = savedData
                bit_saved = 0;
            } else if (postData[i]['name'] == "bit_all_enrolled") {
                postData[i]['value'] = 1
                bit_count_enrolled = 0;
            }
            /* MS-147*/
        });
        if (bit_push == 1) {
            postData.push({
                "name": "searchfilter",
                "value": ""
            });
        }
        if (bit_count_enrolled == 1 && $('#bit_all_enrolled').is(':checked') == true) {
            postData.push({
                "name": "bit_all_enrolled",
                "value": 1
            });
        }
        /* MS-147*/
        if (bit_saved == 1) {
            postData.push({
                "name": "saved_view",
                "value": savedData
            });
        }
        /*  MV-1697  */
        if(searchfilter.length == 0 && bit_alpha == 1){
            postData.push({
                "name": "alphabeticFilter",
                "value": alphabeticFilter
            });    
        }
         /*  MV-1697  */
        /* MS-147*/
        //postData = $.merge( $("#form_customizedviews").serializeArray(), postData );
        $('input[name=userid_list]').each(function () {
            $(this).prop('checked', false);
        });
        $('#selectedUsers').val('');
        $("#sel_action option[value='-1']").prop('selected', true);
        var status = loadUsersList(postData, "");
        $('#strsearchhid').val('');					//MV-1697::MV-1779
        //$('#hidselectedsavedviewreload').val(savedData); //MV-1697::MV-1779
        if (status === true) {
            hideLoadingOverlay();
        }
        $('.volunteer_success_message').hide();
        $('.view_success_message').hide();
    });

    // $('#sel_action').live('change', function(e) {
    //$('#sel_action').on('selectmenuselect', function() {//ADMINFUNCT-34
    //$('#sel_action-menu li div').click(function() {	//ADMINFUNCT-34

    // $.fn.loadDialogContent = function (url) {
    //     this.load(url, {}, function (response, status, xhr) {
    //         loadStatusHandler(status);
    //     });
    // }
    $(document).on('click', '#sel_action-menu li div', function (e) {
        //$("#sel_action-menu li div").unbind().click(function(){											
        var _this = $(this);
        e.stopImmediatePropagation();  /* MS-147*/
        var value = _this.html();
        if (value.indexOf('Select action') == -1) {
            value = value.substring(0, value.indexOf('(')).trim();
            if (value.indexOf('Activate Selected') != -1)
                value = 'activate'
            else if (value.indexOf('Activate All') != -1)
                value = 'activateall'
            else if (value.indexOf('Deactivate Selected') != -1)
                value = 'deactivate'
            else if (value.indexOf('Deactivate All') != -1)
                value = 'deactivateall'
            else if (value.indexOf('Archive Selected') != -1)
                value = 'archive'
            else if (value.indexOf('Archive All') != -1)
                value = 'archiveall'
            else if (value.indexOf('Restore Selected') != -1)
                value = 'restore'
            else if (value.indexOf('Restore All') != -1)
                value = 'restoreall'
            else if (value.indexOf('Delete Selected') != -1)
                value = 'delete'
            else if (value.indexOf('Delete All') != -1)
                value = 'deleteall'
            else if (value.indexOf('Reset Password for Selected') != -1 || value.indexOf('Reset Passwords for Selected') != -1) // Cf18-91  // MV-2153
                value = 'resetpassword'
            else if (value.indexOf('Reset Passwords for All') != -1) // Cf18-91   // MV-2153
                value = 'resetpasswordall'
            else if (value.indexOf('Send Welcome/Password Setup E-mail to Selected Without Passwords') != -1 || value.indexOf('Send Welcome/Password Setup E-mail to Selected Without Passwords') != -1) // Cf18-91 // MV-2153
                value = 'sendmail'
            else if (value.indexOf('Send Welcome/Password Setup E-mail to All Without Passwords') != -1) // Cf18-91 // MV-2153
                value = 'sendmailall'

            var postData = $('#frm_volunteer_list').serializeArray();
            var userid_list = $('[name="userid_list"]:checked');

            var selected_view_id = "";
            var is_anyone_saved_view_selected = 0;
            var bit_all_enrolled_checked = $('#bit_all_enrolled').is(':checked');
            var bit_not_enrolled_checked = $('#bit_not_enrolled').is(':checked');

            if (bit_all_enrolled_checked == true) {
                if (bit_not_enrolled_checked == true) {
                    $("#restAll").show();
                    $("#restSel").show(); //sel-count fix 
                    $("#label1").show(); //sel-count fix
                } else {
                    $("#restAll").hide();
                    $("#restSel").hide();  //sel-count fix
                    $("#label1").hide(); //sel-count fix
                }
            } else if (bit_not_enrolled_checked == true) {
                $("#restAll").show();
                $("#restSel").show();  //sel-count fix
                $("#label1").show(); 	//sel-count fix
            } else {
                $("#restAll").hide();
                $("#restSel").hide();  //sel-count fix
                $("#label1").hide(); //sel-count fix
            }
            var bit_all_enrolled = 0;
            var bit_not_enrolled = 0
            var checksaved = $('#checksaved').val();/* MS-147*/
            var sortColumn = $('#sortColumn').val();
            var sortType = $('#sortType').val();
            var selected_user_count = userid_list.length;
            var selected = setSelectedUsers();
            var user_selected_len = selected.length;//MV-2058
           // var data = $("input[name='saved_view']:checked").attr('sid');     //MV-1697::MV-1779
            //MV-1697::MV-1779
            var data = '';
            var sidnew = '';
            var dataIDs = $('#hidselectedsavedviewreload').val(); 
                $('#insidebox_saved_views .radio .isDefaultView').each(function(){			
                    if($(this).is(":visible") == true){
                        sidnew = $(this).attr('id').split('_')[1];
                    }
                });
            if((sidnew == '') || sidnew == dataIDs){
                data = dataIDs;
                }
            else if(sidnew != dataIDs){
                data = dataIDs;
            }
            if(data == 'AllactivestaffView'){
                data = 0;
            }
            // if((window.bit_change == 1) && $('#savedviewselection').val().length == 0){
            //     data = sidnew;
            //     $('#hidselectedsavedviewreload').val(data);
            // }
            //MV-1697::MV-1779
            var count = 0;
            var staffcusttoken = $('#staffcusttoken').val(); /* MS-147 (29-08-2022)*/
            if (value !== 'activateall' && value !== 'deactivateall' && value !== 'archiveall' && value !== 'restoreall' && value !== 'deleteall' && value !== 'resetpasswordall' && value !== 'sendmailall' && value !== '-1') { //ADMINFUNCT-34
                var arr_selected = $('#selectedUsers').val().split(','); /* SM-630 */
			    if (arr_selected.length <= 0) {
                    var alert_msg = $('#sel_action').attr('data-alert');
                    alert(alert_msg);
                    //ADMINFUNCT-34
                    $('#sel_action-button').focus();
                    $("#sel_action-button span:nth-child(2)").text('Select action... (' + user_selected_len + ')');//MV-2058
                    return;
                }
            }

            /*Altered for MS-55 starts */

            //Start :: MS-539
            // Convert the array back to a string
            var updated_fulluserid_list = ''

            if (value === 'activateall' || value === 'deactivateall' || value === 'archiveall' || value === 'deleteall'){
              // Split the string into an array   
              var fulluserid_list = $('#fulluserid_list').val().split(',');
              
              // Remove the value from the array
              var indexToRemove = fulluserid_list.indexOf(window.userid);
              
              if (indexToRemove !== -1) {
                  fulluserid_list.splice(indexToRemove, 1);
              }

              //console.log(fulluserid_list.length >0)
              
              if (fulluserid_list.length >0 ){
                  updated_fulluserid_list = fulluserid_list.join(',');
              }
              //END :: MS-539
            }

            if (value === 'archive') {
                var alert_msg = $('#sel_action > #archSele').attr('data-msg');
                if (selected_user_count == 1) {
                    alert_msg = "To archive the selected account, please click OK."
                }
                if (confirm(alert_msg)) {
                    postData.push({
                        "name": "action",
                        "value": "archive"
                    });
                    postData.push({
                        "name": "saved_view",
                        "value": data
                    });
                    /* MS-147 (29-08-2022) :: Start*/
                    postData.push({
                        "name": "staffcusttoken",
                        "value": staffcusttoken
                    });
                    /* MS-147 (29-08-2022) :: End*/
                } else {
                    $('#sel_action').val(-1);
                    //ADMINFUNCT-34
                    $('#sel_action-button').focus();
                    $("#sel_action-button span:nth-child(2)").text('Select action... (' + user_selected_len + ')');//MV-2058
                    return false;
                }
                /*Altered for MS-55 Ends */
            } else if (value === 'restore') {
                postData.push({
                    "name": "action",
                    "value": "restore"
                });
                postData.push({
                    "name": "saved_view",
                    "value": data
                });
                /* MS-147 (29-08-2022) :: Start*/
                postData.push({
                    "name": "staffcusttoken",
                    "value": staffcusttoken
                });
                /* MS-147 (29-08-2022) :: End*/
            } else if (value === 'restoreall') {

                var alert_msg = $('#sel_action > #restAll').attr('data-msg');
                if (confirm(alert_msg)) {

                    //Start :: MS-539
                    // Convert the array back to a string
                    var updated_archiveduserid_list = ''
                    // Split the string into an array   
                    var fulluserid_list = $('#archiveduserid_list').val().split(',');
                    
                    // Remove the value from the array
                    var indexToRemove = fulluserid_list.indexOf(window.userid);
                    
                    if (indexToRemove !== -1) {
                        fulluserid_list.splice(indexToRemove, 1);
                    }

                    //console.log(fulluserid_list.length >0)
                    
                    if (fulluserid_list.length >0 ){
                        updated_archiveduserid_list = fulluserid_list.join(',');
                    }
                    //END :: MS-539

                    postData.push({
                        "name": "action",
                        "value": "restoreall"
                    });
                    postData.push({
                        "name": "alluserids",
                        // "value": $('#archiveduserid_list').val()
                        "value": updated_archiveduserid_list //MS-539
                    });
                    postData.push({
                        "name": "saved_view",
                        "value": data
                    });
                    /* MS-147 (29-08-2022) :: start*/
                    postData.push({
                        "name": "staffcusttoken",
                        "value": staffcusttoken
                    });
                    /* MS-147 (29-08-2022) :: End*/
                    //$(this).html('Restore All (' + 0 + ')');

                } else {
                    $('#sel_action').val(-1);
                    //ADMINFUNCT-34
                    $('#sel_action-button').focus();
                    $("#sel_action-button span:nth-child(2)").text('Select action... (' + user_selected_len + ')');//MV-2058
                    return false;
                }

            } else if (value === 'delete') {
                var alert_msg = $('#sel_action > #delSel').attr('data-msg');
                if (selected_user_count == 1) {
                    alert_msg = "To permanently delete the selected account, please click OK. This action cannot be reversed."
                }
                if (confirm(alert_msg)) {
                    var fulluserid_list = $('#fulluserid_list').val();
                    var slot = $('#slotnumber').html();
                    var slotno = parseInt(slot) - 1;
                    $('#slotnumber').html(slotno);
                    if (fulluserid_list != '') {
                        $('#activeCohort').css("display", "none"); //MS-282
                    }
                    postData.push({
                        "name": "action",
                        "value": "delete"
                    });
                    postData.push({
                        "name": "saved_view",
                        "value": data
                    });
                    /* MS-147 (29-08-2022) :: Start*/
                    postData.push({
                        "name": "staffcusttoken",
                        "value": staffcusttoken
                    });
                    /* MS-147 (29-08-2022) :: End*/
                } else {
                    $('#sel_action').val(-1);
                    //ADMINFUNCT-34
                    $('#sel_action-button').focus();
                    $("#sel_action-button span:nth-child(2)").text('Select action... (' + user_selected_len + ')');//MV-2058
                    return false;
                }
            } else if (value === 'activateall') {
                var alert_msg = $('#sel_action > #actAll').attr('data-msg');
                if (confirm(alert_msg)) {
                    postData.push({
                        "name": "action",
                        "value": "activateall"
                    });
                    postData.push({
                        "name": "alluserids",
                        // "value": $('#fulluserid_list').val()
                        "value":updated_fulluserid_list
                    });
                    /* MS-147 (29-08-2022) :: Start*/
                    postData.push({
                        "name": "staffcusttoken",
                        "value": staffcusttoken
                    });
                    /* MS-147 (29-08-2022) :: End*/
                } else {
                    $('#sel_action').val(-1);
                    //ADMINFUNCT-34
                    $('#sel_action-button').focus();
                    $("#sel_action-button span:nth-child(2)").text('Select action... (' + user_selected_len + ')');//MV-2058
                    return false;
                }
            } else if (value === 'deactivateall') {
                var alert_msg = $('#sel_action > #deactAll').attr('data-msg');
                if (confirm(alert_msg)) {
                    postData.push({
                        "name": "action",
                        "value": "deactivateall"
                    });
                    postData.push({
                        "name": "alluserids",
                        // "value": $('#fulluserid_list').val()
                        "value":updated_fulluserid_list
                    });
                    postData.push({
                        "name": "saved_view",
                        "value": data
                    });
                    /* MS-147 (29-08-2022) :: Start*/
                    postData.push({
                        "name": "staffcusttoken",
                        "value": staffcusttoken
                    });
                    /* MS-147 (29-08-2022) :: End*/
                } else {
                    _this.val(-1);
                    //ADMINFUNCT-34
                    $('#sel_action-button').focus();
                    $("#sel_action-button span:nth-child(2)").text('Select action... (' + user_selected_len + ')');//MV-2058
                    return false;
                }
            } else if (value === 'archiveall') {

                /*  
                //-- Commented for MV-2153 --//
                
                var alert_msg = $('#sel_action > #archAll').attr('data-msg');
                var arr_userid = $('#fulluserid_list').val().split(',');
                // var user_count = arr_userid.length;
                var user_count = arr_userid.filter(function(userId) {
                    return parseInt(userId) != window.userid;
                }).length; //MS-539
                if (user_count == 1) {
                    alert_msg = "You are archiving every staff account in your program (1 Staff Account).  Are you sure you want to do this?"
                }
                if (confirm(alert_msg)) {
                    postData.push({
                        "name": "action",
                        "value": "archiveall"
                    });
                    postData.push({
                        "name": "alluserids",
                        // "value": $('#fulluserid_list').val()
                        "value": updated_fulluserid_list // MS-539
                    });
                    postData.push({
                        "name": "saved_view",
                        "value": data
                    });
                    // MS-147 (29-08-2022) :: Start//
                    postData.push({
                        "name": "staffcusttoken",
                        "value": staffcusttoken
                    });
                    // MS-147 (29-08-2022) :: End//
                    // $('#fulluserid_list').val('');//MS-42
                } else {
                    $('#sel_action').val(-1);
                    //ADMINFUNCT-34
                    $('#sel_action-button').focus();
                    $("#sel_action-button span:nth-child(2)").text('Select action... (' + user_selected_len + ')');//MV-2058
                    return false;
                }
                */
                
               /* MV-2153 : Start */
              
               $dialog.StaffArchivalConfirmationPopup = $('<div></div>').dialog(dialogSettings('Staff Archival Confirmation Popup', 'StaffArchivalConfirmationPopup', 500, 500, 500, "auto"));
               //showLoadingOverlay();
               $.ajax({
                   type: "post",
                   async: false,
                   url: "index.cfm?event=user.getStaffArchivalConfirmationPopup",
                   data: {
                    updated_fulluserid_list: updated_fulluserid_list, 
                    data : data, 
                    staffcusttoken: staffcusttoken,
                    selected_user_count: selected_user_count
                    },
                   success: function(response) 
                   {	hideLoadingOverlay();
                       $dialog.StaffArchivalConfirmationPopup.dialog('open').html(response);
                   },
                   complete: function(){				
                       
                   },
                   error: function(response) {
                       alert('Error');
                   }                          
               });
               /* MV-2153 : Stops */


            } else if (value === 'deleteall') {
                var alert_msg = $('#sel_action > #delAll').attr('data-msg');
                var arr_userid = $('#fulluserid_list').val().split(',');
                // var user_count = arr_userid.length; //MS-539

                var user_count = arr_userid.filter(function(userId) {
                    return parseInt(userId) != window.userid; 
                }).length; //MS-539

                if (user_count == 1) {
                    alert_msg = "You are deleting every staff account in your program (1 Staff Account).  Are you sure you want to do this?"
                }
                if (confirm(alert_msg)) {
                    $('#activeCohort').css("display", "none"); //MS-282
                    $('#slotnumber').html(1);
                    postData.push({
                        "name": "action",
                        "value": "deleteall"
                    });
                    postData.push({
                        "name": "alluserids",
                        // "value": $('#fulluserid_list').val()
                        "value": updated_fulluserid_list //MS-539
                    });

                    postData.push({
                        "name": "saved_view",
                        "value": data
                    });
                    /* MS-147 (29-08-2022) :: Start*/
                    postData.push({
                        "name": "staffcusttoken",
                        "value": staffcusttoken
                    });
                    /* MS-147 (29-08-2022) :: End*/
                    // $('#fulluserid_list').val('');//MS-42
                } else {
                    $('#sel_action').val(-1);
                    //ADMINFUNCT-34
                    $('#sel_action-button').focus();
                    $("#sel_action-button span:nth-child(2)").text('Select action... (' + user_selected_len + ')');//MV-2058
                    return false;
                }
            }
            if (value != -1) {
                if (value === 'resetpassword' || value === 'resetpasswordall' || value === 'sendmail' || value === 'sendmailall') {//ADMINFUNCT-34	
                    if (value === 'resetpasswordall' || value === 'sendmailall')
                        // var selectedUsers = $('#fulluserid_list').val().split(',').length; //MS-539
                        var selectedUsers = $('#fulluserid_list').val().split(',').filter(function(userId) {
                            return parseInt(userId) != window.userid;
                        }).length; //MS-539
                    else
                        var selectedUsers = selected_user_count;
                    /*Ms-147*/
                    if (value === 'sendmail' || value === 'sendmailall') {
                        var title = 'Send Password Setup E-mail to ' + staffAliasPlural + ' Without Passwords';  //MV-862 
                        var height = 400;
                        var width = 420;
                        if (value === 'sendmail') {
                            var height = 260;
                            var width = 420;
                        }
                    } else {
                        var title = 'Reset Passwords';
                        var height = 260;
                        var width = 420;
                    }
                    /*MS-147*/
                    if ($('#fulluserid_list').val()) {
        						/* Start: MV-1634 */
        						var postData = [];
                    if (value !== 'sendmailall'){ //MV-2028
          						postData.push({
          							"name": "sendPasswordUserIds",
          							"value": $('#selectedUsers').val()
          						});
                    }
        						/* End: MV-1634 */
                        $.ajax({
                            type: "POST",
                            url: "index.cfm?event=user.ShowPasswordResetWindow&forusertype=staff&pagereq=staffs&value=" + value + "&selectedUsers=" + selectedUsers,
                            data: postData, /* MV-1634 */
                            before: function () {
                                showLoadingOverlay();
                            },
                            success: function (result) {
                                hideLoadingOverlay();
                                //$('#popupid').css({left:"50%", top:"50%" , position:"fixed" , transform:"translate(-50%, -50%)",border:"3px solid #3266CC"});
                                $('#popupid').css('background', 'white');
								/* Start: MV-1634 */
								$('#popupid').css('max-height', '500px');
								$('#popupid').css('min-height', height);
								$('#popupid').css('padding-bottom', '50px');
								/* End: MV-1634 */
                                $('#popupid').dialog({ autoOpen: false, modal: true, title: title, width: width, center: true, draggable: false, resizable: false, dialogClass: 'dialog-resetpass' });
                                $("#popupid").dialog('open').html(result);
                            }
                        });
                        /* MS-147*/
                        // ColdFusion.Window.create("PasswordReset",title,"index.cfm?event=user.ShowPasswordResetWindow&forusertype=staff&pagereq=staffs&value="+value+"&selectedUsers="+selectedUsers,{modal:true,width:420,height:260,center:true,draggable:false,resizable:false});
                        // 	ColdFusion.Window.onHide("PasswordReset",function(){destroyWindow('PasswordReset')});		
                        // //ADMINFUNCT-34
                        // myWindow = ColdFusion.Window.getWindowObject('PasswordReset');
                        //             console.log("myWindow",myWindow);
                        // popupID = $(myWindow).attr("divid");
                        //             console.log("popupID",popupID);		
                        // $('#'+popupID).removeClass("x-hidden");	
                        // //$('#'+popupID).css({left:"50%", top:"50%" , position:"fixed" , transform:"translate(-50%, -50%)",border:"3px solid #3266CC"});
                        // $('#'+popupID).css({transform: "translate(0%, -50%)",left:"0%",right:"0%",margin:"0 auto" ,top:"30%" , position:"fixed" ,'border-left':"3px solid #3266CC",'border-right':"3px solid #3266CC",'border-bottom':"3px solid #3266CC"});
                        //$(document).find('.x-shadow').css('display','none');
                    }
                    $('#sel_action-button').focus();
                    $("#sel_action-button span:nth-child(2)").text('Select action... (' + user_selected_len + ')');//MV-2058
                }  else if( value != "archiveall") { //MV-2153
                    if (value == 'restoreall' || value == 'restore')
                        var val = $('#archiveduserid_list').val();
                    else
                        var val = $('#fulluserid_list').val();
                    if (val != '') {
                        showLoadingOverlay();

                        $.ajax({
                            type: "post",
                            url: "index.cfm?event=user.editStaffsprocess",
                            data: postData,
                            dataType: "json",
                            success: function (resp) {
                                var alphabeticFilter = $('#alphabeticFilter').val();
                                var searchfilter = $('#str_search').val();
                                var int_start_row = $('#int_prev_start_row').val();
                               
                                /* MS 147 changes*/
                                 var staffcusttoken = $('#staffcusttoken').val(); /* MS-147 (29-08-2022)*/
                                //var customizedata = $("#form_customizedviews").serializeArray();
                                var formData = $('body').data('formdata');
                        
                                var postData = formData;
                                var bit_count_enrolled = 1;
                                var token = 1; /* MS-147 (29-08-2022)*/
                                //postData.filter((item, index) => postData.indexOf(item) === index);
                                /* MS 147 changes*/
                               
                                $(postData).each(function (i) {
                                    if (postData[i]['name'] == "alphabeticFilter") {
                                        postData[i]['value'] = alphabeticFilter;
                                    } else if (postData[i]['name'] == "searchfilter") {
                                        postData[i]['value'] = searchfilter;
                                    } else if (postData[i]['name'] == "sort_column") {
                                        postData[i]['value'] = sortColumn;
                                    } else if (postData[i]['name'] == "sort_type") {
                                        postData[i]['value'] = sortType;
                                    } else if (postData[i]['name'] == "int_start_row") {
                                        postData[i]['value'] = int_start_row;
                                    /* MS 147 */
                                    } else if (postData[i]['name'] == "saved_view") {
                                        postData[i]['value'] = data;
                                        count = 1;
                                    } else if (postData[i]['name'] == "bit_all_enrolled") {
                                        postData[i]['value'] = 1
                                        bit_count_enrolled = 0;
                                    }/* MS-147 (29-08-2022) : Start*/
                                     else if(postData[i]['name'] == "staffcusttoken"){
                                        postData[i]['value'] = staffcusttoken
                                        token = 0;
                                    }
                                    /* MS-147 (29-08-2022) : End*/
                                });
                                if (bit_count_enrolled == 1 && $('#bit_all_enrolled').is(':checked') == true) {
                                    postData.push({
                                        "name": "bit_all_enrolled",
                                        "value": 1
                                    });
                                }
                                if (count == 0 && checksaved ==1 ){
                                    postData.push({
                                        "name": "saved_view",
                                        "value": data
                                    });
                                }
                                /* MS-147 (29-08-2022) :: Start*/
                                if (token == 1){
                                    postData.push({
                                        "name": "staffcusttoken",
                                        "value": staffcusttoken
                                    });
                                }
                                
                                /* MS-147 (29-08-2022) :: End*/
                                /* MS 147 */
                                showLoadingOverlay();
                                var status = loadUsersList(postData, "");
                                //$('#hidselectedsavedviewreload').val(data);     //MV-1697::MV-1779
                                if (status === true) {
                                    hideLoadingOverlay();
                                }
                                $('#selectedUsers').val('');
                                $('#staff_success_msg').html(resp.msg);
                                $('.volunteer_success_message').removeClass('hide').slideDown(1000);
                                setTimeout(function () {
                                    $("#divusermessage").slideUp(1000);
                                }, 2000);
                                // $("#divusermessage").slideUp(8000);
                                //getallemaillist();
                                //ADMINFUNCT-34
                                $('#sel_action-button').focus();
                                $("#sel_action-button span:nth-child(2)").text('Select action... (' + user_selected_len + ')');//MV-2058
                                if (value == 'deleteall' || value === 'archiveall')
                                    $('#fulluserid_list').val('');//MS-42
                            },
                            error: function (resp) {

                            }
                        });
                        if (value == 'deleteall') {
                            $('#fulluserid_list').val('');
                        } else if (value == 'delete') {
                            var userid = $('[name="userid_list"]:checked').attr('id');
                            var fulluserid_list = $('#fulluserid_list').val();
                            var arrfulllist = fulluserid_list.split(',');
                            var arrpush = [];
                            for (i = 0; i < arrfulllist.length; i++) {
                                if (userid != arrfulllist[i])
                                    arrpush.push(arrfulllist[i])
                            }
                            $('#fulluserid_list').val(arrpush);
                        }
                        //}
                    } else {
                        $('#sel_action-button').focus();
                        $("#sel_action-button span:nth-child(2)").text('Select action... (' + user_selected_len + ')');//MV-2058
                    }
                }
            }
        }
    });
    /* MS-147*/
    $(document).on('click', '#passcancel', function () {

        $("#popupid").dialog('close');
    });
    $(document).on('click', '#btn_add', function () {
        $("#popupid").dialog('close');
    });
    $(document).on('click', '#closeRenameview', function () {
        $("#popupid").dialog('close');
    });
    /* MS-147*/
    /* Sorting begin */
    $(document).on('click', '.headers a', function (e) {  /* MS-147*/
        showLoadingOverlay();
        e.preventDefault();
        e.stopImmediatePropagation();  /* MS-147*/
        var sortColumn = $(this).attr('data-column');
        var sortType = $(this).attr('data-sort');
        $('#sortColumn').val(sortColumn);
        $('#sortType').val(sortType);
        var alphabeticFilter = $('#alphabeticFilter').val();
        var searchfilter = $('#str_search').val();
        var int_start_row = 1;
        $('#newstartrowhid').val(int_start_row);
        var subpanel_staff_field_id = $(this).attr('staff_field_id');  /* MS-147*/
        $('#subpanel_staff_field').val(subpanel_staff_field_id);  /* MS-147*/
         var customizedata = $("#form_customizedviews").serializeArray();
        /* MS 147 changes*/
        var checksaved = $('#checksaved').val();
        var formData = $('body').data('formdata');
        $.each(formData, function () {
            formData = $.grep(formData, function (value) {
                return value.name != 'staffcusttoken'; /* Start MS 147 */
            });
        });

        var postData = $.extend(formData, customizedata);
        postData.filter((item, index) => postData.indexOf(item) === index);
        //var data = $("input[name='saved_view']:checked").attr('sid');     //MV-1697::MV-1779
       //MV-1697::MV-1779
        var data = '';
        var sidnew = '';
        var dataIDs = $('#hidselectedsavedviewreload').val(); 
            $('#insidebox_saved_views .radio .isDefaultView').each(function(){			
                if($(this).is(":visible") == true){
                    sidnew = $(this).attr('id').split('_')[1];
                }
            });
        if((sidnew == '') || sidnew == dataIDs){
            data = dataIDs;
            }
        else if(sidnew != dataIDs){
            data = dataIDs;
        }
        if(data == 'AllactivestaffView'){
            data = 0;
        }
        // if((window.bit_change == 1) && $('#savedviewselection').val().length == 0){
        //     data = sidnew;
        //     $('#hidselectedsavedviewreload').val(data);
        // }
        //MV-1697::MV-1779
        var count = 0;
        var bit_alphabet = 1;
        var bit_enrolled = 1;
        var bit_push_type= 1;
        var bit_push_column=1;
        var staffcusttoken = $('#staffcusttoken').val();
        var custtoken = 0;
        $(postData).each(function (i) {
            if (postData[i]['name'] == "alphabeticFilter") {
                postData[i]['value'] = alphabeticFilter;
                bit_alphabet = 0;
            } else if (postData[i]['name'] == "searchfilter") {
                postData[i]['value'] = searchfilter;
            } else if (postData[i]['name'] == "sort_column") {
                postData[i]['value'] = sortColumn;
                bit_push_column= 0;
            } else if (postData[i]['name'] == "sort_type") {
                postData[i]['value'] = sortType;
                bit_push_type = 0;
            } else if (postData[i]['name'] == "int_start_row") {
                postData[i]['value'] = int_start_row;
            } else if (postData[i]['name'] == "saved_view") {
                postData[i]['value'] = data;
                count = 1;
            } else if (postData[i]['name'] == "bit_all_enrolled") {
                postData[i]['value'] = 1;
                bit_enrolled = 0;
            } else if (postData[i]['name'] == 'staffcusttoken') {
                postData[i]['value'] = staffcusttoken;
                custtoken = 1;
            }
        });
        if (bit_push_column == 1) {
            postData.push({
                "name": "sort_column",
                "value": sortColumn
            });
        }
        if(bit_push_type == 1){
            postData.push({
                "name": "sort_type",
                "value": sortType
            });

        }
        /* MS 147 */
        if (custtoken == 0) {
            postData.push({
                "name": "staffcusttoken",
                "value": staffcusttoken
            });
        }
       
        if (count == 0 ) {              //MV-1697
            postData.push({
                "name": "saved_view",
                "value": data
            });
        }
        if (bit_alphabet == 1) {
            postData.push({
                "name": "alphabeticFilter",
                "value": alphabeticFilter
            });
        }
        if (bit_enrolled == 1) {
            postData.push({
                "name": "bit_all_enrolled",
                "value": 1
            });
        }
        var status = loadUsersList(postData, "");
        //$('#hidselectedsavedviewreload').val(data);     //MV-1697::MV-1779
        if (sortType === 'desc') {
            $(this).attr('data-sort', 'asc');
        } else {
            $(this).attr('data-sort', 'desc');
        }
        if (status === true) {
            hideLoadingOverlay();
        }
        $("#sel_action option[value='-1']").prop('selected', true);	 /* Added by Lucky for MV-456*/
        $('.volunteer_success_message').hide();
    }); /* Sorting end */

    //$('.check_userid_list_break_out').change(function(e){
    $(document).on("change", '.check_userid_list_break_out', function (e) {  /* MS-147*/
        e.stopImmediatePropagation(); /* MS-147*/
        var elem_id = $(this).attr('id');
        if ($(this).is(':checked')) {
            $('.' + elem_id).prop('checked', true);
            checkAllCheckboxesOnIdentCB();/* MS-630 */
        } else {
            $('.' + elem_id).prop('checked', false);
            var arr = [];
            $('.' + elem_id + ":checkbox:not(:checked)").each(function () {
                var arr_selected = $('#selectedUsers').val().split(',');
                _val = $(this).val().toString();
                $('input.check_userid_list[id="' + _val + '"]').prop('checked', false);/* MS-630 */
                $(arr_selected).each(function (e, i) {
                    var _iValue = i.toString();
                    if (_iValue == _val) {
                        arr_selected.splice($.inArray(_iValue, arr_selected), 1);
                    }
                });
                $('#selectedUsers').val(arr_selected.toString());
            });
        }
        $("#sel_action option[value='-1']").prop('selected', true);	/* Added by Lucky for MV-456*/
        setSelectedCount(false);
    });

    //$('.linktoeditvolunteer').click(function(e){
    $(document).on('click', '.linktoeditvolunteer', function (e) {  /* MS-147*/
        e.preventDefault();
        e.stopImmediatePropagation();  /* MS-147*/
        var _this = $(this);
        var _elem_rel = _this.attr('rel');
        var _selected_view = $('input[name=view_selection]:checked').attr('id');
        var _thisform = '';
        var _saved_view_selected = '';
        var _column_selected = '';
        /*var _column_selected_type1 ='';
        var _column_selected_type2 ='';
        var _column_selected_type3 ='';*/
        var _optional_breakout_selected = '';
        var _siteassign_selected = '';
        var _account_status_optbreakoutselected ='';	// MV-2153(K)
        var _site_assgmnt_optbreakoutselected = '';
        //var _str_association_assgmnt_optbreakoutselected ='';
        var _cust_view_selected = '';
        var _alphabeticFilter = $('#alphabeticFilter').val();
        var _searchfilter = $('#str_search').val();
        //var _int_start_row = $('#int_next_start_row').val();
        var _int_start_row = $('#newstartrowhid').val();
        //alert(_int_start_row);
        var _sortColumn = $('#sortColumn').val();
        var _sortType = $('#sortType').val();
        _thisform = _thisform + '<form id="editvolform" method="post" action="' + _elem_rel + '">';
        _thisform = _thisform + '<input type="hidden" name="alphabeticFilter_hid" value="' + _alphabeticFilter + '"/>';
        _thisform = _thisform + '<input type="hidden" name="str_search_hid" value="' + _searchfilter + '"/>';
        _thisform = _thisform + '<input type="hidden" name="int_start_row_hid" value="' + _int_start_row + '"/>';
        _thisform = _thisform + '<input type="hidden" name="sortColumn_hid" value="' + _sortColumn + '"/>';
        _thisform = _thisform + '<input type="hidden" name="sortType_hid" value="' + _sortType + '"/>';
        if (_selected_view == 'rad_customize_view') {
            if ($(".radio .columns").is(":checked"))
                _column_selected = $('.radio .columns:checked').map(function () { return $(this).attr('id'); }).get().join(',');
            if ($("input[name=str_optnl_break_out]").is(":checked"))
                _optional_breakout_selected = $('input[name=str_optnl_break_out]:checked').attr('id');
            if ($(".radio .siteassign_select").is(":checked"))
                _siteassign_selected = $(".radio .siteassign_select:checked").map(function () { return $(this).attr('id'); }).get().join(',');
            // MV-2153(K):Start //
			if($("input[name=account_status]").is(":checked"))
    			_account_status_optbreakoutselected = $('input[name=account_status]:checked').map(function() {return $(this).val();}).get().join(',');
			// MV-2153(K):Stop //
            if ($("input[name=str_site_assgmnt_optnl_break_out_site]").is(":checked"))
                _site_assgmnt_optbreakoutselected = $('input[name=str_site_assgmnt_optnl_break_out_site]:checked').map(function () { return $(this).attr('id'); }).get().join(',');
            if ($(".radio .enrollvol").is(":checked"))
                _cust_view_selected = $('.radio .enrollvol:checked').map(function () { return $(this).attr('id'); }).get().join(',');

            _thisform = _thisform + '<input type="hidden" name="selectedview" value="' + _selected_view + '"/>';
            _thisform = _thisform + '<input type="hidden" name="selectedcustview" value="' + _cust_view_selected + '"/>';
            _thisform = _thisform + '<input type="hidden" name="colselected" value="' + _column_selected + '"/>';
            _thisform = _thisform + '<input type="hidden" name="optbreakoutselected" value="' + _optional_breakout_selected + '"/>';
            _thisform = _thisform + '<input type="hidden" name="siteassignselected" value="' + _siteassign_selected + '"/>';
            _thisform = _thisform +'<input type="hidden" name="accountstatusoptbreakoutselected" value="'+htmlEncode(_account_status_optbreakoutselected)+'"/>';// MV-2153(K) //
            _thisform = _thisform + '<input type="hidden" name="siteassignoptbreakoutselected" value="' + _site_assgmnt_optbreakoutselected + '"/></form>';

            $('#submiteditvol').html(_thisform);
            $("#editvolform").attr('target', '_self').submit();//_blank converted to _self : MS-MS-244
        } else {
            if ($("input[name=saved_view]").is(":checked"))
                _saved_view_selected = $('input[name=saved_view]:checked').attr('id');
            /* MV-1697 */
                _saved_view_selected= ('saved_view_'+$('#hidselectedsavedviewreload').val());
                if(_saved_view_selected == 'saved_view_0' || _saved_view_selected == 'saved_view_AllactivestaffView'){
                    _saved_view_selected = 'AllactivestaffView'
                }
                else{
                    _saved_view_selected= ('saved_view_'+$('#hidselectedsavedviewreload').val());
                }
    		/* MV-1697 */
            _thisform = _thisform + '<input type="hidden" name="selectedview" value="' + _selected_view + '"/>';
            _thisform = _thisform + '<input type="hidden" name="selectedsavedview" value="' + _saved_view_selected + '"/></form>';
            $('#submiteditvol').html(_thisform);
            $("#editvolform").attr('target', '_self').submit();//_blank converted to _self : MS-MS-244

        }
        //_thisform = _thisform + '</form>';
    });
    var AllDataJson = "";
    //getallemaillist();
});
// MS-630
function loadUsersList(data, toremove,arr_selected='',updatedView='') {
    showLoadingOverlay();   
    var status = false;
    var _current_time_cache = new Date().getTime();
    var subPanelstaffFieldId = $("#subpanel_staff_field").val();
    //$.ajaxSetup ({cache: false});
    $.ajax({
        type: "POST",
        url: "index.cfm?event=user.stafflistingsection&subPanelstaffFieldId=" +subPanelstaffFieldId+ "&currenttimestamp=" + _current_time_cache,
        data: data,
        dataType: "json",
        success: function (users) {
            if (users.usertoken) {
                var init_sel_action = $('#temp_sel_action').html();
                $('#sel_action').html(init_sel_action);
                $('#archiveduserid_list').val('');
                var pageData = users.paginationData;
                var archivedData = users.data;
                var ArchieveCount = users.totalArchive;//MS-328
                var ActiveCount = users.totalActive;//MS-328
                var arrIds = [];
                var putToarrIds;
                /* comment:: for MS-394 */
                // $.each(archivedData, function (index, report) {
                //     if (report.userid != '' && report.active == 'Archived') {
                //         putToarrIds = report['userid'];
                //         var chkArr = arrIds.indexOf(putToarrIds);
                //         if (chkArr == -1) {
                //             arrIds.push(putToarrIds);
                //         }
                //         $('#archiveduserid_list').val(arrIds);
                //     }
                // });
                /* comment:: for MS-394 */
                $('#archiveduserid_list').val(pageData.archivedStaffid);//MS-394 

                prepareHeaderViewSection(users.alphabeticfilterdata.data);
                prepareviewSection(users.data, users.headers, users.paginationData);
				
				/* Start: MS-539 */
				if(users.data.length == 1 && users.data[0].userid == window.userid) {
					$('#check_all').hide();
				}					
				/* End: MS-539 */
				
                setTimeout(function () {
                    table_width = $('#reportSectionTable').width();
                    if (table_width > $('div.main').width())
                        $('div.main').width(table_width + 500);
                }, 1000);
                if (pageData.alphabeticfilter) {
                    $('.alphabet li a#' + pageData.alphabeticfilter).parent().addClass('active');
                } else {
                    $('#alpha_all').addClass('active');
                }

                if (pageData.userids) {
                    var ids = pageData['userids'];
                    $('#fulluserid_list').val(ids);
                    if (ids != '')
                        $('#activeCohort').css("display", "block") //MS-282
                }
				if (pageData.totalcount || (ArchieveCount + ActiveCount) > 0) { //MS-328
					$('#activeCohort').css("display", "block") //MS-282
				}else{
					$('#activeCohort').css("display", "none") //MS-282
				}

                if (pageData.passwordnotsetemailuserid) {
                    var iids = pageData['passwordnotsetemailuserid'];
                    $('#passwordnotsetemailuserid').val(iids);
                }


                if (users.paginationData) {
                    if (users.paginationData.totalcount >= 0) {
                        // set count of archiveall                                    
                        if ($('#fulluserid_list').val() != '') {
			
			   // MS-539
                            // var arr_userid = $('#fulluserid_list').val().split(',');
                            // var user_count = arr_userid.length;

                            
                            // Split the strings into arrays
                            var full_user_list = $('#fulluserid_list').val().split(',');
                            var archive_user_list = $('#archiveduserid_list').val().split(',');

                            // Remove matching values from aArray
                            archive_user_list.forEach(function(value) {
                                var index = full_user_list.indexOf(value);
                                if (index !== -1) {
                                    full_user_list.splice(index, 1);
                                }
                            });

                            // Join the modified array back into a string
                            var result = full_user_list.join(",");

                            var user_count = result.split(',').filter(function(userId) {
                                return parseInt(userId) != window.userid;
                            }).length; 

                            // MS-539

                            $('.total_user_count').each(function () {
                                var _this = $(this);
                                var _content = _this.attr('data-content');
                                var _alert_msg = _this.attr('data-msg');
                                _alert_msg = _alert_msg.replace("[m]", user_count);
                                _alert_msg = _alert_msg.replace(/\d+/, user_count);
                                _this.attr('data-msg', _alert_msg);
                                _this.html(_content + ' (' + user_count + ')')
                            });
                            $('.total_user_count2').each(function () {
                                var _this = $(this);
                                var _content = _this.attr('data-content');
                                var _alert_msg = _this.attr('data-msg');
                                _alert_msg = _alert_msg.replace("[m]", user_count);
                                _alert_msg = _alert_msg.replace(/\d+/, user_count);
                                _this.attr('data-msg', _alert_msg);
                                _this.html(_content + ' (' + user_count + ')')
                            });
                        } else { //MS-42                                          
                            $('.total_user_count').each(function () {
                                var _this = $(this);
                                var _content = _this.attr('data-content');
                                var _alert_msg = _this.attr('data-msg');
                                _alert_msg = _alert_msg.replace("[m]", 0);
                                _alert_msg = _alert_msg.replace(/\d+/, 0);
                                _this.attr('data-msg', _alert_msg);
                                _this.html(_content + ' (' + 0 + ')')
                            });
                        }
                        // MS-48 Starts
                        var restorelist = $('#archiveduserid_list').val();
                        if ($('#fulluserid_list').val()) {
                            var arr_userid = $('#fulluserid_list').val().split(',');

                            var user_count = arr_userid.filter(function(userId) {
                                return parseInt(userId) != window.userid;
                            }).length; // MS-539
                            
                            // var user_count = arr_userid.length;

                            // MS-539
                            // Split the strings into arrays
                            var full_user_list = $('#fulluserid_list').val().split(',');
                            var archive_user_list = $('#archiveduserid_list').val().split(',');

                            // Remove matching values from aArray
                            archive_user_list.forEach(function(value) {
                                var index = full_user_list.indexOf(value);
                                if (index !== -1) {
                                    full_user_list.splice(index, 1);
                                }
                            });

                            // Join the modified array back into a string
                            var result = full_user_list.join(",");

                            var archive_user_count = result.split(',').filter(function(userId) {
                                return parseInt(userId) != window.userid;
                            }).length; 

                            // MS-539

                        } else {
                            var user_count = 0;
                            var archive_user_count = 0;
                        }

                        if ($('#passwordnotsetemailuserid').val()) {
                            var arr_useridnotsetpwd = $('#passwordnotsetemailuserid').val().split(',');
                            var user_countnotsetpwd = arr_useridnotsetpwd.length;
                        } else {
                            var user_countnotsetpwd = 0;
                        }

                        if ($('#archiveduserid_list').val()) {
                            var arr_archid = $('#archiveduserid_list').val().split(',');
                            var rest_count = arr_archid.length;
                        } else {
                            var rest_count = 0;
                        }
                        if ($('#bit_all_enrolled').is(':checked')) {
                            if ($('#bit_not_enrolled').is(':checked')) {
                                // both checked
                                //active
                                $('.total_user_count').each(function () {
                                    var _this = $(this);
                                    var _content = _this.attr('data-content');
                                    var _alert_msg = _this.attr('data-msg');
                                    _alert_msg = _alert_msg.replace("[m]", archive_user_count);
                                    _alert_msg = _alert_msg.replace(/\d+/, archive_user_count);
                                    _this.attr('data-msg', _alert_msg);
                                    _this.html(_content + ' (' + archive_user_count + ')')
                                });
                                //delete
                                $('.total_user_count2').each(function () {
                                    var _this = $(this);
                                    var _content = _this.attr('data-content');
                                    var _alert_msg = _this.attr('data-msg');
                                    _alert_msg = _alert_msg.replace("[m]", user_count);
                                    _alert_msg = _alert_msg.replace(/\d+/, user_count);
                                    _this.attr('data-msg', _alert_msg);
                                    _this.html(_content + ' (' + user_count + ')')
                                });
                            } else {
                                // only active checked
                                $('.total_user_count').each(function () {
                                    var _this = $(this);
                                    var _content = _this.attr('data-content');
                                    var _alert_msg = _this.attr('data-msg');
                                    _alert_msg = _alert_msg.replace("[m]", archive_user_count);
                                    _alert_msg = _alert_msg.replace(/\d+/, archive_user_count);
                                    _this.attr('data-msg', _alert_msg);
                                    _this.html(_content + ' (' + archive_user_count + ')')
                                });
                                $('.total_user_count2').each(function () {
                                    var _this = $(this);
                                    var _content = _this.attr('data-content');
                                    var _alert_msg = _this.attr('data-msg');
                                    _alert_msg = _alert_msg.replace("[m]", user_count);
                                    _alert_msg = _alert_msg.replace(/\d+/, user_count);
                                    _this.attr('data-msg', _alert_msg);
                                    _this.html(_content + ' (' + user_count + ')')
                                });
                            }
                        } else if ($('#bit_not_enrolled').is(':checked')) {
                            //only archive checked
                            //active
                            $('.total_user_count').each(function () {
                                var _this = $(this);
                                var _content = _this.attr('data-content');
                                var _alert_msg = _this.attr('data-msg');
                                _alert_msg = _alert_msg.replace("[m]", 0);
                                _alert_msg = _alert_msg.replace(/\d+/, 0);
                                _this.attr('data-msg', _alert_msg);
                                _this.html(_content + ' (' + 0 + ')')
                            });
                            //delete          
                            $('.total_user_count2').each(function () {
                                var _this = $(this);
                                var _content = _this.attr('data-content');
                                var _alert_msg = _this.attr('data-msg');
                                _alert_msg = _alert_msg.replace("[m]", rest_count);
                                _alert_msg = _alert_msg.replace(/\d+/, rest_count);
                                _this.attr('data-msg', _alert_msg);
                                _this.html(_content + ' (' + rest_count + ')')
                            });
                        }  // MS-48 Ends

                    }
                    // set count of restoreall
                    var restorelist = $('#archiveduserid_list').val();
                    if (restorelist == '') {
                        var restoreuser_count = 0;
                    } else {
                        var arr_archuserid = $('#archiveduserid_list').val().split(',');
                        var restoreuser_count = arr_archuserid.length;
                    }

                    $('.total_user_count1').each(function () {
                        var _this = $(this);
                        var _content = _this.attr('data-content');
                        var _alert_msg = _this.attr('data-msg');
                        _alert_msg = _alert_msg.replace("[m]", restoreuser_count);
                        _alert_msg = _alert_msg.replace(/\d+/, restoreuser_count);
                        _this.attr('data-msg', _alert_msg);
                        _this.html(_content + ' (' + restoreuser_count + ')')
                    });
                    if ($('#fulluserid_list').val() == '') {
                        $('.total_user_count2').each(function () {
                            var _this = $(this);
                            var _content = _this.attr('data-content');
                            var _alert_msg = _this.attr('data-msg');
                            _alert_msg = _alert_msg.replace("[m]", restoreuser_count);
                            _alert_msg = _alert_msg.replace(/\d+/, restoreuser_count);
                            _this.attr('data-msg', _alert_msg);
                            _this.html(_content + ' (' + restoreuser_count + ')')
                        });
                    }
                }

                status = true;
                if (pageData.searchfilter) {
                    $('#str_search').val(pageData['searchfilter']);
                }

                if (toremove == 'removeall') {
                    $("#sel_action option[value='activateall']").remove();
                    $("#sel_action option[value='deactivateall']").remove();
                }
                /*ADMINFUNCT-34*/
                if ($('#bit_not_enrolled').is(':checked')) {
                    $("#sel_action option[value='resetpasswordall']").remove();
                    $("#sel_action option[value='sendmailall']").remove();
                }
                /*ADMINFUNCT-34*/
                $.each(users.deletearchive, function (index, report) {
                    if (report["readytodelete"] == 'F') {
                        $("#sel_action option[value='deleteall']").remove();
                    }
                    if (report["readytoarchive"] == 'F') {
                        $("#sel_action option[value='archiveall']").remove();
                    }
                    if (report['readytosendpwd'] == 'F') {
                        $("#sel_action option[value='sendmailall']").remove();
                    }
                });
                /* Start :: MS-542_MS-570 */
                if($('#showHideArchieveAllOption').val() == 'hideArcAll_DelAll'){
                    $("#sel_action option[value='archiveall']").remove();
                    $("#sel_action option[value='deleteall']").remove();
                }
                /* End :: MS-542_MS-570 */
                /* selectAlreadySelectedUsers();
                setSelectedCount(false); */
            }
            //MS-328 : Start
            /*
            if (users.data.length > 0)
            {
                $('#activeCohort').css("display", "block") 
            }
            */
            //MS-328 : Stops
        },
        complete: function () {
            /*SiteManage-1:Start*/
            if (IsCohort_Enable == 1 && cohortacessIsEnable == 1) {
                $('#AllTimeAssignmentTypeCohorts').val('');
                $('[name="AllTimeAssignmentType-Cohort"]').each(function (e) {
                    $(this).prop('checked', false);
                });
                $('[name="AssignmentTypeCohort"]').each(function (e) {
                    $(this).prop('checked', false);
                });
                $(".greyBoxCohort level2 customviewcohort").css("margin-top", "6px").css("min-height", "6px").css("display", "none");
                $(".customviewcohort").css("margin-top", "10px").css("margin-left", "0px").css("display", "none");
                $('#blueBox_Cohort').html('<div class="noCohortAssignment" style="display:block;"><div style="width:300px;">No current assignment</div></div>');

                $('#AllTimeAssignmentTypeSites').val('');
                $('[name="AllTimeAssignmentType"]').each(function (e) {
                    $(this).prop('checked', false);
                });
                $('[name="AssignmentType"]').each(function (e) {
                    $(this).prop('checked', false);
                });
                $(".greyBox .level2 .customview").css("margin-top", "6px").css("min-height", "6px").css("display", "none");
                $(".customview").css("margin-top", "10px").css("margin-left", "0px").css("display", "none");
                $(".site-section").css("pointer-events", "none").css("opacity", "0.4");//SiteManageOne
                $('#blueBox_site').html('<div class="noAssignment" style="display:block;"><div style="width:300px;">No current assignment</div></div>');

                /*Code for JS related bugfix*/
                var cohort_link_text = $('#scopeSelectToggle_cohort').text().replace("Select", "Remove");
                $('#scopeSelectToggle_cohort').text(cohort_link_text);
                $('#scopeSelectToggle_cohort').removeClass('select').addClass('remove');
                $('#scopeSelectToggle_cohort').css('display', 'none');

                var site_link_text = $('#scopeSelectToggle_site').text().replace("Select", "Remove");
                $('#scopeSelectToggle_site').text(site_link_text);
                $('#scopeSelectToggle_site').removeClass('select').addClass('remove');
                $('#scopeSelectToggle_site').css('display', 'none');
            }
            /*SiteManage-1:Stops*/
            /* MS-630 */
            if(updatedView == 'updatedView'){
                var currentPage_id_list = Array.from(document.querySelectorAll('.check_userid_list')).map(checkbox => checkbox.id);
                //console.log(currentPage_id_list); // Log the current page IDs
                // Filter arr_selected to keep only IDs that exist in currentPage_id_list
                var filteredIds = arr_selected.filter(id => currentPage_id_list.includes(id));
                //console.log(filteredIds); // Log the filtered IDs
                // Set the filtered IDs as value (you can join as comma-separated string if needed)
                $('#selectedUsers').val(filteredIds.join(','));	
            }else{
            $('#selectedUsers').val(arr_selected); //MS-630
            }
            selectAlreadySelectedUsers();
            setSelectedCount(false);
            /* MS-630 */
            hideLoadingOverlay();
            //$("#str_search").focus(); // Commented for Scroll Issue Under MV-1697
        },
        error: function (data) {
            status = false;
        }
    });
    autoCompleteInit();
    return status;
}

function prepareHeaderViewSection(data) {
    var albhabetSection = $('#viewHeaderAlbhabetSection');
    var actionSection = $('#viewHeaderActionSection');
    var $str_albhabetSection = '';
    var $str_actionSection = '';

    $str_albhabetSection = $str_albhabetSection + '<div class="center-align"><ul class="alphabet">';

    $.each(data, function (index, albhabet) {
        if (albhabet.status == 'active') {
            if (albhabet.id == 'other') {
                $str_albhabetSection = $str_albhabetSection + '<li style="width:40px" ><a id="' + albhabet.id + '" href="javascript:void(0);">' + albhabet.displayName + '</a></li>';
            } else if (albhabet.id == 'all') {
                $str_albhabetSection = $str_albhabetSection + '<li style="width:25px" id="alpha_all"><a id="' + albhabet.id + '" href="javascript:void(0);">' + albhabet.displayName + '</a></li>';
            } else {
                $str_albhabetSection = $str_albhabetSection + '<li><a id="' + albhabet.id + '" href="javascript:void(0);">' + albhabet.displayName + '</a></li>';
            }
        } else {
            if (albhabet.id == 'other') {
                $str_albhabetSection = $str_albhabetSection + '<li style="width:40px">' + albhabet.displayName + '</li>';
            } else if (albhabet.id == 'all') {
                $str_albhabetSection = $str_albhabetSection + '<li style="width:25px" id="alpha_all">' + albhabet.displayName + '</li>';
            } else {
                $str_albhabetSection = $str_albhabetSection + '<li>' + albhabet.displayName + '</li>';
            }
        }
    });

    $str_albhabetSection = $str_albhabetSection + '</ul></div>';
    albhabetSection.html($str_albhabetSection);
    return true;
}

function prepareviewSection(data, headers, pageData) {
    var localData = data;
    var hasArchived = false;
    var onlyHasArchived = true;

    /* Start: MV-817 */
    var activeStaffCount = 0;
    var archivedStaffCount = 0;
    /* End: MV-817 */

    for (var i = 0; i < localData.length; i++) {
        if (localData[i].active == 'Archived') {
            hasArchived = true;
            archivedStaffCount = archivedStaffCount + 1; // MV-817
        }
        /* Start: MV-817 */
        else if (localData[i].active == 1) {
            activeStaffCount = activeStaffCount + 1;
        }
        /* End: MV-817 */
    }
    if (hasArchived) {
        $("#sel_action option[value='activateall']").remove();
        $("#sel_action option[value='deactivateall']").remove();
    }

    /* Commented MV-817
    for(var i=0; i < localData.length; i++)
    {
        if(localData[i].active ==0 || localData[i].active==1)
        {
            onlyHasArchived = false;
            break;
        }
    }
    if(onlyHasArchived)
    { 
         $("#archAll").hide(); 
         $("#restAll").show();        
    }
    else
    {
         $("#archAll").show(); 
        // $("#restAll").hide();
       //  $("#restSel").hide();   
         
    }
    */

    /* Start: MV-817 */
    if (activeStaffCount == localData.length) {
        $("#sel_action option[value='restore']").remove();
        $("#sel_action option[value='restoreall']").remove();
        $("#sel_action > #label1").remove();
        $("#sel_action > #archSele").attr('disabled', false);
    }
    if (archivedStaffCount == localData.length) {
        $("#sel_action option[value='archive']").remove();
        $("#sel_action option[value='archiveall']").remove();
        $("#sel_action > #label1").remove();
    }
    /* End: MV-817 */

    var reportSection = $('#reportSection');
    var paginationSection = $('.viewSectionPagination');
    var oldSelected = $('#selectedUsers').val();
    var checkedTrueOrNOt = '';
    oldSelectedArr = oldSelected.split(',');
    reportSection.html('');

    var $str_viewSectionHeader = '<table cellspacing="0" id="reportSectionTable"  class="listing-table table-layout"><tbody>';
    var $str_viewSection = '';
    var $str_pageSection = '';

    if (pageData.prev_link === "") {
        $str_pageSection = $str_pageSection + '<div class="right-align">';
        /*Should be visible when Volun >250 */
        if (pageData.next_link != "") {
            $str_pageSection = $str_pageSection + '&lt; Previous Page';
        }
    } else {
        $str_pageSection = $str_pageSection + '<div class="right-align"><a id="report_list_previous" title="Previous Page" href="' + pageData.prev_link + '">&lt; Previous Page</a>';
    }

    if (pageData.next_link === "") {
        /*Should be visible when Volun >250 */
        if (pageData.prev_link != "") {
            $str_pageSection = $str_pageSection + ' | Next Page &gt;';
        }
        $str_pageSection = $str_pageSection + '</div>';
    } else {
        $str_pageSection = $str_pageSection + ' | <a id="report_list_next" title="Next Page" href="' + pageData.next_link + '">Next Page &gt;</a></div>';
    }
    $str_pageSection = $str_pageSection + '<input type="hidden" name="int_prev_start_row" id="int_prev_start_row" value="' + pageData.int_prev_start_row + '"><input type="hidden" name="int_next_start_row" id="int_next_start_row" value="' + pageData.int_next_start_row + '"><input type="hidden" name="sortColumn" id="sortColumn" value="' + pageData.sortColumn + '"><input type="hidden" name="sortType" id="sortType" value="' + pageData.sortType + '">'
    paginationSection.html($str_pageSection);

    if (headers.length === 1) {
        $str_viewSectionHeader = $str_viewSectionHeader + '<th id="" class="headers" style="width: 20px;">&nbsp;</th><th class="headers">Name</th>';
    } else {
        $str_viewSectionHeader = $str_viewSectionHeader + '<th id="" class="headers" style="width: 20px;">';
        if ($('#allowedsection').val() != 'add' && $('#allowedsection').val() != 'view' && $('#allowedsection').val() != 'add_view') {
            $str_viewSectionHeader = $str_viewSectionHeader + '<input type="checkbox" id="check_all" ' + checkedTrueOrNOt;
            if (oldSelectedArr.length >= 250) {
                $str_viewSectionHeader = $str_viewSectionHeader + 'checked=""'
            }
            $str_viewSectionHeader = $str_viewSectionHeader + ' name="check_all">'
        }
        $str_viewSectionHeader = $str_viewSectionHeader + '</th><th class="headers"><a id="name" title="Sort by Name" href="" data-column="name"';
        if (pageData.sortType) {
            if (pageData.sortType == "desc") {
                sortType = "asc";
            } else {
                sortType = "desc";
            }
        } else {
            sortType = "desc";
        }
        if (pageData.sortColumn === "name") {
            $str_viewSectionHeader = $str_viewSectionHeader + 'data-sort="' + sortType + '">Name</a></th>';
        } else {
            $str_viewSectionHeader = $str_viewSectionHeader + 'data-sort="' + sortType + '">Name</a></th>';
        }
    }

    $.each(headers, function (index, header) {

        if (header.name != 'userid' && header.name != 'name') {
            $str_viewSectionHeader = $str_viewSectionHeader + '<th  id="" class="headers column" style="width:120px; word-break: break-all;"><a id="' + header.sort + '" title="Sort by ' + header.displayName + '" href="" data-column="' + header.sort + '"  staff_field_id="' + header.staff_field_id + '"';

            if (pageData.sortType) {
                if (pageData.sortType == "desc") {
                    sortType = "asc";
                } else {
                    sortType = "desc";
                }
            } else {
                sortType = "asc";
            }
            if (pageData.sortColumn === header.sort) {
                $str_viewSectionHeader = $str_viewSectionHeader + 'data-sort="' + sortType + '">';
            } else {
                //MV-2219:Start
                if(header.displayName.indexOf("Account Status") == 0 && header.sort == "active")
                {
                    $str_viewSectionHeader = $str_viewSectionHeader + 'data-sort="desc">';
                }
                else
                {
                    $str_viewSectionHeader = $str_viewSectionHeader + 'data-sort="asc">';
                }
                //MV-2219:Stops
            }
			
			// Display Long Field Name as Short
			if((header.displayName).length > 13 ){
                //MV-2219:Start
                if(header.displayName.indexOf("Account Status") == 0 && header.sort == "active"){
                    $str_viewSectionHeader = $str_viewSectionHeader + header.displayName + '</a></th>';
                }
                else{
                    $str_viewSectionHeader = $str_viewSectionHeader + (header.displayName).substring(0,10) + '...' + '</a></th>';
                }	
                //MV-2219:Stops		
			}
			else{
				$str_viewSectionHeader = $str_viewSectionHeader + header.displayName + '</a></th>';
			}
			//MV-1015 : End
            

        }

    });
    var isBreakOut = 0;
    var breakOutFactor = "";
    var breakOutName = "";

    $.each(data, function (index, report) {
        $str_viewSection = $str_viewSection + '<tr>';
        if (report["breakoutfactor"] != null && report["breakoutfactor"].length > 0) {
            isBreakOut = 1;
            breakOutFactor = report["breakoutfactor"];
            breakOutName = report["breakoutname"];

            $str_viewSection = $str_viewSection + '<td class="wordwrap">';
            if ($('#allowedsection').val() != 'add' && $('#allowedsection').val() != 'view' && $('#allowedsection').val() != 'add_view') {
                $str_viewSection = $str_viewSection + '<input type="checkbox" class="check_userid_list_break_out" name="userid_list_break_out" id="' + breakOutFactor + '" value="" ></td>';
            }
            $str_viewSection = $str_viewSection + '<td colspan="' + (headers.length - 1) + '" class="wordwrap"><b>' + breakOutName + '</b></td>';
            $.each(headers, function (index, header) {

                if (header.name == 'name') {

                } else if (header.name == 'userid') {

                } else if (header.name == 'active') {

                    $str_viewSection = $str_viewSection + ' ';
                } else if (header.name == 'bit_role') {
                    $str_viewSection = $str_viewSection + ' ';

                } else if (header.name == 'email') {
                    $str_viewSection = $str_viewSection + ' ';

                } else if (header.name == 'firstname') {
                    $str_viewSection = $str_viewSection + ' ';
                /* MS 147 change*/
                } else if (header.name == 'lastname') {
                    $str_viewSection = $str_viewSection + ' ';
                } else if (header.name == 'enrollment_status') {

                    $str_viewSection = $str_viewSection + ' ';
                }else if (header.name == 'enrolled_date') {

                    $str_viewSection = $str_viewSection + ' ';
                }else if (header.name == 'phone_number') {

                    $str_viewSection = $str_viewSection + ' ';
                } else if (header.name == 'mobile_carrier') {

                    $str_viewSection = $str_viewSection + ' ';
                }
                else if (header.name == 'receive_text') {

                    $str_viewSection = $str_viewSection + ' ';
                } else if (header.name == 'site_assignments') {

                    $str_viewSection = $str_viewSection + ' ';

                } else if ((header.name).substring(0, 6) == 'Field_') {

                    $str_viewSection = $str_viewSection + ' ';
                    /* MS 147 change*/
                } else if ((header.name).substring(0, 9) == 'subpanel_') {
                    $str_viewSection = $str_viewSection + ' ';
                }
                /* MS 147 */

            });
        }

        // target="_blank"
        var isArchivedClass = "";
        $.each(headers, function (index, header) {
            checkbox_class = breakOutFactor;

            if (report["active"] == "Archived") {
                isArchivedClass = "isArchived";
            }

            if (report.breakoutfactor != null) {

            } else {
                if (header.name == 'name') {
                    if (headers.length == 1) {
                        $str_viewSection = $str_viewSection + '<td class="wordwrap">&nbsp;</td><td class="wordwrap" >' + report.name + '</td>';
                    } else {
                        $str_viewSection = $str_viewSection + '<td class="wordwrap">';

                        if ($('#allowedsection').val() != 'add' && $('#allowedsection').val() != 'view' && $('#allowedsection').val() != 'add_view' && window.userid != report.userid) { //MS-539
                           
                            if (isArchivedClass != '') {
                                $str_viewSection = $str_viewSection + '<input type="checkbox" class="check_userid_list ' + checkbox_class + ' ' + checkbox_class + report.userid + ' ' + isArchivedClass + '" name="userid_list" onclick="makethischeck($(this));" id="' + report.userid + '" ';
                            } else {
                                $str_viewSection = $str_viewSection + '<input type="checkbox" class="check_userid_list ' + checkbox_class + ' ' + checkbox_class + report.userid + '" name="userid_list" onclick="makethischeck($(this));" id="' + report.userid + '" ';
                            }
                            if (isInArray(report.userid, oldSelectedArr)) {
                                $str_viewSection = $str_viewSection + 'checked=""';
                            }
                            $str_viewSection = $str_viewSection + 'value="' + report.userid + '">';
                        }
                        if ($('#allowedsection').val() == 'all' || $('#allowedsection').val() == 'view' || $('#allowedsection').val() == 'add_edit' || $('#allowedsection').val() == 'edit' || $('#allowedsection').val() == 'add_view') {
                            $str_viewSection = $str_viewSection + '</td><td class="wordwrap"><a target="_blank" class="linktoeditvolunteer" href="index.cfm?event=user.editstaff&userid=' + report.encuserid + '" rel="index.cfm?event=user.editstaff&userid=' + report.encuserid + '" title="' + htmlEncode(report.name) + '" >' + htmlEncode(report.name) + '</a></td>'; /* MS 147 */
                        }
                        else {
                            $str_viewSection = $str_viewSection + '</td><td class="wordwrap">' + htmlEncode(report.name) + '</td>';
                        }
                    }
                } else if (header.name == 'userid') {

                } else if (header.name == 'bit_role') {
                    $str_viewSection = $str_viewSection + ' <td>' + report.bit_role + '</td>';
                } else if (header.name == 'active') {
                    if (report[header.name] == "1") {
                        value = "Active";
                    } else if (report[header.name] == "0") {
                        value = "No";
                    } else {
                        value = report[header.name];
                    }
                    $str_viewSection = $str_viewSection + ' <td>' + value + '</td>';
                } else if (header.name == 'enrollment_status') {
                    if (report[header.name] == "1") {
                        value = "Currently Enrolled";
                    } else if (report[header.name] == "0") {
                        value = "Previously Enrolled";
                    } else {
                        value = report[header.name];
                    }
                    $str_viewSection = $str_viewSection + ' <td class="email-column">' + value + '</td>';
                } else if (header.name == "receive_text") {

                    if (report.recieve_text == 1) {
                        value_text = "Yes";
                        $str_viewSection = $str_viewSection + ' <td class="email-column">' + htmlDecode(value_text) + '</td>';
                    }
                    else if (report.recieve_text == 0) {
                        value_text = "No";
                        $str_viewSection = $str_viewSection + ' <td class="email-column">' + htmlDecode(value_text) + '</td>';
                    }
                    else {
                        value_text = "";
                        $str_viewSection = $str_viewSection + ' <td class="email-column">' + htmlDecode(value_text) + '</td>';
                    }

                }
                
                else if (header.name == "phone_number") {
                    $str_viewSection = $str_viewSection + ' <td>' + report.phone_number + '</td>';
                }
                else if (header.name == "enrolled_date") {
                    $str_viewSection = $str_viewSection + ' <td>' + report.enrolled_date + '</td>';
                }
                else if (header.name == "email") {
                    $str_viewSection = $str_viewSection + ' <td>' + report.email + '</td>';
                }
                else if (header.name == "site_assignments") {
                    $str_viewSection = $str_viewSection + ' <td>' + report.site_assignments + '</td>';
                }
                //DS::CPORT-100
                else if (header.name == "receivecpemail") {
                    if (report.receivecpemail == 1) {
                        value_textemail = "Yes";
                        $str_viewSection = $str_viewSection + ' <td class="email-column">' + htmlDecode(value_textemail) + '</td>';
                    }
                    else if (report.receivecpemail == 0) {
                        value_textemail = "No";
                        $str_viewSection = $str_viewSection + ' <td class="email-column">' + htmlDecode(value_textemail) + '</td>';
                    }
                }
                //DS::CPORT-100
                else {
                    var headerName = header.name;
                    var headerName1=report[header.name];
                    if (headerName.substring(0, 6) == 'Field_') {
                        if(headerName1.length > 0){
                        $str_viewSection = $str_viewSection + ' <td class="email-column1">' + headerName1.replaceAll("$dquote$", '"').replaceAll("$squote$", "'") + '</td>';   
                        }
                        else{
                            $str_viewSection = $str_viewSection + ' <td class="email-column1">' + headerName1 + '</td>';
                           }
                    } else {
                        if(headerName1.length > 0){
                        $str_viewSection = $str_viewSection + ' <td class="email-column1">' + headerName1.replaceAll("$dquote$", '"').replaceAll("$squote$", "'") + '</td>';   
                        }
                        else{
                            $str_viewSection = $str_viewSection + ' <td class="email-column1">' + headerName1 + '</td>';
                           }
                    }

                }
            }
        });

        //MS-40
        if (report.name == 'No active staff accounts currently exist.' || report.name == 'No archived staff accounts currently exist.' || report.name == 'No active or archived staff accounts currently exist.') {
            $('#export_roster').hide();
        } else {
            $str_viewSection = $str_viewSection + ' ';
            $('#export_roster').show();
        }
        $str_viewSection = $str_viewSection + '</tr>';
    });
    $str_viewSection = $str_viewSectionHeader + $str_viewSection + '</tbody></table>';
    reportSection.html($str_viewSection);

    var page_container_ajax = $('#page_container_ajax');
    var full_page_container_ajax = $('#full_page_container_ajax');
    var page_container_main = $('#page_container_main');
    var full_page_container_main = $('#full_page_container_main');
    var itemsChecked = $("input[type=radio]:checked,input[type=checkbox]:checked");
    var savedview = $("#viewsaved").val();
    if (headers.length >= 5) {
        if (page_container_main.html().length > 0) {
            page_container_ajax.html(page_container_main.html());
        }
        page_container_main.html('');
        full_page_container_ajax.show();
        full_page_container_main.hide();
        itemsChecked.each(function (i) {
            $("input[id ='" + this.id + "']").prop("checked", true); //MS-147
        });
        /*change table styles*/
        if (headers.length >= 15) {
            $('.viewSection').css('width', '99%');
        } else {
            $('.viewSection').css('width', '95%');
        }

        $('.listing-table').css('width', '100%');
        $('table.mc_activate_deactivate').css('width', '100%');
        widthOverride = (100 * headers.length) + 550;
        if (widthOverride < 1100) {
            widthOverride = 1100;
        }
        $('.main').css('width', widthOverride);
        $('#viewHeaderAlbhabetSection').addClass('albhabetSectionExpanded');
        $('.header_full_ajax').show();
        $('.header_full_main').hide();
    } else {
        if (page_container_main.html().length == 0) {
            $('table.mc_activate_deactivate').css('width', '500px');
            page_container_main.html(page_container_ajax.html());
            page_container_ajax.html('');
            full_page_container_main.show();
            full_page_container_ajax.hide();
            $("input[type=radio]:checked,input[type=checkbox]:checked").prop('checked', false);
            itemsChecked.each(function (i) {
                $("input[id ='" + this.id + "']").prop("checked", true); //MS-147
            });
            $('.main').css('width', '765px');
            $('#viewHeaderAlbhabetSection').removeClass('albhabetSectionExpanded');
            $('.header_full_ajax').hide();
            $('.header_full_main').show();
            $('.viewSection').css('width', '475px');
        }
    }
    /* MV-2153(K):Start */
	$('input[name="str_optnl_break_out"]:checked').each( function(){
		var current_str_optnl_break_out = $(this).val();
		if(current_str_optnl_break_out == 'account_status'){
			var currentaccountstatusvalue = $('#currentaccountstatusvalue').val();
			if(currentaccountstatusvalue.length > 0){
                var currentaccountstatusvaluearr = currentaccountstatusvalue.split(',');
				for(i of currentaccountstatusvaluearr){
					if(i == 'Live'){
						$('#status_1').find($('input[name="account_status"]')).prop('checked', true);
					}else if(i == 'Invited'){
						$('#status_2').find($('input[name="account_status"]')).prop('checked', true);
					}else if(i == 'Awaiting Invitation'){
						$('#status_3').find($('input[name="account_status"]')).prop('checked', true);
					}else if(i == 'Archived'){
						$('#status_4').find($('input[name="account_status"]')).prop('checked', true);
					}
				}
			}
		}
	});
	/* MV-2153(K):Stop */
    return true;
}

var noOfArchivedSelected = 0;
function makethischeck(getattibute) {

    var classList = getattibute.prop("class").split(' ');
    var lastElement = classList.length - 1;

    if (classList[lastElement] == "isArchived") {

        newlastElement = classList.length - 2;

        if (classList[lastElement] == "isArchived" && getattibute.prop("checked") == true) {
            noOfArchivedSelected++;
        }
        else if (classList[lastElement] == "isArchived" && getattibute.prop("checked") == false) {
            noOfArchivedSelected--;
        }

        if (noOfArchivedSelected > 0) {
            $("#sel_action > #archSele").attr('disabled', true);
            $("#sel_action > #actSel").attr('disabled', true);
            $("#sel_action > #deactSel").attr('disabled', true);
        }
        else if (noOfArchivedSelected == 0) {
            $("#sel_action > #archSele").attr('disabled', false);
            $("#sel_action > #actSel").attr('disabled', false);
            $("#sel_action > #deactSel").attr('disabled', false);
        }

        var _val = getattibute.val().toString();
        if (getattibute.is(':checked')) {
            $('input[id=' + _val + ']').prop('checked', true);//MV-2058
        } else {
            $('input[id=' + _val + ']').prop('checked', false);//MV-2058
            var arr_selected = $('#selectedUsers').val().split(',');
            $(arr_selected).each(function (e, i) {
                var _iValue = i.toString();
                if (_iValue == _val) {
                    arr_selected.splice($.inArray(_iValue, arr_selected), 1);
                }
            });
            $('#selectedUsers').val(arr_selected.toString());
        }

    } else {

        var _val = getattibute.val().toString();
        if (getattibute.is(':checked')) {
            $('input[id=' + _val + ']').prop('checked', true);//MV-2058
        } else {
            $('input[id=' + _val + ']').prop('checked', false);//MV-2058
            var arr_selected = $('#selectedUsers').val().split(',');
            $(arr_selected).each(function (e, i) {
                var _iValue = i.toString();
                if (_iValue == _val) {
                    arr_selected.splice($.inArray(_iValue, arr_selected), 1);
                }
            });
            $('#selectedUsers').val(arr_selected.toString());
        }
    }

    $("#sel_action option[value='-1']").prop('selected', true);
    setSelectedCount(false);
}

function rendercustomisedview() {
    var colselected = $('#hidcolselected').val();
    //alert(colselected);
    var optbreakoutselected = $('#hidoptbreakoutselected').val();
    var siteassignselected = $('#hidsiteassignselected').val();
    var accountstatusoptbreakoutselected = $('#hidaccountstatusoptbreakoutselected').val();	// MV-2153(K) //
    var siteassignoptbreakoutselected = $('#hidsiteassignoptbreakoutselected').val();
    var elements_active = $('.option_break_type1 label input[data-active=1]');
    var elements_inactive = $('.option_break_type1 label input[data-active=0]');
    var alphabeticFilterhid = $('#alphabeticFilterhid').val();
    var searchfilterhid = $('#strsearchhid').val();
    var intstartrowhid = $('#intstartrowhid').val();
    var sortColumnhid = $('#sortColumnhid').val();
    var sortTypehid = $('#sortTypehid').val();
    var type1open = 0;
    var type2open = 0;
    var type3open = 0;
    if (colselected.length != 0) {
        colselectedarr = colselected.split(",");
        $.each(colselectedarr, function (i) {
            $('#' + colselectedarr[i]).prop('checked', true);
        });
        $('#column-selection-list').css('display', 'block');
    }
    if (optbreakoutselected.length != 0) {
        $('#str_none_break_out').prop('checked', false);
        $('#' + optbreakoutselected).prop('checked', true);
        $('#breakoutby-list').css('display', 'block');

        if (optbreakoutselected == 'str_site_assgmnt_optnl_break_out') {
            if (siteassignselected.length != 0) {//alert(siteassignselected);
                siteassignselectedarr = siteassignselected.split(",");
                $.each(siteassignselectedarr, function (i) {
                    $('#' + siteassignselectedarr[i]).prop('checked', true);
                    if (siteassignselectedarr[i] == 'str_site_assgmnt_optnl_break_out_all_active') {
                        //alert(0);
                        $('.option_break_type1 label input[data-active=1]').parent().parent().show();
                    }
                    if (siteassignselectedarr[i] == 'str_site_assgmnt_optnl_break_out_all_inactive') {
                        $('.option_break_type1 label input[data-active=0]').parent().parent().show();
                    }
                });

            }
            if (siteassignoptbreakoutselected.length != 0) {
                siteassignoptbreakoutselectedarr = siteassignoptbreakoutselected.split(",");
                $.each(siteassignoptbreakoutselectedarr, function (i) {
                    $('#' + siteassignoptbreakoutselectedarr[i]).prop('checked', true);
                });
            }
            $('#site_assgment_break_box1').css('display', 'block');
        }
        // MV-2153(K):Start //
		if(optbreakoutselected == 'str_account_status_assgmnt_optnl_break_out'){
			var setStatusId = '';
			if(accountstatusoptbreakoutselected.length != 0){
                var accountstatusoptbreakoutselectedarr = accountstatusoptbreakoutselected.split(',');
                for(statusval of accountstatusoptbreakoutselectedarr){
                    setStatusId = (statusval == 'Live')? 'status_1':(statusval == 'Invited')? 'status_2':(statusval == 'Awaiting Invitation')? 'status_3':(statusval == 'Archived')? 'status_4':'';
                    if(setStatusId)
                        $('#'+setStatusId).find('input').attr('checked', 'checked');	
                }
			}
			var enrolled_option = $('#bit_all_enrolled').is(':checked'); 
			var archived_option = $('#bit_not_enrolled').is(':checked');
			if(enrolled_option == true && archived_option == false){
				$("#status_4").hide();
				$("#status_1").show();
				$("#status_2").show();
				$("#status_3").show();
			}else if(enrolled_option == false && archived_option == true){
				$("#status_4").show();
				$("#status_1").hide();
				$("#status_2").hide();
				$("#status_3").hide();
			}else if(enrolled_option == true && archived_option == true){
				$("#status_1").show();
				$("#status_2").show();
				$("#status_3").show();
				$("#status_4").show();
			}
            var statuscount = (enrolled_option && !archived_option) ? 3 :
                           (!enrolled_option && archived_option) ? 1 :
                           (enrolled_option && archived_option) ? 4 :
                           0;
            var account_status_checked_count = 0;
            $('input:checkbox[name="account_status"]:checked').each(function() { 
                account_status_checked_count += 1;
            });	
            if(account_status_checked_count == statuscount && statuscount != 0){
                $('#account-status-option-break-selectall').html('Select None');
            }else{
                $('#account-status-option-break-selectall').html('Select All');
            }
			$('#account-toggle-wrapper').css('display','block');
		}
		// MV-2153(K):Stop //
    }
    if($.trim(alphabeticFilterhid) != ''){   /* MS 147 */
        $('#' + alphabeticFilterhid).parent().addClass('active');
        $('#' + alphabeticFilterhid).parent().siblings('li').removeClass('active');
        
    }   /* MS 147 */
    $('#alphabeticFilter').val(alphabeticFilterhid);
    $('#str_search').val(searchfilterhid);
    $('#sortColumn').val(sortColumnhid);
    $('#sortType').val(sortTypehid);
    showLoadingOverlay();
    $('.volunteer_success_message').hide();
    $('.view_success_message').hide();
    var _this = $("#form_customizedviews");
    var str_viewname = htmlEncode($("#str_view_name").val());
    var searchfilter = $('#str_search').val();
    if ($.trim(intstartrowhid).length != 0)
        var int_start_row = intstartrowhid;
    else
        var int_start_row = 1;
    var alphabeticFilter = $('#alphabeticFilter').val();
    var sortColumn = $('#sortColumn').val();
    var sortType = $('#sortType').val();
    var sortColumnhid = $('#sortColumnhid').val();
    var sortTypehid = $('#sortTypehid').val();
    var postData = _this.serializeArray();
    //validation
    var frmData = _this.serializeArray();
    $('body').data('formdata', frmData);

    postData.push({
        "name": "alphabeticFilter",
        "value": alphabeticFilter
    });
    postData.push({
        "name": "searchfilter",
        "value": searchfilterhid
    });
    postData.push({
        "name": "int_start_row",
        "value": int_start_row
    });
    postData.push({
        "name": "sort_column",
        "value": sortColumnhid
    });
    postData.push({
        "name": "sort_type",
        "value": sortTypehid
    });

    status = false;
    if (str_viewname && str_viewname.trim().length) {
        //validate for similar name
        $.ajax({
            url: "index.cfm?event=user.saveaview",
            type: "post",
            data: postData,
            dataType: "json",
            success: function (resp, textStatus, jqXHR) {
                if (resp.data.status == "ok") {
                    status = loadUsersList(postData, "");
                    hideLoadingOverlay();
                    $('#view_success_msg').html(resp.data.msg);
                    $('.view_success_message').removeClass('hide').show();
                } else {
                    alert(resp.data.msg);
                    hideLoadingOverlay();
                    return false;
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
            }
        });
    } else {
        status = loadUsersList(postData, "");
        if (status == true)
            hideLoadingOverlay();
    }
}
function renderalphabeticfilter() {
    var alphabeticFilterhid = $('#alphabeticFilterhid').val();
    var searchfilterhid = $('#strsearchhid').val();
    var intstartrowhid = $('#intstartrowhid').val();
    var sortColumnhid = $('#sortColumnhid').val();
    var sortTypehid = $('#sortTypehid').val();
    var sortColumnhid = $('#sortColumnhid').val();
    var sortTypehid = $('#sortTypehid').val();
    if($.trim(alphabeticFilterhid) != ''){   /* MS 147 */
        $('#' + alphabeticFilterhid).parent().addClass('active');
        $('#' + alphabeticFilterhid).parent().siblings('li').removeClass('active');
    }  /* MS 147 */
    if(searchfilterhid.length !== 0){
		$("#search_icon_new").removeClass('search_inactive').addClass('search_active').attr('src','images/icons/cancel_icon.png');		/*  MV-1697 -- Retain saved View */
	}
    $('#alphabeticFilter').val(alphabeticFilterhid);
    $('#str_search').val(searchfilterhid);
    $('#sortColumn').val(sortColumnhid);
    $('#sortType').val(sortTypehid);
    var searchfilter = $('#str_search').val();
    if ($.trim(intstartrowhid).length != 0)
        var int_start_row = intstartrowhid;
    else
        var int_start_row = 1;
    var sortColumn = $('#sortColumn').val();
    var sortType = $('#sortType').val();
    var postData = $('body').data('formdata');
    var bit_push = 1;
    $(postData).each(function (i) {
        if (postData[i]['name'] == "alphabeticFilter") {
            postData[i]['value'] = alphabeticFilter;
            bit_push = 0;
        } else if (postData[i]['name'] == "searchfilter") {
            postData[i]['value'] = searchfilter;
        } else if (postData[i]['name'] == "sort_column") {
            postData[i]['value'] = sortColumn;
        } else if (postData[i]['name'] == "sort_type") {
            postData[i]['value'] = sortType;
        } else if (postData[i]['name'] == "int_start_row") {
            postData[i]['value'] = int_start_row;
        }
    });
    if (bit_push == 1) {
        postData.push({
            "name": "alphabeticFilter",
            "value": alphabeticFilterhid
        });
    }
    if (int_start_row != 1) {
        postData.push({
            "name": "int_start_row",
            "value": int_start_row
        });
    }
    postData.push({
        "name": "sort_column",
        "value": sortColumnhid
    });
    postData.push({
        "name": "sort_type",
        "value": sortTypehid
    });
    postData.push({
        "name": "searchfilter",
        "value": searchfilterhid
    });
    //setSelectedUsers();
    var status = loadUsersList(postData, "");
    $('#alphabeticFilter').val(alphabeticFilterhid);
    if (status === true) {
        hideLoadingOverlay();
    }
    $('.volunteer_success_message').hide();
    $('.view_success_message').hide();
}

function renderprevnextlink() {

    var alphabeticFilterhid = $('#alphabeticFilterhid').val();
    var searchfilterhid = $('#strsearchhid').val();
    var intstartrowhid = $('#intstartrowhid').val();//alert(intstartrowhid);
    var sortColumnhid = $('#sortColumnhid').val();
    var sortTypehid = $('#sortTypehid').val();
    var sortColumnhid = $('#sortColumnhid').val();
    var sortTypehid = $('#sortTypehid').val();
    if ($.trim(intstartrowhid).length != 0) {
        
        if ($.trim(alphabeticFilterhid).length != 0) { /* MS 147 */
            $('#' + alphabeticFilterhid).parent().addClass('active');
            $('#' + alphabeticFilterhid).parent().siblings('li').removeClass('active');
        } /* MS 147 */
        if(searchfilterhid.length !== 0){
            $("#search_icon_new").removeClass('search_inactive').addClass('search_active').attr('src','images/icons/cancel_icon.png');		/*  MV-1697 -- Retain saved View */
        }
        $('#alphabeticFilter').val(alphabeticFilterhid);
        $('#str_search').val(searchfilterhid);
        $('#sortColumn').val(sortColumnhid);
        $('#sortType').val(sortTypehid);
        var searchfilter = $('#str_search').val();
        if ($.trim(intstartrowhid).length != 0)
            var int_start_row = intstartrowhid;
        else
            var int_start_row = 1;
        var sortColumn = $('#sortColumn').val();
        var sortType = $('#sortType').val();
        var postData = $('body').data('formdata');
        var bit_push = 1;
        var bit_saved = 1;
        $(postData).each(function (i) {
            if (postData[i]['name'] == "alphabeticFilter") {
                postData[i]['value'] = alphabeticFilter;

            } else if (postData[i]['name'] == "searchfilter") {
                postData[i]['value'] = searchfilter;
            } else if (postData[i]['name'] == "sort_column") {
                postData[i]['value'] = sortColumn;
            } else if (postData[i]['name'] == "sort_type") {
                postData[i]['value'] = sortType;
            } else if (postData[i]['name'] == "int_start_row") {
                postData[i]['value'] = int_start_row;
                bit_push = 0;
            }else if (postData[i]['name'] == "saved_view") {
                postData[i]['value'] = data_saved_view;
                bit_saved = 0;
            }
        });
        if (bit_push == 1) {
            postData.push({
                "name": "int_start_row",
                "value": int_start_row
            });
        }
        postData.push({
            "name": "sort_column",
            "value": sortColumnhid
        });
        postData.push({
            "name": "sort_type",
            "value": sortTypehid
        });
        postData.push({
            "name": "searchfilter",
            "value": searchfilterhid
        });
        setSelectedUsers();
        var status = loadUsersList(postData, "");

        if ($.trim(alphabeticFilterhid).length != 0) {
            $('#alphabeticFilter').val(alphabeticFilterhid);
        }

        if (status === true) {
            hideLoadingOverlay();
        }
        $('.volunteer_success_message').hide();
        $('.view_success_message').hide();
    }
}
function rendersavedview() {
    var _this = $("#form_savedviews");
    var str_viewname = $("#str_view_name").val();
    var searchfilter = $('#str_search').val();
    var int_start_row = $('#intstartrowhid').val();
    var alphabeticFilter = $('#alphabeticFilter').val();
    var sortColumn = $('#sortColumn').val();
    var sortType = $('#sortType').val();
    var sortColumnhid = $('#sortColumnhid').val();
    var sortTypehid = $('#sortTypehid').val();
    var searchfilterhid = $('#strsearchhid').val();
    if(searchfilterhid.length != 0){
		$("#search_icon_new").removeClass('search_inactive').addClass('search_active').attr('src','images/icons/cancel_icon.png');		/*  MV-1697 -- Retain saved View */
	}
    //MV-1368 :: 1402
	var hidselectedview_idd_back ='';
	var hidselectedviews_back ='';
	var selectedViews=$("#hidselectedsavedviewreload").val();
	var savedviewselected_onload_back = $('#savedviewselection').val();
	if(savedviewselected_onload_back == 'AllactivestaffView'){
		hidselectedview_idd_back = 'AllactivestaffView';
	}
	else{
		 hidselectedviews_back = savedviewselected_onload_back.split("_")[2];
	}
	$('input[name="saved_view"]').each(function(){
		var sidnew = $(this).attr('sid');
		if(selectedViews != sidnew){
			$(this).attr('checked',false);
		}
	})
	if(selectedViews==0 || selectedViews == 'AllactivestaffView' ){
		$("#AllactivestaffView").attr('checked', true);
	}else{
		$("#saved_view_"+selectedViews).attr('checked', true);
	}
    if(selectedViews == hidselectedview_idd_back){}
	  else if(hidselectedviews_back != selectedViews){
		searchfilterhid = '';
		$('#str_search').val('');
		alphabeticFilter = '';
	}
	//MV-1368 :: 1402
    var postData = _this.serializeArray();
    $('#sortColumn').val('');
    $('#sortType').val('');
    $('body').data('formdata', postData);
    postData.push({
        "name": "alphabeticFilter",
        "value": alphabeticFilter
    });
    postData.push({
        "name": "searchfilter",
        "value": searchfilterhid
    });
    postData.push({
        "name": "int_start_row",
        "value": int_start_row
    });
    postData.push({
        "name": "sort_column",
        "value": sortColumnhid
    });
    postData.push({
        "name": "sort_type",
        "value": sortTypehid
    });
    var status = loadUsersList(postData, "");
    $('.volunteer_success_message').hide();
    $('.view_success_message').hide();
}

// Radio button Add a New Staff Member
$(document).on('click', '#rad_add_member', function (e) {  /* MS-147*/
    //$('#rad_add_member').click(function() {	
    e.stopImmediatePropagation();	 //MS-147
    if ($('#insidebox_new_member').css('display') == 'none') {
        $('#insidebox_new_member').slideDown(1000);
        $('#insidebox_customize').slideUp(1000);
        $('#insidebox_saved').slideUp(1000);
        $('#user_remaining').show();
        // MS-105 start 
        var divHeight = $('.col-1').height();
        $('.col-2').css('height', divHeight + 'px');
        var col3height = $('.col-3').height();
        var col4height = $('.col-4').height();
        if (col3height > col4height) {
            $('.col-4').css('height', col3height + 'px');
        } else {
            $('.col-3').css('height', col4height + 'px');
        }
        // MS-105 End
		
		/*MS-147:216*/
		if($('#getusertype').val()=='submanager'){
			jQuery('.red-alert').tooltip({
				hide:true,			
				tooltipClass:"redoption-alert greyoption-alert",
				position: {
							my: "left+2 center",
							at: "right center"
				},
			});			
			if(createStaffCohortPermission == 0){
				$("#CustomCohort").prop("checked", true);
				$("input[name=AssignmentTypeCohort][value=1]").prop("checked", true);
				$('.customviewcohort').css("display","block");
			}			
		}
		/*MS-147:216*/
    } else {
        $(this).prop('checked', false);
        $('#insidebox_new_member').slideUp(1000);
        $('#user_remaining').hide();
    }
});

// Add a New Staff Member
//$('#btn_add_staff').click(function() {
$(document).on('click', '#btn_add_staff', function (e) {   /* MS-147*/
    $('#btn_add_staff').attr('disabled', true);/* MS-147*/
    e.stopImmediatePropagation();   /* MS-147*/
   // $('.customview').hide(); // MS-105 :: MS-116 //Commented for MS-384
    $('#scopeSelectToggle_site').hide(); // MS-105 :: MS-116 
    $('#btn_add_staff_temp').hide(); //ms 147 pentesting changes
     $('#checksaved').val(0);/* MS-147*/
    if ($('input[id=check_all]').is(':checked')) {
        //console.log('yes')
        $('input[id=check_all]').prop('checked', true);
    } else {
        //console.log('no')
        $('input[id=check_all]').prop('checked', false)
    }
    var res = validateForm();
    if (res) {
        /*Added  For MS-45 Starts Here*/
        var url = 'index.cfm?event=user.checkStaffSafety';
        var newemail = $("#Email").val().trim();//AF-371
        var staffPassword = $("#pwd").val();
        var currentProgramId = $("#ProgramID").val();
        var FirstName = $("#FirstName").val();
        FirstName = FirstName.replaceAll(/\s+/g, ' ').trim();//MV-2043
        var LastName = $("#LastName").val();
        LastName = LastName.replaceAll(/\s+/g, ' ').trim();//MV-2043
        $.ajax({
            type: "post",
            async: true,
            data: {
                email: newemail,
                // password : staffPassword,
                fname: FirstName,
                lname: LastName,
                userid: -11
            },
            url: url,
            dataType: "json",
            success: function (data) {

                for (var i = 0; i < data.length; i++) {
                    /*Commented for adminfunct-34*/
                    /*if(data[i].result == 'notallow')
                        {
                            msg = "Please enter an alternate email address or password.";
                            alert(msg);
                            $('#btn_add_staff_temp').hide();
                                  $('#btn_add_staff').show();									
                            $('#btn_add_staff').attr('disabled',false);
                        break;
                        }
                                            	
            else if(data[i].result == 'changepassword')
                        {
                            msg = "Please select a different password for this person.";
                            alert(msg);
                                $('#btn_add_staff_temp').hide();
                                  $('#btn_add_staff').show();	
                            $('#btn_add_staff').attr('disabled',false);
                        break;
                        }
                    else if(data[i].result == 'anotherprogram')
                        {
                            msg = "You cannot save this user because the email address and password already exist in another program.";
                            alert(msg);
                                $('#btn_add_staff_temp').hide();
                                  $('#btn_add_staff').show();	
                            $('#btn_add_staff').attr('disabled',false);
                        break;
                        }							
                    else if(data[i].result == 'Restore'){
                         addStaffsWithOutDuplicateEmails(true);
                    }*/
                    /*Added for adminfunct-34*/
                    if (data[i].result == 'notallow') {
                        msg = "An account with this e-mail address already exists.  Please see the account for " + FirstName + " " + LastName + "."; //MS-124
                        alert(msg);
                        $('#btn_add_staff_temp').hide();                       
                         $('#btn_add_staff').attr('disabled', false);/* MS-147*/
                        break;
                    }/*MS 576 Start*/
                    else if(data[i].result == 'Invalid first name'){
                        msg = "Please enter a valid first name up to 72 characters that contains only letters, numbers, open parentheses, closed parentheses, accents above letters, periods and astrices.";//MV-2062
                        alert(msg);
                        $('#btn_add_staff_temp').hide();                       
                         $('#btn_add_staff').attr('disabled', false);
                        break;
                    }else if(data[i].result == 'Invalid last name'){
                        msg = "Please enter a valid last name up to 72 characters that contains only letters, numbers, open parentheses, closed parentheses, accents above letters, periods and astrices.";//MV-2062
                        alert(msg);
                        $('#btn_add_staff_temp').hide();                       
                         $('#btn_add_staff').attr('disabled', false);
                        break;
                    }else if(data[i].result == 'Invalid email'){
                        msg= "Please enter a valid e-mail address.";
                        alert(msg);
                        $('#btn_add_staff_temp').hide();                       
                        $('#btn_add_staff').attr('disabled', false);
                       break;
                    
                    }/*MS 576 End*/ 
                    else if(data[i].result == 'allow'){
                        addStaffsWithOutDuplicateEmails(false);
                    }
                }
                //return true;
            }
        });
        /*Added For MS-45 Ends Here*/
    }
    else {
        $('#btn_add_staff_temp').hide();
        $('#btn_add_staff').attr('disabled', false);
    }

});

function addStaffsWithOutDuplicateEmails(msg) {
    ClearUserMessage();
    // var emailExistance = isEmailExistOnAdd_EnrolledIs1();           	
    //if(emailExistance) {	
    $('#btn_add_staff_temp').hide(); //ms 147 pentesting changes
    showLoadingOverlay();
    var _current_time_cache = new Date().getTime();
    var fname = $('#FirstName').val();
    fname = fname.replaceAll(/\s+/g, ' ').trim();//MV-2043
    var lname = $('#LastName').val();
    lname = lname.replaceAll(/\s+/g, ' ').trim();//MV-2043
    var mail = $('#Email').val();
    var mobile = $('#Mobile').val();
    //alert(mobile);
    //var carrier = $("#sel_Carrier").val();
    //alert(carrier);
    var role = $("#sel_userRole").val();
    var staffPassword = $("#pwd").val();
    var SiteId_List = $('#blueBox_site .selectedScope .tick');//MS-384 //$('[name="Sites"]:checked');
	//console.log(SiteId_List)
	
    var selectedSite = [];
    var addstafftoken = $('#addstafftoken').val();  /* MS -147 */
    var AllTimeAssignmentType = $('[name="AllTimeAssignmentType"]:checked').val();//MS-105
    if (AllTimeAssignmentType == 3) {//MS-105 
        SiteId_List.each(function () {
			//MS-384
			var sid=$(this).attr('id');
			console.log(sid)
            if (!isInArray($(this).attr('id'), selectedSite)) {
                selectedSite.push($('#input'+sid).val());
            }
			//MS-384
        });
        //MS-105 Start    
    } else if (AllTimeAssignmentType == 2 || AllTimeAssignmentType == 1) {
        selectedSite = $('#AllTimeAssignmentTypeSites').val();
    } else {
        AllTimeAssignmentType = "";
    }
    //MS-105 End

    /*SiteManage-1:Start*/
    if (IsCohort_Enable == 1 && cohortacessIsEnable == 1) {
        //var CohortId_List = $('[name="Cohorts"]:checked');
        var CohortId_List = $("#blueBox_Cohort .selectedCohortScope .tick");//MS-629
        var selectedCohort = [];
        var AllTimeAssignmentType_Cohort = $('[name="AllTimeAssignmentType-Cohort"]:checked').val();
        if (AllTimeAssignmentType_Cohort == 3) {
            CohortId_List.each(function () {
              var cid=$(this).attr('id');//MS-629
                if (!isInArray($(this).attr('id'), selectedCohort)) {
                    //selectedCohort.push($(this).val());
                    selectedCohort.push($('#input'+cid).val());//MS-629
                }
            });
        }
        else if (AllTimeAssignmentType_Cohort == 2 || AllTimeAssignmentType_Cohort == 1) {
            selectedCohort = $('#AllTimeAssignmentTypeCohorts').val();
        }
        else {
            AllTimeAssignmentType_Cohort = "";
        }
    }
    /*SiteManage-1:Stops*/
    //ADMINFUNCT-34
    var sendmail = '';
    if ($('#sendmail').is(":checked")) {
        sendmail = $('#sendmail').val();
    }
    //ADMINFUNCT-34

    var postData = [];
    postData.push({
        "name": "FirstName",
        "value": fname
    });
    postData.push({
        "name": "LastName",
        "value": lname
    });
    postData.push({
        "name": "Email",
        "value": mail
    });
    /*Added by dk : MS-9 Starts*/
    postData.push({
        "name": "Mobile",
        "value": mobile
    });
    /* MS -147 */
    postData.push({
        "name": "addstafftoken",
        "value": addstafftoken
    });
    /* MS -147 */
    /*postData.push({
       "name": "Carrier",
       "value": carrier
    });*/
    postData.push({
        "name": "Role",
        "value": role
    });
    postData.push({
        "name": "StaffPassword",
        "value": staffPassword
    });
    postData.push({
        "name": "Sites",
        "value": selectedSite
    });
    //ADMINFUNCT-34
    postData.push({
        "name": "sendmail",
        "value": sendmail
    });
    //ADMINFUNCT-34
    //MS-105 Start
    postData.push({
        "name": "AllTimeAssignmentType",
        "value": AllTimeAssignmentType
    });
    //MS-105 End
    /*Added by dk : MS-9 Ends*/

    /*SiteManage-1:Start*/
    if (IsCohort_Enable == 1 && cohortacessIsEnable == 1) {
        postData.push({
            "name": "Cohorts",
            "value": selectedCohort
        });
        postData.push({
            "name": "AllTimeAssignmentType_Cohort",
            "value": AllTimeAssignmentType_Cohort
        });

        
    }
    /*SiteManage-1:Stops*/

    var data = [];
    $("#subpanel_staff_field").val('');
    var alphabeticFilter = $('#alphabeticFilter').val();
    var searchfilter = $('#str_search').val();
    var int_start_row = $('#int_next_start_row').val();
    var sortColumn = $('#sortColumn').val();
    var sortType = $('#sortType').val();
    var staffcusttoken = $('#staffcusttoken').val();
    /*  MV-1697 -- Retain saved View at the of add new staff member*/
    var data_saved_view = $('#hidselectedsavedviewreload').val();   //MV-1697::MV-1803
   // var data_saved_view = $("input[name='saved_view']:checked").attr('sid');      //Commented for MV-1697::MV-1803
    if(data_saved_view > 0){
        data.push({
            "name": "saved_view",
            "value": data_saved_view
        });

    }
    /*  MV-1697 -- Retain saved View */
    if ($('#bit_all_enrolled').is(':checked')) {
        data.push({
            "name": "bit_all_enrolled",
            "value": 1
        });
    }
    if ($('#bit_not_enrolled').is(':checked')) {
        data.push({
            "name": "bit_not_enrolled",
            "value": 1
        });
    }
    if (!$('#bit_all_enrolled').is(':checked') && !$('#bit_not_enrolled').is(':checked')) {
        data.push({
            "name": "bit_all_enrolled",
            "value": 1
        });
    }
    data.push({
        "name": "alphabeticFilter",
        "value": alphabeticFilter
    });
    data.push({
        "name": "searchfilter",
        "value": searchfilter
    });
    data.push({
        "name": "int_start_row",
        "value": 1
    });
    data.push({
        "name": "sort_column",
        "value": ''
    });
    data.push({
        "name": "sort_type",
        "value": ''
    });
	data.push({
		"name": "staffcusttoken",
		"value": staffcusttoken
	});
    $.ajax({
        type: "POST",
        url: "index.cfm?event=user.addstaffmembers&currenttimestamp=" + _current_time_cache,
        data: postData,
        success: function (userdata) {                      
            var userdata = JSON.parse(userdata);
            hideLoadingOverlay();
            if (userdata.usertoken) { 
                if (msg)
                    $("#edit_volun_link").text("View " + fname + " " + lname + "'s Restored Account");
                else
                    $("#edit_volun_link").text("View " + fname + " " + lname + "'s  Account");
                //getallemaillist();
                /*MS-213:Start*/
                var filtercount = 0;
                if (userdata.userType == "submanager") {
                    
                    var filteredRoleIdList = userdata.filteredRoleIdList;
                    var filterarray = filteredRoleIdList.toString().split(",");
                    for (var i = 0; i < filterarray.length; i++) {
                        var stringPart = filterarray[i];
                        
                        if (stringPart == userdata.roleId) {
                            filtercount++;
                        }
                    }
                    /*Code Commented As Per MS-306(Point 8) Requirements*/
                    if(filteredRoleIdList == "ALL"){
                        filtercount++;
                    }
                } 
                
                if (userdata.userType == "manager" || (userdata.userType == "submanager" && filtercount > 0)) {
                    $("#edit_volun_link").attr("href", "index.cfm?event=user.editstaff&userid=" + userdata.newUserID);
                    $("#edit_volun_link").css("cursor", "pointer")
                    $("#edit_volun_link").css("opacity", "1");
                }
                else {
                    $("#edit_volun_link").attr("href", "javascript:void(0)");
                    $("#edit_volun_link").css("cursor", "default")
                    $("#edit_volun_link").css("opacity", "0.4");
                }
                /*MS-213:Stops*/
                $('#add_new_member').trigger("reset");
                $('#btn_add_staff_temp').show();
                // $('#btn_add_staff').attr('disabled', true);
                $('.noAssignment').show();
                $('.selectedScope').remove();
                initsite();
                $('#btn_add_staff_temp').hide();
                 $('#btn_add_staff').attr('disabled', false);/* MS-147*/
                loadUsersList(data);
            }
            
        },
        error: function(){
            hideLoadingOverlay(); 
        }
    });
}

// Validation for Add a New Staff Member
function isValidEmail(email) {
    //var regex = /^([a-zA-Z0-9_.+-\\'])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    //var regex = /^\b[A-Z0-9.%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i; /* MS 147 */ /* comment for MS-400 */
    return emailregex.test(email);
}

function validateForm() {   
    var errFlg = true;
    var msg = "";

    /*SiteManage-1:Start*/
    if (IsCohort_Enable == 1 && cohortacessIsEnable == 1) {
        if ($('input[name="AllTimeAssignmentType-Cohort"]:checked').val() === undefined) {
            // errFlg = false;
            // msg = msg + "Please assign atleast one cohort from cohort assignments section.\n";
        }
        else if ($('input[name="AllTimeAssignmentType-Cohort"]:checked').val() === '3' && $('#CustomCohort').is(':checked') == true) {
            if ($('#blueBox_Cohort .selectedCohortScope').length == 0) {
                errFlg = false;
                msg = msg + "Please assign at least one "+Cohort_alias.toLowerCase()+".\n";/*Sitemanage-165*/
            }
        }
    }
    /*SiteManage-1:Stops*/

    //first name
    var firstname = $('#FirstName').val().trim();
    mtchFnd = matchRegEx(firstname, FLnameRegex); //MS-613
    //mtchFnd = matchRegEx(firstname, "^[a-z A-Z0-9()*'\u00C0-\u017F]+$"); // MS-86//Ms-147
    if (mtchFnd == null) {
        errFlg = false;
        msg = msg + 'Please enter a valid first name up to 72 characters that contains only letters, numbers, open parentheses, closed parentheses, accents above letters, periods and astrices.\n';	//MS-86	and MV-2062
    }

    //last name
    var lastname = $('#LastName').val().trim();
    mtchFnd = matchRegEx(lastname,FLnameRegex); //MS-613
    //mtchFnd = matchRegEx(lastname, "^[a-z A-Z0-9()*'\u00C0-\u017F]+$"); // MS-86//Ms-147
    if (mtchFnd == null) {
        errFlg = false;
        msg = msg + 'Please enter a valid last name up to 72 characters that contains only letters, numbers, open parentheses, closed parentheses, accents above letters, periods and astrices.\n';	//MS-86	and MV-2062
    }

    //email
    var emailid = $('#Email').val().trim();
    if (emailid == "" || (!isValidEmail(emailid))) {
        errFlg = false;
        //msg = msg + 'Please enter a valid e-mail address.\n';
        msg = msg + emailvalidationmessage;
    }

    // Role
    var role = $("#sel_userRole").val();
    if (role.trim() == '') {
        errFlg = false;
        msg = msg + 'Please select a Role.\n';
    }

    //password
    /*var password = $('#pwd').val().trim();
    mtchFnd = matchRegEx(password,"^[\_a-zA-Z0-9!@$#%&^*=:_-~\s\-]+$");
    if (mtchFnd == null){
        errFlg = false;
        msg = msg + 'Please enter a valid password up to 24 characters that contains only letters, numbers and special characters (!, @, $, #, %, &, ^, *, =, :, _, - and ~).\n';
    }*/

    /*Validation for Phone number*/
    if (typeof $('#Mobile').val() != "undefined")//MS-246
    {
        var phone = $('#Mobile').val().trim();
        var length = phone.length;
        var phonepattern = /^\d{3}-\d{3}-\d{4}$/;
        var phoneinvalid = 0000000000;
        if (phone != "") {
            if(length < 12 ){
                errFlg = false;
                msg = msg + 'Please enter a mobile device number with 12 digits without spaces or symbols such as parentheses. \n\nExample: 555-555-5555.\n'; 
            } else {				
                if((!(phone.match(phonepattern))) || (phone == phoneinvalid)){
                    errFlg = false;
                    msg = msg + 'Please enter a mobile device number without spaces or symbols such as parentheses .\n\nExample: 555-555-5555.\n';
                }else if(length == 10){
                    $.ajax({
                        async:false,
                        type: "post",
                        data: {phoneNumber:phone},
                        url: "index.cfm?event=user.vaildateMobileNumberBySlooce",
                        success: function(data) { 
                            data = JSON.parse(data);
                            if(data != true){
                                errFlg = false;
                                msg = msg + data+ '.\n';
                            }
                        }
                    });
                }			
            }		
        }
    }
	    
	/*MS-219*/
	if (IsSite_Enable == 1 ) {
        if ($('input[name="AllTimeAssignmentType"]:checked').val() === undefined) {
             errFlg = false;
             msg = msg + "Please assign at least one "+siteAliasLcase+".\n";/*Sitemanage-165*/
        }
        else if ($('input[name="AllTimeAssignmentType"]:checked').val() === '3' && $('#Custom').is(':checked') == true) {
			var count=0;
			$('#blueBox_site .checkboxparent .tick').each(function (i) {
					count=count+1;				
			});	
            if (count == 0) {
                errFlg = false;
                msg = msg + "Please assign at least one "+siteAliasLcase+".\n";/*Sitemanage-165*/
            }
        }
    }
    /*MS-219*/	   
    if(errFlg){        
        return true;
    }
    else { // if there any restricted character 
        alert(msg);
        return false;
    }
}

function getallemaillist() {
    var url = 'index.cfm?event=user.getemaillistingStaff';
    var pid = $("#ProgramID").val();
    $.ajax({
        type: "post",
        data: { ProgramID: pid },
        url: url,
        dataType: "json",
        success: function (data) {
            AllDataJson = data;
            //alert(data.length);	
        }
    });
}

function isEmailExistOnAdd_EnrolledIs1() {
    var newemail = $("#Email").val().trim();//AF-371

    for (var i = 0; i < AllDataJson.length; i++) {
        if (AllDataJson[i].Email == newemail) {
            if (AllDataJson[i].Enrolled) {
                msg = "Can't create accounts with e-mail address " + AllDataJson[i].Email + '.\nAlready used by staff in the program.\nPlease enter a unique e-mail address for this account.';
                alert(msg);
                return false;
                break;
            }
        }
    }
    return true;
}

function isEmailExistOnAdd_EnrolledIs0() {
    var newemail = $("#Email").val().trim();//AF-371

    for (var i = 0; i < AllDataJson.length; i++) {
        if (AllDataJson[i].Email == newemail && AllDataJson[i].Enrolled == 0) {
            return true;
            break;

        }
    }
    return false;
}

// User Count Set related Functions
function setSelectedCount(flage) {
    var selected = setSelectedUsers();
    var selected_user_count = selected.length;
    var activedelete = 0;
    var activearchive = 0;
    var fulluserid = $('#fulluserid_list').val(); // MS-394
    if (selected_user_count >= 0) {
        $.ajax({
            type: "post",
            url: "index.cfm?event=user.getStaffsDataForArchiveDelete",
            data: {
                "userids": selected,
                "fulluserid": fulluserid // MS-394
            },
            dataType: "json",
            beforeSend: function () {
                showLoadingOverlay();
            },
            success: function (resp) {
                $.each(resp.volunteerdata, function (index, data) {
                    /* Start :: MV-1981*/
                    if(data.getStaffcount_doNotHavePwd > 0){
                        var setPwdCount = data["getStaffcount_doNotHavePwd"];
                        var Memberaliastext = '';
                        $('.selected_count').each(function(i) {
                            if($(this).val() == 'sendmail'){
                                if (selected_user_count > 1) {
                                    Memberaliastext = 'Members';
                                } else {
                                    Memberaliastext = 'Member';
                                }
                                $(this).html('Send Welcome/Password Setup E-mail to Selected Without Passwords (' + setPwdCount + ')'); // MV-2153
                            }
                        });
                    }
                    /* End :: MV-1981*/

                    if (data["readytodelete"] === 'T') {
                        $("#sel_action > #delSel").attr('disabled', false);
                    }
                    else {
                        $("#sel_action > #delSel").attr('disabled', true);
                    }

                    if (data["readytoarchive"] === 'T') {
                        $('.selected_count').each(function (i) {
                            if ($(this).val() == 'archive') {
                                $(this).prop("disabled", false);
                            }
                            //sel-count fix Start
                            if ($(this).val() == 'archiveall') {
                                $(this).prop("disabled", false);
                            }
                            //sel-count fix End
                        });
                    }
                    else {
                        $('.selected_count').each(function (i) {
                            if ($(this).val() == 'archive') {
                                $(this).attr("disabled", "disabled");
                            }
                            /* Commented MV-817
                            if ($(this).val() == 'archiveall') {
                                $(this).attr("disabled","disabled");
                            }
                            */
                        });
                    }

                    if (data["readytorestore"] === 'T') {
                        $('.selected_count').each(function (i) {
                            if ($(this).val() == 'restore') {
                                $(this).prop("disabled", false);
                            }
                        });
                    }
                    else {
                        $('.selected_count').each(function (i) {
                            if ($(this).val() == 'restore') {
                                $(this).attr("disabled", "disabled");
                            }
                        });
                    }
                    //ADMINFUNCT-34
                    if (data["readytowelcomepasswordemail"] === 'T') {
                        $('.selected_count').each(function (i) {
                            if ($(this).val() == 'sendmail') {
                              /*MS-394 ::start*/
                              if(selected_user_count == 0){
                                $(this).prop("disabled", true);
                              }else{
                                $(this).prop("disabled", false);
                              }
                              /*MS-394 ::start*/
                                //$j11( "#ui-id-13" ).parents('li').removeClass("ui-state-disabled ui-menu-item").addClass("ui-menu-item" );//ADMINFUNCT-34

                            }
                        });
                    }
                    else {
                        $('.selected_count').each(function (i) {
                            if ($(this).val() == 'sendmail') {
                                $(this).attr("disabled", "disabled");
                                //$j11( "#ui-id-13" ).parents('li').addClass("ui-state-disabled ui-menu-item");//ADMINFUNCT-34
                            }
                        });
                    }
                    if (data["readytowelcomepasswordemailall"] === 'T') {
                        $('.selected_count').each(function (i) {
                            if ($(this).val() == 'sendmailall') {
                            /*MS-394 ::start*/
                              if($(this).text()=='Send Welcome/Password Setup E-mail to All Without Passwords (0)'){  // MV-2153
                                $(this).prop("disabled", true);
                              }else{
                                $(this).prop("disabled", false);
                              }
                              /*MS-394 ::start*/
                                //	$j11( "#ui-id-14" ).parents('li').removeClass("ui-state-disabled ui-menu-item").addClass("ui-menu-item" );//ADMINFUNCT-34
                            }
                        });
                    }
                    else {
                        $('.selected_count').each(function (i) {
                            if ($(this).val() == 'sendmailall') {
                                $(this).attr("disabled", "disabled");
                                //$j11( "#ui-id-14" ).parents('li').addClass("ui-state-disabled ui-menu-item");//ADMINFUNCT-34
                            }
                        });
                    }
                    if (data["readytoresetpasswordemail"] === 'T') {
                        $('.selected_count').each(function (i) {
                            if ($(this).val() == 'resetpassword') {
                            /*MS-394 ::start*/
                              if(selected_user_count == 0){
                                $(this).prop("disabled", true);
                              }else{
                                $(this).prop("disabled", false);
                              }
                              /*MS-394 ::start*/
                                //	$j11( "#ui-id-10" ).parents('li').removeClass("ui-state-disabled ui-menu-item").addClass("ui-menu-item" );//ADMINFUNCT-34
                            }
                        });
                    }
                    else {
                        $('.selected_count').each(function (i) {
                            if ($(this).val() == 'resetpassword') {
                                $(this).attr("disabled", "disabled");
                                //	$j11( "#ui-id-10" ).parents('li').addClass("ui-state-disabled ui-menu-item");//ADMINFUNCT-34
                            }
                        });
                    }
                    if (data["readytoresetpasswordemailall"] === 'T') {
                        $('.selected_count').each(function (i) {
                            if ($(this).val() == 'resetpasswordall') {
                                $(this).prop("disabled", false);
                                //$j11( "#ui-id-11" ).parents('li').removeClass("ui-state-disabled ui-menu-item").addClass("ui-menu-item" );//ADMINFUNCT-34
                            }
                        });
                    }
                    else {
                        $('.selected_count').each(function (i) {
                            if ($(this).val() == 'resetpasswordall') {
                                $(this).attr("disabled", "disabled");
                                //$j11( "#ui-id-11" ).parents('li').addClass("ui-state-disabled ui-menu-item");//ADMINFUNCT-34
                            }
                        });
                    }
                    //ADMINFUNCT-34
                });
            },
            complete: function () {
                hideLoadingOverlay();
            },
            error: function (resp) {
                console.log("setSelectedCount error");
            }
        });

    }
    //var userid_list = $('[name="userid_list"]:checked'); commented for MV-2058
    //var selected_user_count = userid_list.length;
    /* $('#selectedUsers').val(''); */ // MS-630
    setSelectedUsers();

    $('.selected_count').each(function (i) {
        if ($(this).val() == 'activate') {
            $(this).html('Activate Selected (' + selected_user_count + ')');
        } else if ($(this).val() == 'activateall') {
            //$(this).html('Activate all reporters');
        } else if ($(this).val() == 'deactivate') {
            $(this).html('Deactivate Selected (' + selected_user_count + ')');
        } else if ($(this).val() == 'deactivateall') {
            // $(this).html('Deactivate all reporters');
        } else if ($(this).val() == 'archive') {
            $(this).html('Archive Selected (' + selected_user_count + ')');
        } else if ($(this).val() == 'archiveall') {
            // $(this).html('Deactivate all reporters');
        } else if ($(this).val() == 'restoreall') {
            // $(this).html('Deactivate all reporters');
        } else if ($(this).val() == 'delete') {
            $(this).html('Delete Selected (' + selected_user_count + ')');
        } else if ($(this).val() == 'deleteall') {
            // $(this).html('Deactivate all reporters');
        } else if ($(this).val() == 'restore') {
            $(this).html('Restore Selected (' + selected_user_count + ')');
        } else if ($(this).val() == 'resetpassword') {//ADMINFUNCT-34
            if (selected_user_count > 1) {
                var passval = 'Passwords';
                //var volunalias='Staffs'; // Cf18-91
                var Memberalias = 'Members'; // Cf18-91
            } else {
                var passval = 'Password';
                //var volunalias='Staff'; // Cf18-91
                var Memberalias = 'Member'; // Cf18-91
            }
            $(this).html('Reset ' + passval + ' for Selected (' + selected_user_count + ')'); // Cf18-91    // MV-2153
        } else if ($(this).val() == 'resetpasswordall') {//ADMINFUNCT-34
            if ($('#fulluserid_list').val()) {
                var arr_userid = $('#fulluserid_list').val().split(',');
                var user_count = arr_userid.length;
            } else {
                var user_count = 0;
            }
            $(this).html('Reset Passwords for All (' + user_count + ')'); // Cf18-91    // MV-2153
        } else if ($(this).val() == 'sendmail') {//ADMINFUNCT-34
            if (selected_user_count > 1) {
                //var volunalias='staffs'; // Cf18-91
                var Memberalias = 'Members'; // Cf18-91
            } else {
                //var volunalias='staff'; // Cf18-91
                var Memberalias = 'Member'; // Cf18-91
            }
            $(this).html('Send Welcome/Password Setup E-mail to Selected Without Passwords (' + selected_user_count + ')'); // Cf18-91  // MV-2153
        } else if ($(this).val() == 'sendmailall') {//ADMINFUNCT-34
            if ($('#passwordnotsetemailuserid').val()) {
                var arr_userid = $('#passwordnotsetemailuserid').val().split(',');
                var user_count = arr_userid.length;
            } else {
                var user_count = 0;
            }
            $(this).html('Send Welcome/Password Setup E-mail to All Without Passwords (' + user_count + ')'); // Cf18-91  // MV-2153
        } else {
            $(this).html('Select action... (' + selected_user_count + ')');
        }
    });
    //ADMINFUNCT-34

    $('#sel_action').selectmenu();
    $("#sel_action").selectmenu("refresh");
    var elements = $('#sel_action').selectmenu()[0];	
	if (typeof elements !== 'undefined') { //Ms-147
		setTimeout(function () {
			for (i = 0; i < elements.length; i++) {
				var count = i + 1;
				$("#ui-id-" + count).parents('li').css('display', elements[i].style['display']);
				$("#ui-id-" + count).text(elements[i].innerText);
				if (elements[i].disabled) {
					$("#ui-id-" + count).parents('li').addClass('ui-state-disabled ui-menu-item');
				}
				else {
					$("#ui-id-" + count).parents('li').removeClass('ui-state-disabled ui-menu-item').addClass('ui-menu-item');
				}
                /*MV-2153: Start*/
                var target_text = $("#ui-id-"+count).text();
                if(target_text.includes('Account Status') || target_text.includes('Participation') || target_text.includes('Password Tools')){
                    //console.log($j11("#ui-id-"+count).text());
                    var target_item = $("#ui-id-" + count);
                    target_item.parent().css("opacity", "1");
                    target_item.css("color", "black");
                    target_item.css("font-weight", "bold");
                }
                /*MV-2153: End*/
			}
			//var userid_list = $('[name="userid_list"]:checked');
			//var selected_user_count = userid_list.length;

			$("#sel_action-button span:nth-child(2)").text('Select action... (' + selected_user_count + ')');
			$('.ui-selectmenu-button:eq(1)').remove();
		}, 100);
	}//Ms-147
    /*ADMINFUNCT-34*/
    var findtabelrow = false;
    $('#reportSectionTable').children('tbody').children('tr:first').find("input").each(function () {
        findtabelrow = true;
    });
    //console.log(findtabelrow)

    if (findtabelrow) {
        //$('#edit_volun_link').empty();	// MS-105 commented			
        $('#sel_action-button').removeClass('spandisable');
        //console.log('hello')
    } else {
        $('#sel_action-button').addClass('spandisable');
    }
    /*ADMINFUNCT-34*/
}
function dropdownremove() {
    $('.ui-selectmenu-button').show();
    //console.log('len',$('.ui-selectmenu-button').length);
    for (j = 1; j <= $('.ui-selectmenu-button').length; j++) {
        $('.ui-selectmenu-button:eq(' + j + ')').remove();
    }
    return true;
}

function setSelectedUsers() {
    var userid_list = $('[name="userid_list"]:checked');
    var selected_user_count = userid_list.length;
    var selected = [];
    userid_list.each(function () {
        if (!isInArray($(this).attr('id'), selected)) {
            selected.push($(this).attr('id'));
        }
    });

    if ($('#selectedUsers').val().split(',').length > 0) {
        var arr_selected = $('#selectedUsers').val().split(',');
        $(arr_selected).each(function (e, i) {
            if (!isInArray(i.toString(), selected)) {
                if (i != "") {
                    selected.push(i);
                }
            }
        });
    }

    $('#selectedUsers').val(selected.toString());
    return selected;
}

function selectAlreadySelectedUsers() {
    var arr_allready_selected = $('#selectedUsers').val().split(',');
    $('input[name=userid_list]').each(function () {
        if (isInArray($(this).val(), arr_allready_selected)) {
            $(this).prop('checked', true);
        }
    });
}
/* MS-147 */
$(document).on('click', '#column-selection-selectall', function (e) {  /* MS-147*/

    // var parent_checkbox = $('.assignment_header').children('input[type=checkbox]');
    // var name = parent_checkbox.attr('name');
    // var child_elem_name = name + '_item';
    // if (_this.html() == 'Select All') {
    //     _this.html('Select None');
    //     parent_checkbox.attr('checked', 'checked');
    //     $('input[name=' + child_elem_name + ']').prop('checked',true);
    // } else {
    //     _this.html('Select All');
    //     $('input[name=' + child_elem_name + ']').prop('checked',false);
    // }
    e.stopImmediatePropagation();  /* MS-147*/
    var _this = $(this);
    if (_this.html() == 'Select All') {
        $('.columns').prop('checked', true);
        $('.assignment_box').slideDown(1000);
        $('.assignment_header input').prop('checked', true);  //MS-147
        $('#column-selection-selectall').html('Select None');
        $('.columns_sub').prop('checked', true);
        $('.changeArrow').removeClass("showarrow");
        $('.changeArrow').addClass("hidearrow");
    }
    else {
        $('.columns').prop('checked', false); //MS-147
        $('#column-selection-selectall').html('Select All');
        $('.columns_sub').prop('checked', false);    //MS-147    
        $('.changeArrow').removeClass("hidearrow");
        $('.changeArrow').addClass("showarrow");
        $('.assignment_box').slideUp(1000);
    }
});
/* MS-147 */
function selectUnselect(element, relatedclassname) {
    var obj_element = element;
    if ($(obj_element).html() == 'Select All') {
        $(obj_element).html('Select None');
        if (relatedclassname == 'columns') {
            selectOpenNCloseAssociation(1);
        } else if (relatedclassname == 'site_assignments') {
            $('.option_break_type1').each(function (i) {
                if ($(this).is(":visible")) {
                    $(this).find('input[type="checkbox"]').prop('checked', true); /* MS-147 */
                }
                else {
                    $(this).find('input[type="checkbox"]').prop('checked', false); /* MS-147 */
                }
            });
        /* MV-2153(K):Start */
        } else if (relatedclassname == 'vol_account_status') {
			var enrolled_option = $('#bit_all_enrolled').is(':checked'); 
			var archived_option = $('#bit_not_enrolled').is(':checked');
			if(enrolled_option && !archived_option){
				$('.vol_account_status').each(function () {
					if ($(this).val() != 'Archived') {
						$(this).prop('checked', true);
					}
				});
			}else if(!enrolled_option && archived_option){
				$('.vol_account_status').each(function () {
					if ($(this).val() == 'Archived') {
						$(this).prop('checked', true);
					}
				});
			}else if(enrolled_option && archived_option){
				$('.vol_account_status').each(function () {
					$(this).prop('checked', true);
				});
			}
		/* MV-2153(K):Stop */
        } else {
            $('.' + relatedclassname).prop('checked', true); /* MS-147 */
            $('.' + relatedclassname).parent().siblings('#assignment_box').slideDown(1000);
        }
    } else {
        $(obj_element).html('Select All');
        if (relatedclassname == 'columns') {
            selectOpenNCloseAssociation(0);
        } else {
            $('.' + relatedclassname).prop('checked', false); /* MS-147 */
        }
        $('.' + relatedclassname).parent().siblings('#assignment_box').slideUp(1000);
    }
}

function selectOpenNCloseAssociation(open) {
    if (open == 1) {
        $('.columns').trigger('click');
        $('.columns').prop('checked', true); /* MS-147 */
        $('.assignment_header input').trigger('click');
        $('.assignment_box').slideDown(1000);
        $('.assignment_header input').prop('checked', true);
        $('input[name^=str_association_assignments_type]').prop('checked', true); /* MS-147 */
        $('#column-selection-selectall').html('Select None'); /* MS-147 */
        $('.columns_sub').prop('checked', true); /* MS-147 */
        $('.changeArrow').removeClass("showarrow");
        $('.changeArrow').addClass("hidearrow");
    } else {
        $('.columns').trigger('click');
        $('.columns').prop('checked', false); /* MS-147 */
        $('input[name^=str_association_assignments_type]').prop('checked', true);
        $('#column-selection-selectall').html('Select All'); /* MS-147 */
        $('.columns_sub').prop('checked', false); /* MS-147 */
        $('.changeArrow').removeClass("hidearrow");
        $('.changeArrow').addClass("showarrow");
        $('.assignment_box').slideUp(1000);
    }
}

// Search 
function autoCompleteInit() {
    var postData = [];
    $("#str_search").autocomplete({
        source: function (request, response) {
            $('.search_active').removeClass('search_active').addClass('search_inactive').attr('src', 'images/icons/lens_icon.png');
            postData = $('body').data('formdata');
            var bit_push = 1;
            $(postData).each(function (i) {
                if (postData[i]['name'] == "str_search") {
                    bit_push = 0;
                    postData[i]['value'] = $('#str_search').val();
                }
            });
            if (bit_push == 1) {
                postData.push({
                    "name": "str_search",
                    "value": $('#str_search').val()
                });
            }

            $.ajax({
                url: "index.cfm?event=user.getRelatedUserNamesForStaff",
                dataType: "json",
                type: "Post", /*MS-147*/
                data: postData, /*{"str_search":$('#str_search').val()}*/
                beforeSend: function (xhr) {
                    $('#suggestionLoader').show()
                },
                success: function (data) {
                    response(data.data);
                    $('#suggestionLoader').hide()
                }
                // }).success(function( data ) {
                // 	response(data.data);
                // 	$('#suggestionLoader').hide()
            });
        },
        change: function (event, ui) {
            //console.log(this.value);
        },
        select: function (event, ui) {
            event.preventDefault();
            var text = ui.item.value;
            $("#str_search").val(text);
            $('.search_active').removeClass('search_active').addClass('search_inactive').attr('src', 'images/icons/lens_icon.png');
            $('.search_inactive').trigger('click');
        },
        focus: function (event, ui) {
            $("#str_search").val(ui.item.value);
        },
        appendTo: '#search_box',
        minLength: 3
    });
}

// Other Functions
function htmlEncode(value) {
    //create a in-memory div, set it's inner text(which jQuery automatically encodes)
    //then grab the encoded contents back out.  The div never exists on the page.
    return $('<div/>').text(value).html();
}

function htmlDecode(value) {
    return $('<div/>').html(value).text();
}

function isInArray(value, array) {
    return array.indexOf(value) > -1;
}

function matchRegEx(string, regexPattern) {
    return string.match(regexPattern);
}

function ClearUserMessage() {
    $("#Staff_success_msg").html('');
    $("#divusermessage").attr('class', 'usermessage hide volunteer_success_message');
}

function showLoadingOverlay() {
    $('#ajaxFilterLoading .bg').height('100%');
    $('#ajaxFilterLoading').fadeIn(300);
    $("#ajaxFilterLoading").attr("tabindex", -1).focus();
}

function hideLoadingOverlay() {
    $('#ajaxFilterLoading .bg').height('100%');
    $('#ajaxFilterLoading').fadeOut(300);
}
/*Start: ADMINFUNCT-34*/

// function destroyWindow(val){
// 	ColdFusion.Window.destroy(val,true);		
// }
function resetPasswordChk() {
    if ($('#sendmailchk').is(':checked')) {

        $('#passconfirm').prop('disabled', false);
    } else {

        $('#passconfirm').prop('disabled', true);
        $('#passcancel').css('display', 'inline-block');
        $('#sendmsg').css('display', 'none');
        $('#closebutton').css('display', 'none');
    }
}
function ResetMail(value) {
    var allowedstafftoken = $('#allowedstafftoken').val();
    var postData = [];
    if (value === 'resetpassword' || value === 'resetpasswordall' || value === 'sendmail' || value === 'sendmailall') {
        postData.push({
            "name": "action",
            "value": value
        });
    }
    if (value === 'sendmailall') {
        postData.push({
            "name": "alluserids",
            "value": $('#passwordnotsetemailuserid').val()
        });
    }
    else {
        postData.push({
            "name": "alluserids",
            "value": $('#fulluserid_list').val()
        });
    }
    postData.push({
        "name": "selectedUsers",
        "value": $('#selectedUsers').val()
    });
    /* MS 147 */
    postData.push({
        "name": "allowedstafftoken",
        "value": allowedstafftoken
    });
    /* MS 147 */
    $.ajax({
        type: "post",
        url: "index.cfm?event=user.editStaffsprocess",
        data: postData,
        dataType: "json",
        success: function (resp) {
            var alphabeticFilter = $('#alphabeticFilter').val();
            var searchfilter = $('#str_search').val();
            var int_start_row = $('#int_prev_start_row').val();
            var token=1; /* MS-147 (29-08-2022)*/
            var staffcusttoken = $('#staffcusttoken').val(); /* MS-147 (29-08-2022)*/
            var postData = $('body').data('formdata');
            $(postData).each(function (i) {
                if (postData[i]['name'] == "alphabeticFilter") {
                    postData[i]['value'] = alphabeticFilter;
                } else if (postData[i]['name'] == "searchfilter") {
                    postData[i]['value'] = searchfilter;
                } else if (postData[i]['name'] == "sort_column") {
                    postData[i]['value'] = sortColumn;
                } else if (postData[i]['name'] == "sort_type") {
                    postData[i]['value'] = sortType;
                } else if (postData[i]['name'] == "int_start_row") {
                    postData[i]['value'] = int_start_row;
                } /* MS-147 (29-08-2022) :start*/
                else if(postData[i]['name'] == "staffcusttoken"){
                    postData[i]['value'] = staffcusttoken
                    token = 0
                }
                /* MS-147 (29-08-2022) : end*/
            });
            /* MS-147 (29-08-2022) : Start*/
            if (token == 0){
                postData.push({
                    "name": "staffcusttoken",
                    "value": staffcusttoken
                });
            }
            /* MS-147 (29-08-2022) : End*/
            showLoadingOverlay();
            var status = loadUsersList(postData, "");
            if (status === true) {
                hideLoadingOverlay();
            }
            $('#selectedUsers').val('');
            if (resp.msg) {
                $('#staff_success_msg').html(resp.msg);
                $('.volunteer_success_message').removeClass('hide').slideDown(1000);
                $("#divusermessage").fadeOut(10000);
            } else {
                $('#divusermessage').hide();
            }
            //getallemaillist();
        }, complete: function () {
            $('#sendmsg').css('display', 'block');
            $('#closebutton').css('display', '');
            $('#passcancel').css('display', 'none');
            $('#passconfirm').prop('disabled', true);

        },
        error: function (resp) {

        }
    });
}
/* MS-147 */
$(document).on("change", ".role_assignments", function (e) { /* MS-147*/
    e.stopImmediatePropagation();  /* MS-147*/
    var checkedcount = $('input[class=role_assignments]:checked').length;
    var totalcount = $('input[class=role_assignments]').length;
    if (totalcount == checkedcount) {
        $('#option-break-selectall-role').html('Select None');
    }
    if (totalcount > checkedcount) {
        $('#option-break-selectall-role').html('Select All');
    }
});

$(document).on("change", ".site_assignments", function (e) {  /* MS-147*/
    e.stopImmediatePropagation(); /* MS-147*/
    var totalcount = $(".option_break_type1 :visible").find('input[type="checkbox"]').length;
    var checkedcount = $(".option_break_type1 :visible").find('input[type="checkbox"]:checked').length;
    if (totalcount == checkedcount) {
        $('#option-break-selectall-site').html('Select None');
    }
    if (totalcount > checkedcount) {
        $('#option-break-selectall-site').html('Select All');
    }
});

$(document).on("change", ".columns,.columns_sub", function (e) { /* MS-147*/
    e.stopImmediatePropagation();  /* MS-147*/
    var panelcheckedcount = $('input[class=columns]:checked').length;
    var subpanelcheckedcount = $('input[class=columns_sub]:checked').length;
    var checkedcount = panelcheckedcount + subpanelcheckedcount;
    var subpaneltotalcount = $('input[class=columns_sub]').length;
    var paneltotalcount = $('input[class=columns]').length;
    var totalcount = paneltotalcount + subpaneltotalcount;
    if (totalcount == checkedcount) {
        $("#column-selection-selectall").html("Select None");
    }
    if (totalcount > checkedcount) {
        $("#column-selection-selectall").html("Select All");
    }
});

//$('input[name=saved_view]').live('click', function() {
$(document).on('click', 'input[name=saved_view]', function (e) { /* MS-147*/
    e.stopImmediatePropagation(); /* MS-147*/
    let value = $(this).attr('sid'); 
    let isDefaultRel = $(this).attr('rel');
    $('.defaultViewManage').hide();
    if (value > 0) {
        // If saved view
        //$('#btn_delete').show();
        $('#defaultViewManage_' + value).css('display', 'inline-block');
        if (isDefaultRel == 1) {
            $('#btn_makeDefault_' + value).hide();
        } else {
            $('#btn_makeDefault_' + value).show();
        }
        $('#btn_rename_' + value).show();
        $('#btn_delete_' + value).show();
    } else {
        // if All Enrolled #Volunteers plural#
        //$('#btn_delete').hide();
        var savedid = $(this).attr('sid');

        if (isDefaultRel == 0 && savedid > 0 && value == 0) {
            $('#defaultViewManage_' + savedid).css('display', 'inline-block');
            $('#btn_makeDefault_' + savedid).show();
            $('#btn_rename_0').show();
            $('#btn_delete_0').show();
        } else if (value == 0 && savedid == 0) {
            if (isDefaultRel == 0) {
                $('#defaultViewManage_' + savedid).css('display', 'inline-block');
                if ($('#isDefaultView_0').is(':visible')) {
                    $('#btn_makeDefault_0').hide();
                } else {
                    $('#btn_makeDefault_0').show();
                }
                $('#btn_rename_0').hide();
                $('#btn_delete_0').hide();
            } else {
                $('#defaultViewManage_' + value).css('display', 'none');
            }
        } else if (isDefaultRel == 1) {
            $('#defaultViewManage_' + savedid).css('display', 'inline-block');
            $('#btn_makeDefault_' + savedid).hide();
            $('#btn_rename_' + savedid).show();
            $('#btn_delete_' + savedid).show();
        }
    }
});

$(document).on('click', '#ActionRename', function (e) { /* MS-147*/
    e.stopImmediatePropagation(); /* MS-147*/
    var staffrenametoken = $('#staffrenametoken').val();
    let values = {
        "savedViewId": $("#savedViewId").val(),
        "savedViewText": $("#savedViewText").val(),
        "staffrenametoken": staffrenametoken
    }
    var mtchFnd = matchRegEx(values.savedViewText, "^[a-z A-Z0-9]+$");
	if (mtchFnd == null) {
		alert("Enter valid data into 'Rename Saved View' text field");			
		return false;
	}else{
    $.ajax({
        type: "post",
        url: "index.cfm?event=user.renameStaffSavedView",
        data: values,
        dataType: "json",
        success: function (resp) {
                if(resp.data.status == "ok"){
            $('#view_success_msg').html(resp.data.msg);
            $('.view_success_message').removeClass('hide').slideDown(1000);
            hideLoadingOverlay();
            let input = $("#saved_view_" + values.savedViewId);
            $("#saved_view_label_" + values.savedViewId).html("");
            $("#saved_view_label_" + values.savedViewId).append(input);
            $("#saved_view_label_" + values.savedViewId).append(values.savedViewText);
            $('#popupid').dialog('close').empty();
                }else{
                    alert(resp.data.msg);
                }
        },
        error: function (resp) {
            alert(resp);
        }
    });
    }
});

$(document).on('click', '.btn_rename', function (e) { /* MS-147*/
    e.stopImmediatePropagation();  /* MS-147*/
    var saved_view_name = '';
    var selectedView = $('#insidebox_saved_views .radio input:radio:checked');
    saved_view_name = selectedView.parent().text();
    var value = selectedView.attr('sid');/* MS-147*/
    var root = 'index.cfm?event=user.renameSavedViewWindowforStaff&savedViewId=' + value;
    showLoadingOverlay(); 
    $.ajax({
        type: 'POST',
        url: root,
        success: function (result) {
            $('#popupid').css('background', 'white');
            $('#popupid').dialog({ autoOpen: false, modal: true, title: "Rename Saved View", height: 230, width: 550, dialogClass: 'dialog-resetpass' });
            $("#popupid").dialog('open').html(result);
            hideLoadingOverlay();
        }
    });
});

//$(".btn_makeDefault").live('click', function () {
$(document).on('click', '.btn_makeDefault', function (e) { /* MS-147*/
    e.stopImmediatePropagation();  /* MS-147*/
    var saved_view_name = '';
    var selectedView = $('#insidebox_saved_views .radio input:radio:checked');
    saved_view_name = selectedView.parent().text().trim();
    var staffsavedtoken = $('#staffsavedtoken').val();
    value = selectedView.attr('sid'); /* MS-147 :: 02-09-2022*/
    var values = {
        "viewid": value,
        "staffsavedtoken": staffsavedtoken
    }
    $('.view_success_message').slideUp(1000)
    //if (confirm('Are you sure you want to make default the saved view, "' + saved_view_name + '" ?')) {
    showLoadingOverlay();
    $.ajax({
        type: "post",
        url: "index.cfm?event=user.makedStaffDefault",
        data: values,
        dataType: "json",
        success: function (resp) {
            $('.isDefaultView').hide();
            $('input[name=saved_view]').attr('rel', 0);
            if (values.viewid == 0) {
                $("#saved_view").attr("rel", 1);
            } else {
                $("#saved_view_" + values.viewid).attr("rel", 1);
            }
            $('#isDefaultView_' + values.viewid).css("display", "inline-block");
            $('#btn_makeDefault_' + values.viewid).hide();
            $('#view_success_msg').html(resp.data.msg);
            $('.view_success_message').removeClass('hide').slideDown(1000);
            hideLoadingOverlay();
        },
        error: function (resp) {

        }
    });
    //MV-1697::MV-1803 ----commented for MV-1825
    // if((window.bit_change == 1) && $('#savedviewselection').val().length == 0){
    //     $('#hidselectedsavedviewreload').val(values.viewid);
    //     window.bit_change = 0;	
    // }
    //MV-1697::MV-1803
    //}
});
function downloadSignedDocument(obj) {
    var param = $(obj).attr('data-param');
    var win = window.open('/index.cfm?event=user.downloadStaffSignedDocument' + param, '_blank');
    if (win) {
        //Browser has allowed it to be opened
        win.focus();
    } else {
        //Browser has blocked it
        alert('Please allow popups for this website');
    }
}

//$('.changeArrow').live('click', function() {
$(document).on('click', '.changeArrow', function (e) {
     e.stopImmediatePropagation(); 
    var _this = $(this);
    var child_elem_name = _this.siblings().children('.assignment_header input').attr('name');         
    if (_this.hasClass('showarrow')) {
        _this.removeClass("showarrow");
        _this.addClass("hidearrow");
        _this.siblings('.assignment_box').slideToggle(1000);            
        _this.siblings().children().children('.column-selection-selectall').html('Select None');
        $('input[name='+child_elem_name+']').prop('checked',true);         
    } else {
        _this.removeClass("hidearrow");
        _this.addClass("showarrow");
        _this.siblings('.assignment_box').slideUp(1000);
        _this.siblings().children().children('.column-selection-selectall').html('Select All');
        $('input[name=' + child_elem_name + ']').prop('checked',false);         
    }
});
/* MS-147 */
/*Start: ADMINFUNCT-34*/
/* Start :: MV-1368:MV-1407 */
$(document).on('click', '#standardpanel,#namecontactdetails', function (e) {	
	if($(this). prop("checked")==false){			
		var $elements=$(this).parent().next('.assignment_box');
		$elements.find("input[type=checkbox]").each(function () {
            var inputId=$(this).attr('id');
			$('#'+inputId).prop('checked', false);
        });
	}
});
$(document).on('click', '#UserCustompanel,input[type=checkbox][name=staffpanel],input[type=checkbox][name=staffSubPanel]',function (e) {
	if($(this). prop("checked")==false){			
		var $elements=$(this).parent().next('.assignment_box');
		$elements.find("input[type=checkbox]").each(function () {
            var inputId=$(this).attr('id');
			$('#'+inputId).prop('checked', false);
        });
	}
});
/* End :: MV-1368:MV-1407 */
/* MS-630 */
function checkAllCheckboxesOnIdentCB(){
    // Find all checked checkboxes
    var checkedIds = [];
    // Collect IDs of all checked checkboxes (even if duplicated)
    $('.check_userid_list:checked').each(function() {
        checkedIds.push($(this).attr('id'));
    });

    // Now re-check ALL checkboxes that match those IDs (even duplicates)
    checkedIds.forEach(function(id) {
        $('input.check_userid_list[id="' + id + '"]').each(function() {
            $(this).prop('checked', true);
        });
    });

}
/*MV-2153 : Start*/
function checkInput()
{	
	var id_archive_value = $("#id_archive").val();
	//console.log(id_archive_value)
	if(id_archive_value === "ARCHIVE ALL"){
		$('#archiveItem').removeClass('disabled');
		$('#archiveItem').addClass('enable-archive');
	}
	else{
		$('#archiveItem').addClass('disabled');
		$('#archiveItem').removeClass('enable-archive');
	}
}

function archiveItem() 
{
	//console.log(postData);
	var updated_fulluserid_list = $('#updated_fulluserid_list').val();
	var data = $('#data').val();
   var allowedstafftoken = $("#allowedstafftoken").val();
	var staffcusttoken = $('#staffcusttoken').val();
	var selected_user_count = $('#selected_user_count').val();
    var checksaved = $('#checksaved').val();
    var sortColumn = $('#sortColumn').val();
    var sortType = $('#sortType').val();

	var postData =[];
	console.log("updated_fulluserid_list : " + updated_fulluserid_list + ", data : " + data + ", staffcusttoken : " + staffcusttoken);
    postData.push({
        "name": "action",
        "value": "archiveall"
    });
    postData.push({
        "name": "alluserids",
        "value": updated_fulluserid_list 
    });
    postData.push({
        "name": "saved_view",
        "value": data
    });
    postData.push({
        "name": "staffcusttoken",
        "value": staffcusttoken
    });
     postData.push({
    name: "allowedstafftoken",
    value: allowedstafftoken,
  });

    var val = $('#fulluserid_list').val();
    if (val != '') 
    {
        showLoadingOverlay();
        $.ajax({
            type: "post",
            url: "index.cfm?event=user.editStaffsprocess",
            data: postData,
            dataType: "json",
            success: function (resp){
                try 
                {
                    var alphabeticFilter = $('#alphabeticFilter').val();
                    var searchfilter = $('#str_search').val();
                    var int_start_row = $('#int_prev_start_row').val();
                    var staffcusttoken = $('#staffcusttoken').val(); 
                    var formData = $('body').data('formdata');
                    var postData = formData;
                    var bit_count_enrolled = 1;
                    var token = 1; 
                    var count = 0;    

                    $(postData).each(function (i) {
                        if (postData[i]['name'] == "alphabeticFilter") {
                            postData[i]['value'] = alphabeticFilter;
                        } else if (postData[i]['name'] == "searchfilter") {
                            postData[i]['value'] = searchfilter;
                        } else if (postData[i]['name'] == "sort_column") {
                            postData[i]['value'] = sortColumn;
                        } else if (postData[i]['name'] == "sort_type") {
                            postData[i]['value'] = sortType;
                        } else if (postData[i]['name'] == "int_start_row") {
                            postData[i]['value'] = int_start_row;
                        } else if (postData[i]['name'] == "saved_view") {
                            postData[i]['value'] = data;
                            count = 1;
                        } else if (postData[i]['name'] == "bit_all_enrolled") {
                            postData[i]['value'] = 1
                            bit_count_enrolled = 0;
                        }
                        else if(postData[i]['name'] == "staffcusttoken") {
                            postData[i]['value'] = staffcusttoken
                            token = 0;
                        }
                    });

                    if (bit_count_enrolled == 1 && $('#bit_all_enrolled').is(':checked') == true) {
                        postData.push({
                            "name": "bit_all_enrolled",
                            "value": 1
                        });
                    }
                    if (count == 0 && checksaved ==1 ){
                        postData.push({
                            "name": "saved_view",
                            "value": data
                        });
                    }
                    if (token == 1){
                        postData.push({
                            "name": "staffcusttoken",
                            "value": staffcusttoken
                        });
                    }

                    showLoadingOverlay();
                    var status = loadUsersList(postData, "");
                    if (status === true) {
                        hideLoadingOverlay();
                    }

                    $('#selectedUsers').val('');
                    $('#staff_success_msg').html(resp.msg);
                    $('.volunteer_success_message').removeClass('hide').slideDown(1000);
                    
                    setTimeout(function (){
                        $("#divusermessage").slideUp(1000);
                    }, 2000);

                    $('#sel_action-button').focus();
                    $("#sel_action-button span:nth-child(2)").text('Select action... (' + selected_user_count + ')');
                    $('#fulluserid_list').val('');
                } 
                catch (err) 
                {
                    console.log(err);
                }
            }
        });
    } 
    else 
    {
        $('#sel_action-button').focus();
        $("#sel_action-button span:nth-child(2)").text('Select action... (' + selected_user_count + ')');
    }
    $dialog["StaffArchivalConfirmationPopup"].dialog('close').empty();
}

function cancelAction() 
{
	// Your cancel logic here
	// console.log("Cancel function called.");
	$dialog["StaffArchivalConfirmationPopup"].dialog('close').empty();
}

function dialogSettings(title, dialogClass, maxWidth, width, maxHeight, height )
{
    
    return {
        modal:true, 
        title: title, 
        resizable:false, 
        maxWidth: ( maxWidth === undefined ) ? 500 : maxWidth,
        maxHeight: ( maxHeight === undefined ) ? 500 : maxHeight,
        width: ( width === undefined ) ? 350 : width,
        height: ( height === undefined ) ? 350 : height,
        autoOpen: false,
        position:['center',50],
        dialogClass:dialogClass,
        close:cancelAction
    }
}
/*MV-2153 : Stops*/

/*MV-2153(K):Start*/
$(document).on('click', '#str_account_status_assgmnt_optnl_break_out', function() {
    $('#account-toggle-wrapper').slideDown(1000);
    $('#str_association_assgmnt_optnl_break_out').parent().siblings('.asso_assign_break_box').slideUp(1000);
 $('#str_site_assgmnt_optnl_break_out').parent().siblings('.asso_assign_break_box').slideUp(1000);
 $("input:radio[name=str_association_assgmnt_optnl_break_out_type]:checked").each(function() { 
     $(this).prop('checked', false);
 });
 $("input:checkbox[name=str_site_assgmnt_optnl_break_out_site]:checked").each(function() { 
     $(this).prop('checked', false);
 });

 toggleAccountStatus();
})	
function toggleAccountStatus(){
 var enrolled_option = $('#bit_all_enrolled').is(':checked'); 
 var archived_option = $('#bit_not_enrolled').is(':checked');
 if(enrolled_option == true && archived_option == false){
     $("input:checkbox[name=account_status]").each(function() { 
         if($(this).attr('value') != 'Archived'){
             $("#status_4").hide("slow");
         }
         else{
             $("#status_1").show("slow");
             $("#status_2").show("slow");
             $("#status_3").show("slow");
         }
     });
 }
 else if(enrolled_option == false && archived_option == true){
     $("input:checkbox[name=account_status]").each(function() { 
         if($(this).attr('value') == 'Archived'){
             $("#status_4").show("slow");
         }
         else{
             $("#status_1").hide("slow");
             $("#status_2").hide("slow");
             $("#status_3").hide("slow");
         }
     });
 }
 else if(enrolled_option == true && archived_option == true){
     $("input:checkbox[name=account_status]").each(function() { 
         $("#status_1").show("slow");
         $("#status_2").show("slow");
         $("#status_3").show("slow");
         $("#status_4").show("slow");
     });
 }
}

$(document).on('click', '.enrollvol', function() {
 var enrolled_option = $('#bit_all_enrolled').is(':checked'); 
 var archived_option = $('#bit_not_enrolled').is(':checked');
 if($('#str_account_status_assgmnt_optnl_break_out').prop("checked") == true){
     if(enrolled_option || archived_option){
         $("#str_account_status_assgmnt_optnl_break_out").prop("disabled", false);
         toggleAccountStatus();
         var cur_checked_Id = $(this).attr('id');
         if(cur_checked_Id == 'bit_all_enrolled' && !enrolled_option){
             $('.vol_account_status').each(function () {
                 if ($(this).val() != 'Archived') {
                     $(this).prop('checked', false);
                 }
             });
         }
         if(cur_checked_Id == 'bit_not_enrolled' && !archived_option){
             $('.vol_account_status').each(function () {
                 if ($(this).val() == 'Archived') {
                     $(this).prop('checked', false);
                 }
             });
         }
         var statuscount = (enrolled_option && !archived_option) ? 3 :
                           (!enrolled_option && archived_option) ? 1 :
                           (enrolled_option && archived_option) ? 4 :
                           0;
         var account_status_checked_count = 0;
         $('input:checkbox[name="account_status"]:checked').each(function() { 
             account_status_checked_count += 1;
         });	
         if(account_status_checked_count == statuscount && statuscount != 0){
             $('#account-status-option-break-selectall').html('Select None');
         }else{
             $('#account-status-option-break-selectall').html('Select All');
         }
     }
     else{
         $('#account-toggle-wrapper').slideUp(1000);
         $("#str_account_status_assgmnt_optnl_break_out").prop("disabled", true);
         $("#str_account_status_assgmnt_optnl_break_out").prop("checked", false);
         $('input:checkbox[name="account_status"]:checked').each(function() { 
             $(this).prop('checked', false);
         });	
         $('#account-status-option-break-selectall').html('Select All');
     }
 }	
 else{
     if(!enrolled_option && !archived_option){
         $("#str_account_status_assgmnt_optnl_break_out").prop("disabled", true);
     }else{
         $("#str_account_status_assgmnt_optnl_break_out").prop("disabled", false);
     }
 }	
});

$(document).on('click', '.vol_account_status', function() {
	var enrolled_option = $('#bit_all_enrolled').is(':checked'); 
	var archived_option = $('#bit_not_enrolled').is(':checked');
	var statuscount = (enrolled_option && !archived_option) ? 3 :
					  (!enrolled_option && archived_option) ? 1 :
					  (enrolled_option && archived_option) ? 4 :
					  0;
	var account_status_checked_count = 0;
	$('input:checkbox[name="account_status"]:checked').each(function() { 
		account_status_checked_count += 1;
	});	
	if(account_status_checked_count == statuscount && statuscount != 0){
		$('#account-status-option-break-selectall').html('Select None');
	}else{
		$('#account-status-option-break-selectall').html('Select All');
	}
});
/*MV-2153(K):Stops*/