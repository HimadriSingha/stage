//this is the function to show the breAk by tutor area association wide
function BreakByTutorCheckBoxAssociationWide(allassociationitems, loadingImgId, TutorDataDivId, clickLinkId, questionID, beginSurvey, endSurvey, notSelectedIds, programList, associationitemidcollectionselected, showingstatus, showtutorstudentall, showingstatusother, showtutorstudentallother, qsurveysiteuserid, thisElement, scope, questionType,omitattributelist,includetype_attribute, sites) {
	var BreakByTutorCheckBoxAssociationWide = "BreakByTutorCheckBoxAssociationWide_"+questionID;

		var BreakByTutorCheckBoxAssociationWideId = document.getElementById(BreakByTutorCheckBoxAssociationWide);
		
		if (BreakByTutorCheckBoxAssociationWideId.classList.contains('breakOutOtherThanAttribute')===true){
		BreakByTutorCheckBoxAssociationWideId.classList.remove("breakOutOtherThanAttribute");
	if (document.getElementById(TutorDataDivId).style.display == 'none' || showingstatus == 'firsttimemain' || showingstatus == 'tutor' || showingstatus == 'z-a' || showingstatus == 'a-z' || showingstatus == 'asc' || showingstatus == 'desc' || showingstatusother == 'firsttimemain' || showingstatusother == 'z-a' || showingstatusother == 'a-z' || showingstatusother == 'asc' || showingstatusother == 'desc') {
		document.getElementById(loadingImgId).style.display = 'block';
		if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain' && showingstatusother == 'firsttimemain') {
			document.getElementById(loadingImgId).style.display = 'none';
		} else {
			try{
				attributeString = (jQuery('#attributeString' + questionID).length > 0 ) ? jQuery('#attributeString' + questionID).val():'';
				neededAssociationItems = (jQuery('#theListOfAssociationItems' + questionID).length > 0 ) ? jQuery('#theListOfAssociationItems' + questionID).val() : '';
				allassociationitems = (jQuery('#hidden_allassociationitems').length > 0 ) ? jQuery('#hidden_allassociationitems').val():'';
				associationitemidcollectionselected = (jQuery('#hidden_associationitemidcollectionselected').length > 0 ) ? jQuery('#hidden_associationitemidcollectionselected').val():'';
				if(typeof getUrlVars == 'function'){
					parameterVar = getUrlVars(attributeString);
				}else{
					parameterVar = {};
				}	
				parameterVar = jQuery.extend({},parameterVar,{
					allassociationitems : allassociationitems, allassociations : neededAssociationItems, 
					associationitemidcollectionselected : associationitemidcollectionselected, qsurveysiteuserid : qsurveysiteuserid, scope : scope, sites : sites, 
					questionid : questionID, quid : questionID, beginsurvey : beginSurvey, endsurvey : endSurvey,notselectedids : notSelectedIds, 
					programlist : programList, showingstatus : showingstatus, showtutorstudentall : showtutorstudentall, 
					neededassociations : neededAssociationItems, questionType : questionType, 
					omitattributelist : omitattributelist, includetype_attribute : includetype_attribute
				});
			}
			catch(err){
				parameterVar = {
					allassociationitems: allassociationitems,
					associationitemidcollectionselected: associationitemidcollectionselected,
					qsurveysiteuserid: qsurveysiteuserid
				}
			}

			var attributeDiv = "AttributeDataDiv" + questionID;
			var attributeSelectionDiv = "AttributeSelectionDiv" + questionID;
			new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbytutorassociationwidecheckbox&questionid=" + questionID + "&beginsurvey=" + beginSurvey + "&endsurvey=" + endSurvey + "&notselectedids=" + notSelectedIds + "&programlist=" + programList + "&showingstatus=" + showingstatus + "&showtutorstudentall=" + showtutorstudentall + "&showingstatusother=" + showingstatusother + "&showtutorstudentallother=" + showtutorstudentallother), {
				method: 'post',
				parameters: parameterVar,
				onSuccess: function (returnHtml) {

					document.getElementById(loadingImgId).style.display = 'none';
					document.getElementById(clickLinkId).style.display = 'block';
					Element.update(TutorDataDivId, returnHtml.responseText);
					//Effect.toggle(TutorDataDivId, 'slide');
					if (jQuery('#' + attributeDiv).css('display') != 'none' && typeof (jQuery('#' + attributeDiv).css('display')) !== 'undefined') {
						jQuery('#' + attributeDiv).hide();
						jQuery('#' + attributeSelectionDiv).hide();
						if (showingstatus == 'firsttimemain') {
							document.getElementById(TutorDataDivId).style.display = 'block';
						}
					} else {
						jQuery('#' + attributeSelectionDiv).hide();
						if (showingstatus == 'firsttimemain' && showingstatusother == 'firsttimemain')
							Effect.BlindDown(TutorDataDivId);
					}
					/*if (showingstatus == 'firsttimemain' && showingstatusother == 'firsttimemain')
						Effect.BlindDown(TutorDataDivId);*/
				},
				onFailure: function () {
					alert('Oops...mistake on server');
				}
			});
		}
	} else {
		document.getElementById(loadingImgId).style.display = 'block';
		processAndCloseBreakBoxCheckBox(TutorDataDivId, loadingImgId);
		document.getElementById(loadingImgId).style.display = 'none';
	}
		}
}

function BreakByTutorCheckBoxAssociationWideInner(allassociationitems, loadingImgId, TutorDataDivId, clickLinkId, questionID, beginSurvey, endSurvey, notSelectedIds, programList, associationitemidcollectionselected, showingstatus, showtutorstudentall, showingstatusother, showtutorstudentallother, qsurveysiteuserid, thisElement, scope, questionType,omitattributelist,includetype_attribute, sites) {
	
	if (document.getElementById(TutorDataDivId).style.display == 'none' || showingstatus == 'firsttimemain' || showingstatus == 'tutor' || showingstatus == 'z-a' || showingstatus == 'a-z' || showingstatus == 'asc' || showingstatus == 'desc' || showingstatusother == 'firsttimemain' || showingstatusother == 'z-a' || showingstatusother == 'a-z' || showingstatusother == 'asc' || showingstatusother == 'desc') {
		document.getElementById(loadingImgId).style.display = 'block';
		if (document.getElementById(TutorDataDivId).style.display != 'none' && showingstatus == 'firsttimemain' && showingstatusother == 'firsttimemain') {
			document.getElementById(clickLinkId).style.display = 'block';
			document.getElementById(loadingImgId).style.display = 'none';
			
			
		} else {
			try{
				attributeString = (jQuery('#attributeString' + questionID).length > 0 ) ? jQuery('#attributeString' + questionID).val():'';
				neededAssociationItems = (jQuery('#theListOfAssociationItems' + questionID).length > 0 ) ? jQuery('#theListOfAssociationItems' + questionID).val() : '';
				allassociationitems = (jQuery('#hidden_allassociationitems').length > 0 ) ? jQuery('#hidden_allassociationitems').val():'';
				associationitemidcollectionselected = (jQuery('#hidden_associationitemidcollectionselected').length > 0 ) ? jQuery('#hidden_associationitemidcollectionselected').val():'';
				if(typeof getUrlVars == 'function'){
					parameterVar = getUrlVars(attributeString);
				}else{
					parameterVar = {};
				}	
				parameterVar = jQuery.extend({},parameterVar,{
					allassociationitems : allassociationitems, allassociations : neededAssociationItems, 
					associationitemidcollectionselected : associationitemidcollectionselected, qsurveysiteuserid : qsurveysiteuserid, scope : scope, sites : sites, 
					questionid : questionID, quid : questionID, beginsurvey : beginSurvey, endsurvey : endSurvey,notselectedids : notSelectedIds, 
					programlist : programList, showingstatus : showingstatus, showtutorstudentall : showtutorstudentall, 
					neededassociations : neededAssociationItems, questionType : questionType, 
					omitattributelist : omitattributelist, includetype_attribute : includetype_attribute
				});
			}
			catch(err){
				parameterVar = {
					allassociationitems: allassociationitems,
					associationitemidcollectionselected: associationitemidcollectionselected,
					qsurveysiteuserid: qsurveysiteuserid
				}
			}

			var attributeDiv = "AttributeDataDiv" + questionID;
			var attributeSelectionDiv = "AttributeSelectionDiv" + questionID;
			new Ajax.Request(encodeURI("/index.cfm?event=survey.breakbytutorassociationwidecheckbox&questionid=" + questionID + "&beginsurvey=" + beginSurvey + "&endsurvey=" + endSurvey + "&notselectedids=" + notSelectedIds + "&programlist=" + programList + "&showingstatus=" + showingstatus + "&showtutorstudentall=" + showtutorstudentall + "&showingstatusother=" + showingstatusother + "&showtutorstudentallother=" + showtutorstudentallother), {
				method: 'post',
				parameters: parameterVar,
				onSuccess: function (returnHtml) {

					document.getElementById(loadingImgId).style.display = 'none';
					document.getElementById(clickLinkId).style.display = 'block';
					Element.update(TutorDataDivId, returnHtml.responseText);
					console.log("#returnHtml.responseText#");
					//Effect.toggle(TutorDataDivId, 'slide');
					if (jQuery('#' + attributeDiv).css('display') != 'none' && typeof (jQuery('#' + attributeDiv).css('display')) !== 'undefined') {
						jQuery('#' + attributeDiv).hide();
						jQuery('#' + attributeSelectionDiv).hide();
						if (showingstatus == 'firsttimemain') {
							document.getElementById(TutorDataDivId).style.display = 'block';
						}
					} else {
						jQuery('#' + attributeSelectionDiv).hide();
						if (showingstatus == 'firsttimemain' && showingstatusother == 'firsttimemain')
							Effect.BlindDown(TutorDataDivId);
					}
					/*if (showingstatus == 'firsttimemain' && showingstatusother == 'firsttimemain')
						Effect.BlindDown(TutorDataDivId);*/
				},
				onFailure: function () {
					alert('Oops...mistake on server');
				}
			});
		}
	} else {
		document.getElementById(loadingImgId).style.display = 'block';
		processAndCloseBreakBoxCheckBox(TutorDataDivId, loadingImgId);
		document.getElementById(loadingImgId).style.display = 'none';
	}
		
}

function processAndCloseBreakBoxCheckBox(TutorDataDivId) {
	Effect.Fade(TutorDataDivId);
	//Effect.toggle(TutorDataDivId, 'slide');
	Effect.BlindUp(TutorDataDivId);
	var question1ID = parseInt(TutorDataDivId.match(/[0-9]+/)[0], 10);
	var question2ID = parseInt(TutorDataDivId.match(/[0-9]+/)[0], 10);
	
	var BreakByTutorCheckBox = "BreakByTutorCheckBox_"+question1ID;
	var BreakByTutorCheckBoxAssociationWide = "BreakByTutorCheckBoxAssociationWide_"+question2ID;
    var BreakByTutorCheckBoxId = document.getElementById(BreakByTutorCheckBox);
	var BreakByTutorCheckBoxAssociationWideId = document.getElementById(BreakByTutorCheckBoxAssociationWide);
	if(BreakByTutorCheckBoxId !== null)
	BreakByTutorCheckBoxId.classList.add("breakOutOtherThanAttribute");
    if(BreakByTutorCheckBoxAssociationWideId !== null)
	BreakByTutorCheckBoxAssociationWideId.classList.add("breakOutOtherThanAttribute");

    
	
}