

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author R Prakash
 */
public class CryptoUtils {
    private static final String ALGORITHM = "AES";
    private static final String TRANSFORMATION = "AES";
    
    public String test(String msg)
    {
        String m = msg + " CALLED";
        return m;
    }
//    public static void encrypt(File inputFile, File outputFile) 
//    {
//        doCrypto(Cipher.ENCRYPT_MODE, inputFile, outputFile);
//    }
// 
//    public static void decrypt(File inputFile, File outputFile)
//    {
//        doCrypto(Cipher.DECRYPT_MODE, inputFile, outputFile);
//    }
    public  void encrypt(String sinputFile) 
      {
          File inputFile = new File(sinputFile);          
          doCrypto(Cipher.ENCRYPT_MODE, inputFile,inputFile);
      }

      public  void decrypt(String sinputFile,String soutputFile)
      {	
        File inputFile = new File(sinputFile);
		File outputFile = new File(soutputFile);
        doCrypto(Cipher.DECRYPT_MODE, inputFile,outputFile);
      }
    private static void doCrypto(int cipherMode, File inputFile,File outputFile) {        
        String key = "Mary has one dol";
        
        try {
            Key secretKey = new SecretKeySpec(key.getBytes(), ALGORITHM);
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(cipherMode, secretKey);
             
            FileInputStream inputStream = new FileInputStream(inputFile);
			
            byte[] inputBytes = new byte[(int) inputFile.length()];
            inputStream.read(inputBytes);
             
            byte[] outputBytes = cipher.doFinal(inputBytes);
			
            
            FileOutputStream outputStream = new FileOutputStream(outputFile);
            outputStream.write(outputBytes);
             
            inputStream.close();
            outputStream.close();
             
        } catch (Exception ex) {
             System.out.println(ex.getMessage());			 
        }
    }
    public static void writeFile(String content) {
		  try {
		 
		   //String content = "This is the content to write into file";
		 
		   File file = new File("E:/Error.txt");
		 
		   // if file doesnt exists, then create it
		   if (!file.exists()) {
			file.createNewFile();
		   }
		 
		   FileWriter fileWritter = new FileWriter(file.getAbsolutePath(),true);
		   BufferedWriter bufferWritter = new BufferedWriter(fileWritter);
					 bufferWritter.write(content+'\n');
					 bufferWritter.close();
		 
				 System.out.println("Done");
		 
		  } catch (IOException e) {
		   e.printStackTrace();
		  }
		 }
}
