/*
   Tuesday, March 25, 20088:34:05 PM
   User: sa
   Server: 127.0.0.1
   Database: americalearns2
   Application: 
*/

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Program ADD
	alias_accessactivities nvarchar(500) NULL,
	alias_accessactivitiessubtext nvarchar(500) NULL,
	alias_surveyactive nvarchar(500) NULL,
	alias_surveyactivesubtext nvarchar(500) NULL,
	alias_nostrats nvarchar(500) NULL,
	alias_strats nvarchar(500) NULL,
	alias_programtitle nvarchar(500) NULL,
	alias_umbrellanews nvarchar(500) NULL
GO
COMMIT
